// Shizuku User Service 接口。
// 该接口的实现运行在 Shizuku 拉起的 app_process 中，身份为 uid 2000（shell / adb）。
// destroy() 必须使用 16777114 这个事务号：Shizuku 在 unbindUserService 时会调用它。
package com.android.adbwifi;

interface IShellService {

    // AIDL 规则：要么全部方法都写事务号，要么都不写。
    // destroy() 必须用 16777114（Shizuku 解绑时按此事务号调用），
    // 所以 exec() 也必须显式给一个号。

    /**
     * 以 uid 2000 执行一条 shell 命令。
     * @return 首行为退出码，其后为合并后的 stdout+stderr
     */
    String exec(String cmdline) = 1;

    void destroy() = 16777114;
}
