package com.android.adbwifi;

import android.Manifest;
import android.app.Application;
import android.content.Context;
import android.provider.Settings;

/**
 * 读写 Settings.Global 中的 adb_wifi_enabled。
 *
 * 前置条件：本应用必须已获得 android.permission.WRITE_SECURE_SETTINGS。
 * 该权限只能通过 `pm grant` 授予（adb / root / Shizuku），设置界面里点不出来。
 */
public final class AdbWifiController {

    private static final String KEY_ADB_WIFI_ENABLED = "adb_wifi_enabled";

    private AdbWifiController() {
    }

    /** 读取无线调试开关状态；读取失败或未授权时返回 false。 */
    public static boolean isEnabled(Context context) {
        try {
            return Settings.Global.getInt(context.getContentResolver(), KEY_ADB_WIFI_ENABLED, 0) == 1;
        } catch (Throwable t) {
            return false;
        }
    }

    /**
     * 写入无线调试开关。
     *
     * @return true 表示写入成功。开启时系统可能弹出「允许在此网络上进行无线调试吗？」，
     *         这是 Android 的系统行为，无法用代码绕过；勾选「始终允许」后该 Wi-Fi 下不再弹。
     */
    public static boolean setEnabled(Context context, boolean enabled) {
        try {
            Settings.Global.putInt(context.getContentResolver(),
                    KEY_ADB_WIFI_ENABLED, enabled ? 1 : 0);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }
}
