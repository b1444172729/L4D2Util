package com.android.adbwifi;

import android.os.RemoteException;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

/**
 * Shizuku User Service 实现。
 *
 * 这个类由 Shizuku 在它自己的 app_process 里实例化（不是普通 Android 组件），
 * 因此没有可用的 Context，registerReceiver / getContentResolver 之类都不可用。
 * 我们只用它做一件事：以 uid 2000 执行 shell 命令。
 *
 * 之所以不用 Shizuku.newProcess()：该方法在 Shizuku API 13 里已被改成 private，
 * 官方计划 API 14 移除，UserService 是官方推荐的替代方案。
 */
public class ShellService extends IShellService.Stub {

    private static final String SH = "/system/bin/sh";

    @Override
    public void destroy() {
        // Shizuku 解绑时调用；退出特权进程
        System.exit(0);
    }

    @Override
    public String exec(String cmdline) throws RemoteException {
        Process p = null;
        try {
            ProcessBuilder pb = new ProcessBuilder(SH, "-c", cmdline);
            pb.redirectErrorStream(true);   // stdout 与 stderr 合并，方便解析
            p = pb.start();
            String out = readAll(p.getInputStream());
            int code = p.waitFor();
            return code + "\n" + out;
        } catch (Throwable t) {
            return "-1\n" + t;
        } finally {
            if (p != null) {
                try {
                    p.destroy();
                } catch (Throwable ignored) {
                }
            }
        }
    }

    private static String readAll(InputStream in) {
        if (in == null) return "";
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line).append('\n');
            }
        } catch (Throwable ignored) {
        }
        return sb.toString();
    }
}
