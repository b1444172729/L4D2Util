package com.android.adbwifi;

import android.content.Context;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.MulticastSocket;
import java.nio.charset.StandardCharsets;

/**
 * 自建 mDNS / DNS-SD 客户端，用于发现 adbd 的无线调试连接端口。
 *
 * 为什么不用系统的 NsdManager：
 *   实测部分 ROM（MIUI）的 NsdService 会返回固定不变的错误端口（如 44531），
 *   那是陈旧缓存记录；而 Shizuku 能拿到正确端口，因为它压根没走系统服务，
 *   而是自己在 Java 层往 224.0.0.251:5353 发组播查询包。
 *   这里复刻同样的做法：绕开系统服务，直接从网卡收发组播。
 *
 * 需要的权限都是普通权限（INTERNET / CHANGE_WIFI_MULTICAST_STATE /
 * ACCESS_WIFI_STATE / ACCESS_NETWORK_STATE），安装即授予，不需要 pm grant。
 */
public final class AdbMdns {

    private static final String TAG = "AdbMdns";
    /** adbd 无线调试的连接服务（配对服务是 _adb-tls-pairing，每次打开配对界面才出现）。 */
    public static final String SERVICE_TYPE = "_adb-tls-connect._tcp.local.";
    private static final String GROUP_ADDR = "224.0.0.251";
    private static final int MDNS_PORT = 5353;
    private static final int SO_TIMEOUT_MS = 1200;
    private static final int BUF_SIZE = 9000;

    /** DNS 记录类型 */
    private static final int TYPE_A = 1;
    private static final int TYPE_SRV = 33;

    public interface Callback {
        void onFound(String host, int port);

        void onFailed(String reason);
    }

    public static final class Result {
        public final String address;   // 可能为 null（响应里没带 A 记录）
        public final int port;

        Result(String address, int port) {
            this.address = address;
            this.port = port;
        }
    }

    private static final Handler main = new Handler(Looper.getMainLooper());

    private AdbMdns() {
    }

    /** 异步发现；结果回调到主线程。host 为 null 时由调用方自行取本机 IP。 */
    public static void discover(Context context, int timeoutMs, Callback cb) {
        new Thread(() -> {
            MulticastSocket socket = null;
            WifiManager.MulticastLock lock = null;
            try {
                WifiManager wm = (WifiManager) context.getApplicationContext()
                        .getSystemService(Context.WIFI_SERVICE);
                if (wm != null) {
                    lock = wm.createMulticastLock("adbwifi-mdns");
                    lock.setReferenceCounted(true);
                    lock.acquire();
                }

                socket = createSocket();
                socket.setSoTimeout(SO_TIMEOUT_MS);
                InetAddress group = InetAddress.getByName(GROUP_ADDR);
                try {
                    socket.joinGroup(group);
                } catch (Throwable ignored) {
                    // 某些 ROM 上 joinGroup 会失败，但不代表收不到响应
                }

                byte[] query = buildPtrQuery(SERVICE_TYPE);
                DatagramPacket out = new DatagramPacket(query, query.length, group, MDNS_PORT);

                String host = null;
                int port = -1;
                long deadline = System.currentTimeMillis() + timeoutMs;
                long lastSend = 0;

                while (System.currentTimeMillis() < deadline) {
                    // 组播不可靠，每 1.5 秒补发一次查询
                    long now = System.currentTimeMillis();
                    if (now - lastSend > 1500) {
                        try {
                            socket.send(out);
                        } catch (Throwable ignored) {
                        }
                        lastSend = now;
                    }

                    byte[] buf = new byte[BUF_SIZE];
                    DatagramPacket in = new DatagramPacket(buf, buf.length);
                    try {
                        socket.receive(in);
                    } catch (Throwable ignored) {
                        continue;   // 超时，继续补发
                    }

                    Result r = parseResponse(in.getData(), in.getLength());
                    if (r != null && r.port > 0) {
                        port = r.port;
                        if (r.address != null) host = r.address;
                        Log.d(TAG, "mDNS -> " + host + ":" + port);
                        break;
                    }
                }

                final String finalHost = host;
                final int finalPort = port;
                if (finalPort > 0) {
                    main.post(() -> cb.onFound(finalHost, finalPort));
                } else {
                    main.post(() -> cb.onFailed(
                            "未收到 adbd 的 mDNS 响应（ROM 可能屏蔽了应用层组播）"));
                }
            } catch (Throwable t) {
                final String msg = String.valueOf(t.getMessage());
                Log.w(TAG, "mDNS 异常", t);
                main.post(() -> cb.onFailed("自建 mDNS 失败：" + msg));
            } finally {
                if (socket != null) {
                    try {
                        socket.close();
                    } catch (Throwable ignored) {
                    }
                }
                if (lock != null) {
                    try {
                        if (lock.isHeld()) lock.release();
                    } catch (Throwable ignored) {
                    }
                }
            }
        }, "adbwifi-mdns").start();
    }

    /** 优先绑 5353（部分 ROM 只认这个源端口），失败则退到随机端口。 */
    private static MulticastSocket createSocket() throws Exception {
        try {
            return new MulticastSocket(MDNS_PORT);
        } catch (Throwable t) {
            MulticastSocket s = new MulticastSocket(null);
            s.setReuseAddress(true);
            s.bind(new InetSocketAddress(0));
            return s;
        }
    }

    /** 构造 PTR 查询报文：问「_adb-tls-connect._tcp.local. 有哪些实例」。 */
    static byte[] buildPtrQuery(String serviceType) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        out.write(0);   // ID
        out.write(0);
        out.write(0);   // flags：标准查询
        out.write(0);
        out.write(0);   // QDCOUNT
        out.write(1);
        out.write(0);   // ANCOUNT
        out.write(0);
        out.write(0);   // NSCOUNT
        out.write(0);
        out.write(0);   // ARCOUNT
        out.write(0);

        for (String label : serviceType.split("\\.")) {
            if (label.isEmpty()) continue;
            out.write(label.length());
            byte[] b = label.getBytes(StandardCharsets.US_ASCII);
            out.write(b, 0, b.length);
        }
        out.write(0);   // QNAME 结束

        out.write(0);   // QTYPE = 12 (PTR)
        out.write(12);
        out.write(0);   // QCLASS = 1 (IN)
        out.write(1);

        return out.toByteArray();
    }

    /**
     * 解析 mDNS 响应，取 SRV 的端口与 A 记录的 IPv4。
     * 只看 Answer/Authority/Additional 三段；Question 段直接跳过。
     */
    static Result parseResponse(byte[] d, int len) {
        if (d == null || len < 12) return null;
        try {
            int qdcount = u16(d, 4);
            int ancount = u16(d, 6);
            int nscount = u16(d, 8);
            int arcount = u16(d, 10);

            int pos = 12;
            for (int i = 0; i < qdcount; i++) {
                pos = skipName(d, pos);
                pos += 4;               // QTYPE + QCLASS
            }

            Integer port = null;
            String addr = null;
            int total = ancount + nscount + arcount;
            for (int i = 0; i < total; i++) {
                pos = skipName(d, pos);
                int type = u16(d, pos);
                pos += 2;
                int cls = u16(d, pos);
                pos += 2;
                pos += 4;               // TTL
                int rdlen = u16(d, pos);
                pos += 2;
                int rdstart = pos;

                if (type == TYPE_SRV && cls == 1 && rdlen >= 6) {
                    // SRV: priority(2) weight(2) port(2) target(name)
                    port = u16(d, pos + 4);
                } else if (type == TYPE_A && cls == 1 && rdlen == 4) {
                    addr = (d[pos] & 0xff) + "."
                            + (d[pos + 1] & 0xff) + "."
                            + (d[pos + 2] & 0xff) + "."
                            + (d[pos + 3] & 0xff);
                }

                pos = rdstart + rdlen;
                if (pos > len) break;
            }

            if (port != null) return new Result(addr, port);
            return null;
        } catch (Throwable t) {
            return null;
        }
    }

    /** 跳过一个 DNS 名字，处理 0xC0 压缩指针。 */
    static int skipName(byte[] d, int pos) {
        int guard = 0;
        while (guard++ < 256) {
            int l = d[pos] & 0xff;
            if (l == 0) return pos + 1;
            if ((l & 0xC0) == 0xC0) return pos + 2;   // 指针，占 2 字节
            pos += 1 + l;
            if (pos >= d.length) return pos;
        }
        return pos;
    }

    private static int u16(byte[] d, int p) {
        return ((d[p] & 0xff) << 8) | (d[p + 1] & 0xff);
    }
}
