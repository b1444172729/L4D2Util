package com.android.adbwifi;

import android.content.Context;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.MulticastSocket;
import java.net.NetworkInterface;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.Enumeration;

/**
 * 自建 mDNS / DNS-SD 客户端，用于发现 adbd 的无线调试连接端口。
 *
 * 背景：Shizuku 能拿到正确端口，而系统 NsdManager 在 MIUI 上会返回陈旧的
 * 错误端口（如固定不变的 44531）。所以这里绕开系统服务，自己在 Java 层
 * 往 224.0.0.251:5353 发组播查询。
 *
 * 只用普通权限（INTERNET / CHANGE_WIFI_MULTICAST_STATE / ACCESS_WIFI_STATE），
 * 不需要 pm grant，也不需要 Shizuku。
 *
 * 由于各 ROM 对应用层组播的限制差异很大，这里做了两轮尝试并产出详细诊断，
 * 便于定位到底卡在哪一步（锁 / 绑定 / 入组 / 发送 / 接收）。
 */
public final class AdbMdns {

    private static final String TAG = "AdbMdns";
    /** adbd 无线调试的连接服务（配对服务是 _adb-tls-pairing，只在打开配对界面时出现）。 */
    public static final String SERVICE_TYPE = "_adb-tls-connect._tcp.local.";
    private static final String GROUP_ADDR = "224.0.0.251";
    private static final int MDNS_PORT = 5353;
    private static final int SO_TIMEOUT_MS = 1500;
    private static final int BUF_SIZE = 9000;

    private static final int TYPE_A = 1;
    private static final int TYPE_SRV = 33;

    public interface Callback {
        void onFound(String host, int port, String diag);

        void onFailed(String diag);
    }

    private static final Handler main = new Handler(Looper.getMainLooper());

    private AdbMdns() {
    }

    public static void discover(Context context, int timeoutMs, Callback cb) {
        new Thread(() -> {
            StringBuilder log = new StringBuilder();
            MulticastSocket socket = null;
            WifiManager.MulticastLock lock = null;

            try {
                // 1) 组播锁：Android 默认过滤组播包省电，不拿锁就收不到
                boolean lockOk = false;
                try {
                    WifiManager wm = (WifiManager) context.getApplicationContext()
                            .getSystemService(Context.WIFI_SERVICE);
                    if (wm != null) {
                        lock = wm.createMulticastLock("adbwifi-mdns");
                        lock.setReferenceCounted(true);
                        lock.acquire();
                        lockOk = lock.isHeld();
                    }
                } catch (Throwable t) {
                    Log.w(TAG, "MulticastLock 失败", t);
                }
                log.append("锁=").append(lockOk ? "OK" : "失败");

                InetAddress group = InetAddress.getByName(GROUP_ADDR);
                byte[] query = buildPtrQuery(SERVICE_TYPE);
                // 尝试两种源端口：规范要求 5353，部分 ROM 上 5353 被系统占用需退到随机端口
                int[] bindPorts = {MDNS_PORT, 0};
                long overallDeadline = System.currentTimeMillis() + timeoutMs;

                for (int bindPort : bindPorts) {
                    if (System.currentTimeMillis() > overallDeadline) break;
                    log.append("\n— 尝试源端口 ").append(bindPort).append(" —");

                    try {
                        socket = createSocket(bindPort);
                    } catch (Throwable t) {
                        log.append(" 绑定失败(").append(t.getMessage()).append(")");
                        continue;
                    }

                    // 2) 明确绑定到 wlan0，避免组播从移动数据口发出
                    NetworkInterface wifi = findWifiInterface();
                    if (wifi != null) {
                        try {
                            socket.setNetworkInterface(wifi);
                            log.append(" 网卡=").append(wifi.getName());
                        } catch (Throwable t) {
                            log.append(" 网卡绑定失败");
                        }
                    } else {
                        log.append(" 未找到 wlan 网卡");
                    }

                    // 3) 加入组播组：mDNS 响应发往组播地址，不入组就收不到
                    boolean joined = false;
                    try {
                        socket.joinGroup(group);
                        joined = true;
                    } catch (Throwable t) {
                        Log.w(TAG, "joinGroup 失败", t);
                    }
                    log.append(" 入组=").append(joined ? "OK" : "失败");

                    socket.setSoTimeout(SO_TIMEOUT_MS);
                    DatagramPacket out = new DatagramPacket(query, query.length, group, MDNS_PORT);

                    int sent = 0;
                    int received = 0;
                    long attemptDeadline = System.currentTimeMillis()
                            + Math.max(1500, timeoutMs / 2);
                    long lastSend = 0;

                    while (System.currentTimeMillis() < attemptDeadline) {
                        long now = System.currentTimeMillis();
                        if (now - lastSend > 1200) {   // 组播不可靠，周期性补发
                            try {
                                socket.send(out);
                                sent++;
                            } catch (Throwable t) {
                                log.append(" 发送异常(").append(t.getMessage()).append(")");
                            }
                            lastSend = now;
                        }

                        byte[] buf = new byte[BUF_SIZE];
                        DatagramPacket in = new DatagramPacket(buf, buf.length);
                        try {
                            socket.receive(in);
                            received++;
                        } catch (Throwable ignored) {
                            continue;   // 超时，继续补发
                        }

                        int[] srv = parseResponse(in.getData(), in.getLength());
                        if (srv != null && srv[0] > 0) {
                            String addr = (srv[1] != 0) ? intToIp(srv[1]) : null;
                            log.append(" 发送=").append(sent)
                                    .append(" 收到=").append(received)
                                    .append(" 端口=").append(srv[0]);
                            final String host = addr;
                            final int port = srv[0];
                            final String diag = log.toString();
                            main.post(() -> cb.onFound(host, port, diag));
                            return;
                        }
                    }

                    log.append(" 发送=").append(sent).append(" 收到=").append(received);
                    try {
                        socket.close();
                    } catch (Throwable ignored) {
                    }
                    socket = null;
                }

                final String diag = log.toString();
                main.post(() -> cb.onFailed(diag));

            } catch (Throwable t) {
                Log.w(TAG, "mDNS 异常", t);
                final String diag = log + "\n异常：" + t;
                main.post(() -> cb.onFailed(diag));
            } finally {
                if (socket != null) {
                    try {
                        socket.close();
                    } catch (Throwable ignored) {
                    }
                }
                if (lock != null) {
                    try {
                        if (lock.isHeld()) lock.release();
                    } catch (Throwable ignored) {
                    }
                }
            }
        }, "adbwifi-mdns").start();
    }

    /** 解析结果：[0]=端口，[1]=IPv4（0 表示响应里没带 A 记录）。 */
    private static int[] parseResponse(byte[] d, int len) {
        Result r = parse(d, len);
        if (r == null) return null;
        int ip = 0;
        if (r.address != null) {
            try {
                ip = ipToInt(r.address);
            } catch (Throwable ignored) {
            }
        }
        return new int[]{r.port, ip};
    }

    private static String intToIp(int v) {
        return (v & 0xff) + "." + ((v >> 8) & 0xff)
                + "." + ((v >> 16) & 0xff) + "." + ((v >> 24) & 0xff);
    }

    private static int ipToInt(String s) {
        String[] p = s.split("\\.");
        return (Integer.parseInt(p[0]) & 0xff)
                | ((Integer.parseInt(p[1]) & 0xff) << 8)
                | ((Integer.parseInt(p[2]) & 0xff) << 16)
                | ((Integer.parseInt(p[3]) & 0xff) << 24);
    }

    public static final class Result {
        public final String address;
        public final int port;

        Result(String address, int port) {
            this.address = address;
            this.port = port;
        }
    }

    private static MulticastSocket createSocket(int port) throws Exception {
        MulticastSocket s;
        try {
            s = new MulticastSocket(port);
        } catch (Throwable t) {
            s = new MulticastSocket(null);
            s.setReuseAddress(true);
            s.bind(new InetSocketAddress(port == 0 ? 0 : port));
        }
        return s;
    }

    private static NetworkInterface findWifiInterface() {
        try {
            Enumeration<NetworkInterface> it = NetworkInterface.getNetworkInterfaces();
            if (it == null) return null;
            for (NetworkInterface ni : Collections.list(it)) {
                String n = ni.getName();
                if (n != null && n.startsWith("wlan")) return ni;
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    /** 构造 PTR 查询报文：问「_adb-tls-connect._tcp.local. 有哪些实例」。 */
    static byte[] buildPtrQuery(String serviceType) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        out.write(0);
        out.write(0);   // ID
        out.write(0);
        out.write(0);   // flags：标准查询
        out.write(0);
        out.write(1);   // QDCOUNT = 1
        out.write(0);
        out.write(0);   // ANCOUNT
        out.write(0);
        out.write(0);   // NSCOUNT
        out.write(0);
        out.write(0);   // ARCOUNT
        out.write(0);

        for (String label : serviceType.split("\\.")) {
            if (label.isEmpty()) continue;
            out.write(label.length());
            byte[] b = label.getBytes(StandardCharsets.US_ASCII);
            out.write(b, 0, b.length);
        }
        out.write(0);   // QNAME 结束

        out.write(0);
        out.write(12);  // QTYPE = 12 (PTR)
        out.write(0);
        out.write(1);   // QCLASS = 1 (IN)

        return out.toByteArray();
    }

    /** 解析 mDNS 响应，取 SRV 的端口与 A 记录的 IPv4。 */
    static Result parse(byte[] d, int len) {
        if (d == null || len < 12) return null;
        try {
            int qdcount = u16(d, 4);
            int ancount = u16(d, 6);
            int nscount = u16(d, 8);
            int arcount = u16(d, 10);

            int pos = 12;
            for (int i = 0; i < qdcount; i++) {
                pos = skipName(d, pos);
                pos += 4;
            }

            Integer port = null;
            String addr = null;
            int total = ancount + nscount + arcount;
            for (int i = 0; i < total; i++) {
                pos = skipName(d, pos);
                int type = u16(d, pos);
                pos += 2;
                int cls = u16(d, pos);
                pos += 2;
                pos += 4;               // TTL
                int rdlen = u16(d, pos);
                pos += 2;
                int rdstart = pos;

                if (type == TYPE_SRV && cls == 1 && rdlen >= 6) {
                    port = u16(d, pos + 4);
                } else if (type == TYPE_A && cls == 1 && rdlen == 4) {
                    addr = (d[pos] & 0xff) + "."
                            + (d[pos + 1] & 0xff) + "."
                            + (d[pos + 2] & 0xff) + "."
                            + (d[pos + 3] & 0xff);
                }

                pos = rdstart + rdlen;
                if (pos > len) break;
            }

            if (port != null) return new Result(addr, port);
            return null;
        } catch (Throwable t) {
            return null;
        }
    }

    /** 跳过一个 DNS 名字，处理 0xC0 压缩指针。 */
    static int skipName(byte[] d, int pos) {
        int guard = 0;
        while (guard++ < 256) {
            if (pos >= d.length) return pos;
            int l = d[pos] & 0xff;
            if (l == 0) return pos + 1;
            if ((l & 0xC0) == 0xC0) return pos + 2;
            pos += 1 + l;
        }
        return pos;
    }

    private static int u16(byte[] d, int p) {
        return ((d[p] & 0xff) << 8) | (d[p + 1] & 0xff);
    }
}
