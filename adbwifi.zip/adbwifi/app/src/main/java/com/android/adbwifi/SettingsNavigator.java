package com.android.adbwifi;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.provider.Settings;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

/**
 * 直达系统「无线调试」设置页。
 *
 * 各 ROM 的实现差异极大，没有统一的公开 Intent，所以这里按可信度从高到低
 * 依次尝试，哪个能解析就跳哪个，全部失败则退回设置首页。
 *
 * 实测情况：
 *   - Android 12+ AOSP：可用 TileService.ACTION_QS_TILE_PREFERENCES 直达子页
 *   - Android 11 AOSP：源码里没有直达子页的入口，通常只能落到开发者选项页
 *   - MIUI：包名是 com.android.settings，能否直达取决于 ROM 是否保留了对应 Activity
 */
public final class SettingsNavigator {

    private static final String TAG = "SettingsNavigator";
    private static final String PKG_SETTINGS = "com.android.settings";

    /** 返回实际打开的层级描述，供 UI 提示。 */
    public static String openWirelessDebugging(Context context) {
        List<Intent> candidates = buildCandidates();

        PackageManager pm = context.getPackageManager();
        for (Intent intent : candidates) {
            if (intent == null) continue;
            try {
                ResolveInfo ri = pm.resolveActivity(intent, 0);
                if (ri == null) continue;
                Intent launch = intent;
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(launch);
                return describe(intent);
            } catch (Throwable t) {
                Log.w(TAG, "跳转失败：" + intent, t);
            }
        }

        // 最后兜底：设置首页
        try {
            Intent home = new Intent(Settings.ACTION_SETTINGS);
            home.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(home);
            return "设置首页（未找到无线调试入口，请在搜索框搜「无线调试」）";
        } catch (Throwable t) {
            return null;
        }
    }

    private static List<Intent> buildCandidates() {
        List<Intent> list = new ArrayList<>();

        // 1) 系统公开的无线调试 action（部分 Android 11+ ROM 支持）
        list.add(new Intent("android.settings.WIRELESS_DEBUGGING_SETTINGS"));

        // 2) 直接指定 Settings 内部的无线调试 Activity（各版本类名不同）
        String[] activities = {
                "com.android.settings.Settings$WirelessDebuggingActivity",
                "com.android.settings.Settings$WirelessDebuggingSettingsActivity",
                "com.android.settings.Settings$AdbWirelessSettingsActivity",
                "com.android.settings.development.WirelessDebuggingActivity",
                "com.android.settings.wifi.WirelessDebuggingActivity",
        };
        for (String cls : activities) {
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setComponent(new ComponentName(PKG_SETTINGS, cls));
            list.add(i);
        }

        // 3) Android 12+ 可用：通过「快捷开关」的偏好页 intent 直达
        try {
            Intent qs = new Intent("android.service.quicksettings.action.QS_TILE_PREFERENCES");
            qs.putExtra(Intent.EXTRA_COMPONENT_NAME, new ComponentName(
                    PKG_SETTINGS,
                    "com.android.settings.development.qstile.DevelopmentTiles$WirelessDebugging"));
            qs.setPackage(PKG_SETTINGS);
            list.add(qs);
        } catch (Throwable ignored) {
        }

        // 4) 开发者选项页（绝大多数机器都能到，进去后需手动往下找无线调试）
        list.add(new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS));

        // 5) MIUI 的更多设置页
        try {
            Intent miui = new Intent(Intent.ACTION_VIEW);
            miui.setComponent(new ComponentName(PKG_SETTINGS,
                    "com.android.settings.Settings$DevelopmentSettingsActivity"));
            list.add(miui);
        } catch (Throwable ignored) {
        }

        return list;
    }

    private static String describe(Intent intent) {
        String action = intent.getAction();
        ComponentName cn = intent.getComponent();

        if ("android.settings.WIRELESS_DEBUGGING_SETTINGS".equals(action)) {
            return "无线调试页（系统 action 直达）";
        }
        if ("android.service.quicksettings.action.QS_TILE_PREFERENCES".equals(action)) {
            return "无线调试页（快捷开关偏好页直达）";
        }
        if (cn != null) {
            String cls = cn.getClassName();
            if (cls != null && cls.contains("WirelessDebugging")) {
                return "无线调试页（Activity 直达）";
            }
            return "开发者选项页（请在「调试」分组里找无线调试）";
        }
        if (Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS.equals(action)) {
            return "开发者选项页（请在「调试」分组里找无线调试）";
        }
        return "已打开设置";
    }
}
