package com.android.adbwifi;

import android.content.Context;
import android.net.wifi.WifiManager;
import android.util.Log;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Locale;

/**
 * 获取本机 Wi-Fi IPv4 地址。
 *
 * 注意：Android 8+ 起 WifiManager.getConnectionInfo() 受位置权限约束（部分 ROM
 * 直接抛 SecurityException，或返回 null / ip=0），所以每一步都必须单独 try，
 * 且失败后要能降级到遍历网卡，绝不能把异常抛给调用方。
 */
public final class NetUtils {

    private static final String TAG = "NetUtils";

    private NetUtils() {
    }

    /** 拿不到就返回 127.0.0.1，永远不为 null。 */
    public static String getWifiIp(Context context) {
        String ip = null;
        try {
            ip = fromWifiManager(context);
        } catch (Throwable t) {
            Log.w(TAG, "WifiManager 取 IP 失败（多为缺少位置权限）", t);
        }
        if (ip == null) {
            try {
                ip = fromInterfaces();
            } catch (Throwable t) {
                Log.w(TAG, "遍历网卡取 IP 失败", t);
            }
        }
        return ip != null ? ip : "127.0.0.1";
    }

    private static String fromWifiManager(Context context) {
        if (context == null) return null;
        WifiManager wm = (WifiManager) context.getApplicationContext()
                .getSystemService(Context.WIFI_SERVICE);
        if (wm == null) return null;
        android.net.wifi.WifiInfo info = wm.getConnectionInfo();
        if (info == null) return null;
        int ip = info.getIpAddress();
        if (ip == 0) return null;
        return String.format(Locale.US, "%d.%d.%d.%d",
                ip & 0xff, (ip >> 8) & 0xff, (ip >> 16) & 0xff, (ip >> 24) & 0xff);
    }

    /**
     * 兜底：遍历网卡（Android 10+ 上 WifiManager 可能拿不到）。
     * getNetworkInterfaces() 会抛 SocketException（受检异常），这里内部消化，绝不外抛。
     */
    private static String fromInterfaces() {
        try {
            Enumeration<NetworkInterface> itf = NetworkInterface.getNetworkInterfaces();
            if (itf == null) return null;
            String fallback = null;
            for (NetworkInterface ni : Collections.list(itf)) {
                String name = ni.getName();
                if (name == null) continue;
                Enumeration<InetAddress> addrs = ni.getInetAddresses();
                if (addrs == null) continue;
                for (InetAddress addr : Collections.list(addrs)) {
                    if (addr == null || addr.isLoopbackAddress()) continue;
                    if (!(addr instanceof Inet4Address)) continue;
                    String s = addr.getHostAddress();
                    if (s == null) continue;
                    if (name.startsWith("wlan")) return s;
                    if (fallback == null) fallback = s;
                }
            }
            return fallback;
        } catch (Throwable t) {
            Log.w(TAG, "遍历网卡失败", t);
            return null;
        }
    }
}
