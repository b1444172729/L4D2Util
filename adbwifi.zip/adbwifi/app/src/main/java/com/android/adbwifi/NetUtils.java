package com.android.adbwifi;

import android.content.Context;
import android.net.wifi.WifiManager;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Locale;

/** 获取本机 Wi-Fi IPv4 地址。 */
public final class NetUtils {

    private NetUtils() {
    }

    public static String getWifiIp(Context context) {
        try {
            WifiManager wm = (WifiManager) context.getApplicationContext()
                    .getSystemService(Context.WIFI_SERVICE);
            if (wm != null) {
                int ip = wm.getConnectionInfo().getIpAddress();
                if (ip != 0) {
                    return String.format(Locale.US, "%d.%d.%d.%d",
                            ip & 0xff, (ip >> 8) & 0xff, (ip >> 16) & 0xff, (ip >> 24) & 0xff);
                }
            }
        } catch (Throwable ignored) {
        }
        return getInterfaceIp();
    }

    /** 兜底：遍历网卡（Android 10+ 上 WifiManager 可能拿不到）。 */
    private static String getInterfaceIp() {
        try {
            Enumeration<NetworkInterface> itf = NetworkInterface.getNetworkInterfaces();
            if (itf == null) return null;
            String fallback = null;
            for (NetworkInterface ni : Collections.list(itf)) {
                String name = ni.getName();
                Enumeration<InetAddress> addrs = ni.getInetAddresses();
                for (InetAddress addr : Collections.list(addrs)) {
                    if (addr.isLoopbackAddress() || !(addr instanceof Inet4Address)) continue;
                    String s = addr.getHostAddress();
                    if (s == null) continue;
                    if (name != null && name.startsWith("wlan")) return s;
                    if (fallback == null) fallback = s;
                }
            }
            return fallback;
        } catch (Throwable t) {
            return null;
        }
    }
}
