package com.android.adbwifi;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * 崩溃捕获。真机闪退时往往不方便连 logcat，所以三处落地，总能拿到一份：
 *   1. SharedPreferences —— 下次打开 App 显示在界面上
 *   2. 剪贴板            —— 闪退后直接长按粘贴即可
 *   3. getExternalFilesDir()/crash.txt —— 无需权限，MT 管理器可直接打开
 */
public final class CrashHandler implements Thread.UncaughtExceptionHandler {

    private static final String TAG = "CrashHandler";
    public static final String PREF = "crash";
    public static final String KEY = "last";

    private final Context ctx;
    private final Thread.UncaughtExceptionHandler defaultHandler;

    private CrashHandler(Context ctx, Thread.UncaughtExceptionHandler def) {
        this.ctx = ctx.getApplicationContext();
        this.defaultHandler = def;
    }

    public static void install(Context ctx) {
        Thread.setDefaultUncaughtExceptionHandler(
                new CrashHandler(ctx, Thread.getDefaultUncaughtExceptionHandler()));
    }

    @Override
    public void uncaughtException(Thread thread, Throwable throwable) {
        String text;
        try {
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            pw.println("时间：" + new SimpleDateFormat("MM-dd HH:mm:ss", Locale.CHINA)
                    .format(new Date()));
            pw.println("线程：" + thread.getName());
            pw.println("设备：" + Build.MANUFACTURER + " " + Build.MODEL
                    + " / Android " + Build.VERSION.RELEASE
                    + " (API " + Build.VERSION.SDK_INT + ")");
            try {
                PackageInfo pi = ctx.getPackageManager().getPackageInfo(ctx.getPackageName(), 0);
                pw.println("版本：" + pi.versionName + " (" + pi.versionCode + ")");
            } catch (PackageManager.NameNotFoundException ignored) {
            }
            pw.println("异常：" + throwable);
            pw.println("---- 堆栈 ----");
            throwable.printStackTrace(pw);
            Throwable cause = throwable.getCause();
            while (cause != null) {
                pw.println("Caused by: " + cause);
                cause.printStackTrace(pw);
                cause = cause.getCause();
            }
            pw.close();
            text = sw.toString();

            saveToPref(text);
            saveToClipboard(text);
            saveToFile(text);
        } catch (Throwable ignored) {
            text = null;
        }
        if (text != null) Log.e(TAG, text);

        if (defaultHandler != null) {
            defaultHandler.uncaughtException(thread, throwable);
        }
    }

    private void saveToPref(String text) {
        try {
            ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                    .edit().putString(KEY, text).apply();
        } catch (Throwable ignored) {
        }
    }

    private void saveToClipboard(String text) {
        try {
            android.content.ClipboardManager cm =
                    (android.content.ClipboardManager) ctx
                            .getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) {
                cm.setPrimaryClip(android.content.ClipData
                        .newPlainText("adbwifi-crash", text));
            }
        } catch (Throwable ignored) {
        }
    }

    private void saveToFile(String text) {
        try {
            File dir = ctx.getExternalFilesDir(null);
            if (dir == null) return;
            if (!dir.exists() && !dir.mkdirs()) return;
            File f = new File(dir, "crash.txt");
            try (FileOutputStream fos = new FileOutputStream(f, false)) {
                fos.write(text.getBytes(StandardCharsets.UTF_8));
            }
        } catch (Throwable ignored) {
        }
    }

    public static String getLast(Context ctx) {
        try {
            return ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, null);
        } catch (Throwable t) {
            return null;
        }
    }

    public static void clear(Context ctx) {
        try {
            ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().remove(KEY).apply();
        } catch (Throwable ignored) {
        }
    }
}
