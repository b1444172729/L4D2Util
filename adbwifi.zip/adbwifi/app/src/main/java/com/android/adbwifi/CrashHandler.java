package com.android.adbwifi;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * 崩溃捕获：把堆栈存进 SharedPreferences，下次打开 App 时显示在界面上。
 * 目的很实际——真机闪退时不一定能连 logcat，让 App 自己把原因吐出来。
 */
public final class CrashHandler implements Thread.UncaughtExceptionHandler {

    public static final String PREF = "crash";
    public static final String KEY = "last";

    private final Context ctx;
    private final Thread.UncaughtExceptionHandler defaultHandler;

    private CrashHandler(Context ctx, Thread.UncaughtExceptionHandler def) {
        this.ctx = ctx.getApplicationContext();
        this.defaultHandler = def;
    }

    public static void install(Context ctx) {
        Thread.setDefaultUncaughtExceptionHandler(
                new CrashHandler(ctx, Thread.getDefaultUncaughtExceptionHandler()));
    }

    @Override
    public void uncaughtException(Thread thread, Throwable throwable) {
        try {
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            pw.println("时间：" + new SimpleDateFormat("MM-dd HH:mm:ss", Locale.CHINA)
                    .format(new Date()));
            pw.println("线程：" + thread.getName());
            pw.println("设备：" + Build.MANUFACTURER + " " + Build.MODEL
                    + " / Android " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")");
            try {
                PackageInfo pi = ctx.getPackageManager().getPackageInfo(ctx.getPackageName(), 0);
                pw.println("版本：" + pi.versionName + " (" + pi.versionCode + ")");
            } catch (PackageManager.NameNotFoundException ignored) {
            }
            pw.println("异常：" + throwable);
            pw.println("---- 堆栈 ----");
            throwable.printStackTrace(pw);
            Throwable cause = throwable.getCause();
            while (cause != null) {
                pw.println("Caused by: " + cause);
                cause.printStackTrace(pw);
                cause = cause.getCause();
            }
            pw.close();

            SharedPreferences sp = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE);
            sp.edit().putString(KEY, sw.toString()).apply();
        } catch (Throwable ignored) {
        }

        if (defaultHandler != null) {
            defaultHandler.uncaughtException(thread, throwable);
        }
    }

    public static String getLast(Context ctx) {
        try {
            return ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, null);
        } catch (Throwable t) {
            return null;
        }
    }

    public static void clear(Context ctx) {
        try {
            ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().remove(KEY).apply();
        } catch (Throwable ignored) {
        }
    }
}
