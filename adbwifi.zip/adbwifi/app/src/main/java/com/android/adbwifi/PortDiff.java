package com.android.adbwifi;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * 端口判定用差分法，不靠猜。
 *
 * 背景：/proc/net/tcp 里混着很多别的进程的监听端口（例如固定不变的 44531），
 * 只看一次快照无法区分哪个是 adbd 的；而 adbd 的 socket inode 在 MIUI 上
 * 常常读不到（/proc/<pid>/fd 被拒）。
 *
 * 差分法原理：
 *   无线调试「关闭」时采一次 LISTEN 端口集合 OFF
 *   无线调试「开启」后再采一次集合 ON
 *   ON - OFF = 本次开启新增的监听端口 = adbd 的端口
 *
 * 开关无线调试只需要 WRITE_SECURE_SETTINGS（已由 pm grant 授予），不需要 Shizuku。
 * 读端口优先尝试本应用直接读 /proc/net/tcp，读不到才借 Shizuku 的 shell 身份。
 */
public final class PortDiff {

    private PortDiff() {
    }

    /** shell 身份抓取所有 LISTEN 端口（tcp + tcp6），一次 IPC。 */
    public static String buildListenCommand() {
        return "cat /proc/net/tcp 2>/dev/null; cat /proc/net/tcp6 2>/dev/null";
    }

    /**
     * 本应用进程直接读 /proc/net/tcp。
     * Android 10+ 可能限制普通应用读取，被拒时返回空串——调用方据此判断是否需要 shell。
     */
    public static String readListenDirect() {
        StringBuilder sb = new StringBuilder();
        appendFile("/proc/net/tcp", sb);
        appendFile("/proc/net/tcp6", sb);
        return sb.toString();
    }

    private static void appendFile(String path, StringBuilder sb) {
        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader(path));
            String line;
            int n = 0;
            while ((line = br.readLine()) != null) {
                sb.append(line).append('\n');
                n++;
                if (n > 4000) break;
            }
        } catch (Throwable ignored) {
            // 权限不足或文件不存在：静默跳过
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (Throwable ignored) {
                }
            }
        }
    }

    /** 解析 LISTEN 端口，去重，保持出现顺序。 */
    public static Set<Integer> parseListen(String raw) {
        Set<Integer> ports = new LinkedHashSet<>();
        if (raw == null) return ports;
        for (String line : raw.split("\n")) {
            String[] f = line.trim().split("\\s+");
            if (f.length < 4) continue;
            if (!"0A".equalsIgnoreCase(f[3])) continue;   // 0A = TCP_LISTEN
            int idx = f[1].indexOf(':');
            if (idx < 0 || idx + 1 >= f[1].length()) continue;
            try {
                int p = Integer.parseInt(f[1].substring(idx + 1), 16);
                if (p > 0 && p < 65536) ports.add(p);
            } catch (NumberFormatException ignored) {
            }
        }
        return ports;
    }

    /** ON 里有、OFF 里没有的端口，即本次开启新增的监听。 */
    public static List<Integer> diff(Set<Integer> on, Set<Integer> off) {
        List<Integer> added = new ArrayList<>();
        if (on == null) return added;
        for (Integer p : on) {
            if (off == null || !off.contains(p)) added.add(p);
        }
        return added;
    }

    /**
     * 从候选中挑最像 adbd 的那个。
     * 差分后通常只剩一个；若仍有多个，按 adbd 端口特征排序。
     */
    public static int pickBest(List<Integer> candidates) {
        if (candidates == null || candidates.isEmpty()) return -1;
        if (candidates.size() == 1) return candidates.get(0);

        int best = -1;
        int bestScore = Integer.MIN_VALUE;
        for (Integer p : candidates) {
            int score = 0;
            // adbd 的随机端口历史上多落在 30000~60999
            if (p >= 30000 && p <= 60999) score += 100;
            // 端口越大越像（系统固定服务多用小端口）
            score += Math.min(p / 1000, 60);
            if (score > bestScore) {
                bestScore = score;
                best = p;
            }
        }
        return best;
    }
}
