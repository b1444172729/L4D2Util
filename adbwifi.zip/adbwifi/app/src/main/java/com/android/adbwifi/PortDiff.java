package com.android.adbwifi;

import android.util.Log;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * 端口判定不再靠「猜」，改用差分法。
 *
 * 背景：/proc/net/tcp 里混着很多别的进程的监听端口（例如固定不变的 44531），
 * 单看一次快照无法区分哪个是 adbd 的。而 adbd 的 socket inode 在 MIUI 上
 * 常常读不到（/proc/<pid>/fd 被拒），所以 inode 匹配也不稳。
 *
 * 差分法原理（100% 可靠）：
 *   无线调试「关闭」时采一次 LISTEN 端口集合 OFF
 *   无线调试「开启」后再采一次集合 ON
 *   ON - OFF = 本次开启新增的监听端口 = adbd 的端口
 *
 * 因为无线调试开关我们自己就能控制（已有 WRITE_SECURE_SETTINGS），
 * 所以这个流程可以全自动完成，无需用户干预。
 */
public final class PortDiff {

    private static final String TAG = "PortDiff";

    private PortDiff() {
    }

    /** 抓取当前所有 LISTEN 端口（tcp + tcp6），一次 IPC。 */
    public static String buildListenCommand() {
        return "cat /proc/net/tcp 2>/dev/null; cat /proc/net/tcp6 2>/dev/null";
    }

    /** 解析 LISTEN 端口，去重，保持出现顺序。 */
    public static Set<Integer> parseListen(String raw) {
        Set<Integer> ports = new LinkedHashSet<>();
        if (raw == null) return ports;
        for (String line : raw.split("\n")) {
            String[] f = line.trim().split("\\s+");
            if (f.length < 4) continue;
            if (!"0A".equalsIgnoreCase(f[3])) continue;   // 0A = TCP_LISTEN
            int idx = f[1].indexOf(':');
            if (idx < 0 || idx + 1 >= f[1].length()) continue;
            try {
                int p = Integer.parseInt(f[1].substring(idx + 1), 16);
                if (p > 0 && p < 65536) ports.add(p);
            } catch (NumberFormatException ignored) {
            }
        }
        return ports;
    }

    /** ON 里有、OFF 里没有的端口，即本次开启新增的监听。 */
    public static List<Integer> diff(Set<Integer> on, Set<Integer> off) {
        List<Integer> added = new ArrayList<>();
        if (on == null) return added;
        for (Integer p : on) {
            if (off == null || !off.contains(p)) added.add(p);
        }
        return added;
    }

    /**
     * 从候选中挑最像 adbd 的那个。
     * 差分后通常只剩一个；若仍有多个，按 adbd 端口特征排序。
     */
    public static int pickBest(List<Integer> candidates) {
        if (candidates == null || candidates.isEmpty()) return -1;
        if (candidates.size() == 1) return candidates.get(0);

        int best = -1;
        int bestScore = Integer.MIN_VALUE;
        for (Integer p : candidates) {
            int score = 0;
            // adbd 的随机端口历史上多落在 30000~60999
            if (p >= 30000 && p <= 60999) score += 100;
            // 端口越大越像（系统固定服务多用小端口）
            score += Math.min(p / 1000, 60);
            Log.d(TAG, "candidate " + p + " score=" + score);
            if (score > bestScore) {
                bestScore = score;
                best = p;
            }
        }
        return best;
    }

    /**
     * 固定端口：让 adbd 监听 5555，从此端口不再随机变。
     *
     * 原理：设置 service.adb.tcp.port 后重启 adbd，它会按该属性监听 TCP。
     * 风险：adbd 重启会中断当前无线调试连接，可能导致需要重新配对一次；
     *       若失败，重新开关一次无线调试即可恢复。
     */
    public static String buildFixPortCommand(int port) {
        return "setprop service.adb.tcp.port " + port + ";"
                + " setprop ctl.restart adbd";
    }

    /** 恢复随机端口（取消固定）。 */
    public static String buildUnfixPortCommand() {
        return "setprop service.adb.tcp.port -1;"
                + " setprop ctl.restart adbd";
    }
}
