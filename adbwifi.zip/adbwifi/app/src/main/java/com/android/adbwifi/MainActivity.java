package com.android.adbwifi;

import android.Manifest;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public class MainActivity extends AppCompatActivity {

    private static final String SHIZUKU_PKG = "moe.shizuku.privileged.api";
    private static final String PERM = Manifest.permission.WRITE_SECURE_SETTINGS;
    private static final int REQ_SHIZUKU = 1001;
    private static final int DISCOVER_TIMEOUT_MS = 8000;

    private TextView tvPerm;
    private TextView tvState;
    private TextView tvEndpoint;
    private TextView tvCrash;
    private Button btnGrant;
    private Button btnToggle;

    private final Handler ui = new Handler(Looper.getMainLooper());

    private String foundHost;
    private int foundPort = -1;

    /** shell 身份是否实测可用（由后台线程刷新，避免误报已授权） */
    private volatile boolean shellVerified = false;
    private volatile boolean shizukuAlive = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        CrashHandler.install(this);
        setContentView(R.layout.activity_main);

        tvPerm = findViewById(R.id.tv_perm);
        tvState = findViewById(R.id.tv_state);
        tvEndpoint = findViewById(R.id.tv_endpoint);
        tvCrash = findViewById(R.id.tv_crash);
        btnGrant = findViewById(R.id.btn_grant);
        btnToggle = findViewById(R.id.btn_toggle);

        ShizukuAuth.init(this, REQ_SHIZUKU, this::refreshPermissionUi);

        findViewById(R.id.btn_grant).setOnClickListener(v -> onGrantClicked());
        findViewById(R.id.btn_copy_cmd).setOnClickListener(v -> {
            copy(getGrantCommand());
            toast("已复制，粘到 Termux / aShell 里执行");
        });
        findViewById(R.id.btn_toggle).setOnClickListener(v -> onToggleClicked());
        findViewById(R.id.btn_refresh).setOnClickListener(v -> discoverPort());
        findViewById(R.id.btn_copy_connect).setOnClickListener(v -> {
            if (foundHost == null || foundPort <= 0) {
                toast("先点「重新扫描端口」");
                return;
            }
            copy("adb connect " + foundHost + ":" + foundPort);
            toast("已复制 adb connect 命令");
        });
        findViewById(R.id.btn_shizuku).setOnClickListener(v -> launchShizuku());
        findViewById(R.id.btn_open_adb_page).setOnClickListener(v -> openAdbWifiPage());
        findViewById(R.id.btn_copy_crash).setOnClickListener(v -> {
            String s = CrashHandler.getLast(this);
            if (s == null) {
                toast("没有崩溃记录");
                return;
            }
            copy(s);
            toast("已复制崩溃日志");
        });

        showLastCrash();
        refreshPermissionUi();
        refreshStateUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshPermissionUi();
        refreshStateUi();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    // ---------- 崩溃日志 ----------

    private void showLastCrash() {
        String last = CrashHandler.getLast(this);
        if (last == null || last.isEmpty()) return;
        tvCrash.setVisibility(View.VISIBLE);
        tvCrash.setText("上次崩溃日志（可长按选中复制）：\n" + last);
        findViewById(R.id.btn_copy_crash).setVisibility(View.VISIBLE);
    }

    // ---------- 权限 ----------

    private boolean hasSecureSettingsPermission() {
        try {
            return ContextCompat.checkSelfPermission(this, PERM)
                    == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) {
            return false;
        }
    }

    private String getGrantCommand() {
        return "adb shell pm grant " + getPackageName()
                + " " + ShizukuAuth.PERM_WRITE_SECURE_SETTINGS;
    }

    /**
     * 权限状态展示。
     * Shizuku 是否可用不采信 API 的 checkSelfPermission（实测会误报已授权），
     * 改为后台真跑一条 `id` 看是否 uid=2000，结果回写到界面。
     */
    private void refreshPermissionUi() {
        boolean granted = hasSecureSettingsPermission();

        try {
            shizukuAlive = ShizukuAuth.isBinderAlive();
        } catch (Throwable t) {
            shizukuAlive = false;
        }

        StringBuilder sb = new StringBuilder();
        if (granted) {
            sb.append(getString(R.string.perm_granted));
        } else {
            sb.append(getString(R.string.perm_denied));
        }
        sb.append("\nShizuku 服务：").append(shizukuAlive ? "运行中" : "未运行");
        sb.append("\nShizuku 授权：").append(shellVerified ? "已实测可用（uid 2000）"
                : (shizukuAlive ? "检测中…" : "不可用"));
        tvPerm.setText(sb.toString());

        btnGrant.setVisibility(granted ? View.GONE : View.VISIBLE);

        // 后台实测，避免主线程阻塞
        if (shizukuAlive) {
            new Thread(() -> {
                boolean ok = false;
                try {
                    ok = ShizukuAuth.verifyShell();
                } catch (Throwable ignored) {
                }
                final boolean finalOk = ok;
                ui.post(() -> {
                    shellVerified = finalOk;
                    StringBuilder b = new StringBuilder();
                    b.append(hasSecureSettingsPermission()
                            ? getString(R.string.perm_granted)
                            : getString(R.string.perm_denied));
                    b.append("\nShizuku 服务：").append(shizukuAlive ? "运行中" : "未运行");
                    b.append("\nShizuku 授权：").append(finalOk
                            ? "已实测可用（uid 2000）"
                            : "未授权 —— 请在 Shizuku 的授权应用列表里允许本应用");
                    tvPerm.setText(b.toString());
                });
            }, "adbwifi-verify").start();
        } else {
            shellVerified = false;
        }
    }

    private void onGrantClicked() {
        if (!ShizukuAuth.isBinderAlive()) {
            toast("Shizuku 未运行，请先启动 Shizuku（或用复制的命令在 Termux 里授权）");
            launchShizuku();
            return;
        }
        if (!ShizukuAuth.hasShizukuPermission()) {
            toast("请在弹出的 Shizuku 授权请求中点「允许」");
            ShizukuAuth.requestShizukuPermission();
            return;
        }
        toast("正在授权…");
        new Thread(() -> {
            ShizukuAuth.ExecResult r = ShizukuAuth.grantSelfExec();
            boolean ok = r != null && r.isSuccess();
            String msg = ok ? "授权成功，现在可以一键开关了"
                    : "授权失败：" + (r == null ? "未知错误" : r.message());
            ui.post(() -> {
                refreshPermissionUi();
                toast(msg);
            });
        }).start();
    }

    // ---------- 开关 ----------

    private void onToggleClicked() {
        if (!hasSecureSettingsPermission()) {
            toast("尚未授权 WRITE_SECURE_SETTINGS，先点上面的授权按钮");
            return;
        }
        boolean cur = AdbWifiController.isEnabled(this);
        boolean target = !cur;
        boolean ok = AdbWifiController.setEnabled(this, target);
        if (!ok) {
            toast("写入失败：无权限或被系统拒绝");
            return;
        }
        toast(target ? "已开启，正在扫描端口…" : "已关闭");
        refreshStateUi();
        if (target) {
            ui.postDelayed(this::discoverPort, 1500);
        } else {
            foundPort = -1;
            tvEndpoint.setText(R.string.endpoint_empty);
        }
    }

    private void refreshStateUi() {
        boolean on = AdbWifiController.isEnabled(this);
        tvState.setText(on ? R.string.state_on : R.string.state_off);
        btnToggle.setEnabled(hasSecureSettingsPermission());
    }

    // ---------- 端口发现：差分法 ----------

    private void discoverPort() {
        try {
            doDiscover();
        } catch (Throwable t) {
            tvEndpoint.setText("扫描异常：" + t);
        }
    }

    /**
     * 差分法：
     *   关闭无线调试 → 采 LISTEN 集合 OFF
     *   开启无线调试 → 采 LISTEN 集合 ON
     *   ON - OFF = adbd 本次监听的端口
     *
     * 开关无线调试只需要 WRITE_SECURE_SETTINGS，**不需要 Shizuku**。
     * 读 /proc/net/tcp 先试本应用直接读；读不到（Android 10+ 常限制）
     * 才借 Shizuku 的 shell 身份。
     */
    private void doDiscover() {
        if (!hasSecureSettingsPermission()) {
            tvEndpoint.setText("尚未授权 WRITE_SECURE_SETTINGS，无法开关无线调试，也就无法判定端口。\n"
                    + "请先点上面的授权按钮。");
            return;
        }

        tvEndpoint.setText("正在扫描…");
        foundPort = -1;
        final AtomicBoolean diffDone = new AtomicBoolean(false);
        final AtomicIntegerRef mdnsPort = new AtomicIntegerRef();

        // ① 自建 mDNS：不需要 Shizuku，也不需要任何特殊权限，优先出结果
        startMdns(mdnsPort, diffDone);

        // ② 差分法：作为校验/兜底（需要能读 /proc/net，直接或借 Shizuku）
        new Thread(() -> {
            String direct = PortDiff.readListenDirect();
            final boolean canDirect = !direct.trim().isEmpty();
            final boolean useShell = !canDirect && ShizukuAuth.verifyShell();

            if (!canDirect && !useShell) {
                // 没有 shell 可用：mDNS 是唯一手段，让它自己出结果即可
                ui.postDelayed(() -> {
                    if (!diffDone.get() && mdnsPort.get() <= 0) {
                        tvEndpoint.setText("自建 mDNS 也没有结果。\n"
                                + "本 ROM 可能屏蔽了应用层组播。\n"
                                + "可点「无线调试页」去设置里查看端口。");
                    }
                }, DISCOVER_TIMEOUT_MS + 2000);
                return;
            }

            Set<Integer> off = null;
            Set<Integer> on = null;
            try {
                if (AdbWifiController.isEnabled(MainActivity.this)) {
                    AdbWifiController.setEnabled(MainActivity.this, false);
                }
                Thread.sleep(1200);
                off = PortDiff.parseListen(snapshot(canDirect));

                AdbWifiController.setEnabled(MainActivity.this, true);
                Thread.sleep(2500);
                on = PortDiff.parseListen(snapshot(canDirect));
            } catch (Throwable t) {
                return;   // 差分失败不影响 mDNS 的结果
            }

            final List<Integer> added = PortDiff.diff(on, off);
            final int port = PortDiff.pickBest(added);
            if (port <= 0) return;

            final String ip = NetUtils.getWifiIp(MainActivity.this);
            final int offSize = (off == null) ? 0 : off.size();
            final String via = canDirect ? "本应用直接读 /proc/net" : "Shizuku shell";
            final int mdns = mdnsPort.get();

            ui.post(() -> {
                refreshStateUi();
                if (mdns > 0 && mdns != port) {
                    // 两者不一致：以差分为准，并把差异告诉用户
                    showResult(ip, port, "差分法判定（" + via + "；关闭时 " + offSize
                            + " 个监听，开启后新增 " + added + "）"
                            + "\n注意：自建 mDNS 给的是 " + mdns + "，与差分结果不一致，已按差分法修正",
                            added);
                } else if (mdns > 0) {
                    showResult(ip, port, "自建 mDNS 与差分法一致（" + via + " 二次确认），可信度最高",
                            added);
                } else {
                    showResult(ip, port, "差分法判定（" + via + "；关闭时 " + offSize
                            + " 个监听，开启后新增 " + added + "）", added);
                }
                diffDone.set(true);
            });
        }, "adbwifi-diff").start();
    }

    /** 按已确定的方式抓一次端口快照。 */
    private String snapshot(boolean canDirect) {
        if (canDirect) return PortDiff.readListenDirect();
        return ShizukuAuth.listenPortsRaw();
    }

    /**
     * 自建 mDNS（复刻 Shizuku 的做法）：绕开系统 NsdService，
     * 直接往 224.0.0.251:5353 发组播查询，拿 adbd 广播的真实端口。
     * 不需要 Shizuku，也不需要 pm grant。
     */
    private void startMdns(final AtomicIntegerRef mdnsPort, final AtomicBoolean diffDone) {
        AdbMdns.discover(this, DISCOVER_TIMEOUT_MS, new AdbMdns.Callback() {
            @Override
            public void onFound(String host, int port) {
                mdnsPort.set(port);
                if (diffDone.get()) return;      // 差分已给出结论，不覆盖
                String h = (host != null) ? host : NetUtils.getWifiIp(MainActivity.this);
                showResult(h, port, "自建 mDNS 发现（未依赖 Shizuku）"
                        + "\n差分法还在校验中…", new ArrayList<>());
            }

            @Override
            public void onFailed(String reason) {
                if (diffDone.get() || mdnsPort.get() > 0) return;
                tvEndpoint.setText(getString(R.string.endpoint_empty)
                        + "\n" + reason
                        + "\n正在等待差分法结果…");
            }
        });
    }

    /** 简易的可变 int 容器，供线程间传递单一数值。 */
    private static final class AtomicIntegerRef {
        private final AtomicInteger value = new AtomicInteger(-1);

        void set(int v) {
            value.set(v);
        }

        int get() {
            return value.get();
        }
    }

    // ---------- 展示 ----------

    private void showResult(String ip, int port, String note, List<Integer> others) {
        foundHost = (ip != null) ? ip : "127.0.0.1";
        foundPort = port;
        StringBuilder sb = new StringBuilder();
        sb.append(foundHost).append(":").append(port);
        sb.append("\nadb connect ").append(foundHost).append(":").append(port);
        sb.append("\n\n[").append(note).append("]");
        if (others != null && others.size() > 1) {
            sb.append("\n其他候选：").append(others);
        }
        tvEndpoint.setText(sb.toString());
    }

    // ---------- 杂项 ----------

    private void launchShizuku() {
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage(SHIZUKU_PKG);
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } else {
                toast("未检测到 Shizuku（moe.shizuku.privileged.api）");
            }
        } catch (Throwable t) {
            toast("拉起 Shizuku 失败：" + t.getMessage());
        }
    }

    /** 一键跳到系统设置的无线调试页，省去层层点进去的麻烦。 */
    private void openAdbWifiPage() {
        try {
            String where = SettingsNavigator.openWirelessDebugging(this);
            if (where == null) {
                toast("打不开设置页");
            } else {
                toast("已打开：" + where);
            }
        } catch (Throwable t) {
            toast("跳转失败：" + t.getMessage());
        }
    }

    private void copy(String text) {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("adbwifi", text));
        } catch (Throwable ignored) {
        }
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
