package com.android.adbwifi;

import android.Manifest;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends AppCompatActivity {

    private static final String SHIZUKU_PKG = "moe.shizuku.privileged.api";
    private static final String PERM = Manifest.permission.WRITE_SECURE_SETTINGS;
    private static final int REQ_SHIZUKU = 1001;
    private static final int DISCOVER_TIMEOUT_MS = 8000;

    private TextView tvPerm;
    private TextView tvState;
    private TextView tvEndpoint;
    private TextView tvCrash;
    private Button btnGrant;
    private Button btnToggle;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private PortFinder finder;

    /** 最近一次扫到的地址 */
    private String foundHost;
    private int foundPort = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        CrashHandler.install(this);
        setContentView(R.layout.activity_main);

        tvPerm = findViewById(R.id.tv_perm);
        tvState = findViewById(R.id.tv_state);
        tvEndpoint = findViewById(R.id.tv_endpoint);
        tvCrash = findViewById(R.id.tv_crash);
        btnGrant = findViewById(R.id.btn_grant);
        btnToggle = findViewById(R.id.btn_toggle);

        finder = new PortFinder(this);
        ShizukuAuth.init(this, REQ_SHIZUKU, this::refreshPermissionUi);

        findViewById(R.id.btn_grant).setOnClickListener(v -> onGrantClicked());
        findViewById(R.id.btn_copy_cmd).setOnClickListener(v -> {
            copy(getGrantCommand());
            toast("已复制，粘到 Termux / aShell 里执行");
        });
        findViewById(R.id.btn_toggle).setOnClickListener(v -> onToggleClicked());
        findViewById(R.id.btn_refresh).setOnClickListener(v -> discoverPort());
        findViewById(R.id.btn_copy_connect).setOnClickListener(v -> {
            if (foundHost == null || foundPort <= 0) {
                toast("先点「重新扫描端口」");
                return;
            }
            copy("adb connect " + foundHost + ":" + foundPort);
            toast("已复制 adb connect 命令");
        });
        findViewById(R.id.btn_shizuku).setOnClickListener(v -> launchShizuku());
        findViewById(R.id.btn_copy_crash).setOnClickListener(v -> {
            String s = CrashHandler.getLast(this);
            if (s == null) {
                toast("没有崩溃记录");
                return;
            }
            copy(s);
            toast("已复制崩溃日志");
        });

        showLastCrash();
        refreshPermissionUi();
        refreshStateUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshPermissionUi();
        refreshStateUi();
    }

    @Override
    protected void onDestroy() {
        if (finder != null) finder.stop();
        super.onDestroy();
    }

    // ---------- 崩溃日志 ----------

    private void showLastCrash() {
        String last = CrashHandler.getLast(this);
        if (last == null || last.isEmpty()) return;
        tvCrash.setVisibility(View.VISIBLE);
        tvCrash.setText("上次崩溃日志（可长按选中复制）：\n" + last);
        findViewById(R.id.btn_copy_crash).setVisibility(View.VISIBLE);
    }

    // ---------- 权限 ----------

    private boolean hasSecureSettingsPermission() {
        return ContextCompat.checkSelfPermission(this, PERM)
                == PackageManager.PERMISSION_GRANTED;
    }

    private String getGrantCommand() {
        return "adb shell pm grant " + getPackageName()
                + " " + ShizukuAuth.PERM_WRITE_SECURE_SETTINGS;
    }

    private void refreshPermissionUi() {
        boolean granted = hasSecureSettingsPermission();
        boolean szAlive = ShizukuAuth.isBinderAlive();
        boolean szGranted = ShizukuAuth.hasShizukuPermission();

        tvPerm.setText(granted
                ? getString(R.string.perm_granted)
                : getString(R.string.perm_denied)
                + "\nShizuku：" + (szAlive ? (szGranted ? "已授权本应用" : "未授权本应用") : "未运行"));

        btnGrant.setVisibility(granted ? View.GONE : View.VISIBLE);
    }

    private void onGrantClicked() {
        if (!ShizukuAuth.isBinderAlive()) {
            toast("Shizuku 未运行，请先启动 Shizuku（或用复制的命令在 Termux 里授权）");
            launchShizuku();
            return;
        }
        if (!ShizukuAuth.hasShizukuPermission()) {
            toast("请在弹出的 Shizuku 授权请求中点「允许」");
            ShizukuAuth.requestShizukuPermission();
            return;
        }
        toast("正在授权…");
        new Thread(() -> {
            ShizukuAuth.ExecResult r = ShizukuAuth.grantSelfExec();
            boolean ok = r != null && r.isSuccess();
            String msg = ok ? "授权成功，现在可以一键开关了"
                    : "授权失败：" + (r == null ? "未知错误" : r.message());
            ui.post(() -> {
                refreshPermissionUi();
                toast(msg);
            });
        }).start();
    }

    // ---------- 开关 ----------

    private void onToggleClicked() {
        if (!hasSecureSettingsPermission()) {
            toast("尚未授权 WRITE_SECURE_SETTINGS，先点上面的授权按钮");
            return;
        }
        boolean cur = AdbWifiController.isEnabled(this);
        boolean target = !cur;
        boolean ok = AdbWifiController.setEnabled(this, target);
        if (!ok) {
            toast("写入失败：无权限或被系统拒绝");
            return;
        }
        toast(target ? "已开启，正在扫描端口…" : "已关闭");
        refreshStateUi();
        if (target) {
            ui.postDelayed(this::discoverPort, 1500);
        } else {
            foundPort = -1;
            tvEndpoint.setText(R.string.endpoint_empty);
        }
    }

    private void refreshStateUi() {
        boolean on = AdbWifiController.isEnabled(this);
        tvState.setText(on ? R.string.state_on : R.string.state_off);
        btnToggle.setEnabled(hasSecureSettingsPermission());
    }

    // ---------- 端口发现 ----------

    /**
     * 两条路并行，谁先出结果用谁：
     *   A. shell 身份读 /proc/net/tcp（快、准，但需要本应用已被 Shizuku 授权）
     *   B. mDNS 发现 _adb-tls-connect._tcp（MIUI 上常常扫不到）
     */
    private void discoverPort() {
        tvEndpoint.setText("正在扫描…");
        foundPort = -1;
        final AtomicBoolean done = new AtomicBoolean(false);

        boolean szOk = ShizukuAuth.hasShizukuPermission();
        if (szOk) {
            new Thread(() -> {
                String raw = ShizukuAuth.catProcNetTcp();
                List<Integer> ports = PortFinder.parseListenPorts(raw);
                String ip = NetUtils.getWifiIp(MainActivity.this);
                if (!ports.isEmpty() && ip != null && done.compareAndSet(false, true)) {
                    ui.post(() -> showEndpoint(ip, ports, raw != null));
                }
            }, "adbwifi-scan").start();
        }

        finder.discover(DISCOVER_TIMEOUT_MS, new PortFinder.Callback() {
            @Override
            public void onFound(String host, int port) {
                if (!done.compareAndSet(false, true)) return;
                String h = (host != null) ? host : NetUtils.getWifiIp(MainActivity.this);
                showEndpoint((h != null) ? h : "127.0.0.1",
                        new java.util.ArrayList<>(java.util.Collections.singletonList(port)), true);
            }

            @Override
            public void onFailed(String reason) {
                if (done.get()) return;
                ui.post(() -> {
                    if (!szOk) {
                        tvEndpoint.setText(getString(R.string.endpoint_empty)
                                + "\n原因：" + reason
                                + "\n\n没拿到 shell 身份，无法兜底。请在 Shizuku 的"
                                + "「授权应用」里允许本应用，再重新扫描。");
                    } else {
                        tvEndpoint.setText(getString(R.string.endpoint_empty)
                                + "\n原因：" + reason
                                + "\n（shell 扫描也没结果，确认无线调试确实已开启）");
                    }
                });
            }
        });
    }

    private void showEndpoint(String ip, List<Integer> ports, boolean real) {
        foundHost = ip;
        foundPort = ports.get(0);
        StringBuilder sb = new StringBuilder();
        sb.append(ip).append(":").append(foundPort);
        sb.append("\nadb connect ").append(ip).append(":").append(foundPort);
        if (ports.size() > 1) {
            sb.append("\n其他候选端口：").append(ports.subList(1, Math.min(ports.size(), 6)));
        }
        tvEndpoint.setText(sb.toString());
    }

    // ---------- 杂项 ----------

    private void launchShizuku() {
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage(SHIZUKU_PKG);
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } else {
                toast("未检测到 Shizuku（moe.shizuku.privileged.api）");
            }
        } catch (Throwable t) {
            toast("拉起 Shizuku 失败：" + t.getMessage());
        }
    }

    private void copy(String text) {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("adbwifi", text));
        } catch (Throwable ignored) {
        }
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
