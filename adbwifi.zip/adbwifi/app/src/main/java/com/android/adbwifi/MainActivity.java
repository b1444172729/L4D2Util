package com.android.adbwifi;

import android.Manifest;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    private static final String SHIZUKU_PKG = "moe.shizuku.privileged.api";
    private static final String PERM = Manifest.permission.WRITE_SECURE_SETTINGS;
    private static final int REQ_SHIZUKU = 1001;
    private static final int DISCOVER_TIMEOUT_MS = 8000;

    private TextView tvPerm;
    private TextView tvState;
    private TextView tvEndpoint;
    private TextView tvCrash;
    private Button btnGrant;
    private Button btnToggle;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private PortFinder finder;

    private String foundHost;
    private int foundPort = -1;

    /** shell 身份是否实测可用（由后台线程刷新，避免误报已授权） */
    private volatile boolean shellVerified = false;
    private volatile boolean shizukuAlive = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        CrashHandler.install(this);
        setContentView(R.layout.activity_main);

        tvPerm = findViewById(R.id.tv_perm);
        tvState = findViewById(R.id.tv_state);
        tvEndpoint = findViewById(R.id.tv_endpoint);
        tvCrash = findViewById(R.id.tv_crash);
        btnGrant = findViewById(R.id.btn_grant);
        btnToggle = findViewById(R.id.btn_toggle);

        finder = new PortFinder(this);
        ShizukuAuth.init(this, REQ_SHIZUKU, this::refreshPermissionUi);

        findViewById(R.id.btn_grant).setOnClickListener(v -> onGrantClicked());
        findViewById(R.id.btn_copy_cmd).setOnClickListener(v -> {
            copy(getGrantCommand());
            toast("已复制，粘到 Termux / aShell 里执行");
        });
        findViewById(R.id.btn_toggle).setOnClickListener(v -> onToggleClicked());
        findViewById(R.id.btn_refresh).setOnClickListener(v -> discoverPort());
        findViewById(R.id.btn_copy_connect).setOnClickListener(v -> {
            if (foundHost == null || foundPort <= 0) {
                toast("先点「重新扫描端口」");
                return;
            }
            copy("adb connect " + foundHost + ":" + foundPort);
            toast("已复制 adb connect 命令");
        });
        findViewById(R.id.btn_shizuku).setOnClickListener(v -> launchShizuku());
        findViewById(R.id.btn_open_adb_page).setOnClickListener(v -> openAdbWifiPage());
        findViewById(R.id.btn_copy_crash).setOnClickListener(v -> {
            String s = CrashHandler.getLast(this);
            if (s == null) {
                toast("没有崩溃记录");
                return;
            }
            copy(s);
            toast("已复制崩溃日志");
        });

        showLastCrash();
        refreshPermissionUi();
        refreshStateUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshPermissionUi();
        refreshStateUi();
    }

    @Override
    protected void onDestroy() {
        if (finder != null) finder.stop();
        super.onDestroy();
    }

    // ---------- 崩溃日志 ----------

    private void showLastCrash() {
        String last = CrashHandler.getLast(this);
        if (last == null || last.isEmpty()) return;
        tvCrash.setVisibility(View.VISIBLE);
        tvCrash.setText("上次崩溃日志（可长按选中复制）：\n" + last);
        findViewById(R.id.btn_copy_crash).setVisibility(View.VISIBLE);
    }

    // ---------- 权限 ----------

    private boolean hasSecureSettingsPermission() {
        try {
            return ContextCompat.checkSelfPermission(this, PERM)
                    == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) {
            return false;
        }
    }

    private String getGrantCommand() {
        return "adb shell pm grant " + getPackageName()
                + " " + ShizukuAuth.PERM_WRITE_SECURE_SETTINGS;
    }

    /**
     * 权限状态展示。
     * Shizuku 是否可用不采信 API 的 checkSelfPermission（实测会误报已授权），
     * 改为后台真跑一条 `id` 看是否 uid=2000，结果回写到界面。
     */
    private void refreshPermissionUi() {
        boolean granted = hasSecureSettingsPermission();

        try {
            shizukuAlive = ShizukuAuth.isBinderAlive();
        } catch (Throwable t) {
            shizukuAlive = false;
        }

        StringBuilder sb = new StringBuilder();
        if (granted) {
            sb.append(getString(R.string.perm_granted));
        } else {
            sb.append(getString(R.string.perm_denied));
        }
        sb.append("\nShizuku 服务：").append(shizukuAlive ? "运行中" : "未运行");
        sb.append("\nShizuku 授权：").append(shellVerified ? "已实测可用（uid 2000）"
                : (shizukuAlive ? "检测中…" : "不可用"));
        tvPerm.setText(sb.toString());

        btnGrant.setVisibility(granted ? View.GONE : View.VISIBLE);

        // 后台实测，避免主线程阻塞
        if (shizukuAlive) {
            new Thread(() -> {
                boolean ok = false;
                try {
                    ok = ShizukuAuth.verifyShell();
                } catch (Throwable ignored) {
                }
                final boolean finalOk = ok;
                ui.post(() -> {
                    shellVerified = finalOk;
                    StringBuilder b = new StringBuilder();
                    b.append(hasSecureSettingsPermission()
                            ? getString(R.string.perm_granted)
                            : getString(R.string.perm_denied));
                    b.append("\nShizuku 服务：").append(shizukuAlive ? "运行中" : "未运行");
                    b.append("\nShizuku 授权：").append(finalOk
                            ? "已实测可用（uid 2000）"
                            : "未授权 —— 请在 Shizuku 的授权应用列表里允许本应用");
                    tvPerm.setText(b.toString());
                });
            }, "adbwifi-verify").start();
        } else {
            shellVerified = false;
        }
    }

    private void onGrantClicked() {
        if (!ShizukuAuth.isBinderAlive()) {
            toast("Shizuku 未运行，请先启动 Shizuku（或用复制的命令在 Termux 里授权）");
            launchShizuku();
            return;
        }
        if (!ShizukuAuth.hasShizukuPermission()) {
            toast("请在弹出的 Shizuku 授权请求中点「允许」");
            ShizukuAuth.requestShizukuPermission();
            return;
        }
        toast("正在授权…");
        new Thread(() -> {
            ShizukuAuth.ExecResult r = ShizukuAuth.grantSelfExec();
            boolean ok = r != null && r.isSuccess();
            String msg = ok ? "授权成功，现在可以一键开关了"
                    : "授权失败：" + (r == null ? "未知错误" : r.message());
            ui.post(() -> {
                refreshPermissionUi();
                toast(msg);
            });
        }).start();
    }

    // ---------- 开关 ----------

    private void onToggleClicked() {
        if (!hasSecureSettingsPermission()) {
            toast("尚未授权 WRITE_SECURE_SETTINGS，先点上面的授权按钮");
            return;
        }
        boolean cur = AdbWifiController.isEnabled(this);
        boolean target = !cur;
        boolean ok = AdbWifiController.setEnabled(this, target);
        if (!ok) {
            toast("写入失败：无权限或被系统拒绝");
            return;
        }
        toast(target ? "已开启，正在扫描端口…" : "已关闭");
        refreshStateUi();
        if (target) {
            ui.postDelayed(this::discoverPort, 1500);
        } else {
            foundPort = -1;
            tvEndpoint.setText(R.string.endpoint_empty);
        }
    }

    private void refreshStateUi() {
        boolean on = AdbWifiController.isEnabled(this);
        tvState.setText(on ? R.string.state_on : R.string.state_off);
        btnToggle.setEnabled(hasSecureSettingsPermission());
    }

    // ---------- 端口发现：差分法 ----------

    private void discoverPort() {
        try {
            doDiscover();
        } catch (Throwable t) {
            tvEndpoint.setText("扫描异常：" + t);
        }
    }

    /**
     * 差分法：
     *   关闭无线调试 → 采 LISTEN 集合 OFF
     *   开启无线调试 → 采 LISTEN 集合 ON
     *   ON - OFF = adbd 本次监听的端口
     *
     * 开关无线调试只需要 WRITE_SECURE_SETTINGS，**不需要 Shizuku**。
     * 读 /proc/net/tcp 先试本应用直接读；读不到（Android 10+ 常限制）
     * 才借 Shizuku 的 shell 身份。
     */
    private void doDiscover() {
        if (!hasSecureSettingsPermission()) {
            tvEndpoint.setText("尚未授权 WRITE_SECURE_SETTINGS，无法开关无线调试，也就无法判定端口。\n"
                    + "请先点上面的授权按钮。");
            return;
        }

        tvEndpoint.setText("正在扫描（会重开一次无线调试，约 4 秒）…");
        foundPort = -1;

        new Thread(() -> {
            // 判断读端口走哪条路
            String direct = PortDiff.readListenDirect();
            final boolean canDirect = !direct.trim().isEmpty();
            final boolean useShell = !canDirect && ShizukuAuth.verifyShell();

            if (!canDirect && !useShell) {
                ui.post(() -> tvEndpoint.setText(
                        "无法读取端口列表。\n"
                                + "本应用直接读 /proc/net/tcp 被系统拒绝，"
                                + "且 Shizuku 的 shell 身份也不可用。\n\n"
                                + "解决：在 Shizuku 的「授权应用」里允许本应用后重试。"));
                return;
            }

            Set<Integer> off = null;
            Set<Integer> on = null;
            try {
                // 1) 关闭，采基线
                if (AdbWifiController.isEnabled(MainActivity.this)) {
                    AdbWifiController.setEnabled(MainActivity.this, false);
                }
                Thread.sleep(1200);
                off = PortDiff.parseListen(snapshot(canDirect));

                // 2) 打开，等 adbd 起来
                AdbWifiController.setEnabled(MainActivity.this, true);
                Thread.sleep(2500);
                on = PortDiff.parseListen(snapshot(canDirect));
            } catch (Throwable t) {
                ui.post(() -> tvEndpoint.setText("差分扫描异常：" + t));
                return;
            }

            final List<Integer> added = PortDiff.diff(on, off);
            final int port = PortDiff.pickBest(added);
            final String ip = NetUtils.getWifiIp(MainActivity.this);
            final int offSize = (off == null) ? 0 : off.size();
            final String onSnapshot = (on == null) ? "" : String.valueOf(on);
            final String via = canDirect ? "本应用直接读 /proc/net" : "Shizuku shell";

            ui.post(() -> {
                refreshStateUi();
                if (port > 0) {
                    showResult(ip, port, "差分法判定（" + via + "；关闭时 " + offSize
                            + " 个监听，开启后新增 " + added + "）", added);
                } else {
                    StringBuilder sb = new StringBuilder();
                    sb.append(getString(R.string.endpoint_empty));
                    sb.append("\n差分后没有新增监听端口（读取方式：").append(via).append("）。\n");
                    if (!onSnapshot.isEmpty()) {
                        sb.append("当前 LISTEN 端口：").append(onSnapshot).append("\n");
                    }
                    sb.append("\n确认无线调试确实已开启，或尝试 mDNS…");
                    tvEndpoint.setText(sb.toString());
                    startMdnsFallback();
                }
            });
        }, "adbwifi-diff").start();
    }

    /** 按已确定的方式抓一次端口快照。 */
    private String snapshot(boolean canDirect) {
        if (canDirect) return PortDiff.readListenDirect();
        return ShizukuAuth.listenPortsRaw();
    }

    /** 仅当差分失败时才走 mDNS，结果标注为待核对。 */
    private void startMdnsFallback() {
        try {
            finder.discover(DISCOVER_TIMEOUT_MS, new PortFinder.Callback() {
                @Override
                public void onFound(String host, int port) {
                    if (foundPort > 0) return;
                    String h = (host != null) ? host : NetUtils.getWifiIp(MainActivity.this);
                    ui.post(() -> showResult(h, port,
                            "mDNS 发现（可信度低，请与系统设置页核对）", new ArrayList<>()));
                }

                @Override
                public void onFailed(String reason) {
                    // 不覆盖已有提示
                }
            });
        } catch (Throwable ignored) {
        }
    }

    // ---------- 展示 ----------

    private void showResult(String ip, int port, String note, List<Integer> others) {
        foundHost = (ip != null) ? ip : "127.0.0.1";
        foundPort = port;
        StringBuilder sb = new StringBuilder();
        sb.append(foundHost).append(":").append(port);
        sb.append("\nadb connect ").append(foundHost).append(":").append(port);
        sb.append("\n\n[").append(note).append("]");
        if (others != null && others.size() > 1) {
            sb.append("\n其他候选：").append(others);
        }
        tvEndpoint.setText(sb.toString());
    }

    // ---------- 杂项 ----------

    private void launchShizuku() {
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage(SHIZUKU_PKG);
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } else {
                toast("未检测到 Shizuku（moe.shizuku.privileged.api）");
            }
        } catch (Throwable t) {
            toast("拉起 Shizuku 失败：" + t.getMessage());
        }
    }

    /** 一键跳到系统设置的无线调试页，省去层层点进去的麻烦。 */
    private void openAdbWifiPage() {
        try {
            String where = SettingsNavigator.openWirelessDebugging(this);
            if (where == null) {
                toast("打不开设置页");
            } else {
                toast("已打开：" + where);
            }
        } catch (Throwable t) {
            toast("跳转失败：" + t.getMessage());
        }
    }

    private void copy(String text) {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("adbwifi", text));
        } catch (Throwable ignored) {
        }
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
