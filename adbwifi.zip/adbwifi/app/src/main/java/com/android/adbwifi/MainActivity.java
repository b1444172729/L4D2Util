package com.android.adbwifi;

import android.Manifest;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    private static final String SHIZUKU_PKG = "moe.shizuku.privileged.api";
    private static final String PERM = Manifest.permission.WRITE_SECURE_SETTINGS;
    private static final int REQ_SHIZUKU = 1001;
    private static final int DISCOVER_TIMEOUT_MS = 8000;
    private static final int FIXED_PORT = 5555;

    private TextView tvPerm;
    private TextView tvState;
    private TextView tvEndpoint;
    private TextView tvCrash;
    private EditText etPort;
    private Button btnGrant;
    private Button btnToggle;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private PortFinder finder;

    /** 最近一次扫到的地址 */
    private String foundHost;
    private int foundPort = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        CrashHandler.install(this);
        setContentView(R.layout.activity_main);

        tvPerm = findViewById(R.id.tv_perm);
        tvState = findViewById(R.id.tv_state);
        tvEndpoint = findViewById(R.id.tv_endpoint);
        tvCrash = findViewById(R.id.tv_crash);
        etPort = findViewById(R.id.et_port);
        btnGrant = findViewById(R.id.btn_grant);
        btnToggle = findViewById(R.id.btn_toggle);

        finder = new PortFinder(this);
        ShizukuAuth.init(this, REQ_SHIZUKU, this::refreshPermissionUi);

        findViewById(R.id.btn_grant).setOnClickListener(v -> onGrantClicked());
        findViewById(R.id.btn_copy_cmd).setOnClickListener(v -> {
            copy(getGrantCommand());
            toast("已复制，粘到 Termux / aShell 里执行");
        });
        findViewById(R.id.btn_toggle).setOnClickListener(v -> onToggleClicked());
        findViewById(R.id.btn_refresh).setOnClickListener(v -> discoverPort());
        findViewById(R.id.btn_copy_connect).setOnClickListener(v -> {
            if (foundHost == null || foundPort <= 0) {
                toast("先点「重新扫描端口」");
                return;
            }
            copy("adb connect " + foundHost + ":" + foundPort);
            toast("已复制 adb connect 命令");
        });
        findViewById(R.id.btn_shizuku).setOnClickListener(v -> launchShizuku());
        findViewById(R.id.btn_use_port).setOnClickListener(v -> onUseManualPort());
        findViewById(R.id.btn_fix_port).setOnClickListener(v -> onFixPortClicked());
        findViewById(R.id.btn_diag).setOnClickListener(v -> onDiagClicked());
        findViewById(R.id.btn_copy_crash).setOnClickListener(v -> {
            String s = CrashHandler.getLast(this);
            if (s == null) {
                toast("没有崩溃记录");
                return;
            }
            copy(s);
            toast("已复制崩溃日志");
        });

        showLastCrash();
        refreshPermissionUi();
        refreshStateUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshPermissionUi();
        refreshStateUi();
    }

    @Override
    protected void onDestroy() {
        if (finder != null) finder.stop();
        super.onDestroy();
    }

    // ---------- 崩溃日志 ----------

    private void showLastCrash() {
        String last = CrashHandler.getLast(this);
        if (last == null || last.isEmpty()) return;
        tvCrash.setVisibility(View.VISIBLE);
        tvCrash.setText("上次崩溃日志（可长按选中复制）：\n" + last);
        findViewById(R.id.btn_copy_crash).setVisibility(View.VISIBLE);
    }

    // ---------- 权限 ----------

    private boolean hasSecureSettingsPermission() {
        try {
            return ContextCompat.checkSelfPermission(this, PERM)
                    == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) {
            return false;
        }
    }

    private String getGrantCommand() {
        return "adb shell pm grant " + getPackageName()
                + " " + ShizukuAuth.PERM_WRITE_SECURE_SETTINGS;
    }

    private void refreshPermissionUi() {
        boolean granted = hasSecureSettingsPermission();
        boolean szAlive = ShizukuAuth.isBinderAlive();
        boolean szGranted = ShizukuAuth.hasShizukuPermission();

        tvPerm.setText(granted
                ? getString(R.string.perm_granted)
                : getString(R.string.perm_denied)
                + "\nShizuku：" + (szAlive ? (szGranted ? "已授权本应用" : "未授权本应用") : "未运行"));

        btnGrant.setVisibility(granted ? View.GONE : View.VISIBLE);
    }

    private void onGrantClicked() {
        if (!ShizukuAuth.isBinderAlive()) {
            toast("Shizuku 未运行，请先启动 Shizuku（或用复制的命令在 Termux 里授权）");
            launchShizuku();
            return;
        }
        if (!ShizukuAuth.hasShizukuPermission()) {
            toast("请在弹出的 Shizuku 授权请求中点「允许」");
            ShizukuAuth.requestShizukuPermission();
            return;
        }
        toast("正在授权…");
        new Thread(() -> {
            ShizukuAuth.ExecResult r = ShizukuAuth.grantSelfExec();
            boolean ok = r != null && r.isSuccess();
            String msg = ok ? "授权成功，现在可以一键开关了"
                    : "授权失败：" + (r == null ? "未知错误" : r.message());
            ui.post(() -> {
                refreshPermissionUi();
                toast(msg);
            });
        }).start();
    }

    // ---------- 开关 ----------

    private void onToggleClicked() {
        if (!hasSecureSettingsPermission()) {
            toast("尚未授权 WRITE_SECURE_SETTINGS，先点上面的授权按钮");
            return;
        }
        boolean cur = AdbWifiController.isEnabled(this);
        boolean target = !cur;
        boolean ok = AdbWifiController.setEnabled(this, target);
        if (!ok) {
            toast("写入失败：无权限或被系统拒绝");
            return;
        }
        toast(target ? "已开启，正在扫描端口…" : "已关闭");
        refreshStateUi();
        if (target) {
            ui.postDelayed(this::discoverPort, 1500);
        } else {
            foundPort = -1;
            tvEndpoint.setText(R.string.endpoint_empty);
        }
    }

    private void refreshStateUi() {
        boolean on = AdbWifiController.isEnabled(this);
        tvState.setText(on ? R.string.state_on : R.string.state_off);
        btnToggle.setEnabled(hasSecureSettingsPermission());
    }

    // ---------- 端口发现：差分法 ----------

    private void discoverPort() {
        try {
            doDiscoverByDiff();
        } catch (Throwable t) {
            tvEndpoint.setText("扫描异常：" + t);
        }
    }

    /**
     * 差分法（主路径，100% 可靠）：
     *   关闭无线调试 → 采 LISTEN 集合 OFF
     *   开启无线调试 → 采 LISTEN 集合 ON
     *   ON - OFF = adbd 本次监听的端口
     *
     * 不依赖 mDNS，不依赖读 adbd 的 fd（MIUI 上常被拒）。
     * 开关由本应用自己控制，全程自动。
     */
    private void doDiscoverByDiff() {
        boolean szOk;
        try {
            szOk = ShizukuAuth.hasShizukuPermission();
        } catch (Throwable t) {
            szOk = false;
        }

        if (!szOk) {
            tvEndpoint.setText(getString(R.string.endpoint_empty)
                    + "\n没拿到 shell 身份，无法自动判定端口。\n"
                    + "请在 Shizuku 的「授权应用」里允许本应用，再重新扫描。\n"
                    + "或在下方手动填端口。");
            startMdnsFallback(null);
            return;
        }

        tvEndpoint.setText("正在扫描（会开关一次无线调试，约 4 秒）…");
        foundPort = -1;

        new Thread(() -> {
            Set<Integer> off = null;
            Set<Integer> on = null;
            try {
                // 1) 先关掉，采基线
                if (AdbWifiController.isEnabled(MainActivity.this)) {
                    AdbWifiController.setEnabled(MainActivity.this, false);
                }
                Thread.sleep(1200);
                off = PortDiff.parseListen(ShizukuAuth.listenPortsRaw());

                // 2) 再打开，等 adbd 起来
                AdbWifiController.setEnabled(MainActivity.this, true);
                Thread.sleep(2500);
                on = PortDiff.parseListen(ShizukuAuth.listenPortsRaw());
            } catch (Throwable t) {
                ui.post(() -> tvEndpoint.setText("差分扫描异常：" + t));
                return;
            }

            final List<Integer> added = PortDiff.diff(on, off);
            final int port = PortDiff.pickBest(added);
            final String ip = NetUtils.getWifiIp(MainActivity.this);
            // lambda 只能引用 effectively final 的变量，所以在这里固化快照
            final int offSize = (off == null) ? 0 : off.size();
            final String onSnapshot = (on == null) ? "" : String.valueOf(on);

            ui.post(() -> {
                refreshStateUi();
                if (port > 0) {
                    showResult(ip, port, "差分法判定（关闭时 " + offSize
                            + " 个监听，开启后新增 " + added + "）", added);
                } else {
                    StringBuilder sb = new StringBuilder();
                    sb.append(getString(R.string.endpoint_empty));
                    sb.append("\n差分后没有新增监听端口。\n");
                    if (!onSnapshot.isEmpty()) {
                        sb.append("当前 LISTEN 端口：").append(onSnapshot).append("\n");
                    }
                    sb.append("\n可能无线调试未真正起来，请在设置页确认，")
                            .append("或点「诊断」把环境信息发出来。\n")
                            .append("也可在下方手动填端口。");
                    tvEndpoint.setText(sb.toString());
                }
            });
        }, "adbwifi-diff").start();

        // mDNS 作为对照，但只在差分没结果时才用
        startMdnsFallback(0);
    }

    private void startMdnsFallback(Integer delayHint) {
        try {
            finder.discover(DISCOVER_TIMEOUT_MS, new PortFinder.Callback() {
                @Override
                public void onFound(String host, int port) {
                    // 差分已经出结果就别覆盖
                    if (foundPort > 0) return;
                    String h = (host != null) ? host : NetUtils.getWifiIp(MainActivity.this);
                    ui.post(() -> showResult(h, port, "mDNS 发现", new ArrayList<>()));
                }

                @Override
                public void onFailed(String reason) {
                    // 差分是主路径，mDNS 失败无需打扰用户
                }
            });
        } catch (Throwable ignored) {
        }
    }

    // ---------- 固定端口 ----------

    private void onFixPortClicked() {
        if (!ShizukuAuth.hasShizukuPermission()) {
            toast("需要 shell 身份：请在 Shizuku 的「授权应用」里允许本应用");
            return;
        }
        tvEndpoint.setText("正在把 adbd 固定到 " + FIXED_PORT + " 端口…");
        new Thread(() -> {
            ShizukuAuth.ExecResult r = ShizukuAuth.fixPort(FIXED_PORT);
            try {
                Thread.sleep(3000);
            } catch (InterruptedException ignored) {
            }
            // 确保无线调试是开的
            AdbWifiController.setEnabled(MainActivity.this, true);
            try {
                Thread.sleep(1500);
            } catch (InterruptedException ignored) {
            }
            String ip = NetUtils.getWifiIp(MainActivity.this);
            boolean ok = r != null && r.isSuccess();
            ui.post(() -> {
                refreshStateUi();
                if (ok) {
                    showResult(ip, FIXED_PORT,
                            "已固定为 " + FIXED_PORT + "，以后不再随机变", new ArrayList<>());
                    toast("已固定到 " + FIXED_PORT + "，去 Termux 连 127.0.0.1:" + FIXED_PORT);
                } else {
                    tvEndpoint.setText("固定失败："
                            + (r == null ? "无返回" : r.message())
                            + "\n\n该 ROM 可能不允许 shell 改 service.adb.tcp.port。"
                            + "\n若无线调试因此断掉，重新开关一次即可恢复。");
                }
            });
        }).start();
    }

    // ---------- 诊断 ----------

    private void onDiagClicked() {
        if (!ShizukuAuth.hasShizukuPermission()) {
            toast("需要 shell 身份：请在 Shizuku 的「授权应用」里允许本应用");
            return;
        }
        tvEndpoint.setText("正在收集诊断信息…");
        new Thread(() -> {
            String d = ShizukuAuth.diagnostics();
            ui.post(() -> {
                if (d == null || d.trim().isEmpty()) {
                    tvEndpoint.setText("诊断无输出（shell 执行失败）");
                    return;
                }
                tvEndpoint.setText(d);
                copy(d);
                toast("诊断信息已显示并复制到剪贴板");
            });
        }).start();
    }

    // ---------- 手动填端口 ----------

    private void onUseManualPort() {
        try {
            String s = etPort.getText() == null ? "" : etPort.getText().toString().trim();
            if (s.isEmpty()) {
                toast("先填端口（从系统设置页抄）");
                return;
            }
            int port;
            try {
                port = Integer.parseInt(s);
            } catch (NumberFormatException e) {
                toast("端口必须是数字");
                return;
            }
            if (port < 1 || port > 65535) {
                toast("端口范围 1-65535");
                return;
            }
            showResult(NetUtils.getWifiIp(this), port, "手动指定", new ArrayList<>());
            toast("已生成 adb connect 命令");
        } catch (Throwable t) {
            toast("出错：" + t.getMessage());
        }
    }

    // ---------- 展示 ----------

    private void showResult(String ip, int port, String note, List<Integer> others) {
        foundHost = (ip != null) ? ip : "127.0.0.1";
        foundPort = port;
        StringBuilder sb = new StringBuilder();
        sb.append(foundHost).append(":").append(port);
        sb.append("\nadb connect ").append(foundHost).append(":").append(port);
        sb.append("\n\n[").append(note).append("]");
        if (others != null && others.size() > 1) {
            sb.append("\n其他候选：").append(others);
        }
        tvEndpoint.setText(sb.toString());
    }

    private void showProbeResult(String ip, PortFinder.ProbeResult pr) {
        showResult(ip, pr.port, pr.note, pr.candidates);
    }

    private void showProbeFailure(String ip, PortFinder.ProbeResult pr) {
        tvEndpoint.setText(getString(R.string.endpoint_empty) + "\n" + pr.note);
    }

    // ---------- 杂项 ----------

    private void launchShizuku() {
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage(SHIZUKU_PKG);
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } else {
                toast("未检测到 Shizuku（moe.shizuku.privileged.api）");
            }
        } catch (Throwable t) {
            toast("拉起 Shizuku 失败：" + t.getMessage());
        }
    }

    private void copy(String text) {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("adbwifi", text));
        } catch (Throwable ignored) {
        }
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
