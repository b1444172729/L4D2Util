package com.android.adbwifi;

import android.Manifest;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    private static final String SHIZUKU_PKG = "moe.shizuku.privileged.api";
    private static final String PERM = Manifest.permission.WRITE_SECURE_SETTINGS;
    private static final int REQ_SHIZUKU = 1001;
    private static final int DISCOVER_TIMEOUT_MS = 8000;
    private static final int FIXED_PORT = 5555;

    private TextView tvPerm;
    private TextView tvState;
    private TextView tvEndpoint;
    private TextView tvCrash;
    private EditText etPort;
    private Button btnGrant;
    private Button btnToggle;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private PortFinder finder;

    /** 最近一次扫到的地址 */
    private String foundHost;
    private int foundPort = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        CrashHandler.install(this);
        setContentView(R.layout.activity_main);

        tvPerm = findViewById(R.id.tv_perm);
        tvState = findViewById(R.id.tv_state);
        tvEndpoint = findViewById(R.id.tv_endpoint);
        tvCrash = findViewById(R.id.tv_crash);
        etPort = findViewById(R.id.et_port);
        btnGrant = findViewById(R.id.btn_grant);
        btnToggle = findViewById(R.id.btn_toggle);

        finder = new PortFinder(this);
        ShizukuAuth.init(this, REQ_SHIZUKU, this::refreshPermissionUi);

        findViewById(R.id.btn_grant).setOnClickListener(v -> onGrantClicked());
        findViewById(R.id.btn_copy_cmd).setOnClickListener(v -> {
            copy(getGrantCommand());
            toast("已复制，粘到 Termux / aShell 里执行");
        });
        findViewById(R.id.btn_toggle).setOnClickListener(v -> onToggleClicked());
        findViewById(R.id.btn_refresh).setOnClickListener(v -> discoverPort());
        findViewById(R.id.btn_copy_connect).setOnClickListener(v -> {
            if (foundHost == null || foundPort <= 0) {
                toast("先点「重新扫描端口」");
                return;
            }
            copy("adb connect " + foundHost + ":" + foundPort);
            toast("已复制 adb connect 命令");
        });
        findViewById(R.id.btn_shizuku).setOnClickListener(v -> launchShizuku());
        findViewById(R.id.btn_use_port).setOnClickListener(v -> onUseManualPort());
        findViewById(R.id.btn_fix_port).setOnClickListener(v -> onFixPortClicked());
        findViewById(R.id.btn_diag).setOnClickListener(v -> onDiagClicked());
        findViewById(R.id.btn_copy_crash).setOnClickListener(v -> {
            String s = CrashHandler.getLast(this);
            if (s == null) {
                toast("没有崩溃记录");
                return;
            }
            copy(s);
            toast("已复制崩溃日志");
        });

        showLastCrash();
        refreshPermissionUi();
        refreshStateUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshPermissionUi();
        refreshStateUi();
    }

    @Override
    protected void onDestroy() {
        if (finder != null) finder.stop();
        super.onDestroy();
    }

    // ---------- 崩溃日志 ----------

    private void showLastCrash() {
        String last = CrashHandler.getLast(this);
        if (last == null || last.isEmpty()) return;
        tvCrash.setVisibility(View.VISIBLE);
        tvCrash.setText("上次崩溃日志（可长按选中复制）：\n" + last);
        findViewById(R.id.btn_copy_crash).setVisibility(View.VISIBLE);
    }

    // ---------- 权限 ----------

    private boolean hasSecureSettingsPermission() {
        try {
            return ContextCompat.checkSelfPermission(this, PERM)
                    == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) {
            return false;
        }
    }

    private String getGrantCommand() {
        return "adb shell pm grant " + getPackageName()
                + " " + ShizukuAuth.PERM_WRITE_SECURE_SETTINGS;
    }

    private void refreshPermissionUi() {
        boolean granted = hasSecureSettingsPermission();
        boolean szAlive = ShizukuAuth.isBinderAlive();
        boolean szGranted = ShizukuAuth.hasShizukuPermission();

        tvPerm.setText(granted
                ? getString(R.string.perm_granted)
                : getString(R.string.perm_denied)
                + "\nShizuku：" + (szAlive ? (szGranted ? "已授权本应用" : "未授权本应用") : "未运行"));

        btnGrant.setVisibility(granted ? View.GONE : View.VISIBLE);
    }

    private void onGrantClicked() {
        if (!ShizukuAuth.isBinderAlive()) {
            toast("Shizuku 未运行，请先启动 Shizuku（或用复制的命令在 Termux 里授权）");
            launchShizuku();
            return;
        }
        if (!ShizukuAuth.hasShizukuPermission()) {
            toast("请在弹出的 Shizuku 授权请求中点「允许」");
            ShizukuAuth.requestShizukuPermission();
            return;
        }
        toast("正在授权…");
        new Thread(() -> {
            ShizukuAuth.ExecResult r = ShizukuAuth.grantSelfExec();
            boolean ok = r != null && r.isSuccess();
            String msg = ok ? "授权成功，现在可以一键开关了"
                    : "授权失败：" + (r == null ? "未知错误" : r.message());
            ui.post(() -> {
                refreshPermissionUi();
                toast(msg);
            });
        }).start();
    }

    // ---------- 开关 ----------

    private void onToggleClicked() {
        if (!hasSecureSettingsPermission()) {
            toast("尚未授权 WRITE_SECURE_SETTINGS，先点上面的授权按钮");
            return;
        }
        boolean cur = AdbWifiController.isEnabled(this);
        boolean target = !cur;
        boolean ok = AdbWifiController.setEnabled(this, target);
        if (!ok) {
            toast("写入失败：无权限或被系统拒绝");
            return;
        }
        toast(target ? "已开启，正在扫描端口…" : "已关闭");
        refreshStateUi();
        if (target) {
            ui.postDelayed(this::discoverPort, 1500);
        } else {
            foundPort = -1;
            tvEndpoint.setText(R.string.endpoint_empty);
        }
    }

    private void refreshStateUi() {
        boolean on = AdbWifiController.isEnabled(this);
        tvState.setText(on ? R.string.state_on : R.string.state_off);
        btnToggle.setEnabled(hasSecureSettingsPermission());
    }

    // ---------- 端口发现：差分法 ----------

    private void discoverPort() {
        try {
            doDiscoverByDiff();
        } catch (Throwable t) {
            tvEndpoint.setText("扫描异常：" + t);
        }
    }

    /**
     * 端口发现主流程：
     *   0. 先看 adbd 是否已固定端口（getprop service.adb.tcp.port），
     *      已固定就直接显示，无需扫描——这一步零延迟、零副作用。
     *   1. 否则走差分法：关→采基线，开→采快照，差集即 adbd 端口。
     *   2. 差分也失败才降级到 mDNS。
     *
     * mDNS 不再并行抢先显示：实测它会先返回一个固定不变的干扰端口
     * （如 44531），反而把正确结果盖掉。
     */
    private void doDiscoverByDiff() {
        boolean szOk;
        try {
            szOk = ShizukuAuth.hasShizukuPermission();
        } catch (Throwable t) {
            szOk = false;
        }

        if (!szOk) {
            tvEndpoint.setText(getString(R.string.endpoint_empty)
                    + "\n没拿到 shell 身份，无法自动判定端口。\n"
                    + "请在 Shizuku 的「授权应用」里允许本应用，再重新扫描。\n"
                    + "或在下方手动填端口。");
            startMdnsFallback();
            return;
        }

        tvEndpoint.setText("正在扫描…");
        foundPort = -1;

        new Thread(() -> {
            // 0) 已固定端口则直接出结果
            int fixed = ShizukuAuth.getAdbTcpPort();
            if (fixed > 0 && fixed < 65536) {
                final int fp = fixed;
                final String fip = NetUtils.getWifiIp(MainActivity.this);
                ui.post(() -> {
                    refreshStateUi();
                    showResult(fip, fp, "已固定端口（不会再变）", new ArrayList<>());
                });
                return;
            }

            Set<Integer> off = null;
            Set<Integer> on = null;
            try {
                // 1) 先关掉，采基线
                if (AdbWifiController.isEnabled(MainActivity.this)) {
                    AdbWifiController.setEnabled(MainActivity.this, false);
                }
                Thread.sleep(1200);
                off = PortDiff.parseListen(ShizukuAuth.listenPortsRaw());

                // 2) 再打开，等 adbd 起来
                AdbWifiController.setEnabled(MainActivity.this, true);
                Thread.sleep(2500);
                on = PortDiff.parseListen(ShizukuAuth.listenPortsRaw());
            } catch (Throwable t) {
                ui.post(() -> tvEndpoint.setText("差分扫描异常：" + t));
                return;
            }

            final List<Integer> added = PortDiff.diff(on, off);
            final int port = PortDiff.pickBest(added);
            final String ip = NetUtils.getWifiIp(MainActivity.this);
            // lambda 只能引用 effectively final 的变量，所以在这里固化快照
            final int offSize = (off == null) ? 0 : off.size();
            final String onSnapshot = (on == null) ? "" : String.valueOf(on);

            ui.post(() -> {
                refreshStateUi();
                if (port > 0) {
                    showResult(ip, port, "差分法判定（关闭时 " + offSize
                                    + " 个监听，开启后新增 " + added + "）"
                                    + "\n提示：每次扫描都会重开一次无线调试，端口因此会变。"
                                    + "点「把端口固定为 5555」可彻底解决。",
                            added);
                } else {
                    StringBuilder sb = new StringBuilder();
                    sb.append(getString(R.string.endpoint_empty));
                    sb.append("\n差分后没有新增监听端口。\n");
                    if (!onSnapshot.isEmpty()) {
                        sb.append("当前 LISTEN 端口：").append(onSnapshot).append("\n");
                    }
                    sb.append("\n正在尝试 mDNS…");
                    tvEndpoint.setText(sb.toString());
                    startMdnsFallback();
                }
            });
        }, "adbwifi-diff").start();
    }

    /** 仅当差分失败时才走 mDNS，且结果标注为「待确认」。 */
    private void startMdnsFallback() {
        try {
            finder.discover(DISCOVER_TIMEOUT_MS, new PortFinder.Callback() {
                @Override
                public void onFound(String host, int port) {
                    if (foundPort > 0) return;   // 已有更可靠的结果
                    String h = (host != null) ? host : NetUtils.getWifiIp(MainActivity.this);
                    ui.post(() -> showResult(h, port,
                            "mDNS 发现（可信度低，请与系统设置页核对）", new ArrayList<>()));
                }

                @Override
                public void onFailed(String reason) {
                    // 保持原有提示，不覆盖
                }
            });
        } catch (Throwable ignored) {
        }
    }

    // ---------- 固定端口 ----------

    private void onFixPortClicked() {
        if (!ShizukuAuth.hasShizukuPermission()) {
            toast("需要 shell 身份：请在 Shizuku 的「授权应用」里允许本应用");
            return;
        }
        tvEndpoint.setText("正在把 adbd 固定到 " + FIXED_PORT + " 端口…");
        new Thread(() -> {
            ShizukuAuth.ExecResult r = ShizukuAuth.fixPort(FIXED_PORT);
            try {
                Thread.sleep(3000);
            } catch (InterruptedException ignored) {
            }
            // 确保无线调试是开的
            AdbWifiController.setEnabled(MainActivity.this, true);
            try {
                Thread.sleep(2000);
            } catch (InterruptedException ignored) {
            }

            // 验证：属性是否生效 + 端口是否真的在 LISTEN
            final int prop = ShizukuAuth.getAdbTcpPort();
            final boolean listening = PortDiff.parseListen(
                    ShizukuAuth.listenPortsRaw()).contains(FIXED_PORT);
            final String ip = NetUtils.getWifiIp(MainActivity.this);
            final String cmdMsg = (r == null) ? "无返回" : r.message();

            ui.post(() -> {
                refreshStateUi();
                if (prop == FIXED_PORT && listening) {
                    showResult(ip, FIXED_PORT,
                            "已固定为 " + FIXED_PORT + "，端口不再随机变。\n"
                                    + "以后点扫描会秒出结果，Termux 里固定连 127.0.0.1:"
                                    + FIXED_PORT, new ArrayList<>());
                    toast("已固定到 " + FIXED_PORT);
                } else {
                    StringBuilder sb = new StringBuilder();
                    sb.append("固定未生效。\n");
                    sb.append("属性 service.adb.tcp.port = ").append(prop).append("\n");
                    sb.append(FIXED_PORT).append(" 是否在监听：").append(listening).append("\n");
                    if (cmdMsg != null && !cmdMsg.isEmpty()) {
                        sb.append("命令回显：").append(cmdMsg).append("\n");
                    }
                    sb.append("\n该 ROM 可能不允许 shell 改此属性或重启 adbd。\n")
                            .append("若无线调试因此断掉，重新开关一次即可恢复。\n")
                            .append("可点「诊断」把环境信息发出来。");
                    tvEndpoint.setText(sb.toString());
                }
            });
        }).start();
    }

    // ---------- 诊断 ----------

    private void onDiagClicked() {
        if (!ShizukuAuth.hasShizukuPermission()) {
            toast("需要 shell 身份：请在 Shizuku 的「授权应用」里允许本应用");
            return;
        }
        tvEndpoint.setText("正在收集诊断信息…");
        new Thread(() -> {
            String d = ShizukuAuth.diagnostics();
            ui.post(() -> {
                if (d == null || d.trim().isEmpty()) {
                    tvEndpoint.setText("诊断无输出（shell 执行失败）");
                    return;
                }
                tvEndpoint.setText(d);
                copy(d);
                toast("诊断信息已显示并复制到剪贴板");
            });
        }).start();
    }

    // ---------- 手动填端口 ----------

    private void onUseManualPort() {
        try {
            String s = etPort.getText() == null ? "" : etPort.getText().toString().trim();
            if (s.isEmpty()) {
                toast("先填端口（从系统设置页抄）");
                return;
            }
            int port;
            try {
                port = Integer.parseInt(s);
            } catch (NumberFormatException e) {
                toast("端口必须是数字");
                return;
            }
            if (port < 1 || port > 65535) {
                toast("端口范围 1-65535");
                return;
            }
            showResult(NetUtils.getWifiIp(this), port, "手动指定", new ArrayList<>());
            toast("已生成 adb connect 命令");
        } catch (Throwable t) {
            toast("出错：" + t.getMessage());
        }
    }

    // ---------- 展示 ----------

    private void showResult(String ip, int port, String note, List<Integer> others) {
        foundHost = (ip != null) ? ip : "127.0.0.1";
        foundPort = port;
        StringBuilder sb = new StringBuilder();
        sb.append(foundHost).append(":").append(port);
        sb.append("\nadb connect ").append(foundHost).append(":").append(port);
        sb.append("\n\n[").append(note).append("]");
        if (others != null && others.size() > 1) {
            sb.append("\n其他候选：").append(others);
        }
        tvEndpoint.setText(sb.toString());
    }

    private void showProbeResult(String ip, PortFinder.ProbeResult pr) {
        showResult(ip, pr.port, pr.note, pr.candidates);
    }

    private void showProbeFailure(String ip, PortFinder.ProbeResult pr) {
        tvEndpoint.setText(getString(R.string.endpoint_empty) + "\n" + pr.note);
    }

    // ---------- 杂项 ----------

    private void launchShizuku() {
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage(SHIZUKU_PKG);
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } else {
                toast("未检测到 Shizuku（moe.shizuku.privileged.api）");
            }
        } catch (Throwable t) {
            toast("拉起 Shizuku 失败：" + t.getMessage());
        }
    }

    private void copy(String text) {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("adbwifi", text));
        } catch (Throwable ignored) {
        }
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
