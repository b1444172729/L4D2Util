package com.android.adbwifi;

import android.Manifest;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final String SHIZUKU_PKG = "moe.shizuku.privileged.api";
    private static final String PERM = Manifest.permission.WRITE_SECURE_SETTINGS;
    private static final int REQ_SHIZUKU = 1001;
    private static final int DISCOVER_TIMEOUT_MS = 8000;

    private TextView tvPerm;
    private TextView tvState;
    private TextView tvEndpoint;
    private Button btnGrant;
    private Button btnToggle;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private PortFinder finder;

    /** 最近一次扫到的地址 */
    private String foundHost;
    private int foundPort = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvPerm = findViewById(R.id.tv_perm);
        tvState = findViewById(R.id.tv_state);
        tvEndpoint = findViewById(R.id.tv_endpoint);
        btnGrant = findViewById(R.id.btn_grant);
        btnToggle = findViewById(R.id.btn_toggle);

        finder = new PortFinder(this);
        ShizukuAuth.init(this, REQ_SHIZUKU, this::refreshPermissionUi);

        findViewById(R.id.btn_grant).setOnClickListener(v -> onGrantClicked());
        findViewById(R.id.btn_copy_cmd).setOnClickListener(v -> {
            copy(getGrantCommand());
            toast("已复制，粘到 Termux / aShell 里执行");
        });
        findViewById(R.id.btn_toggle).setOnClickListener(v -> onToggleClicked());
        findViewById(R.id.btn_refresh).setOnClickListener(v -> discoverPort());
        findViewById(R.id.btn_copy_connect).setOnClickListener(v -> {
            if (foundHost == null || foundPort <= 0) {
                toast("先点「重新扫描端口」");
                return;
            }
            copy("adb connect " + foundHost + ":" + foundPort);
            toast("已复制 adb connect 命令");
        });
        findViewById(R.id.btn_shizuku).setOnClickListener(v -> launchShizuku());

        refreshPermissionUi();
        refreshStateUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshPermissionUi();
        refreshStateUi();
    }

    @Override
    protected void onDestroy() {
        if (finder != null) finder.stop();
        super.onDestroy();
    }

    // ---------- 权限 ----------

    private boolean hasSecureSettingsPermission() {
        return ContextCompat.checkSelfPermission(this, PERM)
                == PackageManager.PERMISSION_GRANTED;
    }

    private String getGrantCommand() {
        return "adb shell pm grant " + getPackageName()
                + " " + ShizukuAuth.PERM_WRITE_SECURE_SETTINGS;
    }

    private void refreshPermissionUi() {
        boolean granted = hasSecureSettingsPermission();
        boolean szAlive = ShizukuAuth.isBinderAlive();
        boolean szGranted = ShizukuAuth.hasShizukuPermission();

        tvPerm.setText(granted
                ? getString(R.string.perm_granted)
                : getString(R.string.perm_denied)
                + "\nShizuku：" + (szAlive ? (szGranted ? "已授权本应用" : "未授权本应用") : "未运行"));

        btnGrant.setVisibility(granted ? View.GONE : View.VISIBLE);
    }

    private void onGrantClicked() {
        if (!ShizukuAuth.isBinderAlive()) {
            toast("Shizuku 未运行，请先启动 Shizuku（或用复制的命令在 Termux 里授权）");
            launchShizuku();
            return;
        }
        if (!ShizukuAuth.hasShizukuPermission()) {
            toast("请在弹出的 Shizuku 授权请求中点「允许」");
            ShizukuAuth.requestShizukuPermission();
            return;
        }
        toast("正在授权…");
        new Thread(() -> {
            ShizukuAuth.ExecResult r = ShizukuAuth.grantSelfExec();
            boolean ok = r != null && r.isSuccess();
            String msg = ok ? "授权成功，现在可以一键开关了"
                    : "授权失败：" + (r == null ? "未知错误" : r.message());
            ui.post(() -> {
                refreshPermissionUi();
                toast(msg);
            });
        }).start();
    }

    // ---------- 开关 ----------

    private void onToggleClicked() {
        if (!hasSecureSettingsPermission()) {
            toast("尚未授权 WRITE_SECURE_SETTINGS，先点上面的授权按钮");
            return;
        }
        boolean cur = AdbWifiController.isEnabled(this);
        boolean target = !cur;
        boolean ok = AdbWifiController.setEnabled(this, target);
        if (!ok) {
            toast("写入失败：无权限或被系统拒绝");
            return;
        }
        toast(target ? "已开启，正在扫描端口…" : "已关闭");
        refreshStateUi();
        if (target) {
            // 等 adbd 起来、mDNS 广播出去
            ui.postDelayed(this::discoverPort, 1500);
        } else {
            foundPort = -1;
            tvEndpoint.setText(R.string.endpoint_empty);
        }
    }

    private void refreshStateUi() {
        boolean on = AdbWifiController.isEnabled(this);
        tvState.setText(on ? R.string.state_on : R.string.state_off);
        btnToggle.setEnabled(hasSecureSettingsPermission());
    }

    // ---------- 端口发现 ----------

    private void discoverPort() {
        tvEndpoint.setText("正在扫描…");
        finder.discover(DISCOVER_TIMEOUT_MS, new PortFinder.Callback() {
            @Override
            public void onFound(String host, int port) {
                String h = (host != null) ? host : NetUtils.getWifiIp(MainActivity.this);
                foundHost = (h != null) ? h : "127.0.0.1";
                foundPort = port;
                tvEndpoint.setText(foundHost + ":" + foundPort
                        + "\nadb connect " + foundHost + ":" + foundPort);
            }

            @Override
            public void onFailed(String reason) {
                fallbackScan(reason);
            }
        });
    }

    /** mDNS 不灵时，用 shell 身份扫 /proc/net/tcp 兜底。 */
    private void fallbackScan(String reason) {
        if (!ShizukuAuth.hasShizukuPermission()) {
            tvEndpoint.setText(getString(R.string.endpoint_empty)
                    + "\n（mDNS 失败：" + reason + "，且无 shell 身份可兜底）");
            return;
        }
        tvEndpoint.setText("mDNS 失败，改用 /proc/net/tcp 扫描…");
        new Thread(() -> {
            String raw = ShizukuAuth.catProcNetTcp();
            List<Integer> ports = PortFinder.parseListenPorts(raw);
            String ip = NetUtils.getWifiIp(MainActivity.this);
            ui.post(() -> {
                if (ports.isEmpty() || ip == null) {
                    tvEndpoint.setText(getString(R.string.endpoint_empty));
                    return;
                }
                foundHost = ip;
                foundPort = ports.get(0);
                tvEndpoint.setText(foundHost + ":" + foundPort
                        + "\nadbd 候选端口：" + ports
                        + "\nadb connect " + foundHost + ":" + foundPort);
            });
        }).start();
    }

    // ---------- 杂项 ----------

    private void launchShizuku() {
        Intent i = getPackageManager().getLaunchIntentForPackage(SHIZUKU_PKG);
        if (i != null) {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } else {
            toast("未检测到 Shizuku（moe.shizuku.privileged.api）");
        }
    }

    private void copy(String text) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("adbwifi", text));
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
