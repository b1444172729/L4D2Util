package com.android.adbwifi;

import android.content.Context;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

/**
 * 端口发现。
 *
 * 无线调试开启后，adbd 会通过 mDNS 广播服务：
 *   - "_adb-tls-connect._tcp."  -> 连接端口（adb connect 用，我们要的就是这个，每次开启随机变）
 *   - "_adb-tls-pairing._tcp."  -> 配对端口（只有打开「使用配对码配对设备」界面时才存在）
 *
 * 现实情况：国产 ROM（尤其是 MIUI）上 NsdManager 经常扫不到这个服务，
 * 最常见的原因是没拿 MulticastLock——Android 默认过滤组播包省电，
 * 不 acquire 就收不到 mDNS 响应。这里已经处理。
 * 即便如此仍可能失败，所以调用方应同时走 shell 兜底。
 */
public class PortFinder {

    private static final String TAG = "PortFinder";
    public static final String TYPE_CONNECT = "_adb-tls-connect._tcp.";
    public static final String TYPE_PAIRING = "_adb-tls-pairing._tcp.";
    /** adbd 随机端口的取值区间（Android 11 实测落在此范围内）。 */
    public static final int PORT_MIN = 30000;
    public static final int PORT_MAX = 60999;

    public interface Callback {
        void onFound(String host, int port);

        void onFailed(String reason);
    }

    private final Context ctx;
    private final NsdManager nsd;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private WifiManager.MulticastLock multicastLock;
    private DiscoveryListenerImpl listener;
    private Callback callback;
    private boolean running;

    public PortFinder(Context context) {
        ctx = context.getApplicationContext();
        nsd = (NsdManager) ctx.getSystemService(Context.NSD_SERVICE);
    }

    public boolean isRunning() {
        return running;
    }

    /** 扫描最长 timeoutMs 毫秒，找到第一个可用服务即回调 onFound。 */
    public void discover(int timeoutMs, Callback cb) {
        stop();
        if (nsd == null) {
            cb.onFailed("NsdManager 不可用");
            return;
        }
        callback = cb;
        running = true;
        acquireMulticastLock();
        listener = new DiscoveryListenerImpl();
        try {
            nsd.discoverServices(TYPE_CONNECT, NsdManager.PROTOCOL_DNS_SD, listener);
        } catch (Throwable t) {
            running = false;
            releaseMulticastLock();
            cb.onFailed("mDNS 启动失败：" + t.getMessage());
            return;
        }
        ui.postDelayed(this::finishTimeout, timeoutMs);
    }

    private void finishTimeout() {
        if (running && callback != null) callback.onFailed("mDNS 超时（本机 ROM 可能屏蔽了 mDNS）");
        stop();
    }

    public void stop() {
        running = false;
        if (listener != null && nsd != null) {
            try {
                nsd.stopServiceDiscovery(listener);
            } catch (Throwable ignored) {
            }
            listener = null;
        }
        releaseMulticastLock();
    }

    private void acquireMulticastLock() {
        try {
            WifiManager wm = (WifiManager) ctx.getSystemService(Context.WIFI_SERVICE);
            if (wm == null) return;
            if (multicastLock == null) {
                multicastLock = wm.createMulticastLock("adbwifi-mdns");
                multicastLock.setReferenceCounted(true);
            }
            if (!multicastLock.isHeld()) multicastLock.acquire();
        } catch (Throwable t) {
            Log.w(TAG, "MulticastLock 获取失败", t);
        }
    }

    private void releaseMulticastLock() {
        try {
            if (multicastLock != null && multicastLock.isHeld()) multicastLock.release();
        } catch (Throwable ignored) {
        }
    }

    private void deliver(String host, int port) {
        Callback cb = callback;
        running = false;
        stop();
        if (cb != null) cb.onFound(host, port);
    }

    private class DiscoveryListenerImpl implements NsdManager.DiscoveryListener {
        @Override
        public void onServiceFound(NsdServiceInfo info) {
            if (TYPE_CONNECT.equals(info.getServiceType())) {
                try {
                    nsd.resolveService(info, new ResolveListenerImpl());
                } catch (Throwable ignored) {
                }
            }
        }

        @Override public void onDiscoveryStarted(String serviceType) { }

        @Override
        public void onStartDiscoveryFailed(String serviceType, int errorCode) {
            if (callback != null) callback.onFailed("mDNS 启动失败 code=" + errorCode);
            stop();
        }

        @Override public void onServiceLost(NsdServiceInfo serviceInfo) { }
        @Override public void onDiscoveryStopped(String serviceType) { }
        @Override public void onStopDiscoveryFailed(String serviceType, int errorCode) { }
    }

    private class ResolveListenerImpl implements NsdManager.ResolveListener {
        @Override
        public void onServiceResolved(NsdServiceInfo info) {
            int port = info.getPort();
            String host = null;
            try {
                if (info.getHost() != null) host = info.getHost().getHostAddress();
            } catch (Throwable ignored) {
            }
            Log.d(TAG, "resolved " + info.getServiceName() + " -> " + host + ":" + port);
            if (port > 0 && port < 65536) deliver(host, port);
        }

        @Override public void onResolveFailed(NsdServiceInfo info, int errorCode) { }
    }

    /** 从 /proc/net/tcp 中筛出落在 adbd 端口区间的 LISTEN 端口。 */
    public static List<Integer> parseListenPorts(String procNetTcp) {
        List<Integer> all = parseAllListenPorts(procNetTcp);
        List<Integer> hit = new ArrayList<>();
        for (Integer p : all) {
            if (p >= PORT_MIN && p <= PORT_MAX) hit.add(p);
        }
        return hit.isEmpty() ? all : hit;
    }

    /**
     * 解析 /proc/net/tcp，返回所有处于 LISTEN(0A) 状态的端口。
     * 注意：普通应用进程读 /proc/net/tcp 在 Android 10+ 常被限制，需用 shell 身份执行 cat。
     */
    public static List<Integer> parseAllListenPorts(String procNetTcp) {
        List<Integer> result = new ArrayList<>();
        if (procNetTcp == null) return result;
        for (String raw : procNetTcp.split("\n")) {
            String[] f = raw.trim().split("\\s+");
            if (f.length < 4) continue;
            if (!"0A".equalsIgnoreCase(f[3])) continue;      // 0A = TCP_LISTEN
            String local = f[1];
            int idx = local.indexOf(':');
            if (idx < 0 || idx + 1 >= local.length()) continue;
            try {
                int p = Integer.parseInt(local.substring(idx + 1), 16);
                if (p > 0 && p < 65536 && !result.contains(p)) result.add(p);
            } catch (NumberFormatException ignored) {
            }
        }
        return result;
    }
}
