package com.android.adbwifi;

import android.content.Context;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

/**
 * mDNS 端口发现。
 *
 * 无线调试开启后 adbd 会广播 "_adb-tls-connect._tcp"，
 * 但实测部分 ROM（MIUI）上它会返回固定不变的干扰端口，可信度低，
 * 因此本类只作兜底，主路径走 PortDiff 的差分法。
 */
public class PortFinder {

    private static final String TAG = "PortFinder";
    public static final String TYPE_CONNECT = "_adb-tls-connect._tcp.";

    public interface Callback {
        void onFound(String host, int port);

        void onFailed(String reason);
    }

    private final Context ctx;
    private final NsdManager nsd;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private WifiManager.MulticastLock multicastLock;
    private DiscoveryListenerImpl listener;
    private Callback callback;
    private boolean running;

    public PortFinder(Context context) {
        ctx = context.getApplicationContext();
        nsd = (NsdManager) ctx.getSystemService(Context.NSD_SERVICE);
    }

    public boolean isRunning() {
        return running;
    }

    public void discover(int timeoutMs, Callback cb) {
        stop();
        if (nsd == null) {
            cb.onFailed("NsdManager 不可用");
            return;
        }
        callback = cb;
        running = true;
        acquireMulticastLock();
        listener = new DiscoveryListenerImpl();
        try {
            nsd.discoverServices(TYPE_CONNECT, NsdManager.PROTOCOL_DNS_SD, listener);
        } catch (Throwable t) {
            running = false;
            releaseMulticastLock();
            cb.onFailed("mDNS 启动失败：" + t.getMessage());
            return;
        }
        ui.postDelayed(this::finishTimeout, timeoutMs);
    }

    private void finishTimeout() {
        if (running && callback != null) callback.onFailed("mDNS 超时（该 ROM 可能屏蔽了 mDNS）");
        stop();
    }

    public void stop() {
        running = false;
        if (listener != null && nsd != null) {
            try {
                nsd.stopServiceDiscovery(listener);
            } catch (Throwable ignored) {
            }
            listener = null;
        }
        releaseMulticastLock();
    }

    private void acquireMulticastLock() {
        try {
            WifiManager wm = (WifiManager) ctx.getSystemService(Context.WIFI_SERVICE);
            if (wm == null) return;
            if (multicastLock == null) {
                multicastLock = wm.createMulticastLock("adbwifi-mdns");
                multicastLock.setReferenceCounted(true);
            }
            if (!multicastLock.isHeld()) multicastLock.acquire();
        } catch (Throwable t) {
            Log.w(TAG, "MulticastLock 获取失败", t);
        }
    }

    private void releaseMulticastLock() {
        try {
            if (multicastLock != null && multicastLock.isHeld()) multicastLock.release();
        } catch (Throwable ignored) {
        }
    }

    private void deliver(String host, int port) {
        Callback cb = callback;
        running = false;
        stop();
        if (cb != null) cb.onFound(host, port);
    }

    private class DiscoveryListenerImpl implements NsdManager.DiscoveryListener {
        @Override
        public void onServiceFound(NsdServiceInfo info) {
            if (TYPE_CONNECT.equals(info.getServiceType())) {
                try {
                    nsd.resolveService(info, new ResolveListenerImpl());
                } catch (Throwable ignored) {
                }
            }
        }

        @Override public void onDiscoveryStarted(String serviceType) { }

        @Override
        public void onStartDiscoveryFailed(String serviceType, int errorCode) {
            if (callback != null) callback.onFailed("mDNS 启动失败 code=" + errorCode);
            stop();
        }

        @Override public void onServiceLost(NsdServiceInfo serviceInfo) { }
        @Override public void onDiscoveryStopped(String serviceType) { }
        @Override public void onStopDiscoveryFailed(String serviceType, int errorCode) { }
    }

    private class ResolveListenerImpl implements NsdManager.ResolveListener {
        @Override
        public void onServiceResolved(NsdServiceInfo info) {
            int port = info.getPort();
            String host = null;
            try {
                if (info.getHost() != null) host = info.getHost().getHostAddress();
            } catch (Throwable ignored) {
            }
            Log.d(TAG, "resolved " + info.getServiceName() + " -> " + host + ":" + port);
            if (port > 0 && port < 65536) deliver(host, port);
        }

        @Override public void onResolveFailed(NsdServiceInfo info, int errorCode) { }
    }
}
