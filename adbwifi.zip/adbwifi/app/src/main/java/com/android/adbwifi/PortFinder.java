package com.android.adbwifi;

import android.content.Context;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

/**
 * 端口发现。
 *
 * 无线调试开启后，adbd 会通过 mDNS 广播服务：
 *   - "_adb-tls-connect._tcp."  -> 连接端口（adb connect 用，我们要的就是这个，每次开启随机变）
 *   - "_adb-tls-pairing._tcp."  -> 配对端口（只有打开「使用配对码配对设备」界面时才存在）
 *
 * mDNS 失败时可用 parseListenPorts() 解析 /proc/net/tcp 兜底（需 shell 身份，走 Shizuku）。
 */
public class PortFinder {

    private static final String TAG = "PortFinder";
    public static final String TYPE_CONNECT = "_adb-tls-connect._tcp.";
    public static final String TYPE_PAIRING = "_adb-tls-pairing._tcp.";
    /** adbd 随机端口的取值区间（Android 11 实测落在此范围内）。 */
    public static final int PORT_MIN = 30000;
    public static final int PORT_MAX = 60999;

    public interface Callback {
        void onFound(String host, int port);

        void onFailed(String reason);
    }

    private final NsdManager nsd;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private DiscoveryListenerImpl listener;
    private Callback callback;
    private boolean running;

    public PortFinder(Context context) {
        nsd = (NsdManager) context.getApplicationContext().getSystemService(Context.NSD_SERVICE);
    }

    public boolean isRunning() {
        return running;
    }

    /** 扫描最长 timeoutMs 毫秒，找到第一个可用服务即回调 onFound。 */
    public void discover(int timeoutMs, Callback cb) {
        stop();
        if (nsd == null) {
            cb.onFailed("NsdManager 不可用");
            return;
        }
        callback = cb;
        running = true;
        listener = new DiscoveryListenerImpl();
        try {
            nsd.discoverServices(TYPE_CONNECT, NsdManager.PROTOCOL_DNS_SD, listener);
        } catch (Throwable t) {
            running = false;
            cb.onFailed("mDNS 启动失败：" + t.getMessage());
            return;
        }
        ui.postDelayed(this::finishTimeout, timeoutMs);
    }

    private void finishTimeout() {
        if (running && callback != null) callback.onFailed("mDNS 超时");
        stop();
    }

    public void stop() {
        running = false;
        if (listener != null && nsd != null) {
            try {
                nsd.stopServiceDiscovery(listener);
            } catch (Throwable ignored) {
            }
            listener = null;
        }
    }

    private void deliver(String host, int port) {
        Callback cb = callback;
        running = false;
        stop();
        if (cb != null) cb.onFound(host, port);
    }

    private class DiscoveryListenerImpl implements NsdManager.DiscoveryListener {
        @Override
        public void onServiceFound(NsdServiceInfo info) {
            if (TYPE_CONNECT.equals(info.getServiceType())) {
                try {
                    nsd.resolveService(info, new ResolveListenerImpl());
                } catch (Throwable ignored) {
                }
            }
        }

        @Override public void onDiscoveryStarted(String serviceType) { }
        @Override public void onStartDiscoveryFailed(String serviceType, int errorCode) {
            if (callback != null) callback.onFailed("mDNS 启动失败 code=" + errorCode);
            stop();
        }
        @Override public void onServiceLost(NsdServiceInfo serviceInfo) { }
        @Override public void onDiscoveryStopped(String serviceType) { }
        @Override public void onStopDiscoveryFailed(String serviceType, int errorCode) { }
    }

    private class ResolveListenerImpl implements NsdManager.ResolveListener {
        @Override
        public void onServiceResolved(NsdServiceInfo info) {
            int port = info.getPort();
            String host = null;
            try {
                if (info.getHost() != null) host = info.getHost().getHostAddress();
            } catch (Throwable ignored) {
            }
            Log.d(TAG, "resolved " + info.getServiceName() + " -> " + host + ":" + port);
            if (port > 0 && port < 65536) deliver(host, port);
        }

        @Override public void onResolveFailed(NsdServiceInfo info, int errorCode) { }
    }

    /**
     * 兜底：解析 /proc/net/tcp，取出处于 LISTEN(0A) 且端口落在 adbd 区间内的端口。
     * 注意：普通应用进程读 /proc/net/tcp 在 Android 10+ 常被限制，需用 shell 身份执行 cat。
     */
    public static List<Integer> parseListenPorts(String procNetTcp) {
        List<Integer> result = new ArrayList<>();
        if (procNetTcp == null) return result;
        for (String raw : procNetTcp.split("\n")) {
            String[] f = raw.trim().split("\\s+");
            if (f.length < 4) continue;
            if (!"0A".equalsIgnoreCase(f[3])) continue;      // 0A = TCP_LISTEN
            String local = f[1];
            int idx = local.indexOf(':');
            if (idx < 0 || idx + 1 >= local.length()) continue;
            try {
                int p = Integer.parseInt(local.substring(idx + 1), 16);
                if (p >= PORT_MIN && p <= PORT_MAX) result.add(p);
            } catch (NumberFormatException ignored) {
            }
        }
        return result;
    }
}
