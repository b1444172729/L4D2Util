package com.android.adbwifi;

import android.content.Context;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 端口发现。
 *
 * 无线调试开启后，adbd 会监听一个**每次随机**的端口。难点在于：光看
 * /proc/net/tcp 无法区分哪个端口是 adbd 的——同一个 30000~60999 区间里
 * 还监听着别的进程（那些端口往往是固定的，所以区间筛选会稳定挑到错误答案）。
 *
 * 精确做法：按 socket inode 匹配。
 *   - /proc/net/tcp 每一行的第 10 列是该 socket 的 inode
 *   - /proc/<adbd_pid>/fd/ 下的链接形如 socket:[inode]
 *   两边 inode 对上，这个端口就确定属于 adbd，不需要猜。
 *
 * 主路径失败时依次降级：inode 匹配 -> uid 过滤(0/2000) -> 列出全部候选由用户手动选。
 */
public class PortFinder {

    private static final String TAG = "PortFinder";
    public static final String TYPE_CONNECT = "_adb-tls-connect._tcp.";
    public static final String TYPE_PAIRING = "_adb-tls-pairing._tcp.";
    /** adbd 随机端口通常落在这个区间（仅用于排序与降级筛选，不用于判定）。 */
    public static final int PORT_MIN = 30000;
    public static final int PORT_MAX = 60999;

    public interface Callback {
        void onFound(String host, int port);

        void onFailed(String reason);
    }

    private final Context ctx;
    private final NsdManager nsd;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private WifiManager.MulticastLock multicastLock;
    private DiscoveryListenerImpl listener;
    private Callback callback;
    private boolean running;

    public PortFinder(Context context) {
        ctx = context.getApplicationContext();
        nsd = (NsdManager) ctx.getSystemService(Context.NSD_SERVICE);
    }

    public boolean isRunning() {
        return running;
    }

    public void discover(int timeoutMs, Callback cb) {
        stop();
        if (nsd == null) {
            cb.onFailed("NsdManager 不可用");
            return;
        }
        callback = cb;
        running = true;
        acquireMulticastLock();
        listener = new DiscoveryListenerImpl();
        try {
            nsd.discoverServices(TYPE_CONNECT, NsdManager.PROTOCOL_DNS_SD, listener);
        } catch (Throwable t) {
            running = false;
            releaseMulticastLock();
            cb.onFailed("mDNS 启动失败：" + t.getMessage());
            return;
        }
        ui.postDelayed(this::finishTimeout, timeoutMs);
    }

    private void finishTimeout() {
        if (running && callback != null) callback.onFailed("mDNS 超时（ROM 可能屏蔽了 mDNS）");
        stop();
    }

    public void stop() {
        running = false;
        if (listener != null && nsd != null) {
            try {
                nsd.stopServiceDiscovery(listener);
            } catch (Throwable ignored) {
            }
            listener = null;
        }
        releaseMulticastLock();
    }

    private void acquireMulticastLock() {
        try {
            WifiManager wm = (WifiManager) ctx.getSystemService(Context.WIFI_SERVICE);
            if (wm == null) return;
            if (multicastLock == null) {
                multicastLock = wm.createMulticastLock("adbwifi-mdns");
                multicastLock.setReferenceCounted(true);
            }
            if (!multicastLock.isHeld()) multicastLock.acquire();
        } catch (Throwable t) {
            Log.w(TAG, "MulticastLock 获取失败", t);
        }
    }

    private void releaseMulticastLock() {
        try {
            if (multicastLock != null && multicastLock.isHeld()) multicastLock.release();
        } catch (Throwable ignored) {
        }
    }

    private void deliver(String host, int port) {
        Callback cb = callback;
        running = false;
        stop();
        if (cb != null) cb.onFound(host, port);
    }

    private class DiscoveryListenerImpl implements NsdManager.DiscoveryListener {
        @Override
        public void onServiceFound(NsdServiceInfo info) {
            if (TYPE_CONNECT.equals(info.getServiceType())) {
                try {
                    nsd.resolveService(info, new ResolveListenerImpl());
                } catch (Throwable ignored) {
                }
            }
        }

        @Override public void onDiscoveryStarted(String serviceType) { }

        @Override
        public void onStartDiscoveryFailed(String serviceType, int errorCode) {
            if (callback != null) callback.onFailed("mDNS 启动失败 code=" + errorCode);
            stop();
        }

        @Override public void onServiceLost(NsdServiceInfo serviceInfo) { }
        @Override public void onDiscoveryStopped(String serviceType) { }
        @Override public void onStopDiscoveryFailed(String serviceType, int errorCode) { }
    }

    private class ResolveListenerImpl implements NsdManager.ResolveListener {
        @Override
        public void onServiceResolved(NsdServiceInfo info) {
            int port = info.getPort();
            String host = null;
            try {
                if (info.getHost() != null) host = info.getHost().getHostAddress();
            } catch (Throwable ignored) {
            }
            Log.d(TAG, "resolved " + info.getServiceName() + " -> " + host + ":" + port);
            if (port > 0 && port < 65536) deliver(host, port);
        }

        @Override public void onResolveFailed(NsdServiceInfo info, int errorCode) { }
    }

    // ==================== /proc 精确匹配 ====================

    /** 一条 LISTEN 记录。 */
    public static final class ListenEntry {
        public final int port;
        public final int uid;
        public final long inode;

        ListenEntry(int port, int uid, long inode) {
            this.port = port;
            this.uid = uid;
            this.inode = inode;
        }
    }

    public static final class ProbeResult {
        /** 精确命中（inode 匹配）的 adbd 端口，没命中则为 null。 */
        public Integer port;
        /** 所有 LISTEN 端口，按“越像 adbd 越靠前”排序，供用户手动对照。 */
        public List<Integer> candidates = new ArrayList<>();
        /** 说明：命中方式 / 失败原因。 */
        public String note = "";

        public boolean hasPort() {
            return port != null;
        }
    }

    /** 一次 cat 同时拿到 tcp/tcp6/adbd 的 fd，避免多次 IPC。 */
    public static String buildProbeCommand() {
        return "echo ==TCP==; cat /proc/net/tcp 2>/dev/null;"
                + " echo ==TCP6==; cat /proc/net/tcp6 2>/dev/null;"
                + " echo ==FD==;"
                + " P=$(pidof adbd 2>/dev/null);"
                + " if [ -z \"$P\" ]; then"
                + "   P=$(ps -A 2>/dev/null | grep adbd | awk '{print $2}');"
                + " fi;"
                + " echo ==PID==$P;"
                + " for x in $P; do ls -l /proc/$x/fd 2>/dev/null; done";
    }

    /**
     * 解析 buildProbeCommand() 的输出。
     *
     * 判定顺序：
     *   1) socket inode 与 adbd 的 fd inode 一致 —— 精确
     *   2) inode 拿不到时，退化为 uid 过滤（adbd 为 0 或 2000）
     *   3) 都没有则列出全部 LISTEN 端口，交给用户对照系统设置页手动选
     */
    public static ProbeResult parseProbe(String raw) {
        ProbeResult r = new ProbeResult();
        if (raw == null || raw.trim().isEmpty()) {
            r.note = "shell 返回为空";
            return r;
        }

        List<ListenEntry> listen = new ArrayList<>();
        Set<Long> adbInodes = new HashSet<>();
        boolean sawFdSection = false;

        int section = 0;   // 1=tcp, 2=tcp6, 3=fd
        for (String rawLine : raw.split("\n")) {
            String line = rawLine.trim();
            if (line.startsWith("==TCP==")) { section = 1; continue; }
            if (line.startsWith("==TCP6==")) { section = 2; continue; }
            if (line.startsWith("==FD==")) { section = 3; sawFdSection = true; continue; }
            if (line.startsWith("==PID==")) { continue; }

            if (section == 1 || section == 2) {
                ListenEntry e = parseListenLine(line);
                if (e != null) listen.add(e);
            } else if (section == 3) {
                long in = extractSocketInode(line);
                if (in > 0) adbInodes.add(in);
            }
        }

        // 1) inode 精确匹配
        if (!adbInodes.isEmpty()) {
            for (ListenEntry e : listen) {
                if (e.inode > 0 && adbInodes.contains(e.inode)) {
                    r.port = e.port;
                    r.note = "按 socket inode 精确匹配到 adbd（共 " + adbInodes.size() + " 个 fd）";
                    fillCandidates(r, listen, e.port);
                    return r;
                }
            }
        }

        // 2) uid 降级
        List<ListenEntry> byUid = new ArrayList<>();
        for (ListenEntry e : listen) {
            if (e.uid == 0 || e.uid == 2000) byUid.add(e);
        }
        if (!byUid.isEmpty()) {
            for (ListenEntry e : byUid) {
                if (e.port >= PORT_MIN && e.port <= PORT_MAX) {
                    r.port = e.port;
                    r.note = "按 uid 推断（未拿到 adbd 的 fd，可信度次一档）";
                    fillCandidates(r, listen, e.port);
                    return r;
                }
            }
        }

        // 3) 都没命中
        if (!sawFdSection) {
            r.note = "没读到 adbd 的 fd（/proc/<pid>/fd 被拒），请在下方手动填端口";
        } else if (adbInodes.isEmpty()) {
            r.note = "adbd 进程未找到或没有 socket fd，请确认无线调试已开启";
        } else {
            r.note = "inode 未对上，请在下方手动填端口（或复制候选逐个试）";
        }
        fillCandidates(r, listen, -1);
        return r;
    }

    /** 解析 /proc/net/tcp{,6} 的一行，只要 LISTEN。 */
    private static ListenEntry parseListenLine(String line) {
        String[] f = line.split("\\s+");
        if (f.length < 10) return null;
        if (!"0A".equalsIgnoreCase(f[3])) return null;       // 0A = TCP_LISTEN
        int idx = f[1].indexOf(':');
        if (idx < 0 || idx + 1 >= f[1].length()) return null;
        int port;
        try {
            port = Integer.parseInt(f[1].substring(idx + 1), 16);
        } catch (NumberFormatException e) {
            return null;
        }
        if (port <= 0 || port >= 65536) return null;
        int uid = -1;
        try {
            uid = Integer.parseInt(f[7]);
        } catch (NumberFormatException ignored) {
        }
        long inode = -1;
        try {
            inode = Long.parseLong(f[9]);
        } catch (NumberFormatException ignored) {
        }
        return new ListenEntry(port, uid, inode);
    }

    /** 从 `lrwx------ ... 1234 -> socket:[56789]` 中取出 inode。 */
    private static long extractSocketInode(String line) {
        int s = line.indexOf("socket:[");
        if (s < 0) return -1;
        int e = line.indexOf(']', s);
        if (e < 0) return -1;
        try {
            return Long.parseLong(line.substring(s + "socket:[".length(), e).trim());
        } catch (NumberFormatException ex) {
            return -1;
        }
    }

    /** 候选排序：落在 adbd 常见区间的优先，其次端口大的优先，命中项置顶。 */
    private static void fillCandidates(ProbeResult r, List<ListenEntry> listen, int hit) {
        Map<Integer, Integer> score = new LinkedHashMap<>();
        for (ListenEntry e : listen) {
            if (score.containsKey(e.port)) continue;
            int v = 0;
            if (e.port >= PORT_MIN && e.port <= PORT_MAX) v += 100;
            if (e.uid == 0 || e.uid == 2000) v += 20;
            score.put(e.port, v + Math.min(e.port / 1000, 60));
        }
        List<Map.Entry<Integer, Integer>> list = new ArrayList<>(score.entrySet());
        Collections.sort(list, (a, b) -> b.getValue().compareTo(a.getValue()));
        for (Map.Entry<Integer, Integer> en : list) {
            if (en.getKey() == hit) continue;
            r.candidates.add(en.getKey());
        }
    }

    /** 兼容旧调用：只给文本时退化为区间筛选。 */
    public static List<Integer> parseListenPorts(String procNetTcp) {
        List<Integer> all = parseAllListenPorts(procNetTcp);
        List<Integer> hit = new ArrayList<>();
        for (Integer p : all) {
            if (p >= PORT_MIN && p <= PORT_MAX) hit.add(p);
        }
        return hit.isEmpty() ? all : hit;
    }

    public static List<Integer> parseAllListenPorts(String procNetTcp) {
        List<Integer> result = new ArrayList<>();
        if (procNetTcp == null) return result;
        for (String raw : procNetTcp.split("\n")) {
            ListenEntry e = parseListenLine(raw.trim());
            if (e != null && !result.contains(e.port)) result.add(e.port);
        }
        return result;
    }
}
