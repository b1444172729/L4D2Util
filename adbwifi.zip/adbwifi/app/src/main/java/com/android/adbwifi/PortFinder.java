package com.android.adbwifi;

import android.content.Context;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;

/**
 * 用 NsdManager 发现 adbd 的无线调试端口——复刻 Shizuku 的做法。
 *
 * 【之前一直拿错端口的根因】
 * NsdManager 在 MIUI 上会返回陈旧缓存里的错误端口（例如固定不变的 44531）。
 * Shizuku 用的同样是 NsdManager，却能拿到正确端口，差别只有一步：
 * 它对每个候选端口做**可达性校验**，校验不过就丢弃、继续等下一个。
 * 旧实现少了这一步，拿到第一个就直接用，所以永远显示那个错误的固定端口。
 *
 * 校验内容（对齐 Shizuku）：
 *   1. 服务确实在本机（mDNS 返回的 host 是本机某个 IP）
 *   2. 端口确实被监听（TCP 连 127.0.0.1:port 能连上）
 *   3. 校验失败不停止发现，继续等下一个候选，直到超时
 *
 * 只需 INTERNET 普通权限，不需要 pm grant，也不需要 Shizuku。
 */
public class PortFinder {

    private static final String TAG = "PortFinder";
    public static final String TYPE_CONNECT = "_adb-tls-connect._tcp.";
    private static final String LOOPBACK = "127.0.0.1";
    private static final int CONNECT_TIMEOUT_MS = 400;

    public interface Callback {
        void onFound(String host, int port, String note);

        void onFailed(String reason);
    }

    private final Context ctx;
    private final NsdManager nsd;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private WifiManager.MulticastLock multicastLock;
    private DiscoveryListenerImpl listener;
    private Callback callback;
    private volatile boolean running;
    /** 被丢弃的候选，用于失败时给出诊断信息 */
    private final List<String> rejected = new ArrayList<>();

    public PortFinder(Context context) {
        ctx = context.getApplicationContext();
        nsd = (NsdManager) ctx.getSystemService(Context.NSD_SERVICE);
    }

    public boolean isRunning() {
        return running;
    }

    /** 持续发现直到找到「校验通过」的端口，或超时。 */
    public void discover(int timeoutMs, Callback cb) {
        stop();
        if (nsd == null) {
            cb.onFailed("NsdManager 不可用");
            return;
        }
        callback = cb;
        rejected.clear();
        running = true;
        acquireMulticastLock();

        listener = new DiscoveryListenerImpl();
        try {
            nsd.discoverServices(TYPE_CONNECT, NsdManager.PROTOCOL_DNS_SD, listener);
        } catch (Throwable t) {
            running = false;
            releaseMulticastLock();
            cb.onFailed("mDNS 启动失败：" + t.getMessage());
            return;
        }
        ui.postDelayed(this::finishTimeout, timeoutMs);
    }

    private void finishTimeout() {
        if (!running) return;
        running = false;
        Callback cb = callback;
        stop();
        if (cb == null) return;
        StringBuilder sb = new StringBuilder();
        sb.append("mDNS 超时，未找到校验通过的端口。\n");
        if (!rejected.isEmpty()) {
            sb.append("已发现但校验未通过（说明是陈旧缓存）：");
            int n = Math.min(rejected.size(), 5);
            for (int i = 0; i < n; i++) {
                sb.append("\n  ").append(rejected.get(i));
            }
        } else {
            sb.append("期间没有任何服务被发现。");
        }
        cb.onFailed(sb.toString());
    }

    public void stop() {
        running = false;
        if (listener != null && nsd != null) {
            try {
                nsd.stopServiceDiscovery(listener);
            } catch (Throwable ignored) {
            }
            listener = null;
        }
        releaseMulticastLock();
    }

    private void acquireMulticastLock() {
        try {
            WifiManager wm = (WifiManager) ctx.getSystemService(Context.WIFI_SERVICE);
            if (wm == null) return;
            if (multicastLock == null) {
                multicastLock = wm.createMulticastLock("adbwifi-mdns");
                multicastLock.setReferenceCounted(true);
            }
            if (!multicastLock.isHeld()) multicastLock.acquire();
        } catch (Throwable t) {
            Log.w(TAG, "MulticastLock 获取失败", t);
        }
    }

    private void releaseMulticastLock() {
        try {
            if (multicastLock != null && multicastLock.isHeld()) multicastLock.release();
        } catch (Throwable ignored) {
        }
    }

    // ==================== 核心：校验 ====================

    /**
     * 端口可达性校验——这一步就是 Shizuku 能拿对端口而我们之前拿错的关键。
     * 只有 127.0.0.1:port 真的能连上，才认为 adbd 在监听它。
     */
    static boolean isPortListening(int port) {
        if (port <= 0 || port >= 65536) return false;
        Socket s = null;
        try {
            s = new Socket();
            s.connect(new InetSocketAddress(LOOPBACK, port), CONNECT_TIMEOUT_MS);
            return true;
        } catch (Throwable t) {
            return false;
        } finally {
            if (s != null) {
                try {
                    s.close();
                } catch (Throwable ignored) {
                }
            }
        }
    }

    /** mDNS 返回的 host 是否是本机 IP。 */
    static boolean isLocalAddress(String host) {
        if (host == null || host.isEmpty()) return false;
        if (LOOPBACK.equals(host)) return true;
        try {
            InetAddress target = InetAddress.getByName(host);
            Enumeration<NetworkInterface> it = NetworkInterface.getNetworkInterfaces();
            if (it == null) return false;
            for (NetworkInterface ni : Collections.list(it)) {
                Enumeration<InetAddress> addrs = ni.getInetAddresses();
                if (addrs == null) continue;
                for (InetAddress addr : Collections.list(addrs)) {
                    if (addr.equals(target)) return true;
                }
            }
        } catch (Throwable ignored) {
        }
        return false;
    }

    // ==================== 监听 ====================

    private class DiscoveryListenerImpl implements NsdManager.DiscoveryListener {
        @Override
        public void onServiceFound(NsdServiceInfo info) {
            if (!running) return;
            if (TYPE_CONNECT.equals(info.getServiceType())) {
                try {
                    nsd.resolveService(info, new ResolveListenerImpl());
                } catch (Throwable ignored) {
                    // 常见 Failure to resolve，忽略即可，后面还会再回调
                }
            }
        }

        @Override public void onDiscoveryStarted(String serviceType) { }

        @Override
        public void onStartDiscoveryFailed(String serviceType, int errorCode) {
            running = false;
            stop();
            if (callback != null) callback.onFailed("mDNS 启动失败 code=" + errorCode);
        }

        @Override public void onServiceLost(NsdServiceInfo serviceInfo) { }
        @Override public void onDiscoveryStopped(String serviceType) { }
        @Override public void onStopDiscoveryFailed(String serviceType, int errorCode) { }
    }

    private class ResolveListenerImpl implements NsdManager.ResolveListener {
        @Override
        public void onServiceResolved(NsdServiceInfo info) {
            if (!running) return;
            int port = info.getPort();
            String host = null;
            try {
                if (info.getHost() != null) host = info.getHost().getHostAddress();
            } catch (Throwable ignored) {
            }
            Log.d(TAG, "resolved " + info.getServiceName() + " -> " + host + ":" + port);

            if (port <= 0) return;

            // 校验一：必须是本机
            if (host != null && !isLocalAddress(host)) {
                rejected.add(host + ":" + port + "（非本机）");
                return;   // 不停止，继续等
            }

            // 校验二：端口必须真的能连上（Shizuku 的关键一步）
            if (!isPortListening(port)) {
                rejected.add((host == null ? LOOPBACK : host) + ":" + port + "（连不上，陈旧记录）");
                return;   // 不停止，继续等下一个
            }

            // 校验通过
            running = false;
            final int finalPort = port;
            final String finalHost = (host == null) ? LOOPBACK : host;
            final String note = "mDNS 发现并通过可达性校验"
                    + (rejected.isEmpty() ? ""
                    : "（已丢弃 " + rejected.size() + " 个无效候选：" + rejected + "）");
            final Callback cb = callback;
            stop();
            if (cb != null) cb.onFound(finalHost, finalPort, note);
        }

        @Override public void onResolveFailed(NsdServiceInfo info, int errorCode) {
            // 解析失败很常见，忽略，后续仍会继续发现
        }
    }
}
