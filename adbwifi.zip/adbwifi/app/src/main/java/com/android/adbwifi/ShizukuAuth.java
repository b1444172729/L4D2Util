package com.android.adbwifi;

import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.Looper;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

import rikka.shizuku.Shizuku;

/**
 * Shizuku 封装：
 *   1) 检测 Shizuku 服务是否存活、本应用是否已被 Shizuku 授权；
 *   2) 以 shell(uid 2000) 身份执行命令；
 *   3) 最关键的用途——让本应用「自己给自己」授予 WRITE_SECURE_SETTINGS，
 *      从而彻底摆脱电脑与 adb 连线。
 */
public final class ShizukuAuth {

    public static final String PERM_WRITE_SECURE_SETTINGS =
            "android.permission.WRITE_SECURE_SETTINGS";

    public interface StateListener {
        void onStateChanged();
    }

    private static Context appContext;
    private static int requestCode = 1001;
    private static StateListener listener;
    private static final Handler ui = new Handler(Looper.getMainLooper());

    private ShizukuAuth() {
    }

    public static void init(Context context, int reqCode, StateListener l) {
        appContext = context.getApplicationContext();
        requestCode = reqCode;
        listener = l;
        try {
            // sticky：若 binder 已经存在，注册后立刻回调一次
            Shizuku.addBinderReceivedListenerSticky(() -> notifyState());
            Shizuku.addRequestPermissionResultListener((code, grantResult) -> notifyState());
        } catch (Throwable ignored) {
        }
    }

    private static void notifyState() {
        ui.post(() -> {
            if (listener != null) listener.onStateChanged();
        });
    }

    /** Shizuku 服务是否在运行。 */
    public static boolean isBinderAlive() {
        try {
            return Shizuku.pingBinder();
        } catch (Throwable t) {
            return false;
        }
    }

    /** 本应用是否已在 Shizuku 的「授权应用」列表里。 */
    public static boolean hasShizukuPermission() {
        try {
            return isBinderAlive()
                    && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) {
            return false;
        }
    }

    /** 向 Shizuku 发起授权请求（系统弹窗点一下「允许」）。 */
    public static void requestShizukuPermission() {
        try {
            Shizuku.requestPermission(requestCode);
        } catch (Throwable ignored) {
        }
    }

    public static class ExecResult {
        public int code = -1;
        public String out = "";
        public String err = "";

        public boolean isSuccess() {
            return code == 0;
        }
    }

    /** 以 shell 身份执行命令，例如 exec("pm", "grant", pkg, perm)。 */
    public static ExecResult exec(String... command) {
        ExecResult r = new ExecResult();
        try {
            rikka.shizuku.ShizukuProcess p =
                    Shizuku.newProcess(command, null, "/");
            r.out = readAll(p.getInputStream());
            r.err = readAll(p.getErrorStream());
            r.code = p.waitFor();
        } catch (Throwable t) {
            r.err = String.valueOf(t.getMessage());
        }
        return r;
    }

    private static String readAll(InputStream in) {
        if (in == null) return "";
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line).append('\n');
            }
        } catch (Throwable ignored) {
        }
        return sb.toString();
    }

    /** 核心：让本应用自己授予自己 WRITE_SECURE_SETTINGS。 */
    public static boolean grantSelfWriteSecureSettings() {
        if (appContext == null) return false;
        ExecResult r = exec("pm", "grant",
                appContext.getPackageName(), PERM_WRITE_SECURE_SETTINGS);
        return r.isSuccess();
    }

    /**
     * 兜底取端口：shell 身份执行 `cat /proc/net/tcp`，再从 LISTEN 项中筛 adbd 端口。
     * 普通应用直接读该文件在 Android 10+ 常被拒，所以必须走 Shizuku。
     */
    public static String catProcNetTcp() {
        ExecResult r = exec("cat", "/proc/net/tcp");
        return (r.out == null || r.out.isEmpty()) ? null : r.out;
    }
}
