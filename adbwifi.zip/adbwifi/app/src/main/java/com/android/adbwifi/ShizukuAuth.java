package com.android.adbwifi;

import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import rikka.shizuku.Shizuku;

/**
 * Shizuku 封装：
 *   1) 检测 Shizuku 服务是否存活、本应用是否已被 Shizuku 授权；
 *   2) 通过 User Service 以 shell(uid 2000) 身份执行 shell 命令；
 *   3) 核心用途——让本应用「自己给自己」授予 WRITE_SECURE_SETTINGS。
 *
 * 两条硬性约束（踩过的坑，别改回去）：
 *   - Shizuku.newProcess() 在 API 13 已变成 private（官方计划 API 14 移除），
 *     只能走 bindUserService()。
 *   - bindUserService() 必须在**主线程**调用：Shizuku 内部要用 Handler/Looper，
 *     在没有 Looper 的后台线程里调用会直接崩。
 *     而 exec() 本身是阻塞 IPC，必须放在后台线程。
 *     所以这里是「主线程 bind + 后台线程 exec + latch 等待」。
 */
public final class ShizukuAuth {

    private static final String TAG = "ShizukuAuth";
    public static final String PERM_WRITE_SECURE_SETTINGS =
            "android.permission.WRITE_SECURE_SETTINGS";

    private static final int USER_SERVICE_VERSION = 1;
    private static final long EXEC_TIMEOUT_SEC = 25;

    public interface StateListener {
        void onStateChanged();
    }

    private static Context appContext;
    private static int requestCode = 1001;
    private static StateListener listener;
    private static final Handler ui = new Handler(Looper.getMainLooper());

    private ShizukuAuth() {
    }

    public static void init(Context context, int reqCode, StateListener l) {
        appContext = context.getApplicationContext();
        requestCode = reqCode;
        listener = l;
        try {
            // sticky：若 binder 已经存在，注册后立刻回调一次
            Shizuku.addBinderReceivedListenerSticky(() -> notifyState());
            Shizuku.addBinderDeadListener(() -> notifyState());
            Shizuku.addRequestPermissionResultListener((code, grantResult) -> notifyState());
        } catch (Throwable t) {
            Log.w(TAG, "init", t);
        }
    }

    private static void notifyState() {
        ui.post(() -> {
            if (listener != null) listener.onStateChanged();
        });
    }

    /** Shizuku 服务是否在运行。 */
    public static boolean isBinderAlive() {
        try {
            return Shizuku.pingBinder();
        } catch (Throwable t) {
            return false;
        }
    }

    public static int getVersion() {
        try {
            return Shizuku.getVersion();
        } catch (Throwable t) {
            return -1;
        }
    }

    /** 本应用是否已在 Shizuku 的「授权应用」列表里。 */
    public static boolean hasShizukuPermission() {
        try {
            return isBinderAlive()
                    && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) {
            return false;
        }
    }

    /** 向 Shizuku 发起授权请求（系统弹窗点一下「允许」）。 */
    public static void requestShizukuPermission() {
        try {
            Shizuku.requestPermission(requestCode);
        } catch (Throwable t) {
            Log.w(TAG, "requestPermission", t);
        }
    }

    public static class ExecResult {
        public int code = -1;
        public String out = "";
        public String err = "";

        public boolean isSuccess() {
            return code == 0;
        }

        public String message() {
            String s = (err != null && !err.isEmpty()) ? err : out;
            return s == null ? "" : s.trim();
        }
    }

    /**
     * 以 shell(uid 2000) 身份执行一条 shell 命令。
     * 必须在**后台线程**调用：内部用 latch 阻塞等待结果。
     */
    public static ExecResult exec(String cmdline) {
        ExecResult r = new ExecResult();
        if (appContext == null) {
            r.err = "ShizukuAuth 未初始化";
            return r;
        }
        if (!isBinderAlive()) {
            r.err = "Shizuku 服务未运行";
            return r;
        }
        if (!hasShizukuPermission()) {
            r.err = "Shizuku 未授权本应用（请在 Shizuku 的授权应用列表里允许它）";
            return r;
        }
        int v = getVersion();
        if (v < 10) {
            r.err = "Shizuku 版本过低（" + v + "），User Service 需要 v10+";
            return r;
        }
        try {
            String raw = execViaUserService(cmdline);
            if (raw == null) {
                r.err = "绑定 User Service 超时";
                return r;
            }
            int nl = raw.indexOf('\n');
            if (nl < 0) {
                r.code = -1;
                r.err = raw;
                return r;
            }
            try {
                r.code = Integer.parseInt(raw.substring(0, nl).trim());
            } catch (NumberFormatException e) {
                r.code = -1;
            }
            r.out = raw.substring(nl + 1);
        } catch (Throwable t) {
            r.err = String.valueOf(t.getMessage());
        }
        return r;
    }

    private static String execViaUserService(String cmdline) throws Exception {
        Shizuku.UserServiceArgs args = new Shizuku.UserServiceArgs(
                new ComponentName(appContext.getPackageName(), ShellService.class.getName()))
                .processNameSuffix("adbwifi_shell")
                .debuggable(false)
                .daemon(false)
                .version(USER_SERVICE_VERSION);

        final CountDownLatch latch = new CountDownLatch(1);
        final String[] result = new String[1];
        final boolean[] bound = new boolean[1];

        ServiceConnection conn = new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                // 阻塞式 IPC 放到后台线程，别卡主线程
                new Thread(() -> {
                    try {
                        IShellService s = IShellService.Stub.asInterface(service);
                        result[0] = s.exec(cmdline);
                    } catch (Throwable t) {
                        result[0] = "-1\n" + t;
                    } finally {
                        latch.countDown();
                    }
                }, "adbwifi-exec").start();
            }

            @Override
            public void onServiceDisconnected(ComponentName name) {
            }
        };

        // 关键：bind 必须投递到主线程，否则 Shizuku 内部创建 Handler 会崩
        ui.post(() -> {
            try {
                Shizuku.bindUserService(args, conn);
                bound[0] = true;
            } catch (Throwable t) {
                result[0] = "-1\n" + t;
                latch.countDown();
            }
        });

        boolean ok = latch.await(EXEC_TIMEOUT_SEC, TimeUnit.SECONDS);

        ui.post(() -> {
            try {
                if (bound[0]) Shizuku.unbindUserService(args, conn, true);
            } catch (Throwable ignored) {
            }
        });

        return ok ? result[0] : null;
    }

    /** 核心：让本应用自己授予自己 WRITE_SECURE_SETTINGS。必须在后台线程调用。 */
    public static boolean grantSelfWriteSecureSettings() {
        ExecResult r = grantSelfExec();
        return r != null && r.isSuccess();
    }

    /** 同上，但返回完整结果（含失败原因），供 UI 展示。 */
    public static ExecResult grantSelfExec() {
        ExecResult r = new ExecResult();
        if (appContext == null) {
            r.err = "ShizukuAuth 未初始化";
            return r;
        }
        return exec("pm grant " + appContext.getPackageName()
                + " " + PERM_WRITE_SECURE_SETTINGS);
    }

    /**
     * 取端口：shell 身份一次性抓取 /proc/net/tcp、tcp6 以及 adbd 的 fd，
     * 由 PortFinder.parseProbe() 按 socket inode 精确判定哪个端口属于 adbd。
     * 普通应用直接读这些文件在 Android 10+ 常被拒，所以必须走 Shizuku。
     */
    public static String probeAdbPort() {
        ExecResult r = exec(PortFinder.buildProbeCommand());
        if (r.out == null || r.out.trim().isEmpty()) return null;
        return r.out;
    }

    /** 抓当前所有 LISTEN 端口（tcp + tcp6）。 */
    public static String listenPortsRaw() {
        ExecResult r = exec(PortDiff.buildListenCommand());
        if (r.out != null && !r.out.trim().isEmpty()) return r.out;
        return null;
    }

    /**
     * 诊断：把 adbd 相关的一切原始输出都 dump 出来，
     * 用于在真机上一次性看清「到底哪一步被 ROM 挡住了」。
     */
    public static String diagnostics() {
        return exec(
                "echo ==WHOAMI==; id;"
                        + " echo ==PIDOF==; pidof adbd 2>&1;"
                        + " echo ==PS==; ps -A 2>/dev/null | grep -i adb;"
                        + " echo ==TCP==; cat /proc/net/tcp 2>&1;"
                        + " echo ==TCP6==; cat /proc/net/tcp6 2>&1;"
                        + " echo ==SELF_FD==; ls -l /proc/self/fd 2>&1 | head -5;"
                        + " echo ==PROP==; getprop service.adb.tcp.port 2>&1;"
                        + " echo ==DUMPSYS==; dumpsys adb 2>&1 | head -40"
        ).out;
    }

    /** 固定端口：让 adbd 监听指定端口（通常 5555）。 */
    public static ExecResult fixPort(int port) {
        return exec(PortDiff.buildFixPortCommand(port));
    }

    /** 取消固定，恢复随机端口。 */
    public static ExecResult unfixPort() {
        return exec(PortDiff.buildUnfixPortCommand());
    }

    /** 旧接口保留：只读 /proc/net/tcp。 */
    public static String catProcNetTcp() {
        ExecResult r = exec("cat /proc/net/tcp");
        if (r.out != null && !r.out.trim().isEmpty()) return r.out;
        ExecResult r6 = exec("cat /proc/net/tcp6");
        if (r6.out != null && !r6.out.trim().isEmpty()) return r6.out;
        return null;
    }
}
