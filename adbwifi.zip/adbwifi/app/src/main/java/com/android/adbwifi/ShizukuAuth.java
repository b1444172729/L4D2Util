package com.android.adbwifi;

import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import rikka.shizuku.Shizuku;

/**
 * Shizuku 封装：
 *   1) 检测 Shizuku 服务是否存活、本应用是否已被 Shizuku 授权；
 *   2) 通过 User Service 以 shell(uid 2000) 身份执行 shell 命令；
 *   3) 核心用途——让本应用「自己给自己」授予 WRITE_SECURE_SETTINGS，
 *      从而彻底摆脱电脑与 adb 连线。
 *
 * 注意：Shizuku.newProcess() 在 API 13 已变成 private（官方计划 API 14 移除），
 * 所以这里走官方推荐的 bindUserService() 方案。
 */
public final class ShizukuAuth {

    public static final String PERM_WRITE_SECURE_SETTINGS =
            "android.permission.WRITE_SECURE_SETTINGS";

    private static final int USER_SERVICE_VERSION = 1;
    private static final long EXEC_TIMEOUT_SEC = 25;

    public interface StateListener {
        void onStateChanged();
    }

    private static Context appContext;
    private static int requestCode = 1001;
    private static StateListener listener;
    private static final Handler ui = new Handler(Looper.getMainLooper());

    private ShizukuAuth() {
    }

    public static void init(Context context, int reqCode, StateListener l) {
        appContext = context.getApplicationContext();
        requestCode = reqCode;
        listener = l;
        try {
            // sticky：若 binder 已经存在，注册后立刻回调一次
            Shizuku.addBinderReceivedListenerSticky(() -> notifyState());
            Shizuku.addBinderDeadListener(() -> notifyState());
            Shizuku.addRequestPermissionResultListener((code, grantResult) -> notifyState());
        } catch (Throwable ignored) {
        }
    }

    private static void notifyState() {
        ui.post(() -> {
            if (listener != null) listener.onStateChanged();
        });
    }

    /** Shizuku 服务是否在运行。 */
    public static boolean isBinderAlive() {
        try {
            return Shizuku.pingBinder();
        } catch (Throwable t) {
            return false;
        }
    }

    /** Shizuku 服务版本号，取不到返回 -1。 */
    public static int getVersion() {
        try {
            return Shizuku.getVersion();
        } catch (Throwable t) {
            return -1;
        }
    }

    /** 本应用是否已在 Shizuku 的「授权应用」列表里。 */
    public static boolean hasShizukuPermission() {
        try {
            return isBinderAlive()
                    && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) {
            return false;
        }
    }

    /** 向 Shizuku 发起授权请求（系统弹窗点一下「允许」）。 */
    public static void requestShizukuPermission() {
        try {
            Shizuku.requestPermission(requestCode);
        } catch (Throwable ignored) {
        }
    }

    public static class ExecResult {
        public int code = -1;
        public String out = "";
        public String err = "";

        public boolean isSuccess() {
            return code == 0;
        }

        /** 出错时的可读描述。 */
        public String message() {
            String s = (err != null && !err.isEmpty()) ? err : out;
            return s == null ? "" : s.trim();
        }
    }

    /**
     * 以 shell(uid 2000) 身份执行一条 shell 命令。
     *
     * 必须在**后台线程**调用：内部用 CountDownLatch 等待 User Service 绑定结果，
     * 而绑定回调投递到主线程，若在主线程调用会死锁。
     */
    public static ExecResult exec(String cmdline) {
        ExecResult r = new ExecResult();
        if (appContext == null) {
            r.err = "ShizukuAuth 未初始化";
            return r;
        }
        if (!isBinderAlive()) {
            r.err = "Shizuku 服务未运行";
            return r;
        }
        if (!hasShizukuPermission()) {
            r.err = "Shizuku 未授权本应用";
            return r;
        }
        int v = getVersion();
        if (v < 10) {
            r.err = "Shizuku 版本过低（" + v + "），User Service 需要 v10+";
            return r;
        }
        try {
            String raw = execViaUserService(cmdline);
            if (raw == null) {
                r.err = "绑定 User Service 超时";
                return r;
            }
            int nl = raw.indexOf('\n');
            if (nl < 0) {
                r.code = -1;
                r.err = raw;
                return r;
            }
            try {
                r.code = Integer.parseInt(raw.substring(0, nl).trim());
            } catch (NumberFormatException e) {
                r.code = -1;
            }
            r.out = raw.substring(nl + 1);
        } catch (Throwable t) {
            r.err = String.valueOf(t.getMessage());
        }
        return r;
    }

    private static String execViaUserService(String cmdline) throws Exception {
        Shizuku.UserServiceArgs args = new Shizuku.UserServiceArgs(
                new ComponentName(appContext.getPackageName(), ShellService.class.getName()))
                .processNameSuffix("adbwifi_shell")
                .debuggable(false)
                .daemon(false)
                .version(USER_SERVICE_VERSION);

        final CountDownLatch latch = new CountDownLatch(1);
        final String[] result = new String[1];

        ServiceConnection conn = new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                try {
                    IShellService s = IShellService.Stub.asInterface(service);
                    result[0] = s.exec(cmdline);
                } catch (Throwable t) {
                    result[0] = "-1\n" + t;
                }
                latch.countDown();
            }

            @Override
            public void onServiceDisconnected(ComponentName name) {
            }
        };

        Shizuku.bindUserService(args, conn);
        boolean ok = latch.await(EXEC_TIMEOUT_SEC, TimeUnit.SECONDS);
        try {
            // 第三个参数 true：同时让 Shizuku 销毁这个特权进程，避免常驻耗电
            Shizuku.unbindUserService(args, conn, true);
        } catch (Throwable ignored) {
        }
        return ok ? result[0] : null;
    }

    /** 核心：让本应用自己授予自己 WRITE_SECURE_SETTINGS。必须在后台线程调用。 */
    public static boolean grantSelfWriteSecureSettings() {
        ExecResult r = grantSelfExec();
        return r != null && r.isSuccess();
    }

    /** 同上，但返回完整结果（含失败原因），供 UI 展示。 */
    public static ExecResult grantSelfExec() {
        ExecResult r = new ExecResult();
        if (appContext == null) {
            r.err = "ShizukuAuth 未初始化";
            return r;
        }
        return exec("pm grant " + appContext.getPackageName()
                + " " + PERM_WRITE_SECURE_SETTINGS);
    }

    /**
     * 兜底取端口：shell 身份执行 `cat /proc/net/tcp`，再从 LISTEN 项中筛 adbd 端口。
     * 普通应用直接读该文件在 Android 10+ 常被拒，所以必须走 Shizuku。
     */
    public static String catProcNetTcp() {
        ExecResult r = exec("cat /proc/net/tcp");
        return (r.out == null || r.out.isEmpty()) ? null : r.out;
    }
}
