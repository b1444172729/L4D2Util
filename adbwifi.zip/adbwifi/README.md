# 无线调试开关（com.android.adbwifi）

一个打开就能开关「无线调试」、自动显示 IP 和随机端口的小工具，用来替代每次重启后进
「设置 → 更多设置 → 开发者选项 → 无线调试」翻菜单的流程。

## 能做什么 / 不能做什么

| 功能 | 支持 | 说明 |
|---|---|---|
| 一键开启 / 关闭无线调试 | ✅ | 写 `Settings.Global` 的 `adb_wifi_enabled` |
| 显示当前 IP:端口 | ✅ | mDNS 发现 `_adb-tls-connect._tcp`，失败则用 shell 身份扫 `/proc/net/tcp` 兜底 |
| 复制 `adb connect` 命令 | ✅ | 直接粘贴到 Termux |
| 一键拉起 Shizuku | ✅ | 包名 `moe.shizuku.privileged.api` |
| 让本应用自己给自己授权 | ✅ | 通过 Shizuku 执行 `pm grant` |
| 显示 6 位配对码 | ❌ | Android 硬限制，任何第三方 App 都读不到 |
| 开机自启 | ❌ | 按要求未实现 |

## 两个必须知道的事实

1. **配对只需一次，重启不会丢。** 重启后失效的只有两件事：开关被关掉、端口变了。
   所以本工具把「开开关 + 拿端口」做成一键，就够用了，不需要再看配对码。
2. **`WRITE_SECURE_SETTINGS` 只能靠 `pm grant` 授予**，设置界面里点不出来。
   装完 App 后必须执行一次，之后跨重启保留。

## 授权方式（三选一）

### 方式 A：Shizuku 自授权（推荐，全程不用电脑）
1. 确保 Shizuku 已在运行；
2. 打开本应用，点「用 Shizuku 给自己授权」；
3. Shizuku 弹出授权请求 → 点允许；
4. App 自动执行 `pm grant com.android.adbwifi android.permission.WRITE_SECURE_SETTINGS`；
5. 提示「授权成功」即完成，此后本应用独立运行，不再依赖 Shizuku。

### 方式 B：Termux / aShell 手动执行
```
adb shell pm grant com.android.adbwifi android.permission.WRITE_SECURE_SETTINGS
```
（在 App 里点「复制授权命令」可直接复制。）

### 方式 C：电脑
```
adb shell pm grant com.android.adbwifi android.permission.WRITE_SECURE_SETTINGS
```

> 小米机型若报 `Neither user 2000 nor current process has GRANT_RUNTIME_PERMISSIONS`，
> 去开发者选项打开「USB 调试（安全设置）」再重试。
> 实测 Redmi Note 8 Pro / MIUI 12.5.6 / Android 11 无需开此开关即可授权成功。

## 编译

```bash
./gradlew assembleDebug
# 产物：app/build/outputs/apk/debug/app-debug.apk
```

环境要求：JDK 11、Android Gradle Plugin 7.4.2、compileSdk 33。
依赖 `dev.rikka.shizuku:api:13.1.5` 与 `dev.rikka.shizuku:provider:13.1.5`。

## 使用流程

1. 装 APK → 打开 → 完成一次授权（见上）；
2. 点「打开」，系统会弹「要允许在此网络上进行无线调试吗？」，
   勾上「在此网络上始终允许」→ 该 Wi-Fi 下以后开启不再弹窗；
3. 端口自动扫出后显示 `IP:端口`，点「复制 adb connect 命令」；
4. 打开 Shizuku，点「启动」。

## 授权什么时候会掉

重启**不会**掉。只有以下情况需要重新授权一次：卸载重装、系统大版本更新（部分 OTA）、
备份恢复、手动 revoke。

## 源码结构

```
app/src/main/java/com/android/adbwifi/
├── MainActivity.java          UI 与交互
├── AdbWifiController.java     读写 adb_wifi_enabled
├── PortFinder.java            mDNS 发现 + /proc/net/tcp 解析
├── ShizukuAuth.java           Shizuku 封装与自我授权
└── NetUtils.java              本机 IP
```
