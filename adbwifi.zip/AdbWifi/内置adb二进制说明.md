# 让终端支持 adb 命令

## 为什么需要

Android 11+ 的无线调试要配对连接，必须用到 adb，但系统默认**不带** adb 可执行文件。
MT管理器 的 `/data/user/0/bin.mt.plus/files/term/bin/adb` 是它运行时才生成的，APK 里并没有
（我扫过 MT管理器 APK 全部 2261 个条目，`adb` 零命中）。

而且那个目录属于 MT 的**私有数据区**，第三方应用无权直接读——必须借 ROOT 或 Shizuku 才能拷贝出来。

## 本应用的四级获取机制

`util/AdbBinary.kt` 按「从稳到不稳」自动探测，取第一个可用的：

| 级别 | 来源 | 是否需要权限 |
|---|---|---|
| 1 | APK 内置 `jniLibs/<abi>/libadb.so` | 否，**最可靠** |
| 2 | 系统自带 `/system/bin/adb` 等 | 否 |
| 3 | 用户放到 `/sdcard/adb` 或 `/sdcard/Download/adb` | 否 |
| 4 | 从 MT管理器 / Termux 私有目录复制 | 需 ROOT 或 Shizuku |

## 方式一：运行时自动安装（最简单）

用任意方式把 adb 二进制放到手机的：

```
/sdcard/adb
```

然后打开本应用 → 高级设置 → 终端模拟器 → 点「安装 adb」，
或者直接进终端页，启动时会自动扫描安装。

## 方式二：打包进 APK（一劳永逸）

把 adb 二进制**重命名**后放进对应目录：

```
app/src/main/jniLibs/arm64-v8a/libadb.so      ← 主流 64 位 ARM 手机
app/src/main/jniLibs/armeabi-v7a/libadb.so    ← 老旧 32 位 ARM
app/src/main/jniLibs/x86/libadb.so            ← x86 模拟器
app/src/main/jniLibs/x86_64/libadb.so         ← x86_64 模拟器
```

**三个注意点：**

1. 文件名必须是 `libadb.so` —— Android 只把 `lib` 前缀 `.so` 结尾的文件提取到
   `nativeLibraryDir`，改名是为了让系统帮忙提取并确保可执行权限，内容仍是原生 ELF
2. 必须是 **Android/bionic** 版本，不能用 Linux glibc 版本（会 `No such file or directory`）
3. 目录为空不影响编译，只是终端里没有 adb

## adb 二进制从哪来

- **MT管理器**（需 ROOT/Shizuku 才能取出）：`/data/user/0/bin.mt.plus/files/term/bin/adb`
- **Termux**：`pkg install android-tools`，产物在 `/data/data/com.termux/files/usr/bin/adb`
- **Magisk 模块**：多数带 adb 的模块会放到 `/system/bin` 或 `/data/adb/modules/*/system/bin`

取出来后用 `adb push` 或文件管理器复制到 `/sdcard/adb` 即可，App 会自动安装。

## 终端的环境

终端页启动时会按顺序执行：

```sh
export PATH=/data/data/com.android.adbwifi/files/bin:$PATH
export HOME=/sdcard
export TMPDIR=<cacheDir>
alias adb='/data/data/.../files/bin/adb'   # 仅当 adb 可用时
cd /sdcard
```

即**默认工作目录就是 /sdcard**，且自带 bin 目录已前置到 PATH，
装好 adb 后直接敲 `adb devices` 就能用。
