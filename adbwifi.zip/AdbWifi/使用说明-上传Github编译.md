# 用 GitHub Actions 编译成 APK

## ⚠️ 关键：yml 必须放在「仓库根目录」，不能只在压缩包里

GitHub 只认**仓库根目录** `.github/workflows/*.yml` 里的脚本。
压缩包里的那份**不会生效**，它只是随源码备份。

仓库结构应该是这样：

```
你的仓库/
├── .github/
│   └── workflows/
│       └── build-apk.yml     ← 必须放这里（从源码包里取出这一份）
└── adbwifi.zip               ← 你上传的源码压缩包（里面套一层文件夹没关系）
```

## 操作步骤

1. 新建 GitHub 仓库（私有也可以，Actions 免费额度充足）
2. 在仓库根目录创建 `.github/workflows/build-apk.yml`，内容用源码包里那份
3. 把 `adbwifi.zip` 传到仓库根目录（网页直接拖拽上传即可）
4. 提交后自动触发编译；也可以进 **Actions** → **Build AdbWifi APK** → **Run workflow** 手动触发
5. 跑完后在 **Artifacts** 里下载 `adbwifi-apk`，里面是 `无线调试-debug.apk`

如果要 Release：打个 tag 再推送就会自动带上 APK。

```bash
git tag v1.0 && git push origin v1.0
```

## 脚本做了什么

| 步骤 | 说明 |
|---|---|
| Checkout | 检出仓库，拿到 `adbwifi.zip` |
| Setup JDK 17 / SDK 34 | 装 `platforms;android-34` + `build-tools;34.0.0`，接受 licenses |
| Setup Gradle | 下载 Gradle 8.2 到 `/opt`（**因为仓库里没有 `gradle-wrapper.jar`**，不能直接用 `./gradlew`） |
| Cache Gradle | 缓存 `~/.gradle/caches`，二次构建快很多 |
| Unzip source | 用 Python 解压（避开中文文件名编码问题），然后 `find` 找 `settings.gradle` 定位根目录——**无论压缩包里套了几层文件夹都能找到** |
| Build APK | 有 `gradle-wrapper.jar` 就用 `./gradlew`，没有就用系统 `gradle`，跑 `:app:assembleDebug` |
| Collect / Upload | 复制成 `无线调试-debug.apk`，上传 Artifact，保留 90 天 |

## 手动触发时可选 release

`Run workflow` 里 `build_type` 选 `release` 会跑 `assembleRelease`。
注意：release 目前**未配置签名**，AGP 会用 debug keystore 兜底（能装，但不是你的签名）。
要正式签名的话，把 keystore 用 base64 存进 Secrets，再加个 `signing.properties` 写入步骤即可。

## 首次使用提醒

装好 APK 后，想直接用 App 开关无线调试，需先授权一次：

```bash
adb shell pm grant com.android.adbwifi android.permission.WRITE_SECURE_SETTINGS
```

没授权的话，App 会自动降级为通过 ROOT / Shizuku 执行同一条 `settings put global adb_wifi_enabled` 命令。
