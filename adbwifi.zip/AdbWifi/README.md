# 无线调试（AdbWifi）

包名 `com.android.adbwifi`，界面与交互参照 **MCP远程**，端口获取方式参照 **RikkaApps/Shizuku**。

## 功能

| 模块 | 说明 |
|---|---|
| 服务地址 | `127.0.0.1:端口` 与 `局域网IP:端口`，4 秒轮询实时刷新，点击可复制 |
| 工作模式 | ROOT / Shizuku 切换，实时显示「※ 当前状态：ROOT：可用/不可用 Shizuku：可用/不可用」，可一键发起 Shizuku 授权 |
| 端口查询 | 右侧实时显示端口，子菜单含「端口扫描」 |
| 系统设置 | 打开系统设置 / 开关无线调试 / 开发人员选项 |
| 终端模拟器 | 长驻 shell 会话（su / Shizuku / sh），参照 MT管理器 |
| 运行日志 | 黑底绿·红字，输出 ROOT 与 Shizuku 的授权与执行结果 |

## 端口是怎么拿到的（关键）

Android 11+ 的无线调试端口是**随机的**，Shizuku 用三档方式取，本项目完整复刻：

1. **系统属性** —— `service.adb.tcp.port` / `persist.adb.tcp.port`
   （对应 Shizuku `EnvironmentUtils.getAdbTcpPort()`）

2. **mDNS 发现** —— `NsdManager` 发现 `_adb-tls-connect._tcp`，并校验：
   - 解析出的 host 必须是**本机**某块网卡的地址（避免发现到局域网里别人的设备）
   - 该端口在本机确实处于**监听**状态
   （对应 Shizuku `AdbMdns`，`manager/.../adb/AdbMdns.kt`）

   > 这正是「配对好之后，重启手机只要无线调试开着，点一下就能拿到端口」的原因：
   > 配对凭据已写入 `/data/misc/adb/adb_keys`，端口由 adbd 注册到 mDNS，无需 ROOT 即可发现。

3. **本机端口扫描兜底** —— 并发探测 127.0.0.1 的 30000–49999 及 5555，
   对开放端口发 ADB `CNXN` 握手，回 `STLS`/`CNXN`/`AUTH` 即判定为 adbd。
   （mDNS 被部分 ROM 屏蔽时生效）

## 开关无线调试

需先授权一次：

```bash
adb shell pm grant com.android.adbwifi android.permission.WRITE_SECURE_SETTINGS
```

拿到 `WRITE_SECURE_SETTINGS` 后直接写全局设置：

```
settings put global adb_wifi_enabled 0|1
```

未授权时自动降级为通过 ROOT / Shizuku 执行同一条 `settings put` 命令。

## 编译

```bash
./gradlew :app:assembleDebug
# 产物 app/build/outputs/apk/debug/app-debug.apk
```

要求：JDK 17、Android SDK 34、Gradle 8.2。

## 目录

```
app/src/main/java/com/android/adbwifi/
├── MainActivity.kt          主界面（地址卡片 + 高级设置 + 运行日志）
├── TerminalActivity.kt      终端模拟器
├── AdbWifiApp.kt            Application，初始化 Shizuku
├── adb/
│   ├── AdbPortFinder.kt     三档端口获取（核心）
│   ├── AdbMdns.kt           mDNS 发现（移植自 Shizuku）
│   ├── AdbWifiController.kt 无线调试开关 / 跳转设置页
│   ├── AdbProtocol.kt       ADB 协议常量
│   └── SystemProps.kt       反射读 SystemProperties
├── exec/
│   ├── ExecutionEngine.kt   root / shizuku / auto 降级调度
│   ├── RootExecutor.kt      su -c
│   ├── ShizukuExecutor.kt   Shizuku newProcess
│   ├── ShizukuHelper.kt     Binder 监听 + 授权 + 反射 newProcess
│   ├── AppExecutor.kt       普通身份兜底
│   ├── PrivilegeExecutor.kt 统一接口
│   └── ShellResult.kt       执行结果
├── util/                    AppLog / NetworkUtils / Prefs
└── receiver/BootReceiver.kt 开机自启
```
