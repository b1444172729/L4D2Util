package com.android.adbwifi.exec

import android.os.SystemClock

/**
 * 可用性探测的「缓存 + 变化门控」。
 *
 * 解决两个问题：
 *
 *   B 加缓存 —— TTL 内复用上次结果，避免 ROOT 通道每隔几秒就 fork 一次 `su -c id`。
 *              多个调用方（4 秒轮询、执行前的降级判断）共享同一份结果。
 *
 *   A 只在变化时记日志 —— 探测结果或描述与上次不同时才对外返回非 null，
 *              由调用方决定怎么写日志；否则返回 null 保持静默。
 *              这样主界面 4 秒轮询不会把同样的两行刷满运行日志。
 *
 * 注意：detect() 在锁内执行（它可能 fork 进程并等待），
 * 这是有意为之——并发调用时会排队等待首个结果，而不是各自 fork 一遍。
 */
class AvailabilityProbe(
    private val ttlMs: Long,
    private val detect: () -> Pair<Boolean, String>
) {
    private val lock = Any()

    /** 缓存值 */
    private var value = false
    private var detail = ""
    private var at = -1L

    /** 上一次对外汇报的内容（用于判断变化） */
    private var lastValue: Boolean? = null
    private var lastDetail = ""

    /** 当前是否可用（优先取缓存） */
    fun check(): Boolean = checkDetail().first

    /** 当前可用性 + 描述（优先取缓存） */
    fun checkDetail(): Pair<Boolean, String> {
        val now = SystemClock.elapsedRealtime()
        synchronized(lock) {
            if (at < 0 || now - at >= ttlMs) {
                val (v, d) = try {
                    detect()
                } catch (t: Throwable) {
                    false to "探测异常: ${t.message}"
                }
                value = v
                detail = d
                at = now
            }
            return value to detail
        }
    }

    /**
     * 状态或描述发生变化时返回 (是否可用, 描述)，供调用方写日志；
     * 与上次完全一致则返回 null（表示「无需汇报」）。
     */
    fun changed(): Pair<Boolean, String>? {
        val (v, d) = checkDetail()
        synchronized(lock) {
            if (lastValue == v && lastDetail == d) return null
            lastValue = v
            lastDetail = d
            return v to d
        }
    }

    /** 让缓存立即失效（Shizuku 授权完成、Binder 重连等场景） */
    fun invalidate() {
        synchronized(lock) { at = -1L }
    }
}
