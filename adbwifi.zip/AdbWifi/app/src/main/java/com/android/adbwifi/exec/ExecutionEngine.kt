package com.android.adbwifi.exec

import android.content.Context
import com.android.adbwifi.util.Prefs

/**
 * 执行引擎 —— 与 MCP远程 的 ExecutionEngine 同构：
 *   mode: root | shizuku，auto 时按 root -> shizuku -> app 逐级降级
 *
 * 各通道的可用性结果带 TTL 缓存（见 AvailabilityProbe），
 * 因此 exec 前的降级判断不会重复 fork `su`，主界面轮询也不会重复刷日志。
 */
object ExecutionEngine {

    fun currentExecutor(ctx: Context): PrivilegeExecutor =
        if (Prefs.getMode(ctx) == Prefs.MODE_ROOT) RootExecutor else ShizukuExecutor

    fun isRootAvailable(): Boolean = RootExecutor.isAvailable()

    fun isShizukuAvailable(): Boolean = ShizukuExecutor.isAvailable()

    /** 让全部通道的缓存失效，下一次查询立即真实探测 */
    fun invalidateAll() {
        RootExecutor.invalidate()
        ShizukuExecutor.invalidate()
    }

    /** 按当前模式执行；ROOT 不可用时自动降级到 Shizuku，再不行退回普通身份 */
    fun exec(ctx: Context, cmd: String, timeoutSec: Int = 15): ShellResult {
        val prefer = currentExecutor(ctx)
        val chain = if (prefer === RootExecutor) {
            listOf(RootExecutor, ShizukuExecutor, AppExecutor)
        } else {
            listOf(ShizukuExecutor, RootExecutor, AppExecutor)
        }
        for (ex in chain) {
            if (ex === AppExecutor) {
                return ex.exec(cmd, timeoutSec)
            }
            if (!ex.isAvailable()) continue
            val r = ex.exec(cmd, timeoutSec)
            if (r.err.isBlank() || r.combined.isNotBlank()) return r
        }
        return AppExecutor.exec(cmd, timeoutSec)
    }

    /** 终端模拟器：优先用当前模式的会话 */
    fun openSession(ctx: Context): ShellSession {
        val prefer = currentExecutor(ctx)
        if (prefer.isAvailable()) prefer.openSession()?.let { return it }
        ShizukuExecutor.takeIf { it.isAvailable() }?.openSession()?.let { return it }
        RootExecutor.takeIf { it.isAvailable() }?.openSession()?.let { return it }
        return AppExecutor.openSession()
            ?: throw IllegalStateException("无法创建终端会话")
    }
}
