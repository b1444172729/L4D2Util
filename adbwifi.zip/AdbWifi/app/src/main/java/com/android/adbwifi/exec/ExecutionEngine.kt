package com.android.adbwifi.exec

import android.content.Context
import com.android.adbwifi.util.Prefs

/**
 * 执行引擎 —— 与 MCP远程 的 ExecutionEngine 同构：
 *   mode: root | shizuku，auto 时按 root -> shizuku -> app 逐级降级
 *
 * 各通道的可用性结果带 TTL 缓存（见 AvailabilityProbe），
 * 因此 exec 前的降级判断不会重复 fork `su`，主界面轮询也不会重复刷日志。
 *
 * ## 终端会话的身份策略（重要）
 *
 * 早期版本是「提权优先」：终端会话直接以 su / Shizuku 身份创建。副作用是
 * 未授权时会话是个死进程（`exec` 不抛异常，进程 fork 后立刻退出），
 * 结果连 ls / cd / pwd 都报 Permission denied。
 *
 * 而且提权后进程进入 root 域 / shell 域，不再属于 appdomain，
 * 于是拿不到 `allow appdomain apk_data_file:file rx_file_perms` 这条放行，
 * 无法执行 APK 内的二进制（内置 adb 因此一直不可用）。
 *
 * 现在改为「普通优先 + 按需提权」：
 *   - 默认以普通应用身份起 /system/bin/sh —— 一定能成功，基础命令全部可用
 *   - 检测到 ROOT / Shizuku 可用时，再额外提供提权会话
 * 这与 MT 管理器终端的行为一致：基础命令零门槛，需要时终端内敲 su。
 */
object ExecutionEngine {

    /** 终端会话的身份标记 */
    enum class Identity(val label: String) {
        APP("普通"),
        ROOT("ROOT"),
        SHIZUKU("Shizuku")
    }

    /** 带身份的终端会话 */
    data class TermSession(val session: ShellSession, val identity: Identity)

    fun currentExecutor(ctx: Context): PrivilegeExecutor =
        if (Prefs.getMode(ctx) == Prefs.MODE_ROOT) RootExecutor else ShizukuExecutor

    fun isRootAvailable(): Boolean = RootExecutor.isAvailable()

    fun isShizukuAvailable(): Boolean = ShizukuExecutor.isAvailable()

    /** 让全部通道的缓存失效，下一次查询立即真实探测 */
    fun invalidateAll() {
        RootExecutor.invalidate()
        ShizukuExecutor.invalidate()
    }

    /** 按当前模式执行；ROOT 拒绝时自动降级到 Shizuku，再不行退回普通身份 */
    fun exec(ctx: Context, cmd: String, timeoutSec: Int = 15): ShellResult {
        val prefer = currentExecutor(ctx)
        val chain = if (prefer === RootExecutor) {
            listOf(RootExecutor, ShizukuExecutor, AppExecutor)
        } else {
            listOf(ShizukuExecutor, RootExecutor, AppExecutor)
        }
        for (ex in chain) {
            if (ex === AppExecutor) {
                return ex.exec(cmd, timeoutSec)
            }
            if (!ex.isAvailable()) continue
            val r = ex.exec(cmd, timeoutSec)
            if (r.err.isBlank() || r.combined.isNotBlank()) return r
        }
        return AppExecutor.exec(cmd, timeoutSec)
    }

    /**
     * 普通身份会话 —— 一定能成功，基础命令（ls/cd/pwd）可用。
     * 终端默认使用它，与是否授权 ROOT/Shizuku 无关。
     */
    fun openAppSession(cwd: String? = null): ShellSession =
        AppExecutor.openSession(cwd) ?: throw IllegalStateException("无法创建终端会话")

    /**
     * 尝试创建提权会话。按工作模式优先，另一个作为备选。
     *
     * 建完会立刻跑一条探针命令确认会话真的活着 —— 早期版本缺这步，
     * 导致 su 授权被拒时仍返回非 null 的死会话，所有命令无声失效。
     *
     * @return 成功返回会话及身份，全部不可用返回 null
     */
    fun openElevatedSession(ctx: Context, prefer: Identity? = null): TermSession? {
        val order = when (prefer) {
            Identity.ROOT -> listOf(RootExecutor to Identity.ROOT, ShizukuExecutor to Identity.SHIZUKU)
            Identity.SHIZUKU -> listOf(ShizukuExecutor to Identity.SHIZUKU, RootExecutor to Identity.ROOT)
            else -> if (Prefs.getMode(ctx) == Prefs.MODE_ROOT) {
                listOf(RootExecutor to Identity.ROOT, ShizukuExecutor to Identity.SHIZUKU)
            } else {
                listOf(ShizukuExecutor to Identity.SHIZUKU, RootExecutor to Identity.ROOT)
            }
        }
        for ((ex, id) in order) {
            if (!ex.isAvailable()) continue
            val s = ex.openSession() ?: continue
            if (probe(s, id)) return TermSession(s, id)
            runCatching { s.destroy() }
        }
        return null
    }

    /**
     * 探针：确认会话进程真的能执行命令。
     *
     * 不能用 exec 通道验证（那是另一个进程），必须写进这个会话再读输出。
     * 读取带超时，避免死会话把线程卡住。
     */
    private fun probe(s: ShellSession, id: Identity): Boolean {
        val magic = "__PROBE_${System.nanoTime()}__"
        return try {
            s.input.write("echo $magic\n".toByteArray())
            s.input.flush()
            val buf = ByteArray(4096)
            val deadline = System.currentTimeMillis() + 3000
            val sb = StringBuilder()
            while (System.currentTimeMillis() < deadline) {
                if (s.output.available() <= 0) {
                    Thread.sleep(50)
                    continue
                }
                val n = s.output.read(buf)
                if (n <= 0) break
                sb.append(String(buf, 0, n))
                if (sb.contains(magic)) {
                    // ROOT 会话再确认一次 uid，避免 su 存在但未真正提权
                    if (id != Identity.ROOT) return true
                    s.input.write("id -u\n".toByteArray())
                    s.input.flush()
                    val d2 = System.currentTimeMillis() + 3000
                    val sb2 = StringBuilder()
                    while (System.currentTimeMillis() < d2) {
                        if (s.output.available() <= 0) {
                            Thread.sleep(50)
                            continue
                        }
                        val m = s.output.read(buf)
                        if (m <= 0) break
                        sb2.append(String(buf, 0, m))
                        if (sb2.contains("\n")) break
                    }
                    return sb2.toString().trim().endsWith("0")
                }
            }
            false
        } catch (_: Throwable) {
            false
        }
    }
}
