package com.android.adbwifi.adb

import android.content.Context
import android.os.Build
import com.android.adbwifi.util.AppLog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/**
 * 无线调试端口获取器 —— 三档降级，完全对齐 Shizuku 的做法。
 *
 * 这就是为什么「配对好 Shizuku 后，重启手机只要无线调试开着，点一下就能拿到端口」：
 *
 *   档位 1  系统属性  service.adb.tcp.port / persist.adb.tcp.port
 *           （Shizuku: EnvironmentUtils.getAdbTcpPort()）
 *
 *   档位 2  mDNS 发现 _adb-tls-connect._tcp
 *           （Shizuku: AdbMdns —— Android 11+ 无线调试是随机端口，
 *             adbd 会把它注册到 mDNS，这是无 ROOT 无 Shizuku 也能拿到端口的关键）
 *
 *   档位 3  本机端口扫描 + ADB 握手探测
 *           （兜底：mDNS 被部分 ROM 屏蔽时使用；先并发找开放端口，再用 CNXN 握手确认是 adbd）
 */
object AdbPortFinder {

    data class Result(val port: Int, val source: String) {
        val isFound: Boolean get() = port > 0
    }

    /** ── 档位 1：系统属性 ───────────────────────────── */
    fun fromSystemProps(): Int {
        var port = SystemProps.getInt("service.adb.tcp.port", -1)
        if (port <= 0) port = SystemProps.getInt("persist.adb.tcp.port", -1)
        return port
    }

    /** ── 档位 2：mDNS ───────────────────────────────── */
    suspend fun viaMdns(context: Context, timeoutMs: Long = 4000L): Int = withContext(Dispatchers.IO) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return@withContext -1
        val latch = CountDownLatch(1)
        val found = AtomicInteger(-1)
        var mdns: AdbMdns? = null

        withContext(Dispatchers.Main) {
            mdns = AdbMdns(context) { port ->
                if (port > 0 && found.compareAndSet(-1, port)) latch.countDown()
            }.also { it.start() }
        }
        try {
            latch.await(timeoutMs, TimeUnit.MILLISECONDS)
        } finally {
            withContext(Dispatchers.Main) { mdns?.stop() }
        }
        found.get()
    }

    /** ── 档位 3：本机端口扫描 + ADB 握手 ─────────────── */
    suspend fun viaScan(
        host: String = "127.0.0.1",
        extra: IntArray = intArrayOf(5555),
        from: Int = 30000,
        to: Int = 49999,
        workers: Int = 64,
        onProgress: ((scanned: Int, total: Int) -> Unit)? = null
    ): Int = withContext(Dispatchers.IO) {
        val open = ConcurrentLinkedQueue<Int>()
        val total = (to - from + 1) + extra.size
        val done = AtomicInteger(0)

        extra.forEach { p ->
            if (isTcpOpen(host, p, 200)) open.add(p)
            done.incrementAndGet()
        }

        val jobs = (0 until workers).map { w ->
            async {
                var p = from + w
                while (p <= to && isActive) {
                    if (isTcpOpen(host, p, 120)) open.add(p)
                    val d = done.incrementAndGet()
                    if (onProgress != null && d % 2000 == 0) onProgress(d, total)
                    p += workers
                }
            }
        }
        jobs.awaitAll()
        onProgress?.invoke(total, total)

        // 对开放端口逐一做 ADB 握手，确认是 adbd 而不是别的监听
        for (p in open.toSortedSet()) {
            if (probeAdb(host, p, 800)) return@withContext p
        }
        -1
    }

    /** 组合：1 -> 2 -> 3 */
    suspend fun find(
        context: Context,
        useMdns: Boolean = true,
        useScan: Boolean = true,
        onProgress: ((Int, Int) -> Unit)? = null
    ): Result {
        val p1 = fromSystemProps()
        if (p1 > 0) {
            AppLog.ok("端口 $p1（来源：系统属性 service.adb.tcp.port）")
            return Result(p1, "系统属性")
        }

        if (useMdns && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            AppLog.i("系统属性无端口，尝试 mDNS 发现 $AdbMdns.TLS_CONNECT …")
            val p2 = viaMdns(context)
            if (p2 > 0) {
                AppLog.ok("端口 $p2（来源：mDNS $AdbMdns.TLS_CONNECT）")
                return Result(p2, "mDNS")
            }
            AppLog.w("mDNS 未发现，尝试本机端口扫描…")
        }

        if (useScan) {
            val p3 = viaScan(onProgress = onProgress)
            if (p3 > 0) {
                AppLog.ok("端口 $p3（来源：本机端口扫描 + ADB 握手）")
                return Result(p3, "端口扫描")
            }
        }

        AppLog.e("未能获取端口：请确认「无线调试」已开启并完成配对")
        return Result(-1, "未找到")
    }

    /** ── 底层工具 ───────────────────────────────────── */

    private fun isTcpOpen(host: String, port: Int, timeoutMs: Int): Boolean = try {
        Socket().use {
            it.connect(InetSocketAddress(host, port), timeoutMs)
            true
        }
    } catch (t: Throwable) {
        false
    }

    /** 发一个 CNXN，若回 STLS / CNXN / AUTH 则判定为 adbd */
    private fun probeAdb(host: String, port: Int, timeoutMs: Int): Boolean = try {
        Socket().use { s ->
            s.connect(InetSocketAddress(host, port), timeoutMs)
            s.soTimeout = timeoutMs
            s.tcpNoDelay = true
            val out = DataOutputStream(s.getOutputStream())
            writeMessage(out, AdbProtocol.A_CNXN, AdbProtocol.A_VERSION, AdbProtocol.A_MAXDATA, "host::".toByteArray())

            val header = ByteArray(AdbProtocol.HEADER_LENGTH)
            DataInputStream(s.getInputStream()).readFully(header)
            val cmd = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN).int
            cmd == AdbProtocol.A_STLS || cmd == AdbProtocol.A_CNXN || cmd == AdbProtocol.A_AUTH
        }
    } catch (t: Throwable) {
        false
    }

    private fun writeMessage(out: DataOutputStream, cmd: Int, arg0: Int, arg1: Int, data: ByteArray) {
        val checksum = data.fold(0) { acc, b -> acc + (b.toInt() and 0xFF) }
        val magic = cmd xor -1
        val size = data.size
        val buf = ByteBuffer.allocate(AdbProtocol.HEADER_LENGTH + size).order(ByteOrder.LITTLE_ENDIAN)
        buf.putInt(cmd)
        buf.putInt(arg0)
        buf.putInt(arg1)
        buf.putInt(size)
        buf.putInt(checksum)
        buf.putInt(magic)
        buf.put(data)
        out.write(buf.array())
        out.flush()
    }
}
