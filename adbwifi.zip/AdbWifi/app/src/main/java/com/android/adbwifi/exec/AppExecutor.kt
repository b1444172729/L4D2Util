package com.android.adbwifi.exec

/** 普通应用身份通道（兜底，权限最低） */
object AppExecutor : PrivilegeExecutor {

    override val name = "APP"

    override fun isAvailable(): Boolean = true

    /** 兜底通道恒定可用，无需汇报，避免刷屏 */
    override fun availabilityChanged(): Pair<Boolean, String>? = null

    override fun invalidate() = Unit

    override fun exec(cmd: String, timeoutSec: Int): ShellResult = try {
        val p = Runtime.getRuntime().exec(arrayOf("sh", "-c", cmd))
        val (out, err) = ShellResult.readAll(p, timeoutSec)
        val code = try { p.exitValue() } catch (_: Throwable) { -1 }
        ShellResult(code, out, err, name)
    } catch (t: Throwable) {
        ShellResult.fail(t.message ?: "执行异常", name)
    }

    override fun openSession(): ShellSession? = try {
        val p = ProcessBuilder("sh").redirectErrorStream(false).start()
        object : ShellSession {
            override val input get() = p.outputStream
            override val output get() = p.inputStream
            override val error get() = p.errorStream
            override fun destroy() { runCatching { p.destroy() } }
        }
    } catch (_: Throwable) {
        null
    }
}
