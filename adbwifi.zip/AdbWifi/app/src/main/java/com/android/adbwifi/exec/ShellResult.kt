package com.android.adbwifi.exec

data class ShellResult(
    val exitCode: Int,
    val out: String,
    val err: String,
    val via: String
) {
    val combined: String get() = listOf(out, err).filter { it.isNotBlank() }.joinToString("\n")
    val isOk: Boolean get() = exitCode == 0

    companion object {
        fun fail(msg: String, via: String) = ShellResult(-1, "", msg, via)

        internal fun readAll(p: Process, timeoutSec: Int): Pair<String, String> {
            val out = StringBuilder()
            val err = StringBuilder()
            val t1 = thread(p.inputStream) { out.appendLine(it) }
            val t2 = thread(p.errorStream) { err.appendLine(it) }
            val done = try {
                p.waitFor(timeoutSec.toLong(), java.util.concurrent.TimeUnit.SECONDS)
            } catch (t: Throwable) {
                true
            }
            if (!done) runCatching { p.destroyForcibly() }
            runCatching { t1.join(1500) }
            runCatching { t2.join(1500) }
            return out.toString().trimEnd() to err.toString().trimEnd()
        }

        private fun thread(stream: java.io.InputStream, sink: (String) -> Unit): Thread =
            Thread {
                try {
                    stream.bufferedReader().forEachLine { sink(it) }
                } catch (_: Throwable) {
                }
            }.apply { isDaemon = true; start() }
    }
}
