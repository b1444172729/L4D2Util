package com.android.adbwifi.adb

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import com.android.adbwifi.util.AppLog

/**
 * 无线调试开关控制。
 *
 * 两条路径，自动选择：
 *   A. 已授权 WRITE_SECURE_SETTINGS  -> 直接 Settings.Global.putInt(adb_wifi_enabled, 0/1)
 *      （首次授权：adb shell pm grant com.android.adbwifi android.permission.WRITE_SECURE_SETTINGS）
 *   B. 未授权但有 ROOT / Shizuku      -> settings put global adb_wifi_enabled 0/1
 */
object AdbWifiController {

    const val ADB_WIFI_ENABLED = "adb_wifi_enabled"
    private const val ADB_ENABLED = "adb_enabled"

    /** 无线调试当前是否开启（读 Settings.Global 不需要特殊权限） */
    fun isEnabled(ctx: Context): Boolean = try {
        Settings.Global.getInt(ctx.contentResolver, ADB_WIFI_ENABLED, 0) == 1
    } catch (t: Throwable) {
        AppLog.w("读取 $ADB_WIFI_ENABLED 失败: ${t.message}")
        false
    }

    fun hasWriteSecure(ctx: Context): Boolean =
        ctx.checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS) == PackageManager.PERMISSION_GRANTED

    /** 路径 A：直接写全局设置 */
    fun setEnabledDirect(ctx: Context, enable: Boolean): Boolean {
        if (!hasWriteSecure(ctx)) return false
        return try {
            val cr = ctx.contentResolver
            Settings.Global.putInt(cr, ADB_WIFI_ENABLED, if (enable) 1 else 0)
            // 顺带把「USB 调试」也打开，否则部分 ROM 上无线调试不生效（与 Shizuku 一致）
            if (enable) {
                Settings.Global.putInt(cr, ADB_ENABLED, 1)
                runCatching { Settings.Global.putLong(cr, "adb_allowed_connection_time", 0L) }
            }
            true
        } catch (t: Throwable) {
            AppLog.e("写入 $ADB_WIFI_ENABLED 失败: ${t.message}")
            false
        }
    }

    /** 路径 B：走提权通道执行 settings put */
    fun shellCommand(enable: Boolean): String =
        "settings put global $ADB_WIFI_ENABLED ${if (enable) 1 else 0}"

    /** 供 UI 展示的授权提示命令 */
    fun grantCommand(ctx: Context): String =
        "adb shell pm grant ${ctx.packageName} android.permission.WRITE_SECURE_SETTINGS"

    /** 打开系统设置主页 */
    fun openSystemSettings(ctx: Context) {
        safeStart(ctx, Intent(Settings.ACTION_SETTINGS))
    }

    /** 打开开发者选项 */
    fun openDeveloperOptions(ctx: Context) {
        safeStart(ctx, Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
    }

    /** 直接跳到「无线调试」开关页（Shizuku 用的就是这个 fragment key） */
    fun openWirelessDebuggingPage(ctx: Context) {
        val intent = Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra(":settings:fragment_args_key", "toggle_adb_wireless")
        }
        safeStart(ctx, intent)
    }

    private fun safeStart(ctx: Context, intent: Intent) {
        try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            AppLog.e("无法跳转设置页: ${intent.action}")
        } catch (t: Throwable) {
            AppLog.e("跳转失败: ${t.message}")
        }
    }
}
