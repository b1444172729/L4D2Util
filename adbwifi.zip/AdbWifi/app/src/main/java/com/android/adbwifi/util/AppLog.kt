package com.android.adbwifi.util

import android.os.Handler
import android.os.Looper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class Level { INFO, OK, WARN, ERR }

data class LogEntry(val time: String, val level: Level, val text: String)

/**
 * 全局运行日志。
 * 与 MCP远程 的 AppLog 同构：环形缓冲 + 监听器，UI 直接订阅即可。
 */
object AppLog {

    private const val MAX = 600
    private val entries = ArrayList<LogEntry>()
    private val listeners = LinkedHashMap<String, (LogEntry) -> Unit>()
    private val main = Handler(Looper.getMainLooper())
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.CHINA)

    fun i(text: String) = push(Level.INFO, text)
    fun ok(text: String) = push(Level.OK, text)
    fun w(text: String) = push(Level.WARN, text)
    fun e(text: String) = push(Level.ERR, text)

    @Synchronized
    private fun push(level: Level, text: String) {
        val entry = LogEntry(fmt.format(Date()), level, text)
        entries.add(entry)
        while (entries.size > MAX) entries.removeAt(0)
        val snapshot = ArrayList(listeners.values)
        main.post {
            snapshot.forEach { runCatching { it.invoke(entry) } }
        }
    }

    @Synchronized
    fun snapshot(): List<LogEntry> = ArrayList(entries)

    @Synchronized
    fun clear() {
        entries.clear()
        main.post { listeners.values.forEach { runCatching { } } }
    }

    @Synchronized
    fun addListener(key: String, l: (LogEntry) -> Unit) {
        listeners[key] = l
    }

    fun removeListener(key: String) {
        listeners.remove(key)
    }
}
