package com.android.adbwifi.util

import android.content.Context

object Prefs {

    private const val NAME = "adbwifi"
    private const val K_MODE = "mode"          // root | shizuku
    private const val K_PORT = "port"          // 最近一次获取到的端口
    private const val K_AUTOSTART = "autostart"

    const val MODE_ROOT = "root"
    const val MODE_SHIZUKU = "shizuku"

    private fun sp(ctx: Context) = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun getMode(ctx: Context): String = sp(ctx).getString(K_MODE, MODE_ROOT) ?: MODE_ROOT
    fun setMode(ctx: Context, mode: String) = sp(ctx).edit().putString(K_MODE, mode).apply()

    fun getPort(ctx: Context): Int = sp(ctx).getInt(K_PORT, -1)
    fun setPort(ctx: Context, port: Int) = sp(ctx).edit().putInt(K_PORT, port).apply()

    fun isAutoStart(ctx: Context): Boolean = sp(ctx).getBoolean(K_AUTOSTART, false)
    fun setAutoStart(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean(K_AUTOSTART, v).apply()
}
