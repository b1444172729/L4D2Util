package com.android.adbwifi.util

import android.content.Context

object Prefs {

    private const val NAME = "adbwifi"
    private const val K_MODE = "mode"          // root | shizuku
    private const val K_PORT = "port"          // 最近一次获取到的端口
    private const val K_AUTOSTART = "autostart"
    private const val K_TERM_CWD = "term_cwd"  // 终端起始工作目录
    private const val K_TERM_SIZE = "term_size" // 终端字号 sp
    private const val K_TERM_WRAP = "term_wrap" // 自动换行：默认关闭
    private const val K_TERM_IDLINE = "term_idline" // 显示身份凭证（uid 行）：默认隐藏
    private const val K_TERM_CMDS = "term_cmds"     // 常用命令，按 \n 拼接

    const val MODE_ROOT = "root"
    const val MODE_SHIZUKU = "shizuku"

    /** 终端默认起始目录 */
    const val DEFAULT_TERM_CWD = "/sdcard"
    /** 终端字号范围，与设置菜单的选择范围一致 */
    const val TERM_SIZE_MIN = 5
    const val TERM_SIZE_MAX = 30
    const val TERM_SIZE_DEFAULT = 12

    private fun sp(ctx: Context) = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun getMode(ctx: Context): String = sp(ctx).getString(K_MODE, MODE_ROOT) ?: MODE_ROOT
    fun setMode(ctx: Context, mode: String) = sp(ctx).edit().putString(K_MODE, mode).apply()

    fun getPort(ctx: Context): Int = sp(ctx).getInt(K_PORT, -1)
    fun setPort(ctx: Context, port: Int) = sp(ctx).edit().putInt(K_PORT, port).apply()

    fun isAutoStart(ctx: Context): Boolean = sp(ctx).getBoolean(K_AUTOSTART, false)
    fun setAutoStart(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean(K_AUTOSTART, v).apply()

    /** 终端起始工作目录，默认 /sdcard；目录不存在时由调用方回退 */
    fun getTermCwd(ctx: Context): String = sp(ctx).getString(K_TERM_CWD, DEFAULT_TERM_CWD) ?: DEFAULT_TERM_CWD
    fun setTermCwd(ctx: Context, v: String) = sp(ctx).edit().putString(K_TERM_CWD, v).apply()

    /** 终端字号 sp，范围 5..30 */
    fun getTermSize(ctx: Context): Int =
        sp(ctx).getInt(K_TERM_SIZE, TERM_SIZE_DEFAULT).coerceIn(TERM_SIZE_MIN, TERM_SIZE_MAX)
    fun setTermSize(ctx: Context, v: Int) =
        sp(ctx).edit().putInt(K_TERM_SIZE, v.coerceIn(TERM_SIZE_MIN, TERM_SIZE_MAX)).apply()

    /** 自动换行，默认关闭：关闭时一行完整显示，可横向滑动看到行尾 */
    fun isTermWrap(ctx: Context): Boolean = sp(ctx).getBoolean(K_TERM_WRAP, false)
    fun setTermWrap(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean(K_TERM_WRAP, v).apply()

    /** 是否显示身份凭证（uid/gid/groups/context 那行），默认隐藏 */
    fun isTermIdLine(ctx: Context): Boolean = sp(ctx).getBoolean(K_TERM_IDLINE, false)
    fun setTermIdLine(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean(K_TERM_IDLINE, v).apply()

    // ---- 常用命令：按换行拼接存储，保留添加顺序 ----

    fun getCmds(ctx: Context): List<String> =
        sp(ctx).getString(K_TERM_CMDS, "").orEmpty()
            .split("\n").map { it.trim() }.filter { it.isNotEmpty() }

    fun setCmds(ctx: Context, list: List<String>) =
        sp(ctx).edit().putString(K_TERM_CMDS, list.joinToString("\n")).apply()

    /** 追加一条命令（已存在则不再重复添加） */
    fun addCmd(ctx: Context, cmd: String) {
        val list = getCmds(ctx).toMutableList()
        if (cmd in list) return
        list.add(cmd)
        setCmds(ctx, list)
    }

    fun removeCmd(ctx: Context, cmd: String) = setCmds(ctx, getCmds(ctx) - cmd)
}
