package com.android.adbwifi.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.android.adbwifi.adb.AdbPortFinder
import com.android.adbwifi.adb.AdbWifiController
import com.android.adbwifi.exec.ShizukuHelper
import com.android.adbwifi.util.AppLog
import com.android.adbwifi.util.Prefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * 开机自启：若无线调试处于开启状态，尝试自动获取端口。
 * 逻辑与 Shizuku 的 BootCompleteReceiver#adbStart 一致：
 *   先确保 adb_wifi_enabled = 1，再用三档方式取端口。
 */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        if (action != Intent.ACTION_BOOT_COMPLETED
            && action != Intent.ACTION_LOCKED_BOOT_COMPLETED
            && action != Intent.ACTION_MY_PACKAGE_REPLACED
        ) return

        if (!Prefs.isAutoStart(context)) return

        ShizukuHelper.init()
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                if (AdbWifiController.hasWriteSecure(context)) {
                    AdbWifiController.setEnabledDirect(context, true)
                }
                if (AdbWifiController.isEnabled(context)) {
                    val r = AdbPortFinder.find(context)
                    if (r.isFound) Prefs.setPort(context, r.port)
                }
            } catch (t: Throwable) {
                AppLog.e("开机自启失败: ${t.message}")
            } finally {
                pending.finish()
            }
        }
    }
}
