package com.android.adbwifi.exec

/** 交互式 shell 会话（终端模拟器用） */
interface ShellSession {
    val input: java.io.OutputStream
    val output: java.io.InputStream
    val error: java.io.InputStream
    fun destroy()
}

/** 提权执行器统一接口 */
interface PrivilegeExecutor {
    val name: String

    /** 当前是否可用（结果带 TTL 缓存，不会每次都真实探测） */
    fun isAvailable(): Boolean

    /** 当前可用性 + 描述（同样走缓存），用于需要把原因写进日志的场景 */
    fun availability(): Pair<Boolean, String>

    fun exec(cmd: String, timeoutSec: Int = 15): ShellResult
    fun openSession(): ShellSession?

    /**
     * 可用性或描述发生变化时返回 (是否可用, 描述)，供调用方写日志；
     * 与上次一致则返回 null。用于避免轮询把同一条日志反复刷屏。
     */
    fun availabilityChanged(): Pair<Boolean, String>?

    /** 让可用性缓存立即失效 */
    fun invalidate()
}
