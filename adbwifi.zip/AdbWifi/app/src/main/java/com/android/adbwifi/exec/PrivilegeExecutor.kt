package com.android.adbwifi.exec

/** 交互式 shell 会话（终端模拟器用） */
interface ShellSession {
    val input: java.io.OutputStream
    val output: java.io.InputStream
    val error: java.io.InputStream
    fun destroy()
}

/** 提权执行器统一接口 */
interface PrivilegeExecutor {
    val name: String
    fun isAvailable(): Boolean
    fun exec(cmd: String, timeoutSec: Int = 15): ShellResult
    fun openSession(): ShellSession?
}
