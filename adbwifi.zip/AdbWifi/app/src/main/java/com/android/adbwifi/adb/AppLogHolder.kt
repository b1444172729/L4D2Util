package com.android.adbwifi.adb

import com.android.adbwifi.util.AppLog

/** adb 包内便捷访问日志（避免循环引用时的包名歧义） */
internal object AppLogHolder {
    val log = AppLog
}
