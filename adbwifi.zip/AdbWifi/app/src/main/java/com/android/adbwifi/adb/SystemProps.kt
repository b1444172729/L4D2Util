package com.android.adbwifi.adb

/** 反射读取 android.os.SystemProperties（隐藏 API，无需 bypass） */
object SystemProps {

    private val clazz = Class.forName("android.os.SystemProperties")
    private val getInt = clazz.getDeclaredMethod("getInt", String::class.java, Int::class.javaPrimitiveType)
    private val get = clazz.getDeclaredMethod("get", String::class.java, String::class.java)

    fun getInt(key: String, def: Int): Int = try {
        getInt.invoke(null, key, def) as Int
    } catch (t: Throwable) {
        def
    }

    fun get(key: String, def: String = ""): String = try {
        (get.invoke(null, key, def) as? String) ?: def
    } catch (t: Throwable) {
        def
    }
}
