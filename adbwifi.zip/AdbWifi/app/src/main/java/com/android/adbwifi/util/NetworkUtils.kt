package com.android.adbwifi.util

import java.net.Inet4Address
import java.net.NetworkInterface

object NetworkUtils {

    /** 枚举本机全部 IPv4（排除回环 / 断开的接口） */
    fun getAllLanIpv4(): List<String> {
        val out = ArrayList<String>()
        try {
            val en = NetworkInterface.getNetworkInterfaces() ?: return out
            while (en.hasMoreElements()) {
                val ni = en.nextElement()
                if (!ni.isUp || ni.isLoopback) continue
                val addrs = ni.inetAddresses
                while (addrs.hasMoreElements()) {
                    val a = addrs.nextElement()
                    if (a is Inet4Address && !a.isLoopbackAddress && !a.isLinkLocalAddress) {
                        val ip = a.hostAddress ?: continue
                        if (ip !in out) out.add(ip)
                    }
                }
            }
        } catch (t: Throwable) {
            AppLog.w("枚举网络接口失败: ${t.message}")
        }
        return out
    }

    /** 优先取 192.168 / 10. / 172.16-31 这类局域网地址 */
    fun preferredLanIp(): String? {
        val all = getAllLanIpv4()
        if (all.isEmpty()) return null
        return all.firstOrNull { it.startsWith("192.168.") }
            ?: all.firstOrNull { it.startsWith("10.") }
            ?: all.firstOrNull {
                it.startsWith("172.") && it.split(".").getOrNull(1)?.toIntOrNull() in 16..31
            }
            ?: all.first()
    }
}
