package com.android.adbwifi

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.style.ForegroundColorSpan
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.android.adbwifi.adb.AdbPortFinder
import com.android.adbwifi.adb.AdbWifiController
import com.android.adbwifi.databinding.ActivityMainBinding
import com.android.adbwifi.exec.ExecutionEngine
import com.android.adbwifi.exec.RootExecutor
import com.android.adbwifi.exec.ShizukuExecutor
import com.android.adbwifi.exec.ShizukuHelper
import com.android.adbwifi.util.AppLog
import com.android.adbwifi.util.Level
import com.android.adbwifi.util.LogEntry
import com.android.adbwifi.util.NetworkUtils
import com.android.adbwifi.util.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding

    private val timer = Handler(Looper.getMainLooper())
    private var currentPort = -1
    private var scanning = false

    private val logBuilder = SpannableStringBuilder()

    /**
     * RadioGroup 的选中回调在 updateModeRadio() 调 check() 时也会触发，
     * 用这个标志跳过初始化时的那一次，避免刚进界面就弹 Shizuku 授权框。
     */
    private var modeRadioReady = false

    /** 实时刷新：端口 + IP + ROOT/Shizuku 可用性 */
    private val refreshTask = object : Runnable {
        override fun run() {
            refreshAll()
            timer.postDelayed(this, REFRESH_MS)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        ShizukuHelper.init()
        bindViews()
        initAdvancedMenu()
        loadLogHistory()
        updateModeRadio()
    }

    override fun onResume() {
        super.onResume()
        AppLog.addListener(LISTENER) { renderLog(it) }
        refreshAll()
        timer.postDelayed(refreshTask, REFRESH_MS)
    }

    override fun onPause() {
        super.onPause()
        AppLog.removeListener(LISTENER)
        timer.removeCallbacks(refreshTask)
    }

    // ───────────────────────── 绑定 ─────────────────────────

    private fun bindViews() {
        // 点击地址复制
        b.tvLocal.setOnClickListener { copy(b.tvLocal.text.toString()) }
        b.tvLan.setOnClickListener { copy(b.tvLan.text.toString()) }

        b.btnRefresh.setOnClickListener {
            AppLog.i("手动刷新…")
            refreshAll()
        }

        b.btnClearLog.setOnClickListener {
            AppLog.clear()
            logBuilder.clear()
            b.tvLog.text = ""
        }

        // 折叠面板
        togglePanel(b.itemMode, b.panelMode, b.ivArrowMode)
        togglePanel(b.itemPort, b.panelPort, b.ivArrowPort)
        togglePanel(b.itemSystem, b.panelSystem, b.ivArrowSystem)
        togglePanel(b.itemTerminal, b.panelTerminal, b.ivArrowTerminal)

        // 工作模式：切换后立刻申请对应权限并把结果打印到运行日志
        b.rgMode.setOnCheckedChangeListener { _, id ->
            if (!modeRadioReady) return@setOnCheckedChangeListener
            onModeSwitched(id)
        }

        // 端口扫描
        b.btnScanPort.setOnClickListener { doScanPort() }

        // 系统设置
        b.btnSysSettings.setOnClickListener { AdbWifiController.openSystemSettings(this) }
        b.btnDevOptions.setOnClickListener { AdbWifiController.openDeveloperOptions(this) }
        b.btnToggleWadbMain.setOnClickListener { toggleWirelessAdb() }

        // 终端
        b.btnTerminal.setOnClickListener {
            startActivity(android.content.Intent(this, TerminalActivity::class.java))
        }

    }

    /**
     * 切换工作模式后立刻申请对应权限。
     *  - ROOT    ：探测 su 并真正执行 su -c id，把结果打印到运行日志
     *  - Shizuku ：发起 Shizuku 授权（与原「发起 Shizuku 授权」按钮逻辑一致）
     */
    private fun onModeSwitched(checkedId: Int) {
        val mode = if (checkedId == b.rbRoot.id) Prefs.MODE_ROOT else Prefs.MODE_SHIZUKU
        val label = getString(if (mode == Prefs.MODE_ROOT) R.string.mode_root else R.string.mode_shizuku)
        Prefs.setMode(this, mode)
        b.tvModeValue.text = label
        AppLog.i("工作模式切换为 $label")

        if (mode == Prefs.MODE_ROOT) {
            // 缓存失效，确保这一次是真探测（真的去执行 su -c id）而不是读缓存
            RootExecutor.invalidate()
            lifecycleScope.launch {
                val (ok, msg) = withContext(Dispatchers.IO) { RootExecutor.availability() }
                if (ok) AppLog.ok(msg) else AppLog.w(msg)
                refreshStatus()
            }
        } else {
            ShizukuExecutor.invalidate()
            ShizukuHelper.refreshGranted()
            if (ShizukuHelper.granted) {
                AppLog.ok("Shizuku 授权已获得")
            } else {
                ShizukuHelper.requestPermission()
                ShizukuExecutor.invalidate()
            }
            refreshStatus()
        }
    }

    private fun initAdvancedMenu() {
        // 预留：后续可在此挂载更多高级项
        ShizukuHelper.addGrantedCallback { refreshStatus() }
    }

    private fun togglePanel(header: View, panel: View, arrow: View) {
        header.setOnClickListener {
            val show = panel.visibility != View.VISIBLE
            panel.visibility = if (show) View.VISIBLE else View.GONE
            arrow.rotation = if (show) 180f else 0f
        }
    }

    private fun updateModeRadio() {
        val mode = Prefs.getMode(this)
        modeRadioReady = false
        if (mode == Prefs.MODE_SHIZUKU) b.rgMode.check(b.rbShizuku.id) else b.rgMode.check(b.rbRoot.id)
        modeRadioReady = true
        b.tvModeValue.text = if (mode == Prefs.MODE_ROOT) getString(R.string.mode_root) else getString(R.string.mode_shizuku)
    }

    // ───────────────────────── 刷新 ─────────────────────────

    private fun refreshAll() {
        updateAddress()
        refreshStatus()
        updateWadbButton()
    }

    private fun updateAddress() {
        val port = if (currentPort > 0) currentPort else Prefs.getPort(this)
        val ip = NetworkUtils.preferredLanIp()

        if (port > 0) {
            b.tvLocal.text = "$LOCAL_HOST:$port"
            b.tvLan.text = if (ip != null) "$ip:$port" else getString(R.string.no_ip)
        } else {
            b.tvLocal.text = getString(R.string.addr_unknown)
            b.tvLan.text = getString(R.string.addr_unknown)
        }
        b.tvPortValue.text = if (port > 0) port.toString() else getString(R.string.port_unset)
    }

    /**
     * 获取 ROOT / Shizuku 可用性。
     * 探测结果带 TTL 缓存，且只有状态发生变化时才写运行日志，
     * 避免 4 秒轮询把同样的两行反复刷屏。
     */
    private fun refreshStatus() {
        lifecycleScope.launch {
            val rootChanged = withContext(Dispatchers.IO) { RootExecutor.availabilityChanged() }
            val shizukuChanged = withContext(Dispatchers.IO) { ShizukuExecutor.availabilityChanged() }
            val rootOk = withContext(Dispatchers.IO) { RootExecutor.isAvailable() }
            val shizukuOk = withContext(Dispatchers.IO) { ShizukuExecutor.isAvailable() }

            // 仅在状态变化时输出，可用走 OK（绿），拒绝走 WARN（黄）
            rootChanged?.let { (ok, msg) -> if (ok) AppLog.ok(msg) else AppLog.w(msg) }
            shizukuChanged?.let { (ok, msg) -> if (ok) AppLog.ok(msg) else AppLog.w(msg) }

            updatePermStatus(rootOk, shizukuOk)
        }
    }

    /**
     * 权限状态行：「权限状态：ROOT：拒绝/允许    Shizuku：拒绝/允许」
     * 拒绝标红、允许标青绿，其余文字用主文本色。
     */
    private fun updatePermStatus(rootOk: Boolean, shizukuOk: Boolean) {
        val allowed = getString(R.string.perm_allowed)
        val denied = getString(R.string.perm_denied)
        val text = getString(
            R.string.perm_status,
            if (rootOk) allowed else denied,
            if (shizukuOk) allowed else denied
        )
        val sb = SpannableStringBuilder(text)
        val colorAllowed = ContextCompat.getColor(this, R.color.brand_teal)
        val colorDenied = ContextCompat.getColor(this, R.color.bad)
        for (word in arrayOf(allowed, denied)) {
            val color = if (word == allowed) colorAllowed else colorDenied
            var idx = text.indexOf(word)
            while (idx >= 0) {
                sb.setSpan(
                    ForegroundColorSpan(color), idx, idx + word.length,
                    Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
                )
                idx = text.indexOf(word, idx + word.length)
            }
        }
        b.tvPermStatus.text = sb
    }

    private fun updateWadbButton() {
        val on = AdbWifiController.isEnabled(this)

        // 顶部状态版块：「服务状态: 」固定青绿，状态词按开关状态着色；
        // 按钮随之切换：已开启时「关闭」标红，已关闭时「开启」标亮绿
        if (on) {
            setWadbStatus(getString(R.string.wadb_status_on_word), R.color.log_ok)
            b.btnToggleWadbMain.text = getString(R.string.btn_disable)
            b.btnToggleWadbMain.setTextColor(ContextCompat.getColor(this, R.color.bad))
        } else {
            setWadbStatus(getString(R.string.wadb_status_off_word), R.color.bad)
            b.btnToggleWadbMain.text = getString(R.string.btn_enable)
            b.btnToggleWadbMain.setTextColor(ContextCompat.getColor(this, R.color.log_ok))
        }
    }

    /**
     * 拼出「服务状态: 已开启/已关闭」：
     * 前缀「服务状态: 」恒为青绿（brand_teal），状态词单独上色。
     */
    private fun setWadbStatus(word: String, wordColorRes: Int) {
        val prefix = getString(R.string.wadb_status_prefix)
        val sb = SpannableStringBuilder(prefix + word)
        sb.setSpan(
            ForegroundColorSpan(ContextCompat.getColor(this, R.color.brand_teal)),
            0, prefix.length,
            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        sb.setSpan(
            ForegroundColorSpan(ContextCompat.getColor(this, wordColorRes)),
            prefix.length, prefix.length + word.length,
            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        b.tvWadbStatus.text = sb
    }

    private fun doScanPort() {
        if (scanning) return
        scanning = true
        val old = b.btnScanPort.text
        b.btnScanPort.isEnabled = false
        b.btnScanPort.text = getString(R.string.scanning)
        AppLog.i("开始扫描本机 ADB 端口…")

        lifecycleScope.launch {
            val r = withContext(Dispatchers.IO) {
                AdbPortFinder.find(this@MainActivity) { done, total ->
                    if (done % 8000 == 0) AppLog.i("扫描进度 $done/$total")
                }
            }
            if (r.isFound) {
                currentPort = r.port
                Prefs.setPort(this@MainActivity, r.port)
            }
            updateAddress()
            scanning = false
            b.btnScanPort.isEnabled = true
            b.btnScanPort.text = old
        }
    }

    private fun toggleWirelessAdb() {
        val target = !AdbWifiController.isEnabled(this)
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                if (AdbWifiController.hasWriteSecure(this@MainActivity)) {
                    AdbWifiController.setEnabledDirect(this@MainActivity, target)
                } else {
                    val cmd = AdbWifiController.shellCommand(target)
                    val r = ExecutionEngine.exec(this@MainActivity, cmd)
                    if (r.combined.isNotBlank()) AppLog.i(r.combined)
                    r.err.isBlank()
                }
            }
            if (ok) {
                AppLog.ok(if (target) "无线调试已开启" else "无线调试已关闭")
            } else {
                AppLog.e(getString(R.string.need_write_secure, packageName))
            }
            updateWadbButton()
            refreshAll()
        }
    }

    private fun copy(text: String) {
        if (text.isBlank() || text == getString(R.string.addr_unknown)) {
            Toast.makeText(this, R.string.no_addr_copy, Toast.LENGTH_SHORT).show()
            return
        }
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("adbwifi", text))
        Toast.makeText(this, R.string.copied, Toast.LENGTH_SHORT).show()
    }

    // ───────────────────────── 日志 ─────────────────────────

    private fun loadLogHistory() {
        logBuilder.clear()
        AppLog.snapshot().forEach { renderLog(it) }
    }

    private fun renderLog(e: LogEntry) {
        val color = when (e.level) {
            Level.INFO -> ContextCompat.getColor(this, R.color.log_info)
            Level.OK -> ContextCompat.getColor(this, R.color.log_ok)
            Level.WARN -> ContextCompat.getColor(this, R.color.log_warn)
            Level.ERR -> ContextCompat.getColor(this, R.color.log_err)
        }
        val start = logBuilder.length
        logBuilder.append("${e.time}  ${e.text}\n")
        logBuilder.setSpan(ForegroundColorSpan(color), start, logBuilder.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        b.tvLog.text = logBuilder
        b.logScroll.post { b.logScroll.fullScroll(View.FOCUS_DOWN) }
    }

    companion object {
        private const val LOCAL_HOST = "127.0.0.1"
        private const val LISTENER = "main"
        private const val REFRESH_MS = 4000L
    }
}
