package com.android.adbwifi

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.style.ForegroundColorSpan
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.android.adbwifi.adb.AdbPortFinder
import com.android.adbwifi.adb.AdbWifiController
import com.android.adbwifi.databinding.ActivityMainBinding
import com.android.adbwifi.exec.ExecutionEngine
import com.android.adbwifi.exec.ShizukuHelper
import com.android.adbwifi.util.AppLog
import com.android.adbwifi.util.Level
import com.android.adbwifi.util.LogEntry
import com.android.adbwifi.util.NetworkUtils
import com.android.adbwifi.util.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding

    private val timer = Handler(Looper.getMainLooper())
    private var currentPort = -1
    private var scanning = false

    private val logBuilder = SpannableStringBuilder()

    /** 实时刷新：端口 + IP + ROOT/Shizuku 可用性 */
    private val refreshTask = object : Runnable {
        override fun run() {
            refreshAll()
            timer.postDelayed(this, REFRESH_MS)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        ShizukuHelper.init()
        bindViews()
        initAdvancedMenu()
        loadLogHistory()
        updateModeRadio()
    }

    override fun onResume() {
        super.onResume()
        AppLog.addListener(LISTENER) { renderLog(it) }
        refreshAll()
        timer.postDelayed(refreshTask, REFRESH_MS)
    }

    override fun onPause() {
        super.onPause()
        AppLog.removeListener(LISTENER)
        timer.removeCallbacks(refreshTask)
    }

    // ───────────────────────── 绑定 ─────────────────────────

    private fun bindViews() {
        // 点击地址复制
        b.tvLocal.setOnClickListener { copy(b.tvLocal.text.toString()) }
        b.tvLan.setOnClickListener { copy(b.tvLan.text.toString()) }

        b.btnRefresh.setOnClickListener {
            AppLog.i("手动刷新…")
            refreshAll()
        }

        b.btnClearLog.setOnClickListener {
            AppLog.clear()
            logBuilder.clear()
            b.tvLog.text = ""
        }

        // 折叠面板
        togglePanel(b.itemMode, b.panelMode, b.ivArrowMode)
        togglePanel(b.itemPort, b.panelPort, b.ivArrowPort)
        togglePanel(b.itemSystem, b.panelSystem, b.ivArrowSystem)
        togglePanel(b.itemTerminal, b.panelTerminal, b.ivArrowTerminal)

        // 工作模式
        b.rgMode.setOnCheckedChangeListener { _, id ->
            val mode = if (id == b.rbRoot.id) Prefs.MODE_ROOT else Prefs.MODE_SHIZUKU
            Prefs.setMode(this, mode)
            b.tvModeValue.text = if (mode == Prefs.MODE_ROOT) getString(R.string.mode_root) else getString(R.string.mode_shizuku)
            AppLog.i("工作模式切换为 ${b.tvModeValue.text}")
            refreshStatus()
        }

        b.btnGrantShizuku.setOnClickListener {
            ShizukuHelper.refreshGranted()
            if (ShizukuHelper.granted) {
                AppLog.ok("Shizuku 授权已获得")
            } else {
                ShizukuHelper.requestPermission()
            }
        }

        // 端口扫描
        b.btnScanPort.setOnClickListener { doScanPort() }

        // 系统设置
        b.btnSysSettings.setOnClickListener { AdbWifiController.openSystemSettings(this) }
        b.btnDevOptions.setOnClickListener { AdbWifiController.openDeveloperOptions(this) }
        b.btnToggleWadbMain.setOnClickListener { toggleWirelessAdb() }

        // 终端
        b.btnTerminal.setOnClickListener {
            startActivity(android.content.Intent(this, TerminalActivity::class.java))
        }

    }

    private fun initAdvancedMenu() {
        // 预留：后续可在此挂载更多高级项
        ShizukuHelper.addGrantedCallback { refreshStatus() }
    }

    private fun togglePanel(header: View, panel: View, arrow: View) {
        header.setOnClickListener {
            val show = panel.visibility != View.VISIBLE
            panel.visibility = if (show) View.VISIBLE else View.GONE
            arrow.rotation = if (show) 180f else 0f
        }
    }

    private fun updateModeRadio() {
        val mode = Prefs.getMode(this)
        if (mode == Prefs.MODE_SHIZUKU) b.rgMode.check(b.rbShizuku.id) else b.rgMode.check(b.rbRoot.id)
        b.tvModeValue.text = if (mode == Prefs.MODE_ROOT) getString(R.string.mode_root) else getString(R.string.mode_shizuku)
    }

    // ───────────────────────── 刷新 ─────────────────────────

    private fun refreshAll() {
        updateAddress()
        refreshStatus()
        updateWadbButton()
    }

    private fun updateAddress() {
        val port = if (currentPort > 0) currentPort else Prefs.getPort(this)
        val ip = NetworkUtils.preferredLanIp()

        if (port > 0) {
            b.tvLocal.text = "$LOCAL_HOST:$port"
            b.tvLan.text = if (ip != null) "$ip:$port" else getString(R.string.no_ip)
        } else {
            b.tvLocal.text = getString(R.string.addr_unknown)
            b.tvLan.text = getString(R.string.addr_unknown)
        }
        b.tvPortValue.text = if (port > 0) port.toString() else getString(R.string.port_unset)
    }

    /** 实时获取 ROOT / Shizuku 可用性 */
    private fun refreshStatus() {
        lifecycleScope.launch {
            val rootOk = withContext(Dispatchers.IO) { ExecutionEngine.isRootAvailable() }
            val shizukuOk = withContext(Dispatchers.IO) { ExecutionEngine.isShizukuAvailable() }
            b.tvModeStatus.text = getString(
                R.string.mode_status,
                getString(if (rootOk) R.string.avail else R.string.unavail),
                getString(if (shizukuOk) R.string.avail else R.string.unavail)
            )
        }
    }

    private fun updateWadbButton() {
        val on = AdbWifiController.isEnabled(this)

        // 顶部状态版块：文字颜色 + 圆点 + 按钮文案随状态切换
        if (on) {
            b.tvWadbStatus.text = getString(R.string.wadb_status_on)
            b.tvWadbStatus.setTextColor(ContextCompat.getColor(this, R.color.brand_teal))
            b.ivWadbDot.setImageResource(R.drawable.ic_dot_on)
            b.btnToggleWadbMain.text = getString(R.string.btn_disable)
        } else {
            b.tvWadbStatus.text = getString(R.string.wadb_status_off)
            b.tvWadbStatus.setTextColor(ContextCompat.getColor(this, R.color.bad))
            b.ivWadbDot.setImageResource(R.drawable.ic_dot_off)
            b.btnToggleWadbMain.text = getString(R.string.btn_enable)
        }
    }

    private fun doScanPort() {
        if (scanning) return
        scanning = true
        val old = b.btnScanPort.text
        b.btnScanPort.isEnabled = false
        b.btnScanPort.text = getString(R.string.scanning)
        AppLog.i("开始扫描本机 ADB 端口…")

        lifecycleScope.launch {
            val r = withContext(Dispatchers.IO) {
                AdbPortFinder.find(this@MainActivity) { done, total ->
                    if (done % 8000 == 0) AppLog.i("扫描进度 $done/$total")
                }
            }
            if (r.isFound) {
                currentPort = r.port
                Prefs.setPort(this@MainActivity, r.port)
            }
            updateAddress()
            scanning = false
            b.btnScanPort.isEnabled = true
            b.btnScanPort.text = old
        }
    }

    private fun toggleWirelessAdb() {
        val target = !AdbWifiController.isEnabled(this)
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                if (AdbWifiController.hasWriteSecure(this@MainActivity)) {
                    AdbWifiController.setEnabledDirect(this@MainActivity, target)
                } else {
                    val cmd = AdbWifiController.shellCommand(target)
                    val r = ExecutionEngine.exec(this@MainActivity, cmd)
                    if (r.combined.isNotBlank()) AppLog.i(r.combined)
                    r.err.isBlank()
                }
            }
            if (ok) {
                AppLog.ok(if (target) "无线调试已开启" else "无线调试已关闭")
            } else {
                AppLog.e(getString(R.string.need_write_secure, packageName))
            }
            updateWadbButton()
            refreshAll()
        }
    }

    private fun copy(text: String) {
        if (text.isBlank() || text == getString(R.string.addr_unknown)) {
            Toast.makeText(this, R.string.no_addr_copy, Toast.LENGTH_SHORT).show()
            return
        }
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("adbwifi", text))
        Toast.makeText(this, R.string.copied, Toast.LENGTH_SHORT).show()
    }

    // ───────────────────────── 日志 ─────────────────────────

    private fun loadLogHistory() {
        logBuilder.clear()
        AppLog.snapshot().forEach { renderLog(it) }
    }

    private fun renderLog(e: LogEntry) {
        val color = when (e.level) {
            Level.INFO -> ContextCompat.getColor(this, R.color.log_info)
            Level.OK -> ContextCompat.getColor(this, R.color.log_ok)
            Level.WARN -> ContextCompat.getColor(this, R.color.log_warn)
            Level.ERR -> ContextCompat.getColor(this, R.color.log_err)
        }
        val start = logBuilder.length
        logBuilder.append("${e.time}  ${e.text}\n")
        logBuilder.setSpan(ForegroundColorSpan(color), start, logBuilder.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        b.tvLog.text = logBuilder
        b.logScroll.post { b.logScroll.fullScroll(View.FOCUS_DOWN) }
    }

    companion object {
        private const val LOCAL_HOST = "127.0.0.1"
        private const val LISTENER = "main"
        private const val REFRESH_MS = 4000L
    }
}
