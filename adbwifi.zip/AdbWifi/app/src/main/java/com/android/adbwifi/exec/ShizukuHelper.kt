package com.android.adbwifi.exec

import android.content.pm.PackageManager
import com.android.adbwifi.util.AppLog
import rikka.shizuku.Shizuku

/**
 * Shizuku 接入助手 —— 与 MCP远程 同构：
 *   · Binder 生死监听 + 授权结果回调
 *   · 反射调用 Shizuku#newProcess（该方法是 private，且不同版本签名不同，故逐一尝试）
 */
object ShizukuHelper {

    const val REQ_CODE = 20240

    @Volatile
    var binderAlive = false
        private set

    @Volatile
    var granted = false
        private set

    private var inited = false
    private val grantedCallbacks = ArrayList<(Boolean) -> Unit>()

    fun init() {
        if (inited) return
        inited = true
        try {
            Shizuku.addBinderReceivedListenerSticky {
                binderAlive = true
                AppLog.ok("Shizuku：Binder 已连接")
                refreshGranted()
                ShizukuExecutor.invalidate()
                notify(granted)
            }
            Shizuku.addBinderDeadListener {
                binderAlive = false
                granted = false
                AppLog.w("Shizuku：Binder 已断开，请重新启动 Shizuku")
                ShizukuExecutor.invalidate()
                notify(false)
            }
            Shizuku.addRequestPermissionResultListener { _, result ->
                granted = result == PackageManager.PERMISSION_GRANTED
                if (granted) AppLog.ok("Shizuku：授权成功")
                else AppLog.e("Shizuku：授权被拒绝（code=$result）")
                ShizukuExecutor.invalidate()
                notify(granted)
            }
        } catch (t: Throwable) {
            AppLog.e("Shizuku：初始化失败 ${t.message}")
        }
        refreshGranted()
    }

    fun refreshGranted() {
        binderAlive = try {
            Shizuku.pingBinder()
        } catch (t: Throwable) {
            false
        }
        granted = if (binderAlive) {
            try {
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
            } catch (t: Throwable) {
                false
            }
        } else false
    }

    fun requestPermission() {
        if (!binderAlive) {
            AppLog.w("Shizuku：Binder 未连接，无法弹出授权框。请先启动 Shizuku 服务。")
            return
        }
        try {
            Shizuku.requestPermission(REQ_CODE)
            ShizukuExecutor.invalidate()
            AppLog.i("Shizuku：已向系统发起授权请求")
        } catch (t: Throwable) {
            AppLog.e("Shizuku：发起授权请求失败 ${t.message}")
        }
    }

    fun addGrantedCallback(cb: (Boolean) -> Unit) {
        grantedCallbacks.add(cb)
    }

    private fun notify(v: Boolean) {
        grantedCallbacks.forEach { runCatching { it(v) } }
    }

    /** 版本信息，用于日志 */
    fun versionString(): String = try {
        if (Shizuku.pingBinder()) "Shizuku 可用（版本 ${Shizuku.getVersion()}）" else "Shizuku 未运行"
    } catch (t: Throwable) {
        "Shizuku 未运行"
    }

    /**
     * 反射调用 private static ShizukuRemoteProcess newProcess(String[] cmd, String[] env, String dir)。
     * 不同 Shizuku 版本签名略有差异，逐一尝试。
     */
    fun newProcess(cmd: Array<String>): Process? {
        val signatures: List<Array<Class<*>>> = listOf(
            arrayOf(Array<String>::class.java, Array<String>::class.java, String::class.java),
            arrayOf(Array<String>::class.java, Array<String>::class.java),
            arrayOf(Array<String>::class.java)
        )
        for (sig in signatures) {
            try {
                val m = Shizuku::class.java.getDeclaredMethod("newProcess", *sig)
                m.isAccessible = true
                val args = when (sig.size) {
                    3 -> arrayOf<Any?>(cmd, null, null)
                    2 -> arrayOf<Any?>(cmd, null)
                    else -> arrayOf<Any?>(cmd)
                }
                val p = m.invoke(null, *args) as? Process
                if (p != null) return p
            } catch (_: Throwable) {
                // 换下一种签名
            }
        }
        AppLog.e("Shizuku newProcess 反射调用失败，已尝试全部已知签名")
        return null
    }
}
