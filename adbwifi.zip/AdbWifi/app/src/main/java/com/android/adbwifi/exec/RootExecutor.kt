package com.android.adbwifi.exec

import java.io.File

/** ROOT 通道：探测 su 并执行 su -c */
object RootExecutor : PrivilegeExecutor {

    override val name = "ROOT"

    /** su 是否存在基本不会变，缓存可以久一点 */
    private const val TTL_MS = 15_000L

    private val SU_CANDIDATES = arrayOf(
        "/sbin/su", "/su/bin/su", "/system/bin/su", "/system/xbin/su",
        "/data/local/su", "/data/local/bin/su", "/system/sd/xbin/su"
    )

    private var suPath: String? = null

    private val probe = AvailabilityProbe(TTL_MS) { detect() }

    /** 依次探测常见 su 路径，并兼容 PATH 中的 su */
    private fun detectSu(): String? {
        suPath?.let { if (File(it).exists()) return it }
        SU_CANDIDATES.firstOrNull { File(it).exists() }?.let { suPath = it; return it }
        System.getenv("PATH")?.split(File.pathSeparatorChar)
            ?.firstOrNull { File("$it/su").exists() }
            ?.let { suPath = "$it/su"; return suPath }
        return null
    }

    /** 真实探测：只返回结果与描述，不写日志（日志由 availabilityChanged 的调用方决定） */
    private fun detect(): Pair<Boolean, String> {
        val su = detectSu() ?: return false to "ROOT：未找到 su，拒绝"
        return try {
            val p = Runtime.getRuntime().exec(arrayOf(su, "-c", "id"))
            val (out, err) = ShellResult.readAll(p, 5)
            if (out.contains("uid=0")) true to "ROOT 允许（$su，uid=0）"
            else false to "ROOT 拒绝: ${out.ifBlank { err }}"
        } catch (t: Throwable) {
            false to "ROOT 探测异常: ${t.message}"
        }
    }

    override fun isAvailable(): Boolean = probe.check()

    override fun availability(): Pair<Boolean, String> = probe.checkDetail()

    override fun availabilityChanged(): Pair<Boolean, String>? = probe.changed()

    override fun invalidate() = probe.invalidate()

    override fun exec(cmd: String, timeoutSec: Int): ShellResult {
        val su = detectSu() ?: return ShellResult.fail("未找到 su", name)
        return try {
            val p = Runtime.getRuntime().exec(arrayOf(su, "-c", cmd))
            val (out, err) = ShellResult.readAll(p, timeoutSec)
            val code = try { p.exitValue() } catch (_: Throwable) { -1 }
            ShellResult(code, out, err, name)
        } catch (t: Throwable) {
            ShellResult.fail(t.message ?: "执行异常", name)
        }
    }

    override fun openSession(cwd: String?): ShellSession? {
        val su = detectSu() ?: return null
        return try {
            val p = Runtime.getRuntime().exec(arrayOf(su))
            ProcessSession(p)
        } catch (_: Throwable) {
            null
        }
    }

    private class ProcessSession(private val p: Process) : ShellSession {
        override val input get() = p.outputStream
        override val output get() = p.inputStream
        override val error get() = p.errorStream
        override fun destroy() { runCatching { p.destroy() } }
    }
}
