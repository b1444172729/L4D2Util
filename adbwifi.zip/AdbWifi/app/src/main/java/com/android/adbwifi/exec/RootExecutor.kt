package com.android.adbwifi.exec

import com.android.adbwifi.util.AppLog
import java.io.File

/** ROOT 通道：探测 su 并执行 su -c */
object RootExecutor : PrivilegeExecutor {

    override val name = "ROOT"

    private val SU_CANDIDATES = arrayOf(
        "/sbin/su", "/su/bin/su", "/system/bin/su", "/system/xbin/su",
        "/data/local/su", "/data/local/bin/su", "/system/sd/xbin/su"
    )

    private var suPath: String? = null

    /** 依次探测常见 su 路径，并兼容 PATH 中的 su */
    private fun detectSu(): String? {
        suPath?.let { if (File(it).exists()) return it }
        SU_CANDIDATES.firstOrNull { File(it).exists() }?.let { suPath = it; return it }
        System.getenv("PATH")?.split(File.pathSeparatorChar)
            ?.firstOrNull { File("$it/su").exists() }
            ?.let { suPath = "$it/su"; return suPath }
        return null
    }

    override fun isAvailable(): Boolean {
        val su = detectSu()
            ?: run { AppLog.w("ROOT：未找到 su，不可用"); return false }
        return try {
            val p = Runtime.getRuntime().exec(arrayOf(su, "-c", "id"))
            val (out, err) = ShellResult.readAll(p, 5)
            val ok = out.contains("uid=0")
            if (ok) AppLog.ok("ROOT 可用（$su，uid=0）")
            else AppLog.w("ROOT 不可用: ${out.ifBlank { err }}")
            ok
        } catch (t: Throwable) {
            AppLog.w("ROOT 探测异常: ${t.message}")
            false
        }
    }

    override fun exec(cmd: String, timeoutSec: Int): ShellResult {
        val su = detectSu() ?: return ShellResult.fail("未找到 su", name)
        return try {
            val p = Runtime.getRuntime().exec(arrayOf(su, "-c", cmd))
            val (out, err) = ShellResult.readAll(p, timeoutSec)
            val code = try { p.exitValue() } catch (_: Throwable) { -1 }
            ShellResult(code, out, err, name)
        } catch (t: Throwable) {
            AppLog.e("ROOT 执行失败: ${t.message}")
            ShellResult.fail(t.message ?: "执行异常", name)
        }
    }

    override fun openSession(): ShellSession? {
        val su = detectSu() ?: return null
        return try {
            val p = Runtime.getRuntime().exec(arrayOf(su))
            ProcessSession(p)
        } catch (t: Throwable) {
            AppLog.e("ROOT 会话创建失败: ${t.message}")
            null
        }
    }

    private class ProcessSession(private val p: Process) : ShellSession {
        override val input get() = p.outputStream
        override val output get() = p.inputStream
        override val error get() = p.errorStream
        override fun destroy() { runCatching { p.destroy() } }
    }
}
