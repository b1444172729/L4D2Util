package com.android.adbwifi.adb

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Build
import androidx.annotation.RequiresApi
import java.io.IOException
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket

/**
 * 通过 mDNS 发现无线调试端口。
 *
 * 直接移植自 RikkaApps/Shizuku —— manager/src/main/java/moe/shizuku/manager/adb/AdbMdns.kt
 * Android 11+ 的无线调试端口是随机的，adbd 会把 _adb-tls-connect._tcp 注册到 mDNS，
 * 因此这是「无 ROOT、无 Shizuku 也能拿到端口」的关键。
 *
 * 校验两点：
 *   1. 解析出的 host 必须是本机的某个网卡地址（排除发现到别人的设备）
 *   2. 该端口在本机确实处于监听状态（isPortInUse）
 */
private const val DEFAULT_SERVICE_TYPE = "_adb-tls-connect._tcp"

@RequiresApi(Build.VERSION_CODES.R)
class AdbMdns(
    context: Context,
    private val serviceType: String = DEFAULT_SERVICE_TYPE,
    private val onPort: (Int) -> Unit
) {
    private var registered = false
    private var running = false
    private var serviceName: String? = null
    private val listener = DiscoveryListener(this)
    private val nsdManager: NsdManager = context.getSystemService(NsdManager::class.java)

    fun start() {
        if (running) return
        running = true
        if (!registered) {
            runCatching { nsdManager.discoverServices(serviceType, NsdManager.PROTOCOL_DNS_SD, listener) }
        }
    }

    fun stop() {
        if (!running) return
        running = false
        if (registered) {
            runCatching { nsdManager.stopServiceDiscovery(listener) }
        }
    }

    private fun onDiscoveryStart() { registered = true }
    private fun onDiscoveryStop() { registered = false }

    private fun onServiceFound(info: NsdServiceInfo) {
        runCatching { nsdManager.resolveService(info, ResolveListener(this)) }
    }

    private fun onServiceLost(info: NsdServiceInfo) {
        if (info.serviceName == serviceName) onPort(-1)
    }

    private fun onServiceResolved(resolved: NsdServiceInfo) {
        val host = resolved.host?.hostAddress ?: return
        if (!running) return
        if (!isLocalAddress(host)) return
        if (!isPortInUse(resolved.port)) return
        serviceName = resolved.serviceName
        onPort(resolved.port)
    }

    /** 仅接受本机地址，避免发现到局域网里另一台开了无线调试的设备 */
    private fun isLocalAddress(host: String): Boolean = try {
        NetworkInterface.getNetworkInterfaces()
            .asSequence()
            .flatMap { it.inetAddresses.asSequence() }
            .any { it.hostAddress == host }
    } catch (t: Throwable) {
        false
    }

    /** 端口处于监听状态 => 本机无法再 bind 它 */
    private fun isPortInUse(port: Int): Boolean = try {
        ServerSocket().use { it.bind(InetSocketAddress("127.0.0.1", port), 1); false }
    } catch (e: IOException) {
        true
    }

    internal class DiscoveryListener(private val owner: AdbMdns) : NsdManager.DiscoveryListener {
        override fun onDiscoveryStarted(serviceType: String) = owner.onDiscoveryStart()
        override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {
            AppLogHolder.log.w("mDNS 启动失败: $serviceType code=$errorCode")
        }
        override fun onDiscoveryStopped(serviceType: String) = owner.onDiscoveryStop()
        override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {}
        override fun onServiceFound(info: NsdServiceInfo) = owner.onServiceFound(info)
        override fun onServiceLost(info: NsdServiceInfo) = owner.onServiceLost(info)
    }

    internal class ResolveListener(private val owner: AdbMdns) : NsdManager.ResolveListener {
        override fun onResolveFailed(info: NsdServiceInfo, code: Int) {
            AppLogHolder.log.w("mDNS 解析失败: ${info.serviceName} code=$code")
        }
        override fun onServiceResolved(info: NsdServiceInfo) = owner.onServiceResolved(info)
    }

    companion object {
        const val TLS_CONNECT = "_adb-tls-connect._tcp"
        const val TLS_PAIRING = "_adb-tls-pairing._tcp"
    }
}
