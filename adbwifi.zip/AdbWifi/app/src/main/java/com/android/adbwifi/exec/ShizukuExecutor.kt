package com.android.adbwifi.exec

import com.android.adbwifi.util.AppLog

/** Shizuku 通道：通过 Shizuku#newProcess 起进程 */
object ShizukuExecutor : PrivilegeExecutor {

    override val name = "Shizuku"

    override fun isAvailable(): Boolean {
        ShizukuHelper.refreshGranted()
        return when {
            !ShizukuHelper.binderAlive -> {
                AppLog.w("Shizuku 不可用：Binder 未连接（请确认 Shizuku 已启动）")
                false
            }
            !ShizukuHelper.granted -> {
                AppLog.w("Shizuku 不可用：已连接但未授权，请在弹出的对话框中允许")
                false
            }
            else -> {
                AppLog.ok(ShizukuHelper.versionString())
                true
            }
        }
    }

    override fun exec(cmd: String, timeoutSec: Int): ShellResult {
        if (!isAvailable()) return ShellResult.fail("Shizuku 不可用", name)
        val p = ShizukuHelper.newProcess(arrayOf("sh", "-c", cmd))
            ?: return ShellResult.fail("Shizuku 创建进程失败（newProcess 不可用）", name)
        return try {
            val (out, err) = ShellResult.readAll(p, timeoutSec)
            val code = try { p.exitValue() } catch (_: Throwable) { 0 }
            ShellResult(code, out, err, name)
        } catch (t: Throwable) {
            AppLog.e("Shizuku 执行失败: ${t.message}")
            ShellResult.fail(t.message ?: "执行异常", name)
        } finally {
            runCatching { p.destroy() }
        }
    }

    override fun openSession(): ShellSession? {
        if (!isAvailable()) return null
        val p = ShizukuHelper.newProcess(arrayOf("sh")) ?: return null
        return object : ShellSession {
            override val input get() = p.outputStream
            override val output get() = p.inputStream
            override val error get() = p.errorStream
            override fun destroy() { runCatching { p.destroy() } }
        }
    }
}
