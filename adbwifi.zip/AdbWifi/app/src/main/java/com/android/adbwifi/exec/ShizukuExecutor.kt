package com.android.adbwifi.exec

/** Shizuku 通道：通过 Shizuku#newProcess 起进程 */
object ShizukuExecutor : PrivilegeExecutor {

    override val name = "Shizuku"

    /** Shizuku 状态可能较快变化（启动服务、授权），缓存短一些 */
    private const val TTL_MS = 5_000L

    private val probe = AvailabilityProbe(TTL_MS) { detect() }

    /** 真实探测：只返回结果与描述，不写日志 */
    private fun detect(): Pair<Boolean, String> {
        ShizukuHelper.refreshGranted()
        return when {
            !ShizukuHelper.binderAlive ->
                false to "Shizuku 不可用：Binder 未连接（请确认 Shizuku 已启动）"
            !ShizukuHelper.granted ->
                false to "Shizuku 不可用：已连接但未授权，请在弹出的对话框中允许"
            else ->
                true to ShizukuHelper.versionString()
        }
    }

    override fun isAvailable(): Boolean = probe.check()

    override fun availability(): Pair<Boolean, String> = probe.checkDetail()

    override fun availabilityChanged(): Pair<Boolean, String>? = probe.changed()

    override fun invalidate() = probe.invalidate()

    override fun exec(cmd: String, timeoutSec: Int): ShellResult {
        if (!isAvailable()) return ShellResult.fail("Shizuku 不可用", name)
        val p = ShizukuHelper.newProcess(arrayOf("sh", "-c", cmd))
            ?: return ShellResult.fail("Shizuku 创建进程失败（newProcess 不可用）", name)
        return try {
            val (out, err) = ShellResult.readAll(p, timeoutSec)
            val code = try { p.exitValue() } catch (_: Throwable) { 0 }
            ShellResult(code, out, err, name)
        } catch (t: Throwable) {
            ShellResult.fail(t.message ?: "执行异常", name)
        } finally {
            runCatching { p.destroy() }
        }
    }

    override fun openSession(): ShellSession? {
        if (!isAvailable()) return null
        val p = ShizukuHelper.newProcess(arrayOf("sh")) ?: return null
        return object : ShellSession {
            override val input get() = p.outputStream
            override val output get() = p.inputStream
            override val error get() = p.errorStream
            override fun destroy() { runCatching { p.destroy() } }
        }
    }
}
