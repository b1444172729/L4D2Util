package com.android.adbwifi

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.android.adbwifi.databinding.ActivityTerminalBinding
import com.android.adbwifi.exec.ExecutionEngine
import com.android.adbwifi.exec.ExecutionEngine.Identity
import com.android.adbwifi.exec.RootExecutor
import com.android.adbwifi.exec.ShellSession
import com.android.adbwifi.exec.ShizukuHelper
import com.android.adbwifi.util.AdbBin
import com.android.adbwifi.util.AppLog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.InputStream

/**
 * 终端模拟器 —— 身份策略为「默认普通 + 手动选择」：
 *
 *   · 进入即创建普通应用身份的 /system/bin/sh，ls / cd / pwd 等基础命令
 *     无需任何授权即可使用；
 *   · **不再跟随工作模式自动切换身份**，也不在后台探测 ROOT / Shizuku；
 *   · 只有点击标题栏「选择身份」并明确选中某项后才切换。
 *
 * 选中 ROOT / Shizuku 时，走与「工作模式切换」完全一致的逻辑顺序与日志文案
 * （见 switchToRoot / switchToShizuku），结果同时写入运行日志与终端显示区。
 *
 * 注意：内置 adb 在两种身份下走不同的物理文件——
 *   普通身份执行 nativeLibraryDir 里的 libadb.so（apk_data_file，appdomain 放行）
 *   提权身份执行 /data/local/tmp 下的副本（shell_data_file）
 * 两份路径都会写进 PATH，由 shell 按可执行的那个来挑。
 */
class TerminalActivity : AppCompatActivity() {

    private lateinit var b: ActivityTerminalBinding
    private val ui = Handler(Looper.getMainLooper())
    private val screen = StringBuilder()

    /** 普通身份会话，全程保留，供切回使用 */
    private var appSession: ShellSession? = null
    /** 当前提权会话（若有），切走时销毁 */
    private var elevatedSession: ShellSession? = null

    private var current: ShellSession? = null
    private var identity: Identity = Identity.APP

    /** Shizuku 授权结果的一次性回调 */
    private var shizukuCallback: ((Boolean) -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityTerminalBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.btnRun.setOnClickListener { send() }
        b.btnSwitchIdentity.setOnClickListener { showIdentityMenu() }
        b.etCmd.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                send()
                true
            } else false
        }

        startSession()
    }

    private fun startSession() {
        appendText("无线调试 · 终端模拟器\n\n")

        lifecycleScope.launch {
            // 内置 adb（建符号链接，几乎瞬时）
            val adbReady = withContext(Dispatchers.IO) {
                AdbBin.install(this@TerminalActivity)
            }

            // 普通身份会话 —— 一定成功，基础命令立即可用
            // 不做任何后台提权探测：需要更高权限时由用户点「选择身份」
            val app = withContext(Dispatchers.IO) {
                runCatching { ExecutionEngine.openAppSession() }.getOrNull()
            }
            if (app == null) {
                appendText("[错误] 无法创建终端会话\n")
                return@launch
            }
            appSession = app
            attach(app, Identity.APP)

            if (adbReady) {
                write(AdbBin.envScript(this@TerminalActivity))
            } else {
                appendText("[内置 adb] 不可用（非 arm64 设备）\n")
            }
            appendText("[身份] 以普通身份运行，需要更高权限请点右上角「选择身份」\n")
            write("id\n")
        }
    }

    // ---------------------------------------------------------------- 身份菜单

    /** 屏幕中央弹出身份选择菜单，顺序：普通 / ROOT / Shizuku */
    private fun showIdentityMenu() {
        val items = arrayOf(
            getString(R.string.identity_app),
            getString(R.string.identity_root),
            getString(R.string.identity_shizuku)
        )
        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle(R.string.identity_choose)
            .setItems(items) { d, which ->
                d.dismiss()
                when (which) {
                    0 -> switchToApp()
                    1 -> switchToRoot()
                    2 -> switchToShizuku()
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun switchToApp() {
        if (identity == Identity.APP) {
            appendText("[身份] 当前已是普通身份\n")
            return
        }
        val app = appSession ?: run {
            appendText("[身份] 普通会话不可用\n")
            return
        }
        runCatching { elevatedSession?.destroy() }
        elevatedSession = null
        attach(app, Identity.APP)
        appendText("[身份] 已切换为普通\n")
        write("id\n")
    }

    /**
     * 切换到 ROOT —— 与「工作模式切换到 ROOT」的逻辑顺序一致：
     *   ① 两侧可用性缓存失效（确保真探测，不读 TTL 内的旧结果）
     *   ② RootExecutor.availability()（内部执行 su -c id 并检查 uid=0）
     *   ③ 成功 AppLog.ok / 失败 AppLog.w，文案与主界面完全一致
     *   ④ 成功后才建立会话
     */
    private fun switchToRoot() {
        appendText("[身份] 切换到 ROOT…\n")
        lifecycleScope.launch {
            ExecutionEngine.invalidateAll()
            val (ok, msg) = withContext(Dispatchers.IO) { RootExecutor.availability() }
            // 与工作模式切换同样的日志，同时写进运行日志与终端显示区
            if (ok) AppLog.ok(msg) else AppLog.w(msg)
            appendText("$msg\n")
            if (!ok) {
                appendText("[身份] 切换到 ROOT 失败\n")
                return@launch
            }
            val up = withContext(Dispatchers.IO) {
                ExecutionEngine.openElevatedSession(this@TerminalActivity, Identity.ROOT)
            }
            if (up == null) {
                val m = "ROOT 会话创建失败"
                AppLog.w(m)
                appendText("$m\n[身份] 切换到 ROOT 失败\n")
                return@launch
            }
            onElevatedReady(up)
        }
    }

    /**
     * 切换到 Shizuku —— 与「工作模式切换到 Shizuku」的逻辑顺序一致：
     *   ① 两侧可用性缓存失效
     *   ② refreshGranted() 刷新授权状态
     *   ③ 已授权 → AppLog.ok("Shizuku 授权已获得")
     *      未授权 → requestPermission() 发起授权 + 再次失效缓存，
     *               授权结果异步到达后自动继续
     *   ④ 授权到位后建立会话
     */
    private fun switchToShizuku() {
        appendText("[身份] 切换到 Shizuku…\n")
        lifecycleScope.launch {
            ExecutionEngine.invalidateAll()
            ShizukuHelper.refreshGranted()
            if (!ShizukuHelper.granted) {
                // 与主界面一致：发起授权请求，结果由 Shizuku 回调异步返回
                ShizukuHelper.requestPermission()
                ExecutionEngine.invalidateAll()
                appendText("[身份] 已向 Shizuku 发起授权请求，请在弹出框中允许…\n")
                waitForShizukuGrant()
                return@launch
            }
            val m = "Shizuku 授权已获得"
            AppLog.ok(m)
            appendText("$m\n")
            openShizukuSession()
        }
    }

    /** 等待用户在 Shizuku 弹出框中授权，结果到位后自动继续建立会话 */
    private fun waitForShizukuGrant() {
        val cb: (Boolean) -> Unit = { granted ->
            shizukuCallback?.let { ShizukuHelper.removeGrantedCallback(it) }
            shizukuCallback = null
            ui.post {
                if (granted) {
                    val m = "Shizuku 授权已获得"
                    AppLog.ok(m)
                    appendText("$m\n")
                    openShizukuSession()
                } else {
                    appendText("[身份] Shizuku 授权被拒绝\n")
                }
            }
        }
        shizukuCallback = cb
        ShizukuHelper.addGrantedCallback(cb)
    }

    private fun openShizukuSession() {
        lifecycleScope.launch {
            val up = withContext(Dispatchers.IO) {
                ExecutionEngine.openElevatedSession(this@TerminalActivity, Identity.SHIZUKU)
            }
            if (up == null) {
                val m = "Shizuku 会话创建失败（服务未运行或权限不足）"
                AppLog.w(m)
                appendText("$m\n[身份] 切换到 Shizuku 失败\n")
                return@launch
            }
            onElevatedReady(up)
        }
    }

    /** 提权会话就绪：确保 adb 有副本后接管输出 */
    private fun onElevatedReady(up: ExecutionEngine.TermSession) {
        lifecycleScope.launch {
            if (AdbBin.isInstalled(this@TerminalActivity)) {
                withContext(Dispatchers.IO) {
                    AdbBin.publishElevated(this@TerminalActivity)
                }
            }
            runCatching { elevatedSession?.destroy() }
            elevatedSession = up.session
            attach(up.session, up.identity)
            appendText("[身份] 已切换为 ${up.identity.label}\n")
            write("id\n")
        }
    }

    // ---------------------------------------------------------------- 会话与输出

    /** 切换会话：接管输出流并更新标题栏 */
    private fun attach(s: ShellSession, id: Identity) {
        current = s
        identity = id
        pump(s.output)
        pump(s.error)
        updateIdentityUi()
    }

    /**
     * 标题栏：「身份：」固定灰色；身份名（普通/ROOT/Shizuku）固定亮绿。
     * 颜色不再随身份变化，是否提权看文字即可。
     */
    private fun updateIdentityUi() {
        b.tvIdentityValue.text = when (identity) {
            Identity.APP -> getString(R.string.identity_app)
            Identity.ROOT -> getString(R.string.identity_root)
            Identity.SHIZUKU -> getString(R.string.identity_shizuku)
        }
    }

    /** 持续读取 shell 输出并追加到屏幕 */
    private fun pump(stream: InputStream) {
        Thread {
            val buf = ByteArray(8192)
            try {
                while (true) {
                    val n = stream.read(buf)
                    if (n <= 0) break
                    val text = String(buf, 0, n)
                    ui.post { appendText(text) }
                }
            } catch (_: Throwable) {
            }
            ui.post { appendText("\n[会话已结束]\n") }
        }.apply { isDaemon = true; start() }
    }

    private fun send() {
        val cmd = b.etCmd.text?.toString()?.trim().orEmpty()
        b.etCmd.setText("")
        if (cmd.isBlank()) return
        appendText(if (identity == Identity.ROOT) "# $cmd\n" else "\$ $cmd\n")
        write("$cmd\n")
    }

    private fun write(line: String) {
        val s = current ?: run { appendText("[错误] 会话未就绪\n"); return }
        try {
            s.input.write(line.toByteArray())
            s.input.flush()
        } catch (t: Throwable) {
            appendText("[错误] 写入失败: ${t.message}\n")
        }
    }

    private fun appendText(text: String) {
        screen.append(text)
        // 限制缓冲，避免长会话卡顿
        if (screen.length > 120_000) screen.delete(0, screen.length - 80_000)
        b.tvTerm.text = screen
        b.termScroll.post { b.termScroll.fullScroll(android.view.View.FOCUS_DOWN) }
    }

    override fun onDestroy() {
        super.onDestroy()
        shizukuCallback?.let { ShizukuHelper.removeGrantedCallback(it) }
        shizukuCallback = null
        runCatching { appSession?.destroy() }
        runCatching { elevatedSession?.destroy() }
    }
}
