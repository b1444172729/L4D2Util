package com.android.adbwifi

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.android.adbwifi.databinding.ActivityTerminalBinding
import com.android.adbwifi.exec.ExecutionEngine
import com.android.adbwifi.exec.ShellSession
import com.android.adbwifi.util.AdbBinary
import com.android.adbwifi.util.AppLog
import com.android.adbwifi.util.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.InputStream

/**
 * 终端模拟器 —— 参照 MT管理器 的终端实现：
 * 直接持有一个长驻的 shell 进程（ROOT 模式为 su，Shizuku 模式为 Shizuku 起的 sh，
 * 都没有则退回普通 sh），双向读写流，输出以等宽字体追加显示。
 *
 * 与 MT管理器 一致的几个细节：
 *   · 默认工作目录 /sdcard
 *   · 自建 bin 目录并前置 PATH，adb 等外部工具可直接调用
 *   · 启动时自动执行 id 确认提权身份
 */
class TerminalActivity : AppCompatActivity() {

    private lateinit var b: ActivityTerminalBinding
    private val ui = Handler(Looper.getMainLooper())
    private val screen = StringBuilder()
    private var session: ShellSession? = null
    private var adbPath: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityTerminalBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.btnRun.setOnClickListener { send() }
        b.etCmd.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                send()
                true
            } else false
        }

        startSession()
    }

    private fun startSession() {
        val mode = if (Prefs.getMode(this) == Prefs.MODE_ROOT) "ROOT" else "Shizuku"
        appendText("无线调试 · 终端模拟器\n")
        appendText("工作模式：$mode\n")
        appendText("工作目录：/sdcard\n\n")

        lifecycleScope.launch {
            // 1) 先准备 adb 二进制
            adbPath = withContext(Dispatchers.IO) { AdbBinary.ensure(this@TerminalActivity) }
            if (adbPath == null) {
                appendText("[提示] 未找到 adb，终端内无法执行 adb 命令\n")
                appendText("       把 adb 放到 /sdcard/adb 后重进本页即可自动安装\n\n")
            } else {
                appendText("[adb] $adbPath\n\n")
            }

            // 2) 建立 shell 会话
            val s = withContext(Dispatchers.IO) {
                try {
                    ExecutionEngine.openSession(this@TerminalActivity)
                } catch (t: Throwable) {
                    AppLog.e("终端会话创建失败: ${t.message}")
                    null
                }
            }
            if (s == null) {
                appendText("[错误] 无法创建终端会话\n")
                return@launch
            }
            session = s
            pump(s.output)
            pump(s.error)

            // 3) 初始化环境：PATH / HOME / cd /sdcard / alias adb
            AdbBinary.initCommands(this@TerminalActivity, adbPath).forEach { write(it) }
            write("id; pwd; echo '--- adb ---'; command -v adb || echo 'adb 不可用'\n")
            b.etCmd.requestFocus()
        }
    }

    /** 持续读取 shell 输出并追加到屏幕 */
    private fun pump(stream: InputStream) {
        Thread {
            val buf = ByteArray(8192)
            try {
                while (true) {
                    val n = stream.read(buf)
                    if (n <= 0) break
                    val text = String(buf, 0, n)
                    ui.post { appendText(text) }
                }
            } catch (_: Throwable) {
            }
            ui.post { appendText("\n[会话已结束]\n") }
        }.apply { isDaemon = true; start() }
    }

    private fun send() {
        val cmd = b.etCmd.text?.toString()?.trim().orEmpty()
        b.etCmd.setText("")
        if (cmd.isBlank()) return
        appendText("$ $cmd\n")
        write("$cmd\n")
    }

    private fun write(line: String) {
        val s = session ?: run { appendText("[错误] 会话未就绪\n"); return }
        try {
            s.input.write(line.toByteArray())
            s.input.flush()
        } catch (t: Throwable) {
            appendText("[错误] 写入失败: ${t.message}\n")
        }
    }

    private fun appendText(text: String) {
        screen.append(text)
        // 限制缓冲，避免长会话卡顿
        if (screen.length > 120_000) screen.delete(0, screen.length - 80_000)
        b.tvTerm.text = screen
        b.termScroll.post { b.termScroll.fullScroll(android.view.View.FOCUS_DOWN) }
    }

    override fun onDestroy() {
        super.onDestroy()
        runCatching { session?.destroy() }
    }
}
