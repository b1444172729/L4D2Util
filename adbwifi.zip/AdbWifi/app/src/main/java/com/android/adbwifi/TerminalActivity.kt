package com.android.adbwifi

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.android.adbwifi.databinding.ActivityTerminalBinding
import com.android.adbwifi.exec.ExecutionEngine
import com.android.adbwifi.exec.ShellSession
import com.android.adbwifi.util.AppLog
import com.android.adbwifi.util.Prefs
import com.android.adbwifi.util.TermEnv
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.InputStream

/**
 * 终端模拟器 —— 参照 MT管理器 的终端实现：
 * 直接持有一个长驻的 shell 进程（ROOT 模式为 su，Shizuku 模式为 Shizuku 起的 sh，
 * 都没有则退回普通 sh），双向读写流，输出以等宽字体追加显示。
 */
class TerminalActivity : AppCompatActivity() {

    private lateinit var b: ActivityTerminalBinding
    private val ui = Handler(Looper.getMainLooper())
    private val screen = StringBuilder()
    private var session: ShellSession? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityTerminalBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.btnRun.setOnClickListener { send() }
        b.etCmd.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                send()
                true
            } else false
        }

        startSession()
    }

    private fun startSession() {
        appendText("无线调试 · 终端模拟器\n")
        appendText("工作模式：${if (Prefs.getMode(this) == Prefs.MODE_ROOT) "ROOT" else "Shizuku"}\n\n")

        lifecycleScope.launch {
            // 第一步：确保 GNU 工具链就位（首次进入需要释放，约 1-3 秒）
            if (!TermEnv.isInstalled(this@TerminalActivity)) {
                appendText("[终端扩展] 首次使用，正在释放 GNU 工具链…\n")
                val ok = withContext(Dispatchers.IO) {
                    TermEnv.install(this@TerminalActivity) { p ->
                        ui.post { progressLine(p) }
                    }
                }
                if (ok) {
                    appendText("[终端扩展] 释放完成\n")
                } else {
                    appendText("[终端扩展] 释放失败，将使用系统自带命令\n")
                }
            } else {
                appendText("[终端扩展] ${TermEnv.banner(this@TerminalActivity)}\n")
            }
            appendText("\n")

            // 第二步：建立长驻 shell 会话
            val s = withContext(Dispatchers.IO) {
                try {
                    ExecutionEngine.openSession(this@TerminalActivity)
                } catch (t: Throwable) {
                    AppLog.e("终端会话创建失败: ${t.message}")
                    null
                }
            }
            if (s == null) {
                appendText("[错误] 无法创建终端会话\n")
                return@launch
            }
            session = s
            pump(s.output)
            pump(s.error)

            // 第三步：注入工具链环境（PATH / 库路径 / HOME / TMPDIR）
            if (TermEnv.isInstalled(this@TerminalActivity)) {
                write(TermEnv.envScript(this@TerminalActivity))
                // 自检：确认 GNU 版本真的被命中（而不是系统的 toybox）
                write("echo \"[GNU] \$(ls --version 2>/dev/null | head -1 || echo '未生效，回退系统命令')\"\n")
            }
            // 输出当前身份，便于确认提权是否生效
            write("id\n")
        }
    }

    /** 释放进度：用回车覆盖同一行，不刷屏 */
    private fun progressLine(p: Int) {
        screen.append("\r[终端扩展] 释放中… $p%")
        b.tvTerm.text = screen
        b.termScroll.post { b.termScroll.fullScroll(android.view.View.FOCUS_DOWN) }
    }

    /** 持续读取 shell 输出并追加到屏幕 */
    private fun pump(stream: InputStream) {
        Thread {
            val buf = ByteArray(8192)
            try {
                while (true) {
                    val n = stream.read(buf)
                    if (n <= 0) break
                    val text = String(buf, 0, n)
                    ui.post { appendText(text) }
                }
            } catch (_: Throwable) {
            }
            ui.post { appendText("\n[会话已结束]\n") }
        }.apply { isDaemon = true; start() }
    }

    private fun send() {
        val cmd = b.etCmd.text?.toString()?.trim().orEmpty()
        b.etCmd.setText("")
        if (cmd.isBlank()) return
        appendText("$ $cmd\n")
        write("$cmd\n")
    }

    private fun write(line: String) {
        val s = session ?: run { appendText("[错误] 会话未就绪\n"); return }
        try {
            s.input.write(line.toByteArray())
            s.input.flush()
        } catch (t: Throwable) {
            appendText("[错误] 写入失败: ${t.message}\n")
        }
    }

    private fun appendText(text: String) {
        screen.append(text)
        // 限制缓冲，避免长会话卡顿
        if (screen.length > 120_000) screen.delete(0, screen.length - 80_000)
        b.tvTerm.text = screen
        b.termScroll.post { b.termScroll.fullScroll(android.view.View.FOCUS_DOWN) }
    }

    override fun onDestroy() {
        super.onDestroy()
        runCatching { session?.destroy() }
    }
}
