package com.android.adbwifi

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextWatcher
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.android.adbwifi.databinding.ActivityTerminalBinding
import com.android.adbwifi.exec.ExecutionEngine
import com.android.adbwifi.exec.ExecutionEngine.Identity
import com.android.adbwifi.exec.RootExecutor
import com.android.adbwifi.exec.ShellSession
import com.android.adbwifi.exec.ShizukuHelper
import com.android.adbwifi.util.AdbBin
import com.android.adbwifi.util.AppLog
import com.android.adbwifi.util.Prefs
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.InputStream

/**
 * 终端模拟器 —— 交互方式对齐 MT 管理器：
 *
 *   · 无底部输入栏：点击输出区任意位置即可输入，回车提交
 *   · 提示符自行渲染：`# 目录名`（root）或 `➜ 目录名`（非 root），
 *     ➜/# 随上条命令退出码变色（成功绿 / 失败红），目录名固定青色
 *   · 自绘灰色方块光标
 *   · stdout 白色、stderr 红色
 *
 * 提示符由 Java 层拼装而非 bash PS1：我们用系统 mksh 且是往长驻 shell 写命令
 * （非交互模式），shell 不会自己打印提示符。做法是每条命令后追加一条探针，
 * 用 magic marker 回传退出码与当前目录，解析后渲染，marker 不显示。
 *
 * 注意：内置 adb 在两种身份下走不同的物理文件——
 *   普通身份执行 nativeLibraryDir 里的 libadb.so（apk_data_file，appdomain 放行）
 *   提权身份执行 /data/local/tmp 下的副本（shell_data_file）
 * 两份路径都会写进 PATH，由 shell 按可执行的那个来挑。
 */
class TerminalActivity : AppCompatActivity() {

    private lateinit var b: ActivityTerminalBinding
    private val ui = Handler(Looper.getMainLooper())

    /**
     * 已完成输出，存成「文本 + 颜色」片段而非累积的 SpannableStringBuilder。
     *
     * 之前每次 render() 都执行 SpannableStringBuilder(screen) 复制构造，
     * 嵌套层数随刷新次数增长，Android 的 countSpans 是递归实现，
     * 层数一深就 StackOverflowError（真机 crash.txt 已复现）。
     * 改成片段列表后，每次都从空的 builder 逐个 append 纯文本，不存在嵌套。
     */
    private val pieces = ArrayList<Piece>()
    private data class Piece(val text: String, val colorId: Int?)

    /** render() 重入保护：setText 会触发监听回调，回调里又调 render() */
    private var rendering = false

    /** 普通身份会话，全程保留，供切回使用 */
    private var appSession: ShellSession? = null
    private var elevatedSession: ShellSession? = null
    private var current: ShellSession? = null
    private var identity: Identity = Identity.APP

    // ---- 提示符状态 ----
    private var isRoot = false
    private var lastExitOk = true
    private var curDir = Prefs.DEFAULT_TERM_CWD
    /** 可能是不完整的 marker 片段，等下一块数据补全 */
    private var tail = ""

    private var shizukuCallback: ((Boolean) -> Unit)? = null

    // ---- 输出区触摸：长按选择（系统原生）/ 点击选区复制 / 点击空白聚焦输入 ----
    private var downX = 0f
    private var downY = 0f
    private var downMoved = false

    /**
     * 协程异常处理：lifecycleScope 默认不装 handler，协程里抛出未捕获异常会
     * 直接传播到线程未捕获处理器导致进程崩溃——表现为「进终端几秒后自动返回
     * 主页」。这里统一兜底，任何异常只写日志与屏幕，不让进程死掉。
     */
    private val errHandler = CoroutineExceptionHandler { _, e ->
        AppLog.e("终端异常: ${e.message}")
        runCatching { appendOut("[错误] ${e.javaClass.simpleName}: ${e.message}\n", true) }
    }

    /** 代替 lifecycleScope.launch：带异常处理，且整块包 try/catch */
    private fun safeLaunch(block: suspend () -> Unit) =
        lifecycleScope.launch(errHandler) {
            runCatching { block() }.onFailure {
                AppLog.e("终端异常: ${it.message}")
                runCatching { appendOut("[错误] ${it.javaClass.simpleName}: ${it.message}\n", true) }
            }
        }

    /**
     * 真实路径 → 短别名。
     * /sdcard 是 /storage/emulated/0 的符号链接，shell 报回的永远是真实路径。
     * 顺序按长度从长到短，避免短前缀先被替换掉。
     */
    private val PATH_ALIASES = listOf(
        "/storage/emulated/0" to "/sdcard",
        "/storage/self/primary" to "/sdcard",
        "/mnt/sdcard" to "/sdcard"
    )

    /** 探针回传格式：__ADBW:退出码:当前目录__ */
    private val MARKER = Regex("""__ADBW:(-?\d+):(.*?)__""")
    private val MARKER_HEAD = "__ADBW:"
    private val PROBE = "printf '__ADBW:%s:%s__\\n' \"\$?\" \"\$(pwd)\"\n"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityTerminalBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.btnSwitchIdentity.setOnClickListener { showIdentityMenu() }
        b.btnTermSettings.setOnClickListener { showSettingsMenu() }
        applyFontSize(Prefs.getTermSize(this))

        setupInput()
        watchKeyboard()

        startSession()
    }

    // ---------------------------------------------------------------- 键盘避让

    /**
     * 监听软键盘弹出/收起，把输出区滚到底，保证光标行不被键盘遮住。
     *
     * Manifest 已声明 adjustResize，键盘弹出时窗口可用高度会变小；但
     * ScrollView 的滚动位置不会自动跟着变，内容一多（铺满整屏）时，
     * 处在末尾的光标行就会被键盘盖住。
     * 这里在可视高度变化时主动滚到底，与 MT 管理器终端的行为一致。
     *
     * 用 getWindowVisibleDisplayFrame 的差值判断，兼容性好
     * （WindowInsets.Type.ime() 需要 API 30+）。
     */
    private var lastVisibleBottom = 0

    private fun watchKeyboard() {
        val root = findViewById<android.view.View>(android.R.id.content) ?: return
        root.viewTreeObserver.addOnGlobalLayoutListener {
            val r = android.graphics.Rect()
            root.getWindowVisibleDisplayFrame(r)
            if (lastVisibleBottom == 0) {
                lastVisibleBottom = r.bottom
                return@addOnGlobalLayoutListener
            }
            if (kotlin.math.abs(r.bottom - lastVisibleBottom) > 40) {
                lastVisibleBottom = r.bottom
                scrollToCursor()
            }
        }
    }

    /**
     * 滚到光标（内容末尾）处。
     *
     * 多次重试：键盘弹出是异步的，且各 ROM 上 resize / 重排的时序不同，
     * 单次 post 常拿到的是键盘未弹出时的旧高度，导致滚不到位。
     */
    private fun scrollToCursor() {
        b.termScroll.post { scrollEnd() }
        b.termScroll.postDelayed({ scrollEnd() }, 120)
        b.termScroll.postDelayed({ scrollEnd() }, 320)
        b.termScroll.postDelayed({ scrollEnd() }, 600)
    }

    /**
     * 关键：按「屏幕上真正可见的高度」计算，而不是 ScrollView 的 height。
     *
     * 之前用 tvTerm.height - termScroll.height，只在 adjustResize 真正生效、
     * ScrollView 被压缩时才对。一旦 resize 未生效（部分 ROM / 输入法组合下
     * 键盘直接盖在窗口上），termScroll.height 仍是全屏高度，算出来的滚动量
     * 偏小，末尾的光标行就落在键盘底下看不见——正是截图里的现象。
     *
     * 这里用 getWindowVisibleDisplayFrame 算出 ScrollView 在屏幕上没被键盘
     * 遮住的那部分高度，两种情况下都能把光标行顶到键盘上方。
     */
    private fun scrollEnd() {
        runCatching {
            val sv = b.termScroll
            val tv = b.tvTerm
            val r = android.graphics.Rect()
            sv.getWindowVisibleDisplayFrame(r)
            val loc = IntArray(2)
            sv.getLocationOnScreen(loc)
            // ScrollView 未被键盘遮住的可见高度
            val visible = (r.bottom - loc[1]).coerceIn(0, sv.height)
            val maxY = maxOf(0, tv.height - visible + sv.paddingTop + sv.paddingBottom)
            // 用 scrollTo 而非 fullScroll：后者会请求焦点，把 etInput 的焦点抢走
            sv.scrollTo(0, maxY)
        }
    }

    // ---------------------------------------------------------------- 输入

    private fun setupInput() {
        b.etInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                submit(b.etInput.text?.toString().orEmpty())
                true
            } else false
        }
        b.etInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) = Unit
            override fun onTextChanged(s: CharSequence?, st: Int, be: Int, c: Int) = Unit
            override fun afterTextChanged(s: android.text.Editable?) = render()
        })

        // 由「真正拿到焦点」来驱动弹键盘，而不是在点击回调里直接弹。
        // 原因：tvTerm 因 textIsSelectable=true 而可聚焦，第一次点击时框架先把
        // 焦点给了 tvTerm；此时立刻调 showSoftInput，IMM 仍认为焦点在不可编辑的
        // tvTerm 上，调用被静默忽略 —— 表现就是要点两次。
        // 改成等焦点确实落到 etInput 后再弹，并补一次延迟重试兜底。
        b.etInput.setOnFocusChangeListener { _, has ->
            if (has) {
                b.etInput.post { showIme() }
                b.etInput.postDelayed({ showIme() }, 150)
            }
        }
        // 进入时不自动弹键盘；点击输出区才聚焦并弹出

        // 复制方式对齐 MT 管理器：
        //   · 长按 → 系统原生选择（带蓝色手柄，可拖动调整选区）
        //   · 点击选中的文本 → 直接复制
        //   · 点击空白处 → 聚焦输入并弹键盘
        //
        // 因此这里**不再拦截 ACTION_DOWN**：一旦消费 DOWN，框架的 Editor 就收不到
        // 事件，选择手柄与拖选全部失效（上一版正是这样丢掉手柄的）。
        // 只在 DOWN 时记下坐标，供点击命中判断使用，事件照常交还框架。
        b.tvTerm.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    downX = ev.x
                    downY = ev.y
                    downMoved = false
                    return@setOnTouchListener false // 不消费：长按/拖手柄/滚动交给系统
                }
                android.view.MotionEvent.ACTION_MOVE -> {
                    if (kotlin.math.abs(ev.x - downX) > 12 || kotlin.math.abs(ev.y - downY) > 12) {
                        downMoved = true
                    }
                    return@setOnTouchListener false
                }
                android.view.MotionEvent.ACTION_UP -> {
                    if (downMoved) return@setOnTouchListener false // 滑动/拖手柄，不干预

                    // 已有选区（长按刚起来、或正在拖手柄）→ 完全不干预。
                    // 一旦在这里 clearFocus / removeSelection，手柄和工具栏会立刻消失，
                    // 正是"长按直接复制、没有手柄"的原因。
                    val t = b.tvTerm.text
                    val s = android.text.Selection.getSelectionStart(t)
                    val e = android.text.Selection.getSelectionEnd(t)
                    if (s >= 0 && e > s) return@setOnTouchListener false

                    // 无选区：在这里直接聚焦 + 弹键盘，而不是留给 onClick。
                    // tvTerm 因 textIsSelectable=true 可在触摸模式获焦，第一次点击时
                    // Editor 常在 onTouchEvent 里把事件吃掉（准备起选区/光标），
                    // 于是 performClick 不触发 → onClick 不执行 → 要点第二次。
                    // OnTouchListener 先于 onTouchEvent，这里直接处理即可一次生效。
                    focusInputAndIme()
                    return@setOnTouchListener true
                }
            }
            false
        }

        b.tvTerm.setOnClickListener {
            // 走到这里说明无选区 → 聚焦输入、弹键盘
            focusInputAndIme()
        }

        // 不再设置 setCustomSelectionActionModeCallback：
        // 之前为屏蔽顶部工具栏而返回 false，连带把选择手柄也一起干掉了。
        // 现在交回系统默认的 ActionMode，长按即可出现蓝色手柄 + 上方工具栏。
        b.termScroll.setOnClickListener { focusInputAndIme() }
    }

    /** 聚焦输入框并弹出键盘（显式调用，不依赖焦点变化回调） */
    private fun focusInputAndIme() {
        clearTermSelection()
        focusInput()
        // 必须显式弹键盘：etInput 往往已持有焦点，requestFocus() 不产生
        // 焦点变化 → OnFocusChangeListener 不触发 → 键盘不弹（表现为要点两次）
        b.etInput.post { showIme() }
        b.etInput.postDelayed({ showIme() }, 120)
        b.etInput.postDelayed({ showIme() }, 320)
        // 键盘弹出后补一次滚动，确保光标行露在键盘上方
        scrollToCursor()
    }

    /** 清掉输出区可能存在的选区与选中高亮 */
    private fun clearTermSelection() {
        runCatching {
            val t = b.tvTerm.text
            if (t is android.text.Spannable) android.text.Selection.removeSelection(t)
        }
        runCatching { b.tvTerm.clearFocus() }
    }

    /** 弹出输入法；重复调用是安全的（已显示时无副作用） */
    private fun showIme() {
        runCatching {
            if (!b.etInput.isFocused) b.etInput.requestFocus()
            val imm = getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager
            imm?.showSoftInput(b.etInput, InputMethodManager.SHOW_IMPLICIT)
        }.onFailure { AppLog.w("弹出输入法失败: ${it.message}") }
    }

    private fun focusInput() {
        // textIsSelectable=true 会让 tvTerm 变成可聚焦，点击时它可能与 etInput
        // 抢焦点——一旦焦点留在 tvTerm 上，输入法就没有可编辑目标，表现为"打不进字"。
        // 因此这里先让 tvTerm 放弃焦点，再 post 一次给 etInput 抢回来
        // （post 是为了排在 tvTerm 自身的触摸处理之后，确保最后生效）。
        clearTermSelection()
        runCatching { b.etInput.requestFocus() }
        b.etInput.post {
            clearTermSelection()
            runCatching { b.etInput.requestFocus() }
        }
        runCatching { render() }
            .onFailure { AppLog.w("终端渲染失败: ${it.message}") }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        // 窗口刚拿到焦点时 IMM 可能还没完成绑定，补一次弹起
        if (hasFocus && b.etInput.isFocused) {
            b.etInput.postDelayed({ showIme() }, 120)
        }
    }

    private fun submit(raw: String) {
        val cmd = raw.trim()
        // 回显：完整提示符（符号 + 目录名）+ 命令
        // 必须与 render() 用同一套片段，否则回显行会缺目录名
        for (p in promptPieces()) addPiece(p.text, p.colorId)
        addPiece(" ${replacePathAliases(cmd)}\n", null)
        b.etInput.setText("")
        render()
        if (cmd.isBlank()) {
            // 空回车也要刷新提示符（退出码不变）
            write(PROBE)
            return
        }
        write("$cmd\n")
        write(PROBE)
    }

    // ---------------------------------------------------------------- 会话

    private fun startSession() {
        safeLaunch {
            val adbReady = withContext(Dispatchers.IO) {
                AdbBin.install(this@TerminalActivity)
            }
            val cwd = Prefs.getTermCwd(this@TerminalActivity)
            // 先按设置目录建；失败（目录不存在/无权进入）则回退到默认目录再建一次
            var app = withContext(Dispatchers.IO) {
                runCatching { ExecutionEngine.openAppSession(cwd) }.getOrNull()
            }
            if (app == null) {
                AppLog.w("以 $cwd 建会话失败，回退默认目录")
                appendOut("[提示] 工作目录 $cwd 不可用，回退默认目录\n", false)
                app = withContext(Dispatchers.IO) {
                    runCatching { ExecutionEngine.openAppSession(null) }.getOrNull()
                }
            }
            if (app == null) {
                AppLog.e("无法创建终端会话")
                appendOut("[错误] 无法创建终端会话\n", true)
                return@safeLaunch
            }
            appSession = app
            attach(app, Identity.APP)

            if (adbReady) {
                write(AdbBin.envScript(this@TerminalActivity))
            } else {
                appendOut("[内置 adb] 不可用（非 arm64 设备）\n", false)
            }
            // 拿初始目录 + 判断身份
            write("id\n")
            write(PROBE)
        }
    }

    /** 切换会话：接管输出流并更新标题栏 */
    private fun attach(s: ShellSession, id: Identity) {
        current = s
        identity = id
        pump(s.output, false)
        pump(s.error, true)
        updateIdentityUi()
    }

    private fun pump(stream: InputStream, isErr: Boolean) {
        Thread {
            val buf = ByteArray(8192)
            try {
                while (true) {
                    val n = stream.read(buf)
                    if (n <= 0) break
                    val text = String(buf, 0, n)
                    if (isErr) {
                        // stderr 里的路径同样替换（如 cp: /storage/...: Permission denied）
                        val shown = replacePathAliases(text)
                        ui.post { runCatching { appendOut(shown, true) } }
                    } else {
                        // 先剥探针（要拿到真实路径），再把真实路径换成短别名显示
                        val clean = replacePathAliases(sanitize(text))
                        ui.post {
                            runCatching {
                                if (clean.isNotEmpty()) appendOut(clean, false)
                                else render()
                            }
                        }
                    }
                }
            } catch (t: Throwable) {
                AppLog.w("输出读取中断: ${t.message}")
            }
            AppLog.w("终端会话已结束（shell 进程退出）")
            ui.post { runCatching { appendOut("\n[会话已结束]\n", true) } }
        }.apply { isDaemon = true; start() }
    }

    /**
     * 剥离探针 marker，并用它更新提示符状态。
     * 未闭合的 marker 片段留在 tail，等下一块数据补全后再处理。
     */
    private fun sanitize(chunk: String): String {
        val s = tail + chunk
        tail = ""
        val idx = s.lastIndexOf(MARKER_HEAD)
        if (idx < 0) return s
        val head = s.substring(0, idx)
        val cand = s.substring(idx)
        val m = MARKER.find(cand)
        if (m != null) {
            lastExitOk = m.groupValues[1] == "0"
            val d = m.groupValues[2].trim()
            // 只接受绝对路径，避免把退出码等误当成目录名
            if (d.startsWith("/")) curDir = d
            return head + cand.removeRange(m.range)
        }
        // 还没收全，先攒着
        tail = cand
        return head
    }

    // ---------------------------------------------------------------- 渲染

    /** 追加一段已完成输出；isErr 时整段红色，否则用默认白色 */
    private fun appendOut(text: String, isErr: Boolean) {
        if (text.isEmpty()) return
        // 顺便判断是否为 root（id 输出里的 uid=0）
        if (text.contains("uid=0")) isRoot = true
        addPiece(text, if (isErr) com.android.adbwifi.R.color.log_err else null)
        render()
    }

    /** 记录一段输出，并控制总量 */
    private fun addPiece(text: String, colorId: Int?) {
        pieces.add(Piece(text, colorId))
        trimPieces()
    }

    private fun buildPromptSym() = if (isRoot) "#" else "\u279C"

    private fun promptColorId() =
        if (lastExitOk) com.android.adbwifi.R.color.log_ok else com.android.adbwifi.R.color.log_err

    /**
     * 提示符片段：符号（绿/红）+ " " + 目录名（青）+ " "。
     *
     * render()（打字中的实时提示符）与 submit()（回车后的命令回显）必须共用
     * 这一份定义——之前两处各写一套，回显那套漏了目录名，导致回车后变成
     * "➜ ls" 而目录名消失。
     */
    private fun promptPieces(): List<Piece> = listOf(
        Piece(buildPromptSym(), promptColorId()),
        Piece(" ", null),
        Piece(dirName(), com.android.adbwifi.R.color.term_cyan),
        Piece(" ", null)
    )

    /**
     * 渲染：已完成输出 + 提示符 + 正在输入的内容 + 灰色方块光标。
     *
     * 关键点：
     *  · 从**空的** builder 开始，逐个 append 纯文本 —— 不做复制构造，不嵌套
     *  · append 的是 String 而不是 etInput 的 Editable，避免把带 ChangeWatcher
     *    的对象牵进来形成 "setText → 回调 → render" 的死循环
     *  · rendering 重入保护，双保险
     */
    private fun render() {
        if (rendering) return
        rendering = true
        try {
            val sb = SpannableStringBuilder()
            for (p in pieces) {
                val st = sb.length
                sb.append(p.text)
                val c = p.colorId
                if (c != null) {
                    sb.setSpan(
                        ForegroundColorSpan(color(c)),
                        st, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                    )
                }
            }
            // 提示符：符号（绿/红）+ 空格 + 目录名（青）+ 空格
            for (p in promptPieces()) {
                val st = sb.length
                sb.append(p.text)
                val c = p.colorId
                if (c != null) {
                    sb.setSpan(
                        ForegroundColorSpan(color(c)),
                        st, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                    )
                }
            }
            // 正在输入的内容（用 String，不放 Editable）
            sb.append(b.etInput.text?.toString().orEmpty())
            // 光标：灰色方块（在末尾一个空格上打背景色）
            val cs = sb.length
            sb.append(" ")
            sb.setSpan(
                BackgroundColorSpan(color(com.android.adbwifi.R.color.text_secondary)),
                cs, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            b.tvTerm.setText(sb, android.widget.TextView.BufferType.SPANNABLE)
            // 滚到末尾，保证光标行可见（用 scrollTo 而非 fullScroll，避免抢焦点）
            scrollToCursor()
        } finally {
            rendering = false
        }
    }

    /** 控制已完成输出的总字符数，避免长时间会话后卡顿 */
    private fun trimPieces() {
        var total = 0
        for (p in pieces) total += p.text.length
        if (total <= 80_000) return
        var drop = 0
        while (drop < pieces.size && total > 60_000) {
            total -= pieces[drop].text.length
            drop++
        }
        if (drop > 0) pieces.subList(0, drop).clear()
    }

    /**
     * 把 shell 报回的真实路径换回更直观的等价写法。
     *
     * /sdcard 是 /storage/emulated/0 的符号链接，pwd 会解析成后者，
     * 直接取 basename 就剩一个 "0"，既不美观也不好认。
     * 这里把常见等价路径映射回短别名，显示成 sdcard。
     */
    private fun normalizePath(p: String): String = replacePathAliases(p)

    /**
     * 输出层统一替换真实路径为短别名。
     *
     * 之所以在显示层做而不是逐个命令处理：pwd 是 shell 内建命令、
     * cd 本身不输出、cp/mv 只在出错时带路径，逐个改既改不动也改不全；
     * 而所有命令的路径最终都会出现在 stdout/stderr 文本里，
     * 在这一层替换即可覆盖全部命令，且与 MT 管理器的观感一致。
     *
     * 只影响显示，不改动实际执行（写入 shell 的命令原样传递），
     * 所以 cd /storage/emulated/0 与 cd /sdcard 都照常工作。
     */
    private fun replacePathAliases(text: String): String {
        if (!text.contains("/storage") && !text.contains("/mnt/")) return text
        var r = text
        for ((real, alias) in PATH_ALIASES) {
            r = r.replace("$real/", "$alias/")
            // 路径出现在行尾或被引号/空格包住时，后面没有斜杠
            r = r.replace(real, alias)
        }
        return r
    }

    /** 只显示目录名，与 bash PS1 的 \W 一致 */
    private fun dirName(): String {
        val p = normalizePath(curDir).trimEnd('/')
        if (p.isEmpty()) return "/"
        val i = p.lastIndexOf('/')
        return if (i < 0) p else p.substring(i + 1).ifEmpty { "/" }
    }

    private fun color(id: Int) = ContextCompat.getColor(this, id)

    private fun updateIdentityUi() {
        b.tvIdentityValue.text = when (identity) {
            Identity.APP -> getString(R.string.identity_app)
            Identity.ROOT -> getString(R.string.identity_root)
            Identity.SHIZUKU -> getString(R.string.identity_shizuku)
        }
    }

    private fun write(line: String) {
        val s = current ?: run { appendOut("[错误] 会话未就绪\n", true); return }
        try {
            s.input.write(line.toByteArray())
            s.input.flush()
        } catch (t: Throwable) {
            appendOut("[错误] 写入失败: ${t.message}\n", true)
        }
    }

    private fun applyFontSize(sp: Int) {
        b.tvTerm.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, sp.toFloat())
    }

    // ---------------------------------------------------------------- 身份菜单

    private fun showIdentityMenu() {
        val items = arrayOf(
            getString(R.string.identity_app),
            getString(R.string.identity_root),
            getString(R.string.identity_shizuku)
        )
        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle(R.string.identity_choose)
            .setItems(items) { d, which ->
                d.dismiss()
                when (which) {
                    0 -> switchToApp()
                    1 -> switchToRoot()
                    2 -> switchToShizuku()
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun switchToApp() {
        if (identity == Identity.APP) {
            appendOut("[身份] 当前已是普通身份\n", false)
            return
        }
        val app = appSession ?: run {
            appendOut("[身份] 普通会话不可用\n", true)
            return
        }
        runCatching { elevatedSession?.destroy() }
        elevatedSession = null
        isRoot = false
        attach(app, Identity.APP)
        appendOut("[身份] 已切换为普通\n", false)
        write(PROBE)
    }

    private fun switchToRoot() {
        appendOut("[身份] 切换到 ROOT…\n", false)
        safeLaunch {
            ExecutionEngine.invalidateAll()
            val (ok, msg) = withContext(Dispatchers.IO) { RootExecutor.availability() }
            if (ok) AppLog.ok(msg) else AppLog.w(msg)
            appendOut("$msg\n", !ok)
            if (!ok) {
                appendOut("[身份] 切换到 ROOT 失败\n", true)
                return@safeLaunch
            }
            val up = withContext(Dispatchers.IO) {
                ExecutionEngine.openElevatedSession(this@TerminalActivity, Identity.ROOT)
            }
            if (up == null) {
                val m = "ROOT 会话创建失败"
                AppLog.w(m)
                appendOut("$m\n[身份] 切换到 ROOT 失败\n", true)
                return@safeLaunch
            }
            onElevatedReady(up, true)
        }
    }

    private fun switchToShizuku() {
        appendOut("[身份] 切换到 Shizuku…\n", false)
        safeLaunch {
            ExecutionEngine.invalidateAll()
            ShizukuHelper.refreshGranted()
            if (!ShizukuHelper.granted) {
                ShizukuHelper.requestPermission()
                ExecutionEngine.invalidateAll()
                appendOut("[身份] 已向 Shizuku 发起授权请求，请在弹出框中允许…\n", false)
                waitForShizukuGrant()
                return@safeLaunch
            }
            val m = "Shizuku 授权已获得"
            AppLog.ok(m)
            appendOut("$m\n", false)
            openShizukuSession()
        }
    }

    private fun waitForShizukuGrant() {
        val cb: (Boolean) -> Unit = { granted ->
            shizukuCallback?.let { ShizukuHelper.removeGrantedCallback(it) }
            shizukuCallback = null
            ui.post {
                if (granted) {
                    val m = "Shizuku 授权已获得"
                    AppLog.ok(m)
                    appendOut("$m\n", false)
                    openShizukuSession()
                } else {
                    appendOut("[身份] Shizuku 授权被拒绝\n", true)
                }
            }
        }
        shizukuCallback = cb
        ShizukuHelper.addGrantedCallback(cb)
    }

    private fun openShizukuSession() {
        safeLaunch {
            val up = withContext(Dispatchers.IO) {
                ExecutionEngine.openElevatedSession(this@TerminalActivity, Identity.SHIZUKU)
            }
            if (up == null) {
                val m = "Shizuku 会话创建失败（服务未运行或权限不足）"
                AppLog.w(m)
                appendOut("$m\n[身份] 切换到 Shizuku 失败\n", true)
                return@safeLaunch
            }
            onElevatedReady(up, null)
        }
    }

    private fun onElevatedReady(up: ExecutionEngine.TermSession, rootFlag: Boolean?) {
        safeLaunch {
            if (AdbBin.isInstalled(this@TerminalActivity)) {
                withContext(Dispatchers.IO) {
                    AdbBin.publishElevated(this@TerminalActivity)
                }
            }
            runCatching { elevatedSession?.destroy() }
            elevatedSession = up.session
            attach(up.session, up.identity)
            appendOut("[身份] 已切换为 ${up.identity.label}\n", false)
            // rootFlag 为 null 表示 Shizuku，用 id 输出判断；ROOT 直接置 true
            if (rootFlag != null) isRoot = rootFlag
            write("id\n")
            write(PROBE)
        }
    }

    // ---------------------------------------------------------------- 设置菜单

    private fun showSettingsMenu() {
        val items = arrayOf(
            getString(R.string.term_cwd),
            getString(R.string.term_font_size)
        )
        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle(R.string.term_settings)
            .setItems(items) { d, which ->
                d.dismiss()
                when (which) {
                    0 -> showCwdDialog()
                    1 -> showFontSizeDialog()
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun showCwdDialog() {
        val input = android.widget.EditText(this).apply {
            setText(Prefs.getTermCwd(this@TerminalActivity))
            setSelection(text.length)
            setSingleLine(true)
        }
        val box = android.widget.FrameLayout(this).apply {
            val pad = (16 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad / 2, pad, 0)
            addView(input)
        }
        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle(R.string.term_cwd)
            .setView(box)
            .setPositiveButton(android.R.string.ok) { d, _ ->
                val v = input.text?.toString()?.trim().orEmpty()
                if (v.isNotEmpty()) {
                    Prefs.setTermCwd(this@TerminalActivity, v)
                    appendOut("[设置] 工作目录已改为 $v，重启终端模拟器后生效\n", false)
                }
                d.dismiss()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun showFontSizeDialog() {
        val sizes = (Prefs.TERM_SIZE_MIN..Prefs.TERM_SIZE_MAX).toList()
        val labels = sizes.map { "$it sp" }.toTypedArray()
        val current = Prefs.getTermSize(this)
        val checked = sizes.indexOf(current).coerceAtLeast(0)
        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle(R.string.term_font_size)
            .setSingleChoiceItems(labels, checked) { d, which ->
                val v = sizes[which]
                Prefs.setTermSize(this@TerminalActivity, v)
                applyFontSize(v)
                appendOut("[设置] 字体大小已改为 ${v}sp\n", false)
                d.dismiss()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    override fun onDestroy() {
        super.onDestroy()
        shizukuCallback?.let { ShizukuHelper.removeGrantedCallback(it) }
        shizukuCallback = null
        runCatching { appSession?.destroy() }
        runCatching { elevatedSession?.destroy() }
    }
}
