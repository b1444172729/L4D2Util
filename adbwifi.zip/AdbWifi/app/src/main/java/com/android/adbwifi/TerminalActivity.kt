package com.android.adbwifi

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextWatcher
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.android.adbwifi.databinding.ActivityTerminalBinding
import com.android.adbwifi.exec.ExecutionEngine
import com.android.adbwifi.exec.ExecutionEngine.Identity
import com.android.adbwifi.exec.RootExecutor
import com.android.adbwifi.exec.ShellSession
import com.android.adbwifi.exec.ShizukuHelper
import com.android.adbwifi.util.AdbBin
import com.android.adbwifi.util.AppLog
import com.android.adbwifi.util.Prefs
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.InputStream

/**
 * 终端模拟器 —— 交互方式对齐 MT 管理器：
 *
 *   · 无底部输入栏：点击输出区任意位置即可输入，回车提交
 *   · 提示符自行渲染：`# 目录名`（root）或 `➜ 目录名`（非 root），
 *     ➜/# 随上条命令退出码变色（成功绿 / 失败红），目录名固定青色
 *   · 自绘灰色方块光标
 *   · stdout 白色、stderr 红色
 *
 * 提示符由 Java 层拼装而非 bash PS1：我们用系统 mksh 且是往长驻 shell 写命令
 * （非交互模式），shell 不会自己打印提示符。做法是每条命令后追加一条探针，
 * 用 magic marker 回传退出码与当前目录，解析后渲染，marker 不显示。
 *
 * 注意：内置 adb 在两种身份下走不同的物理文件——
 *   普通身份执行 nativeLibraryDir 里的 libadb.so（apk_data_file，appdomain 放行）
 *   提权身份执行 /data/local/tmp 下的副本（shell_data_file）
 * 两份路径都会写进 PATH，由 shell 按可执行的那个来挑。
 */
class TerminalActivity : AppCompatActivity() {

    private lateinit var b: ActivityTerminalBinding
    private val ui = Handler(Looper.getMainLooper())

    /**
     * 已完成输出，存成「文本 + 颜色」片段而非累积的 SpannableStringBuilder。
     *
     * 之前每次 render() 都执行 SpannableStringBuilder(screen) 复制构造，
     * 嵌套层数随刷新次数增长，Android 的 countSpans 是递归实现，
     * 层数一深就 StackOverflowError（真机 crash.txt 已复现）。
     * 改成片段列表后，每次都从空的 builder 逐个 append 纯文本，不存在嵌套。
     */
    private val pieces = ArrayList<Piece>()
    private data class Piece(val text: String, val colorId: Int?)

    /** render() 重入保护：setText 会触发监听回调，回调里又调 render() */
    private var rendering = false

    /** 普通身份会话，全程保留，供切回使用 */
    private var appSession: ShellSession? = null
    private var elevatedSession: ShellSession? = null
    private var current: ShellSession? = null
    private var identity: Identity = Identity.APP

    // ---- 提示符状态 ----
    private var isRoot = false
    private var lastExitOk = true
    private var curDir = Prefs.DEFAULT_TERM_CWD
    /** 可能是不完整的 marker 片段，等下一块数据补全 */
    private var tail = ""

    private var shizukuCallback: ((Boolean) -> Unit)? = null

    /**
     * 协程异常处理：lifecycleScope 默认不装 handler，协程里抛出未捕获异常会
     * 直接传播到线程未捕获处理器导致进程崩溃——表现为「进终端几秒后自动返回
     * 主页」。这里统一兜底，任何异常只写日志与屏幕，不让进程死掉。
     */
    private val errHandler = CoroutineExceptionHandler { _, e ->
        AppLog.e("终端异常: ${e.message}")
        runCatching { appendOut("[错误] ${e.javaClass.simpleName}: ${e.message}\n", true) }
    }

    /** 代替 lifecycleScope.launch：带异常处理，且整块包 try/catch */
    private fun safeLaunch(block: suspend () -> Unit) =
        lifecycleScope.launch(errHandler) {
            runCatching { block() }.onFailure {
                AppLog.e("终端异常: ${it.message}")
                runCatching { appendOut("[错误] ${it.javaClass.simpleName}: ${it.message}\n", true) }
            }
        }

    /** 探针回传格式：__ADBW:退出码:当前目录__ */
    private val MARKER = Regex("""__ADBW:(-?\d+):(.*?)__""")
    private val MARKER_HEAD = "__ADBW:"
    private val PROBE = "printf '__ADBW:%s:%s__\\n' \"\$?\" \"\$PWD\"\n"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityTerminalBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.btnSwitchIdentity.setOnClickListener { showIdentityMenu() }
        b.btnTermSettings.setOnClickListener { showSettingsMenu() }
        applyFontSize(Prefs.getTermSize(this))

        setupInput()

        startSession()
    }

    // ---------------------------------------------------------------- 输入

    private fun setupInput() {
        // 点击输出区任意位置 → 聚焦隐藏输入框并弹出键盘
        val focus = { focusInput() }
        b.tvTerm.setOnClickListener { focus() }
        b.termScroll.setOnClickListener { focus() }

        b.etInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                submit(b.etInput.text?.toString().orEmpty())
                true
            } else false
        }
        b.etInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) = Unit
            override fun onTextChanged(s: CharSequence?, st: Int, be: Int, c: Int) = Unit
            override fun afterTextChanged(s: android.text.Editable?) = render()
        })
        // 首次进入主动弹出，省一次点击
        b.termScroll.post { focusInput() }
    }

    private fun focusInput() {
        runCatching {
            b.etInput.requestFocus()
            val imm = getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager
            imm?.showSoftInput(b.etInput, InputMethodManager.SHOW_IMPLICIT)
        }.onFailure { AppLog.w("键盘聚焦失败: ${it.message}") }
        runCatching { render() }
            .onFailure { AppLog.w("终端渲染失败: ${it.message}") }
    }

    private fun submit(raw: String) {
        val cmd = raw.trim()
        // 回显：提示符 + 命令
        addPiece(buildPromptSym(), promptColorId())
        addPiece(" $cmd\n", null)
        b.etInput.setText("")
        render()
        if (cmd.isBlank()) {
            // 空回车也要刷新提示符（退出码不变）
            write(PROBE)
            return
        }
        write("$cmd\n")
        write(PROBE)
    }

    // ---------------------------------------------------------------- 会话

    private fun startSession() {
        safeLaunch {
            val adbReady = withContext(Dispatchers.IO) {
                AdbBin.install(this@TerminalActivity)
            }
            val cwd = Prefs.getTermCwd(this@TerminalActivity)
            // 先按设置目录建；失败（目录不存在/无权进入）则回退到默认目录再建一次
            var app = withContext(Dispatchers.IO) {
                runCatching { ExecutionEngine.openAppSession(cwd) }.getOrNull()
            }
            if (app == null) {
                AppLog.w("以 $cwd 建会话失败，回退默认目录")
                appendOut("[提示] 工作目录 $cwd 不可用，回退默认目录\n", false)
                app = withContext(Dispatchers.IO) {
                    runCatching { ExecutionEngine.openAppSession(null) }.getOrNull()
                }
            }
            if (app == null) {
                AppLog.e("无法创建终端会话")
                appendOut("[错误] 无法创建终端会话\n", true)
                return@safeLaunch
            }
            appSession = app
            attach(app, Identity.APP)

            if (adbReady) {
                write(AdbBin.envScript(this@TerminalActivity))
            } else {
                appendOut("[内置 adb] 不可用（非 arm64 设备）\n", false)
            }
            // 拿初始目录 + 判断身份
            write("id\n")
            write(PROBE)
        }
    }

    /** 切换会话：接管输出流并更新标题栏 */
    private fun attach(s: ShellSession, id: Identity) {
        current = s
        identity = id
        pump(s.output, false)
        pump(s.error, true)
        updateIdentityUi()
    }

    private fun pump(stream: InputStream, isErr: Boolean) {
        Thread {
            val buf = ByteArray(8192)
            try {
                while (true) {
                    val n = stream.read(buf)
                    if (n <= 0) break
                    val text = String(buf, 0, n)
                    if (isErr) {
                        ui.post { runCatching { appendOut(text, true) } }
                    } else {
                        val clean = sanitize(text)
                        ui.post {
                            runCatching {
                                if (clean.isNotEmpty()) appendOut(clean, false)
                                else render()
                            }
                        }
                    }
                }
            } catch (t: Throwable) {
                AppLog.w("输出读取中断: ${t.message}")
            }
            AppLog.w("终端会话已结束（shell 进程退出）")
            ui.post { runCatching { appendOut("\n[会话已结束]\n", true) } }
        }.apply { isDaemon = true; start() }
    }

    /**
     * 剥离探针 marker，并用它更新提示符状态。
     * 未闭合的 marker 片段留在 tail，等下一块数据补全后再处理。
     */
    private fun sanitize(chunk: String): String {
        val s = tail + chunk
        tail = ""
        val idx = s.lastIndexOf(MARKER_HEAD)
        if (idx < 0) return s
        val head = s.substring(0, idx)
        val cand = s.substring(idx)
        val m = MARKER.find(cand)
        if (m != null) {
            lastExitOk = m.groupValues[1] == "0"
            val d = m.groupValues[2]
            if (d.isNotBlank()) curDir = d
            return head + cand.removeRange(m.range)
        }
        // 还没收全，先攒着
        tail = cand
        return head
    }

    // ---------------------------------------------------------------- 渲染

    /** 追加一段已完成输出；isErr 时整段红色，否则用默认白色 */
    private fun appendOut(text: String, isErr: Boolean) {
        if (text.isEmpty()) return
        // 顺便判断是否为 root（id 输出里的 uid=0）
        if (text.contains("uid=0")) isRoot = true
        addPiece(text, if (isErr) com.android.adbwifi.R.color.log_err else null)
        render()
    }

    /** 记录一段输出，并控制总量 */
    private fun addPiece(text: String, colorId: Int?) {
        pieces.add(Piece(text, colorId))
        trimPieces()
    }

    private fun buildPromptSym() = if (isRoot) "#" else "\u279C"

    private fun promptColorId() =
        if (lastExitOk) com.android.adbwifi.R.color.log_ok else com.android.adbwifi.R.color.log_err

    /**
     * 渲染：已完成输出 + 提示符 + 正在输入的内容 + 灰色方块光标。
     *
     * 关键点：
     *  · 从**空的** builder 开始，逐个 append 纯文本 —— 不做复制构造，不嵌套
     *  · append 的是 String 而不是 etInput 的 Editable，避免把带 ChangeWatcher
     *    的对象牵进来形成 "setText → 回调 → render" 的死循环
     *  · rendering 重入保护，双保险
     */
    private fun render() {
        if (rendering) return
        rendering = true
        try {
            val sb = SpannableStringBuilder()
            for (p in pieces) {
                val st = sb.length
                sb.append(p.text)
                val c = p.colorId
                if (c != null) {
                    sb.setSpan(
                        ForegroundColorSpan(color(c)),
                        st, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                    )
                }
            }
            // 提示符：符号（绿/红）+ 空格 + 目录名（青）
            run {
                val st = sb.length
                sb.append(buildPromptSym())
                sb.setSpan(
                    ForegroundColorSpan(color(promptColorId())),
                    st, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )
                val ds = sb.length
                sb.append(" ")
                sb.append(dirName())
                sb.setSpan(
                    ForegroundColorSpan(color(com.android.adbwifi.R.color.term_cyan)),
                    ds + 1, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )
                sb.append(" ")
            }
            // 正在输入的内容（用 String，不放 Editable）
            sb.append(b.etInput.text?.toString().orEmpty())
            // 光标：灰色方块（在末尾一个空格上打背景色）
            val cs = sb.length
            sb.append(" ")
            sb.setSpan(
                BackgroundColorSpan(color(com.android.adbwifi.R.color.text_secondary)),
                cs, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            b.tvTerm.setText(sb, android.widget.TextView.BufferType.SPANNABLE)
            b.termScroll.post { b.termScroll.fullScroll(android.view.View.FOCUS_DOWN) }
        } finally {
            rendering = false
        }
    }

    /** 控制已完成输出的总字符数，避免长时间会话后卡顿 */
    private fun trimPieces() {
        var total = 0
        for (p in pieces) total += p.text.length
        if (total <= 80_000) return
        var drop = 0
        while (drop < pieces.size && total > 60_000) {
            total -= pieces[drop].text.length
            drop++
        }
        if (drop > 0) pieces.subList(0, drop).clear()
    }

    /** 只显示目录名，与 bash PS1 的 \W 一致 */
    private fun dirName(): String {
        val p = curDir.trimEnd('/')
        if (p.isEmpty()) return "/"
        val i = p.lastIndexOf('/')
        return if (i < 0) p else p.substring(i + 1).ifEmpty { "/" }
    }

    private fun color(id: Int) = ContextCompat.getColor(this, id)

    private fun updateIdentityUi() {
        b.tvIdentityValue.text = when (identity) {
            Identity.APP -> getString(R.string.identity_app)
            Identity.ROOT -> getString(R.string.identity_root)
            Identity.SHIZUKU -> getString(R.string.identity_shizuku)
        }
    }

    private fun write(line: String) {
        val s = current ?: run { appendOut("[错误] 会话未就绪\n", true); return }
        try {
            s.input.write(line.toByteArray())
            s.input.flush()
        } catch (t: Throwable) {
            appendOut("[错误] 写入失败: ${t.message}\n", true)
        }
    }

    private fun applyFontSize(sp: Int) {
        b.tvTerm.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, sp.toFloat())
    }

    // ---------------------------------------------------------------- 身份菜单

    private fun showIdentityMenu() {
        val items = arrayOf(
            getString(R.string.identity_app),
            getString(R.string.identity_root),
            getString(R.string.identity_shizuku)
        )
        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle(R.string.identity_choose)
            .setItems(items) { d, which ->
                d.dismiss()
                when (which) {
                    0 -> switchToApp()
                    1 -> switchToRoot()
                    2 -> switchToShizuku()
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun switchToApp() {
        if (identity == Identity.APP) {
            appendOut("[身份] 当前已是普通身份\n", false)
            return
        }
        val app = appSession ?: run {
            appendOut("[身份] 普通会话不可用\n", true)
            return
        }
        runCatching { elevatedSession?.destroy() }
        elevatedSession = null
        isRoot = false
        attach(app, Identity.APP)
        appendOut("[身份] 已切换为普通\n", false)
        write(PROBE)
    }

    private fun switchToRoot() {
        appendOut("[身份] 切换到 ROOT…\n", false)
        safeLaunch {
            ExecutionEngine.invalidateAll()
            val (ok, msg) = withContext(Dispatchers.IO) { RootExecutor.availability() }
            if (ok) AppLog.ok(msg) else AppLog.w(msg)
            appendOut("$msg\n", !ok)
            if (!ok) {
                appendOut("[身份] 切换到 ROOT 失败\n", true)
                return@safeLaunch
            }
            val up = withContext(Dispatchers.IO) {
                ExecutionEngine.openElevatedSession(this@TerminalActivity, Identity.ROOT)
            }
            if (up == null) {
                val m = "ROOT 会话创建失败"
                AppLog.w(m)
                appendOut("$m\n[身份] 切换到 ROOT 失败\n", true)
                return@safeLaunch
            }
            onElevatedReady(up, true)
        }
    }

    private fun switchToShizuku() {
        appendOut("[身份] 切换到 Shizuku…\n", false)
        safeLaunch {
            ExecutionEngine.invalidateAll()
            ShizukuHelper.refreshGranted()
            if (!ShizukuHelper.granted) {
                ShizukuHelper.requestPermission()
                ExecutionEngine.invalidateAll()
                appendOut("[身份] 已向 Shizuku 发起授权请求，请在弹出框中允许…\n", false)
                waitForShizukuGrant()
                return@safeLaunch
            }
            val m = "Shizuku 授权已获得"
            AppLog.ok(m)
            appendOut("$m\n", false)
            openShizukuSession()
        }
    }

    private fun waitForShizukuGrant() {
        val cb: (Boolean) -> Unit = { granted ->
            shizukuCallback?.let { ShizukuHelper.removeGrantedCallback(it) }
            shizukuCallback = null
            ui.post {
                if (granted) {
                    val m = "Shizuku 授权已获得"
                    AppLog.ok(m)
                    appendOut("$m\n", false)
                    openShizukuSession()
                } else {
                    appendOut("[身份] Shizuku 授权被拒绝\n", true)
                }
            }
        }
        shizukuCallback = cb
        ShizukuHelper.addGrantedCallback(cb)
    }

    private fun openShizukuSession() {
        safeLaunch {
            val up = withContext(Dispatchers.IO) {
                ExecutionEngine.openElevatedSession(this@TerminalActivity, Identity.SHIZUKU)
            }
            if (up == null) {
                val m = "Shizuku 会话创建失败（服务未运行或权限不足）"
                AppLog.w(m)
                appendOut("$m\n[身份] 切换到 Shizuku 失败\n", true)
                return@safeLaunch
            }
            onElevatedReady(up, null)
        }
    }

    private fun onElevatedReady(up: ExecutionEngine.TermSession, rootFlag: Boolean?) {
        safeLaunch {
            if (AdbBin.isInstalled(this@TerminalActivity)) {
                withContext(Dispatchers.IO) {
                    AdbBin.publishElevated(this@TerminalActivity)
                }
            }
            runCatching { elevatedSession?.destroy() }
            elevatedSession = up.session
            attach(up.session, up.identity)
            appendOut("[身份] 已切换为 ${up.identity.label}\n", false)
            // rootFlag 为 null 表示 Shizuku，用 id 输出判断；ROOT 直接置 true
            if (rootFlag != null) isRoot = rootFlag
            write("id\n")
            write(PROBE)
        }
    }

    // ---------------------------------------------------------------- 设置菜单

    private fun showSettingsMenu() {
        val items = arrayOf(
            getString(R.string.term_cwd),
            getString(R.string.term_font_size)
        )
        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle(R.string.term_settings)
            .setItems(items) { d, which ->
                d.dismiss()
                when (which) {
                    0 -> showCwdDialog()
                    1 -> showFontSizeDialog()
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun showCwdDialog() {
        val input = android.widget.EditText(this).apply {
            setText(Prefs.getTermCwd(this@TerminalActivity))
            setSelection(text.length)
            setSingleLine(true)
        }
        val box = android.widget.FrameLayout(this).apply {
            val pad = (16 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad / 2, pad, 0)
            addView(input)
        }
        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle(R.string.term_cwd)
            .setView(box)
            .setPositiveButton(android.R.string.ok) { d, _ ->
                val v = input.text?.toString()?.trim().orEmpty()
                if (v.isNotEmpty()) {
                    Prefs.setTermCwd(this@TerminalActivity, v)
                    appendOut("[设置] 工作目录已改为 $v，重启终端模拟器后生效\n", false)
                }
                d.dismiss()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun showFontSizeDialog() {
        val sizes = (Prefs.TERM_SIZE_MIN..Prefs.TERM_SIZE_MAX).toList()
        val labels = sizes.map { "$it sp" }.toTypedArray()
        val current = Prefs.getTermSize(this)
        val checked = sizes.indexOf(current).coerceAtLeast(0)
        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle(R.string.term_font_size)
            .setSingleChoiceItems(labels, checked) { d, which ->
                val v = sizes[which]
                Prefs.setTermSize(this@TerminalActivity, v)
                applyFontSize(v)
                appendOut("[设置] 字体大小已改为 ${v}sp\n", false)
                d.dismiss()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    override fun onDestroy() {
        super.onDestroy()
        shizukuCallback?.let { ShizukuHelper.removeGrantedCallback(it) }
        shizukuCallback = null
        runCatching { appSession?.destroy() }
        runCatching { elevatedSession?.destroy() }
    }
}
