package com.android.adbwifi

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.android.adbwifi.databinding.ActivityTerminalBinding
import com.android.adbwifi.exec.ExecutionEngine
import com.android.adbwifi.exec.ExecutionEngine.Identity
import com.android.adbwifi.exec.ShellSession
import com.android.adbwifi.util.AdbBin
import com.android.adbwifi.util.AppLog
import com.android.adbwifi.util.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.InputStream

/**
 * 终端模拟器 —— 身份策略为「普通优先 + 按需提权」：
 *
 *   进入即创建普通应用身份的 /system/bin/sh，ls / cd / pwd 等基础命令
 *   无需任何授权即可使用；随后后台探测 ROOT / Shizuku，可用则自动切到
 *   提权会话，也可通过标题栏按钮手动切换。
 *
 * 这与 MT 管理器终端的行为一致。
 *
 * 注意：内置 adb 在两种身份下走不同的物理文件——
 *   普通身份执行 nativeLibraryDir 里的 libadb.so（apk_data_file，appdomain 放行）
 *   提权身份执行 /data/local/tmp 下的副本（shell_data_file）
 * 两份路径都会写进 PATH，由 shell 按可执行的那个来挑。
 */
class TerminalActivity : AppCompatActivity() {

    private lateinit var b: ActivityTerminalBinding
    private val ui = Handler(Looper.getMainLooper())
    private val screen = StringBuilder()

    /** 普通身份会话，全程保留，供切回使用 */
    private var appSession: ShellSession? = null
    /** 提权会话，探测到可用后建立并缓存 */
    private var elevated: ExecutionEngine.TermSession? = null

    private var current: ShellSession? = null
    private var identity: Identity = Identity.APP

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityTerminalBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.btnRun.setOnClickListener { send() }
        b.btnSwitchIdentity.setOnClickListener { toggleIdentity() }
        b.etCmd.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                send()
                true
            } else false
        }

        startSession()
    }

    private fun startSession() {
        appendText("无线调试 · 终端模拟器\n")
        appendText("工作模式：${if (Prefs.getMode(this) == Prefs.MODE_ROOT) "ROOT" else "Shizuku"}\n\n")

        lifecycleScope.launch {
            // 第一步：内置 adb（建符号链接，几乎瞬时）
            val adbReady = withContext(Dispatchers.IO) {
                AdbBin.install(this@TerminalActivity)
            }

            // 第二步：普通身份会话 —— 一定成功，基础命令立即可用
            val app = withContext(Dispatchers.IO) {
                runCatching { ExecutionEngine.openAppSession() }.getOrNull()
            }
            if (app == null) {
                appendText("[错误] 无法创建终端会话\n")
                return@launch
            }
            appSession = app
            attach(app, Identity.APP)

            // 注入环境后再说明 adb 状态
            if (adbReady) {
                write(AdbBin.envScript(this@TerminalActivity))
            } else {
                appendText("[内置 adb] 不可用（非 arm64 设备）\n")
            }
            write("id\n")

            // 第三步：后台探测提权，可用则自动切换
            val up = withContext(Dispatchers.IO) {
                ExecutionEngine.openElevatedSession(this@TerminalActivity)
            }
            if (up == null) {
                appendText("[身份] 未检测到 ROOT / Shizuku，以普通身份运行（需要时可在终端内输入 su）\n")
                return@launch
            }
            // 提权身份执行不了 apk_data_file，先补一份副本到 /data/local/tmp
            if (adbReady) {
                withContext(Dispatchers.IO) {
                    AdbBin.publishElevated(this@TerminalActivity)
                }
            }
            elevated = up
            attach(up.session, up.identity)
            appendText("[身份] 已提权：${up.identity.label}\n")
            write("id\n")
        }
    }

    /** 切换会话：接管输出流并更新标题栏 */
    private fun attach(s: ShellSession, id: Identity) {
        current = s
        identity = id
        pump(s.output)
        pump(s.error)
        updateIdentityUi()
    }

    private fun updateIdentityUi() {
        b.tvIdentity.text = when (identity) {
            Identity.APP -> "身份：普通"
            Identity.ROOT -> "身份：ROOT"
            Identity.SHIZUKU -> "身份：Shizuku"
        }
        b.tvIdentity.setTextColor(
            if (identity == Identity.APP) {
                resources.getColor(com.android.adbwifi.R.color.text_secondary, theme)
            } else {
                resources.getColor(com.android.adbwifi.R.color.log_ok, theme)
            }
        )
    }

    /** 手动切换：普通 ↔ 提权 */
    private fun toggleIdentity() {
        if (identity != Identity.APP) {
            appSession?.let {
                attach(it, Identity.APP)
                appendText("[身份] 已切换为普通\n")
                write("id\n")
            }
            return
        }
        val cached = elevated
        if (cached != null) {
            attach(cached.session, cached.identity)
            appendText("[身份] 已切换为 ${cached.identity.label}\n")
            write("id\n")
            return
        }
        appendText("[身份] 正在尝试提权…\n")
        lifecycleScope.launch {
            val up = withContext(Dispatchers.IO) {
                ExecutionEngine.openElevatedSession(this@TerminalActivity)
            }
            if (up == null) {
                appendText("[身份] 提权失败：ROOT / Shizuku 均不可用\n")
                return@launch
            }
            elevated = up
            attach(up.session, up.identity)
            appendText("[身份] 已切换为 ${up.identity.label}\n")
            write("id\n")
        }
    }

    /** 持续读取 shell 输出并追加到屏幕 */
    private fun pump(stream: InputStream) {
        Thread {
            val buf = ByteArray(8192)
            try {
                while (true) {
                    val n = stream.read(buf)
                    if (n <= 0) break
                    val text = String(buf, 0, n)
                    ui.post { appendText(text) }
                }
            } catch (_: Throwable) {
            }
            ui.post { appendText("\n[会话已结束]\n") }
        }.apply { isDaemon = true; start() }
    }

    private fun send() {
        val cmd = b.etCmd.text?.toString()?.trim().orEmpty()
        b.etCmd.setText("")
        if (cmd.isBlank()) return
        appendText(if (identity == Identity.ROOT) "# $cmd\n" else "\$ $cmd\n")
        write("$cmd\n")
    }

    private fun write(line: String) {
        val s = current ?: run { appendText("[错误] 会话未就绪\n"); return }
        try {
            s.input.write(line.toByteArray())
            s.input.flush()
        } catch (t: Throwable) {
            appendText("[错误] 写入失败: ${t.message}\n")
        }
    }

    private fun appendText(text: String) {
        screen.append(text)
        // 限制缓冲，避免长会话卡顿
        if (screen.length > 120_000) screen.delete(0, screen.length - 80_000)
        b.tvTerm.text = screen
        b.termScroll.post { b.termScroll.fullScroll(android.view.View.FOCUS_DOWN) }
    }

    override fun onDestroy() {
        super.onDestroy()
        runCatching { appSession?.destroy() }
        runCatching { elevated?.session?.destroy() }
    }
}
