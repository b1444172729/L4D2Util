package com.android.adbwifi

import android.app.Application
import com.android.adbwifi.exec.ShizukuHelper
import com.android.adbwifi.util.AppLog

class AdbWifiApp : Application() {

    override fun onCreate() {
        super.onCreate()
        AppLog.i("无线调试 启动")
        ShizukuHelper.init()
        AppLog.i(ShizukuHelper.versionString())
    }
}
