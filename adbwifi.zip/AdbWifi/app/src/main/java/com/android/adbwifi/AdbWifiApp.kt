package com.android.adbwifi

import android.app.Application
import com.android.adbwifi.exec.ShizukuHelper
import com.android.adbwifi.util.AppLog

class AdbWifiApp : Application() {

    override fun onCreate() {
        super.onCreate()
        installCrashDump()
        AppLog.i("无线调试 启动")
        ShizukuHelper.init()
        AppLog.i(ShizukuHelper.versionString())
    }

    /**
     * 把未捕获异常写入外部私有目录 crash.txt，便于真机排查。
     *
     * AppLog 只在内存里，进程崩了就没了；写文件才能事后查看。
     * 路径是 /sdcard/Android/data/<pkg>/files/crash.txt，
     * 用 MT 管理器或本应用的终端（adb）都能读到。
     * 仅追加最近一次崩溃，避免无限增长。
     */
    private fun installCrashDump() {
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            runCatching {
                val dir = getExternalFilesDir(null)
                if (dir != null) {
                    if (!dir.exists()) dir.mkdirs()
                    val sb = StringBuilder()
                    sb.append("=== ${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.CHINA).format(java.util.Date())} ===\n")
                    sb.append("thread: ${t.name}\n")
                    sb.append("${e.javaClass.name}: ${e.message}\n")
                    e.stackTrace.take(40).forEach { sb.append("  at $it\n") }
                    sb.append("\n")
                    java.io.File(dir, "crash.txt").writeText(sb.toString())
                }
            }
            prev?.uncaughtException(t, e)
        }
    }
}
