package com.android.adbwifi.util

import android.content.Context
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/**
 * adb 二进制的获取与管理。
 *
 * 背景：Android 11+ 的无线调试需要 adb 才能配对连接，但系统默认不带 adb 可执行文件。
 * MT管理器 把 adb 放在 /data/user/0/bin.mt.plus/files/term/bin/adb —— 但那是 App 私有目录，
 * 第三方应用**无权直接读取**，必须借助 ROOT 或 Shizuku 才能拷贝出来。
 *
 * 本类按「从稳到不稳」四级探测，取第一个可用的：
 *
 *   1. 内置（推荐）—— 打包进 APK 的 jniLibs/<abi>/libadb.so
 *      安装时由系统自动提取到 nativeLibraryDir，天然带可执行权限，最可靠。
 *   2. 系统自带 —— 少数 ROM 把 adb 放进了 /system/bin
 *   3. 外部导入 —— 用户把 adb 放到 /sdcard/adb 或 /sdcard/Download/adb，由本应用复制安装
 *   4. 提权拷贝 —— 从 MT管理器 / Termux 的私有目录复制（需 ROOT / Shizuku）
 */
object AdbBinary {

    /** APK 内置时的文件名（放在 jniLibs/<abi>/ 下，必须叫 libxxx.so 才会被系统提取） */
    private const val BUILT_IN_NAME = "libadb.so"

    /** 安装到本地后的名字 */
    private const val ADB_NAME = "adb"

    /** 可被导入的外部路径 */
    private val IMPORT_CANDIDATES = arrayOf(
        "/sdcard/adb",
        "/sdcard/Download/adb",
        "/sdcard/Download/adb/adb",
        "/sdcard/mt/adb"
    )

    /** 其他应用的私有目录（需提权才能读） */
    private val FOREIGN_CANDIDATES = arrayOf(
        "/data/user/0/bin.mt.plus/files/term/bin/adb",   // MT管理器
        "/data/data/bin.mt.plus/files/term/bin/adb",
        "/data/data/com.termux/files/usr/bin/adb",       // Termux
        "/data/data/com.termux/files/usr/bin/adb.bin"
    )

    /** 系统自带 */
    private val SYSTEM_CANDIDATES = arrayOf(
        "/system/bin/adb",
        "/system/xbin/adb",
        "/vendor/bin/adb"
    )

    /** 本机 ABI 列表，按优先级 */
    private fun abis(): List<String> = buildList {
        Build.SUPPORTED_ABIS.forEach { add(it) }
        add("armeabi-v7a")
        add("arm64-v8a")
    }

    /** 本应用自己的 bin 目录 */
    fun binDir(ctx: Context): File = File(ctx.filesDir, "bin").apply { mkdirs() }

    /** 已安装到本地的 adb（可能不存在） */
    fun localAdb(ctx: Context): File = File(binDir(ctx), ADB_NAME)

    /** 内置 adb 所在路径（nativeLibraryDir 下） */
    private fun builtInAdb(ctx: Context): File? {
        val dir = ctx.applicationInfo.nativeLibraryDir ?: return null
        return File(dir, BUILT_IN_NAME).takeIf { it.exists() && it.length() > 0 }
    }

    /**
     * 确保 adb 可用，返回可直接执行的路径；全部失败返回 null。
     * 检测结果会写入运行日志。
     */
    suspend fun ensure(ctx: Context): String? = withContext(Dispatchers.IO) {
        // 1) 已经安装过且可执行
        val local = localAdb(ctx)
        if (local.exists() && local.canExecute() && local.length() > 0) {
            AppLog.ok("adb 已就位: ${local.absolutePath}")
            return@withContext local.absolutePath
        }

        // 2) APK 内置
        builtInAdb(ctx)?.let { so ->
            if (install(ctx, so, "APK 内置")) return@withContext local.absolutePath
        }

        // 3) 系统自带
        SYSTEM_CANDIDATES.firstOrNull { File(it).exists() }?.let {
            AppLog.ok("使用系统 adb: $it")
            return@withContext it
        }

        // 4) 外部导入（/sdcard 下的，无需提权）
        val external = IMPORT_CANDIDATES.firstOrNull { File(it).exists() && File(it).length() > 0 }
        if (external != null && install(ctx, File(external), "外部导入")) {
            return@withContext local.absolutePath
        }

        // 5) 提权拷贝（MT管理器 / Termux）
        val engine = com.android.adbwifi.exec.ExecutionEngine
        for (src in FOREIGN_CANDIDATES) {
            val r = engine.exec(ctx, "ls -l $src 2>/dev/null && cp $src ${local.absolutePath} && chmod 755 ${local.absolutePath}", 10)
            if (local.exists() && local.length() > 0) {
                local.setExecutable(true, false)
                AppLog.ok("已从 $src 复制 adb")
                return@withContext local.absolutePath
            }
            if (r.combined.isNotBlank() && !r.combined.contains("No such file")) {
                AppLog.i("探测 $src: ${r.combined.lines().firstOrNull() ?: ""}")
            }
        }

        AppLog.w("未找到 adb 二进制，终端将无法执行 adb 命令")
        AppLog.i("可将 adb 放到 /sdcard/adb 后重试，或在 APK 的 jniLibs/<abi>/ 内置 libadb.so")
        null
    }

    /** 把二进制复制到 filesDir/bin/adb 并赋可执行权限 */
    private fun install(ctx: Context, src: File, from: String): Boolean {
        val dst = localAdb(ctx)
        return try {
            binDir(ctx).mkdirs()
            if (dst.exists()) dst.delete()
            src.inputStream().use { input ->
                FileOutputStream(dst).use { out -> input.copyTo(out) }
            }
            dst.setExecutable(true, false)
            dst.setReadable(true, false)
            val ok = dst.exists() && dst.length() > 0
            if (ok) AppLog.ok("adb 安装成功（来源：$from，${dst.length()} 字节）")
            else AppLog.w("adb 复制后为空（来源：$from）")
            ok
        } catch (t: Throwable) {
            AppLog.w("adb 安装失败（$from）: ${t.message}")
            false
        }
    }

    /**
     * 生成终端的环境变量与初始化命令。
     * - PATH 前置本应用的 bin 目录
     * - 工作目录切换到 /sdcard
     */
    fun initCommands(ctx: Context, adbPath: String?): List<String> {
        val bin = binDir(ctx).absolutePath
        val cmds = mutableListOf<String>()
        cmds.add("export PATH=$bin:\$PATH")
        cmds.add("export HOME=/sdcard")
        cmds.add("export TMPDIR=${ctx.cacheDir.absolutePath}")
        if (adbPath != null) cmds.add("alias adb='$adbPath'")
        cmds.add("cd /sdcard")
        return cmds
    }

    /** 供 UI 展示的说明 */
    fun howToGet(): String =
        "adb 是 Android 平台调试桥，用于无线调试配对。\n" +
        "获取方式（任选其一）：\n" +
        "  1) 把 adb 二进制放到 /sdcard/adb，本应用会自动安装\n" +
        "  2) 重新打包 APK 时放入 app/src/main/jniLibs/<abi>/libadb.so\n" +
        "  3) 已装 MT管理器 且已授权 ROOT/Shizuku 时，自动从其私有目录复制"
}
