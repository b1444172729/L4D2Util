package com.android.adbwifi.util

import android.content.Context
import android.system.Os
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipInputStream

/**
 * 终端扩展环境 —— 把 GNU 工具链（coreutils / bash / grep / sed / gawk / find /
 * xargs / adb）从 APK assets 释放到应用私有目录，供终端模拟器使用。
 *
 * ## 为什么需要它
 *
 * Android 自带的 `/system/bin` 只有 toybox（Android 6+）或 toolbox（旧版），
 * 命令是精简实现：`ls` 没有 `--color`、`grep` 不支持 `-P`、`find` 缺 `-printf`、
 * 没有 `bash`/`awk`/`sed` 的完整功能。内置一套 GNU 工具后，终端才真正可用。
 *
 * ## 二进制来源
 *
 * 取自 MT 管理器「终端扩展包」（bin.mt.termex，arm64-v8a）。这些文件是
 * Termux 体系的构建产物：PIE 动态链接、interp 为 /system/bin/linker64、
 * DT_NEEDED 为裸名（libiconv.so 等），依赖运行时按路径找到 .so。
 *
 * ## 依赖库怎么被找到（关键）
 *
 * 原包把 .so 命名成 `libiconv.so.rename` 这类名字，靠外层设置 LD_LIBRARY_PATH。
 * 这里改用更可靠的做法：打包前用 patchelf 给二进制写入
 * `DT_RUNPATH = $ORIGIN/../lib`，linker 会直接去可执行文件同级的 ../lib 找。
 *
 * 选 RUNPATH 而不是 LD_LIBRARY_PATH，是为了避开两处陷阱：
 *   1. AT_SECURE —— 进程经 setuid 提权后（如 su），bionic linker 会忽略
 *      环境变量里的 LD_LIBRARY_PATH，导致动态库找不到。
 *   2. linker namespace —— Android 7+ 对应用进程的库搜索路径有白名单，
 *      环境变量指定的目录可能被判为不可访问。
 * RUNPATH 写在 ELF 内部，不受这两者影响。
 *
 * ## 释放位置与跨 UID 访问
 *
 * 释放到 `/data/data/<pkg>/files/term/{bin,lib,home,tmp}`。
 *
 * 注意终端可能以 ROOT 或 Shizuku（shell, uid 2000）身份执行，而应用私有目录
 * 默认 0700，shell 进不来。因此释放后会把主目录放宽为 0711（仅保留 traverse
 * 位，其他应用列不出目录内容），让 shell 能进入并 exec 这些工具。
 * ROOT 身份不受此限制，此设置只是为了让 Shizuku 模式同样可用。
 */
object TermEnv {

    /** 资源版本：内置工具更新时递增，触发重新释放 */
    private const val VERSION = 1

    private const val ASSET_ZIP = "termbin.zip"
    private const val ASSET_MANIFEST = "termbin.manifest.json"
    private const val ASSET_BASHRC = "term_bashrc"
    private const val STAMP = ".version"

    /** 工具链根目录 */
    fun root(ctx: Context): File = File(ctx.filesDir, "term")

    fun binDir(ctx: Context): File = File(root(ctx), "bin")
    fun libDir(ctx: Context): File = File(root(ctx), "lib")
    fun homeDir(ctx: Context): File = File(root(ctx), "home")
    fun tmpDir(ctx: Context): File = File(root(ctx), "tmp")

    /** 已释放且版本匹配 */
    fun isInstalled(ctx: Context): Boolean {
        val stamp = File(root(ctx), STAMP)
        if (!stamp.exists()) return false
        return runCatching { stamp.readText().trim() }.getOrNull() == VERSION.toString()
    }

    /**
     * 释放工具链。幂等：已安装且版本一致时直接返回 true。
     *
     * @param onProgress 进度回调（0-100），在调用方线程外执行，需自行切主线程
     * @return 是否成功；失败时终端仍可用（退化为系统 toybox 命令），不应阻断启动
     */
    fun install(ctx: Context, onProgress: ((Int) -> Unit)? = null): Boolean {
        if (isInstalled(ctx)) {
            ensureReachable(ctx)
            onProgress?.invoke(100)
            return true
        }
        val dir = root(ctx)
        val staging = File(ctx.filesDir, "term.installing")
        return try {
            // 先释放到临时目录，成功后再原子改名，避免半份残留
            if (staging.exists()) staging.deleteRecursively()
            staging.mkdirs()

            val expected = readExpectedCount(ctx)
            var done = 0

            ctx.assets.open(ASSET_ZIP).use { raw ->
                ZipInputStream(raw.buffered()).use { zis ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val e = zis.nextEntry ?: break
                        if (e.isDirectory) {
                            File(staging, e.name).mkdirs()
                            continue
                        }
                        val out = File(staging, e.name)
                        out.parentFile?.mkdirs()
                        out.outputStream().use { os ->
                            while (true) {
                                val n = zis.read(buf)
                                if (n <= 0) break
                                os.write(buf, 0, n)
                            }
                        }
                        done++
                        if (expected > 0 && done % 8 == 0) {
                            onProgress?.invoke((done * 90 / expected).coerceIn(0, 90))
                        }
                    }
                }
            }

            // 权限：bin 可执行，lib 可读可执行（.so 需要被执行映射）
            File(staging, "bin").listFiles()?.forEach { chmod(it, 0b111_101_101) } // 0755
            File(staging, "lib").listFiles()?.forEach { chmod(it, 0b111_101_101) } // 0755

            // 运行期目录
            File(staging, "home").mkdirs()
            File(staging, "tmp").mkdirs()
            chmod(File(staging, "tmp"), 0b111_111_111) // 0777，多 UID 都要能写

            // bash 启动配置：从 assets 直接复制，避免 Kotlin 字符串与 shell 的
            // 美元符转义互相打架（PS1 里需要大量 \$(...) 做延迟求值）
            runCatching {
                ctx.assets.open(ASSET_BASHRC).use { it.copyTo(File(staging, "home/.bashrc").outputStream()) }
            }

            onProgress?.invoke(95)

            // 原子替换
            if (dir.exists()) dir.deleteRecursively()
            if (!staging.renameTo(dir)) {
                // 改名失败（跨挂载点等）时退回逐文件复制
                staging.copyRecursively(dir, overwrite = true)
                staging.deleteRecursively()
            }

            File(dir, STAMP).writeText(VERSION.toString())
            ensureReachable(ctx)

            onProgress?.invoke(100)
            AppLog.ok("终端扩展已就绪：${File(dir, "bin").listFiles()?.size ?: 0} 个命令")
            true
        } catch (t: Throwable) {
            AppLog.w("终端扩展释放失败: ${t.message}（将退化为系统自带命令）")
            runCatching { staging.deleteRecursively() }
            false
        }
    }

    /**
     * 生成注入终端的环境变量命令。
     *
     * 不做 `exec bash` —— 保持当前 shell，只把 GNU 工具路径前置到 PATH，
     * 这样用户输入 ls/cat/grep 时会优先命中 GNU 版本，系统命令仍可回退。
     * 需要 bash 时用户可自行输入 `bash`。
     */
    fun envScript(ctx: Context): String {
        val bin = binDir(ctx).absolutePath
        val lib = libDir(ctx).absolutePath
        val home = homeDir(ctx).absolutePath
        val tmp = tmpDir(ctx).absolutePath
        return buildString {
            append("export PATH=$bin:\$PATH\n")
            append("export LD_LIBRARY_PATH=$lib:\${LD_LIBRARY_PATH:+\$LD_LIBRARY_PATH:}\n")
            append("export HOME=$home\n")
            append("export TMPDIR=$tmp\n")
            append("export TERM=xterm-256color\n")
            append("export LANG=C.UTF-8\n")
            append("export LC_ALL=C.UTF-8\n")
            append("export PAGER=cat\n")
        }
    }

    /** 一句话自检，写进终端欢迎语，便于确认工具链是否生效 */
    fun banner(ctx: Context): String =
        if (isInstalled(ctx)) "GNU 工具链：已就绪（coreutils / bash / grep / sed / awk / adb）"
        else "GNU 工具链：未就绪，当前使用系统自带命令"

    /**
     * 让 ROOT / shell（Shizuku）身份也能进入应用私有目录执行这些工具。
     *
     * 仅放开 traverse 位（0711）：不给其他应用读权限，它们仍然列不出目录内容。
     */
    private fun ensureReachable(ctx: Context) {
        runCatching { chmod(ctx.filesDir, 0b111_101_101) }        // files: 0755
        runCatching { chmod(ctx.filesDir.parentFile, 0b111_001_001) } // 主目录: 0711
        runCatching { chmod(root(ctx), 0b111_101_101) }
    }

    private fun chmod(f: File?, mode: Int) {
        if (f == null || !f.exists()) return
        runCatching { Os.chmod(f.absolutePath, mode) }
            .onFailure { runCatching { f.setExecutable(true, false); f.setReadable(true, false) } }
    }

    /** 从清单读取预期文件数，仅用于进度显示 */
    private fun readExpectedCount(ctx: Context): Int = try {
        ctx.assets.open(ASSET_MANIFEST).use { it.readBytes() }
            .let { JSONObject(String(it)).optInt("count", 0) }
    } catch (_: Throwable) {
        0
    }
}
