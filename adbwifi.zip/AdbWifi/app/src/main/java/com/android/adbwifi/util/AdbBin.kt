package com.android.adbwifi.util

import android.content.Context
import android.system.Os
import com.android.adbwifi.exec.ExecutionEngine
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipInputStream

/**
 * 内置 adb 运行环境。
 *
 * ## 走过的三个坑（实测结论，别再退回去）
 *
 * 1. filesDir 直接执行 → `inaccessible or not found`
 *    Android 10+ 的 SELinux W^X：app_data_file 不允许 execve，chmod 无效。
 *
 * 2. jniLibs → nativeLibraryDir 后在 filesDir 建符号链接 → 同样失败
 *    放行规则是 `allow appdomain apk_data_file:file rx_file_perms`，
 *    而终端会话是 root 域或 shell 域，不在 appdomain 属性里，拿不到放行。
 *
 * 3. 放到 /sdcard/Android/data/<pkg>/files 让 shell 复制 → 复制失败
 *    Android 11+ 起 /sdcard/Android/data 对 adb shell 与 root 都做了限制，
 *    FUSE 会按调用方 uid 判权，即使 root 也常被拒。
 *
 * ## 现在的做法
 *
 * 应用把二进制解到**自己的 filesDir**（一定写得进去），然后用**提权通道**
 * （ExecutionEngine，即当前工作模式的 root / shell 身份）把它们复制到
 * /data/local/tmp/adbw/bin 并 chmod。
 *
 * 之所以用提权通道而不是让终端会话的 shell 自己复制：
 *   应用进程写不了 /data/local/tmp（SELinux 不允许 app 写 shell_data_file），
 *   而 root/shell 身份既能读 filesDir（我们已放开 traverse）又能写该目录。
 *   复制结果还能拿到 stderr，便于定位，而不是像 shell 里那样静默失败。
 *
 * 终端侧只负责 export PATH，不再做复制。
 *
 * ## 依赖库
 *
 * adb 动态链接（PIE，interp = /system/bin/linker64），10 个 DT_NEEDED 中
 * 6 个系统没有，必须同带（符号级收敛后的最小闭包）：
 *   libc++_shared.so(121 个符号) liblz4.so(12) libzstd.so(9)
 *   libbrotlienc.so(5) libbrotlidec.so(3) libbrotlicommon.so(间接必需 8/6)
 * 另有 3 个 OPENSSL_memory_* 为 WEAK 符号，bionic 下解析为 nullptr，
 * 不需要 libcrypto.so.3（省 4.4MB）。
 *
 * 全部文件在同一目录，打包前已 patchelf 写入 DT_RUNPATH = $ORIGIN，
 * linker 直接在同目录找；envScript 再补 LD_LIBRARY_PATH 做双保险。
 */
object AdbBin {

    private const val VERSION = 1
    private const val ASSET_ZIP = "adbbin.zip"
    private const val ASSET_MANIFEST = "adbbin.manifest.json"
    private const val STAMP = ".version"

    private const val DIR_NAME = "adbin"
    /** shell 侧运行目录：shell_data_file，root/shell 可读写可执行 */
    private const val SHELL_DIR = "/data/local/tmp/adbw"

    private val FILES = arrayOf(
        "adb", "libbrotlicommon.so", "libbrotlidec.so", "libbrotlienc.so",
        "libc++_shared.so", "liblz4.so", "libzstd.so"
    )

    private fun srcDir(ctx: Context): File = File(ctx.filesDir, DIR_NAME)

    /** 应用侧是否已释放（不含 shell 侧是否就绪） */
    fun isInstalled(ctx: Context): Boolean {
        val s = File(srcDir(ctx), STAMP)
        return s.exists() && runCatching { s.readText().trim() }.getOrNull() == VERSION.toString()
    }

    /**
     * 完整准备流程：解包 → 放开目录权限 → 用提权通道复制到 shell 目录 → 验证。
     *
     * 每次进终端都会调用：/data/local/tmp 可能被系统清理，需要时自动重建。
     * 失败不抛异常 —— 终端仍可用（只是没有 adb）。
     *
     * @return shell 目录下的 adb 是否可用
     */
    fun ensureReady(ctx: Context): Boolean {
        if (!extract(ctx)) return false
        publishToShell(ctx)
        return verify(ctx)
    }

    /** 解包到 filesDir，幂等 */
    private fun extract(ctx: Context): Boolean {
        if (isInstalled(ctx)) {
            openForShell(ctx)
            return true
        }
        val dir = srcDir(ctx)
        val staging = File(ctx.filesDir, "$DIR_NAME.installing")
        return try {
            if (staging.exists()) staging.deleteRecursively()
            staging.mkdirs()

            ctx.assets.open(ASSET_ZIP).use { raw ->
                ZipInputStream(raw.buffered()).use { zis ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val e = zis.nextEntry ?: break
                        if (e.isDirectory) {
                            File(staging, e.name).mkdirs()
                            continue
                        }
                        val out = File(staging, e.name)
                        out.parentFile?.mkdirs()
                        out.outputStream().use { os ->
                            while (true) {
                                val n = zis.read(buf)
                                if (n <= 0) break
                                os.write(buf, 0, n)
                            }
                        }
                    }
                }
            }
            staging.listFiles()?.forEach { if (it.isFile) chmod(it, 0b111_101_101) } // 0755

            if (dir.exists()) dir.deleteRecursively()
            if (!staging.renameTo(dir)) {
                staging.copyRecursively(dir, overwrite = true)
                staging.deleteRecursively()
            }
            File(dir, STAMP).writeText(VERSION.toString())
            openForShell(ctx)
            true
        } catch (t: Throwable) {
            AppLog.w("内置 adb 解包失败: ${t.message}")
            runCatching { staging.deleteRecursively() }
            false
        }
    }

    /**
     * 放开目录权限，让 shell（Shizuku，uid 2000）能 traverse 进 filesDir 读文件。
     * 只给 traverse/读，不给写；ROOT 身份不受 DAC 限制，此设置对其无副作用。
     */
    private fun openForShell(ctx: Context) {
        chmod(srcDir(ctx), 0b111_101_101)              // adbin:      0755
        chmod(ctx.filesDir, 0b111_101_101)             // files:      0755
        chmod(ctx.filesDir.parentFile, 0b111_001_001)  // 主目录:     0711
    }

    /** 用提权通道把二进制搬到 /data/local/tmp/adbw/bin */
    private fun publishToShell(ctx: Context): Boolean {
        val src = srcDir(ctx).absolutePath
        val cmd = buildString {
            append("mkdir -p $SHELL_DIR/bin $SHELL_DIR/home $SHELL_DIR/tmp 2>&1\n")
            append("chmod 0777 $SHELL_DIR $SHELL_DIR/bin $SHELL_DIR/home $SHELL_DIR/tmp 2>&1\n")
            for (f in FILES) append("cp -f $src/$f $SHELL_DIR/bin/ 2>&1\n")
            append("chmod 0755 $SHELL_DIR/bin/adb 2>&1\n")
        }
        val r = ExecutionEngine.exec(ctx, cmd, 30)
        if (r.err.isNotBlank()) {
            AppLog.w("内置 adb 复制失败（${r.via}）: ${r.err.lines().first()}")
            return false
        }
        return true
    }

    /** 验证 shell 目录下 adb 真能跑 */
    private fun verify(ctx: Context): Boolean {
        val r = ExecutionEngine.exec(ctx, "$SHELL_DIR/bin/adb version 2>&1", 15)
        val ok = r.out.contains("Android Debug Bridge")
        if (ok) {
            AppLog.ok("内置 adb 就绪：${r.out.lines().first()}")
        } else {
            AppLog.w("内置 adb 不可用: ${r.combined.lines().firstOrNull().orEmpty()}")
        }
        return ok
    }

    /** 终端环境注入：只导出变量，不涉及复制 */
    fun envScript(ctx: Context): String {
        val d = SHELL_DIR
        return buildString {
            append("export PATH=$d/bin:\$PATH\n")
            append("export LD_LIBRARY_PATH=$d/bin\n")
            // adb 在 $HOME/.android/adbkey 存密钥；/data/local/tmp 是 shell 自己的目录，可写
            append("export HOME=$d/home\n")
            append("export TMPDIR=$d/tmp\n")
            append("mkdir -p $d/home $d/tmp 2>/dev/null\n")
            append("chmod 0777 $d/home $d/tmp 2>/dev/null\n")
            // 多身份共用同一份密钥：adb 生成 adbkey 时会 chmod 600，owner 是创建者。
            // 从 ROOT 切到 Shizuku 后 shell 读不了，会重新生成密钥、又要点一次
            // 「允许调试」。这里放宽已存在的密钥，避免重复授权。
            append("mkdir -p $d/home/.android 2>/dev/null\n")
            append("chmod 0777 $d/home/.android 2>/dev/null\n")
            append("chmod 0644 $d/home/.android/adbkey $d/home/.android/adbkey.pub 2>/dev/null\n")
        }
    }

    private fun chmod(f: File?, mode: Int) {
        if (f == null || !f.exists()) return
        runCatching { Os.chmod(f.absolutePath, mode) }
            .onFailure { runCatching { f.setExecutable(true, false); f.setReadable(true, false) } }
    }
}
