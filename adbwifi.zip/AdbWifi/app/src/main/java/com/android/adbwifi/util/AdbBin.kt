package com.android.adbwifi.util

import android.content.Context
import android.system.Os
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipInputStream

/**
 * 内置 adb 运行环境。
 *
 * ## 为什么需要它
 *
 * 多数 ROM 的 /system/bin 里没有 adb，终端里敲 adb 会 command not found。
 * 这里把 MT 管理器「终端扩展包」里的 adb 二进制放进 APK，首次进终端时释放出来。
 *
 * ## 为什么不是只放一个 adb 文件
 *
 * adb 是动态链接的（PIE，interp = /system/bin/linker64），有 10 个 DT_NEEDED。
 * 其中 6 个系统没有，必须一起带上，否则启动即报：
 *     CANNOT LINK EXECUTABLE "adb": library "libzstd.so" not found
 *
 * 打包清单已用 readelf 做过符号级收敛验证，是最小闭包，无冗余：
 *   libc++_shared.so    adb 直接引用 121 个符号
 *   liblz4.so                        12 个
 *   libzstd.so                        9 个
 *   libbrotlienc.so                   5 个
 *   libbrotlidec.so                   3 个
 *   libbrotlicommon.so                间接必需（brotlidec/enc 各引用 8/6 个符号）
 *
 * 另有 3 个 OPENSSL_memory_* 符号虽出现在符号表，但 Bind 为 WEAK，
 * bionic 下解析为 nullptr 且不调用，故不需要 libcrypto.so.3（省 4.4MB）。
 *
 * ## 依赖库怎么被找到（关键）
 *
 * 原包把 .so 命名为 libzstd.so.rename，靠外层设 LD_LIBRARY_PATH。
 * 这里改为打包前用 patchelf 写入 DT_RUNPATH = $ORIGIN/../lib。
 *
 * 选 RUNPATH 而非 LD_LIBRARY_PATH，是因为后者在 Android 上有两个坑：
 *   1. AT_SECURE —— 经 su（setuid）提权后，bionic linker 忽略环境变量里的库路径，
 *      恰好会让 ROOT 模式下的终端失效。
 *   2. linker namespace —— Android 7+ 对应用进程的库搜索路径有白名单。
 * RUNPATH 写在 ELF 内部，两者都不影响。
 *
 * ## 目录权限
 *
 * 终端可能以 Shizuku（shell, uid 2000）身份执行，而应用私有目录默认 0700，
 * shell 进不来。释放后会把主目录放宽为 0711（仅 traverse 位），
 * 不给读权限，其他应用仍列不出目录内容。
 */
object AdbBin {

    /** 资源版本：内置 adb 更新时递增，触发重新释放 */
    private const val VERSION = 1

    private const val ASSET_ZIP = "adbbin.zip"
    private const val ASSET_MANIFEST = "adbbin.manifest.json"
    private const val STAMP = ".version"

    fun root(ctx: Context): File = File(ctx.filesDir, "adbin")
    fun binDir(ctx: Context): File = File(root(ctx), "bin")
    fun libDir(ctx: Context): File = File(root(ctx), "lib")
    fun homeDir(ctx: Context): File = File(root(ctx), "home")
    fun tmpDir(ctx: Context): File = File(root(ctx), "tmp")

    /** 已释放且版本匹配 */
    fun isInstalled(ctx: Context): Boolean {
        val stamp = File(root(ctx), STAMP)
        if (!stamp.exists()) return false
        return runCatching { stamp.readText().trim() }.getOrNull() == VERSION.toString()
    }

    /**
     * 释放 adb。幂等：已安装且版本一致时直接返回 true。
     *
     * 失败不抛异常 —— 终端仍可用（只是没有 adb），不应阻断启动。
     *
     * @param onProgress 进度回调（0-100），在 IO 线程调用，调用方需自行切主线程
     */
    fun install(ctx: Context, onProgress: ((Int) -> Unit)? = null): Boolean {
        if (isInstalled(ctx)) {
            ensureReachable(ctx)
            onProgress?.invoke(100)
            return true
        }
        val dir = root(ctx)
        val staging = File(ctx.filesDir, "adbin.installing")
        return try {
            if (staging.exists()) staging.deleteRecursively()
            staging.mkdirs()

            val expected = readExpectedCount(ctx)
            var done = 0

            ctx.assets.open(ASSET_ZIP).use { raw ->
                ZipInputStream(raw.buffered()).use { zis ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val e = zis.nextEntry ?: break
                        if (e.isDirectory) {
                            File(staging, e.name).mkdirs()
                            continue
                        }
                        val out = File(staging, e.name)
                        out.parentFile?.mkdirs()
                        out.outputStream().use { os ->
                            while (true) {
                                val n = zis.read(buf)
                                if (n <= 0) break
                                os.write(buf, 0, n)
                            }
                        }
                        done++
                        if (expected > 0) onProgress?.invoke((done * 90 / expected).coerceIn(0, 90))
                    }
                }
            }

            // .so 需要可执行位才能被 mmap 映射；adb 需要可执行
            File(staging, "bin").listFiles()?.forEach { chmod(it, 0b111_101_101) } // 0755
            File(staging, "lib").listFiles()?.forEach { chmod(it, 0b111_101_101) } // 0755

            File(staging, "home").mkdirs()
            File(staging, "tmp").mkdirs()
            // home 必须可写：adb 在 $HOME/.android/adbkey 生成密钥对。
            // mkdirs() 的实际权限是 0777 & ~umask，应用进程 umask 常为 0077，
            // 结果就是 0700 —— Shizuku（shell uid 2000）进不来，密钥写不进去，
            // 表现为每次 adb connect 都要在手机上重新点「允许调试」。
            // 所以显式放宽为 0777，不能依赖 umask。
            chmod(File(staging, "home"), 0b111_111_111) // 0777
            chmod(File(staging, "tmp"), 0b111_111_111)  // 0777

            onProgress?.invoke(95)

            // 原子替换：先解到临时目录再改名，避免半份残留
            if (dir.exists()) dir.deleteRecursively()
            if (!staging.renameTo(dir)) {
                staging.copyRecursively(dir, overwrite = true)
                staging.deleteRecursively()
            }

            File(dir, STAMP).writeText(VERSION.toString())
            ensureReachable(ctx)

            onProgress?.invoke(100)
            AppLog.ok("内置 adb 已就绪")
            true
        } catch (t: Throwable) {
            AppLog.w("内置 adb 释放失败: ${t.message}")
            runCatching { staging.deleteRecursively() }
            false
        }
    }

    /**
     * 注入终端的环境变量命令。
     *
     * HOME 是必需的：adb 会在 $HOME/.android/adbkey 生成密钥对。
     * 不设或不可写会导致每次 adb connect 都要在手机上重新点「允许调试」。
     */
    fun envScript(ctx: Context): String {
        val bin = binDir(ctx).absolutePath
        val home = homeDir(ctx).absolutePath
        val tmp = tmpDir(ctx).absolutePath
        return buildString {
            append("export PATH=$bin:\$PATH\n")
            append("export HOME=$home\n")
            append("export TMPDIR=$tmp\n")
            // 多身份共用同一份密钥：
            // adb 生成 adbkey 时会 chmod 600，owner 是创建者。若从 ROOT 切到
            // Shizuku，shell 读不了 root 的 600 文件，会重新生成密钥，于是又
            // 要在手机上点一次「允许调试」。这里把已存在的密钥放宽，避免重复授权。
            // 能读到此目录的只有 root/shell（本身已具备提权），不额外增加风险。
            append("mkdir -p $home/.android 2>/dev/null\n")
            append("chmod 0777 $home/.android 2>/dev/null\n")
            append("chmod 0644 $home/.android/adbkey $home/.android/adbkey.pub 2>/dev/null\n")
        }
    }

    /** 让 root / shell（Shizuku）身份也能进入应用私有目录执行 adb */
    private fun ensureReachable(ctx: Context) {
        runCatching { chmod(ctx.filesDir, 0b111_101_101) }              // files: 0755
        runCatching { chmod(ctx.filesDir.parentFile, 0b111_001_001) }    // 主目录: 0711
        runCatching { chmod(root(ctx), 0b111_101_101) }
    }

    private fun chmod(f: File?, mode: Int) {
        if (f == null || !f.exists()) return
        runCatching { Os.chmod(f.absolutePath, mode) }
            .onFailure { runCatching { f.setExecutable(true, false); f.setReadable(true, false) } }
    }

    /** 从清单读预期文件数，仅用于进度显示 */
    private fun readExpectedCount(ctx: Context): Int = try {
        ctx.assets.open(ASSET_MANIFEST).use { it.readBytes() }
            .let { JSONObject(String(it)).optInt("count", 0) }
    } catch (_: Throwable) {
        0
    }
}
