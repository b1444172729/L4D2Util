package com.android.adbwifi.util

import android.content.Context
import android.system.Os
import com.android.adbwifi.exec.ExecutionEngine
import java.io.File

/**
 * 内置 adb。
 *
 * ## 方案：jniLibs + 普通应用身份执行
 *
 * 这是 MT 管理器 / Termux（APKLF）采用的思路，与本项目前几版都不同：
 *
 * | 版本 | 存放 | 执行身份 | 结果 |
 * |---|---|---|---|
 * | 1 | filesDir | root/shell | W^X 拒绝 exec app_data_file |
 * | 2 | jniLibs+符号链接 | root/shell | 规则只对 appdomain 生效 |
 * | 3 | /data/local/tmp | root/shell | 可用，但必须有提权 |
 * | **4（本版）** | **jniLibs** | **普通 App** | **零权限可用** |
 *
 * ## 为什么现在能成
 *
 * 放行规则是
 *     allow appdomain apk_data_file:file rx_file_perms
 * 关键在 **appdomain**——它是所有普通应用的属性。前几版失败不是存放位置
 * 错了，而是执行者是 root 域 / shell 域（uid 2000），不在这个属性里。
 *
 * 本版把终端默认身份改为普通应用进程（见 ExecutionEngine.openSession），
 * 于是它执行自己 APK 里解压出来的 nativeLibraryDir 内容完全合法：
 *   - 不需要 ROOT
 *   - 不需要 Shizuku
 *   - 不需要 /data/local/tmp 那份拷贝
 *
 * ## 命令名
 *
 * PackageManager 只提取 lib 开头、.so 结尾的文件，所以真实文件叫
 * libadb.so。这里在 filesDir/adbin/bin/ 下建一个名为 adb 的符号链接，
 * execve 解析链接后拿到 apk_data_file 的 inode，因此允许执行。
 * （W^X 只禁 exec，不禁写，filesDir 存密钥没问题。）
 *
 * ## 依赖库
 *
 * adb 动态链接（PIE，interp = /system/bin/linker64），10 个 DT_NEEDED 中
 * 6 个系统没有，必须同带（符号级收敛后的最小闭包）：
 *   libc++_shared.so(121 个符号) liblz4.so(12) libzstd.so(9)
 *   libbrotlienc.so(5) libbrotlidec.so(3) libbrotlicommon.so(间接必需 8/6)
 * 另有 3 个 OPENSSL_memory_* 为 WEAK 符号，bionic 下解析为 nullptr，
 * 不需要 libcrypto.so.3（省 4.4MB）。
 *
 * 全部文件同在 nativeLibraryDir，打包前已 patchelf 写入 DT_RUNPATH=$ORIGIN，
 * linker 直接在同目录找。
 */
object AdbBin {

    private const val LIB_NAME = "libadb.so"
    private const val LINK_NAME = "adb"

    /** 系统解压出的真实可执行文件 */
    private fun realFile(ctx: Context): File? =
        ctx.applicationInfo.nativeLibraryDir?.let { File(it, LIB_NAME) }?.takeIf { it.exists() }

    /** 供 PATH 使用的链接目录 */
    private fun linkDir(ctx: Context): File = File(ctx.filesDir, "adbin/bin")

    fun isInstalled(ctx: Context): Boolean =
        realFile(ctx) != null && File(linkDir(ctx), LINK_NAME).exists()

    /**
     * 建立 adb 命令链接。幂等，几乎瞬时（只建一个符号链接）。
     * 失败不抛异常 —— 终端仍可用（只是没有 adb）。
     */
    fun install(ctx: Context): Boolean {
        val real = realFile(ctx)
        if (real == null) {
            // 非 arm64 设备或库未解压：静默降级
            AppLog.w("未找到 $LIB_NAME，终端不含 adb")
            return false
        }
        return try {
            val dir = linkDir(ctx)
            if (!dir.exists()) dir.mkdirs()
            chmod(dir, 0b111_101_101)
            chmod(File(ctx.filesDir, "adbin"), 0b111_101_101)
            chmod(ctx.filesDir, 0b111_101_101)

            val link = File(dir, LINK_NAME)
            if (runCatching { Os.lstat(link.absolutePath) }.isSuccess) {
                runCatching { Os.remove(link.absolutePath) }
            }
            Os.symlink(real.absolutePath, link.absolutePath)
            AppLog.ok("内置 adb 已就绪")
            true
        } catch (t: Throwable) {
            AppLog.w("内置 adb 链接失败: ${t.message}")
            false
        }
    }

    /** 提权身份下的运行目录：root/shell 执行不了 apk_data_file，需要这份副本 */
    const val ELEVATED_DIR = "/data/local/tmp/adbw"

    private val FILES = arrayOf(
        LIB_NAME, "libbrotlicommon.so", "libbrotlidec.so", "libbrotlienc.so",
        "libc++_shared.so", "liblz4.so", "libzstd.so"
    )

    /**
     * 给提权身份准备一份副本。
     *
     * root / shell 域拿不到 appdomain 的放行，执行不了 nativeLibraryDir 里的
     * apk_data_file，所以额外复制一份到 /data/local/tmp（shell_data_file，
     * root/shell 可读写可执行）。只有提权可用时才调用。
     *
     * @return 副本是否就位
     */
    fun publishElevated(ctx: Context): Boolean {
        val src = ctx.applicationInfo.nativeLibraryDir ?: return false
        val cmd = buildString {
            append("mkdir -p $ELEVATED_DIR/bin 2>&1\n")
            append("chmod 0777 $ELEVATED_DIR $ELEVATED_DIR/bin 2>&1\n")
            for (f in FILES) append("cp -f $src/$f $ELEVATED_DIR/bin/ 2>&1\n")
            // 副本里也要有名为 adb 的可执行文件
            append("cp -f $src/$LIB_NAME $ELEVATED_DIR/bin/adb 2>&1\n")
            append("chmod 0755 $ELEVATED_DIR/bin/adb 2>&1\n")
        }
        val r = ExecutionEngine.exec(ctx, cmd, 30)
        if (r.err.isNotBlank()) {
            AppLog.w("adb 提权副本失败（${r.via}）: ${r.err.lines().first()}")
            return false
        }
        return true
    }

    /**
     * 注入终端的环境变量。
     *
     * PATH 里放两个候选位置，让 shell 自己挑能执行的那个：
     *   1. nativeLibraryDir 的符号链接 —— 普通身份可用（apk_data_file）
     *   2. /data/local/tmp 的副本     —— 提权身份可用（shell_data_file）
     * mksh 在 exec 返回 EACCES 时会继续搜索 PATH 的下一项，所以切换身份后
     * 不需要重新注入环境也能命中正确的那份。
     *
     * HOME/TMPDIR 放 filesDir 下：普通身份可写（W^X 只禁 exec 不禁写）；
     * 提权身份不受 DAC 限制，同样能写。
     */
    fun envScript(ctx: Context): String {
        val link = linkDir(ctx).absolutePath
        val libs = ctx.applicationInfo.nativeLibraryDir.orEmpty()
        val home = File(ctx.filesDir, "adbin/home").absolutePath
        val tmp = File(ctx.filesDir, "adbin/tmp").absolutePath
        return buildString {
            append("export PATH=$link:$ELEVATED_DIR/bin:\$PATH\n")
            append("export LD_LIBRARY_PATH=$libs:$ELEVATED_DIR/bin:\${LD_LIBRARY_PATH:+\$LD_LIBRARY_PATH:}\n")
            append("export HOME=$home\n")
            append("export TMPDIR=$tmp\n")
            append("mkdir -p $home $tmp 2>/dev/null\n")
            append("chmod 0777 $home $tmp 2>/dev/null\n")
            append("mkdir -p $home/.android 2>/dev/null\n")
            append("chmod 0777 $home/.android 2>/dev/null\n")
            append("chmod 0644 $home/.android/adbkey $home/.android/adbkey.pub 2>/dev/null\n")
        }
    }

    private fun chmod(f: File?, mode: Int) {
        if (f == null || !f.exists()) return
        runCatching { Os.chmod(f.absolutePath, mode) }
            .onFailure { runCatching { f.setExecutable(true, false); f.setReadable(true, false) } }
    }
}
