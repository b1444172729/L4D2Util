package com.android.adbwifi.util

import android.content.Context
import android.system.Os
import java.io.File

/**
 * 内置 adb 运行环境。
 *
 * ## 为什么不能用「assets 解压到 filesDir」的常规做法
 *
 * Android 10（targetSdk >= 29）起启用 SELinux W^X：应用自己写进数据目录
 * （files/、cache/）的文件标签是 app_data_file，execve 被拒绝。表现就是
 * 终端里敲 adb 得到 `inaccessible or not found`，而 chmod +x 毫无用处。
 *
 * 绕过方式是 jniLibs 机制：把可执行文件改名成 libXXX.so 放进
 * src/main/jniLibs/<abi>/，安装时由 PackageManager 解压到
 * applicationInfo.nativeLibraryDir（/data/app/.../lib/arm64/），
 * 该目录标签是 apk_data_file，SELinux 明确允许 exec。
 * 这条路跟 targetSdk 无关，也是符合商店政策的做法（Termux 为了绕开这个
 * 限制不得不把 targetSdk 锁死在 28，我们不需要）。
 *
 * ## 依赖库
 *
 * adb 是动态链接的（PIE，interp = /system/bin/linker64），有 10 个 DT_NEEDED，
 * 其中 6 个系统没有，必须一起带（已用 readelf 做过符号级收敛，是最小闭包）：
 *   libc++_shared.so    adb 直接引用 121 个符号
 *   liblz4.so                        12 个
 *   libzstd.so                        9 个
 *   libbrotlienc.so                   5 个
 *   libbrotlidec.so                   3 个
 *   libbrotlicommon.so                间接必需（brotlidec/enc 各引用 8/6 个符号）
 * 另有 3 个 OPENSSL_memory_* 符号 Bind 为 WEAK，bionic 下解析为 nullptr，
 * 不需要 libcrypto.so.3（省 4.4MB）。
 *
 * 这些库与 libadb.so 同在 nativeLibraryDir，打包前已 patchelf 写入
 * DT_RUNPATH = $ORIGIN，linker 直接在同目录找。envScript 里再补一个
 * LD_LIBRARY_PATH 作为双保险（shell 域非 AT_SECURE，环境变量有效）。
 *
 * ## 命令名问题
 *
 * 系统只认 lib 开头、.so 结尾的文件，所以真实文件叫 libadb.so。
 * 这里在 filesDir 下建一个名为 adb 的符号链接指向它——
 * execve 解析符号链接后拿到的是 apk_data_file 的 inode，因此允许执行。
 *
 * ## HOME / TMPDIR
 *
 * adb 会在 $HOME/.android/adbkey 生成密钥对，目录必须可写。
 * 应用私有目录虽能 chmod 0777，但还需看 SELinux 是否允许 shell 写
 * app_data_file，稳妥起见直接用 /data/local/tmp 下的子目录，
 * 由 shell 自己在 envScript 里创建（shell 对自己的 shell_data_file 一定可写）。
 */
object AdbBin {

    private const val LIB_NAME = "libadb.so"
    private const val LINK_NAME = "adb"

    /** native 库目录，形如 /data/app/~~xxx==/pkg-yyy==/lib/arm64 */
    private fun nativeDir(ctx: Context): String? = ctx.applicationInfo.nativeLibraryDir

    /** 真实的可执行文件（由系统安装时解压出来） */
    private fun realFile(ctx: Context): File? =
        nativeDir(ctx)?.let { File(it, LIB_NAME) }?.takeIf { it.exists() }

    /** 供 PATH 使用的链接目录：filesDir/adbin/bin */
    private fun linkDir(ctx: Context): File = File(ctx.filesDir, "adbin/bin")

    /** 已就绪：系统已解压出 libadb.so，且链接已建好 */
    fun isInstalled(ctx: Context): Boolean =
        realFile(ctx) != null && File(linkDir(ctx), LINK_NAME).exists()

    /**
     * 建立 adb 命令链接。幂等，耗时可忽略（只是建一个符号链接）。
     *
     * 失败不抛异常 —— 终端仍可用（只是没有 adb）。
     */
    fun install(ctx: Context): Boolean {
        val real = realFile(ctx)
        if (real == null) {
            // 32 位设备或库未解压：静默降级，不打扰用户
            AppLog.w("未找到 $LIB_NAME（可能非 arm64 设备），终端不含 adb")
            return false
        }
        return try {
            val dir = linkDir(ctx)
            if (!dir.exists()) dir.mkdirs()
            chmod(ctx.filesDir, 0b111_101_101)               // files: 0755
            chmod(ctx.filesDir.parentFile, 0b111_001_001)    // 主目录: 0711
            chmod(File(ctx.filesDir, "adbin"), 0b111_101_101)
            chmod(dir, 0b111_101_101)

            val link = File(dir, LINK_NAME)
            if (link.exists() || runCatching { Os.lstat(link.absolutePath) }.isSuccess) {
                runCatching { Os.remove(link.absolutePath) }
            }
            Os.symlink(real.absolutePath, link.absolutePath)

            AppLog.ok("内置 adb 已就绪")
            true
        } catch (t: Throwable) {
            AppLog.w("内置 adb 链接失败: ${t.message}")
            false
        }
    }

    /**
     * 注入终端的环境变量命令。
     *
     * HOME/TMPDIR 放在 /data/local/tmp 下，由 shell 自己创建：
     * adb 需要写 $HOME/.android/adbkey，用 shell 自己的可写目录最稳。
     */
    fun envScript(ctx: Context): String {
        val link = linkDir(ctx).absolutePath
        val libs = nativeDir(ctx) ?: link
        val base = "/data/local/tmp/adbw"
        return buildString {
            append("export PATH=$link:\$PATH\n")
            append("export LD_LIBRARY_PATH=$libs:\${LD_LIBRARY_PATH:+\$LD_LIBRARY_PATH:}\n")
            append("export HOME=$base/home\n")
            append("export TMPDIR=$base/tmp\n")
            // 目录交给 shell 自己建，权限天然正确
            append("mkdir -p $base/home $base/tmp 2>/dev/null\n")
            append("chmod 0777 $base/home $base/tmp 2>/dev/null\n")
            // 多身份共用同一份密钥：adb 生成 adbkey 时会 chmod 600，owner 是创建者。
            // 从 ROOT 切到 Shizuku 后 shell 读不了，会重新生成密钥、又要点一次
            // 「允许调试」。这里放宽已存在的密钥，避免重复授权。
            append("mkdir -p $base/home/.android 2>/dev/null\n")
            append("chmod 0777 $base/home/.android 2>/dev/null\n")
            append("chmod 0644 $base/home/.android/adbkey $base/home/.android/adbkey.pub 2>/dev/null\n")
        }
    }

    private fun chmod(f: File?, mode: Int) {
        if (f == null || !f.exists()) return
        runCatching { Os.chmod(f.absolutePath, mode) }
            .onFailure { runCatching { f.setExecutable(true, false); f.setReadable(true, false) } }
    }
}
