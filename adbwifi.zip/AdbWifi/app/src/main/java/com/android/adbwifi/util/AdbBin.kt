package com.android.adbwifi.util

import android.content.Context
import android.system.Os
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipInputStream

/**
 * 内置 adb 运行环境。
 *
 * ## 为什么连 jniLibs 方案也不行（实测结论）
 *
 * 前一版把 adb 以 libadb.so 放进 jniLibs，指望安装时解压到 nativeLibraryDir
 * （apk_data_file，SELinux 允许 exec）后在 filesDir 建符号链接调用。
 * 结果终端里仍是 `adb: inaccessible or not found`。
 *
 * 原因：允许 exec apk_data_file 的 SELinux 规则是
 *     allow appdomain apk_data_file:file rx_file_perms
 * 而终端会话不是应用进程——ROOT 模式是 root 域，Shizuku 模式是 **shell 域**
 * （uid 2000）。shell 不在 appdomain 属性里，拿不到这条放行，execve 被拒。
 *
 * ## 现在的做法：把二进制放到 shell 自己的可写可执行目录
 *
 * /data/local/tmp 是 shell_data_file，shell 域对它可读写可执行。
 * 这也是 Shizuku 自己的做法——它的 start.sh 会把 starter 复制到
 * /data/local/tmp 再执行。
 *
 * 但应用进程（untrusted_app）**写不了** /data/local/tmp，所以分两步：
 *   1. 应用把二进制从 assets 解到外部私有目录
 *      （/sdcard/Android/data/<pkg>/files/，sdcardfs，shell 可读——
 *        Shizuku 的 start.sh 正是靠这条路被 adb shell 读到的）
 *   2. 终端会话启动后由 **shell 自己** 复制到 /data/local/tmp/adbw/bin 并
 *      chmod，再前置到 PATH
 *
 * 第 2 步写在 envScript 里，随环境注入一起写进 shell，对用户透明。
 *
 * ## 依赖库
 *
 * adb 动态链接（PIE，interp = /system/bin/linker64），10 个 DT_NEEDED 中
 * 6 个系统没有，必须同带（符号级收敛后的最小闭包）：
 *   libc++_shared.so(121 个符号) liblz4.so(12) libzstd.so(9)
 *   libbrotlienc.so(5) libbrotlidec.so(3) libbrotlicommon.so(间接必需 8/6)
 * 另有 3 个 OPENSSL_memory_* 为 WEAK 符号，bionic 下解析为 nullptr，
 * 不需要 libcrypto.so.3（省 4.4MB）。
 *
 * 全部文件副本放在同一目录，打包前已 patchelf 写入 DT_RUNPATH = $ORIGIN，
 * linker 直接在同目录找；envScript 再补 LD_LIBRARY_PATH 做双保险。
 */
object AdbBin {

    /** 资源版本：内置 adb 更新时递增，触发重新释放 */
    private const val VERSION = 1

    private const val ASSET_ZIP = "adbbin.zip"
    private const val ASSET_MANIFEST = "adbbin.manifest.json"
    private const val STAMP = ".version"
    private const val DIR_NAME = "adbin"

    /** shell 侧运行目录 */
    private const val SHELL_DIR = "/data/local/tmp/adbw"

    /**
     * 暂存目录：优先外部私有目录（shell 可读）， degrade 到内部 filesDir。
     * 返回 null 表示彻底不可用。
     */
    private fun stagedDir(ctx: Context): File? =
        ctx.getExternalFilesDir(DIR_NAME) ?: File(ctx.filesDir, DIR_NAME)

    /** 应用侧是否已释放 */
    fun isInstalled(ctx: Context): Boolean {
        val d = stagedDir(ctx) ?: return false
        return File(d, STAMP).let { it.exists() && runCatching { it.readText().trim() }.getOrNull() == VERSION.toString() }
    }

    /**
     * 把 adb 及依赖解到暂存目录。幂等，已安装且版本一致时直接返回。
     * 失败不抛异常 —— 终端仍可用（只是没有 adb）。
     */
    fun install(ctx: Context): Boolean {
        if (isInstalled(ctx)) return true
        val dir = stagedDir(ctx) ?: run {
            AppLog.w("无可用暂存目录，终端不含 adb")
            return false
        }
        val staging = File(dir.parentFile, "$DIR_NAME.installing")
        return try {
            if (staging.exists()) staging.deleteRecursively()
            staging.mkdirs()

            ctx.assets.open(ASSET_ZIP).use { raw ->
                ZipInputStream(raw.buffered()).use { zis ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val e = zis.nextEntry ?: break
                        if (e.isDirectory) {
                            File(staging, e.name).mkdirs()
                            continue
                        }
                        val out = File(staging, e.name)
                        out.parentFile?.mkdirs()
                        out.outputStream().use { os ->
                            while (true) {
                                val n = zis.read(buf)
                                if (n <= 0) break
                                os.write(buf, 0, n)
                            }
                        }
                    }
                }
            }
            staging.listFiles()?.forEach { if (it.isFile) chmod(it, 0b111_101_101) } // 0755

            if (dir.exists()) dir.deleteRecursively()
            if (!staging.renameTo(dir)) {
                staging.copyRecursively(dir, overwrite = true)
                staging.deleteRecursively()
            }
            chmod(dir, 0b111_101_101)
            // 外部目录在 sdcard 上，父级本身对 shell 可读，无需额外 chmod；
            // 内部目录则需要放开 traverse，让 shell 能进入。
            if (dir.parentFile == ctx.filesDir) {
                chmod(ctx.filesDir, 0b111_101_101)
                chmod(ctx.filesDir.parentFile, 0b111_001_001)
            }
            File(dir, STAMP).writeText(VERSION.toString())

            AppLog.ok("内置 adb 已释放：${dir.absolutePath}")
            true
        } catch (t: Throwable) {
            AppLog.w("内置 adb 释放失败: ${t.message}")
            runCatching { staging.deleteRecursively() }
            false
        }
    }

    /**
     * 环境注入命令：由 shell 自己把二进制搬到 /data/local/tmp 再前置 PATH。
     *
     * 之所以不在应用侧搬，是因为应用进程写不进 /data/local/tmp；
     * 之所以不直接 exec 暂存目录，是因为 /sdcard 挂载为 noexec。
     */
    fun envScript(ctx: Context): String {
        val src = stagedDir(ctx)?.absolutePath.orEmpty()
        val d = SHELL_DIR
        return buildString {
            append("D=$d\n")
            append("mkdir -p $d/bin $d/home $d/tmp 2>/dev/null\n")
            append("chmod 0777 $d $d/bin $d/home $d/tmp 2>/dev/null\n")

            // 依次尝试暂存目录与 nativeLibraryDir，哪个读得到用哪个
            val native = ctx.applicationInfo.nativeLibraryDir.orEmpty()
            append("for S in \"$src\" \"$native\"; do\n")
            append("  [ -z \"\$S\" ] && continue\n")
            append("  [ -f \"\$S/adb\" ] || continue\n")
            append("  for f in adb libbrotlicommon.so libbrotlidec.so libbrotlienc.so libc++_shared.so liblz4.so libzstd.so; do\n")
            append("    cp \"\$S/\$f\" $d/bin/ 2>/dev/null\n")
            append("  done\n")
            append("  break\n")
            append("done\n")
            append("chmod 0755 $d/bin/adb $d/bin/*.so 2>/dev/null\n")

            append("export PATH=$d/bin:\$PATH\n")
            append("export LD_LIBRARY_PATH=$d/bin\n")
            // adb 在 $HOME/.android/adbkey 存密钥，目录必须可写；
            // /data/local/tmp 是 shell 自己的目录，权限天然正确
            append("export HOME=$d/home\n")
            append("export TMPDIR=$d/tmp\n")
            // 多身份共用同一份密钥：adb 生成 adbkey 时会 chmod 600，owner 是创建者。
            // 从 ROOT 切到 Shizuku 后 shell 读不了，会重新生成密钥、又要点一次
            // 「允许调试」。这里放宽已存在的密钥，避免重复授权。
            append("mkdir -p $d/home/.android 2>/dev/null\n")
            append("chmod 0777 $d/home/.android 2>/dev/null\n")
            append("chmod 0644 $d/home/.android/adbkey $d/home/.android/adbkey.pub 2>/dev/null\n")

            // 自检：把成败直接打出来，失败时能看到卡在哪一步
            append("if command -v adb >/dev/null 2>&1; then\n")
            append("  echo \"[adb] \$(adb version 2>&1 | head -1)\"\n")
            append("else\n")
            append("  echo \"[adb] 不可用：未能把二进制复制到 $d/bin\"\n")
            append("fi\n")
        }
    }

    private fun chmod(f: File?, mode: Int) {
        if (f == null || !f.exists()) return
        runCatching { Os.chmod(f.absolutePath, mode) }
            .onFailure { runCatching { f.setExecutable(true, false); f.setReadable(true, false) } }
    }
}
