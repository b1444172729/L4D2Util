-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class rikka.shizuku.** { *; }
-keep class moe.shizuku.server.** { *; }
