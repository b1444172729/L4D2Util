package com.android.mcpremote.tools;

import android.content.Context;

import com.android.mcpremote.exec.ExecutionEngine;
import com.android.mcpremote.exec.ShellResult;
import com.android.mcpremote.server.ToolDefinition;
import com.android.mcpremote.util.Json;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** 网络工具：HTTP 请求、ping、WiFi 信息 */
public final class NetworkTools {

    public static List<ToolDefinition> all(Context ctx) {
        List<ToolDefinition> list = new ArrayList<>();

        list.add(new ToolDefinition("dev_net_http",
                "发起 HTTP 请求（基于 curl）。支持 GET/POST 等方法、自定义 Header 和请求体。" +
                        "可用于调用外部 API、测试网络连通性。",
                Json.schema(Json.obj(
                        "url", Json.strProp("请求地址"),
                        "method", Json.strProp("请求方法，默认 GET"),
                        "headers", Json.strProp("自定义 Header，多个用换行分隔，格式 Key: Value"),
                        "body", Json.strProp("请求体（POST/PUT 时使用）"),
                        "timeoutSec", Json.intProp("超时秒数，默认 15")),
                        "url")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                String url = a.optString("url", "");
                if (url.isEmpty()) return Json.errorResult("url 不能为空");
                String method = a.optString("method", "GET").toUpperCase();
                int timeout = a.optInt("timeoutSec", 15);
                StringBuilder cmd = new StringBuilder("curl -s -i --max-time ").append(timeout);
                if (!"GET".equals(method)) cmd.append(" -X ").append(method);
                String headers = a.optString("headers", "");
                if (!headers.isEmpty()) {
                    for (String h : headers.split("\n")) {
                        String t = h.trim();
                        if (!t.isEmpty()) cmd.append(" -H \"").append(t.replace("\"", "\\\"")).append('"');
                    }
                }
                String body = a.optString("body", "");
                if (!body.isEmpty()) {
                    cmd.append(" -d '").append(body.replace("'", "'\\''")).append("'");
                }
                cmd.append(" \"").append(url.replace("\"", "\\\"")).append('"');
                ShellResult r = engine.exec(cmd.toString(), null, timeout + 10);
                String out = r.stdout == null ? "" : r.stdout;
                if (out.length() > 6000) out = out.substring(0, 6000) + "\n...(已截断)";
                return Json.textResult(out.isEmpty() ? "(无响应)" : out);
            }
        });

        list.add(new ToolDefinition("dev_net_ping",
                "测试到指定主机的网络连通性（ping）。返回延迟与丢包情况。",
                Json.schema(Json.obj(
                        "host", Json.strProp("目标主机或 IP"),
                        "count", Json.intProp("ping 次数，默认 4")),
                        "host")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                String host = a.optString("host", "");
                if (host.isEmpty()) return Json.errorResult("host 不能为空");
                int count = a.optInt("count", 4);
                ShellResult r = engine.exec("ping -c " + count + " -W 3 " + host, null, 30);
                String out = (r.stdout == null ? "" : r.stdout)
                        + (r.stderr == null ? "" : r.stderr);
                return Json.textResult(out.trim().isEmpty() ? "(无结果)" : out.trim());
            }
        });

        list.add(new ToolDefinition("dev_net_wifi_info",
                "获取 WiFi 连接信息（SSID、信号强度、IP、网关、DNS 等）。",
                Json.schema(new JSONObject())) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                StringBuilder sb = new StringBuilder();
                ShellResult wifi = engine.exec("dumpsys wifi | grep -E 'SSID|BSSID|RSSI|ip_address|link_speed|NetworkInfo|frequency'", null, 25);
                if (wifi.stdout != null && !wifi.stdout.trim().isEmpty()) {
                    sb.append("=== WiFi ===\n").append(wifi.stdout.trim()).append("\n\n");
                }
                ShellResult ip = engine.exec("ip addr show wlan0", null, 15);
                if (ip.stdout != null && !ip.stdout.trim().isEmpty()) {
                    sb.append("=== 接口 wlan0 ===\n").append(ip.stdout.trim()).append("\n\n");
                }
                ShellResult route = engine.exec("ip route", null, 15);
                if (route.stdout != null && !route.stdout.trim().isEmpty()) {
                    sb.append("=== 路由 ===\n").append(route.stdout.trim());
                }
                String res = sb.toString();
                return Json.textResult(res.trim().isEmpty() ? "(未获取到 WiFi 信息)" : res);
            }
        });

        return list;
    }
}
