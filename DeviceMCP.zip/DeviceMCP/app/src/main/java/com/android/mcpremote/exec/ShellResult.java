package com.android.mcpremote.exec;

/** 命令执行结果 */
public class ShellResult {
    public final int exitCode;
    public final String stdout;
    public final String stderr;
    /** 实际使用的执行器：root / shizuku / app */
    public final String via;

    public ShellResult(int exitCode, String stdout, String stderr, String via) {
        this.exitCode = exitCode;
        this.stdout = stdout == null ? "" : stdout;
        this.stderr = stderr == null ? "" : stderr;
        this.via = via;
    }

    public boolean ok() { return exitCode == 0; }

    public String combined() {
        StringBuilder sb = new StringBuilder();
        if (!stdout.isEmpty()) sb.append(stdout);
        if (!stderr.isEmpty()) {
            if (sb.length() > 0) sb.append('\n');
            sb.append("[stderr] ").append(stderr);
        }
        return sb.toString();
    }

    public String toText() {
        return "exit=" + exitCode + " via=" + via + "\n" + combined();
    }
}
