package com.android.mcpremote.server;

import android.content.Context;

import com.android.mcpremote.util.AppLog;
import com.android.mcpremote.util.Json;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * 极简 HTTP/1.1 + MCP（JSON-RPC 2.0）服务器。
 *
 * 关键设计：
 *  - 默认绑定 0.0.0.0，使局域网设备可直接访问（仅绑 127.0.0.1 时外部不可达）
 *  - 单端点 POST /mcp，兼容 Streamable HTTP；支持 application/json 与 text/event-stream
 *  - 可选 Bearer Token 鉴权
 */
public class McpHttpServer {

    public static final String PROTOCOL_VERSION = "2025-06-18";
    public static final String SERVER_NAME = "mcp-remote";
    public static final String SERVER_VERSION = "1.0.0";

    private final Context ctx;
    private final String token;
    private final AtomicBoolean running = new AtomicBoolean(false);
    private volatile ServerSocket serverSocket;
    private ExecutorService pool;
    private Thread acceptThread;
    private volatile int boundPort = -1;

    public interface StateListener {
        void onStarted(int port);
        void onStopped();
    }

    private StateListener listener;

    public McpHttpServer(Context ctx, String token) {
        this.ctx = ctx.getApplicationContext();
        this.token = token == null ? "" : token.trim();
        ToolRegistry.init(this.ctx);
    }

    public void setStateListener(StateListener l) { this.listener = l; }

    public boolean isRunning() { return running.get(); }
    public int getPort() { return boundPort; }

    /** 启动服务：bindHost 传 "0.0.0.0" 允许局域网访问，传 "127.0.0.1" 仅本机 */
    public synchronized void start(int port, String bindHost) throws IOException {
        if (running.get()) return;
        if (bindHost == null || bindHost.trim().isEmpty()) bindHost = "0.0.0.0";

        serverSocket = new ServerSocket();
        serverSocket.setReuseAddress(true);
        serverSocket.bind(new InetSocketAddress(bindHost, port));
        boundPort = serverSocket.getLocalPort();
        running.set(true);
        pool = Executors.newCachedThreadPool(r -> {
            Thread t = new Thread(r, "mcp-conn");
            t.setDaemon(true);
            return t;
        });
        acceptThread = new Thread(this::acceptLoop, "mcp-accept");
        acceptThread.setDaemon(true);
        acceptThread.start();
        AppLog.i("MCP 服务已启动: " + bindHost + ":" + boundPort + " 鉴权=" + (token.isEmpty() ? "关闭" : "开启"));
        if (listener != null) listener.onStarted(boundPort);
    }

    public synchronized void stop() {
        if (!running.get()) return;
        running.set(false);
        try { if (serverSocket != null) serverSocket.close(); } catch (Throwable ignored) {}
        try { if (pool != null) pool.shutdownNow(); } catch (Throwable ignored) {}
        try { if (acceptThread != null) acceptThread.interrupt(); } catch (Throwable ignored) {}
        AppLog.i("MCP 服务已停止");
        if (listener != null) listener.onStopped();
    }

    private void acceptLoop() {
        while (running.get() && serverSocket != null && !serverSocket.isClosed()) {
            try {
                Socket s = serverSocket.accept();
                s.setSoTimeout(30000);
                pool.submit(() -> handle(s));
            } catch (IOException e) {
                if (running.get()) AppLog.w("accept 异常: " + e.getMessage());
            } catch (Throwable t) {
                AppLog.w("accept 提交失败: " + t.getMessage());
            }
        }
    }

    // ---------------- HTTP 层 ----------------

    private void handle(Socket socket) {
        try (socket) {
            InputStream is = socket.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));

            String requestLine = br.readLine();
            if (requestLine == null || requestLine.isEmpty()) return;

            String method = "", path = "";
            String[] parts = requestLine.split(" ");
            if (parts.length >= 2) { method = parts[0]; path = parts[1]; }

            int contentLength = 0;
            String accept = "";
            String auth = "";
            String line;
            while ((line = br.readLine()) != null && !line.isEmpty()) {
                String lower = line.toLowerCase(Locale.US);
                if (lower.startsWith("content-length:")) {
                    contentLength = parseIntSafe(line.substring(line.indexOf(':') + 1).trim());
                } else if (lower.startsWith("accept:")) {
                    accept = line.substring(line.indexOf(':') + 1).trim();
                } else if (lower.startsWith("authorization:")) {
                    auth = line.substring(line.indexOf(':') + 1).trim();
                }
            }

            String body = "";
            if (contentLength > 0) {
                char[] buf = new char[contentLength];
                int read = 0;
                while (read < contentLength) {
                    int n = br.read(buf, read, contentLength - read);
                    if (n < 0) break;
                    read += n;
                }
                body = new String(buf, 0, read);
            }

            // 鉴权
            if (!token.isEmpty()) {
                boolean ok = auth.toLowerCase(Locale.US).startsWith("bearer " + token.toLowerCase(Locale.US));
                if (!ok) {
                    sendJson(socket, 401, Json.obj("error", "unauthorized",
                            "message", "缺少或错误的 Bearer Token"));
                    return;
                }
            }

            boolean wantSse = accept.toLowerCase(Locale.US).contains("text/event-stream");

            // 健康检查
            if (path.startsWith("/health")) {
                sendJson(socket, 200, Json.obj("ok", true, "running", running.get(),
                        "port", boundPort, "tools", ToolRegistry.count(), "auth", !token.isEmpty()));
                return;
            }

            // MCP 端点
            if (!path.startsWith("/mcp")) {
                sendJson(socket, 404, Json.obj("error", "not_found", "message", "请使用 /mcp 端点"));
                return;
            }

            if ("GET".equalsIgnoreCase(method)) {
                // Streamable HTTP 规范下 GET 用于建立流；此处返回 405 并提示用 POST
                sendJson(socket, 405, Json.obj("error", "method_not_allowed",
                        "message", "本实现使用无状态模式，请通过 POST /mcp 调用"));
                return;
            }

            if (!"POST".equalsIgnoreCase(method)) {
                sendJson(socket, 405, Json.obj("error", "method_not_allowed"));
                return;
            }

            JSONObject response;
            try {
                JSONObject req = new JSONObject(body.isEmpty() ? "{}" : body);
                response = handleJsonRpc(req);
            } catch (Exception e) {
                response = Json.obj("jsonrpc", "2.0", "id", JSONObject.NULL,
                        "error", Json.obj("code", -32700, "message", "JSON 解析失败: " + e.getMessage()));
            }

            if (response == null) {
                // 通知类消息（如 notifications/initialized）无需响应体
                sendJson(socket, 202, Json.obj("accepted", true));
            } else if (wantSse) {
                sendSse(socket, response);
            } else {
                sendJson(socket, 200, response);
            }
        } catch (Throwable t) {
            AppLog.e("连接处理异常", t);
        }
    }

    private int parseIntSafe(String s) {
        try { return Integer.parseInt(s.trim()); } catch (Exception e) { return 0; }
    }

    private void sendJson(Socket s, int code, JSONObject body) {
        try {
            byte[] payload = body.toString().getBytes(StandardCharsets.UTF_8);
            String reason = code == 200 ? "OK" : (code == 401 ? "Unauthorized" : (code == 405 ? "Method Not Allowed" : (code == 404 ? "Not Found" : "Error")));
            StringBuilder head = new StringBuilder();
            head.append("HTTP/1.1 ").append(code).append(' ').append(reason).append("\r\n");
            head.append("Content-Type: application/json; charset=utf-8\r\n");
            head.append("Content-Length: ").append(payload.length).append("\r\n");
            head.append("Cache-Control: no-store\r\n");
            head.append("Access-Control-Allow-Origin: *\r\n");
            head.append("Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n");
            head.append("Access-Control-Allow-Headers: Content-Type, Authorization, Mcp-Session-Id, Mcp-Protocol-Version\r\n");
            head.append("Connection: close\r\n\r\n");
            OutputStream os = s.getOutputStream();
            os.write(head.toString().getBytes(StandardCharsets.UTF_8));
            os.write(payload);
            os.flush();
        } catch (Throwable ignored) {}
    }

    private void sendSse(Socket s, JSONObject body) {
        try {
            byte[] payload = ("event: message\ndata: " + body.toString() + "\n\n").getBytes(StandardCharsets.UTF_8);
            StringBuilder head = new StringBuilder();
            head.append("HTTP/1.1 200 OK\r\n");
            head.append("Content-Type: text/event-stream; charset=utf-8\r\n");
            head.append("Content-Length: ").append(payload.length).append("\r\n");
            head.append("Cache-Control: no-cache\r\n");
            head.append("Connection: close\r\n\r\n");
            OutputStream os = s.getOutputStream();
            os.write(head.toString().getBytes(StandardCharsets.UTF_8));
            os.write(payload);
            os.flush();
        } catch (Throwable ignored) {}
    }

    // ---------------- MCP / JSON-RPC 层 ----------------

    private JSONObject handleJsonRpc(JSONObject req) throws Exception {
        Object idRaw = req.opt("id");
        Object id = req.has("id") ? idRaw : JSONObject.NULL;
        String method = req.optString("method", "");
        JSONObject params = req.optJSONObject("params");
        if (params == null) params = new JSONObject();

        JSONObject result;
        switch (method) {
            case "initialize":
                result = Json.obj(
                        "protocolVersion", PROTOCOL_VERSION,
                        "serverInfo", Json.obj("name", SERVER_NAME, "version", SERVER_VERSION),
                        "capabilities", Json.obj("tools", Json.obj("listChanged", false)),
                        "instructions", "MCP远程：通过 MCP 控制本机。建议先调用 dev_device_info 与 dev_mcp_status 了解环境。");
                break;
            case "ping":
                result = new JSONObject();
                break;
            case "tools/list":
                JSONArray tools = ToolRegistry.listJson();
                result = Json.obj("tools", tools);
                break;
            case "tools/call": {
                String name = params.optString("name", "");
                JSONObject args = params.optJSONObject("arguments");
                AppLog.i("tools/call -> " + name);
                result = ToolRegistry.dispatch(ctx, name, args == null ? new JSONObject() : args);
                break;
            }
            case "resources/list":
                result = Json.obj("resources", new JSONArray());
                break;
            case "prompts/list":
                result = Json.obj("prompts", new JSONArray());
                break;
            case "notifications/initialized":
                // 通知类消息不返回 result
                return null;
            default:
                JSONObject err = Json.obj("code", -32601, "message", "不支持的方法: " + method);
                return Json.obj("jsonrpc", "2.0", "id", id, "error", err);
        }

        JSONObject resp = new JSONObject();
        resp.put("jsonrpc", "2.0");
        resp.put("id", id);
        resp.put("result", result);
        return resp;
    }
}
