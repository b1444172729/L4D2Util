package com.android.mcpremote.util;

import org.json.JSONArray;
import org.json.JSONObject;

/** JSON 构造小工具（基于 org.json，Android 内置，无需额外依赖） */
public final class Json {

    public static JSONObject obj(Object... kv) {
        JSONObject o = new JSONObject();
        for (int i = 0; i + 1 < kv.length; i += 2) {
            try { o.put(String.valueOf(kv[i]), kv[i + 1]); } catch (Exception ignored) {}
        }
        return o;
    }

    /** 构造 MCP inputSchema：object + properties + required */
    public static JSONObject schema(JSONObject properties, String... required) {
        JSONObject o = new JSONObject();
        try {
            o.put("type", "object");
            o.put("properties", properties == null ? new JSONObject() : properties);
            JSONArray req = new JSONArray();
            if (required != null) for (String r : required) req.put(r);
            o.put("required", req);
            o.put("additionalProperties", false);
        } catch (Exception ignored) {}
        return o;
    }

    /** 字符串属性 */
    public static JSONObject strProp(String desc) {
        return obj("type", "string", "description", desc);
    }

    public static JSONObject intProp(String desc) {
        return obj("type", "integer", "description", desc);
    }

    public static JSONObject boolProp(String desc) {
        return obj("type", "boolean", "description", desc);
    }

    /** MCP 文本结果 */
    public static JSONObject textResult(String text) {
        JSONObject content = new JSONObject();
        try {
            content.put("type", "text");
            content.put("text", text);
            JSONArray arr = new JSONArray();
            arr.put(content);
            JSONObject r = new JSONObject();
            r.put("content", arr);
            r.put("isError", false);
            return r;
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    public static JSONObject errorResult(String text) {
        try {
            JSONObject content = new JSONObject();
            content.put("type", "text");
            content.put("text", text);
            JSONArray arr = new JSONArray();
            arr.put(content);
            JSONObject r = new JSONObject();
            r.put("content", arr);
            r.put("isError", true);
            return r;
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    public static String pretty(JSONObject o) {
        try { return o.toString(2); } catch (Exception e) { return o.toString(); }
    }

    /**
     * 通用缩进格式化：同时支持 JSONObject / JSONArray。
     * 关键：org.json 的 toString(int) 会抛受检异常 JSONException，
     * 直接调用会导致编译失败（unreported exception），此处统一吞掉。
     */
    public static String fmt(Object o) {
        if (o == null) return "";
        try {
            if (o instanceof JSONObject) return ((JSONObject) o).toString(2);
            if (o instanceof JSONArray) return ((JSONArray) o).toString(2);
            return String.valueOf(o);
        } catch (Exception e) {
            return String.valueOf(o);
        }
    }
}
