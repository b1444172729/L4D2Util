package com.android.mcpremote.tools;

import android.content.Context;

import com.android.mcpremote.exec.ExecutionEngine;
import com.android.mcpremote.exec.ShellResult;
import com.android.mcpremote.server.ToolDefinition;
import com.android.mcpremote.util.AppLog;
import com.android.mcpremote.util.Json;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * UI 自动化工具（adb / shell 通道，不依赖无障碍服务）
 *
 * 实现方式：
 *  - 控件树：uiautomator dump 导出窗口 XML，再解析出各节点文本与坐标
 *  - 点击/滑动：input tap / input swipe（走 shell 的 INJECT_EVENTS 权限）
 *  - 文本输入：ASCII 用 input text；非 ASCII（如中文）走剪贴板 + KEYCODE_PASTE
 *  - 按键：input keyevent
 *
 * 稳定性关键：dumpXml() 内置重试。uiautomator dump 在窗口切换、应用启动动画
 * 期间会偶发失败（这正是多步骤操作链的主要失败来源），重试 3 次可覆盖绝大多数情况。
 *
 * 权限要求：ROOT 或 Shizuku（adb 模式）。普通应用权限无法注入输入事件。
 */
public final class UiTools {

    /** dump 文件存放路径 */
    private static final String DUMP_PATH = "/sdcard/mcp_window_dump.xml";
    /** dump 重试次数 */
    private static final int DUMP_RETRY = 3;

    public static List<ToolDefinition> all(Context ctx) {
        List<ToolDefinition> list = new ArrayList<>();

        // ---------- 控件树 ----------
        list.add(new ToolDefinition("dev_ui_nodes",
                "导出当前屏幕的控件树（文本、描述、类名、坐标）。基于 uiautomator dump，" +
                        "无需无障碍服务，但比无障碍版本慢（约 1-2 秒）。",
                Json.schema(Json.obj("maxNodes", Json.intProp("最大节点数，默认 200")), "maxNodes")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                String xml = dumpXml(engine);
                if (xml == null) return Json.errorResult("导出控件树失败，需 ROOT 或 Shizuku 权限");
                int max = a.optInt("maxNodes", 200);
                JSONArray arr = parseNodes(xml, max);
                if (arr.length() == 0) return Json.errorResult("未解析到任何节点（窗口可能为空）");
                return Json.textResult("节点数 " + arr.length() + "：\n" + Json.fmt(arr));
            }
        });

        // ---------- 仅提取屏幕文本（轻量读屏）----------
        list.add(new ToolDefinition("dev_ui_get_text",
                "只提取当前屏幕上的全部文本内容（不含坐标），适合快速判断当前界面，返回内容比控件树小很多。",
                Json.schema(new JSONObject())) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                String xml = dumpXml(engine);
                if (xml == null) return Json.errorResult("导出控件树失败，需 ROOT 或 Shizuku 权限");
                JSONArray arr = new JSONArray();
                Pattern p = Pattern.compile("<node\\s+([^>]*?)/>");
                Matcher m = p.matcher(xml);
                while (m.find()) {
                    String at = m.group(1);
                    String t = attr(at, "text");
                    String d = attr(at, "content-desc");
                    if (!t.isEmpty()) arr.put(t);
                    if (!d.isEmpty()) arr.put("[desc]" + d);
                }
                if (arr.length() == 0) return Json.textResult("(屏幕无文本)");
                return Json.textResult("屏幕文本（" + arr.length() + " 条）：\n" + Json.fmt(arr));
            }
        });

        // ---------- 判断文本是否存在 ----------
        list.add(new ToolDefinition("dev_ui_exists",
                "判断指定文本/描述是否出现在当前屏幕上（不执行点击），返回 true/false 及匹配到的节点数。",
                Json.schema(Json.obj(
                        "text", Json.strProp("要查找的文本或描述"),
                        "exact", Json.boolProp("是否完全匹配，默认 false（子串匹配）")),
                        "text")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                String text = a.optString("text", "");
                boolean exact = a.optBoolean("exact", false);
                String xml = dumpXml(engine);
                if (xml == null) return Json.errorResult("导出控件树失败，需 ROOT 或 Shizuku 权限");
                int n = countMatch(xml, text, exact);
                JSONObject o = Json.obj("text", text, "exists", n > 0, "count", n);
                return Json.textResult(Json.fmt(o));
            }
        });

        // ---------- 等待文本出现 ----------
        list.add(new ToolDefinition("dev_ui_wait_text",
                "等待指定文本出现，超时则返回失败。用于替代「固定等待 N 秒」，大幅提升多步骤操作成功率。" +
                        "例如启动应用后等待其主界面元素出现。",
                Json.schema(Json.obj(
                        "text", Json.strProp("要等待出现的文本"),
                        "timeoutMs", Json.intProp("超时毫秒，默认 10000"),
                        "exact", Json.boolProp("是否完全匹配，默认 false")),
                        "text")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                String text = a.optString("text", "");
                int timeout = a.optInt("timeoutMs", 10000);
                boolean exact = a.optBoolean("exact", false);
                long deadline = System.currentTimeMillis() + timeout;
                int tries = 0;
                while (System.currentTimeMillis() < deadline) {
                    String xml = dumpXml(engine);
                    if (xml != null && countMatch(xml, text, exact) > 0) {
                        JSONObject o = Json.obj("found", true, "text", text,
                                "waitedMs", timeout - (deadline - System.currentTimeMillis()),
                                "dumpTries", tries + 1);
                        return Json.textResult("文本已出现：\n" + Json.fmt(o));
                    }
                    tries++;
                    try { Thread.sleep(600); } catch (InterruptedException e) { break; }
                }
                return Json.errorResult("等待超时（" + timeout + "ms），文本未出现: " + text);
            }
        });

        // ---------- 等待文本消失 ----------
        list.add(new ToolDefinition("dev_ui_wait_gone",
                "等待指定文本从屏幕消失（例如等待加载提示、弹窗关闭），超时返回失败。",
                Json.schema(Json.obj(
                        "text", Json.strProp("要等待消失的文本"),
                        "timeoutMs", Json.intProp("超时毫秒，默认 10000")),
                        "text")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                String text = a.optString("text", "");
                int timeout = a.optInt("timeoutMs", 10000);
                long deadline = System.currentTimeMillis() + timeout;
                while (System.currentTimeMillis() < deadline) {
                    String xml = dumpXml(engine);
                    if (xml != null && countMatch(xml, text, false) == 0) {
                        return Json.textResult("文本已消失: " + text);
                    }
                    try { Thread.sleep(600); } catch (InterruptedException e) { break; }
                }
                return Json.errorResult("等待超时（" + timeout + "ms），文本仍在屏幕上: " + text);
            }
        });

        // ---------- 按文本点击 ----------
        list.add(new ToolDefinition("dev_ui_click_text",
                "按文本点击控件：先导出控件树，找到文本匹配的节点，再点击其中心坐标。",
                Json.schema(Json.obj(
                        "text", Json.strProp("要匹配的文本或描述"),
                        "exact", Json.boolProp("是否完全匹配，默认 false（子串匹配）")),
                        "text")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                String text = a.optString("text", "");
                boolean exact = a.optBoolean("exact", false);
                String xml = dumpXml(engine);
                if (xml == null) return Json.errorResult("导出控件树失败，需 ROOT 或 Shizuku 权限");
                int[] center = findCenter(xml, text, exact);
                if (center == null) return Json.errorResult("未找到包含文本的节点: " + text);
                ShellResult r = engine.exec("input tap " + center[0] + " " + center[1], null, 15);
                if (r.ok()) {
                    return Json.textResult("已点击「" + text + "」于 (" + center[0] + "," + center[1] + ")");
                }
                return Json.errorResult("点击失败：" + r.combined());
            }
        });

        // ---------- 按 resource-id 点击 ----------
        list.add(new ToolDefinition("dev_ui_click_id",
                "按 resource-id 点击控件（如 com.xxx:id/btn_ok）。比按文本点击更稳定，适合有固定 id 的按钮。",
                Json.schema(Json.obj("id", Json.strProp("控件的 resource-id")), "id")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                String id = a.optString("id", "");
                String xml = dumpXml(engine);
                if (xml == null) return Json.errorResult("导出控件树失败，需 ROOT 或 Shizuku 权限");
                int[] center = findByAttr(xml, "resource-id", id, true);
                if (center == null) return Json.errorResult("未找到 resource-id 匹配的节点: " + id);
                ShellResult r = engine.exec("input tap " + center[0] + " " + center[1], null, 15);
                return r.ok() ? Json.textResult("已点击 id=" + id + " 于 (" + center[0] + "," + center[1] + ")")
                              : Json.errorResult("点击失败：" + r.combined());
            }
        });

        // ---------- 按 content-desc 点击 ----------
        list.add(new ToolDefinition("dev_ui_click_desc",
                "按 content-desc（内容描述）点击控件，适合图标类按钮（无文字，只有描述）。",
                Json.schema(Json.obj("desc", Json.strProp("控件的 content-desc")), "desc")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                String desc = a.optString("desc", "");
                String xml = dumpXml(engine);
                if (xml == null) return Json.errorResult("导出控件树失败，需 ROOT 或 Shizuku 权限");
                int[] center = findByAttr(xml, "content-desc", desc, false);
                if (center == null) return Json.errorResult("未找到 content-desc 匹配的节点: " + desc);
                ShellResult r = engine.exec("input tap " + center[0] + " " + center[1], null, 15);
                return r.ok() ? Json.textResult("已点击 desc=" + desc + " 于 (" + center[0] + "," + center[1] + ")")
                              : Json.errorResult("点击失败：" + r.combined());
            }
        });

        // ---------- 滚动查找并点击 ----------
        list.add(new ToolDefinition("dev_ui_scroll_to",
                "在列表中滚动查找指定文本，找到后自动点击。解决目标在屏幕外不可见的问题" +
                        "（如长列表、文件管理器中靠下的文件夹）。找不到会在滚动若干次后返回失败。",
                Json.schema(Json.obj(
                        "text", Json.strProp("要查找并点击的文本"),
                        "maxScrolls", Json.intProp("最大滚动次数，默认 5"),
                        "direction", Json.strProp("滚动方向：up（上滑，看下方内容）/ down（下滑，看上方内容），默认 up")),
                        "text")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                String text = a.optString("text", "");
                int maxScrolls = a.optInt("maxScrolls", 5);
                String dir = a.optString("direction", "up");
                int[] wh = screenSize(engine);
                int w = wh[0], h = wh[1];
                for (int i = 0; i <= maxScrolls; i++) {
                    String xml = dumpXml(engine);
                    if (xml != null) {
                        int[] center = findCenter(xml, text, false);
                        if (center != null) {
                            ShellResult r = engine.exec("input tap " + center[0] + " " + center[1], null, 15);
                            JSONObject o = Json.obj("found", true, "scrolls", i,
                                    "at", center[0] + "," + center[1], "clicked", r.ok());
                            return Json.textResult("已找到并点击「" + text + "」：\n" + Json.fmt(o));
                        }
                    }
                    if (i == maxScrolls) break;
                    // 执行一次滚动
                    String swipe;
                    if ("down".equals(dir)) {
                        swipe = "input swipe " + (w / 2) + " " + (int) (h * 0.25) + " "
                                + (w / 2) + " " + (int) (h * 0.8) + " 400";
                    } else {
                        swipe = "input swipe " + (w / 2) + " " + (int) (h * 0.8) + " "
                                + (w / 2) + " " + (int) (h * 0.25) + " 400";
                    }
                    engine.exec(swipe, null, 15);
                    try { Thread.sleep(700); } catch (InterruptedException ignored) {}
                }
                return Json.errorResult("滚动 " + maxScrolls + " 次后仍未找到: " + text);
            }
        });

        // ---------- 坐标点击 ----------
        list.add(new ToolDefinition("dev_ui_click_xy", "按屏幕坐标点击。",
                Json.schema(Json.obj("x", Json.intProp("横坐标px"), "y", Json.intProp("纵坐标px")), "x", "y")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                int x = a.optInt("x", 0), y = a.optInt("y", 0);
                ShellResult r = engine.exec("input tap " + x + " " + y, null, 15);
                return r.ok() ? Json.textResult("已点击 (" + x + "," + y + ")")
                              : Json.errorResult("点击失败：" + r.combined());
            }
        });

        // ---------- 长按 ----------
        list.add(new ToolDefinition("dev_ui_long_click",
                "长按指定坐标（或按文本/描述自动定位后长按）。用于弹出上下文菜单、进入多选模式等。",
                Json.schema(Json.obj(
                        "x", Json.intProp("横坐标px；若提供 text 则忽略"),
                        "y", Json.intProp("纵坐标px；若提供 text 则忽略"),
                        "text", Json.strProp("要长按的文本（提供时自动定位坐标）"),
                        "durationMs", Json.intProp("长按时长毫秒，默认 800")),
                        "x", "y")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                long dur = a.optLong("durationMs", 800);
                int x, y;
                String text = a.optString("text", "");
                if (!text.isEmpty()) {
                    String xml = dumpXml(engine);
                    if (xml == null) return Json.errorResult("导出控件树失败，需 ROOT 或 Shizuku 权限");
                    int[] ct = findCenter(xml, text, false);
                    if (ct == null) return Json.errorResult("未找到文本: " + text);
                    x = ct[0]; y = ct[1];
                } else {
                    x = a.optInt("x", 0); y = a.optInt("y", 0);
                }
                // 长按 = 起终点相同、时长较长的 swipe
                ShellResult r = engine.exec(
                        "input swipe " + x + " " + y + " " + x + " " + y + " " + dur, null, 20);
                return r.ok() ? Json.textResult("已长按 (" + x + "," + y + ") " + dur + "ms")
                              : Json.errorResult("长按失败：" + r.combined());
            }
        });

        // ---------- 滑动 ----------
        list.add(new ToolDefinition("dev_ui_swipe", "在屏幕上滑动（翻页、下拉刷新、上滑返回等）。",
                Json.schema(Json.obj(
                        "x1", Json.intProp("起点X"), "y1", Json.intProp("起点Y"),
                        "x2", Json.intProp("终点X"), "y2", Json.intProp("终点Y"),
                        "durationMs", Json.intProp("滑动时长毫秒，默认 400")),
                        "x1", "y1", "x2", "y2")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                int x1 = a.optInt("x1"), y1 = a.optInt("y1");
                int x2 = a.optInt("x2"), y2 = a.optInt("y2");
                long dur = a.optLong("durationMs", 400);
                ShellResult r = engine.exec(
                        "input swipe " + x1 + " " + y1 + " " + x2 + " " + y2 + " " + dur, null, 20);
                return r.ok() ? Json.textResult("已滑动 (" + x1 + "," + y1 + ") → (" + x2 + "," + y2 + ")")
                              : Json.errorResult("滑动失败：" + r.combined());
            }
        });

        // ---------- 文本输入 ----------
        list.add(new ToolDefinition("dev_ui_input",
                "向当前获得焦点的输入框输入文本。中文等非 ASCII 会自动改用剪贴板粘贴方式。",
                Json.schema(Json.obj("text", Json.strProp("要输入的文本")), "text")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                String text = a.optString("text", "");
                if (text.isEmpty()) return Json.errorResult("文本为空");
                ShellResult r = inputText(engine, text);
                return r.ok() ? Json.textResult("已输入文本")
                              : Json.errorResult("输入失败：" + r.combined());
            }
        });

        // ---------- 按键 ----------
        list.add(new ToolDefinition("dev_ui_key",
                "执行按键操作：back / home / recents / notifications / menu / power / enter。",
                Json.schema(Json.obj("key",
                        Json.strProp("按键名：back|home|recents|notifications|menu|power|enter")), "key")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                String key = a.optString("key", "back").toLowerCase();
                String cmd = keyCommand(key);
                if (cmd == null) return Json.errorResult("不支持的按键: " + key);
                ShellResult r = engine.exec(cmd, null, 15);
                return r.ok() ? Json.textResult("已执行: " + key)
                              : Json.errorResult("执行失败：" + r.combined());
            }
        });

        // ---------- 截图（保存文件）----------
        list.add(new ToolDefinition("dev_ui_screenshot",
                "截取当前屏幕并保存到手机存储，返回文件路径。需 ROOT 或 Shizuku 权限。",
                Json.schema(Json.obj("path", Json.strProp("保存路径，默认 /sdcard/mcp_screen.png")), "path")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                String path = a.optString("path", "/sdcard/mcp_screen.png");
                ShellResult r = engine.exec("screencap -p " + path, null, 25);
                if (!r.ok()) return Json.errorResult("截图失败：" + r.combined());
                ShellResult ls = engine.exec("ls -l " + path, null, 10);
                JSONObject o = Json.obj("path", path, "detail", ls.stdout);
                return Json.textResult("截图已保存：\n" + Json.fmt(o));
            }
        });

        // ---------- 截图（base64）----------
        list.add(new ToolDefinition("dev_ui_screenshot_b64",
                "截屏并以 base64 字符串返回（可直接作为图像内容分析）。" +
                        "注意：完整截屏 base64 体积较大，会占用较多 token；" +
                        "超过 maxKb 时只返回文件路径，请改用 dev_ui_get_text 或 dev_ui_nodes 读取界面。",
                Json.schema(Json.obj(
                        "maxKb", Json.intProp("base64 大小上限(KB)，默认 200；超出则只返回路径")), "maxKb")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                int maxKb = a.optInt("maxKb", 200);
                String path = "/sdcard/mcp_screen_b64.png";
                ShellResult r = engine.exec("screencap -p " + path, null, 25);
                if (!r.ok()) return Json.errorResult("截图失败：" + r.combined());
                ShellResult b = engine.exec("base64 " + path, null, 30);
                String b64 = b.stdout == null ? "" : b.stdout.replaceAll("\\s", "");
                int kb = b64.length() * 3 / 4 / 1024;
                if (kb > maxKb) {
                    return Json.errorResult("截图 base64 约 " + kb + "KB，超过上限 " + maxKb
                            + "KB，已保存为文件: " + path
                            + "。建议改用 dev_ui_get_text 或 dev_ui_nodes 读取界面内容。");
                }
                return Json.textResult("data:image/png;base64," + b64);
            }
        });

        // ---------- 当前前台应用 ----------
        list.add(new ToolDefinition("dev_ui_foreground",
                "获取当前前台应用的包名与 Activity，用于判断当前处于哪个界面。",
                Json.schema(new JSONObject())) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                ShellResult r = engine.exec("dumpsys activity activities | grep mResumedActivity", null, 15);
                String out = r.stdout == null ? "" : r.stdout.trim();
                if (out.isEmpty()) {
                    ShellResult r2 = engine.exec("dumpsys activity top | grep ACTIVITY", null, 15);
                    out = r2.stdout == null ? "" : r2.stdout.trim();
                }
                JSONObject o = Json.obj("raw", out.isEmpty() ? "(未获取到)" : out);
                return Json.textResult(Json.fmt(o));
            }
        });

        return list;
    }

    // ---------------- 辅助 ----------------

    /**
     * 执行 uiautomator dump 并读回 XML 内容（带重试）。
     * 窗口切换/启动动画期间 dump 会偶发失败，重试可显著提升多步骤操作的成功率。
     */
    private static String dumpXml(ExecutionEngine engine) {
        for (int i = 0; i < DUMP_RETRY; i++) {
            engine.exec("rm -f " + DUMP_PATH, null, 10);
            ShellResult d = engine.exec("uiautomator dump " + DUMP_PATH, null, 30);
            if (!d.ok()) {
                try { Thread.sleep(400); } catch (InterruptedException ignored) {}
                continue;
            }
            ShellResult c = engine.exec("cat " + DUMP_PATH, null, 20);
            if (c.stdout != null && !c.stdout.isEmpty() && c.stdout.contains("<node")) {
                return c.stdout;
            }
            try { Thread.sleep(400); } catch (InterruptedException ignored) {}
        }
        AppLog.w("uiautomator dump 失败，已重试 " + DUMP_RETRY + " 次");
        return null;
    }

    /** 获取屏幕宽高 */
    private static int[] screenSize(ExecutionEngine engine) {
        ShellResult r = engine.exec("wm size", null, 10);
        String s = r.stdout == null ? "" : r.stdout;
        Matcher m = Pattern.compile("(\\d+)x(\\d+)").matcher(s);
        if (m.find()) {
            try {
                return new int[]{Integer.parseInt(m.group(1)), Integer.parseInt(m.group(2))};
            } catch (NumberFormatException ignored) {}
        }
        return new int[]{1080, 1920};
    }

    /** 解析 dump XML 中的节点，提取 text / desc / class / bounds */
    private static JSONArray parseNodes(String xml, int max) {
        JSONArray arr = new JSONArray();
        Pattern p = Pattern.compile("<node\\s+([^>]*?)/>");
        Matcher m = p.matcher(xml);
        while (m.find() && arr.length() < max) {
            String attrs = m.group(1);
            String text = attr(attrs, "text");
            String desc = attr(attrs, "content-desc");
            String cls = attr(attrs, "class");
            String bounds = attr(attrs, "bounds");
            boolean meaningful = (!text.isEmpty()) || (!desc.isEmpty()) || bounds != null;
            if (!meaningful) continue;
            arr.put(Json.obj(
                    "text", text,
                    "desc", desc,
                    "cls", cls,
                    "bounds", bounds == null ? "" : bounds
            ));
        }
        return arr;
    }

    /** 统计匹配的节点数 */
    private static int countMatch(String xml, String text, boolean exact) {
        if (text == null || text.isEmpty()) return 0;
        int n = 0;
        Pattern p = Pattern.compile("<node\\s+([^>]*?)/>");
        Matcher m = p.matcher(xml);
        while (m.find()) {
            String at = m.group(1);
            String t = attr(at, "text");
            String d = attr(at, "content-desc");
            boolean hit = exact ? (t.equals(text) || d.equals(text))
                                : (t.contains(text) || d.contains(text));
            if (hit) n++;
        }
        return n;
    }

    /** 按文本查找节点，返回其中心坐标；找不到返回 null */
    private static int[] findCenter(String xml, String text, boolean exact) {
        if (text == null || text.isEmpty()) return null;
        Pattern p = Pattern.compile("<node\\s+([^>]*?)/>");
        Matcher m = p.matcher(xml);
        String fallbackBounds = null;
        while (m.find()) {
            String attrs = m.group(1);
            String t = attr(attrs, "text");
            String d = attr(attrs, "content-desc");
            boolean hit = exact ? (t.equals(text) || d.equals(text))
                                : (t.contains(text) || d.contains(text));
            if (!hit) continue;
            String bounds = attr(attrs, "bounds");
            int[] c = centerOf(bounds);
            if (c != null) {
                if (attr(attrs, "clickable").equals("true")) return c;
                if (fallbackBounds == null) fallbackBounds = bounds;
            }
        }
        return fallbackBounds == null ? null : centerOf(fallbackBounds);
    }

    /** 按指定属性查找节点中心坐标 */
    private static int[] findByAttr(String xml, String attrName, String value, boolean exact) {
        if (value == null || value.isEmpty()) return null;
        Pattern p = Pattern.compile("<node\\s+([^>]*?)/>");
        Matcher m = p.matcher(xml);
        while (m.find()) {
            String attrs = m.group(1);
            String v = attr(attrs, attrName);
            boolean hit = exact ? v.equals(value) : v.contains(value);
            if (!hit) continue;
            int[] c = centerOf(attr(attrs, "bounds"));
            if (c != null) return c;
        }
        return null;
    }

    /** 从 bounds="[x1,y1][x2,y2]" 解析中心点 */
    private static int[] centerOf(String bounds) {
        if (bounds == null) return null;
        Pattern p = Pattern.compile("\\[(\\d+),(\\d+)\\]\\[(\\d+),(\\d+)\\]");
        Matcher m = p.matcher(bounds);
        if (!m.find()) return null;
        try {
            int x1 = Integer.parseInt(m.group(1));
            int y1 = Integer.parseInt(m.group(2));
            int x2 = Integer.parseInt(m.group(3));
            int y2 = Integer.parseInt(m.group(4));
            int cx = (x1 + x2) / 2;
            int cy = (y1 + y2) / 2;
            if (cx < 0 || cy < 0) return null;
            return new int[]{cx, cy};
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /** 提取 XML 属性值 */
    private static String attr(String attrs, String name) {
        Pattern p = Pattern.compile(name + "=\"([^\"]*)\"");
        Matcher m = p.matcher(attrs);
        return m.find() ? m.group(1) : "";
    }

    /**
     * 输入文本。
     * input text 只支持 ASCII，含非 ASCII（中文等）时改用剪贴板 + 粘贴。
     */
    private static ShellResult inputText(ExecutionEngine engine, String text) {
        if (isAscii(text)) {
            String escaped = text.replace(" ", "%s").replace("\"", "\\\"");
            ShellResult r = engine.exec("input text \"" + escaped + "\"", null, 20);
            if (r.ok()) return r;
        }
        String safe = text.replace("\"", "\\\"");
        ShellResult clip = engine.exec("cmd clipboard set \"" + safe + "\"", null, 15);
        if (!clip.ok()) {
            return new ShellResult(-1, "", "无法写入剪贴板，且 input text 不支持该文本：" + clip.combined(), "ui");
        }
        return engine.exec("input keyevent 279", null, 15); // KEYCODE_PASTE
    }

    private static boolean isAscii(String s) {
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) > 127) return false;
        }
        return true;
    }

    /** 按键名 → shell 命令 */
    private static String keyCommand(String key) {
        switch (key) {
            case "back": return "input keyevent 4";
            case "home": return "input keyevent 3";
            case "recents": return "input keyevent 187";
            case "notifications": return "cmd statusbar expand-notifications";
            case "menu": return "input keyevent 82";
            case "power": return "input keyevent 26";
            case "enter": return "input keyevent 66";
            default: return null;
        }
    }
}
