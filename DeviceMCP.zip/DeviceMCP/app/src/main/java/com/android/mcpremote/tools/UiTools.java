package com.android.mcpremote.tools;

import android.content.Context;

import com.android.mcpremote.exec.ExecutionEngine;
import com.android.mcpremote.exec.ShellResult;
import com.android.mcpremote.server.ToolDefinition;
import com.android.mcpremote.util.Json;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * UI 自动化工具（adb / shell 通道，不依赖无障碍服务）
 *
 * 实现方式：
 *  - 控件树：uiautomator dump 导出窗口 XML，再解析出各节点文本与坐标
 *  - 点击/滑动：input tap / input swipe（走 shell 的 INJECT_EVENTS 权限）
 *  - 文本输入：ASCII 用 input text；非 ASCII（如中文）走剪贴板 + KEYCODE_PASTE
 *  - 按键：input keyevent
 *
 * 权限要求：ROOT 或 Shizuku（adb 模式）。普通应用权限无法注入输入事件。
 */
public final class UiTools {

    /** dump 文件存放路径 */
    private static final String DUMP_PATH = "/sdcard/mcp_window_dump.xml";

    public static List<ToolDefinition> all(Context ctx) {
        List<ToolDefinition> list = new ArrayList<>();

        // ---------- 控件树 ----------
        list.add(new ToolDefinition("dev_ui_nodes",
                "导出当前屏幕的控件树（文本、描述、类名、坐标）。基于 uiautomator dump，" +
                        "无需无障碍服务，但比无障碍版本慢（约 1-2 秒）。",
                Json.schema(Json.obj("maxNodes", Json.intProp("最大节点数，默认 200")), "maxNodes")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                String xml = dumpXml(engine);
                if (xml == null) return Json.errorResult("导出控件树失败，需 ROOT 或 Shizuku 权限");
                int max = a.optInt("maxNodes", 200);
                JSONArray arr = parseNodes(xml, max);
                if (arr.length() == 0) return Json.errorResult("未解析到任何节点（窗口可能为空）");
                return Json.textResult("节点数 " + arr.length() + "：\n" + Json.fmt(arr));
            }
        });

        // ---------- 按文本点击 ----------
        list.add(new ToolDefinition("dev_ui_click_text",
                "按文本点击控件：先导出控件树，找到文本匹配的节点，再点击其中心坐标。",
                Json.schema(Json.obj(
                        "text", Json.strProp("要匹配的文本或描述"),
                        "exact", Json.boolProp("是否完全匹配，默认 false（子串匹配）")),
                        "text")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                String text = a.optString("text", "");
                boolean exact = a.optBoolean("exact", false);
                String xml = dumpXml(engine);
                if (xml == null) return Json.errorResult("导出控件树失败，需 ROOT 或 Shizuku 权限");
                int[] center = findCenter(xml, text, exact);
                if (center == null) return Json.errorResult("未找到包含文本的节点: " + text);
                ShellResult r = engine.exec("input tap " + center[0] + " " + center[1], null, 15);
                if (r.ok()) {
                    return Json.textResult("已点击「" + text + "」于 (" + center[0] + "," + center[1] + ")");
                }
                return Json.errorResult("点击失败：" + r.combined());
            }
        });

        // ---------- 坐标点击 ----------
        list.add(new ToolDefinition("dev_ui_click_xy", "按屏幕坐标点击。",
                Json.schema(Json.obj("x", Json.intProp("横坐标px"), "y", Json.intProp("纵坐标px")), "x", "y")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                int x = a.optInt("x", 0), y = a.optInt("y", 0);
                ShellResult r = engine.exec("input tap " + x + " " + y, null, 15);
                return r.ok() ? Json.textResult("已点击 (" + x + "," + y + ")")
                              : Json.errorResult("点击失败：" + r.combined());
            }
        });

        // ---------- 滑动 ----------
        list.add(new ToolDefinition("dev_ui_swipe", "在屏幕上滑动（翻页、下拉刷新、上滑返回等）。",
                Json.schema(Json.obj(
                        "x1", Json.intProp("起点X"), "y1", Json.intProp("起点Y"),
                        "x2", Json.intProp("终点X"), "y2", Json.intProp("终点Y"),
                        "durationMs", Json.intProp("滑动时长毫秒，默认 400")),
                        "x1", "y1", "x2", "y2")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                int x1 = a.optInt("x1"), y1 = a.optInt("y1");
                int x2 = a.optInt("x2"), y2 = a.optInt("y2");
                long dur = a.optLong("durationMs", 400);
                ShellResult r = engine.exec(
                        "input swipe " + x1 + " " + y1 + " " + x2 + " " + y2 + " " + dur, null, 20);
                return r.ok() ? Json.textResult("已滑动 (" + x1 + "," + y1 + ") → (" + x2 + "," + y2 + ")")
                              : Json.errorResult("滑动失败：" + r.combined());
            }
        });

        // ---------- 文本输入 ----------
        list.add(new ToolDefinition("dev_ui_input",
                "向当前获得焦点的输入框输入文本。中文等非 ASCII 会自动改用剪贴板粘贴方式。",
                Json.schema(Json.obj("text", Json.strProp("要输入的文本")), "text")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                String text = a.optString("text", "");
                if (text.isEmpty()) return Json.errorResult("文本为空");
                ShellResult r = inputText(engine, text);
                return r.ok() ? Json.textResult("已输入文本")
                              : Json.errorResult("输入失败：" + r.combined());
            }
        });

        // ---------- 按键 ----------
        list.add(new ToolDefinition("dev_ui_key",
                "执行按键操作：back / home / recents / notifications / menu / power / enter。",
                Json.schema(Json.obj("key",
                        Json.strProp("按键名：back|home|recents|notifications|menu|power|enter")), "key")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                String key = a.optString("key", "back").toLowerCase();
                String cmd = keyCommand(key);
                if (cmd == null) return Json.errorResult("不支持的按键: " + key);
                ShellResult r = engine.exec(cmd, null, 15);
                return r.ok() ? Json.textResult("已执行: " + key)
                              : Json.errorResult("执行失败：" + r.combined());
            }
        });

        // ---------- 截图 ----------
        list.add(new ToolDefinition("dev_ui_screenshot",
                "截取当前屏幕并保存到手机存储，返回文件路径。需 ROOT 或 Shizuku 权限。",
                Json.schema(Json.obj("path", Json.strProp("保存路径，默认 /sdcard/mcp_screen.png")), "path")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                String path = a.optString("path", "/sdcard/mcp_screen.png");
                ShellResult r = engine.exec("screencap -p " + path, null, 25);
                if (!r.ok()) return Json.errorResult("截图失败：" + r.combined());
                // 确认文件存在
                ShellResult ls = engine.exec("ls -l " + path, null, 10);
                JSONObject o = Json.obj("path", path, "detail", ls.stdout);
                return Json.textResult("截图已保存：\n" + Json.fmt(o));
            }
        });

        // ---------- 当前前台应用 ----------
        list.add(new ToolDefinition("dev_ui_foreground",
                "获取当前前台应用的包名与 Activity，用于判断当前处于哪个界面。",
                Json.schema(new JSONObject())) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                ShellResult r = engine.exec("dumpsys activity activities | grep mResumedActivity", null, 15);
                String out = r.stdout == null ? "" : r.stdout.trim();
                if (out.isEmpty()) {
                    ShellResult r2 = engine.exec("dumpsys activity top | grep ACTIVITY", null, 15);
                    out = r2.stdout == null ? "" : r2.stdout.trim();
                }
                JSONObject o = Json.obj("raw", out.isEmpty() ? "(未获取到)" : out);
                return Json.textResult(Json.fmt(o));
            }
        });

        return list;
    }

    // ---------------- 辅助 ----------------

    /** 执行 uiautomator dump 并读回 XML 内容 */
    private static String dumpXml(ExecutionEngine engine) {
        // 先删除旧文件，避免读到过期内容
        engine.exec("rm -f " + DUMP_PATH, null, 10);
        ShellResult d = engine.exec("uiautomator dump " + DUMP_PATH, null, 30);
        if (!d.ok()) return null;
        ShellResult c = engine.exec("cat " + DUMP_PATH, null, 20);
        if (c.stdout == null || c.stdout.isEmpty()) return null;
        return c.stdout;
    }

    /** 解析 dump XML 中的节点，提取 text / desc / class / bounds */
    private static JSONArray parseNodes(String xml, int max) {
        JSONArray arr = new JSONArray();
        // 匹配 <node ... /> 自闭合节点
        Pattern p = Pattern.compile("<node\\s+([^>]*?)/>");
        Matcher m = p.matcher(xml);
        while (m.find() && arr.length() < max) {
            String attrs = m.group(1);
            String text = attr(attrs, "text");
            String desc = attr(attrs, "content-desc");
            String cls = attr(attrs, "class");
            String bounds = attr(attrs, "bounds");
            boolean meaningful = (!text.isEmpty()) || (!desc.isEmpty()) || bounds != null;
            if (!meaningful) continue;
            arr.put(Json.obj(
                    "text", text,
                    "desc", desc,
                    "cls", cls,
                    "bounds", bounds == null ? "" : bounds
            ));
        }
        return arr;
    }

    /** 按文本查找节点，返回其中心坐标；找不到返回 null */
    private static int[] findCenter(String xml, String text, boolean exact) {
        if (text == null || text.isEmpty()) return null;
        Pattern p = Pattern.compile("<node\\s+([^>]*?)/>");
        Matcher m = p.matcher(xml);
        String fallbackBounds = null;
        while (m.find()) {
            String attrs = m.group(1);
            String t = attr(attrs, "text");
            String d = attr(attrs, "content-desc");
            boolean hit;
            if (exact) {
                hit = t.equals(text) || d.equals(text);
            } else {
                hit = t.contains(text) || d.contains(text);
            }
            if (!hit) continue;
            String bounds = attr(attrs, "bounds");
            int[] c = centerOf(bounds);
            if (c != null) {
                // 优先返回可点击的节点
                if (attr(attrs, "clickable").equals("true")) return c;
                if (fallbackBounds == null) {
                    fallbackBounds = bounds;
                }
            }
        }
        return fallbackBounds == null ? null : centerOf(fallbackBounds);
    }

    /** 从 bounds="[x1,y1][x2,y2]" 解析中心点 */
    private static int[] centerOf(String bounds) {
        if (bounds == null) return null;
        Pattern p = Pattern.compile("\\[(\\d+),(\\d+)\\]\\[(\\d+),(\\d+)\\]");
        Matcher m = p.matcher(bounds);
        if (!m.find()) return null;
        try {
            int x1 = Integer.parseInt(m.group(1));
            int y1 = Integer.parseInt(m.group(2));
            int x2 = Integer.parseInt(m.group(3));
            int y2 = Integer.parseInt(m.group(4));
            int cx = (x1 + x2) / 2;
            int cy = (y1 + y2) / 2;
            if (cx < 0 || cy < 0) return null;
            return new int[]{cx, cy};
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /** 提取 XML 属性值 */
    private static String attr(String attrs, String name) {
        Pattern p = Pattern.compile(name + "=\"([^\"]*)\"");
        Matcher m = p.matcher(attrs);
        return m.find() ? m.group(1) : "";
    }

    /**
     * 输入文本。
     * input text 只支持 ASCII，含非 ASCII（中文等）时改用剪贴板 + 粘贴。
     */
    private static ShellResult inputText(ExecutionEngine engine, String text) {
        if (isAscii(text)) {
            // 空格需转义，否则会被当作参数分隔符
            String escaped = text.replace(" ", "%s").replace("\"", "\\\"");
            ShellResult r = engine.exec("input text \"" + escaped + "\"", null, 20);
            if (r.ok()) return r;
            // 失败则回退到剪贴板方式
        }
        // 剪贴板 + 粘贴（支持中文）
        String safe = text.replace("\"", "\\\"");
        ShellResult clip = engine.exec("cmd clipboard set \"" + safe + "\"", null, 15);
        if (!clip.ok()) {
            return new ShellResult(-1, "", "无法写入剪贴板，且 input text 不支持该文本：" + clip.combined(), "ui");
        }
        return engine.exec("input keyevent 279", null, 15); // KEYCODE_PASTE
    }

    private static boolean isAscii(String s) {
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) > 127) return false;
        }
        return true;
    }

    /** 按键名 → shell 命令 */
    private static String keyCommand(String key) {
        switch (key) {
            case "back": return "input keyevent 4";             // KEYCODE_BACK
            case "home": return "input keyevent 3";             // KEYCODE_HOME
            case "recents": return "input keyevent 187";        // KEYCODE_APP_SWITCH
            case "notifications": return "cmd statusbar expand-notifications";
            case "menu": return "input keyevent 82";            // KEYCODE_MENU
            case "power": return "input keyevent 26";           // KEYCODE_POWER
            case "enter": return "input keyevent 66";           // KEYCODE_ENTER
            default: return null;
        }
    }
}
