package com.android.mcpremote.tools;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.provider.Settings;

import com.android.mcpremote.exec.ExecutionEngine;
import com.android.mcpremote.exec.ShellResult;
import com.android.mcpremote.server.ToolDefinition;
import com.android.mcpremote.util.Json;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** 应用管理类工具 */
public final class AppTools {

    public static List<ToolDefinition> all(Context ctx) {
        List<ToolDefinition> list = new ArrayList<>();

        list.add(new ToolDefinition("dev_app_list", "列出已安装应用（包名、名称、版本、是否系统应用）。",
                Json.schema(Json.obj(
                        "includeSystem", Json.boolProp("是否包含系统应用，默认 false"),
                        "keyword", Json.strProp("按包名或名称过滤，可为空")))) {
            @Override public JSONObject call(Context c, JSONObject a) {
                PackageManager pm = c.getPackageManager();
                boolean sys = a.optBoolean("includeSystem", false);
                String kw = a.optString("keyword", "");
                List<PackageInfo> ps = pm.getInstalledPackages(0);
                JSONArray arr = new JSONArray();
                for (PackageInfo pi : ps) {
                    ApplicationInfo ai = pi.applicationInfo;
                    boolean isSys = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                    if (isSys && !sys) continue;
                    String label = pm.getApplicationLabel(ai).toString();
                    if (!kw.isEmpty() && !(label.toLowerCase().contains(kw.toLowerCase())
                            || pi.packageName.toLowerCase().contains(kw.toLowerCase()))) continue;
                    arr.put(Json.obj("package", pi.packageName, "name", label,
                            "versionName", pi.versionName, "versionCode", pi.versionCode, "system", isSys));
                }
                return Json.textResult("共 " + arr.length() + " 个应用：\n" + Json.fmt(arr));
            }
        });

        list.add(new ToolDefinition("dev_app_info", "获取指定应用的详细信息（版本、权限、安装时间、首次安装时间）。",
                Json.schema(Json.obj("package", Json.strProp("应用包名")), "package")) {
            @Override public JSONObject call(Context c, JSONObject a) throws Exception {
                String pkg = a.optString("package", "");
                PackageManager pm = c.getPackageManager();
                PackageInfo pi = pm.getPackageInfo(pkg, PackageManager.GET_PERMISSIONS);
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
                JSONArray perms = new JSONArray();
                if (pi.requestedPermissions != null) for (String p : pi.requestedPermissions) perms.put(p);
                JSONObject o = Json.obj(
                        "package", pkg,
                        "name", pm.getApplicationLabel(pi.applicationInfo).toString(),
                        "versionName", pi.versionName,
                        "versionCode", pi.versionCode,
                        "firstInstallTime", sdf.format(new java.util.Date(pi.firstInstallTime)),
                        "lastUpdateTime", sdf.format(new java.util.Date(pi.lastUpdateTime)),
                        "system", (pi.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0,
                        "sourceDir", pi.applicationInfo.sourceDir,
                        "dataDir", pi.applicationInfo.dataDir,
                        "permissions", perms
                );
                return Json.textResult(Json.fmt(o));
            }
        });

        list.add(new ToolDefinition("dev_app_launch", "启动指定应用（通过包名获取启动 Intent）。",
                Json.schema(Json.obj("package", Json.strProp("应用包名")), "package")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                String pkg = a.optString("package", "");
                Intent launch = c.getPackageManager().getLaunchIntentForPackage(pkg);
                if (launch == null) return Json.errorResult("无法启动（未找到启动 Activity）: " + pkg);
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                c.startActivity(launch);
                return Json.textResult("已启动: " + pkg);
            }
        });

        list.add(new ToolDefinition("dev_app_stop", "强制停止指定应用（需系统签名或 ROOT，普通模式下仅能杀自己）。",
                Json.schema(Json.obj("package", Json.strProp("应用包名")), "package")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                String pkg = a.optString("package", "");
                android.app.ActivityManager am = (android.app.ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
                try {
                    java.lang.reflect.Method m = am.getClass().getMethod("forceStopPackage", String.class);
                    m.invoke(am, pkg);
                    return Json.textResult("已请求停止: " + pkg + "（需系统权限才真正生效）");
                } catch (Throwable t) {
                    return Json.errorResult("停止失败（可能需要 ROOT/系统权限）: " + t.getMessage()
                            + "\n提示：可改用 dev_shell_exec 执行 am force-stop " + pkg);
                }
            }
        });

        list.add(new ToolDefinition("dev_app_install", "请求安装 APK（会弹出系统安装界面）。",
                Json.schema(Json.obj("apkPath", Json.strProp("APK 文件绝对路径")), "apkPath")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                String p = a.optString("apkPath", "");
                java.io.File f = new java.io.File(p);
                if (!f.isFile()) return Json.errorResult("APK 不存在: " + p);
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                Uri uri = androidx.core.content.FileProvider.getUriForFile(c, c.getPackageName() + ".fileprovider", f);
                i.setDataAndType(uri, "application/vnd.android.package-archive");
                c.startActivity(i);
                return Json.textResult("已发起安装请求: " + p);
            }
        });

        list.add(new ToolDefinition("dev_app_uninstall", "请求卸载应用（会弹出系统确认界面）。",
                Json.schema(Json.obj("package", Json.strProp("应用包名")), "package")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                String pkg = a.optString("package", "");
                Intent i = new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + pkg));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                c.startActivity(i);
                return Json.textResult("已发起卸载请求: " + pkg + "（静默卸载请用 dev_shell_exec + pm uninstall）");
            }
        });

        list.add(new ToolDefinition("dev_app_current", "获取当前前台应用包名（基于 dumpsys，无需无障碍）。",
                Json.schema(new JSONObject())) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                ShellResult r = engine.exec("dumpsys activity activities | grep mResumedActivity", null, 15);
                String out = r.stdout == null ? "" : r.stdout.trim();
                String pkg = null;
                // 形如：mResumedActivity: ActivityRecord{... com.xxx/.MainActivity ...}
                java.util.regex.Matcher m = java.util.regex.Pattern
                        .compile("([a-zA-Z0-9_.]+)/([a-zA-Z0-9_.$]+)")
                        .matcher(out);
                if (m.find()) pkg = m.group(1);
                if (pkg == null) {
                    ShellResult r2 = engine.exec("dumpsys activity top | grep ACTIVITY", null, 15);
                    String o2 = r2.stdout == null ? "" : r2.stdout.trim();
                    java.util.regex.Matcher m2 = java.util.regex.Pattern
                            .compile("([a-zA-Z0-9_.]+)/([a-zA-Z0-9_.$]+)")
                            .matcher(o2);
                    if (m2.find()) pkg = m2.group(1);
                }
                if (pkg == null) return Json.errorResult("未能获取前台应用，需 ROOT 或 Shizuku 权限");
                return Json.textResult(pkg);
            }
        });

        // ---------- 应用权限 ----------
        list.add(new ToolDefinition("dev_app_permissions",
                "查询指定应用已申请/已授予的权限列表（基于 dumpsys package）。",
                Json.schema(Json.obj("pkg", Json.strProp("应用包名")), "pkg")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                String pkg = a.optString("pkg", "");
                if (pkg.isEmpty()) return Json.errorResult("pkg 不能为空");
                ShellResult r = engine.exec("dumpsys package " + pkg, null, 25);
                String out = r.stdout == null ? "" : r.stdout;
                if (out.trim().isEmpty()) return Json.errorResult("未获取到权限信息，需 ROOT 或 Shizuku");
                org.json.JSONArray granted = new org.json.JSONArray();
                org.json.JSONArray requested = new org.json.JSONArray();
                boolean inRequested = false;
                for (String line : out.split("\n")) {
                    String t = line.trim();
                    if (t.startsWith("requested permissions:")) { inRequested = true; continue; }
                    if (t.startsWith("install permissions:") || t.startsWith("runtime permissions:")) {
                        inRequested = false;
                    }
                    if (t.startsWith("android.permission.")) {
                        if (inRequested) requested.put(t);
                    }
                    if (t.contains("android.permission.") && t.contains("granted=true")) {
                        java.util.regex.Matcher m = java.util.regex.Pattern
                                .compile("(android\\.permission\\.[A-Z_0-9]+)").matcher(t);
                        if (m.find()) granted.put(m.group(1));
                    }
                }
                return Json.textResult(Json.fmt(Json.obj("pkg", pkg,
                        "grantedCount", granted.length(),
                        "granted", granted,
                        "requestedCount", requested.length())));
            }
        });

        // ---------- 清除应用数据 ----------
        list.add(new ToolDefinition("dev_app_clear_data",
                "清除指定应用的全部数据（相当于设置里的「清除数据」）。会清空登录状态与本地缓存，慎用。",
                Json.schema(Json.obj("pkg", Json.strProp("应用包名")), "pkg")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                String pkg = a.optString("pkg", "");
                if (pkg.isEmpty()) return Json.errorResult("pkg 不能为空");
                ShellResult r = engine.exec("pm clear " + pkg, null, 25);
                return r.ok() ? Json.textResult("已清除数据: " + pkg)
                              : Json.errorResult("清除失败：" + r.combined());
            }
        });

        // ---------- 启动指定 Activity ----------
        list.add(new ToolDefinition("dev_app_start_activity",
                "启动指定应用的某个 Activity（比 dev_app_launch 更精确，可直达内部页面）。",
                Json.schema(Json.obj(
                        "pkg", Json.strProp("应用包名"),
                        "activity", Json.strProp("Activity 全名或简写，如 .MainActivity 或 com.x/.Main"),
                        "extras", Json.strProp("附加参数，可选。格式：--es key value")),
                        "pkg", "activity")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                String pkg = a.optString("pkg", "");
                String act = a.optString("activity", "");
                if (pkg.isEmpty() || act.isEmpty()) return Json.errorResult("pkg 与 activity 均不能为空");
                String comp = act.startsWith(".") ? (pkg + act) : act;
                String cmd = "am start -n " + comp;
                String extras = a.optString("extras", "");
                if (!extras.isEmpty()) cmd += " " + extras;
                ShellResult r = engine.exec(cmd, null, 20);
                return r.ok() ? Json.textResult("已启动: " + comp)
                              : Json.errorResult("启动失败：" + r.combined());
            }
        });

        // ---------- 禁用应用 ----------
        list.add(new ToolDefinition("dev_app_disable",
                "禁用指定应用（pm disable-user）。应用会从桌面消失且无法运行，可再用 dev_app_enable 恢复。",
                Json.schema(Json.obj("pkg", Json.strProp("应用包名")), "pkg")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                String pkg = a.optString("pkg", "");
                if (pkg.isEmpty()) return Json.errorResult("pkg 不能为空");
                ShellResult r = engine.exec("pm disable-user --user 0 " + pkg, null, 25);
                if (!r.ok()) {
                    ShellResult r2 = engine.exec("pm disable " + pkg, null, 25);
                    if (r2.ok()) return Json.textResult("已禁用: " + pkg);
                    return Json.errorResult("禁用失败：" + r.combined());
                }
                return Json.textResult("已禁用: " + pkg);
            }
        });

        // ---------- 启用应用 ----------
        list.add(new ToolDefinition("dev_app_enable",
                "启用被禁用的应用（pm enable）。",
                Json.schema(Json.obj("pkg", Json.strProp("应用包名")), "pkg")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                String pkg = a.optString("pkg", "");
                if (pkg.isEmpty()) return Json.errorResult("pkg 不能为空");
                ShellResult r = engine.exec("pm enable " + pkg, null, 25);
                return r.ok() ? Json.textResult("已启用: " + pkg)
                              : Json.errorResult("启用失败：" + r.combined());
            }
        });

        return list;
    }
}
