package com.android.mcpremote;

import android.app.Application;

import com.android.mcpremote.exec.ShizukuHelper;
import com.android.mcpremote.util.AppLog;

/** 应用入口：初始化 Shizuku 监听等全局组件 */
public class McpApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        AppLog.i("MCP远程 启动");
        try {
            ShizukuHelper.init(this);
        } catch (Throwable t) {
            AppLog.e("Shizuku 初始化异常", t);
        }
    }
}
