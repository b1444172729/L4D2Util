package com.android.mcpremote.exec;

/** 权限执行器统一接口 */
public interface PrivilegeExecutor {
    /** 标识：root / shizuku / app */
    String getId();
    /** 展示名 */
    String getLabel();
    /** 当前是否可用 */
    boolean isAvailable();
    /** 执行命令 */
    ShellResult exec(String command, int timeoutSeconds);
}
