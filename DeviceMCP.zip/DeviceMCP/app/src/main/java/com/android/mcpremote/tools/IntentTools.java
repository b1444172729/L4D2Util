package com.android.mcpremote.tools;

import android.content.Context;

import com.android.mcpremote.exec.ExecutionEngine;
import com.android.mcpremote.exec.ShellResult;
import com.android.mcpremote.server.ToolDefinition;
import com.android.mcpremote.util.Json;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Intent 工具：发送广播、打开 URL/文件、系统分享 */
public final class IntentTools {

    public static List<ToolDefinition> all(Context ctx) {
        List<ToolDefinition> list = new ArrayList<>();

        list.add(new ToolDefinition("dev_intent_view",
                "用系统方式打开一个 URL 或文件（ACTION_VIEW）。例如打开网页、播放视频、查看图片。",
                Json.schema(Json.obj(
                        "uri", Json.strProp("目标地址，如 https://example.com 或 file:///sdcard/a.pdf"),
                        "mimeType", Json.strProp("MIME 类型，可选，如 image/png、application/pdf"),
                        "package", Json.strProp("指定用哪个应用打开（包名），可选")),
                        "uri")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                String uri = a.optString("uri", "");
                if (uri.isEmpty()) return Json.errorResult("uri 不能为空");
                String mime = a.optString("mimeType", "");
                String pkg = a.optString("package", "");
                StringBuilder cmd = new StringBuilder("am start -a android.intent.action.VIEW");
                if (!mime.isEmpty()) cmd.append(" -t ").append(mime);
                cmd.append(" -d \"").append(uri.replace("\"", "\\\"")).append('"');
                if (!pkg.isEmpty()) cmd.append(" -n ").append(pkg);
                ShellResult r = engine.exec(cmd.toString(), null, 20);
                return r.ok() ? Json.textResult("已打开: " + uri)
                              : Json.errorResult("打开失败：" + r.combined());
            }
        });

        list.add(new ToolDefinition("dev_intent_share",
                "调用系统分享（ACTION_SEND），分享文本或文件到其他应用。",
                Json.schema(Json.obj(
                        "text", Json.strProp("要分享的文本"),
                        "uri", Json.strProp("要分享的文件 URI，可选（如 file:///sdcard/a.png）"),
                        "mimeType", Json.strProp("MIME 类型，默认 text/plain")),
                        "text")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                String text = a.optString("text", "");
                String uri = a.optString("uri", "");
                String mime = a.optString("mimeType", "text/plain");
                if (text.isEmpty() && uri.isEmpty()) return Json.errorResult("text 与 uri 不能同时为空");
                StringBuilder cmd = new StringBuilder("am start -a android.intent.action.SEND -t ").append(mime);
                if (!text.isEmpty()) {
                    cmd.append(" --es android.intent.extra.TEXT \"").append(text.replace("\"", "\\\"")).append('"');
                }
                if (!uri.isEmpty()) {
                    cmd.append(" --eu android.intent.extra.STREAM \"").append(uri.replace("\"", "\\\"")).append('"');
                }
                ShellResult r = engine.exec(cmd.toString(), null, 20);
                return r.ok() ? Json.textResult("已唤起系统分享")
                              : Json.errorResult("分享失败：" + r.combined());
            }
        });

        list.add(new ToolDefinition("dev_intent_send",
                "发送广播 Intent（am broadcast）。可自定义 action、组件、附加参数。用于触发系统或应用自定义事件。",
                Json.schema(Json.obj(
                        "action", Json.strProp("广播 action，如 android.intent.action.BOOT_COMPLETED"),
                        "package", Json.strProp("目标包名，可选"),
                        "extras", Json.strProp("附加参数，可选。格式：--es key value 或 --ez key true 等")),
                        "action")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                String action = a.optString("action", "");
                if (action.isEmpty()) return Json.errorResult("action 不能为空");
                String pkg = a.optString("package", "");
                String extras = a.optString("extras", "");
                StringBuilder cmd = new StringBuilder("am broadcast -a ").append(action);
                if (!pkg.isEmpty()) cmd.append(" -p ").append(pkg);
                if (!extras.isEmpty()) cmd.append(' ').append(extras);
                ShellResult r = engine.exec(cmd.toString(), null, 20);
                return r.ok() ? Json.textResult("已发送广播: " + action)
                              : Json.errorResult("发送失败：" + r.combined());
            }
        });

        return list;
    }
}
