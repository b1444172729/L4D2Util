package com.android.mcpremote.exec;

/** 普通应用权限执行器（无提权），仅能执行普通用户可做的操作 */
public class AppExecutor implements PrivilegeExecutor {
    @Override public String getId() { return "app"; }
    @Override public String getLabel() { return "普通应用权限"; }
    @Override public boolean isAvailable() { return true; }

    @Override
    public ShellResult exec(String command, int timeoutSeconds) {
        return RootExecutor.ExecSupport.run(new String[]{"sh", "-c", command}, timeoutSeconds, getId());
    }
}
