package com.android.mcpremote.tools;

import android.content.Context;

import com.android.mcpremote.exec.ExecutionEngine;
import com.android.mcpremote.server.ToolDefinition;
import com.android.mcpremote.util.Json;
import com.android.mcpremote.util.McpConfig;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Shell 类工具：按所选权限模式执行 */
public final class ShellTools {

    public static List<ToolDefinition> all(Context ctx) {
        List<ToolDefinition> list = new ArrayList<>();
        ExecutionEngine engine = new ExecutionEngine(ctx);

        list.add(new ToolDefinition("dev_shell_exec",
                "执行 shell 命令。工作模式由 mode 参数指定：root / shizuku / accessibility / auto（自动降级）。无障碍模式下以普通应用权限执行。",
                Json.schema(Json.obj(
                        "command", Json.strProp("要执行的 shell 命令"),
                        "mode", Json.strProp("工作模式：root|shizuku|accessibility|auto，留空则使用 App 中配置的默认模式"),
                        "timeoutSeconds", Json.intProp("超时秒数，默认 20")),
                        "command")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                String cmd = a.optString("command", "");
                String mode = a.optString("mode", "");
                int timeout = a.optInt("timeoutSeconds", 20);
                if (timeout < 1) timeout = 1;
                if (timeout > 300) timeout = 300;
                com.android.mcpremote.exec.ShellResult r = engine.exec(cmd, mode, timeout);
                return r.ok() ? Json.textResult(r.toText()) : Json.errorResult(r.toText());
            }
        });

        list.add(new ToolDefinition("dev_shell_which",
                "检测各工作模式可用性，并返回当前生效模式。",
                Json.schema(new JSONObject())) {
            @Override public JSONObject call(Context c, JSONObject a) {
                String cfg = new McpConfig(c).getMode();
                JSONObject o = Json.obj(
                        "configuredMode", cfg,
                        "probe", engine.probeAll(),
                        "available", engine.isAvailable(cfg)
                );
                return Json.textResult(Json.fmt(o));
            }
        });

        return list;
    }
}
