package com.android.mcpremote.server;

import android.content.Context;

import com.android.mcpremote.tools.AppTools;
import com.android.mcpremote.tools.DeviceTools;
import com.android.mcpremote.tools.FileTools;
import com.android.mcpremote.tools.ShellTools;
import com.android.mcpremote.tools.UiTools;

import org.json.JSONObject;

import java.util.LinkedHashMap;
import java.util.Map;

/** 工具注册表：集中管理全部 MCP 工具 */
public final class ToolRegistry {

    private static final Map<String, ToolDefinition> TOOLS = new LinkedHashMap<>();

    public static synchronized void init(Context ctx) {
        if (!TOOLS.isEmpty()) return;
        Context c = ctx.getApplicationContext();
        for (ToolDefinition t : FileTools.all(c)) TOOLS.put(t.name, t);
        for (ToolDefinition t : ShellTools.all(c)) TOOLS.put(t.name, t);
        for (ToolDefinition t : AppTools.all(c)) TOOLS.put(t.name, t);
        for (ToolDefinition t : DeviceTools.all(c)) TOOLS.put(t.name, t);
        for (ToolDefinition t : UiTools.all(c)) TOOLS.put(t.name, t);
    }

    public static ToolDefinition get(String name) { return TOOLS.get(name); }

    public static org.json.JSONArray listJson() {
        org.json.JSONArray arr = new org.json.JSONArray();
        for (ToolDefinition t : TOOLS.values()) arr.put(t.toJson());
        return arr;
    }

    public static int count() { return TOOLS.size(); }

    /** 统一执行入口，捕获所有异常并转为 MCP 错误结果 */
    public static JSONObject dispatch(Context ctx, String name, JSONObject args) {
        ToolDefinition t = TOOLS.get(name);
        if (t == null) {
            return com.android.mcpremote.util.Json.errorResult("未知工具: " + name + "（可用工具数：" + count() + "）");
        }
        try {
            return t.call(ctx, args == null ? new JSONObject() : args);
        } catch (Throwable e) {
            return com.android.mcpremote.util.Json.errorResult("工具执行异常 [" + name + "]: " + e);
        }
    }
}
