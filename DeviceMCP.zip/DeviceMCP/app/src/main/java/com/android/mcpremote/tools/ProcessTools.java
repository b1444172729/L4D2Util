package com.android.mcpremote.tools;

import android.content.Context;

import com.android.mcpremote.exec.ExecutionEngine;
import com.android.mcpremote.exec.ShellResult;
import com.android.mcpremote.server.ToolDefinition;
import com.android.mcpremote.util.Json;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** 进程与性能工具：进程列表、杀进程、CPU/内存/存储占用 */
public final class ProcessTools {

    public static List<ToolDefinition> all(Context ctx) {
        List<ToolDefinition> list = new ArrayList<>();

        list.add(new ToolDefinition("dev_process_list",
                "列出正在运行的进程（PID、名称、用户、内存占用）。可按关键字过滤。",
                Json.schema(Json.obj(
                        "filter", Json.strProp("按进程名过滤关键字，可选"),
                        "maxLines", Json.intProp("最多返回行数，默认 60")), "filter")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                String filter = a.optString("filter", "");
                int max = a.optInt("maxLines", 60);
                ShellResult r = engine.exec("ps -A -o PID,USER,NAME,RSS", null, 20);
                String out = r.stdout == null ? "" : r.stdout;
                if (out.trim().isEmpty()) {
                    ShellResult r2 = engine.exec("ps", null, 20);
                    out = r2.stdout == null ? "" : r2.stdout;
                }
                if (out.trim().isEmpty()) return Json.errorResult("未获取到进程列表，需 ROOT 或 Shizuku 权限");
                JSONArray arr = new JSONArray();
                int n = 0;
                for (String line : out.split("\n")) {
                    if (n >= max) break;
                    if (line.trim().isEmpty()) continue;
                    if (!filter.isEmpty() && !line.contains(filter)) continue;
                    arr.put(line.trim());
                    n++;
                }
                return Json.textResult("进程（显示 " + arr.length() + " 条）：\n" + Json.fmt(arr));
            }
        });

        list.add(new ToolDefinition("dev_process_kill",
                "按 PID 或进程名结束进程。按 PID 更精确；按名称会 kill 所有匹配进程。",
                Json.schema(Json.obj(
                        "pid", Json.intProp("进程 PID（与 name 二选一）"),
                        "name", Json.strProp("进程名（与 pid 二选一，会结束所有匹配进程）"),
                        "signal", Json.strProp("信号：默认 9（强制杀死），可选 15（优雅退出）")),
                        "pid")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                String sig = a.optString("signal", "9");
                if (a.has("pid")) {
                    int pid = a.optInt("pid", -1);
                    if (pid <= 0) return Json.errorResult("pid 无效");
                    ShellResult r = engine.exec("kill -" + sig + " " + pid, null, 15);
                    return r.ok() ? Json.textResult("已向 PID " + pid + " 发送信号 " + sig)
                                  : Json.errorResult("失败：" + r.combined());
                }
                String name = a.optString("name", "");
                if (name.isEmpty()) return Json.errorResult("需提供 pid 或 name");
                ShellResult r = engine.exec("pkill -" + sig + " " + name, null, 15);
                if (!r.ok()) {
                    ShellResult r2 = engine.exec("killall -" + sig + " " + name, null, 15);
                    if (r2.ok()) return Json.textResult("已结束进程: " + name);
                    return Json.errorResult("失败：" + r.combined());
                }
                return Json.textResult("已结束进程: " + name);
            }
        });

        list.add(new ToolDefinition("dev_perf_cpu", "获取 CPU 占用情况（各进程 CPU 使用率排行）。",
                Json.schema(Json.obj("maxLines", Json.intProp("最多返回行数，默认 20")), "maxLines")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                int max = a.optInt("maxLines", 20);
                ShellResult r = engine.exec("dumpsys cpuinfo", null, 25);
                String out = r.stdout == null ? "" : r.stdout;
                if (out.trim().isEmpty()) {
                    ShellResult r2 = engine.exec("top -n 1 -b", null, 25);
                    out = r2.stdout == null ? "" : r2.stdout;
                }
                if (out.trim().isEmpty()) return Json.errorResult("未获取到 CPU 信息，需 ROOT 或 Shizuku");
                if (out.length() > max * 120) out = out.substring(0, max * 120);
                return Json.textResult(out);
            }
        });

        list.add(new ToolDefinition("dev_perf_memory", "获取内存使用情况（总内存、可用内存、各进程占用）。",
                Json.schema(Json.obj(
                        "topN", Json.intProp("显示占用最高的前 N 个进程，默认 10")), "topN")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                int topN = a.optInt("topN", 10);
                ShellResult mem = engine.exec("cat /proc/meminfo", null, 15);
                StringBuilder sb = new StringBuilder("=== 系统内存 ===\n");
                if (mem.stdout != null) {
                    String[] keys = {"MemTotal", "MemFree", "MemAvailable", "Buffers", "Cached", "SwapTotal", "SwapFree"};
                    for (String line : mem.stdout.split("\n")) {
                        for (String k : keys) {
                            if (line.startsWith(k)) { sb.append(line.trim()).append('\n'); break; }
                        }
                    }
                }
                ShellResult procs = engine.exec("dumpsys meminfo", null, 30);
                if (procs.stdout != null && !procs.stdout.trim().isEmpty()) {
                    sb.append("\n=== 进程占用（前 ").append(topN).append("）===\n");
                    int n = 0;
                    for (String line : procs.stdout.split("\n")) {
                        if (n >= topN) break;
                        if (line.contains("kB:") || line.matches(".*\\d+K:.*")) {
                            sb.append(line.trim()).append('\n');
                            n++;
                        }
                    }
                }
                return Json.textResult(sb.toString());
            }
        });

        list.add(new ToolDefinition("dev_perf_storage", "获取存储空间使用情况（各分区总容量、已用、可用）。",
                Json.schema(new JSONObject())) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                ShellResult r = engine.exec("df -h", null, 20);
                String out = r.stdout == null ? "" : r.stdout;
                if (out.trim().isEmpty()) return Json.errorResult("未获取到存储信息");
                return Json.textResult(out);
            }
        });

        return list;
    }
}
