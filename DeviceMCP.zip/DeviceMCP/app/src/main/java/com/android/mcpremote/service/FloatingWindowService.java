package com.android.mcpremote.service;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.mcpremote.R;
import com.android.mcpremote.util.AppLog;
import com.android.mcpremote.util.McpConfig;

/**
 * 悬浮窗服务：显示可拖动的应用图标浮窗，用于提升后台存活并快速查看状态。
 *
 * 修复要点：
 *  - 采用 WindowManager 直接 addView，并在无权限时明确提示而非静默退出
 *  - 记录拖动后的位置，下次启动复用
 *  - 定时刷新状态指示点与端口文本
 */
public class FloatingWindowService extends Service {

    private WindowManager wm;
    private View floatView;
    private View dotView;
    private TextView tvPort;
    private ImageView ivIcon;
    private WindowManager.LayoutParams lp;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private static final int[] DEFAULT_POS = {20, 180};

    public static boolean canDrawOverlay(Context ctx) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return true;
        try {
            return Settings.canDrawOverlays(ctx);
        } catch (Throwable t) {
            return false;
        }
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (!canDrawOverlay(this)) {
            AppLog.w("悬浮窗未显示：缺少 SYSTEM_ALERT_WINDOW 权限，请在设置中授予");
            stopSelf();
            return START_NOT_STICKY;
        }
        if (floatView == null) {
            boolean ok = show();
            if (!ok) {
                stopSelf();
                return START_NOT_STICKY;
            }
        }
        update();
        startRefresh();
        return START_STICKY;
    }

    private boolean show() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (wm == null) {
            AppLog.e("悬浮窗未显示：WindowManager 不可用");
            return false;
        }

        floatView = View.inflate(this, R.layout.floating_window, null);
        if (floatView == null) {
            AppLog.e("悬浮窗未显示：布局加载失败");
            return false;
        }

        ivIcon = floatView.findViewById(R.id.float_icon);
        dotView = floatView.findViewById(R.id.float_dot);
        tvPort = floatView.findViewById(R.id.float_port);

        int type;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1) {
            type = WindowManager.LayoutParams.TYPE_PHONE;
        } else {
            type = WindowManager.LayoutParams.TYPE_PHONE;
        }

        lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;

        McpConfig cfg = new McpConfig(this);
        lp.x = cfg.getFloatX();
        lp.y = cfg.getFloatY();

        // 拖动支持：按下记录起点，移动更新位置，抬起持久化
        final float[] down = new float[2];
        final int[] origin = new int[2];
        final long[] downTime = new long[1];
        final boolean[] moved = new boolean[1];

        floatView.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    down[0] = event.getRawX();
                    down[1] = event.getRawY();
                    origin[0] = lp.x;
                    origin[1] = lp.y;
                    downTime[0] = System.currentTimeMillis();
                    moved[0] = false;
                    return true;

                case MotionEvent.ACTION_MOVE:
                    int dx = (int) (event.getRawX() - down[0]);
                    int dy = (int) (event.getRawY() - down[1]);
                    if (Math.abs(dx) > 4 || Math.abs(dy) > 4) moved[0] = true;
                    lp.x = origin[0] + dx;
                    lp.y = origin[1] + dy;
                    try { wm.updateViewLayout(floatView, lp); } catch (Throwable ignored) {}
                    return true;

                case MotionEvent.ACTION_UP:
                    // 未拖动且短按，视为点击：回到主界面
                    if (!moved[0] && System.currentTimeMillis() - downTime[0] < 300) {
                        try {
                            Intent home = new Intent(this, com.android.mcpremote.MainActivity.class);
                            home.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                                    | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                            startActivity(home);
                        } catch (Throwable t) {
                            AppLog.w("点击悬浮窗跳转失败: " + t.getMessage());
                        }
                    } else {
                        new McpConfig(this).setFloatPos(lp.x, lp.y);
                    }
                    return true;
            }
            return false;
        });

        try {
            wm.addView(floatView, lp);
            AppLog.i("悬浮窗已显示（可拖动）");
            return true;
        } catch (Throwable t) {
            AppLog.e("悬浮窗添加失败", t);
            floatView = null;
            return false;
        }
    }

    private void startRefresh() {
        ui.postDelayed(new Runnable() {
            @Override public void run() {
                update();
                ui.postDelayed(this, 3000);
            }
        }, 3000);
    }

    private void update() {
        if (tvPort == null || dotView == null) return;
        boolean running = McpForegroundService.isServerRunning();
        int port = running ? McpForegroundService.getRunningPort() : new McpConfig(this).getPort();
        tvPort.setText(String.valueOf(port));

        // 动态生成状态点：运行中绿色，未运行灰色
        android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
        gd.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        gd.setColor(running ? 0xFF4CAF50 : 0xFF9E9E9E);
        gd.setStroke(1, 0xFFFFFFFF);
        dotView.setBackground(gd);
    }

    @Override
    public void onDestroy() {
        ui.removeCallbacksAndMessages(null);
        try {
            if (floatView != null && wm != null) wm.removeView(floatView);
        } catch (Throwable ignored) {}
        floatView = null;
        AppLog.i("悬浮窗已移除");
        super.onDestroy();
    }
}
