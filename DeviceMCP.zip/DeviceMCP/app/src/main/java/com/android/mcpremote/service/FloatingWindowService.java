package com.android.mcpremote.service;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;

import com.android.mcpremote.R;
import com.android.mcpremote.util.AppLog;
import com.android.mcpremote.util.McpConfig;

/**
 * 悬浮窗服务：与 MT 管理器类似的圆形小图标悬浮窗。
 *
 * 行为：
 *  - 尺寸 44dp（与 MT 管理器相当），不显示端口号
 *  - 可自由拖动，位置自动记忆
 *  - 3 秒无操作自动贴边隐藏，仅露出约 30%；点击露出的部分即可弹回
 *  - 短按（未拖动）回到主界面
 *  - 右上角状态点：绿=服务运行中，灰=未运行
 */
public class FloatingWindowService extends Service {

    /** 悬浮窗尺寸（dp），与 layout 中保持一致 */
    private static final int FLOAT_SIZE_DP = 44;
    /** 贴边后露出的比例 */
    private static final float EDGE_VISIBLE_RATIO = 0.30f;
    /** 无操作后自动贴边的延时 */
    private static final long AUTO_HIDE_DELAY = 3000L;

    private WindowManager wm;
    private View floatView;
    private View dotView;
    private WindowManager.LayoutParams lp;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private boolean edgeHidden = false;
    private int normalX = 20;
    private int normalY = 180;
    private int floatSizePx = 0;

    private final Runnable hideTask = this::hideToEdge;

    public static boolean canDrawOverlay(Context ctx) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return true;
        try {
            return Settings.canDrawOverlays(ctx);
        } catch (Throwable t) {
            return false;
        }
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (!canDrawOverlay(this)) {
            AppLog.w("悬浮窗未显示：缺少悬浮窗权限，请在设置中授予");
            stopSelf();
            return START_NOT_STICKY;
        }
        if (floatView == null) {
            if (!show()) {
                stopSelf();
                return START_NOT_STICKY;
            }
        }
        update();
        scheduleAutoHide();
        return START_STICKY;
    }

    private boolean show() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (wm == null) {
            AppLog.e("悬浮窗未显示：WindowManager 不可用");
            return false;
        }

        floatView = View.inflate(this, R.layout.floating_window, null);
        if (floatView == null) {
            AppLog.e("悬浮窗未显示：布局加载失败");
            return false;
        }
        floatSizePx = dp(FLOAT_SIZE_DP);

        dotView = floatView.findViewById(R.id.float_dot);

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        lp = new WindowManager.LayoutParams(
                floatSizePx,
                floatSizePx,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;

        McpConfig cfg = new McpConfig(this);
        normalX = cfg.getFloatX();
        normalY = cfg.getFloatY();
        lp.x = normalX;
        lp.y = normalY;

        final float[] down = new float[2];
        final int[] origin = new int[2];
        final long[] downTime = new long[1];
        final boolean[] moved = new boolean[1];

        floatView.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    // 贴边状态下按下：先弹回原位，不立即进入拖动
                    if (edgeHidden) {
                        expandFromEdge();
                        scheduleAutoHide();
                        return true;
                    }
                    down[0] = event.getRawX();
                    down[1] = event.getRawY();
                    origin[0] = lp.x;
                    origin[1] = lp.y;
                    downTime[0] = System.currentTimeMillis();
                    moved[0] = false;
                    cancelAutoHide();
                    return true;

                case MotionEvent.ACTION_MOVE:
                    if (edgeHidden) return true;
                    int dx = (int) (event.getRawX() - down[0]);
                    int dy = (int) (event.getRawY() - down[1]);
                    if (Math.abs(dx) > 4 || Math.abs(dy) > 4) moved[0] = true;
                    lp.x = origin[0] + dx;
                    lp.y = origin[1] + dy;
                    applyLayout();
                    return true;

                case MotionEvent.ACTION_UP:
                    if (edgeHidden) return true;
                    if (!moved[0] && System.currentTimeMillis() - downTime[0] < 300) {
                        // 短按：回到主界面
                        try {
                            Intent home = new Intent(this, MainActivity.class);
                            home.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                                    | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                            startActivity(home);
                        } catch (Throwable t) {
                            AppLog.w("点击悬浮窗跳转失败: " + t.getMessage());
                        }
                    } else {
                        // 拖动结束：记住位置
                        normalX = lp.x;
                        normalY = lp.y;
                        new McpConfig(this).setFloatPos(normalX, normalY);
                    }
                    scheduleAutoHide();
                    return true;
            }
            return false;
        });

        try {
            wm.addView(floatView, lp);
            AppLog.i("悬浮窗已显示（" + FLOAT_SIZE_DP + "dp，可拖动，3 秒无操作自动贴边）");
            return true;
        } catch (Throwable t) {
            AppLog.e("悬浮窗添加失败", t);
            floatView = null;
            return false;
        }
    }

    private void applyLayout() {
        if (floatView == null || wm == null) return;
        try { wm.updateViewLayout(floatView, lp); } catch (Throwable ignored) {}
    }

    private int screenWidth() {
        try {
            DisplayMetrics dm = new DisplayMetrics();
            wm.getDefaultDisplay().getMetrics(dm);
            return dm.widthPixels;
        } catch (Throwable t) {
            return 1080;
        }
    }

    /** 贴边隐藏：仅露出约 30% */
    private void hideToEdge() {
        if (edgeHidden || floatView == null) return;
        int sw = screenWidth();
        int visible = (int) (floatSizePx * EDGE_VISIBLE_RATIO);
        // 依据当前位置判断吸附到左边还是右边
        int center = lp.x + floatSizePx / 2;
        normalX = lp.x;
        normalY = lp.y;
        if (center < sw / 2) {
            lp.x = -(floatSizePx - visible);
        } else {
            lp.x = sw - visible;
        }
        edgeHidden = true;
        applyLayout();
    }

    /** 从贴边状态弹回 */
    private void expandFromEdge() {
        if (!edgeHidden) return;
        lp.x = normalX;
        lp.y = normalY;
        edgeHidden = false;
        applyLayout();
    }

    private void scheduleAutoHide() {
        ui.removeCallbacks(hideTask);
        ui.postDelayed(hideTask, AUTO_HIDE_DELAY);
    }

    private void cancelAutoHide() {
        ui.removeCallbacks(hideTask);
    }

    /** 定时刷新状态点 */
    private void startRefresh() {
        ui.postDelayed(new Runnable() {
            @Override public void run() {
                update();
                ui.postDelayed(this, 3000);
            }
        }, 3000);
    }

    private void update() {
        if (dotView == null) return;
        boolean running = McpForegroundService.isServerRunning();
        android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
        gd.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        gd.setColor(running ? 0xFF4CAF50 : 0xFF9E9E9E);
        gd.setStroke(1, 0xFFFFFFFF);
        dotView.setBackground(gd);
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public void onDestroy() {
        ui.removeCallbacksAndMessages(null);
        try {
            if (floatView != null && wm != null) wm.removeView(floatView);
        } catch (Throwable ignored) {}
        floatView = null;
        AppLog.i("悬浮窗已移除");
        super.onDestroy();
    }
}
