package com.android.mcpremote.server;

import android.content.Context;

import org.json.JSONObject;

/** MCP 工具定义基类 */
public abstract class ToolDefinition {
    public final String name;
    public final String description;
    public final JSONObject inputSchema;

    public ToolDefinition(String name, String description, JSONObject inputSchema) {
        this.name = name;
        this.description = description;
        this.inputSchema = inputSchema == null ? new JSONObject() : inputSchema;
    }

    /** 执行工具，返回 MCP 结果对象（含 content / isError） */
    public abstract JSONObject call(Context ctx, JSONObject args) throws Exception;

    /** 转为 MCP tools/list 中的条目 */
    public JSONObject toJson() {
        JSONObject o = new JSONObject();
        try {
            o.put("name", name);
            o.put("description", description);
            o.put("inputSchema", inputSchema);
        } catch (Exception ignored) {}
        return o;
    }
}
