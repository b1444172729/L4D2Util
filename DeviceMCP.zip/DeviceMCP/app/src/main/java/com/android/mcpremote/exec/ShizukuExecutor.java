package com.android.mcpremote.exec;

import android.content.Context;

import com.android.mcpremote.util.AppLog;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import rikka.shizuku.Shizuku;
import rikka.shizuku.ShizukuRemoteProcess;

/**
 * Shizuku 执行器：通过 Shizuku 的 Binder 以 shell/ROOT 身份执行命令。
 *
 * 依赖：
 *   implementation 'dev.rikka.shizuku:api:13.1.5'
 *   implementation 'dev.rikka.shizuku:provider:13.1.5'
 * Manifest 中必须声明 rikka.shizuku.ShizukuProvider。
 */
public class ShizukuExecutor implements PrivilegeExecutor {

    private final Context ctx;

    public ShizukuExecutor(Context ctx) { this.ctx = ctx.getApplicationContext(); }

    @Override public String getId() { return "shizuku"; }
    @Override public String getLabel() { return "Shizuku"; }

    @Override
    public boolean isAvailable() {
        boolean alive = ShizukuHelper.isBinderAlive();
        boolean granted = ShizukuHelper.isGranted();
        if (!alive) {
            AppLog.w("Shizuku 不可用：Binder 未连接（请确认 Shizuku 已启动）");
            return false;
        }
        if (!granted) {
            AppLog.w("Shizuku 不可用：已连接但未授权，请在弹出的对话框中允许");
            return false;
        }
        return true;
    }

    public String diagnose() {
        return ShizukuHelper.diagnose();
    }

    @Override
    public ShellResult exec(String command, int timeoutSeconds) {
        ShizukuRemoteProcess proc = null;
        try {
            if (!ShizukuHelper.isBinderAlive()) {
                return new ShellResult(-1, "", "Shizuku Binder 未连接", getId());
            }
            if (!ShizukuHelper.isGranted()) {
                return new ShellResult(-1, "", "Shizuku 未授权本应用", getId());
            }

            proc = Shizuku.newProcess(new String[]{"sh", "-c", command}, null, null);
            if (proc == null) return new ShellResult(-1, "", "Shizuku newProcess 返回空", getId());

            InputStream in = proc.getInputStream();
            InputStream err = proc.getErrorStream();

            List<String> out = new ArrayList<>();
            List<String> errs = new ArrayList<>();
            Thread t1 = new Thread(() -> read(in, out));
            Thread t2 = new Thread(() -> read(err, errs));
            t1.start();
            t2.start();

            int code = waitFor(proc, timeoutSeconds);

            t1.join(3000);
            t2.join(3000);

            return new ShellResult(code, join(out), join(errs), getId());
        } catch (Throwable t) {
            AppLog.e("Shizuku 执行失败", t);
            return new ShellResult(-1, "", String.valueOf(t.getMessage()), getId());
        } finally {
            if (proc != null) {
                try { proc.destroy(); } catch (Throwable ignored) {}
            }
        }
    }

    /** 带超时的 waitFor：ShizukuRemoteProcess.waitFor() 无超时版本 */
    private int waitFor(ShizukuRemoteProcess proc, int timeoutSeconds) {
        final int[] code = {-1};
        Thread t = new Thread(() -> {
            try { code[0] = proc.waitFor(); } catch (Throwable ignored) {}
        });
        t.setDaemon(true);
        t.start();
        try {
            t.join(timeoutSeconds * 1000L);
        } catch (InterruptedException ignored) {}
        if (t.isAlive()) {
            try { proc.destroy(); } catch (Throwable ignored) {}
            AppLog.w("Shizuku 命令超时（" + timeoutSeconds + "s）");
            return -1;
        }
        return code[0];
    }

    private static void read(InputStream is, List<String> sink) {
        try (BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF-8"))) {
            String line;
            while ((line = br.readLine()) != null) {
                synchronized (sink) { sink.add(line); }
            }
        } catch (Throwable ignored) {}
    }

    private static String join(List<String> lines) {
        synchronized (lines) {
            StringBuilder sb = new StringBuilder();
            for (String l : lines) sb.append(l).append('\n');
            return sb.toString().trim();
        }
    }
}
