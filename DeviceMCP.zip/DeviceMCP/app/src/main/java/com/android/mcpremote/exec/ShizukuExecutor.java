package com.android.mcpremote.exec;

import android.content.Context;
import android.content.pm.PackageManager;

import com.android.mcpremote.util.AppLog;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Shizuku 执行器：通过 Shizuku 提供的 Binder 以 shell/ROOT 身份执行。
 *
 * 依赖（可选）：
 *   implementation 'dev.rikka.shizuku:api:13.1.5'
 *   implementation 'dev.rikka.shizuku:provider:13.1.5'
 *
 * 若未引入依赖，本类自动降级为不可用，不会导致崩溃。
 */
public class ShizukuExecutor implements PrivilegeExecutor {

    private final Context ctx;

    public ShizukuExecutor(Context ctx) { this.ctx = ctx.getApplicationContext(); }

    @Override public String getId() { return "shizuku"; }
    @Override public String getLabel() { return "Shizuku"; }

    @Override
    public boolean isAvailable() {
        if (!shizukuInstalled(ctx)) return false;
        try {
            Class<?> cls = Class.forName("rikka.shizuku.Shizuku");
            java.lang.reflect.Method ping = cls.getMethod("pingBinder");
            Object alive = ping.invoke(null);
            if (!(alive instanceof Boolean) || !((Boolean) alive)) return false;
            java.lang.reflect.Method check = cls.getMethod("checkSelfPermission");
            Object res = check.invoke(null);
            return res instanceof Integer && ((Integer) res) == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) {
            AppLog.w("Shizuku 不可用: " + t.getClass().getSimpleName());
            return false;
        }
    }

    public static boolean shizukuInstalled(Context ctx) {
        try {
            ctx.getPackageManager().getPackageInfo("moe.shizuku.privileged.api", 0);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    @Override
    public ShellResult exec(String command, int timeoutSeconds) {
        try {
            Class<?> cls = Class.forName("rikka.shizuku.Shizuku");
            java.lang.reflect.Method newProcess =
                    cls.getMethod("newProcess", String[].class, String.class, String.class);
            Object proc = newProcess.invoke(null, new String[]{"sh", "-c", command}, null, null);
            if (proc == null) return new ShellResult(-1, "", "Shizuku newProcess 返回空", getId());

            InputStream in = (InputStream) proc.getClass().getMethod("getInputStream").invoke(proc);
            InputStream err = (InputStream) proc.getClass().getMethod("getErrorStream").invoke(proc);

            List<String> out = new ArrayList<>();
            List<String> errs = new ArrayList<>();
            Thread t1 = new Thread(() -> read(in, out));
            Thread t2 = new Thread(() -> read(err, errs));
            t1.start(); t2.start();

            // 等待进程结束（ShizukuRemoteProcess 提供 waitFor）
            int code = -1;
            try {
                java.lang.reflect.Method wf = proc.getClass().getMethod("waitFor");
                Object r = wf.invoke(proc);
                if (r instanceof Integer) code = (Integer) r;
            } catch (Throwable ignored) {}

            t1.join(3000); t2.join(3000);
            try { proc.getClass().getMethod("destroy").invoke(proc); } catch (Throwable ignored) {}

            return new ShellResult(code, join(out), join(errs), getId());
        } catch (Throwable t) {
            AppLog.e("Shizuku 执行失败", t);
            return new ShellResult(-1, "", String.valueOf(t.getMessage()), getId());
        }
    }

    private static void read(InputStream is, List<String> sink) {
        try (BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF-8"))) {
            String line;
            while ((line = br.readLine()) != null) {
                synchronized (sink) { sink.add(line); }
            }
        } catch (Throwable ignored) {}
    }

    private static String join(List<String> lines) {
        synchronized (lines) {
            StringBuilder sb = new StringBuilder();
            for (String l : lines) sb.append(l).append('\n');
            return sb.toString().trim();
        }
    }
}
