package com.android.mcpremote.exec;

import android.content.Context;

import com.android.mcpremote.util.AppLog;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/**
 * Shizuku 执行器：通过 Shizuku 的 Binder 以 shell/ROOT 身份执行命令。
 *
 * 依赖：
 *   implementation 'dev.rikka.shizuku:api:13.1.5'
 *   implementation 'dev.rikka.shizuku:provider:13.1.5'
 * Manifest 中必须声明 rikka.shizuku.ShizukuProvider。
 *
 * 重要说明：
 *   Shizuku.newProcess(String[], String[], String) 在部分版本中是 private，
 *   直接调用会导致编译失败（has private access）。
 *   因此此处改为反射调用，编译期不依赖该方法签名，兼容各版本 Shizuku。
 */
public class ShizukuExecutor implements PrivilegeExecutor {

    private final Context ctx;

    public ShizukuExecutor(Context ctx) { this.ctx = ctx.getApplicationContext(); }

    @Override public String getId() { return "shizuku"; }
    @Override public String getLabel() { return "Shizuku"; }

    @Override
    public boolean isAvailable() {
        boolean alive = ShizukuHelper.isBinderAlive();
        boolean granted = ShizukuHelper.isGranted();
        if (!alive) {
            AppLog.w("Shizuku 不可用：Binder 未连接（请确认 Shizuku 已启动）");
            return false;
        }
        if (!granted) {
            AppLog.w("Shizuku 不可用：已连接但未授权，请在弹出的对话框中允许");
            return false;
        }
        return true;
    }

    public String diagnose() {
        return ShizukuHelper.diagnose();
    }

    /** 进程句柄的反射包装，避免编译期依赖具体类型 */
    private static final class Proc {
        final Object raw;
        Proc(Object raw) { this.raw = raw; }

        InputStream in() {
            try {
                Method m = raw.getClass().getMethod("getInputStream");
                return (InputStream) m.invoke(raw);
            } catch (Throwable t) { return null; }
        }

        InputStream err() {
            try {
                Method m = raw.getClass().getMethod("getErrorStream");
                return (InputStream) m.invoke(raw);
            } catch (Throwable t) { return null; }
        }

        int waitFor() {
            try {
                Method m = raw.getClass().getMethod("waitFor");
                Object r = m.invoke(raw);
                return r instanceof Integer ? (Integer) r : -1;
            } catch (Throwable t) { return -1; }
        }

        void destroy() {
            try {
                Method m = raw.getClass().getMethod("destroy");
                m.invoke(raw);
            } catch (Throwable ignored) {}
        }
    }

    /** 反射创建进程：尝试多种签名，兼容不同 Shizuku 版本 */
    private Proc createProcess(String[] cmd) {
        Class<?> cls = tryLoad("rikka.shizuku.Shizuku");
        if (cls == null) {
            AppLog.w("Shizuku API 类未找到，请确认已引入 dev.rikka.shizuku:api 依赖");
            return null;
        }
        // 1) newProcess(String[], String[], String)
        try {
            Method m = cls.getDeclaredMethod("newProcess",
                    String[].class, String[].class, String.class);
            m.setAccessible(true);
            Object p = m.invoke(null, cmd, null, null);
            if (p != null) return new Proc(p);
        } catch (Throwable ignored) {}
        // 2) newProcess(String[], String[], String, int) 部分版本带额外参数
        try {
            Method m = cls.getDeclaredMethod("newProcess",
                    String[].class, String[].class, String.class, int.class);
            m.setAccessible(true);
            Object p = m.invoke(null, cmd, null, null, 0);
            if (p != null) return new Proc(p);
        } catch (Throwable ignored) {}
        AppLog.w("Shizuku newProcess 反射调用失败，已尝试全部已知签名");
        return null;
    }

    private static Class<?> tryLoad(String name) {
        try { return Class.forName(name); } catch (Throwable t) { return null; }
    }

    @Override
    public ShellResult exec(String command, int timeoutSeconds) {
        Proc proc = null;
        try {
            if (!ShizukuHelper.isBinderAlive()) {
                return new ShellResult(-1, "", "Shizuku Binder 未连接", getId());
            }
            if (!ShizukuHelper.isGranted()) {
                return new ShellResult(-1, "", "Shizuku 未授权本应用", getId());
            }

            proc = createProcess(new String[]{"sh", "-c", command});
            if (proc == null) {
                return new ShellResult(-1, "", "Shizuku 创建进程失败（newProcess 不可用）", getId());
            }

            // lambda 只能引用 effectively final 的局部变量，故在此固化一份
            final Proc p = proc;

            List<String> out = new ArrayList<>();
            List<String> errs = new ArrayList<>();

            Thread t1 = new Thread(() -> read(p.in(), out));
            Thread t2 = new Thread(() -> read(p.err(), errs));
            t1.start();
            t2.start();

            int code = waitWithTimeout(p, timeoutSeconds);

            t1.join(3000);
            t2.join(3000);

            return new ShellResult(code, join(out), join(errs), getId());
        } catch (Throwable t) {
            AppLog.e("Shizuku 执行失败", t);
            return new ShellResult(-1, "", String.valueOf(t.getMessage()), getId());
        } finally {
            if (proc != null) proc.destroy();
        }
    }

    /** 带超时等待，避免命令挂死 */
    private int waitWithTimeout(Proc proc, int timeoutSeconds) {
        final int[] code = {-1};
        Thread t = new Thread(() -> code[0] = proc.waitFor());
        t.setDaemon(true);
        t.start();
        try {
            t.join(Math.max(1, timeoutSeconds) * 1000L);
        } catch (InterruptedException ignored) {}
        if (t.isAlive()) {
            proc.destroy();
            AppLog.w("Shizuku 命令超时（" + timeoutSeconds + "s）");
            return -1;
        }
        return code[0];
    }

    private static void read(InputStream is, List<String> sink) {
        if (is == null) return;
        try (BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF-8"))) {
            String line;
            while ((line = br.readLine()) != null) {
                synchronized (sink) { sink.add(line); }
            }
        } catch (Throwable ignored) {}
    }

    private static String join(List<String> lines) {
        synchronized (lines) {
            StringBuilder sb = new StringBuilder();
            for (String l : lines) sb.append(l).append('\n');
            return sb.toString().trim();
        }
    }
}
