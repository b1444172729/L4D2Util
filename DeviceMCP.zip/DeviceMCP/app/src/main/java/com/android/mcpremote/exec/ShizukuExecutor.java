package com.android.mcpremote.exec;

import android.content.Context;
import android.content.pm.PackageManager;

import com.android.mcpremote.util.AppLog;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 * Shizuku 执行器：通过 Shizuku 提供的 Binder 以 shell/ROOT 身份执行。
 *
 * 依赖：
 *   implementation 'dev.rikka.shizuku:api:13.1.5'
 *   implementation 'dev.rikka.shizuku:provider:13.1.5'
 *
 * 检测要点（此前误判为「不可用」的根因）：
 *  1) 不再以「能否查到 Shizuku 包名」作为前置条件——Android 11+ 包可见性限制会
 *     导致 getPackageInfo 抛 NameNotFoundException。改以 pingBinder() 为准。
 *  2) pingBinder() 在 Binder 尚未就绪时会短暂返回 false，这里做有限次重试。
 *  3) 每一步失败都写入运行日志，便于在 App 内直接定位原因。
 */
public class ShizukuExecutor implements PrivilegeExecutor {

    private final Context ctx;

    public ShizukuExecutor(Context ctx) { this.ctx = ctx.getApplicationContext(); }

    @Override public String getId() { return "shizuku"; }
    @Override public String getLabel() { return "Shizuku"; }

    /** 反射调用 Shizuku 静态方法；失败返回 null */
    private static Object callStatic(String method, Class<?>[] types, Object... args) {
        try {
            Class<?> cls = Class.forName("rikka.shizuku.Shizuku");
            java.lang.reflect.Method m = cls.getMethod(method, types);
            m.setAccessible(true);
            return m.invoke(null, args);
        } catch (Throwable t) {
            return null;
        }
    }

    /** Binder 是否存活（带重试，避免刚启动时误判） */
    public boolean pingBinder() {
        for (int i = 0; i < 6; i++) {
            Object r = callStatic("pingBinder", null);
            if (r instanceof Boolean && (Boolean) r) return true;
            try { Thread.sleep(150); } catch (InterruptedException ignored) { break; }
        }
        return false;
    }

    /** 权限检查结果：0=已授权，其它=未授权或异常 */
    public int checkPermissionRaw() {
        Object r = callStatic("checkSelfPermission", null);
        return r instanceof Integer ? (Integer) r : -1;
    }

    @Override
    public boolean isAvailable() {
        // 1) Binder 是否连通
        if (!pingBinder()) {
            AppLog.w("Shizuku 不可用：Binder 未连接（请确认 Shizuku App 已启动并处于运行状态）");
            return false;
        }
        // 2) 是否已授权
        int r = checkPermissionRaw();
        if (r != PackageManager.PERMISSION_GRANTED) {
            AppLog.w("Shizuku 不可用：Binder 已连接但未授权（code=" + r + "），请在 Shizuku 的「已授权应用」中允许 MCP远程");
            return false;
        }
        return true;
    }

    /**
     * 详细诊断，用于界面提示。返回可读的原因说明。
     */
    public String diagnose() {
        if (!shizukuInstalled(ctx)) return "未检测到 Shizuku 应用（或受包可见性限制无法查询）";
        if (!pingBinder()) return "Shizuku 未运行，请打开 Shizuku 并启动服务";
        int r = checkPermissionRaw();
        if (r != PackageManager.PERMISSION_GRANTED) return "Shizuku 已运行但未授权本应用（code=" + r + "）";
        return "Shizuku 可用";
    }

    public static boolean shizukuInstalled(Context ctx) {
        try {
            ctx.getPackageManager().getPackageInfo("moe.shizuku.privileged.api", 0);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    @Override
    public ShellResult exec(String command, int timeoutSeconds) {
        try {
            Class<?> cls = Class.forName("rikka.shizuku.Shizuku");
            java.lang.reflect.Method newProcess =
                    cls.getMethod("newProcess", String[].class, String.class, String.class);
            Object proc = newProcess.invoke(null, new String[]{"sh", "-c", command}, null, null);
            if (proc == null) return new ShellResult(-1, "", "Shizuku newProcess 返回空", getId());

            InputStream in = (InputStream) proc.getClass().getMethod("getInputStream").invoke(proc);
            InputStream err = (InputStream) proc.getClass().getMethod("getErrorStream").invoke(proc);

            List<String> out = new ArrayList<>();
            List<String> errs = new ArrayList<>();
            Thread t1 = new Thread(() -> read(in, out));
            Thread t2 = new Thread(() -> read(err, errs));
            t1.start(); t2.start();

            int code = -1;
            try {
                java.lang.reflect.Method wf = proc.getClass().getMethod("waitFor");
                Object r = wf.invoke(proc);
                if (r instanceof Integer) code = (Integer) r;
            } catch (Throwable ignored) {}

            t1.join(3000); t2.join(3000);
            try { proc.getClass().getMethod("destroy").invoke(proc); } catch (Throwable ignored) {}

            return new ShellResult(code, join(out), join(errs), getId());
        } catch (Throwable t) {
            AppLog.e("Shizuku 执行失败", t);
            return new ShellResult(-1, "", String.valueOf(t.getMessage()), getId());
        }
    }

    private static void read(InputStream is, List<String> sink) {
        try (BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF-8"))) {
            String line;
            while ((line = br.readLine()) != null) {
                synchronized (sink) { sink.add(line); }
            }
        } catch (Throwable ignored) {}
    }

    private static String join(List<String> lines) {
        synchronized (lines) {
            StringBuilder sb = new StringBuilder();
            for (String l : lines) sb.append(l).append('\n');
            return sb.toString().trim();
        }
    }
}
