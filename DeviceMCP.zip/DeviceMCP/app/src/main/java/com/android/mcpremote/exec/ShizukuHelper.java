package com.android.mcpremote.exec;

import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.Looper;

import com.android.mcpremote.util.AppLog;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import rikka.shizuku.Shizuku;

/**
 * Shizuku 统一封装：初始化监听、权限申请、状态诊断。
 *
 * 关键修复：
 *  1) 使用官方 Shizuku API 而非反射，并在 Manifest 中声明 ShizukuProvider
 *     （此前仅靠反射调用，缺少 Provider 导致即便已授权也判定为不可用）。
 *  2) 提供 requestPermission()，未授权时弹出系统授权对话框（与 MT 管理器一致）。
 *  3) 注册 Binder 存活/死亡与授权结果回调，授权成功后自动通知界面刷新。
 */
public final class ShizukuHelper {

    public static final int REQ_CODE = 20240;

    private static boolean inited = false;
    private static final List<Runnable> GRANTED_CB = new CopyOnWriteArrayList<>();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private ShizukuHelper() {}

    /** 在 Application.onCreate 中调用一次 */
    public static synchronized void init(Context ctx) {
        if (inited) return;
        try {
            Shizuku.addBinderReceivedListener(() -> {
                AppLog.i("Shizuku：Binder 已连接");
                MAIN.post(ShizukuHelper::notifyStateChanged);
            });
            Shizuku.addBinderDeadListener(() -> {
                AppLog.w("Shizuku：Binder 已断开，请重新启动 Shizuku");
                MAIN.post(ShizukuHelper::notifyStateChanged);
            });
            Shizuku.addRequestPermissionResultListener((requestCode, grantResult) -> {
                if (requestCode != REQ_CODE) return;
                if (grantResult == PackageManager.PERMISSION_GRANTED) {
                    AppLog.i("Shizuku：授权成功");
                    MAIN.post(ShizukuHelper::notifyGranted);
                } else {
                    AppLog.w("Shizuku：授权被拒绝（code=" + grantResult + "）");
                }
                MAIN.post(ShizukuHelper::notifyStateChanged);
            });
            inited = true;
            AppLog.i("Shizuku：监听已注册");
        } catch (Throwable t) {
            AppLog.e("Shizuku：初始化失败", t);
        }
    }

    /** Binder 是否存活 */
    public static boolean isBinderAlive() {
        try {
            return Shizuku.pingBinder();
        } catch (Throwable t) {
            return false;
        }
    }

    /** 是否已授权 */
    public static boolean isGranted() {
        try {
            return Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) {
            return false;
        }
    }

    /** 是否完全可用（Binder 存活 + 已授权） */
    public static boolean isAvailable() {
        return isBinderAlive() && isGranted();
    }

    /** Shizuku 版本，未连接返回 -1 */
    public static int getVersion() {
        try {
            return Shizuku.getVersion();
        } catch (Throwable t) {
            return -1;
        }
    }

    /**
     * 申请 Shizuku 权限，弹出系统授权对话框（MT 管理器同款行为）。
     * 必须在主线程调用。
     *
     * @return 0=已授权直接返回；1=已发起申请；-1=Binder 未连接无法申请
     */
    public static int requestPermission() {
        if (!isBinderAlive()) {
            AppLog.w("Shizuku：Binder 未连接，无法弹出授权框。请先启动 Shizuku 服务。");
            return -1;
        }
        if (isGranted()) {
            return 0;
        }
        try {
            Shizuku.requestPermission(REQ_CODE);
            AppLog.i("Shizuku：已向系统发起授权请求");
            return 1;
        } catch (Throwable t) {
            AppLog.e("Shizuku：发起授权请求失败", t);
            return -1;
        }
    }

    /** 详细诊断，供界面提示 */
    public static String diagnose() {
        if (!isBinderAlive()) {
            return "Shizuku 未运行，请打开 Shizuku 并启动服务";
        }
        if (!isGranted()) {
            return "Shizuku 已运行但未授权本应用，将弹出授权请求";
        }
        return "Shizuku 可用（版本 " + getVersion() + "）";
    }

    /** 注册授权成功回调 */
    public static void addGrantedCallback(Runnable r) {
        if (r != null) GRANTED_CB.add(r);
    }

    public static void removeGrantedCallback(Runnable r) {
        if (r != null) GRANTED_CB.remove(r);
    }

    private static void notifyGranted() {
        for (Runnable r : GRANTED_CB) {
            try { r.run(); } catch (Throwable ignored) {}
        }
    }

    private static void notifyStateChanged() {
        // 状态变化由界面轮询刷新兜底，此处仅用于日志即时性
    }
}
