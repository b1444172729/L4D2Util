package com.android.mcpremote.util;

import android.content.Context;
import android.content.SharedPreferences;

/** 配置持久化：端口、Token、工作模式、悬浮窗、开机自启 */
public final class McpConfig {
    private static final String PREF = "device_mcp";
    public static final int DEFAULT_PORT = 9797;

    private static final String K_PORT = "port";
    private static final String K_TOKEN = "token";
    private static final String K_MODE = "mode";           // root / shizuku / accessibility
    private static final String K_FLOAT = "floating";
    private static final String K_AUTOSTART = "autostart";
    private static final String K_FLOAT_X = "float_x";
    private static final String K_FLOAT_Y = "float_y";

    /** 工作模式常量：ROOT / Shizuku / 无障碍 */
    public static final String MODE_ROOT = "root";
    public static final String MODE_SHIZUKU = "shizuku";
    public static final String MODE_ACCESSIBILITY = "accessibility";

    private final SharedPreferences sp;

    public McpConfig(Context ctx) {
        sp = ctx.getApplicationContext().getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    public int getPort() { return sp.getInt(K_PORT, DEFAULT_PORT); }
    public void setPort(int p) { sp.edit().putInt(K_PORT, p).apply(); }

    public String getToken() { return sp.getString(K_TOKEN, ""); }
    public void setToken(String t) { sp.edit().putString(K_TOKEN, t == null ? "" : t).apply(); }

    public String getMode() { return sp.getString(K_MODE, MODE_ROOT); }
    public void setMode(String m) { sp.edit().putString(K_MODE, m).apply(); }

    public boolean isFloating() { return sp.getBoolean(K_FLOAT, false); }
    public void setFloating(boolean f) { sp.edit().putBoolean(K_FLOAT, f).apply(); }

    public boolean isAutoStart() { return sp.getBoolean(K_AUTOSTART, false); }
    public void setAutoStart(boolean f) { sp.edit().putBoolean(K_AUTOSTART, f).apply(); }

    /** 悬浮窗位置记忆 */
    public int getFloatX() { return sp.getInt(K_FLOAT_X, 20); }
    public int getFloatY() { return sp.getInt(K_FLOAT_Y, 180); }
    public void setFloatPos(int x, int y) { sp.edit().putInt(K_FLOAT_X, x).putInt(K_FLOAT_Y, y).apply(); }

    /** 生成随机 token */
    public static String randomToken() {
        final String CH = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        StringBuilder sb = new StringBuilder();
        java.security.SecureRandom r = new java.security.SecureRandom();
        for (int i = 0; i < 32; i++) sb.append(CH.charAt(r.nextInt(CH.length())));
        return sb.toString();
    }
}
