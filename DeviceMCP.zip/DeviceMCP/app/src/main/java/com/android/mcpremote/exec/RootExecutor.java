package com.android.mcpremote.exec;

import com.android.mcpremote.util.AppLog;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/** ROOT 执行器：通过 su -c 提权 */
public class RootExecutor implements PrivilegeExecutor {

    private static final String[] SU_CANDIDATES = {"/system/bin/su", "/system/xbin/su", "/sbin/su", "/su/bin/su"};

    @Override public String getId() { return "root"; }
    @Override public String getLabel() { return "ROOT"; }

    @Override
    public boolean isAvailable() {
        for (String p : SU_CANDIDATES) {
            if (new java.io.File(p).exists()) return true;
        }
        // 部分机型 su 不在固定路径，直接尝试执行 id
        try {
            ShellResult r = ExecSupport.run(new String[]{"su", "-c", "id"}, 6);
            return r != null && r.exitCode == 0 && r.stdout.contains("uid=0");
        } catch (Throwable t) {
            return false;
        }
    }

    @Override
    public ShellResult exec(String command, int timeoutSeconds) {
        return ExecSupport.run(new String[]{"su", "-c", command}, timeoutSeconds, getId());
    }

    /** 通用进程运行器，供其它执行器复用 */
    static final class ExecSupport {
        static ShellResult run(String[] cmd, int timeoutSeconds) { return run(cmd, timeoutSeconds, "app"); }

        static ShellResult run(String[] cmd, int timeoutSeconds, String via) {
            Process proc = null;
            try {
                ProcessBuilder pb = new ProcessBuilder(cmd);
                pb.redirectErrorStream(false);
                proc = pb.start();
                final Process p = proc;
                List<String> outLines = new ArrayList<>();
                List<String> errLines = new ArrayList<>();
                Thread t1 = new Thread(() -> readInto(p.getInputStream(), outLines));
                Thread t2 = new Thread(() -> readInto(p.getErrorStream(), errLines));
                t1.start(); t2.start();

                boolean done = proc.waitFor(timeoutSeconds, java.util.concurrent.TimeUnit.SECONDS);
                if (!done) {
                    proc.destroyForcibly();
                    return new ShellResult(-1, join(outLines), join(errLines) + "\n[timeout]", via);
                }
                t1.join(2000); t2.join(2000);
                return new ShellResult(proc.exitValue(), join(outLines), join(errLines), via);
            } catch (Throwable t) {
                AppLog.e("执行失败: " + java.util.Arrays.toString(cmd), t);
                return new ShellResult(-1, "", String.valueOf(t.getMessage()), via);
            } finally {
                if (proc != null) { try { proc.destroy(); } catch (Throwable ignored) {} }
            }
        }

        private static void readInto(java.io.InputStream is, List<String> sink) {
            try (BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF-8"))) {
                String line;
                while ((line = br.readLine()) != null) {
                    synchronized (sink) { sink.add(line); }
                }
            } catch (Throwable ignored) {}
        }

        private static String join(List<String> lines) {
            synchronized (lines) {
                StringBuilder sb = new StringBuilder();
                for (String l : lines) sb.append(l).append('\n');
                return sb.toString().trim();
            }
        }
    }
}
