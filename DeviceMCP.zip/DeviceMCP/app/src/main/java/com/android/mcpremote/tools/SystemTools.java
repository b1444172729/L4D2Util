package com.android.mcpremote.tools;

import android.content.Context;

import com.android.mcpremote.exec.ExecutionEngine;
import com.android.mcpremote.exec.ShellResult;
import com.android.mcpremote.server.ToolDefinition;
import com.android.mcpremote.util.Json;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 系统工具类：通知栏、日志、系统设置。
 *
 * 权限说明：
 *  - 通知读取依赖 dumpsys notification，需 shell 权限（ROOT / Shizuku）
 *  - 系统设置读写依赖 settings 命令与 svc，需 shell 权限
 *  - 音量/亮度等部分操作 shell 权限即可，无需 ROOT
 */
public final class SystemTools {

    public static List<ToolDefinition> all(Context ctx) {
        List<ToolDefinition> list = new ArrayList<>();

        // ==================== 通知栏 ====================

        list.add(new ToolDefinition("dev_notification_list",
                "读取通知栏当前通知（标题、内容、来源包名、时间）。可用于读取验证码、消息提醒等。",
                Json.schema(Json.obj(
                        "maxCount", Json.intProp("最多返回条数，默认 20")), "maxCount")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                int max = a.optInt("maxCount", 20);
                ShellResult r = engine.exec("dumpsys notification --noredact", null, 30);
                String out = r.stdout == null ? "" : r.stdout;
                if (out.trim().isEmpty()) {
                    return Json.errorResult("未读取到通知，需 ROOT 或 Shizuku 权限");
                }
                JSONArray arr = parseNotifications(out, max);
                if (arr.length() == 0) {
                    return Json.textResult("通知栏为空（或无权限读取）");
                }
                return Json.textResult("通知 " + arr.length() + " 条：\n" + Json.fmt(arr));
            }
        });

        list.add(new ToolDefinition("dev_notification_action",
                "展开通知栏（下拉状态栏），便于后续用坐标或文本点击通知。" +
                        "展开后可配合 dev_ui_click_text 点击具体通知，或用 dev_ui_key 收起。",
                Json.schema(Json.obj(
                        "action", Json.strProp("操作：expand（展开，默认）/ collapse（收起）")), "action")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                String act = a.optString("action", "expand");
                String cmd = "collapse".equals(act)
                        ? "cmd statusbar collapse"
                        : "cmd statusbar expand-notifications";
                ShellResult r = engine.exec(cmd, null, 15);
                return r.ok() ? Json.textResult("已" + ("collapse".equals(act) ? "收起" : "展开") + "通知栏")
                              : Json.errorResult("操作失败：" + r.combined());
            }
        });

        list.add(new ToolDefinition("dev_notification_clear",
                "清除通知：展开通知栏后尝试点击「清除/清空」按钮。部分 ROM 按钮文案不同，" +
                        "若失败可改用 dev_ui_click_xy 点击清除按钮坐标。",
                Json.schema(Json.obj(
                        "text", Json.strProp("清除按钮文案，默认「清除」；部分 ROM 为「清空」「全部清除」")), "text")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                String custom = a.optString("text", "");
                List<String> candidates = new ArrayList<>();
                if (!custom.isEmpty()) candidates.add(custom);
                candidates.add("清除");
                candidates.add("清空");
                candidates.add("全部清除");
                candidates.add("清空所有");
                engine.exec("cmd statusbar expand-notifications", null, 15);
                try { Thread.sleep(800); } catch (InterruptedException ignored) {}
                for (String t : candidates) {
                    ShellResult find = engine.exec(
                            "uiautomator dump /sdcard/mcp_n.xml >/dev/null 2>&1; grep -o 'text=\"[^\"]*" + t + "[^\"]*\"' /sdcard/mcp_n.xml | head -1",
                            null, 25);
                    if (find.stdout != null && find.stdout.contains(t)) {
                        // 用坐标点击：解析该节点 bounds
                        ShellResult bounds = engine.exec(
                                "grep -o 'bounds=\"[^\"]*\"[^>]*text=\"[^\"]*" + t + "[^\"]*\"' /sdcard/mcp_n.xml | head -1",
                                null, 15);
                        String bs = bounds.stdout == null ? "" : bounds.stdout;
                        Matcher m = Pattern.compile("\\[(\\d+),(\\d+)\\]\\[(\\d+),(\\d+)\\]").matcher(bs);
                        if (m.find()) {
                            int cx = (Integer.parseInt(m.group(1)) + Integer.parseInt(m.group(3))) / 2;
                            int cy = (Integer.parseInt(m.group(2)) + Integer.parseInt(m.group(4))) / 2;
                            ShellResult tap = engine.exec("input tap " + cx + " " + cy, null, 15);
                            if (tap.ok()) return Json.textResult("已点击「" + t + "」清除通知");
                        }
                    }
                }
                return Json.errorResult("未找到清除按钮，请手动点击或改用 dev_ui_click_xy。"
                        + "也可先用 dev_ui_get_text 查看通知栏上的实际按钮文案。");
            }
        });

        // ==================== 日志 ====================

        list.add(new ToolDefinition("dev_logcat",
                "读取 logcat 日志。用于调试应用、查看崩溃信息、确认操作是否生效。",
                Json.schema(Json.obj(
                        "lines", Json.intProp("读取行数，默认 100"),
                        "filter", Json.strProp("过滤关键字，可选（对结果做包含过滤）"),
                        "level", Json.strProp("日志级别：V/D/I/W/E，留空表示全部")),
                        "lines")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                int lines = a.optInt("lines", 100);
                String filter = a.optString("filter", "");
                String level = a.optString("level", "").toUpperCase();
                StringBuilder cmd = new StringBuilder("logcat -d -t ").append(lines);
                if (!level.isEmpty()) cmd.append(" *:").append(level);
                ShellResult r = engine.exec(cmd.toString(), null, 30);
                String out = r.stdout == null ? "" : r.stdout;
                if (out.trim().isEmpty()) return Json.textResult("(无日志输出)");
                if (!filter.isEmpty()) {
                    StringBuilder sb = new StringBuilder();
                    for (String line : out.split("\n")) {
                        if (line.contains(filter)) sb.append(line).append('\n');
                    }
                    out = sb.toString();
                    if (out.trim().isEmpty()) return Json.textResult("(过滤后无匹配: " + filter + ")");
                }
                // 限制返回长度，避免超长
                if (out.length() > 8000) out = out.substring(0, 8000) + "\n...(已截断)";
                return Json.textResult(out);
            }
        });

        list.add(new ToolDefinition("dev_logcat_clear", "清空 logcat 日志缓冲区。",
                Json.schema(new JSONObject())) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                ShellResult r = engine.exec("logcat -c", null, 15);
                return r.ok() ? Json.textResult("日志已清空")
                              : Json.errorResult("清空失败：" + r.combined());
            }
        });

        list.add(new ToolDefinition("dev_dumpsys",
                "执行 dumpsys 获取系统服务信息（如 battery、wifi、meminfo、cpuinfo、package 等）。" +
                        "这是一个通用接口，可查询任意系统服务状态。",
                Json.schema(Json.obj(
                        "service", Json.strProp("服务名，如 battery / wifi / meminfo / cpuinfo / package / activity"),
                        "args", Json.strProp("附加参数，可选（如包名）"),
                        "maxChars", Json.intProp("返回最大字符数，默认 6000")),
                        "service")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                String svc = a.optString("service", "");
                String args = a.optString("args", "");
                int max = a.optInt("maxChars", 6000);
                if (svc.isEmpty()) return Json.errorResult("service 不能为空");
                String cmd = "dumpsys " + svc + (args.isEmpty() ? "" : " " + args);
                ShellResult r = engine.exec(cmd, null, 30);
                String out = r.stdout == null ? "" : r.stdout;
                if (out.trim().isEmpty()) out = r.stderr == null ? "" : r.stderr;
                if (out.trim().isEmpty()) return Json.errorResult("dumpsys 无输出，可能服务名错误或无权限");
                if (out.length() > max) out = out.substring(0, max) + "\n...(已截断，共 " + out.length() + " 字符)";
                return Json.textResult(out);
            }
        });

        // ==================== 系统设置 ====================

        list.add(new ToolDefinition("dev_settings_get",
                "读取系统设置项。namespace 可选 system / secure / global。",
                Json.schema(Json.obj(
                        "namespace", Json.strProp("命名空间：system|secure|global，默认 system"),
                        "key", Json.strProp("设置项名称")),
                        "key")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                String ns = a.optString("namespace", "system");
                String key = a.optString("key", "");
                if (key.isEmpty()) return Json.errorResult("key 不能为空");
                ShellResult r = engine.exec("settings get " + ns + " " + key, null, 15);
                String v = r.stdout == null ? "" : r.stdout.trim();
                return Json.textResult(Json.fmt(Json.obj("namespace", ns, "key", key, "value", v)));
            }
        });

        list.add(new ToolDefinition("dev_settings_put",
                "写入系统设置项。需 shell 权限。谨慎使用，错误的设置可能影响系统稳定性。",
                Json.schema(Json.obj(
                        "namespace", Json.strProp("命名空间：system|secure|global，默认 system"),
                        "key", Json.strProp("设置项名称"),
                        "value", Json.strProp("要写入的值")),
                        "key", "value")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                String ns = a.optString("namespace", "system");
                String key = a.optString("key", "");
                String val = a.optString("value", "");
                if (key.isEmpty()) return Json.errorResult("key 不能为空");
                ShellResult r = engine.exec("settings put " + ns + " " + key + " " + val, null, 15);
                return r.ok() ? Json.textResult("已设置 " + ns + "/" + key + " = " + val)
                              : Json.errorResult("设置失败：" + r.combined());
            }
        });

        list.add(new ToolDefinition("dev_settings_volume",
                "调节音量。可设置具体数值，或按方向增减。",
                Json.schema(Json.obj(
                        "stream", Json.strProp("音量类型：media|ring|alarm|notification|call，默认 media"),
                        "value", Json.intProp("具体音量值（与 direction 二选一）"),
                        "direction", Json.strProp("调节方向：up|down（与 value 二选一）"),
                        "showUi", Json.boolProp("是否显示系统音量条，默认 false")),
                        "stream")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                String stream = a.optString("stream", "media");
                int streamNum = streamNumber(stream);
                boolean showUi = a.optBoolean("showUi", false);
                String dir = a.optString("direction", "");
                String cmd;
                if (a.has("value")) {
                    cmd = "cmd media_session volume --stream " + streamNum
                            + " --set " + a.optInt("value", 5) + (showUi ? " --show" : "");
                } else if ("up".equals(dir)) {
                    cmd = "cmd media_session volume --stream " + streamNum + " --adj raise"
                            + (showUi ? " --show" : "");
                } else if ("down".equals(dir)) {
                    cmd = "cmd media_session volume --stream " + streamNum + " --adj lower"
                            + (showUi ? " --show" : "");
                } else {
                    // 查询当前音量
                    ShellResult q = engine.exec("cmd media_session volume --stream "
                            + streamNum + " --get", null, 15);
                    return Json.textResult("当前 " + stream + " 音量：\n"
                            + (q.stdout == null ? "(未知)" : q.stdout.trim()));
                }
                ShellResult r = engine.exec(cmd, null, 15);
                if (!r.ok()) {
                    // 回退：用 input keyevent
                    String alt = "up".equals(dir) ? "input keyevent 24" : "input keyevent 25";
                    ShellResult r2 = engine.exec(alt, null, 15);
                    if (r2.ok()) return Json.textResult("已通过按键调节音量（" + dir + "）");
                    return Json.errorResult("音量调节失败：" + r.combined());
                }
                return Json.textResult("音量已调节");
            }
        });

        list.add(new ToolDefinition("dev_settings_brightness",
                "调节屏幕亮度（0-255）。设置后自动写入系统设置使其生效。",
                Json.schema(Json.obj(
                        "value", Json.intProp("亮度值 0-255"),
                        "auto", Json.boolProp("是否恢复自动亮度，默认 false")),
                        "value")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                if (a.optBoolean("auto", false)) {
                    engine.exec("settings put system screen_brightness_mode 1", null, 15);
                    return Json.textResult("已恢复自动亮度");
                }
                int v = a.optInt("value", 128);
                if (v < 0) v = 0;
                if (v > 255) v = 255;
                engine.exec("settings put system screen_brightness_mode 0", null, 15);
                ShellResult r = engine.exec("settings put system screen_brightness " + v, null, 15);
                return r.ok() ? Json.textResult("亮度已设为 " + v + "（0-255，已关闭自动亮度）")
                              : Json.errorResult("设置失败：" + r.combined());
            }
        });

        list.add(new ToolDefinition("dev_settings_torch",
                "开关手电筒（闪光灯）。依赖设备的 sysfs 节点，不同机型路径不同；" +
                        "若全部路径都不可用会返回失败。",
                Json.schema(Json.obj(
                        "on", Json.boolProp("true=打开，false=关闭")), "on")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                boolean on = a.optBoolean("on", true);
                String v = on ? "1" : "0";
                String[] paths = {
                        "/sys/class/leds/torch-light/brightness",
                        "/sys/class/leds/flashlight/brightness",
                        "/sys/class/leds/led:torch_0/brightness",
                        "/sys/class/leds/led:flash_0/brightness",
                        "/sys/class/flashlight_core/flashlight/flashlight_ma/brightness",
                        "/sys/class/camera/flash/rear_flash/brightness",
                        "/sys/kernel/debug/flashlight/torch",
                };
                for (String p : paths) {
                    ShellResult chk = engine.exec("test -w " + p + " && echo OK", null, 8);
                    if (chk.stdout != null && chk.stdout.contains("OK")) {
                        ShellResult w = engine.exec("echo " + v + " > " + p, null, 10);
                        if (w.ok()) {
                            return Json.textResult("手电筒已" + (on ? "打开" : "关闭") + "（" + p + "）");
                        }
                    }
                }
                return Json.errorResult("未找到可写手电筒节点，该机型可能不支持 shell 方式控制闪光灯");
            }
        });

        list.add(new ToolDefinition("dev_settings_wifi",
                "开关 WiFi。需 shell 权限（svc 命令）。",
                Json.schema(Json.obj("enabled", Json.boolProp("true=开启，false=关闭")), "enabled")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                boolean en = a.optBoolean("enabled", true);
                ShellResult r = engine.exec("svc wifi " + (en ? "enable" : "disable"), null, 20);
                return r.ok() ? Json.textResult("WiFi 已" + (en ? "开启" : "关闭"))
                              : Json.errorResult("操作失败：" + r.combined());
            }
        });

        list.add(new ToolDefinition("dev_settings_bluetooth",
                "开关蓝牙。需 shell 权限（svc 命令）。注意：Android 高版本上 svc bluetooth 可能被限制。",
                Json.schema(Json.obj("enabled", Json.boolProp("true=开启，false=关闭")), "enabled")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                boolean en = a.optBoolean("enabled", true);
                ShellResult r = engine.exec("svc bluetooth " + (en ? "enable" : "disable"), null, 20);
                if (!r.ok()) {
                    // 回退方案
                    ShellResult r2 = engine.exec(en
                            ? "cmd bluetooth_manager enable"
                            : "cmd bluetooth_manager disable", null, 20);
                    if (r2.ok()) return Json.textResult("蓝牙已" + (en ? "开启" : "关闭"));
                    return Json.errorResult("操作失败：" + r.combined());
                }
                return Json.textResult("蓝牙已" + (en ? "开启" : "关闭"));
            }
        });

        list.add(new ToolDefinition("dev_settings_airplane",
                "开关飞行模式。会同时写入设置并发送系统广播使其生效。",
                Json.schema(Json.obj("enabled", Json.boolProp("true=开启，false=关闭")), "enabled")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                boolean en = a.optBoolean("enabled", true);
                String v = en ? "1" : "0";
                engine.exec("settings put global airplane_mode_on " + v, null, 15);
                ShellResult r = engine.exec(
                        "am broadcast -a android.intent.action.AIRPLANE_MODE --ez state " + en, null, 15);
                return r.ok() ? Json.textResult("飞行模式已" + (en ? "开启" : "关闭"))
                              : Json.errorResult("设置已写入但广播失败：" + r.combined());
            }
        });

        return list;
    }

    // ---------------- 辅助 ----------------

    /** 解析 dumpsys notification 输出 */
    private static JSONArray parseNotifications(String dump, int max) {
        JSONArray arr = new JSONArray();
        // dumpsys notification 常见格式包含 pkg=、以及 NotificationRecord 块中的 title/text
        String[] blocks = dump.split("NotificationRecord");
        for (String b : blocks) {
            if (arr.length() >= max) break;
            String pkg = matchOne(b, "pkg=([^\\s]+)");
            String title = matchOne(b, "android.title=([^\\n]*)");
            String text = matchOne(b, "android.text=([^\\n]*)");
            String when = matchOne(b, "when=([^\\s]+)");
            if (pkg == null && title == null && text == null) continue;
            arr.put(Json.obj(
                    "pkg", pkg == null ? "" : pkg,
                    "title", title == null ? "" : title,
                    "text", text == null ? "" : text,
                    "when", when == null ? "" : when
            ));
        }
        // 若按 NotificationRecord 切分没结果，退化为按行提取
        if (arr.length() == 0) {
            for (String line : dump.split("\n")) {
                if (arr.length() >= max) break;
                if (line.contains("pkg=") || line.contains("android.title=")) {
                    arr.put(Json.obj("raw", line.trim()));
                }
            }
        }
        return arr;
    }

    private static String matchOne(String s, String regex) {
        Matcher m = Pattern.compile(regex).matcher(s);
        return m.find() ? m.group(1).trim() : null;
    }

    /** 音量流类型 → 数字 */
    private static int streamNumber(String stream) {
        switch (stream) {
            case "ring": return 2;
            case "alarm": return 4;
            case "notification": return 5;
            case "call": return 0;
            case "media":
            default: return 3;
        }
    }
}
