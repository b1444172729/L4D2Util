package com.android.mcpremote.service;

import android.graphics.Bitmap;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import com.android.mcpremote.MainActivity;
import com.android.mcpremote.R;
import com.android.mcpremote.exec.ExecutionEngine;
import com.android.mcpremote.server.McpHttpServer;
import com.android.mcpremote.util.AppLog;
import com.android.mcpremote.util.McpConfig;
import com.android.mcpremote.util.NetworkUtils;

/** 前台服务：托管 MCP HTTP 服务器，保证后台长期运行 */
public class McpForegroundService extends Service {

    public static final String ACTION_START = "com.android.mcpremote.action.START";
    public static final String ACTION_STOP = "com.android.mcpremote.action.STOP";
    public static final String ACTION_REFRESH = "com.android.mcpremote.action.REFRESH";
    public static final String EXTRA_PORT = "port";
    public static final String EXTRA_TOKEN = "token";

    private static final String CHANNEL_ID = "device_mcp";
    private static final int NOTIFY_ID = 0x6d63;

    private static McpHttpServer server;
    private PowerManager.WakeLock wakeLock;
    private final android.os.Handler ui = new android.os.Handler(android.os.Looper.getMainLooper());

    public static boolean isServerRunning() { return server != null && server.isRunning(); }
    public static int getRunningPort() { return server != null ? server.getPort() : -1; }

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        acquireWakeLock();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : ACTION_START;
        if (ACTION_STOP.equals(action)) {
            stopServer();
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_REFRESH.equals(action)) {
            updateNotification();
            return START_STICKY;
        }

        McpConfig cfg = new McpConfig(this);
        int port = intent != null && intent.hasExtra(EXTRA_PORT)
                ? intent.getIntExtra(EXTRA_PORT, cfg.getPort()) : cfg.getPort();
        String token = intent != null && intent.hasExtra(EXTRA_TOKEN)
                ? intent.getStringExtra(EXTRA_TOKEN) : cfg.getToken();

        startForeground(NOTIFY_ID, buildNotification(port));
        startServer(port, token);

        // 若配置了悬浮窗，同步拉起
        if (cfg.isFloating()) {
            try { startService(new Intent(this, FloatingWindowService.class)); }
            catch (Throwable t) { AppLog.w("拉起悬浮窗失败: " + t.getMessage()); }
        }
        return START_STICKY;
    }

    private void startServer(int port, String token) {
        stopServer();
        server = new McpHttpServer(this, token);
        try {
            // 绑定 0.0.0.0：允许局域网客户端访问
            server.start(port, "0.0.0.0");
            int real = server.getPort();
            String lan = NetworkUtils.getWifiIpv4(this);
            AppLog.i("服务就绪 → 本地 http://127.0.0.1:" + real + "/mcp");
            if (lan != null) AppLog.i("服务就绪 → 局域网 http://" + lan + ":" + real + "/mcp");
            updateNotification();
        } catch (Throwable t) {
            AppLog.e("启动失败（端口被占用？）: " + t.getMessage());
            server = null;
        }
    }

    private void stopServer() {
        if (server != null) { try { server.stop(); } catch (Throwable ignored) {} }
        server = null;
    }

    private void acquireWakeLock() {
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MCPRemote:server");
            wakeLock.acquire(60 * 60 * 1000L);
        } catch (Throwable ignored) {}
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "MCP远程服务",
                    NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("MCP远程 本地 MCP 服务运行状态");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }

    private Notification buildNotification(int port) {
        Intent i = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 1, i,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));

        String lan = NetworkUtils.getWifiIpv4(this);
        String text = "本地 http://127.0.0.1:" + port + "/mcp"
                + (lan != null ? "\n局域网 http://" + lan + ":" + port + "/mcp" : "");

        androidx.core.app.NotificationCompat.Builder nb =
                new androidx.core.app.NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("MCP远程 运行中")
                .setContentText(text)
                .setStyle(new androidx.core.app.NotificationCompat.BigTextStyle().bigText(text))
                // 状态栏小图标：必须是白色剪影 + 透明底（Android 5.0+ 规范），
                // 使用 PNG 而非 vector，避免部分 ROM 对 vector 的 tint 处理异常
                .setSmallIcon(R.drawable.ic_stat_notify)
                .setContentIntent(pi)
                .setOngoing(true);

        // 通知左侧大图标：显式指定彩色云朵位图。
        // 不设置时，MIUI/澎湃OS 等 ROM 会自动填充应用图标，
        // 可能取到缓存中的旧图标，因此这里主动设置以确保显示新图标。
        android.graphics.Bitmap large = android.graphics.BitmapFactory.decodeResource(
                getResources(), R.drawable.ic_notify_large);
        if (large != null) nb.setLargeIcon(large);

        return nb.build();
    }

    private void updateNotification() {
        if (server == null) return;
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(NOTIFY_ID, buildNotification(server.getPort()));
    }

    @Override public void onDestroy() {
        ui.removeCallbacksAndMessages(null);
        stopServer();
        try { if (wakeLock != null && wakeLock.isHeld()) wakeLock.release(); } catch (Throwable ignored) {}
        super.onDestroy();
    }
}
