package com.android.mcpremote.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import com.android.mcpremote.MainActivity;
import com.android.mcpremote.R;
import com.android.mcpremote.exec.ExecutionEngine;
import com.android.mcpremote.server.McpHttpServer;
import com.android.mcpremote.util.AccessibilityBoost;
import com.android.mcpremote.util.AppLog;
import com.android.mcpremote.util.McpConfig;
import com.android.mcpremote.util.NetworkUtils;

/** 前台服务：托管 MCP HTTP 服务器，保证后台长期运行 */
public class McpForegroundService extends Service {

    public static final String ACTION_START = "com.android.mcpremote.action.START";
    public static final String ACTION_STOP = "com.android.mcpremote.action.STOP";
    public static final String ACTION_REFRESH = "com.android.mcpremote.action.REFRESH";
    public static final String EXTRA_PORT = "port";
    public static final String EXTRA_TOKEN = "token";

    private static final String CHANNEL_ID = "device_mcp";
    private static final int NOTIFY_ID = 0x6d63;

    private static McpHttpServer server;
    private PowerManager.WakeLock wakeLock;
    private final android.os.Handler ui = new android.os.Handler(android.os.Looper.getMainLooper());

    public static boolean isServerRunning() { return server != null && server.isRunning(); }
    public static int getRunningPort() { return server != null ? server.getPort() : -1; }

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        acquireWakeLock();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : ACTION_START;
        if (ACTION_STOP.equals(action)) {
            stopServer();
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_REFRESH.equals(action)) {
            updateNotification();
            return START_STICKY;
        }

        McpConfig cfg = new McpConfig(this);
        int port = intent != null && intent.hasExtra(EXTRA_PORT)
                ? intent.getIntExtra(EXTRA_PORT, cfg.getPort()) : cfg.getPort();
        String token = intent != null && intent.hasExtra(EXTRA_TOKEN)
                ? intent.getStringExtra(EXTRA_TOKEN) : cfg.getToken();

        startForeground(NOTIFY_ID, buildNotification(port));
        startServer(port, token);

        // 启动无障碍看门狗：检测到掉线且具备提权时自动恢复
        startAccessibilityWatchdog();

        // 若配置了悬浮窗，同步拉起
        if (cfg.isFloating()) {
            try { startService(new Intent(this, FloatingWindowService.class)); }
            catch (Throwable t) { AppLog.w("拉起悬浮窗失败: " + t.getMessage()); }
        }
        return START_STICKY;
    }

    private void startServer(int port, String token) {
        stopServer();
        server = new McpHttpServer(this, token);
        try {
            // 绑定 0.0.0.0：允许局域网客户端访问
            server.start(port, "0.0.0.0");
            int real = server.getPort();
            String lan = NetworkUtils.getWifiIpv4(this);
            AppLog.i("服务就绪 → 本地 http://127.0.0.1:" + real + "/mcp");
            if (lan != null) AppLog.i("服务就绪 → 局域网 http://" + lan + ":" + real + "/mcp");
            updateNotification();
        } catch (Throwable t) {
            AppLog.e("启动失败（端口被占用？）: " + t.getMessage());
            server = null;
        }
    }

    /**
     * 无障碍看门狗：部分 ROM 会自动关闭无障碍开关。
     * 当工作模式为「无障碍」且服务未连接、同时具备 ROOT/Shizuku 时，自动重新写入系统设置恢复。
     */
    private void startAccessibilityWatchdog() {
        ui.removeCallbacksAndMessages(null);
        ui.postDelayed(new Runnable() {
            @Override public void run() {
                try {
                    McpConfig cfg = new McpConfig(McpForegroundService.this);
                    if (McpConfig.MODE_ACCESSIBILITY.equals(cfg.getMode())
                            && !DeviceAccessibilityService.isEnabled()) {
                        ExecutionEngine engine = new ExecutionEngine(McpForegroundService.this);
                        if (engine.hasElevated()) {
                            AppLog.w("检测到无障碍被关闭，尝试自动恢复…");
                            new Thread(() -> {
                                AccessibilityBoost.Result r =
                                        AccessibilityBoost.enable(McpForegroundService.this, engine, cfg.getMode());
                                AppLog.i("无障碍恢复结果: " + (r.ok ? "成功 via " + r.via : "未成功"));
                            }).start();
                        }
                    }
                } catch (Throwable ignored) {}
                ui.postDelayed(this, 30000);
            }
        }, 30000);
    }

    private void stopServer() {
        if (server != null) { try { server.stop(); } catch (Throwable ignored) {} }
        server = null;
    }

    private void acquireWakeLock() {
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MCPRemote:server");
            wakeLock.acquire(60 * 60 * 1000L);
        } catch (Throwable ignored) {}
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "MCP远程服务",
                    NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("MCP远程 本地 MCP 服务运行状态");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }

    private Notification buildNotification(int port) {
        Intent i = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 1, i,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));

        String lan = NetworkUtils.getWifiIpv4(this);
        String text = "本地 http://127.0.0.1:" + port + "/mcp"
                + (lan != null ? "\n局域网 http://" + lan + ":" + port + "/mcp" : "");

        return new androidx.core.app.NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("MCP远程 运行中")
                .setContentText(text)
                .setStyle(new androidx.core.app.NotificationCompat.BigTextStyle().bigText(text))
                .setSmallIcon(R.drawable.ic_mcp_logo)
                // 部分 ROM（如 MIUI/澎湃OS）通知栏直接取应用图标，
                // 这里用彩色云朵版本，可确保显示的是新图标而非旧图标缓存
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
    }

    private void updateNotification() {
        if (server == null) return;
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(NOTIFY_ID, buildNotification(server.getPort()));
    }

    @Override public void onDestroy() {
        ui.removeCallbacksAndMessages(null);
        stopServer();
        try { if (wakeLock != null && wakeLock.isHeld()) wakeLock.release(); } catch (Throwable ignored) {}
        super.onDestroy();
    }
}
