package com.android.mcpremote;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.android.mcpremote.exec.ExecutionEngine;
import com.android.mcpremote.exec.ShizukuHelper;
import com.android.mcpremote.service.FloatingWindowService;
import com.android.mcpremote.service.McpForegroundService;
import com.android.mcpremote.util.AppLog;
import com.android.mcpremote.util.McpConfig;
import com.android.mcpremote.util.NetworkUtils;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private McpConfig cfg;
    private ExecutionEngine engine;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private TextView tvStatus, tvAddrLocal, tvAddrLan, tvLog, tvPriv;
    /** 供点击复制使用的纯 URL（不含前缀文字） */
    private volatile String localUrl = "";
    private volatile String lanUrl = "";
    /** Shizuku 授权成功回调 */
    private final Runnable shizukuGrantedCb = this::onShizukuGranted;
    /** 防止重复弹出授权框 */
    private volatile boolean shizukuRequesting = false;
    private TextView tvModeSummary, tvPortSummary, tvKeepSummary;
    private Button btnToggle;
    private EditText etPort, etToken;
    private RadioGroup rgMode;
    private CheckBox cbFloat;

    // 三个可展开面板
    private LinearLayout panelMode, panelPort, panelKeep;
    private ImageView arrowMode, arrowPort, arrowKeep;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cfg = new McpConfig(this);
        engine = new ExecutionEngine(this);

        bindViews();
        initAdvancedMenu();
        loadConfig();

        AppLog.setListener(line -> ui.post(() -> tvLog.setText(AppLog.snapshot())));
        ShizukuHelper.addGrantedCallback(shizukuGrantedCb);

        requestNotificationPermission();
        ui.post(this::refresh);
        startRefreshTimer();
    }

    @Override
    protected void onDestroy() {
        ShizukuHelper.removeGrantedCallback(shizukuGrantedCb);
        super.onDestroy();
    }

    private void bindViews() {
        tvStatus = findViewById(R.id.tv_status);
        tvAddrLocal = findViewById(R.id.tv_addr_local);
        tvAddrLan = findViewById(R.id.tv_addr_lan);
        tvLog = findViewById(R.id.tv_log);
        tvPriv = findViewById(R.id.tv_priv);
        btnToggle = findViewById(R.id.btn_toggle);
        etPort = findViewById(R.id.et_port);
        etToken = findViewById(R.id.et_token);
        rgMode = findViewById(R.id.rg_mode);
        cbFloat = findViewById(R.id.cb_float);

        tvModeSummary = findViewById(R.id.tv_work_mode_summary);
        tvPortSummary = findViewById(R.id.tv_port_summary);
        tvKeepSummary = findViewById(R.id.tv_keepalive_summary);

        panelMode = findViewById(R.id.panel_work_mode);
        panelPort = findViewById(R.id.panel_port);
        panelKeep = findViewById(R.id.panel_keepalive);

        arrowMode = findViewById(R.id.iv_arrow_mode);
        arrowPort = findViewById(R.id.iv_arrow_port);
        arrowKeep = findViewById(R.id.iv_arrow_keepalive);

        tvLog.setMovementMethod(new ScrollingMovementMethod());

        btnToggle.setOnClickListener(v -> toggle());
        findViewById(R.id.btn_save).setOnClickListener(v -> saveConfig());
        findViewById(R.id.btn_float_perm).setOnClickListener(v -> requestOverlay());
        findViewById(R.id.btn_battery).setOnClickListener(v -> requestBattery());

        tvAddrLocal.setOnClickListener(v -> copy(localUrl, "本地网络地址"));
        tvAddrLan.setOnClickListener(v -> copy(lanUrl, "局域网络地址"));

        // 悬浮窗勾选后立即生效，无需等待服务重启
        cbFloat.setOnCheckedChangeListener((btn, checked) -> {
            cfg.setFloating(checked);
            applyFloating(checked);
            tvKeepSummary.setText(checked ? "已开启" : "未开启");
        });

        rgMode.setOnCheckedChangeListener((g, id) -> {
            String m = McpConfig.MODE_ROOT;
            if (id == R.id.rb_shizuku) m = McpConfig.MODE_SHIZUKU;
            else m = McpConfig.MODE_ROOT;
            cfg.setMode(m);
            tvModeSummary.setText(modeLabel(m));
            refreshPrivilege();
            // 选中 Shizuku 模式后，若未授权则立即弹出授权对话框（与 MT 管理器一致）
            if (McpConfig.MODE_SHIZUKU.equals(m)) {
                ui.postDelayed(this::ensureShizukuPermission, 400);
            }
        });
    }

    /** 高级设置：三个子菜单互斥展开 */
    private void initAdvancedMenu() {
        View itemMode = findViewById(R.id.item_work_mode);
        View itemPort = findViewById(R.id.item_port);
        View itemKeep = findViewById(R.id.item_keepalive);

        itemMode.setOnClickListener(v -> togglePanel(panelMode, arrowMode));
        itemPort.setOnClickListener(v -> togglePanel(panelPort, arrowPort));
        itemKeep.setOnClickListener(v -> togglePanel(panelKeep, arrowKeep));
    }

    private void togglePanel(LinearLayout panel, ImageView arrow) {
        boolean willShow = panel.getVisibility() != View.VISIBLE;
        // 互斥：先全部收起
        hideAllPanels();
        if (willShow) {
            panel.setVisibility(View.VISIBLE);
            arrow.setRotation(180f);
        }
    }

    private void hideAllPanels() {
        panelMode.setVisibility(View.GONE);
        panelPort.setVisibility(View.GONE);
        panelKeep.setVisibility(View.GONE);
        arrowMode.setRotation(0f);
        arrowPort.setRotation(0f);
        arrowKeep.setRotation(0f);
    }

    private void loadConfig() {
        etPort.setText(String.valueOf(cfg.getPort()));
        etToken.setText(cfg.getToken());
        cbFloat.setChecked(cfg.isFloating());
        tvModeSummary.setText(modeLabel(cfg.getMode()));
        tvPortSummary.setText(String.valueOf(cfg.getPort()));
        tvKeepSummary.setText(cfg.isFloating() ? "已开启" : "未开启");
        syncModeRadio();
    }

    private String modeLabel(String m) {
        if (McpConfig.MODE_SHIZUKU.equals(m)) return "Shizuku";
        return "ROOT";
    }

    private void syncModeRadio() {
        if (McpConfig.MODE_SHIZUKU.equals(cfg.getMode())) {
            rgMode.check(R.id.rb_shizuku);
        } else {
            rgMode.check(R.id.rb_root);
        }
    }

    /** 悬浮窗开关立即应用 */
    private void applyFloating(boolean enable) {
        if (enable) {
            if (!FloatingWindowService.canDrawOverlay(this)) {
                AppLog.w("悬浮窗权限未授予，正在跳转设置");
                Toast.makeText(this, "请先授予悬浮窗权限", Toast.LENGTH_SHORT).show();
                requestOverlay();
                cbFloat.setChecked(false);
                cfg.setFloating(false);
                tvKeepSummary.setText("未开启");
                return;
            }
            try {
                startService(new Intent(this, FloatingWindowService.class));
                AppLog.i("悬浮窗已开启");
            } catch (Throwable t) {
                AppLog.e("悬浮窗启动失败", t);
            }
        } else {
            try {
                stopService(new Intent(this, FloatingWindowService.class));
                AppLog.i("悬浮窗已关闭");
            } catch (Throwable ignored) {}
        }
    }

    /**
     * 确保 Shizuku 已授权：Binder 存活但未授权时，弹出系统授权对话框。
     * 若 Binder 未连接则提示用户先启动 Shizuku。
     */
    private void ensureShizukuPermission() {
        if (shizukuRequesting) return;
        shizukuRequesting = true;
        new Thread(() -> {
            try {
                // Binder 连接是异步的，做短暂等待
                boolean alive = false;
                for (int i = 0; i < 10; i++) {
                    if (ShizukuHelper.isBinderAlive()) { alive = true; break; }
                    Thread.sleep(150);
                }
                final boolean binderOk = alive;
                ui.post(() -> {
                    if (!binderOk) {
                        Toast.makeText(this, "Shizuku 未运行，请先打开 Shizuku 并启动服务", Toast.LENGTH_LONG).show();
                        AppLog.w("Shizuku Binder 未连接，无法申请授权");
                    } else if (!ShizukuHelper.isGranted()) {
                        int r = ShizukuHelper.requestPermission();
                        if (r == -1) {
                            Toast.makeText(this, "发起 Shizuku 授权失败，可改用手动开启", Toast.LENGTH_LONG).show();
                        }
                    }
                    shizukuRequesting = false;
                    refreshPrivilege();
                });
            } catch (Throwable t) {
                shizukuRequesting = false;
                AppLog.e("检查 Shizuku 授权失败", t);
            }
        }).start();
    }

    /** Shizuku 授权成功后的处理 */
    private void onShizukuGranted() {
        AppLog.i("Shizuku 授权已获得，正在刷新状态…");
        refreshPrivilege();
        Toast.makeText(this, "Shizuku 授权成功", Toast.LENGTH_SHORT).show();
    }

    private void toggle() {
        if (McpForegroundService.isServerRunning()) {
            Intent i = new Intent(this, McpForegroundService.class);
            i.setAction(McpForegroundService.ACTION_STOP);
            startService(i);
            if (!cfg.isFloating()) stopService(new Intent(this, FloatingWindowService.class));
        } else {
            saveConfigSilent();
            Intent i = new Intent(this, McpForegroundService.class);
            i.setAction(McpForegroundService.ACTION_START);
            i.putExtra(McpForegroundService.EXTRA_PORT, cfg.getPort());
            i.putExtra(McpForegroundService.EXTRA_TOKEN, cfg.getToken());
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i);
            else startService(i);

            if (cfg.isFloating() && FloatingWindowService.canDrawOverlay(this)) {
                startService(new Intent(this, FloatingWindowService.class));
            }
        }
        ui.postDelayed(this::refresh, 700);
    }

    private void saveConfigSilent() {
        int port = parsePort(etPort.getText().toString(), cfg.getPort());
        cfg.setPort(port);
        cfg.setToken(etToken.getText().toString().trim());
    }

    private void saveConfig() {
        saveConfigSilent();
        tvPortSummary.setText(String.valueOf(cfg.getPort()));
        Toast.makeText(this, "配置已保存（端口 " + cfg.getPort() + "）", Toast.LENGTH_SHORT).show();
        AppLog.i("配置已保存：port=" + cfg.getPort() + " token=" + (cfg.getToken().isEmpty() ? "(空)" : "已设置"));
        refresh();
    }

    private int parsePort(String s, int fallback) {
        try {
            int p = Integer.parseInt(s.trim());
            if (p < 1 || p > 65535) return fallback;
            return p;
        } catch (Exception e) { return fallback; }
    }

    private void startRefreshTimer() {
        ui.postDelayed(new Runnable() {
            @Override public void run() {
                refresh();
                ui.postDelayed(this, 3000);
            }
        }, 3000);
    }

    private void refresh() {
        boolean running = McpForegroundService.isServerRunning();
        int port = running ? McpForegroundService.getRunningPort() : cfg.getPort();
        tvStatus.setText(running ? "状态：运行中 ●" : "状态：未启动 ○");
        tvStatus.setTextColor(getColor(running ? R.color.green : R.color.red));
        btnToggle.setText(running ? "停止服务" : "启动服务");

        // 本地网络：标题一行，地址换行且与标题左对齐
        localUrl = NetworkUtils.buildEndpoint("127.0.0.1", port);
        tvAddrLocal.setText("本地网络：\n" + localUrl);

        // 局域网络：标题一行，各 IP 地址依次换行；复制时取第一条
        List<String> ips = NetworkUtils.getAllLanIpv4();
        StringBuilder sb = new StringBuilder("局域网络：\n");
        if (ips.isEmpty()) {
            sb.append("未获取到 IP（请连接 WiFi）");
            lanUrl = "";
        } else {
            lanUrl = NetworkUtils.buildEndpoint(ips.get(0), port);
            for (String ip : ips) {
                sb.append(NetworkUtils.buildEndpoint(ip, port)).append('\n');
            }
        }
        tvAddrLan.setText(sb.toString().trim());

        refreshPrivilege();
        tvLog.setText(AppLog.snapshot());
    }

    /** 权限探测涉及 su / Binder 等待，放后台线程避免阻塞 UI */
    private void refreshPrivilege() {
        new Thread(() -> {
            String result;
            try {
                result = "※ 当前状态：" + engine.probeAll();
            } catch (Throwable t) {
                result = "探测失败：" + t.getMessage();
            }
            final String text = result;
            ui.post(() -> tvPriv.setText(text));
        }).start();
    }

    /** 复制纯 URL（不含前缀文字），并提示复制了哪一条 */
    private void copy(String url, String label) {
        if (url == null || url.trim().isEmpty()) {
            Toast.makeText(this, "暂无可复制的地址", Toast.LENGTH_SHORT).show();
            return;
        }
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("mcp_url", url.trim()));
        Toast.makeText(this, "已复制" + label + "：" + url.trim(), Toast.LENGTH_SHORT).show();
        AppLog.i("已复制" + label + " -> " + url.trim());
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                    != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 100);
            }
        }
    }

    private void requestOverlay() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            try {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } catch (Throwable t) {
                Toast.makeText(this, "无法跳转悬浮窗设置页", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "已具备悬浮窗权限", Toast.LENGTH_SHORT).show();
        }
    }

    private void requestBattery() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } catch (Throwable t) {
                Toast.makeText(this, "无法跳转电池优化设置", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
