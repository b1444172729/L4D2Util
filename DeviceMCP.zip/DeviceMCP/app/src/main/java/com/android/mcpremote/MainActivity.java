package com.android.mcpremote;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.android.mcpremote.exec.ExecutionEngine;
import com.android.mcpremote.service.DeviceAccessibilityService;
import com.android.mcpremote.service.FloatingWindowService;
import com.android.mcpremote.service.McpForegroundService;
import com.android.mcpremote.util.AccessibilityBoost;
import com.android.mcpremote.util.AppLog;
import com.android.mcpremote.util.McpConfig;
import com.android.mcpremote.util.NetworkUtils;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private McpConfig cfg;
    private ExecutionEngine engine;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private TextView tvStatus, tvAddrLocal, tvAddrLan, tvLog, tvPriv;
    private TextView tvModeSummary, tvPortSummary, tvKeepSummary;
    private Button btnToggle;
    private EditText etPort, etToken;
    private RadioGroup rgMode;
    private CheckBox cbFloat;

    // 三个可展开面板
    private LinearLayout panelMode, panelPort, panelKeep;
    private ImageView arrowMode, arrowPort, arrowKeep;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cfg = new McpConfig(this);
        engine = new ExecutionEngine(this);

        bindViews();
        initAdvancedMenu();
        loadConfig();

        AppLog.setListener(line -> ui.post(() -> tvLog.setText(AppLog.snapshot())));

        requestNotificationPermission();
        ui.post(this::refresh);
        startRefreshTimer();
    }

    private void bindViews() {
        tvStatus = findViewById(R.id.tv_status);
        tvAddrLocal = findViewById(R.id.tv_addr_local);
        tvAddrLan = findViewById(R.id.tv_addr_lan);
        tvLog = findViewById(R.id.tv_log);
        tvPriv = findViewById(R.id.tv_priv);
        btnToggle = findViewById(R.id.btn_toggle);
        etPort = findViewById(R.id.et_port);
        etToken = findViewById(R.id.et_token);
        rgMode = findViewById(R.id.rg_mode);
        cbFloat = findViewById(R.id.cb_float);

        tvModeSummary = findViewById(R.id.tv_work_mode_summary);
        tvPortSummary = findViewById(R.id.tv_port_summary);
        tvKeepSummary = findViewById(R.id.tv_keepalive_summary);

        panelMode = findViewById(R.id.panel_work_mode);
        panelPort = findViewById(R.id.panel_port);
        panelKeep = findViewById(R.id.panel_keepalive);

        arrowMode = findViewById(R.id.iv_arrow_mode);
        arrowPort = findViewById(R.id.iv_arrow_port);
        arrowKeep = findViewById(R.id.iv_arrow_keepalive);

        tvLog.setMovementMethod(new ScrollingMovementMethod());

        btnToggle.setOnClickListener(v -> toggle());
        findViewById(R.id.btn_save).setOnClickListener(v -> saveConfig());
        findViewById(R.id.btn_float_perm).setOnClickListener(v -> requestOverlay());
        findViewById(R.id.btn_battery).setOnClickListener(v -> requestBattery());
        findViewById(R.id.btn_acc_manual).setOnClickListener(v -> openAccessibility());
        findViewById(R.id.btn_acc_boost).setOnClickListener(v -> boostAccessibility());

        tvAddrLocal.setOnClickListener(v -> copy(tvAddrLocal.getText().toString()));
        tvAddrLan.setOnClickListener(v -> copy(tvAddrLan.getText().toString()));

        // 悬浮窗勾选后立即生效，无需等待服务重启
        cbFloat.setOnCheckedChangeListener((btn, checked) -> {
            cfg.setFloating(checked);
            applyFloating(checked);
            tvKeepSummary.setText(checked ? "已开启" : "未开启");
        });

        rgMode.setOnCheckedChangeListener((g, id) -> {
            String m = McpConfig.MODE_ROOT;
            if (id == R.id.rb_root) m = McpConfig.MODE_ROOT;
            else if (id == R.id.rb_shizuku) m = McpConfig.MODE_SHIZUKU;
            else if (id == R.id.rb_accessibility) m = McpConfig.MODE_ACCESSIBILITY;
            cfg.setMode(m);
            tvModeSummary.setText(modeLabel(m));
            refreshPrivilege();
        });
    }

    /** 高级设置：三个子菜单互斥展开 */
    private void initAdvancedMenu() {
        View itemMode = findViewById(R.id.item_work_mode);
        View itemPort = findViewById(R.id.item_port);
        View itemKeep = findViewById(R.id.item_keepalive);

        itemMode.setOnClickListener(v -> togglePanel(panelMode, arrowMode));
        itemPort.setOnClickListener(v -> togglePanel(panelPort, arrowPort));
        itemKeep.setOnClickListener(v -> togglePanel(panelKeep, arrowKeep));
    }

    private void togglePanel(LinearLayout panel, ImageView arrow) {
        boolean willShow = panel.getVisibility() != View.VISIBLE;
        // 互斥：先全部收起
        hideAllPanels();
        if (willShow) {
            panel.setVisibility(View.VISIBLE);
            arrow.setRotation(180f);
        }
    }

    private void hideAllPanels() {
        panelMode.setVisibility(View.GONE);
        panelPort.setVisibility(View.GONE);
        panelKeep.setVisibility(View.GONE);
        arrowMode.setRotation(0f);
        arrowPort.setRotation(0f);
        arrowKeep.setRotation(0f);
    }

    private void loadConfig() {
        etPort.setText(String.valueOf(cfg.getPort()));
        etToken.setText(cfg.getToken());
        cbFloat.setChecked(cfg.isFloating());
        tvModeSummary.setText(modeLabel(cfg.getMode()));
        tvPortSummary.setText(String.valueOf(cfg.getPort()));
        tvKeepSummary.setText(cfg.isFloating() ? "已开启" : "未开启");
        syncModeRadio();
    }

    private String modeLabel(String m) {
        if (McpConfig.MODE_ROOT.equals(m)) return "ROOT";
        if (McpConfig.MODE_SHIZUKU.equals(m)) return "Shizuku";
        return "无障碍";
    }

    private void syncModeRadio() {
        switch (cfg.getMode()) {
            case McpConfig.MODE_ROOT: rgMode.check(R.id.rb_root); break;
            case McpConfig.MODE_SHIZUKU: rgMode.check(R.id.rb_shizuku); break;
            default: rgMode.check(R.id.rb_accessibility); break;
        }
    }

    /** 悬浮窗开关立即应用 */
    private void applyFloating(boolean enable) {
        if (enable) {
            if (!FloatingWindowService.canDrawOverlay(this)) {
                AppLog.w("悬浮窗权限未授予，正在跳转设置");
                Toast.makeText(this, "请先授予悬浮窗权限", Toast.LENGTH_SHORT).show();
                requestOverlay();
                cbFloat.setChecked(false);
                cfg.setFloating(false);
                tvKeepSummary.setText("未开启");
                return;
            }
            try {
                startService(new Intent(this, FloatingWindowService.class));
                AppLog.i("悬浮窗已开启");
            } catch (Throwable t) {
                AppLog.e("悬浮窗启动失败", t);
            }
        } else {
            try {
                stopService(new Intent(this, FloatingWindowService.class));
                AppLog.i("悬浮窗已关闭");
            } catch (Throwable ignored) {}
        }
    }

    /** 一键启动无障碍（需 ROOT / Shizuku） */
    private void boostAccessibility() {
        if (!engine.hasElevated()) {
            Toast.makeText(this, "未检测到 ROOT 或 Shizuku 权限，请使用手动开启", Toast.LENGTH_LONG).show();
            AppLog.w("一键启动失败：无可用提权方式");
            return;
        }
        AppLog.i("尝试一键启动无障碍…");
        new Thread(() -> {
            AccessibilityBoost.Result r = AccessibilityBoost.enable(this, engine);
            ui.post(() -> {
                if (r.ok) {
                    AppLog.i("无障碍一键启动成功（via " + r.via + "）");
                    Toast.makeText(this, "已通过 " + r.via + " 启动无障碍，稍等片刻生效", Toast.LENGTH_LONG).show();
                } else {
                    AppLog.w("无障碍一键启动未完成（via " + r.via + "）：\n" + r.detail);
                    Toast.makeText(this, "一键启动未完成，可改用手动开启", Toast.LENGTH_LONG).show();
                }
                refreshPrivilege();
            });
        }).start();
    }

    private void toggle() {
        if (McpForegroundService.isServerRunning()) {
            Intent i = new Intent(this, McpForegroundService.class);
            i.setAction(McpForegroundService.ACTION_STOP);
            startService(i);
            if (!cfg.isFloating()) stopService(new Intent(this, FloatingWindowService.class));
        } else {
            saveConfigSilent();
            Intent i = new Intent(this, McpForegroundService.class);
            i.setAction(McpForegroundService.ACTION_START);
            i.putExtra(McpForegroundService.EXTRA_PORT, cfg.getPort());
            i.putExtra(McpForegroundService.EXTRA_TOKEN, cfg.getToken());
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i);
            else startService(i);

            if (cfg.isFloating() && FloatingWindowService.canDrawOverlay(this)) {
                startService(new Intent(this, FloatingWindowService.class));
            }
        }
        ui.postDelayed(this::refresh, 700);
    }

    private void saveConfigSilent() {
        int port = parsePort(etPort.getText().toString(), cfg.getPort());
        cfg.setPort(port);
        cfg.setToken(etToken.getText().toString().trim());
    }

    private void saveConfig() {
        saveConfigSilent();
        tvPortSummary.setText(String.valueOf(cfg.getPort()));
        Toast.makeText(this, "配置已保存（端口 " + cfg.getPort() + "）", Toast.LENGTH_SHORT).show();
        AppLog.i("配置已保存：port=" + cfg.getPort() + " token=" + (cfg.getToken().isEmpty() ? "(空)" : "已设置"));
        refresh();
    }

    private int parsePort(String s, int fallback) {
        try {
            int p = Integer.parseInt(s.trim());
            if (p < 1 || p > 65535) return fallback;
            return p;
        } catch (Exception e) { return fallback; }
    }

    private void startRefreshTimer() {
        ui.postDelayed(new Runnable() {
            @Override public void run() {
                refresh();
                ui.postDelayed(this, 3000);
            }
        }, 3000);
    }

    private void refresh() {
        boolean running = McpForegroundService.isServerRunning();
        int port = running ? McpForegroundService.getRunningPort() : cfg.getPort();
        tvStatus.setText(running ? "状态：运行中 ●" : "状态：未启动 ○");
        tvStatus.setTextColor(getColor(running ? R.color.green : R.color.red));
        btnToggle.setText(running ? "停止服务" : "启动服务");

        tvAddrLocal.setText("本地：" + NetworkUtils.buildEndpoint("127.0.0.1", port));

        List<String> ips = NetworkUtils.getAllLanIpv4();
        StringBuilder sb = new StringBuilder();
        if (ips.isEmpty()) {
            sb.append("局域网：未获取到 IP（请连接 WiFi）");
        } else {
            sb.append("局域网：\n");
            for (String ip : ips) sb.append("  ").append(NetworkUtils.buildEndpoint(ip, port)).append('\n');
        }
        tvAddrLan.setText(sb.toString().trim());

        refreshPrivilege();
        tvLog.setText(AppLog.snapshot());
    }

    private void refreshPrivilege() {
        tvPriv.setText("探测：" + engine.probeAll());
    }

    private void copy(String text) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("url", text));
        Toast.makeText(this, "已复制", Toast.LENGTH_SHORT).show();
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                    != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 100);
            }
        }
    }

    private void requestOverlay() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            try {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } catch (Throwable t) {
                Toast.makeText(this, "无法跳转悬浮窗设置页", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "已具备悬浮窗权限", Toast.LENGTH_SHORT).show();
        }
    }

    private void openAccessibility() {
        if (DeviceAccessibilityService.isGranted(this)) {
            Toast.makeText(this, "无障碍已开启", Toast.LENGTH_SHORT).show();
            return;
        }
        Toast.makeText(this, "请在列表中找到「MCP远程」并开启", Toast.LENGTH_LONG).show();
        try {
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        } catch (Throwable ignored) {}
    }

    private void requestBattery() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } catch (Throwable t) {
                Toast.makeText(this, "无法跳转电池优化设置", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
