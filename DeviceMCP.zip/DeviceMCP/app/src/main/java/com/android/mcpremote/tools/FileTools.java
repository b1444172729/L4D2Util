package com.android.mcpremote.tools;

import android.content.Context;
import android.os.Environment;

import com.android.mcpremote.exec.ExecutionEngine;
import com.android.mcpremote.exec.ShellResult;
import com.android.mcpremote.server.ToolDefinition;
import com.android.mcpremote.util.AppLog;
import com.android.mcpremote.util.Json;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** 文件类工具 */
public final class FileTools {

    public static List<ToolDefinition> all(Context ctx) {
        List<ToolDefinition> list = new ArrayList<>();

        list.add(new ToolDefinition("dev_file_list", "列出目录内容（含类型、大小、修改时间、权限）。",
                Json.schema(Json.obj("path", Json.strProp("目录绝对路径")))) {
            @Override public JSONObject call(Context c, JSONObject a) {
                String p = a.optString("path", "");
                File dir = resolve(p);
                if (!dir.exists()) return Json.errorResult("路径不存在: " + dir.getAbsolutePath());
                if (!dir.isDirectory()) return Json.errorResult("不是目录: " + dir.getAbsolutePath());
                File[] fs = dir.listFiles();
                if (fs == null) return Json.errorResult("无法读取目录（权限不足？）: " + dir.getAbsolutePath());
                Arrays.sort(fs);
                JSONArray arr = new JSONArray();
                for (File f : fs) {
                    JSONObject o = Json.obj(
                            "name", f.getName(),
                            "path", f.getAbsolutePath(),
                            "type", f.isDirectory() ? "dir" : "file",
                            "size", f.length(),
                            "modified", f.lastModified(),
                            "readable", f.canRead(),
                            "writable", f.canWrite()
                    );
                    arr.put(o);
                }
                return Json.textResult("共 " + fs.length + " 项：\n" + Json.fmt(arr));
            }
        });

        list.add(new ToolDefinition("dev_file_read_text", "读取文本文件内容（默认 UTF-8，可指定偏移与长度）。",
                Json.schema(Json.obj(
                        "path", Json.strProp("文件绝对路径"),
                        "offset", Json.intProp("起始字节偏移，默认 0"),
                        "maxBytes", Json.intProp("最大读取字节数，默认 65536")),
                        "path")) {
            @Override public JSONObject call(Context c, JSONObject a) throws Exception {
                File f = resolve(a.optString("path", ""));
                if (!f.isFile()) return Json.errorResult("文件不存在: " + f.getAbsolutePath());
                long off = a.optLong("offset", 0);
                long max = a.optLong("maxBytes", 65536);
                try (FileInputStream in = new FileInputStream(f)) {
                    long skipped = in.skip(off);
                    byte[] buf = new byte[(int) Math.min(max, f.length() - skipped)];
                    int n = in.read(buf);
                    return Json.textResult(new String(buf, 0, Math.max(n, 0), StandardCharsets.UTF_8));
                }
            }
        });

        list.add(new ToolDefinition("dev_file_read_bytes", "以十六进制读取文件字节（用于查看二进制/SO 文件头部）。",
                Json.schema(Json.obj(
                        "path", Json.strProp("文件绝对路径"),
                        "offset", Json.intProp("起始偏移，默认 0"),
                        "length", Json.intProp("读取长度，默认 256")),
                        "path")) {
            @Override public JSONObject call(Context c, JSONObject a) throws Exception {
                File f = resolve(a.optString("path", ""));
                if (!f.isFile()) return Json.errorResult("文件不存在: " + f.getAbsolutePath());
                long off = a.optLong("offset", 0);
                int len = a.optInt("length", 256);
                try (FileInputStream in = new FileInputStream(f)) {
                    in.skip(off);
                    byte[] buf = new byte[len];
                    int n = in.read(buf);
                    return Json.textResult(hex(buf, Math.max(n, 0)));
                }
            }
        });

        list.add(new ToolDefinition("dev_file_write_text", "写入文本文件（默认覆盖，可追加）。",
                Json.schema(Json.obj(
                        "path", Json.strProp("文件绝对路径"),
                        "content", Json.strProp("写入内容"),
                        "append", Json.boolProp("true 为追加，false 为覆盖，默认 false")),
                        "path", "content")) {
            @Override public JSONObject call(Context c, JSONObject a) throws Exception {
                File f = resolve(a.optString("path", ""));
                File parent = f.getParentFile();
                if (parent != null && !parent.exists() && !parent.mkdirs()) {
                    return Json.errorResult("无法创建父目录: " + parent.getAbsolutePath());
                }
                try (FileOutputStream out = new FileOutputStream(f, a.optBoolean("append", false))) {
                    out.write(a.optString("content", "").getBytes(StandardCharsets.UTF_8));
                }
                return Json.textResult("写入成功: " + f.getAbsolutePath() + " (" + f.length() + " 字节)");
            }
        });

        list.add(new ToolDefinition("dev_file_delete", "删除文件或空目录。",
                Json.schema(Json.obj("path", Json.strProp("目标绝对路径")), "path")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                File f = resolve(a.optString("path", ""));
                if (!f.exists()) return Json.errorResult("路径不存在: " + f.getAbsolutePath());
                boolean ok = f.delete();
                return ok ? Json.textResult("已删除: " + f.getAbsolutePath())
                          : Json.errorResult("删除失败（目录非空或权限不足）: " + f.getAbsolutePath());
            }
        });

        list.add(new ToolDefinition("dev_file_copy", "复制文件。",
                Json.schema(Json.obj("src", Json.strProp("源路径"), "dst", Json.strProp("目标路径")), "src", "dst")) {
            @Override public JSONObject call(Context c, JSONObject a) throws Exception {
                File s = resolve(a.optString("src", ""));
                File d = resolve(a.optString("dst", ""));
                copyOrMove(s, d, false);
                return Json.textResult("已复制: " + s.getAbsolutePath() + " -> " + d.getAbsolutePath());
            }
        });

        list.add(new ToolDefinition("dev_file_move", "移动/重命名文件。",
                Json.schema(Json.obj("src", Json.strProp("源路径"), "dst", Json.strProp("目标路径")), "src", "dst")) {
            @Override public JSONObject call(Context c, JSONObject a) throws Exception {
                File s = resolve(a.optString("src", ""));
                File d = resolve(a.optString("dst", ""));
                copyOrMove(s, d, true);
                return Json.textResult("已移动: " + s.getAbsolutePath() + " -> " + d.getAbsolutePath());
            }
        });

        list.add(new ToolDefinition("dev_file_mkdir", "创建目录（含多级）。",
                Json.schema(Json.obj("path", Json.strProp("目录路径")), "path")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                File d = resolve(a.optString("path", ""));
                boolean ok = d.mkdirs() || d.isDirectory();
                return ok ? Json.textResult("目录就绪: " + d.getAbsolutePath())
                          : Json.errorResult("创建失败: " + d.getAbsolutePath());
            }
        });

        list.add(new ToolDefinition("dev_file_stat", "获取文件或目录的详细信息。",
                Json.schema(Json.obj("path", Json.strProp("目标路径")), "path")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                File f = resolve(a.optString("path", ""));
                if (!f.exists()) return Json.errorResult("路径不存在: " + f.getAbsolutePath());
                JSONObject o = Json.obj(
                        "path", f.getAbsolutePath(),
                        "exists", true,
                        "type", f.isDirectory() ? "dir" : "file",
                        "size", f.length(),
                        "modified", new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(new java.util.Date(f.lastModified())),
                        "readable", f.canRead(),
                        "writable", f.canWrite(),
                        "hidden", f.isHidden()
                );
                return Json.textResult(Json.fmt(o));
            }
        });

        list.add(new ToolDefinition("dev_file_search", "按文件名递归搜索（支持子串匹配）。",
                Json.schema(Json.obj(
                        "dir", Json.strProp("起始目录"),
                        "keyword", Json.strProp("文件名关键字"),
                        "maxResults", Json.intProp("最大结果数，默认 100")),
                        "dir", "keyword")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                File root = resolve(a.optString("dir", ""));
                String kw = a.optString("keyword", "");
                int max = a.optInt("maxResults", 100);
                List<String> hits = new ArrayList<>();
                walk(root, kw, hits, max);
                return Json.textResult("命中 " + hits.size() + " 项：\n" + String.join("\n", hits));
            }
        });

        list.add(new ToolDefinition("dev_file_search_text", "在文本文件内容中搜索关键字。",
                Json.schema(Json.obj(
                        "dir", Json.strProp("起始目录"),
                        "keyword", Json.strProp("搜索关键字"),
                        "maxResults", Json.intProp("最大结果数，默认 50")),
                        "dir", "keyword")) {
            @Override public JSONObject call(Context c, JSONObject a) throws Exception {
                File root = resolve(a.optString("dir", ""));
                String kw = a.optString("keyword", "");
                int max = a.optInt("maxResults", 50);
                List<String> hits = new ArrayList<>();
                searchText(root, kw, hits, max);
                return Json.textResult("命中 " + hits.size() + " 处：\n" + String.join("\n", hits));
            }
        });

        list.add(new ToolDefinition("dev_file_get_access_policy", "查询当前文件访问策略与可用根目录。",
                Json.schema(new JSONObject())) {
            @Override public JSONObject call(Context c, JSONObject a) {
                JSONObject o = Json.obj(
                        "appInternalDir", c.getFilesDir().getAbsolutePath(),
                        "appCacheDir", c.getCacheDir().getAbsolutePath(),
                        "externalFilesDir", c.getExternalFilesDir(null) != null ? c.getExternalFilesDir(null).getAbsolutePath() : "N/A",
                        "publicDownload", Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath(),
                        "externalStorage", Environment.getExternalStorageDirectory().getAbsolutePath(),
                        "note", "Android 11+ 访问公共目录需 MANAGE_EXTERNAL_STORAGE 或通过 ROOT/Shizuku 提权；路径支持 ~ 代表外部存储根目录"
                );
                return Json.textResult(Json.fmt(o));
            }
        });

        // ---------- 文件哈希 ----------
        list.add(new ToolDefinition("dev_file_hash",
                "计算文件哈希值（md5 / sha1 / sha256），用于校验文件完整性或比对文件。",
                Json.schema(Json.obj(
                        "path", Json.strProp("文件路径"),
                        "algo", Json.strProp("算法：md5|sha1|sha256，默认 sha256")),
                        "path")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                String path = a.optString("path", "");
                if (path.isEmpty()) return Json.errorResult("path 不能为空");
                String algo = a.optString("algo", "sha256").toLowerCase();
                String bin = "md5".equals(algo) ? "md5sum" : ("sha1".equals(algo) ? "sha1sum" : "sha256sum");
                ShellResult r = engine.exec(bin + " '" + path.replace("'", "'\\''") + "'", null, 30);
                String out = r.stdout == null ? "" : r.stdout.trim();
                if (out.isEmpty()) return Json.errorResult("计算失败或文件不存在：" + r.combined());
                return Json.textResult(Json.fmt(Json.obj("path", path, "algo", algo, "hash", out.split("\\s+")[0])));
            }
        });

        // ---------- 修改权限 ----------
        list.add(new ToolDefinition("dev_file_chmod",
                "修改文件或目录权限（chmod）。需 shell 权限，部分目录需 ROOT。",
                Json.schema(Json.obj(
                        "path", Json.strProp("文件或目录路径"),
                        "mode", Json.strProp("权限值，如 755 / 644"),
                        "recursive", Json.boolProp("是否递归（目录时），默认 false")),
                        "path", "mode")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                String path = a.optString("path", "");
                String mode = a.optString("mode", "");
                if (path.isEmpty() || mode.isEmpty()) return Json.errorResult("path 与 mode 均不能为空");
                String cmd = "chmod " + (a.optBoolean("recursive", false) ? "-R " : "") + mode
                        + " '" + path.replace("'", "'\\''") + "'";
                ShellResult r = engine.exec(cmd, null, 20);
                return r.ok() ? Json.textResult("已设置权限 " + mode + ": " + path)
                              : Json.errorResult("设置失败：" + r.combined());
            }
        });

        // ---------- 下载文件 ----------
        list.add(new ToolDefinition("dev_file_download",
                "从网络下载文件到手机存储（基于 curl）。支持自定义保存路径与超时。",
                Json.schema(Json.obj(
                        "url", Json.strProp("下载地址"),
                        "path", Json.strProp("保存路径，如 /sdcard/download/a.apk"),
                        "timeoutSec", Json.intProp("超时秒数，默认 60")),
                        "url", "path")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                String url = a.optString("url", "");
                String path = a.optString("path", "");
                if (url.isEmpty() || path.isEmpty()) return Json.errorResult("url 与 path 均不能为空");
                int timeout = a.optInt("timeoutSec", 60);
                String cmd = "curl -sL --max-time " + timeout + " -o '" + path.replace("'", "'\\''")
                        + "' '" + url.replace("'", "'\\''") + "'";
                ShellResult r = engine.exec(cmd, null, timeout + 15);
                if (!r.ok()) return Json.errorResult("下载失败：" + r.combined());
                ShellResult ls = engine.exec("ls -l '" + path.replace("'", "'\\''") + "'", null, 10);
                return Json.textResult("下载完成：\n" + Json.fmt(Json.obj("path", path, "detail", ls.stdout)));
            }
        });

        // ---------- 压缩 ----------
        list.add(new ToolDefinition("dev_file_zip",
                "将文件或目录压缩为 zip（基于 shell 的 zip 命令；若系统无 zip 命令会返回失败）。",
                Json.schema(Json.obj(
                        "source", Json.strProp("要压缩的文件或目录路径"),
                        "dest", Json.strProp("输出的 zip 文件路径"),
                        "recursive", Json.boolProp("目录时是否递归，默认 true")),
                        "source", "dest")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                String src = a.optString("source", "");
                String dest = a.optString("dest", "");
                if (src.isEmpty() || dest.isEmpty()) return Json.errorResult("source 与 dest 均不能为空");
                String cmd = "zip " + (a.optBoolean("recursive", true) ? "-r " : "")
                        + "'" + dest.replace("'", "'\\''") + "' '" + src.replace("'", "'\\''") + "'";
                ShellResult r = engine.exec(cmd, null, 60);
                if (!r.ok()) return Json.errorResult("压缩失败（系统可能缺少 zip 命令）：" + r.combined());
                return Json.textResult("已压缩: " + dest);
            }
        });

        // ---------- 解压 ----------
        list.add(new ToolDefinition("dev_file_unzip",
                "解压 zip 文件到指定目录（基于 shell 的 unzip 命令）。",
                Json.schema(Json.obj(
                        "zipPath", Json.strProp("zip 文件路径"),
                        "destDir", Json.strProp("解压到的目录（不存在会尝试创建）")),
                        "zipPath", "destDir")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ExecutionEngine engine = new ExecutionEngine(c);
                String zp = a.optString("zipPath", "");
                String dd = a.optString("destDir", "");
                if (zp.isEmpty() || dd.isEmpty()) return Json.errorResult("zipPath 与 destDir 均不能为空");
                engine.exec("mkdir -p '" + dd.replace("'", "'\\''") + "'", null, 15);
                String cmd = "unzip -o '" + zp.replace("'", "'\\''") + "' -d '" + dd.replace("'", "'\\''") + "'";
                ShellResult r = engine.exec(cmd, null, 60);
                if (!r.ok()) return Json.errorResult("解压失败（系统可能缺少 unzip 命令）：" + r.combined());
                ShellResult ls = engine.exec("ls '" + dd.replace("'", "'\\''") + "'", null, 15);
                return Json.textResult("已解压到 " + dd + "：\n" + (ls.stdout == null ? "" : ls.stdout));
            }
        });

        return list;
    }

    // ---------------- 辅助 ----------------

    static File resolve(String p) {
        if (p == null || p.isEmpty()) return new File(Environment.getExternalStorageDirectory(), "");
        if (p.startsWith("~/")) p = Environment.getExternalStorageDirectory() + p.substring(1);
        else if (p.equals("~")) p = Environment.getExternalStorageDirectory().getAbsolutePath();
        return new File(p);
    }

    private static void copyOrMove(File s, File d, boolean move) throws Exception {
        if (!s.exists()) throw new Exception("源不存在: " + s.getAbsolutePath());
        if (s.isDirectory()) throw new Exception("暂不支持目录复制/移动，请使用 dev_file_copy 逐个处理或改用 shell 工具");
        File parent = d.getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs()) throw new Exception("无法创建目标父目录");
        if (move) {
            if (!s.renameTo(d)) {
                copyStream(s, d);
                s.delete();
            }
        } else {
            copyStream(s, d);
        }
    }

    private static void copyStream(File s, File d) throws Exception {
        try (FileInputStream in = new FileInputStream(s); FileOutputStream out = new FileOutputStream(d)) {
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        }
    }

    private static void walk(File dir, String kw, List<String> hits, int max) {
        if (dir == null || hits.size() >= max) return;
        File[] fs = dir.listFiles();
        if (fs == null) return;
        for (File f : fs) {
            if (hits.size() >= max) return;
            if (f.getName().toLowerCase().contains(kw.toLowerCase())) hits.add(f.getAbsolutePath());
            if (f.isDirectory()) walk(f, kw, hits, max);
        }
    }

    private static void searchText(File dir, String kw, List<String> hits, int max) {
        if (dir == null || hits.size() >= max) return;
        File[] fs = dir.listFiles();
        if (fs == null) return;
        for (File f : fs) {
            if (hits.size() >= max) return;
            if (f.isDirectory()) { searchText(f, kw, hits, max); continue; }
            if (f.length() > 8 * 1024 * 1024) continue;
            try (java.io.BufferedReader br = new java.io.BufferedReader(new java.io.InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8))) {
                String line; int ln = 0;
                while ((line = br.readLine()) != null && hits.size() < max) {
                    ln++;
                    if (line.contains(kw)) hits.add(f.getAbsolutePath() + ":" + ln + ": " + line.trim());
                }
            } catch (Throwable ignored) { AppLog.w("跳过不可读文件: " + f.getName()); }
        }
    }

    private static String hex(byte[] b, int n) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i++) sb.append(String.format("%02X ", b[i]));
        return sb.toString().trim();
    }
}
