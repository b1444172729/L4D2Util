package com.android.mcpremote.util;

import android.content.Context;

import com.android.mcpremote.exec.ExecutionEngine;
import com.android.mcpremote.exec.ShizukuExecutor;
import com.android.mcpremote.exec.ShellResult;
import com.android.mcpremote.service.DeviceAccessibilityService;

/**
 * 无障碍一键启动：借助 ROOT 或 Shizuku 直接写入系统 secure 设置激活本服务。
 *
 * 权限选取规则（按用户要求）：
 *  - 工作模式 = ROOT     → 只尝试 ROOT，不再触碰 Shizuku
 *  - 工作模式 = Shizuku  → 只尝试 Shizuku，不再触碰 ROOT
 *  - 工作模式 = 无障碍 / 其它 → 依次尝试 ROOT、Shizuku（auto）
 *
 * 原理（与 MT 管理器 Activity 记录功能一致）：
 *   settings put secure enabled_accessibility_services <pkg>/<cls>
 *   settings put secure accessibility_enabled 1
 */
public final class AccessibilityBoost {

    public static final class Result {
        public final boolean ok;
        public final String via;       // root / shizuku / none
        public final String detail;

        Result(boolean ok, String via, String detail) {
            this.ok = ok; this.via = via; this.detail = detail;
        }
    }

    public static String componentName(Context ctx) {
        return ctx.getPackageName() + "/" + DeviceAccessibilityService.class.getName();
    }

    /** 依据当前工作模式决定尝试哪些后端 */
    private static String[] resolveOrder(String mode) {
        if (McpConfig.MODE_ROOT.equals(mode)) {
            return new String[]{McpConfig.MODE_ROOT};
        }
        if (McpConfig.MODE_SHIZUKU.equals(mode)) {
            return new String[]{McpConfig.MODE_SHIZUKU};
        }
        return new String[]{McpConfig.MODE_ROOT, McpConfig.MODE_SHIZUKU};
    }

    private static String label(String mode) {
        return McpConfig.MODE_ROOT.equals(mode) ? "ROOT" : "Shizuku";
    }

    /** 按当前配置的工作模式一键启动无障碍 */
    public static Result enable(Context ctx, ExecutionEngine engine) {
        return enable(ctx, engine, new McpConfig(ctx).getMode());
    }

    /**
     * @param preferredMode 优先使用的权限后端（root / shizuku / accessibility）
     */
    public static Result enable(Context ctx, ExecutionEngine engine, String preferredMode) {
        String component = componentName(ctx);
        String[] order = resolveOrder(preferredMode);
        StringBuilder skipped = new StringBuilder();

        for (String mode : order) {
            if (!engine.isAvailable(mode)) {
                skipped.append("[").append(label(mode)).append("不可用] ");
                if (McpConfig.MODE_SHIZUKU.equals(mode)) {
                    skipped.append(new ShizukuExecutor(ctx).diagnose()).append('\n');
                }
                continue;
            }

            StringBuilder log = new StringBuilder();
            boolean allOk = true;

            ShellResult cur = engine.exec("settings get secure enabled_accessibility_services", mode, 10);
            String current = cur.stdout == null ? "" : cur.stdout.trim();
            if ("null".equals(current)) current = "";
            log.append("[读取] ").append(current.isEmpty() ? "(空)" : current).append('\n');

            if (!current.contains(component)) {
                String newValue = current.isEmpty() ? component : current + ":" + component;
                ShellResult r = engine.exec("settings put secure enabled_accessibility_services " + newValue, mode, 10);
                log.append("[写入服务] ").append(r.ok() ? "成功" : "失败").append('\n');
                if (!r.ok()) { allOk = false; log.append(r.stderr).append('\n'); }
            } else {
                log.append("[写入服务] 已存在，跳过\n");
            }

            ShellResult r2 = engine.exec("settings put secure accessibility_enabled 1", mode, 10);
            log.append("[总开关] ").append(r2.ok() ? "已开启" : "失败").append('\n');
            if (!r2.ok()) { allOk = false; log.append(r2.stderr).append('\n'); }

            engine.exec("settings put secure touch_exploration_enabled 0", mode, 10);

            if (skipped.length() > 0) log.insert(0, skipped);
            AppLog.i("无障碍一键启动 via " + label(mode) + " -> " + (allOk ? "成功" : "部分失败"));
            return new Result(allOk, label(mode), log.toString());
        }

        String tip;
        if (McpConfig.MODE_ROOT.equals(preferredMode)) {
            tip = "当前工作模式为 ROOT，但未获得 ROOT 权限。\n请确认已授权 ROOT，或改用手动开启。";
        } else if (McpConfig.MODE_SHIZUKU.equals(preferredMode)) {
            tip = "当前工作模式为 Shizuku，但 Shizuku 不可用。\n"
                    + new ShizukuExecutor(ctx).diagnose()
                    + "\n请确认 Shizuku 已启动且已授权本应用，或改用手动开启。";
        } else {
            tip = "ROOT 与 Shizuku 均不可用，无法一键启动。\n请点击「手动开启无障碍」在系统设置中启用 MCP远程。";
        }
        if (skipped.length() > 0) tip = skipped + "\n" + tip;
        return new Result(false, "none", tip);
    }

    /** 关闭无障碍（同样按模式取权限） */
    public static Result disable(Context ctx, ExecutionEngine engine) {
        String component = componentName(ctx);
        for (String mode : resolveOrder(new McpConfig(ctx).getMode())) {
            if (!engine.isAvailable(mode)) continue;
            ShellResult r = engine.exec("settings put secure accessibility_enabled 0", mode, 10);
            engine.exec("settings put secure enabled_accessibility_services " + component, mode, 10);
            return new Result(r.ok(), label(mode), r.combined());
        }
        return new Result(false, "none", "无可用提权方式");
    }
}
