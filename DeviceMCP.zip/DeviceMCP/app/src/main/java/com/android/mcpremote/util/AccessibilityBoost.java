package com.android.mcpremote.util;

import android.content.Context;

import com.android.mcpremote.exec.ExecutionEngine;
import com.android.mcpremote.exec.ShellResult;
import com.android.mcpremote.service.DeviceAccessibilityService;

/**
 * 无障碍一键启动：借助 ROOT 或 Shizuku 直接写入系统 secure 设置激活本服务，
 * 用于解决部分 ROM 上无障碍开关被系统自动关闭、或用户手动开启困难的问题。
 *
 * 原理（与 MT 管理器 Activity 记录功能一致）：
 *   settings put secure enabled_accessibility_services <pkg>/<cls>
 *   settings put secure accessibility_enabled 1
 */
public final class AccessibilityBoost {

    /** 结果封装 */
    public static final class Result {
        public final boolean ok;
        public final String via;       // root / shizuku / none
        public final String detail;

        Result(boolean ok, String via, String detail) {
            this.ok = ok; this.via = via; this.detail = detail;
        }
    }

    /** 返回本服务在系统设置中的完整组件名 */
    public static String componentName(Context ctx) {
        return ctx.getPackageName() + "/" + DeviceAccessibilityService.class.getName();
    }

    /**
     * 尝试一键启动无障碍。
     * 优先 ROOT，其次 Shizuku；两者皆不可用时返回失败并提示手动开启。
     */
    public static Result enable(Context ctx, ExecutionEngine engine) {
        String component = componentName(ctx);

        String[] order = {McpConfig.MODE_ROOT, McpConfig.MODE_SHIZUKU};
        String[] labels = {"ROOT", "Shizuku"};

        for (int i = 0; i < order.length; i++) {
            String mode = order[i];
            if (!engine.isAvailable(mode)) continue;

            StringBuilder log = new StringBuilder();
            boolean allOk = true;

            // 1) 读取当前已启用的服务列表
            ShellResult cur = engine.exec("settings get secure enabled_accessibility_services", mode, 10);
            String current = cur.stdout == null ? "" : cur.stdout.trim();
            if ("null".equals(current)) current = "";
            log.append("[读取] ").append(current.isEmpty() ? "(空)" : current).append('\n');

            // 2) 若未包含本服务则追加写入（保留其它服务，避免覆盖）
            if (!current.contains(component)) {
                String newValue = current.isEmpty() ? component : current + ":" + component;
                ShellResult r = engine.exec("settings put secure enabled_accessibility_services " + newValue, mode, 10);
                log.append("[写入服务] ").append(r.ok() ? "成功" : "失败").append('\n');
                if (!r.ok()) { allOk = false; log.append(r.stderr).append('\n'); }
            } else {
                log.append("[写入服务] 已存在，跳过\n");
            }

            // 3) 打开无障碍总开关
            ShellResult r2 = engine.exec("settings put secure accessibility_enabled 1", mode, 10);
            log.append("[总开关] ").append(r2.ok() ? "已开启" : "失败").append('\n');
            if (!r2.ok()) { allOk = false; log.append(r2.stderr).append('\n'); }

            // 4) 部分 ROM 需要清掉 touch exploration 才能稳定
            engine.exec("settings put secure touch_exploration_enabled 0", mode, 10);

            AppLog.i("无障碍一键启动 via " + labels[i] + " -> " + (allOk ? "成功" : "部分失败"));
            return new Result(allOk, labels[i], log.toString());
        }

        return new Result(false, "none",
                "ROOT 与 Shizuku 均不可用，无法一键启动。\n请点击「手动开启无障碍」在系统设置中启用 MCP远程。");
    }

    /** 关闭无障碍（同样需要提权） */
    public static Result disable(Context ctx, ExecutionEngine engine) {
        String component = componentName(ctx);
        for (String mode : new String[]{McpConfig.MODE_ROOT, McpConfig.MODE_SHIZUKU}) {
            if (!engine.isAvailable(mode)) continue;
            ShellResult r = engine.exec("settings put secure accessibility_enabled 0", mode, 10);
            engine.exec("settings put secure enabled_accessibility_services " + component, mode, 10);
            return new Result(r.ok(), mode, r.combined());
        }
        return new Result(false, "none", "无可用提权方式");
    }
}
