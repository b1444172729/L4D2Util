package com.android.mcpremote.exec;

import android.content.Context;

import com.android.mcpremote.util.AppLog;
import com.android.mcpremote.util.McpConfig;

/** 执行引擎：按工作模式选择后端。模式为 ROOT / Shizuku / 无障碍 三种 */
public final class ExecutionEngine {

    private final Context ctx;
    private final RootExecutor root = new RootExecutor();
    private final ShizukuExecutor shizuku;
    private final AppExecutor app = new AppExecutor();

    public ExecutionEngine(Context ctx) {
        this.ctx = ctx.getApplicationContext();
        this.shizuku = new ShizukuExecutor(this.ctx);
    }

    public PrivilegeExecutor get(String id) {
        switch (id) {
            case McpConfig.MODE_ROOT: return root;
            case McpConfig.MODE_SHIZUKU: return shizuku;
            default: return app;
        }
    }

    public boolean isAvailable(String id) {
        try { return get(id).isAvailable(); } catch (Throwable t) { return false; }
    }

    /** 探测各能力可用情况 */
    public String probeAll() {
        StringBuilder sb = new StringBuilder();
        sb.append("ROOT=").append(safe(root)).append("  ");
        sb.append("Shizuku=").append(safe(shizuku)).append("  ");
        sb.append("无障碍=").append("已停用（改用 adb 通道）");
        return sb.toString();
    }

    private String safe(PrivilegeExecutor e) {
        try { return e.isAvailable() ? "可用" : "不可用"; } catch (Throwable t) { return "不可用"; }
    }

    /** 当前是否具备任意一种提权能力（ROOT 或 Shizuku） */
    public boolean hasElevated() {
        return root.isAvailable() || shizuku.isAvailable();
    }

    /** 指定模式是否具备提权能力 */
    public boolean hasElevated(String mode) {
        if (McpConfig.MODE_ROOT.equals(mode)) return root.isAvailable();
        if (McpConfig.MODE_SHIZUKU.equals(mode)) return shizuku.isAvailable();
        return root.isAvailable() || shizuku.isAvailable();
    }

    /** Shizuku 详细诊断（供界面提示） */
    public String shizukuDiagnose() {
        return shizuku.diagnose();
    }

    /**
     * 执行命令。
     * mode 为空取配置；无障碍模式下退化为普通应用权限；
     * mode=auto 按 root → shizuku → 普通 依次降级。
     */
    public ShellResult exec(String command, String mode, int timeoutSeconds) {
        if (command == null || command.trim().isEmpty()) {
            return new ShellResult(-1, "", "命令为空", "none");
        }
        if (mode == null || mode.isEmpty()) mode = new McpConfig(ctx).getMode();

        if ("auto".equals(mode)) {
            String[] order = {McpConfig.MODE_ROOT, McpConfig.MODE_SHIZUKU};
            for (String m : order) {
                PrivilegeExecutor e = get(m);
                if (e.isAvailable()) {
                    AppLog.i("执行 via " + m + ": " + command);
                    return e.exec(command, timeoutSeconds);
                }
            }
            return app.exec(command, timeoutSeconds);
        }

        // 无障碍模式已停用：adb 通道下统一按 root → shizuku → 普通 降级
        if (McpConfig.MODE_ACCESSIBILITY.equals(mode)) {
            AppLog.i("无障碍模式已停用，自动降级为提权通道: " + command);
            if (root.isAvailable()) return root.exec(command, timeoutSeconds);
            if (shizuku.isAvailable()) return shizuku.exec(command, timeoutSeconds);
            return app.exec(command, timeoutSeconds);
        }

        PrivilegeExecutor e = get(mode);
        if (!e.isAvailable()) {
            return new ShellResult(-1, "", "所选工作模式不可用: " + mode + "（当前探测：" + probeAll() + "）", mode);
        }
        AppLog.i("执行 via " + mode + ": " + command);
        return e.exec(command, timeoutSeconds);
    }
}
