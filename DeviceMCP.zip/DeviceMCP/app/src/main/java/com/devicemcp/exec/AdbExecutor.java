package com.devicemcp.exec;

import android.os.Process;

import com.devicemcp.util.AppLog;

/**
 * ADB 执行器：以 ADB（shell uid 2000）身份执行。
 *
 * 说明：
 * 1) 若本进程以 shell(uid=2000) 身份运行（例如通过 `adb shell am start` 拉起并授予权限），
 *    则直接通过 sh -c 执行即具备 ADB 级权限。
 * 2) 若设备开启了无线调试并已完成配对，部分机型允许本机回连 127.0.0.1:5555，
 *    此时可走 ADB 网络协议（此处提供检测入口，实际命令仍由 sh 执行）。
 * 3) 不具备上述条件时，本执行器不可用，请在 UI 中改用 Shizuku(ADB 模式) 或 ROOT。
 */
public class AdbExecutor implements PrivilegeExecutor {

    @Override public String getId() { return "adb"; }
    @Override public String getLabel() { return "ADB"; }

    @Override
    public boolean isAvailable() {
        // 检测自身 uid 是否为 shell(2000)
        try {
            int uid = Process.myUid();
            if (uid == 2000) return true;
        } catch (Throwable ignored) {}

        // 检测无线调试端口是否开放（5555）
        try {
            java.net.Socket s = new java.net.Socket();
            s.connect(new java.net.InetSocketAddress("127.0.0.1", 5555), 400);
            boolean open = s.isConnected();
            s.close();
            if (open) return true;
        } catch (Throwable ignored) {}

        return false;
    }

    @Override
    public ShellResult exec(String command, int timeoutSeconds) {
        if (!isAvailable()) {
            AppLog.w("ADB 执行器不可用，请确认无线调试已开启或改用 Shizuku/ROOT");
        }
        return RootExecutor.ExecSupport.run(new String[]{"sh", "-c", command}, timeoutSeconds, getId());
    }
}
