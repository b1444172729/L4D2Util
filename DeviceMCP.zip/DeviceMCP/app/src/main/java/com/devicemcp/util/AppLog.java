package com.devicemcp.util;

import android.util.Log;

import java.util.ArrayList;
import java.util.List;

/** 轻量日志：同时输出到 logcat 与内存缓冲（供 UI 展示） */
public final class AppLog {
    private static final String TAG = "DeviceMCP";
    private static final int MAX = 400;
    private static final List<String> BUFFER = new ArrayList<>();
    private static volatile Listener listener;

    public interface Listener { void onLog(String line); }

    public static void setListener(Listener l) { listener = l; }

    private static void add(int level, String msg) {
        String prefix = level == Log.ERROR ? "E" : (level == Log.WARN ? "W" : "I");
        String line = prefix + " | " + msg;
        synchronized (BUFFER) {
            BUFFER.add(line);
            while (BUFFER.size() > MAX) BUFFER.remove(0);
        }
        if (listener != null) {
            try { listener.onLog(line); } catch (Throwable ignored) {}
        }
        Log.println(level, TAG, msg);
    }

    public static void i(String m) { add(Log.INFO, m); }
    public static void w(String m) { add(Log.WARN, m); }
    public static void e(String m) { add(Log.ERROR, m); }
    public static void e(String m, Throwable t) { add(Log.ERROR, m + " : " + t); }

    public static String snapshot() {
        StringBuilder sb = new StringBuilder();
        synchronized (BUFFER) {
            for (int i = BUFFER.size() - 1; i >= 0; i--) {
                sb.append(BUFFER.get(i)).append('\n');
            }
        }
        return sb.toString();
    }
}
