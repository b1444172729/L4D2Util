package com.devicemcp.tools;

import android.content.Context;
import android.graphics.Rect;
import android.os.Build;
import android.view.accessibility.AccessibilityNodeInfo;

import com.devicemcp.server.ToolDefinition;
import com.devicemcp.service.DeviceAccessibilityService;
import com.devicemcp.util.Json;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** 无障碍 UI 自动化工具（需在系统设置中开启本应用的无障碍服务） */
public final class UiTools {

    public static List<ToolDefinition> all(Context ctx) {
        List<ToolDefinition> list = new ArrayList<>();

        list.add(new ToolDefinition("dev_ui_nodes",
                "导出当前屏幕的控件树（文本、描述、类名、坐标、可点击性）。用于分析界面结构。",
                Json.schema(Json.obj("maxNodes", Json.intProp("最大节点数，默认 200")), "maxNodes")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                DeviceAccessibilityService svc = DeviceAccessibilityService.getInstance();
                if (svc == null) return Json.errorResult("无障碍服务未开启，请在系统设置中启用 DeviceMCP");
                AccessibilityNodeInfo root = svc.getRootInActiveWindow();
                if (root == null) return Json.errorResult("无法获取当前窗口（无障碍服务未就绪）");
                int max = a.optInt("maxNodes", 200);
                JSONArray arr = new JSONArray();
                collect(root, arr, max, 0);
                return Json.textResult("节点数 " + arr.length() + "：\n" + arr.toString(1));
            }
        });

        list.add(new ToolDefinition("dev_ui_click_text",
                "按文本或内容描述点击控件（自动查找并点击其可见中心点）。",
                Json.schema(Json.obj(
                        "text", Json.strProp("要匹配的文本或描述"),
                        "exact", Json.boolProp("是否完全匹配，默认 false（子串匹配）")),
                        "text")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                DeviceAccessibilityService svc = DeviceAccessibilityService.getInstance();
                if (svc == null) return Json.errorResult("无障碍服务未开启");
                String text = a.optString("text", "");
                boolean exact = a.optBoolean("exact", false);
                AccessibilityNodeInfo root = svc.getRootInActiveWindow();
                if (root == null) return Json.errorResult("无法获取当前窗口");
                AccessibilityNodeInfo target = findByText(root, text, exact);
                if (target == null) return Json.errorResult("未找到包含文本的节点: " + text);
                boolean ok = clickNode(svc, target);
                return ok ? Json.textResult("已点击: " + text) : Json.errorResult("点击失败: " + text);
            }
        });

        list.add(new ToolDefinition("dev_ui_click_xy", "按屏幕坐标点击。",
                Json.schema(Json.obj("x", Json.intProp("横坐标px"), "y", Json.intProp("纵坐标px")), "x", "y")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                DeviceAccessibilityService svc = DeviceAccessibilityService.getInstance();
                if (svc == null) return Json.errorResult("无障碍服务未开启");
                int x = a.optInt("x", 0), y = a.optInt("y", 0);
                boolean ok = svc.clickXY(x, y);
                return ok ? Json.textResult("已点击 (" + x + "," + y + ")") : Json.errorResult("点击失败");
            }
        });

        list.add(new ToolDefinition("dev_ui_swipe", "在屏幕上滑动（用于翻页、下拉刷新等）。",
                Json.schema(Json.obj(
                        "x1", Json.intProp("起点X"), "y1", Json.intProp("起点Y"),
                        "x2", Json.intProp("终点X"), "y2", Json.intProp("终点Y"),
                        "durationMs", Json.intProp("滑动时长毫秒，默认 400")),
                        "x1", "y1", "x2", "y2")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                DeviceAccessibilityService svc = DeviceAccessibilityService.getInstance();
                if (svc == null) return Json.errorResult("无障碍服务未开启");
                boolean ok = svc.swipe(a.optInt("x1"), a.optInt("y1"),
                        a.optInt("x2"), a.optInt("y2"), a.optLong("durationMs", 400));
                return ok ? Json.textResult("已滑动") : Json.errorResult("滑动失败（需 Android 7+ 且开启 canPerformGestures）");
            }
        });

        list.add(new ToolDefinition("dev_ui_input", "向当前获得焦点的输入框输入文本。",
                Json.schema(Json.obj("text", Json.strProp("要输入的文本")), "text")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                DeviceAccessibilityService svc = DeviceAccessibilityService.getInstance();
                if (svc == null) return Json.errorResult("无障碍服务未开启");
                AccessibilityNodeInfo root = svc.getRootInActiveWindow();
                if (root == null) return Json.errorResult("无法获取当前窗口");
                AccessibilityNodeInfo edit = findEditable(root);
                if (edit == null) return Json.errorResult("未找到可编辑的输入框");
                android.os.Bundle args = new android.os.Bundle();
                args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, a.optString("text", ""));
                boolean ok = edit.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
                return ok ? Json.textResult("已输入文本") : Json.errorResult("输入失败");
            }
        });

        list.add(new ToolDefinition("dev_ui_key", "执行全局按键操作：back / home / recents / notifications。",
                Json.schema(Json.obj("key", Json.strProp("按键名：back|home|recents|notifications")), "key")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                DeviceAccessibilityService svc = DeviceAccessibilityService.getInstance();
                if (svc == null) return Json.errorResult("无障碍服务未开启");
                boolean ok = svc.globalAction(a.optString("key", "back"));
                return ok ? Json.textResult("已执行: " + a.optString("key"))
                          : Json.errorResult("执行失败: " + a.optString("key"));
            }
        });

        list.add(new ToolDefinition("dev_ui_screenshot_desc",
                "说明：截图需 Android 9+ 无障碍或 MediaProjection。本工具返回当前前台应用与窗口标题，截图请配合 dev_shell_exec 使用 screencap。",
                Json.schema(new JSONObject())) {
            @Override public JSONObject call(Context c, JSONObject a) {
                String pkg = DeviceAccessibilityService.getForegroundPackage();
                JSONObject o = Json.obj("foregroundPackage", pkg,
                        "hint", "ROOT/ADB 下可执行: screencap -p /sdcard/screen.png");
                return Json.textResult(o.toString(1));
            }
        });

        return list;
    }

    // ---------------- 辅助 ----------------

    private static void collect(AccessibilityNodeInfo node, JSONArray arr, int max, int depth) {
        if (node == null || arr.length() >= max || depth > 20) return;
        Rect r = new Rect();
        node.getBoundsInScreen(r);
        CharSequence txt = node.getText();
        CharSequence desc = node.getContentDescription();
        boolean meaningful = (txt != null && txt.length() > 0) || (desc != null && desc.length() > 0)
                || node.isClickable() || node.isEditable();
        if (meaningful && arr.length() < max) {
            arr.put(Json.obj(
                    "cls", String.valueOf(node.getClassName()),
                    "text", txt == null ? "" : txt.toString(),
                    "desc", desc == null ? "" : desc.toString(),
                    "bounds", r.left + "," + r.top + "," + r.right + "," + r.bottom,
                    "clickable", node.isClickable(),
                    "editable", node.isEditable(),
                    "enabled", node.isEnabled()
            ));
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            collect(node.getChild(i), arr, max, depth + 1);
        }
    }

    private static AccessibilityNodeInfo findByText(AccessibilityNodeInfo node, String text, boolean exact) {
        if (node == null || text == null) return null;
        CharSequence t = node.getText();
        CharSequence d = node.getContentDescription();
        boolean hit = false;
        if (exact) {
            hit = (t != null && t.toString().equals(text)) || (d != null && d.toString().equals(text));
        } else {
            hit = (t != null && t.toString().contains(text)) || (d != null && d.toString().contains(text));
        }
        if (hit && (node.isClickable() || node.getParent() != null)) {
            return node.isClickable() ? node : node.getParent();
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo r = findByText(node.getChild(i), text, exact);
            if (r != null) return r;
        }
        return null;
    }

    private static AccessibilityNodeInfo findEditable(AccessibilityNodeInfo node) {
        if (node == null) return null;
        if (node.isEditable() && node.isFocusable()) return node;
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo r = findEditable(node.getChild(i));
            if (r != null) return r;
        }
        return null;
    }

    private static boolean clickNode(DeviceAccessibilityService svc, AccessibilityNodeInfo node) {
        AccessibilityNodeInfo n = node;
        while (n != null && !n.isClickable()) n = n.getParent();
        if (n != null && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
        Rect r = new Rect();
        node.getBoundsInScreen(r);
        if (r.width() > 0 && r.height() > 0) {
            return svc.clickXY(r.centerX(), r.centerY());
        }
        return false;
    }
}
