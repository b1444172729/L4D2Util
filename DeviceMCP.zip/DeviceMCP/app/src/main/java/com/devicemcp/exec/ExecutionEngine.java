package com.devicemcp.exec;

import android.content.Context;

import com.devicemcp.util.AppLog;
import com.devicemcp.util.McpConfig;

/** 执行引擎：按配置选择权限后端，失败自动降级 */
public final class ExecutionEngine {

    private final Context ctx;
    private final RootExecutor root = new RootExecutor();
    private final AdbExecutor adb = new AdbExecutor();
    private final ShizukuExecutor shizuku;
    private final AppExecutor app = new AppExecutor();

    public ExecutionEngine(Context ctx) {
        this.ctx = ctx.getApplicationContext();
        this.shizuku = new ShizukuExecutor(this.ctx);
    }

    public PrivilegeExecutor get(String id) {
        switch (id) {
            case McpConfig.MODE_ROOT: return root;
            case McpConfig.MODE_SHIZUKU: return shizuku;
            case McpConfig.MODE_ADB: return adb;
            default: return app;
        }
    }

    public boolean isAvailable(String id) {
        try { return get(id).isAvailable(); } catch (Throwable t) { return false; }
    }

    /** 探测全部模式可用情况，形如 "root=✓ shizuku=✗ adb=✗" */
    public String probeAll() {
        StringBuilder sb = new StringBuilder();
        sb.append("ROOT=").append(safe(root)).append("  ");
        sb.append("Shizuku=").append(safe(shizuku)).append("  ");
        sb.append("ADB=").append(safe(adb)).append("  ");
        sb.append("无障碍=").append(com.devicemcp.service.DeviceAccessibilityService.isEnabled() ? "可用" : "未开启");
        return sb.toString();
    }

    private String safe(PrivilegeExecutor e) {
        try { return e.isAvailable() ? "可用" : "不可用"; } catch (Throwable t) { return "不可用"; }
    }

    /**
     * 执行命令。mode 为空则取配置；mode=auto 时按 root→shizuku→adb→app 依次降级。
     */
    public ShellResult exec(String command, String mode, int timeoutSeconds) {
        if (command == null || command.trim().isEmpty()) {
            return new ShellResult(-1, "", "命令为空", "none");
        }
        if (mode == null || mode.isEmpty()) mode = new McpConfig(ctx).getMode();

        if ("auto".equals(mode)) {
            String[] order = {McpConfig.MODE_ROOT, McpConfig.MODE_SHIZUKU, McpConfig.MODE_ADB, McpConfig.MODE_NONE};
            for (String m : order) {
                PrivilegeExecutor e = get(m);
                if (e.isAvailable()) {
                    ShellResult r = e.exec(command, timeoutSeconds);
                    if (r.exitCode == 0 || !"(none)".equals(m)) {
                        AppLog.i("执行 via " + m + ": " + command);
                        return r;
                    }
                }
            }
            return app.exec(command, timeoutSeconds);
        }

        PrivilegeExecutor e = get(mode);
        if (!e.isAvailable()) {
            return new ShellResult(-1, "", "所选权限模式不可用: " + mode + "（当前探测：" + probeAll() + "）", mode);
        }
        AppLog.i("执行 via " + mode + ": " + command);
        return e.exec(command, timeoutSeconds);
    }
}
