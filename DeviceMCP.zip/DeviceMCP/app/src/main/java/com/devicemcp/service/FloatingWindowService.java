package com.devicemcp.service;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import com.devicemcp.R;
import com.devicemcp.util.AppLog;
import com.devicemcp.util.McpConfig;

/** 悬浮窗服务：显示 MCP 状态小窗，同时用于提升后台存活 */
public class FloatingWindowService extends Service {

    private WindowManager wm;
    private View floatView;
    private TextView tvStatus, tvPort;

    public static boolean canDrawOverlay(Context ctx) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return true;
        return Settings.canDrawOverlays(ctx);
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (!canDrawOverlay(this)) {
            AppLog.w("无悬浮窗权限，跳过");
            stopSelf();
            return START_NOT_STICKY;
        }
        show();
        return START_STICKY;
    }

    private void show() {
        if (floatView != null) return;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        floatView = View.inflate(this, R.layout.floating_window, null);
        tvStatus = floatView.findViewById(R.id.float_status);
        tvPort = floatView.findViewById(R.id.float_port);

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = 20;
        lp.y = 180;

        // 拖动支持
        final float[] start = new float[2];
        final int[] startPos = new int[2];
        floatView.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    start[0] = event.getRawX(); start[1] = event.getRawY();
                    startPos[0] = lp.x; startPos[1] = lp.y;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    lp.x = (int) (startPos[0] + event.getRawX() - start[0]);
                    lp.y = (int) (startPos[1] + event.getRawY() - start[1]);
                    try { wm.updateViewLayout(floatView, lp); } catch (Throwable ignored) {}
                    return true;
            }
            return false;
        });

        try {
            wm.addView(floatView, lp);
            update();
            AppLog.i("悬浮窗已显示");
        } catch (Throwable t) {
            AppLog.e("悬浮窗添加失败", t);
            stopSelf();
        }
    }

    private void update() {
        if (tvStatus == null || tvPort == null) return;
        boolean running = McpForegroundService.isServerRunning();
        int port = new McpConfig(this).getPort();
        tvStatus.post(() -> {
            tvStatus.setText(running ? "MCP ●" : "MCP ○");
            tvPort.setText(String.valueOf(port));
        });
    }

    @Override public void onDestroy() {
        try { if (floatView != null && wm != null) wm.removeView(floatView); } catch (Throwable ignored) {}
        floatView = null;
        AppLog.i("悬浮窗已移除");
        super.onDestroy();
    }
}
