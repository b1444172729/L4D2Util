package com.devicemcp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import com.devicemcp.util.AppLog;
import com.devicemcp.util.McpConfig;

/** 开机 / 应用更新后自动拉起服务 */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        String a = intent != null ? intent.getAction() : "";
        if (!Intent.ACTION_BOOT_COMPLETED.equals(a) && !Intent.ACTION_MY_PACKAGE_REPLACED.equals(a)) return;
        McpConfig cfg = new McpConfig(ctx);
        if (!cfg.isAutoStart()) return;
        try {
            Intent i = new Intent(ctx, McpForegroundService.class);
            i.setAction(McpForegroundService.ACTION_START);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                ctx.startForegroundService(i);
            } else {
                ctx.startService(i);
            }
            AppLog.i("开机自启：MCP 服务已拉起");
        } catch (Throwable t) {
            AppLog.e("开机自启失败", t);
        }
    }
}
