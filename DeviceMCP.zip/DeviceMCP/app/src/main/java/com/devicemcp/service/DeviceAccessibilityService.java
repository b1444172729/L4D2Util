package com.devicemcp.service;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.Intent;
import android.graphics.Path;
import android.os.Build;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import com.devicemcp.util.AppLog;

/** 无障碍服务：提供 UI 控件树、模拟点击/滑动/全局按键，并记录前台包名 */
public class DeviceAccessibilityService extends AccessibilityService {

    private static volatile DeviceAccessibilityService instance;
    private static volatile String foregroundPackage = null;

    public static DeviceAccessibilityService getInstance() { return instance; }

    public static String getForegroundPackage() { return foregroundPackage; }

    public static boolean isEnabled() { return instance != null; }

    /** 系统设置中是否已授权本服务 */
    public static boolean isGranted(Context ctx) {
        try {
            String enabled = Settings.Secure.getString(ctx.getContentResolver(),
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (enabled == null) return false;
            String me = ctx.getPackageName() + "/" + DeviceAccessibilityService.class.getName();
            TextUtils.SimpleStringSplitter splitter = new TextUtils.SimpleStringSplitter(':');
            splitter.setString(enabled);
            while (splitter.hasNext()) {
                if (me.equalsIgnoreCase(splitter.next())) return true;
            }
        } catch (Throwable ignored) {}
        return false;
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        AppLog.i("无障碍服务已连接");
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        CharSequence pn = event.getPackageName();
        if (pn != null && pn.length() > 0) foregroundPackage = pn.toString();
    }

    @Override
    public void onInterrupt() { AppLog.w("无障碍服务被中断"); }

    @Override
    public boolean onUnbind(Intent intent) {
        instance = null;
        AppLog.w("无障碍服务已解绑");
        return super.onUnbind(intent);
    }

    // ---------------- 操作封装 ----------------

    public boolean clickXY(int x, int y) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false;
        Path path = new Path();
        path.moveTo(x, y);
        android.accessibilityservice.GestureDescription.StrokeDescription stroke =
                new android.accessibilityservice.GestureDescription.StrokeDescription(path, 0, 60);
        android.accessibilityservice.GestureDescription gd =
                new android.accessibilityservice.GestureDescription.Builder().addStroke(stroke).build();
        return dispatchGesture(gd, null, null);
    }

    public boolean swipe(int x1, int y1, int x2, int y2, long durationMs) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false;
        Path path = new Path();
        path.moveTo(x1, y1);
        path.lineTo(x2, y2);
        android.accessibilityservice.GestureDescription.StrokeDescription stroke =
                new android.accessibilityservice.GestureDescription.StrokeDescription(path, 0, durationMs);
        android.accessibilityservice.GestureDescription gd =
                new android.accessibilityservice.GestureDescription.Builder().addStroke(stroke).build();
        return dispatchGesture(gd, null, null);
    }

    public boolean globalAction(String key) {
        int action;
        switch (key == null ? "" : key.toLowerCase()) {
            case "home": action = GLOBAL_ACTION_HOME; break;
            case "recents": action = GLOBAL_ACTION_RECENTS; break;
            case "notifications": action = GLOBAL_ACTION_NOTIFICATIONS; break;
            case "back":
            default: action = GLOBAL_ACTION_BACK; break;
        }
        return performGlobalAction(action);
    }

    public AccessibilityNodeInfo getRoot() { return getRootInActiveWindow(); }
}
