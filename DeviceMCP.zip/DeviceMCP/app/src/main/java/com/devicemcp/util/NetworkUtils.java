package com.devicemcp.util;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.LinkAddress;
import android.net.LinkProperties;
import android.net.Network;
import android.net.wifi.WifiManager;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** 网络工具：实时枚举本机 IPv4 地址（含 WiFi / 以太网 / 热点 / 移动网络） */
public final class NetworkUtils {

    /** 返回全部非回环 IPv4 地址（文本形式），去重且保持稳定顺序 */
    public static List<String> getAllLanIpv4() {
        Set<String> out = new LinkedHashSet<>();
        try {
            List<NetworkInterface> ifaces = Collections.list(NetworkInterface.getNetworkInterfaces());
            for (NetworkInterface ni : ifaces) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                List<InetAddress> addrs = Collections.list(ni.getInetAddresses());
                for (InetAddress addr : addrs) {
                    if (addr.isLoopbackAddress()) continue;
                    if (!(addr instanceof Inet4Address)) continue;
                    String s = addr.getHostAddress();
                    if (s != null && !s.isEmpty()) out.add(s);
                }
            }
        } catch (Throwable t) {
            AppLog.e("枚举网络接口失败", t);
        }
        return new ArrayList<>(out);
    }

    /** 优先返回 WiFi IPv4（点分十进制），失败则回退到任意 LAN 地址 */
    @SuppressLint("DefaultLocale")
    public static String getWifiIpv4(Context ctx) {
        // 1) WifiManager（旧接口，兼容性好）
        try {
            WifiManager wm = (WifiManager) ctx.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wm != null) {
                int ip = wm.getConnectionInfo() != null ? wm.getConnectionInfo().getIpAddress() : 0;
                if (ip != 0) {
                    return String.format("%d.%d.%d.%d",
                            (ip & 0xff), (ip >> 8 & 0xff), (ip >> 16 & 0xff), (ip >> 24 & 0xff));
                }
            }
        } catch (Throwable t) {
            AppLog.w("WifiManager 获取 IP 失败: " + t.getMessage());
        }

        // 2) ConnectivityManager（Android 6+ 推荐）
        try {
            ConnectivityManager cm = (ConnectivityManager) ctx.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm != null) {
                Network active = cm.getActiveNetwork();
                if (active != null) {
                    LinkProperties lp = cm.getLinkProperties(active);
                    if (lp != null) {
                        for (LinkAddress la : lp.getLinkAddresses()) {
                            InetAddress a = la.getAddress();
                            if (a instanceof Inet4Address && !a.isLoopbackAddress()) {
                                return a.getHostAddress();
                            }
                        }
                    }
                }
            }
        } catch (Throwable t) {
            AppLog.w("ConnectivityManager 获取 IP 失败: " + t.getMessage());
        }

        // 3) 回退：取第一个 LAN 地址
        List<String> all = getAllLanIpv4();
        return all.isEmpty() ? null : all.get(0);
    }

    /** 组装完整 MCP 端点 URL */
    public static String buildEndpoint(String host, int port) {
        return "http://" + host + ":" + port + "/mcp";
    }
}
