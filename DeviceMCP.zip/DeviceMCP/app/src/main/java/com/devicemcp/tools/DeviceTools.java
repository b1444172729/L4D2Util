package com.devicemcp.tools;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Vibrator;
import android.widget.Toast;

import com.devicemcp.server.ToolDefinition;
import com.devicemcp.util.Json;
import com.devicemcp.util.McpConfig;
import com.devicemcp.util.NetworkUtils;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** 设备信息与控制类工具 */
public final class DeviceTools {

    public static List<ToolDefinition> all(Context ctx) {
        List<ToolDefinition> list = new ArrayList<>();

        list.add(new ToolDefinition("dev_device_info", "获取设备基础信息（型号、厂商、系统版本、SDK、ABI、分辨率）。",
                Json.schema(new JSONObject())) {
            @Override public JSONObject call(Context c, JSONObject a) {
                android.util.DisplayMetrics dm = c.getResources().getDisplayMetrics();
                JSONObject o = Json.obj(
                        "manufacturer", Build.MANUFACTURER,
                        "model", Build.MODEL,
                        "device", Build.DEVICE,
                        "product", Build.PRODUCT,
                        "androidVersion", Build.VERSION.RELEASE,
                        "sdkInt", Build.VERSION.SDK_INT,
                        "abis", String.join(", ", Build.SUPPORTED_ABIS),
                        "resolution", dm.widthPixels + "x" + dm.heightPixels,
                        "densityDpi", dm.densityDpi,
                        "fingerprint", Build.FINGERPRINT
                );
                return Json.textResult(o.toString(1));
            }
        });

        list.add(new ToolDefinition("dev_device_battery", "获取电量与充电状态。",
                Json.schema(new JSONObject())) {
            @Override public JSONObject call(Context c, JSONObject a) {
                IntentFilterHolder.check(c);
                Intent i = c.registerReceiver(null, new android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED));
                int level = i != null ? i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) : -1;
                int scale = i != null ? i.getIntExtra(BatteryManager.EXTRA_SCALE, -1) : -1;
                int status = i != null ? i.getIntExtra(BatteryManager.EXTRA_STATUS, -1) : -1;
                String st = status == BatteryManager.BATTERY_STATUS_CHARGING ? "充电中"
                        : status == BatteryManager.BATTERY_STATUS_FULL ? "已充满"
                        : status == BatteryManager.BATTERY_STATUS_DISCHARGING ? "放电中" : "未知";
                return Json.textResult(Json.obj("levelPercent", scale > 0 ? level * 100 / scale : -1,
                        "status", st, "rawLevel", level, "scale", scale).toString(1));
            }
        });

        list.add(new ToolDefinition("dev_device_ip", "实时获取本机全部 IPv4 地址，并给出本地与局域网 MCP 端点。",
                Json.schema(new JSONObject())) {
            @Override public JSONObject call(Context c, JSONObject a) {
                int port = new McpConfig(c).getPort();
                List<String> ips = NetworkUtils.getAllLanIpv4();
                org.json.JSONArray arr = new org.json.JSONArray();
                for (String ip : ips) arr.put(NetworkUtils.buildEndpoint(ip, port));
                JSONObject o = Json.obj(
                        "port", port,
                        "localEndpoint", NetworkUtils.buildEndpoint("127.0.0.1", port),
                        "lanEndpoints", arr,
                        "wifiIp", NetworkUtils.getWifiIpv4(c)
                );
                return Json.textResult(o.toString(1));
            }
        });

        list.add(new ToolDefinition("dev_device_network", "获取网络连接状态与类型。",
                Json.schema(new JSONObject())) {
            @Override public JSONObject call(Context c, JSONObject a) {
                android.net.ConnectivityManager cm = (android.net.ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE);
                JSONObject o = new JSONObject();
                try {
                    android.net.Network n = cm != null ? cm.getActiveNetwork() : null;
                    android.net.NetworkCapabilities nc = cm != null && n != null ? cm.getNetworkCapabilities(n) : null;
                    o.put("connected", n != null);
                    o.put("wifi", nc != null && nc.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI));
                    o.put("cellular", nc != null && nc.hasTransport(android.net.NetworkCapabilities.TRANSPORT_CELLULAR));
                    o.put("ethernet", nc != null && nc.hasTransport(android.net.NetworkCapabilities.TRANSPORT_ETHERNET));
                    o.put("vpn", nc != null && nc.hasTransport(android.net.NetworkCapabilities.TRANSPORT_VPN));
                } catch (Throwable t) {
                    return Json.errorResult("获取网络状态失败: " + t.getMessage());
                }
                return Json.textResult(o.toString(1));
            }
        });

        list.add(new ToolDefinition("dev_device_clipboard_get", "读取剪贴板内容。",
                Json.schema(new JSONObject())) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ClipboardManager cm = (ClipboardManager) c.getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm == null || !cm.hasPrimaryClip()) return Json.textResult("(剪贴板为空)");
                ClipData d = cm.getPrimaryClip();
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < d.getItemCount(); i++) sb.append(d.getItemAt(i).getText()).append('\n');
                return Json.textResult(sb.toString().trim());
            }
        });

        list.add(new ToolDefinition("dev_device_clipboard_set", "写入剪贴板。",
                Json.schema(Json.obj("text", Json.strProp("要写入的文本")), "text")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                ClipboardManager cm = (ClipboardManager) c.getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm == null) return Json.errorResult("剪贴板服务不可用");
                cm.setPrimaryClip(ClipData.newPlainText("mcp", a.optString("text", "")));
                return Json.textResult("已写入剪贴板");
            }
        });

        list.add(new ToolDefinition("dev_device_toast", "在屏幕上显示一条 Toast 提示。",
                Json.schema(Json.obj("text", Json.strProp("提示文本")), "text")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                String t = a.optString("text", "");
                new android.os.Handler(android.os.Looper.getMainLooper()).post(
                        () -> Toast.makeText(c, t, Toast.LENGTH_LONG).show());
                return Json.textResult("已显示 Toast: " + t);
            }
        });

        list.add(new ToolDefinition("dev_device_vibrate", "触发振动。",
                Json.schema(Json.obj("milliseconds", Json.intProp("振动时长，默认 200")), "milliseconds")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                long ms = a.optLong("milliseconds", 200);
                Vibrator v = (Vibrator) c.getSystemService(Context.VIBRATOR_SERVICE);
                if (v == null) return Json.errorResult("振动器不可用");
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    v.vibrate(android.os.VibrationEffect.createOneShot(ms, android.os.VibrationEffect.DEFAULT_AMPLITUDE));
                } else {
                    v.vibrate(ms);
                }
                return Json.textResult("已振动 " + ms + "ms");
            }
        });

        list.add(new ToolDefinition("dev_mcp_status", "查询 MCP 服务自身状态（端口、鉴权、工具数量、权限、端点）。",
                Json.schema(new JSONObject())) {
            @Override public JSONObject call(Context c, JSONObject a) {
                int port = new McpConfig(c).getPort();
                List<String> ips = NetworkUtils.getAllLanIpv4();
                org.json.JSONArray arr = new org.json.JSONArray();
                for (String ip : ips) arr.put(NetworkUtils.buildEndpoint(ip, port));
                JSONObject o = Json.obj(
                        "server", "device-mcp",
                        "running", com.devicemcp.service.McpForegroundService.isServerRunning(),
                        "port", port,
                        "authEnabled", !new McpConfig(c).getToken().isEmpty(),
                        "toolCount", com.devicemcp.server.ToolRegistry.count(),
                        "privilegeMode", new McpConfig(c).getMode(),
                        "localEndpoint", NetworkUtils.buildEndpoint("127.0.0.1", port),
                        "lanEndpoints", arr
                );
                return Json.textResult(o.toString(1));
            }
        });

        return list;
    }

    /** 占位：保持 battery 工具可读性 */
    static final class IntentFilterHolder {
        static void check(Context c) { }
    }
}
