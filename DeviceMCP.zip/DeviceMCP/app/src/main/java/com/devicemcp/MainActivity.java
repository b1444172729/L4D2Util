package com.devicemcp;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.devicemcp.exec.ExecutionEngine;
import com.devicemcp.service.DeviceAccessibilityService;
import com.devicemcp.service.FloatingWindowService;
import com.devicemcp.service.McpForegroundService;
import com.devicemcp.util.AppLog;
import com.devicemcp.util.McpConfig;
import com.devicemcp.util.NetworkUtils;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private McpConfig cfg;
    private ExecutionEngine engine;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private TextView tvStatus, tvAddrLocal, tvAddrLan, tvLog, tvPriv;
    private Button btnToggle;
    private EditText etPort, etToken;
    private RadioGroup rgMode;
    private CheckBox cbFloat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cfg = new McpConfig(this);
        engine = new ExecutionEngine(this);

        tvStatus = findViewById(R.id.tv_status);
        tvAddrLocal = findViewById(R.id.tv_addr_local);
        tvAddrLan = findViewById(R.id.tv_addr_lan);
        tvLog = findViewById(R.id.tv_log);
        tvPriv = findViewById(R.id.tv_priv);
        btnToggle = findViewById(R.id.btn_toggle);
        etPort = findViewById(R.id.et_port);
        etToken = findViewById(R.id.et_token);
        rgMode = findViewById(R.id.rg_mode);
        cbFloat = findViewById(R.id.cb_float);

        tvLog.setMovementMethod(new ScrollingMovementMethod());

        etPort.setText(String.valueOf(cfg.getPort()));
        etToken.setText(cfg.getToken());
        cbFloat.setChecked(cfg.isFloating());
        syncModeRadio();

        btnToggle.setOnClickListener(v -> toggle());
        findViewById(R.id.btn_save).setOnClickListener(v -> saveConfig());
        findViewById(R.id.btn_float_perm).setOnClickListener(v -> requestOverlay());
        findViewById(R.id.btn_acc).setOnClickListener(v -> openAccessibility());
        findViewById(R.id.btn_battery).setOnClickListener(v -> requestBattery());

        tvAddrLocal.setOnClickListener(v -> copy(tvAddrLocal.getText().toString()));
        tvAddrLan.setOnClickListener(v -> copy(tvAddrLan.getText().toString()));

        rgMode.setOnCheckedChangeListener((g, id) -> {
            String m = McpConfig.MODE_NONE;
            if (id == R.id.rb_root) m = McpConfig.MODE_ROOT;
            else if (id == R.id.rb_shizuku) m = McpConfig.MODE_SHIZUKU;
            else if (id == R.id.rb_adb) m = McpConfig.MODE_ADB;
            cfg.setMode(m);
            refreshPrivilege();
        });

        AppLog.setListener(line -> ui.post(() -> tvLog.setText(AppLog.snapshot())));

        requestNotificationPermission();
        ui.post(this::refresh);
        startRefreshTimer();
    }

    private void startRefreshTimer() {
        ui.postDelayed(new Runnable() {
            @Override public void run() {
                refresh();
                ui.postDelayed(this, 3000);
            }
        }, 3000);
    }

    private void toggle() {
        if (McpForegroundService.isServerRunning()) {
            Intent i = new Intent(this, McpForegroundService.class);
            i.setAction(McpForegroundService.ACTION_STOP);
            startService(i);
            stopService(new Intent(this, FloatingWindowService.class));
        } else {
            saveConfig();
            Intent i = new Intent(this, McpForegroundService.class);
            i.setAction(McpForegroundService.ACTION_START);
            i.putExtra(McpForegroundService.EXTRA_PORT, cfg.getPort());
            i.putExtra(McpForegroundService.EXTRA_TOKEN, cfg.getToken());
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i);
            else startService(i);

            if (cfg.isFloating() && FloatingWindowService.canDrawOverlay(this)) {
                startService(new Intent(this, FloatingWindowService.class));
            }
        }
        ui.postDelayed(this::refresh, 600);
    }

    private void saveConfig() {
        int port = parsePort(etPort.getText().toString(), cfg.getPort());
        cfg.setPort(port);
        cfg.setToken(etToken.getText().toString().trim());
        cfg.setFloating(cbFloat.isChecked());
        Toast.makeText(this, "配置已保存（端口 " + port + "）", Toast.LENGTH_SHORT).show();
        AppLog.i("配置已保存：port=" + port + " token=" + (cfg.getToken().isEmpty() ? "(空)" : "已设置"));
        refresh();
    }

    private int parsePort(String s, int fallback) {
        try {
            int p = Integer.parseInt(s.trim());
            if (p < 1 || p > 65535) return fallback;
            return p;
        } catch (Exception e) { return fallback; }
    }

    private void syncModeRadio() {
        switch (cfg.getMode()) {
            case McpConfig.MODE_ROOT: rgMode.check(R.id.rb_root); break;
            case McpConfig.MODE_SHIZUKU: rgMode.check(R.id.rb_shizuku); break;
            case McpConfig.MODE_ADB: rgMode.check(R.id.rb_adb); break;
            default: rgMode.check(R.id.rb_none); break;
        }
    }

    private void refresh() {
        boolean running = McpForegroundService.isServerRunning();
        int port = running ? McpForegroundService.getRunningPort() : cfg.getPort();
        tvStatus.setText(running ? "状态：运行中 ●" : "状态：未启动 ○");
        tvStatus.setTextColor(getColor(running ? R.color.green : R.color.red));
        btnToggle.setText(running ? "停止服务" : "启动服务");

        String local = NetworkUtils.buildEndpoint("127.0.0.1", port);
        tvAddrLocal.setText("本地：" + local);

        List<String> ips = NetworkUtils.getAllLanIpv4();
        StringBuilder sb = new StringBuilder();
        if (ips.isEmpty()) {
            sb.append("局域网：未获取到 IP（请连接 WiFi）");
        } else {
            sb.append("局域网：\n");
            for (String ip : ips) sb.append("  ").append(NetworkUtils.buildEndpoint(ip, port)).append('\n');
        }
        tvAddrLan.setText(sb.toString().trim());

        refreshPrivilege();
        tvLog.setText(AppLog.snapshot());
    }

    private void refreshPrivilege() {
        tvPriv.setText("探测：" + engine.probeAll());
    }

    private void copy(String text) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("url", text));
        Toast.makeText(this, "已复制", Toast.LENGTH_SHORT).show();
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                    != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 100);
            }
        }
    }

    private void requestOverlay() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(i);
        } else {
            Toast.makeText(this, "已具备悬浮窗权限", Toast.LENGTH_SHORT).show();
        }
    }

    private void openAccessibility() {
        if (DeviceAccessibilityService.isGranted(this)) {
            Toast.makeText(this, "无障碍服务已开启", Toast.LENGTH_SHORT).show();
            return;
        }
        Toast.makeText(this, "请在列表中找到 DeviceMCP 并开启", Toast.LENGTH_LONG).show();
        startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
    }

    private void requestBattery() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } catch (Throwable t) {
                Toast.makeText(this, "无法跳转电池优化设置", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
