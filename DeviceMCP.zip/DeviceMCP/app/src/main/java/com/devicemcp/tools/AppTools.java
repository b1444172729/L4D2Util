package com.devicemcp.tools;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.provider.Settings;

import com.devicemcp.server.ToolDefinition;
import com.devicemcp.util.Json;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** 应用管理类工具 */
public final class AppTools {

    public static List<ToolDefinition> all(Context ctx) {
        List<ToolDefinition> list = new ArrayList<>();

        list.add(new ToolDefinition("dev_app_list", "列出已安装应用（包名、名称、版本、是否系统应用）。",
                Json.schema(Json.obj(
                        "includeSystem", Json.boolProp("是否包含系统应用，默认 false"),
                        "keyword", Json.strProp("按包名或名称过滤，可为空")))) {
            @Override public JSONObject call(Context c, JSONObject a) {
                PackageManager pm = c.getPackageManager();
                boolean sys = a.optBoolean("includeSystem", false);
                String kw = a.optString("keyword", "");
                List<PackageInfo> ps = pm.getInstalledPackages(0);
                JSONArray arr = new JSONArray();
                for (PackageInfo pi : ps) {
                    ApplicationInfo ai = pi.applicationInfo;
                    boolean isSys = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                    if (isSys && !sys) continue;
                    String label = pm.getApplicationLabel(ai).toString();
                    if (!kw.isEmpty() && !(label.toLowerCase().contains(kw.toLowerCase())
                            || pi.packageName.toLowerCase().contains(kw.toLowerCase()))) continue;
                    arr.put(Json.obj("package", pi.packageName, "name", label,
                            "versionName", pi.versionName, "versionCode", pi.versionCode, "system", isSys));
                }
                return Json.textResult("共 " + arr.length() + " 个应用：\n" + arr.toString(1));
            }
        });

        list.add(new ToolDefinition("dev_app_info", "获取指定应用的详细信息（版本、权限、安装时间、首次安装时间）。",
                Json.schema(Json.obj("package", Json.strProp("应用包名")), "package")) {
            @Override public JSONObject call(Context c, JSONObject a) throws Exception {
                String pkg = a.optString("package", "");
                PackageManager pm = c.getPackageManager();
                PackageInfo pi = pm.getPackageInfo(pkg, PackageManager.GET_PERMISSIONS);
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
                JSONArray perms = new JSONArray();
                if (pi.requestedPermissions != null) for (String p : pi.requestedPermissions) perms.put(p);
                JSONObject o = Json.obj(
                        "package", pkg,
                        "name", pm.getApplicationLabel(pi.applicationInfo).toString(),
                        "versionName", pi.versionName,
                        "versionCode", pi.versionCode,
                        "firstInstallTime", sdf.format(new java.util.Date(pi.firstInstallTime)),
                        "lastUpdateTime", sdf.format(new java.util.Date(pi.lastUpdateTime)),
                        "system", (pi.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0,
                        "sourceDir", pi.applicationInfo.sourceDir,
                        "dataDir", pi.applicationInfo.dataDir,
                        "permissions", perms
                );
                return Json.textResult(o.toString(1));
            }
        });

        list.add(new ToolDefinition("dev_app_launch", "启动指定应用（通过包名获取启动 Intent）。",
                Json.schema(Json.obj("package", Json.strProp("应用包名")), "package")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                String pkg = a.optString("package", "");
                Intent launch = c.getPackageManager().getLaunchIntentForPackage(pkg);
                if (launch == null) return Json.errorResult("无法启动（未找到启动 Activity）: " + pkg);
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                c.startActivity(launch);
                return Json.textResult("已启动: " + pkg);
            }
        });

        list.add(new ToolDefinition("dev_app_stop", "强制停止指定应用（需系统签名或 ROOT，普通模式下仅能杀自己）。",
                Json.schema(Json.obj("package", Json.strProp("应用包名")), "package")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                String pkg = a.optString("package", "");
                android.app.ActivityManager am = (android.app.ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
                try {
                    java.lang.reflect.Method m = am.getClass().getMethod("forceStopPackage", String.class);
                    m.invoke(am, pkg);
                    return Json.textResult("已请求停止: " + pkg + "（需系统权限才真正生效）");
                } catch (Throwable t) {
                    return Json.errorResult("停止失败（可能需要 ROOT/系统权限）: " + t.getMessage()
                            + "\n提示：可改用 dev_shell_exec 执行 am force-stop " + pkg);
                }
            }
        });

        list.add(new ToolDefinition("dev_app_install", "请求安装 APK（会弹出系统安装界面）。",
                Json.schema(Json.obj("apkPath", Json.strProp("APK 文件绝对路径")), "apkPath")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                String p = a.optString("apkPath", "");
                java.io.File f = new java.io.File(p);
                if (!f.isFile()) return Json.errorResult("APK 不存在: " + p);
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                Uri uri = androidx.core.content.FileProvider.getUriForFile(c, c.getPackageName() + ".fileprovider", f);
                i.setDataAndType(uri, "application/vnd.android.package-archive");
                c.startActivity(i);
                return Json.textResult("已发起安装请求: " + p);
            }
        });

        list.add(new ToolDefinition("dev_app_uninstall", "请求卸载应用（会弹出系统确认界面）。",
                Json.schema(Json.obj("package", Json.strProp("应用包名")), "package")) {
            @Override public JSONObject call(Context c, JSONObject a) {
                String pkg = a.optString("package", "");
                Intent i = new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + pkg));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                c.startActivity(i);
                return Json.textResult("已发起卸载请求: " + pkg + "（静默卸载请用 dev_shell_exec + pm uninstall）");
            }
        });

        list.add(new ToolDefinition("dev_app_current", "获取当前前台应用包名（依赖无障碍服务）。",
                Json.schema(new JSONObject())) {
            @Override public JSONObject call(Context c, JSONObject a) {
                String pkg = com.devicemcp.service.DeviceAccessibilityService.getForegroundPackage();
                if (pkg == null) return Json.errorResult("未能获取前台应用，请确认已开启无障碍服务");
                return Json.textResult(pkg);
            }
        });

        return list;
    }
}
