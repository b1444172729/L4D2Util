# DeviceMCP — 让 AI 通过 MCP 协议控制你的安卓手机

一个完整可编译的 Android 应用源码，在本机运行一个 MCP（Model Context Protocol）服务器，
把手机的文件、Shell、应用、设备状态、UI 自动化能力暴露给任意支持 MCP 的 AI 客户端。

- 默认端口 **9797**，可在 App 内自定义
- 本地端点：`http://127.0.0.1:9797/mcp`
- 局域网端点：`http://<手机实时IP>:9797/mcp`（IP 由工具实时枚举，界面每 3 秒刷新）
- 四种权限后端：**ROOT / Shizuku / ADB / 无障碍**
- 前台服务 + 悬浮窗 + WakeLock 保活，支持开机自启

---

## 一、快速开始

### 1. 编译

```bash
# 环境要求：JDK 17、Android SDK（compileSdk 34）
./gradlew assembleDebug
# 产物：app/build/outputs/apk/debug/app-debug.apk
```

用 Android Studio 打开 `DeviceMCP` 目录直接 Run 亦可。

### 2. 安装与授权

首次打开 App 后依次处理：

| 项目 | 操作 |
|---|---|
| 通知权限 | Android 13+ 首次启动会自动申请（前台服务必需） |
| 悬浮窗 | 点「申请悬浮窗权限」→ 在设置页打开本应用开关 |
| 无障碍 | 点「前往开启无障碍服务」→ 找到 **DeviceMCP** 并开启（UI 类工具依赖此项） |
| 电池优化 | 点「申请忽略电池优化」→ 选择「允许」，提升后台存活 |
| 存储 | 在系统设置中授予文件访问权限；ROOT/Shizuku 下可用提权绕过限制 |

### 3. 配置端口并启动

1. 在「端口」输入框填写端口（默认 9797，可改成任意 1–65535）
2. 「鉴权 Token」留空表示不鉴权；**暴露到局域网时强烈建议填写**
3. 选择权限模式（ROOT / Shizuku / ADB / 无）
4. 点「保存配置」→ 点「启动服务」

启动后界面会实时显示本地地址与全部局域网地址，点击即可复制。

### 4. 在 AI 客户端中接入

在支持**自定义远程 MCP（Streamable HTTP）**的客户端中填写：

```
URL:      http://192.168.10.14:9797/mcp
类型:     Streamable HTTP / 远程 MCP（不要选 stdio）
请求头:   Authorization: Bearer <你的Token>   （若开启了鉴权）
```

典型配置示例：

```json
{
  "mcpServers": {
    "device": {
      "type": "http",
      "url": "http://192.168.10.14:9797/mcp",
      "headers": { "Authorization": "Bearer 你的Token" }
    }
  }
}
```

```bash
# Claude Code
claude mcp add device --transport http http://192.168.10.14:9797/mcp
```

---

## 二、为什么之前会「资源解析服务请求失败」

这个报错是**客户端**返回的，与端口冲突无关。常见原因按概率排序：

1. **客户端不支持自定义远程 MCP** — 多数手机端 AI App 只允许使用内置连接器，无法填入自建 URL。
   这类情况目前没有绕过的办法，只能换用支持自定义 MCP 的客户端
   （如电脑端 Claude Code / Cursor / Cline / LobeChat / Open WebUI，再让手机远程回连）。
2. **服务只绑了 127.0.0.1** — 本项目已默认绑定 `0.0.0.0`，局域网可直连；若你改用其它实现，务必显式指定绑定地址。
3. **手机与客户端不在同一局域网** — `192.168.x.x` 是局域网地址，需连同一 WiFi。
4. **防火墙拦截** 或 **服务未启动**。

排查顺序（建议照做）：

```bash
# 1) 手机浏览器直接访问，先确认网络层通
http://192.168.10.14:9797/health

# 2) 返回类似即服务正常
{"ok":true,"running":true,"port":9797,"tools":40,"auth":false}
```

浏览器都打不开 → 是网络/防火墙问题，与 MCP 协议无关。

---

## 三、权限模式说明

| 模式 | 获取方式 | 能力 |
|---|---|---|
| **ROOT** | 设备已 root 并授权 su | 完整 shell 权限，可静默安装/卸载、访问任意目录 |
| **Shizuku** | 安装 Shizuku（可用 ADB 或 ROOT 启动），本 App 首次调用时授予授权 | 以 shell/ROOT 身份执行，无需 root 手机 |
| **ADB** | 进程以 shell(uid 2000) 身份运行，或已开启无线调试 | 受限的 shell 权限；普通安装场景下通常不可用，建议改用 Shizuku |
| **无障碍** | 系统设置中开启本服务 | 读取控件树、模拟点击/滑动/输入、全局按键，**不需要 root** |

`dev_shell_exec` 的 `mode` 参数支持 `auto`，会按 ROOT → Shizuku → ADB → 普通 依次降级尝试。

> 提示：ADB 模式在普通用户态 App 中很难真正生效。最实用的免 root 组合是
> **Shizuku（负责提权 Shell）+ 无障碍（负责 UI 自动化）**。

---

## 四、工具清单（约 40 个）

### 设备与信息
| 工具 | 说明 |
|---|---|
| `dev_device_info` | 型号、厂商、系统版本、ABI、分辨率 |
| `dev_device_battery` | 电量与充电状态 |
| `dev_device_ip` | **实时枚举全部 IPv4 并给出 MCP 端点** |
| `dev_device_network` | 网络类型（WiFi/蜂窝/以太网/VPN） |
| `dev_device_clipboard_get` / `_set` | 剪贴板读写 |
| `dev_device_toast` | 屏幕 Toast 提示 |
| `dev_device_vibrate` | 振动 |
| `dev_mcp_status` | 服务自身状态（端口、鉴权、工具数、端点） |

### Shell
| 工具 | 说明 |
|---|---|
| `dev_shell_exec` | 执行命令，可指定 `mode`：`root`/`shizuku`/`adb`/`none`/`auto` |
| `dev_shell_which` | 探测各权限模式可用性 |

### 文件
`dev_file_list`、`dev_file_read_text`、`dev_file_read_bytes`（十六进制）、`dev_file_write_text`、
`dev_file_delete`、`dev_file_copy`、`dev_file_move`、`dev_file_mkdir`、`dev_file_stat`、
`dev_file_search`（按名）、`dev_file_search_text`（按内容）、`dev_file_get_access_policy`

路径支持 `~` 代表外部存储根目录。

### 应用
`dev_app_list`、`dev_app_info`、`dev_app_launch`、`dev_app_stop`、`dev_app_install`、
`dev_app_uninstall`、`dev_app_current`

### UI（需无障碍）
`dev_ui_nodes`（控件树）、`dev_ui_click_text`（按文本点击）、`dev_ui_click_xy`（坐标点击）、
`dev_ui_swipe`（滑动）、`dev_ui_input`（输入文本）、`dev_ui_key`（back/home/recents/notifications）、
`dev_ui_screenshot_desc`

---

## 五、目录结构

```
DeviceMCP/
├── app/src/main/java/com/devicemcp/
│   ├── MainActivity.java            主界面：端口/Token/权限模式/地址/日志
│   ├── BootReceiver.java            开机自启
│   ├── server/
│   │   ├── McpHttpServer.java       HTTP + JSON-RPC 2.0 + 鉴权（核心）
│   │   ├── ToolDefinition.java      工具基类
│   │   └── ToolRegistry.java        工具注册与分发
│   ├── exec/
│   │   ├── ExecutionEngine.java     权限后端调度与降级
│   │   ├── RootExecutor.java        su -c（含通用进程运行器）
│   │   ├── ShizukuExecutor.java     Shizuku Binder
│   │   ├── AdbExecutor.java         shell 身份
│   │   └── AppExecutor.java         普通权限
│   ├── tools/                       FileTools / ShellTools / AppTools / DeviceTools / UiTools
│   ├── service/
│   │   ├── McpForegroundService.java  前台服务（托管 Server + 通知 + WakeLock）
│   │   ├── FloatingWindowService.java  悬浮窗保活
│   │   └── DeviceAccessibilityService.java  无障碍
│   └── util/                        AppLog / Json / McpConfig / NetworkUtils
└── app/src/main/res/                布局、值、无障碍配置、FileProvider 路径
```

---

## 六、协议实现要点

- **传输**：Streamable HTTP 风格，单端点 `POST /mcp`，无状态模式（每个请求自包含，无需会话粘性）
- **方法**：`initialize`、`ping`、`tools/list`、`tools/call`、`resources/list`、`prompts/list`、
  `notifications/initialized`
- **响应**：默认 `application/json`；当请求 `Accept` 含 `text/event-stream` 时以 SSE 返回
- **绑定**：`0.0.0.0`，局域网客户端可直接访问（这是能否被手机外设备连上的关键）
- **健康检查**：`GET /health` 返回 `{"ok":true,...}`
- **鉴权**：Token 非空时校验 `Authorization: Bearer <token>`
- **CORS**：已放行，便于浏览器类客户端调试

---

## 七、端口冲突说明

- 同一 IP 同一端口，同一时刻只能有一个进程监听。若 9797 已被其它 MCP 服务占用，本服务会启动失败并在日志中提示，换成其它端口即可。
- 反过来，**多个 AI 客户端同时连同一个 MCP 服务是允许的**，不会冲突——协议本身支持多客户端并发。

---

## 八、安全与合规提醒

1. **仅在可信网络暴露服务**。MCP 服务具备 Shell 与文件读写能力，暴露到公网等同于把手机控制权交出去。
   - 局域网使用时务必设置 Token
   - 用完后及时停止服务
2. **本工具仅可用于**：自己的设备、明确授权的测试环境、安全研究、学习用途。
3. 未经授权控制他人设备、读取他人数据、绕过应用授权机制，均违反相关法律法规。
4. 修改第三方应用、静默安装/卸载可能触及软件许可协议与著作权，请谨慎评估。

---

## 九、常见问题

**Q：改了端口需要重启服务吗？**
A：需要。保存配置后停止再启动一次，前台服务会重新 `bind` 新端口。

**Q：局域网 IP 变了怎么办？**
A：界面每 3 秒自动刷新；也可让 AI 调用 `dev_device_ip` 实时获取，无需你手动查看。

**Q：Shizuku 一直显示不可用？**
A：确认 Shizuku App 已启动且处于运行状态（v11+ 需先在 Shizuku 里启动服务），
并在本 App 首次调用时同意授权。

**Q：无障碍开启后仍读不到控件树？**
A：部分应用（如银行类）会阻止无障碍读取窗口内容，这是系统限制，无法绕过。

**Q：服务过一会儿就被杀了？**
A：依次确认：已开启悬浮窗、已忽略电池优化、通知未被关闭；部分国产 ROM 还需在「自启动管理」中手动放行本应用。
