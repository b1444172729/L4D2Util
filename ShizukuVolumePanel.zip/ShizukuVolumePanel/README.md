# ShizukuVolumePanel

用 Shizuku 权限工作的媒体音量控制示例源码。三个按钮、一套面板、**不需要无障碍权限**。
本仓库只提供源码，不附带编译产物 APK。

## 三个按钮

| 按钮 | 行为 |
| --- | --- |
| 发起授权 | Shizuku 服务没跑 → 引导打开 Shizuku；已跑但未授权 → `Shizuku.requestPermission()` 弹出授权弹窗；授权成功后以 shell 身份自动 `appops set SYSTEM_ALERT_WINDOW allow` + `pm grant POST_NOTIFICATIONS` |
| 启用通知栏 | 开关一条带 `−` / `+` 的常驻通知。点 `−/+` 直接步进媒体音量；点通知文字或通知主体，在屏幕中间弹出面板。再点一次变为「关闭通知栏」 |
| 启用悬浮窗 | 开关一个可拖动的 APP 图标浮标。点一下浮标，在屏幕中间弹出**同一个**面板。再点一次变为「关闭悬浮窗」 |

两个开关都关闭时，前台服务自行停止。

## 为什么不需要无障碍

上一轮结论：Shizuku 给的是「调用身份」，不提供全局输入拦截；要「按音量键自动弹出」才必须靠 `AccessibilityService`。
本版把触发方式改成**用户点击**（通知 / 浮标），因此：

- 不注册任何 `AccessibilityService`，manifest 里也没有相关声明；
- 不存在「无障碍权限被系统自动关掉」的问题；
- 面板由 `WindowManager` 的 `TYPE_APPLICATION_OVERLAY` 绘制，权限由 Shizuku 静默授予。

音量数值本身用 `AudioManager.setStreamVolume(STREAM_MUSIC, index, 0)` 写入：

- 面板是用户主动点开的可见窗口，属于前台交互；
- `PanelService` 由主页（前台可见时）用户点击启动，声明为 `mediaPlayback` 类型前台服务，按 Android 14+ / 17 的音频访问生命周期规则可获得 while-in-use 能力，后台收通知 `−/+` 时写入不会被静默丢弃；
- flags 传 `0`，不弹系统原生音量条，只更新自己的面板。

`ShizukuHelper.audioBinder()` 预留了以 shell 身份拿 `audio` 服务 Binder 的入口，后续要接「按 App 独立音量」的隐藏 API 时从这里扩展即可，本版不调用它，避免引入隐藏 API 编译依赖。

## 面板样式

`VolumePanelView` 用 Canvas 复刻效果示意图：

- 左侧蓝紫渐变描边的喇叭 + 两道声波（与 APP 图标同款造型）
- 深青绿已填充段 + 淡蓝发光、中灰未填充段、两端全圆角
- 白色大圆环 + 青绿圆芯滑块，带柔和投影
- 外层 `bg_panel_glass.xml` 半透明磨砂卡片，居中，点击遮罩关闭

通知栏与悬浮窗**共用 `layout_panel.xml`**，所以样式必然一致。

图标资源 `res/drawable-nodpi/app_icon.png` 来自前面生成的高清图标，做了居中裁切成 512×512 正方形以适配 launcher。
通知 `largeIcon`、悬浮浮标、launcher icon 全部引用它。
通知 `smallIcon` 用 `ic_stat_volume.xml`（同款造型的纯白矢量）——Android 要求 smallIcon 必须是单色 alpha 图，系统会对它着色，直接塞彩色 PNG 会变成白块，这是平台限制，不是样式不一致。

## 运行前提

1. Android 8.0（API 26）及以上；建议 Android 11+ 配合 Shizuku 无线调试，纯手机即可启动。
2. 安装并启动 Shizuku（无线调试 / 电脑 ADB / root 均可），然后在 App 里点「发起授权」。
3. 悬浮窗权限：授权成功后由 Shizuku `appops` 自动开；若 Shizuku 未授权，会退回系统设置页手动开。
4. 通知权限：Android 13+ 由 Shizuku `pm grant` 自动授予；未授权时退回系统权限框。
5. 依赖：`dev.rikka.shizuku:api:13.1.5`、`dev.rikka.shizuku:provider:13.1.5`、AndroidX Core / AppCompat / Material。用 Android Studio 打开根目录即可，`minSdk 26 / targetSdk 35 / compileSdk 35`。

## 已知限制（如实说明）

- **前台服务通知无法彻底隐藏**：「关闭通知栏」只是把带 `−/+` 的自定义通知降级成一条极简常驻通知。Android 不允许 FGS 完全没有通知。
- **Shizuku 重启后失效**：无线调试启动的 Shizuku 会话在手机重启后需要重新启动。App 授权记录本身还在，但 `appops` / `pm grant` 已经生效的授权不会因此回滚；只是「重新自动补权限」这一步要等 Shizuku 再跑起来。
- **固定音量设备**：`AudioManager.isVolumeFixed()` 为真时流音量不可调，主页状态栏会提示。
- **厂商适配**：MIUI / HyperOS / ColorOS 对后台与悬浮窗有额外策略，个别机型需要手动把 App 设为「无限制」电池策略。
- **分发合规**：Shizuku 提权 + 悬浮窗 + 常驻通知三者叠加，商店审核需要在隐私说明里写清用途。
- **launcher 图标**：当前直接用方形 PNG 作 `android:icon`。正式上架建议补一套自适应图标（前景 / 背景两层），否则部分启动器裁切形状不统一。

## 用 GitHub Actions 编译

仓库根目录放两样东西：

```
.github/workflows/build.yml     ← 必须直接放这里，GitHub 只认这个路径
ShizukuVolumePanel.zip          ← 源码压缩包，里面套一层 ShizukuVolumePanel/
```

> ⚠️ zip 内部那份 `.github/workflows/build.yml` 只是留档。**GitHub 不会解压 zip 去读工作流**，
> 所以必须把单独那份 `build.yml` 提交到仓库根的 `.github/workflows/`，否则 Actions 不会触发。
> 网页端可用 Add file → Create new file，路径填 `.github/workflows/build.yml` 自动建目录。

流程：push 或手动 Run workflow → 解压 zip → 自动定位含 `settings.gradle.kts` 的目录 →
JDK 17 + Android SDK 35 + Gradle 8.9 → `assembleDebug` → 上传 artifact。
在 Actions 运行页底部下载 `ShizukuVolumePanel-debug.apk`（保留 30 天）。

因为工程不带 `gradle-wrapper.jar`（二进制文件），脚本显式下载 Gradle 8.9 并直接用 `gradle` 命令，
AGP 8.7.3 对应 Gradle 8.9。Debug 构建不需要签名配置。

> **CI 修复记录（2026-11-04）**：`android-actions/setup-android@v3` 默认会装
> `tools platform-tools`，但 legacy `tools` 包已被 Google 下架，新版 cmdline-tools 下
> `sdkmanager tools` 报 `Failed to find package 'tools'` 并以 exit code 1 结束，
> 任务在编译开始前就挂。脚本已显式声明 `packages: platform-tools` 跳过该包；
> 同时把 `gradle/actions/setup-gradle` 换成显式安装 Gradle 8.9，避免 wrapper 依赖问题。
> 日志里 `setup-java@v4 is deprecated`、`Node.js 20 is deprecated` 都只是警告，不影响构建。

## 目录

```
app/src/main/
├── AndroidManifest.xml
├── java/com/example/volumepanel/
│   ├── MainActivity.kt          三个按钮与 Shizuku 授权
│   ├── ShizukuHelper.kt         Shizuku 状态、授权弹窗、appops / pm grant
│   ├── PanelService.kt          通知栏、悬浮浮标、面板浮层
│   ├── VolumePanelView.kt       自定义滑块绘制
│   ├── VolumeController.kt      媒体音量读写
│   └── Prefs.kt                 两个开关状态
├── res/drawable*/               图标、按钮、玻璃卡片、通知 smallIcon
├── res/layout/                  主页、面板、通知自定义布局
└── res/values/                  颜色、字符串、主题
```
