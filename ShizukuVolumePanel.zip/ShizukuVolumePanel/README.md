# ShizukuVolumePanel

媒体音量控制示例源码，支持 **ROOT / Shizuku 双通道提权**，三个按钮、一套面板、**不需要无障碍权限**。
本仓库只提供源码，不附带编译产物 APK。

## 三个按钮

| 按钮 | 行为 |
| --- | --- |
| 发起授权 | **先异步探测 ROOT**：`su -c id` 拿到 `uid=0` → 走 ROOT 通道，用 `su -c` 自动 `appops set SYSTEM_ALERT_WINDOW allow` + `pm grant POST_NOTIFICATIONS`；ROOT 不可用 → 切 Shizuku，服务没跑就引导打开，已跑未授权就 `Shizuku.requestPermission()` 弹授权框，授权后以 shell 身份执行同样两条命令 |
| 启用通知栏 | 开关一条带 `−` / `+` / `锁屏` 的常驻通知。点 `−/+` 直接步进媒体音量；点通知文字或通知主体，在屏幕中间弹出面板。再点一次变为「关闭通知栏」 |
| 启用悬浮窗 | 开关一个可拖动的圆形图标浮标。点一下浮标，在屏幕中间弹出**同一个**面板。再点一次变为「关闭悬浮窗」 |

两个开关都关闭时，前台服务自行停止。
「发起授权」的探测结果会缓存，之后所有提权命令都走当前通道；两个开关与面板若发现权限缺失，也会自动按同一通道补一次。

## 锁屏按钮（方案 A）

通知栏的 `+` 右边、以及弹出面板里左右居中，各有一个「锁屏」按钮：
48dp 圆形底、蓝色加粗文字，与 `−/+` 同一套样式；通知里三个按钮由 `center_vertical` 天然上下对齐，
面板里用 `layout_gravity="center"` + `translationY="-42dp"`，让按钮**最上边缘与卡片最上边缘齐平**、整体落在卡片内不超出。
（卡片 132dp 居中 → 顶边在中心 -66dp；按钮 48dp 居中 → 顶边在中心 -24dp；故平移 -42dp。早期 -70dp 会让上半圆露出卡片，已修正。）
两个汉字在 48dp 圆内用 18sp，`−/+` 符号用 30sp——再大就会被圆形裁掉。

点击后 `PanelService.lockScreen()`：先 `hidePanel()` 收掉浮层，再在子线程走当前提权通道执行
`input keyevent 223`（KEYCODE_SLEEP）。**零新增权限**：不用无障碍、不用设备管理器、不用系统签名。

- 用 223 而不是 26(POWER)：26 是 toggle，息屏时执行反而会点亮；223 只睡不醒。
- 有 PIN / 图案 / 密码时系统会进入 Keyguard；**没设安全锁时只熄屏、不锁**——Android 不允许第三方强制设置锁屏凭据。
- ROOT / Shizuku 都没起来时，按钮会 Toast「请先在『发起授权』中启用 ROOT 或 Shizuku」，不会崩。
- 个别 ROM 对 shell 注入 input 事件有限制；商店对「一键锁屏」类功能的审核也会更敏感。

## 双通道授权

优先级固定为 **ROOT > Shizuku**：

- `RootHelper`：用 `su -c id` 真正验证 `uid=0`（不是只看 su 文件是否存在），带 8 秒超时与 `destroyForcibly()`；
- `PrivilegeManager`：统一入口，缓存 ROOT 探测结果，对外只暴露 `mode()` / `exec()` / `grantAll()`；
- `ShizukuHelper`：退为纯 Shizuku 后端，只管连接、授权弹窗与 shell 命令执行。

**所有 `su` 与反射调用都放在子线程**，结果回主线程刷新 UI——Magisk / KernelSU 授权弹窗等待期间不会 ANR。
ROOT 可用时完全不碰 Shizuku，也不弹 Shizuku 授权框；ROOT 不可用时非 root 机仍可用无线调试启动的 Shizuku。

两条通道都拿不到权限时，才回退到系统权限框 / 「显示在其他应用上层」设置页。

## 为什么不需要无障碍

上一轮结论：ROOT / Shizuku 给的是「调用身份」，不提供全局输入拦截；要「按音量键自动弹出」才必须靠 `AccessibilityService`。
本版把触发方式改成**用户点击**（通知 / 浮标），因此：

- 不注册任何 `AccessibilityService`，manifest 里也没有相关声明；
- 不存在「无障碍权限被系统自动关掉」的问题；
- 面板由 `WindowManager` 的 `TYPE_APPLICATION_OVERLAY` 绘制，权限由当前提权通道（ROOT 或 Shizuku）静默授予。

音量数值本身用 `AudioManager.setStreamVolume(STREAM_MUSIC, index, 0)` 写入：

- 面板是用户主动点开的可见窗口，属于前台交互；
- `PanelService` 由主页（前台可见时）用户点击启动，声明为 `mediaPlayback` 类型前台服务，按 Android 14+ / 17 的音频访问生命周期规则可获得 while-in-use 能力，后台收通知 `−/+` 时写入不会被静默丢弃；
- flags 传 `0`，不弹系统原生音量条，只更新自己的面板。

`ShizukuHelper.audioBinder()` 预留了以 shell 身份拿 `audio` 服务 Binder 的入口，后续要接「按 App 独立音量」的隐藏 API 时从这里扩展即可，本版不调用它，避免引入隐藏 API 编译依赖。

## 面板样式

`VolumePanelView` 用 Canvas 复刻效果示意图：

- 左侧蓝紫渐变描边的喇叭 + 两道声波（与 APP 图标同款造型）
- 深青绿已填充段 + 淡蓝发光、中灰未填充段、两端全圆角
- 白色大圆环 + 青绿圆芯滑块，带柔和投影；滑块缩小且圆心限制在轨道内「两端各留一个半径」，100% 时圆完整显示、不会被卡片右边缘裁掉，同时青绿色仍铺满整条轨道
- 外层 `bg_panel_glass.xml` 半透明磨砂卡片，居中，点击遮罩关闭

通知栏与悬浮窗**共用 `layout_panel.xml`**，所以样式必然一致。

## 图标统一

`res/drawable-nodpi/app_icon.png` 是用户提供的蓝紫渐变扬声器图，居中裁成 512×512 正方形，仅用于 `android:icon`。

`res/drawable-nodpi/app_icon_round.png` 是**同一张图做圆形透明裁切**得到的圆盘版（四角透明），用于其余所有展示位：
- APP 主页顶部的图标
- 悬浮窗浮标（铺满 56dp，不再露出方角）
- 自定义通知布局左侧的 `iv_icon`
- `android:roundIcon`

通知**不再调用 `setLargeIcon()`**：`DecoratedCustomViewStyle` 会把 largeIcon 渲染在自定义视图末尾
（锁屏按钮右边），和左侧 `iv_icon` 完全重复还白占一块空间，已删除；圆形图标在通知里只保留左侧那一枚。

`res/drawable/ic_stat_volume.png` 是**从同一张图提取形状**生成的 96×96 透明底纯白剪影，用于通知 `smallIcon`。
这是 Android 的平台限制：smallIcon 必须是单色 alpha 图，系统会对它着色；直接塞彩色原图会得到一整块白方块。
因此状态栏里显示的是同款造型的白色剪影，而不是彩色图——形状来自同一张图，不是另画的一套。
Android 强制 smallIcon 为单色 alpha 图，套圆形底板会被系统着成白色实心圆，所以这里不加圆底。

通知自定义布局里 `−/+/锁屏` 是 48dp 圆形按钮（淡蓝底 + 蓝色符号/文字），文案只显示「媒体音量 N%」，右侧不再有多余图标；
点击文案、点击通知主体仍可打开面板，只是不再把这句话写进文案里。

面板内 `VolumePanelView` 左侧的小喇叭是代码用渐变描边绘制的（同款造型），
因为它要嵌进半透明玻璃卡片，直接贴带浅灰底的原图会破坏面板质感。

## 包名

`applicationId` / `namespace` 均为 **`com.android.volume`**，源码目录 `app/src/main/java/com/android/volume/`。
`ShizukuProvider` 的 authorities 用 `${applicationId}.shizuku`，会跟着变成 `com.android.volume.shizuku`，无需手改。

> ⚠️ 两点提醒：
> - 换包名后，若手机上装过旧包名的版本，属于另一个 App，Shizuku 授权、`appops` 悬浮窗授权、`pm grant` 通知授权都要在新包名下重新走一遍「发起授权」。
> - `com.android.*` 是 AOSP / 系统应用常用的命名空间，第三方 App 用它技术上可行，但个别应用商店审核或厂商 ROM 可能把它当作系统包名而额外盘问。若之后要上架，可考虑换成自有域名前缀。

## 运行前提

1. Android 8.0（API 26）及以上。
2. **二选一即可**：设备已 ROOT（Magisk / KernelSU / APatch 任一），**或** 安装并启动 Shizuku（Android 11+ 无线调试纯手机即可，10 及以下需电脑 ADB）。
3. 在 App 里点「发起授权」——会自动优先探测 ROOT，不可用才切 Shizuku。
4. 悬浮窗权限：由当前通道 `appops set SYSTEM_ALERT_WINDOW allow` 自动开；拿不到才退回系统设置页。
5. 通知权限：Android 13+ 由当前通道 `pm grant POST_NOTIFICATIONS` 自动授予；拿不到才弹系统权限框。
6. 依赖：`dev.rikka.shizuku:api:13.1.5`、`dev.rikka.shizuku:provider:13.1.5`、AndroidX Core / AppCompat / Material。用 Android Studio 打开根目录即可，`minSdk 26 / targetSdk 35 / compileSdk 35`。

> `mediaPlayback` 前台服务必须保留：Android 14+ / 17 的音频访问生命周期校验看的是**调用方 App 自身**有没有 while-in-use 能力，
> 不是看 shell / root 身份。ROOT 免不掉这个，删掉 FGS 后台点 `−/+` 会静默失效。

## 已知限制（如实说明）

- **前台服务通知无法彻底隐藏**：「关闭通知栏」只是把带 `−/+` 的自定义通知降级成一条极简常驻通知。Android 不允许 FGS 完全没有通知。
- **Shizuku 重启后失效**：无线调试启动的 Shizuku 会话在手机重启后需要重新启动。ROOT 通道不受此影响，开机后 `su` 仍可用。两种通道下 `appops` / `pm grant` 已生效的授权都不会因重启回滚。
- **ROOT 探测结果按进程缓存**：App 进程内只探测一次。若用户后来在 Magisk 里撤销了本 App 的 ROOT 授权，需杀掉进程重进（或重启 App）才会重新探测；下次点「发起授权」也会重新探测一次并覆盖缓存。
- **固定音量设备**：`AudioManager.isVolumeFixed()` 为真时流音量不可调，主页状态栏会提示。
- **厂商适配**：MIUI / HyperOS / ColorOS 对后台与悬浮窗有额外策略，个别机型需要手动把 App 设为「无限制」电池策略。
- **分发合规**：ROOT / Shizuku 提权 + 悬浮窗 + 常驻通知叠加，商店审核需要在隐私说明里写清用途；ROOT 应用的审核通常更严。
- **launcher 图标**：当前直接用方形 PNG 作 `android:icon`。正式上架建议补一套自适应图标（前景 / 背景两层），否则部分启动器裁切形状不统一。

## 用 GitHub Actions 编译

仓库根目录放两样东西：

```
.github/workflows/build.yml     ← 必须直接放这里，GitHub 只认这个路径
ShizukuVolumePanel.zip          ← 源码压缩包，里面套一层 ShizukuVolumePanel/
```

> ⚠️ zip 内部那份 `.github/workflows/build.yml` 只是留档。**GitHub 不会解压 zip 去读工作流**，
> 所以必须把单独那份 `build.yml` 提交到仓库根的 `.github/workflows/`，否则 Actions 不会触发。
> 网页端可用 Add file → Create new file，路径填 `.github/workflows/build.yml` 自动建目录。

流程：push 或手动 Run workflow → 解压 zip → 自动定位含 `settings.gradle.kts` 的目录 →
JDK 17 + Android SDK 35 + Gradle 8.9 → `assembleDebug` → 上传 artifact。
在 Actions 运行页底部下载 `ShizukuVolumePanel-debug.apk`（保留 30 天）。

因为工程不带 `gradle-wrapper.jar`（二进制文件），脚本显式下载 Gradle 8.9 并直接用 `gradle` 命令，
AGP 8.7.3 对应 Gradle 8.9。Debug 构建不需要签名配置。

> **CI 修复记录（2026-11-04）**：`android-actions/setup-android@v3` 默认会装
> `tools platform-tools`，但 legacy `tools` 包已被 Google 下架，新版 cmdline-tools 下
> `sdkmanager tools` 报 `Failed to find package 'tools'` 并以 exit code 1 结束，
> 任务在编译开始前就挂。脚本已显式声明 `packages: platform-tools` 跳过该包；
> 同时把 `gradle/actions/setup-gradle` 换成显式安装 Gradle 8.9，避免 wrapper 依赖问题。
> 日志里 `setup-java@v4 is deprecated`、`Node.js 20 is deprecated` 都只是警告，不影响构建。

> **源码修复记录（2026-11-04，第 2 次）**：脚本修好后进入 `compileDebugKotlin`，报两处编译错误：
> 1. `FLAG_LAYOUT_NO_LIMIT` 是 `@hide` 常量，public SDK 里不存在 → 已移除，`TYPE_APPLICATION_OVERLAY` 用 x/y 定位不受影响；
> 2. Shizuku API 13 把 `Shizuku.newProcess(...)` 改成 `private`（官方计划 API 14 移除）→ 改为反射调用同名 static 方法，并反射调用 `ShizukuRemoteProcess.waitFor()`。反射的是随 APK 打包的库类而非 framework 隐藏 API，不受 Android 9+ 隐藏 API 限制；反射失败会回退到「跳系统设置页手动授权」。
> 同时新增 `app/proguard-rules.pro`，防止 release 混淆后反射找不到方法名。

## 目录

```
app/src/main/
├── AndroidManifest.xml
├── java/com/android/volume/
│   ├── MainActivity.kt          三个按钮；发起授权先探测 ROOT 再切 Shizuku
│   ├── PrivilegeManager.kt      双通道统一入口：ROOT > Shizuku、缓存探测、grantAll
│   ├── RootHelper.kt            ROOT 探测（su -c id）与 su 命令执行
│   ├── ShizukuHelper.kt         Shizuku 连接、授权弹窗、shell 命令执行（纯后端）
│   ├── PanelService.kt          通知栏、悬浮浮标、面板浮层
│   ├── VolumePanelView.kt       自定义滑块绘制
│   ├── VolumeController.kt      媒体音量读写
│   └── Prefs.kt                 两个开关状态
├── res/drawable-nodpi/app_icon.png            方形原图（仅 android:icon）
├── res/drawable-nodpi/app_icon_round.png      圆形裁切版（主页 / 浮标 / 通知 iv_icon / roundIcon）
├── res/drawable/ic_stat_volume.png            同图形状的纯白剪影（通知 smallIcon）
├── res/drawable/bg_step_btn.xml              通知 −/+ 圆形按钮底
├── res/drawable/*.xml                        按钮、玻璃卡片等
├── res/layout/                  主页、面板、通知自定义布局
└── res/values/                  颜色、字符串、主题
app/proguard-rules.pro           release 混淆保留（反射 Shizuku.newProcess 用）
.github/workflows/build.yml      CI 脚本留档（GitHub 只认仓库根的那份）
```
