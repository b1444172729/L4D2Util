package com.example.volumepanel

import android.content.Context
import android.media.AudioManager

/**
 * 媒体音量的读写入口。
 *
 * 为什么不需要无障碍、也不需要隐藏 API：
 *  - 面板是用户主动点击后弹出的可见窗口，属于前台交互；
 *  - PanelService 是「用户在主页点击按钮、App 处于前台时」启动的 mediaPlayback 类型前台服务，
 *    按 Android 14+ / 17 的音频访问生命周期规则可获得 while-in-use 能力，
 *    后台收到通知的 −/+ PendingIntent 时写 STREAM_MUSIC 不会被静默丢弃。
 *  - flags 传 0，不弹系统原生音量条，只更新我们自己的面板。
 */
object VolumeController {

    const val STREAM = AudioManager.STREAM_MUSIC

    private fun audio(ctx: Context): AudioManager =
        ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    fun max(ctx: Context): Int = audio(ctx).getStreamMaxVolume(STREAM)

    fun current(ctx: Context): Int = audio(ctx).getStreamVolume(STREAM)

    fun isFixed(ctx: Context): Boolean = audio(ctx).isVolumeFixed

    /** 面板拖动时按 0..100 的百分比写入精确音量 */
    fun setByPercent(ctx: Context, percent: Int) {
        val m = max(ctx).coerceAtLeast(1)
        val index = (percent.coerceIn(0, 100) * m / 100f + 0.5f).toInt().coerceIn(0, m)
        audio(ctx).setStreamVolume(STREAM, index, 0)
    }

    /** 通知栏 −/+ 快捷步进 */
    fun step(ctx: Context, up: Boolean) {
        val dir = if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER
        audio(ctx).adjustStreamVolume(STREAM, dir, 0)
    }

    fun percent(ctx: Context): Int {
        val m = max(ctx).coerceAtLeast(1)
        return (current(ctx) * 100f / m + 0.5f).toInt().coerceIn(0, 100)
    }
}
