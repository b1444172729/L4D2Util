package com.example.volumepanel

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuBinderWrapper
import rikka.shizuku.SystemServiceHelper

/**
 * Shizuku 能力封装。
 *
 * 本 App 用 Shizuku 做三件事：
 *  1. 第一个按钮：未授权时弹出 Shizuku 授权弹窗；
 *  2. 授权成功后，以 shell 身份 appops 授予悬浮窗权限、pm grant 通知权限，免去手动设置；
 *  3. 预留 audio 服务 Binder，后续可接隐藏 API（例如按 App 独立音量）。
 *
 * 注意：Shizuku 给的是「调用身份」，不是「全局输入拦截」，
 * 所以本方案完全不依赖无障碍服务——面板靠「点击通知/悬浮图标」触发。
 */
object ShizukuHelper {

    private const val TAG = "ShizukuHelper"
    const val REQ_CODE = 1001

    /** Shizuku 服务进程是否已启动并活着 */
    fun isRunning(): Boolean = try {
        Shizuku.getBinder()?.pingBinder() == true
    } catch (t: Throwable) {
        false
    }

    /** 本 App 是否已拿到 Shizuku 授权 */
    fun isGranted(): Boolean = try {
        isRunning() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (t: Throwable) {
        false
    }

    /**
     * 未授权就发起授权弹窗；已授权返回 true。
     * 弹窗结果由 Shizuku.addRequestPermissionResultListener 回调。
     */
    fun ensureGranted(): Boolean {
        if (!isRunning()) return false
        if (isGranted()) return true
        Shizuku.requestPermission(REQ_CODE)
        return false
    }

    /** 以 shell(uid 2000) 或 root 身份执行命令 */
    fun exec(command: Array<String>): Boolean {
        if (!isGranted()) return false
        return try {
            val p = Shizuku.newProcess(command, null, null) ?: return false
            p.waitFor()
            true
        } catch (t: Throwable) {
            Log.w(TAG, "exec failed: ${command.joinToString(" ")}", t)
            false
        }
    }

    /** 自动开启「显示在其他应用上层」，第三个按钮不再跳系统设置页 */
    fun grantOverlay(context: Context): Boolean {
        val pkg = context.packageName
        return exec(arrayOf("sh", "-c", "appops set $pkg SYSTEM_ALERT_WINDOW allow"))
    }

    /** 自动授予 Android 13+ 的通知运行时权限 */
    fun grantNotifications(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < 33) return true
        val pkg = context.packageName
        return exec(arrayOf("sh", "-c", "pm grant $pkg android.permission.POST_NOTIFICATIONS"))
    }

    /**
     * 预留：拿到 audio 系统服务的 Binder 包装。
     * 后续若要做「按 App 独立音量」，可在此 Binder 上以 shell 身份调用 IAudioService 的隐藏方法。
     * 本版本不调用，避免引入隐藏 API 编译依赖。
     */
    fun audioBinder(): ShizukuBinderWrapper? = try {
        val raw = SystemServiceHelper.getSystemService("audio") ?: return null
        ShizukuBinderWrapper(raw)
    } catch (t: Throwable) {
        null
    }
}
