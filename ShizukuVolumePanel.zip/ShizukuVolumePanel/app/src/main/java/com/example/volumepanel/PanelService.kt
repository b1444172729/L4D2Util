package com.example.volumepanel

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.PixelFormat
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.RemoteViews
import android.widget.Toast
import androidx.core.app.NotificationCompat
import kotlin.math.abs

/**
 * 常驻服务，负责三件事：
 *  1. 通知栏：一条带 −/+ 快捷按钮的常驻通知，点击也能打开面板；
 *  2. 悬浮窗：一个可拖动的 APP 图标浮标，点击在屏幕中间弹出面板；
 *  3. 面板：通知栏与悬浮窗共用 layout_panel.xml + VolumePanelView，样式完全一致。
 *
 * 全程不注册任何 AccessibilityService：触发方式是「用户点击」，不是「拦截按键」。
 */
class PanelService : Service() {

    companion object {
        const val ACTION_SYNC = "com.example.volumepanel.SYNC"
        const val ACTION_MINUS = "com.example.volumepanel.MINUS"
        const val ACTION_PLUS = "com.example.volumepanel.PLUS"
        const val ACTION_PANEL = "com.example.volumepanel.PANEL"

        private const val CHANNEL_ID = "volume_panel"
        private const val NOTI_ID = 1001

        /** 从任意组件同步开关状态 */
        fun sync(context: Context) {
            val i = Intent(context, PanelService::class.java).setAction(ACTION_SYNC)
            androidx.core.content.ContextCompat.startForegroundService(context, i)
        }
    }

    private lateinit var wm: WindowManager
    private var iconBmp: Bitmap? = null

    private var bubbleView: ImageView? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var panelRoot: View? = null
    private var panelView: VolumePanelView? = null

    private val notiHandler = Handler(Looper.getMainLooper())
    private val notiRefresh = Runnable {
        getSystemService(NotificationManager::class.java)
            .notify(NOTI_ID, buildNotification())
    }

    private fun dp(v: Float) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createChannel()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // 前台服务契约：startForegroundService 之后必须先 startForeground
        startForeground(NOTI_ID, buildNotification())

        when (intent?.action) {
            ACTION_MINUS -> {
                VolumeController.step(this, false)
                refreshAll()
            }
            ACTION_PLUS -> {
                VolumeController.step(this, true)
                refreshAll()
            }
            ACTION_PANEL -> showPanel()
        }
        applyState()
        return START_NOT_STICKY
    }

    // ---------------------------------------------------------------- 状态同步

    private fun applyState() {
        if (!Prefs.anyEnabled(this)) {
            hidePanel()
            removeBubble()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return
        }

        if (Prefs.overlay(this)) {
            if (ensureOverlayPermission()) {
                addBubble()
            } else {
                // 权限没拿到就先把开关回退，避免反复弹设置页
                Prefs.setOverlay(this, false)
                removeBubble()
            }
        } else {
            removeBubble()
        }

        refreshAll()
    }

    /** 面板即时同步，通知合并刷新（拖动滑块时不高频重建通知） */
    private fun refreshAll() {
        notiHandler.removeCallbacks(notiRefresh)
        notiHandler.postDelayed(notiRefresh, 80L)
        panelView?.setProgress(VolumeController.percent(this))
    }

    // ---------------------------------------------------------------- 通知栏

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.app_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "常驻音量快捷控制"
                setSound(null, null)
                enableVibration(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun iconBitmap(): Bitmap = iconBmp
        ?: BitmapFactory.decodeResource(resources, R.drawable.app_icon).also { iconBmp = it }

    private fun pi(action: String, requestCode: Int): PendingIntent {
        val i = Intent(this, PanelService::class.java).setAction(action)
        return PendingIntent.getService(
            this, requestCode, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    /**
     * 两个状态：
     *  - 「启用通知栏」开：带 −/+ 与图标的自定义通知（快捷加减音量）
     *  - 关：降级成一条极简常驻通知。
     *    Android 的前台服务必须有通知且无法彻底隐藏，这是平台限制。
     */
    private fun buildNotification(): Notification {
        val percent = VolumeController.percent(this)
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_volume)
            .setLargeIcon(iconBitmap())
            .setContentTitle(getString(R.string.app_name))
            .setContentText("媒体音量 $percent% · 点击打开面板")
            .setContentIntent(pi(ACTION_PANEL, 4))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)

        if (Prefs.notification(this)) {
            val rv = RemoteViews(packageName, R.layout.notification_small).apply {
                setImageViewBitmap(R.id.iv_icon, iconBitmap())
                setTextViewText(R.id.tv_title, getString(R.string.app_name))
                setTextViewText(R.id.tv_volume, "媒体音量 $percent% · 点开面板")
                setOnClickPendingIntent(R.id.tv_volume, pi(ACTION_PANEL, 2))
                setOnClickPendingIntent(R.id.btn_minus, pi(ACTION_MINUS, 1))
                setOnClickPendingIntent(R.id.btn_plus, pi(ACTION_PLUS, 3))
            }
            builder
                .setStyle(NotificationCompat.DecoratedCustomViewStyle())
                .setCustomContentView(rv)
                .setCustomBigContentView(rv)
        }
        return builder.build()
    }

    // ---------------------------------------------------------------- 悬浮权限

    /** 优先靠 Shizuku 的 appops 静默授予；不行再引导用户去系统设置 */
    private fun ensureOverlayPermission(): Boolean {
        if (Settings.canDrawOverlays(this)) return true
        if (ShizukuHelper.isGranted() && ShizukuHelper.grantOverlay(this)) {
            if (Settings.canDrawOverlays(this)) return true
        }
        val i = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
        Toast.makeText(this, "请开启「显示在其他应用上层」", Toast.LENGTH_LONG).show()
        return false
    }

    // ---------------------------------------------------------------- 悬浮图标

    private fun addBubble() {
        if (bubbleView != null) return

        val iv = ImageView(this).apply {
            setImageResource(R.drawable.app_icon)
            background = getDrawable(R.drawable.bg_bubble)
            val pad = dp(5f)
            setPadding(pad, pad, pad, pad)
            elevation = dp(8f).toFloat()
            contentDescription = getString(R.string.app_name)
        }

        val lp = WindowManager.LayoutParams(
            dp(56f), dp(56f),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMIT,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(24f)
            y = dp(220f)
        }

        attachBubbleTouch(iv, lp)
        wm.addView(iv, lp)
        bubbleView = iv
        bubbleLp = lp
    }

    private fun attachBubbleTouch(iv: ImageView, lp: WindowManager.LayoutParams) {
        var initX = 0
        var initY = 0
        var touchX = 0f
        var touchY = 0f
        var downTime = 0L

        @Suppress("ClickableViewAccessibility")
        iv.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    initX = lp.x
                    initY = lp.y
                    touchX = event.rawX
                    touchY = event.rawY
                    downTime = System.currentTimeMillis()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = initX + (event.rawX - touchX).toInt()
                    lp.y = initY + (event.rawY - touchY).toInt()
                    wm.updateViewLayout(v, lp)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val threshold = dp(8f).toFloat()
                    val moved = abs(event.rawX - touchX) > threshold ||
                            abs(event.rawY - touchY) > threshold
                    if (!moved && System.currentTimeMillis() - downTime < 300) {
                        v.performClick()
                        showPanel()
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun removeBubble() {
        bubbleView?.let {
            runCatching { wm.removeView(it) }
        }
        bubbleView = null
        bubbleLp = null
    }

    // ---------------------------------------------------------------- 音量面板

    private fun showPanel() {
        if (!ensureOverlayPermission()) return
        if (panelRoot != null) {
            hidePanel()
            return
        }

        val root = LayoutInflater.from(this).inflate(R.layout.layout_panel, null)
        val vv = root.findViewById<VolumePanelView>(R.id.volume_view)

        vv.setProgress(VolumeController.percent(this))
        vv.onProgressChanged = { p ->
            VolumeController.setByPercent(this, p)
            refreshAll()
        }

        // 点卡片本身不关闭，点遮罩关闭
        root.findViewById<View>(R.id.panel_card).setOnClickListener { }
        root.setOnClickListener { hidePanel() }

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }

        wm.addView(root, lp)
        panelRoot = root
        panelView = vv
    }

    private fun hidePanel() {
        panelRoot?.let { runCatching { wm.removeView(it) } }
        panelRoot = null
        panelView = null
    }

    override fun onDestroy() {
        notiHandler.removeCallbacks(notiRefresh)
        hidePanel()
        removeBubble()
        super.onDestroy()
    }
}
