package com.android.volume

import android.content.Context
import android.os.Build

/**
 * 双通道提权统一入口。
 *
 * 优先级：**ROOT > Shizuku**。
 * 用户点「发起授权」时先异步探测 ROOT；探测结果缓存在这里，
 * 之后所有提权命令都走当前通道，不再重复探测。
 *
 * - ROOT 可用：走 `su -c`，不需要 Shizuku，也不弹 Shizuku 授权框；
 * - ROOT 不可用且 Shizuku 已授权：走 Shizuku 的 shell 身份；
 * - 两者都没有：返回 false，调用方回退到「跳系统设置页 / 系统权限框」。
 *
 * 注意：所有 exec / grantAll 都必须在子线程调用。
 */
object PrivilegeManager {

    enum class Mode { ROOT, SHIZUKU, NONE }

    const val REQ_CODE = 1001

    /** null = 还没探测过；true/false = 探测结果。只在子线程写。 */
    @Volatile
    private var rootAvailable: Boolean? = null

    /** 已探测过 ROOT 吗（用于状态文案区分） */
    fun rootProbed(): Boolean = rootAvailable != null

    /** 子线程：探测 ROOT 并缓存结果 */
    fun probeRoot(): Boolean {
        val ok = RootHelper.probe()
        rootAvailable = ok
        return ok
    }

    /** 当前生效通道。ROOT 优先。 */
    fun mode(): Mode = when {
        rootAvailable == true -> Mode.ROOT
        ShizukuHelper.isGranted() -> Mode.SHIZUKU
        else -> Mode.NONE
    }

    fun isGranted(): Boolean = mode() != Mode.NONE

    /** Shizuku 服务是否在运行（仅 Shizuku 分支的状态展示用） */
    fun shizukuRunning(): Boolean = ShizukuHelper.isRunning()

    /**
     * 子线程：执行一行 shell 命令。
     * 如果还没探测过 ROOT 且当前没有可用通道，先补一次探测，
     * 这样即使用户没点过「发起授权」也能自动用上 ROOT。
     */
    fun exec(shellLine: String): Boolean {
        var m = mode()
        if (m == Mode.NONE && rootAvailable == null) {
            probeRoot()
            m = mode()
        }
        return when (m) {
            Mode.ROOT -> RootHelper.exec(shellLine)
            Mode.SHIZUKU -> ShizukuHelper.exec(arrayOf("sh", "-c", shellLine))
            Mode.NONE -> false
        }
    }

    /** 子线程：一次性把悬浮窗与通知权限都开掉 */
    fun grantAll(context: Context): Boolean {
        val pkg = context.packageName
        val overlay = exec("appops set $pkg SYSTEM_ALERT_WINDOW allow")
        val noti = if (Build.VERSION.SDK_INT >= 33) {
            exec("pm grant $pkg android.permission.POST_NOTIFICATIONS")
        } else {
            true
        }
        return overlay || noti
    }
}
