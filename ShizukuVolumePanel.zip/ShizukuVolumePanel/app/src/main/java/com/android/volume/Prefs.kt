package com.android.volume

import android.content.Context

/** 两个开关 + 悬浮窗透明度的持久化状态 */
object Prefs {
    private const val FILE = "volume_panel_settings"
    private const val K_NOTIFICATION = "notification_enabled"
    private const val K_OVERLAY = "overlay_enabled"
    private const val K_OPACITY = "overlay_opacity"

    /** 100 = 完全不透明；0 = 全透明。默认 100%。 */
    const val DEFAULT_OPACITY = 100

    private fun sp(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun notification(c: Context) = sp(c).getBoolean(K_NOTIFICATION, false)
    fun overlay(c: Context) = sp(c).getBoolean(K_OVERLAY, false)

    /** 0..100，读取时也做一次夹紧，防止旧数据或异常值越界 */
    fun opacity(c: Context) =
        sp(c).getInt(K_OPACITY, DEFAULT_OPACITY).coerceIn(0, 100)

    fun setNotification(c: Context, v: Boolean) = sp(c).edit().putBoolean(K_NOTIFICATION, v).apply()
    fun setOverlay(c: Context, v: Boolean) = sp(c).edit().putBoolean(K_OVERLAY, v).apply()
    fun setOpacity(c: Context, v: Int) =
        sp(c).edit().putInt(K_OPACITY, v.coerceIn(0, 100)).apply()

    fun anyEnabled(c: Context) = notification(c) || overlay(c)
}
