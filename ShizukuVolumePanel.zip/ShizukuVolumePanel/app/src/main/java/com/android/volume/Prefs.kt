package com.android.volume

import android.content.Context

/** 两个开关的持久化状态 */
object Prefs {
    private const val FILE = "volume_panel_settings"
    private const val K_NOTIFICATION = "notification_enabled"
    private const val K_OVERLAY = "overlay_enabled"

    private fun sp(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun notification(c: Context) = sp(c).getBoolean(K_NOTIFICATION, false)
    fun overlay(c: Context) = sp(c).getBoolean(K_OVERLAY, false)

    fun setNotification(c: Context, v: Boolean) = sp(c).edit().putBoolean(K_NOTIFICATION, v).apply()
    fun setOverlay(c: Context, v: Boolean) = sp(c).edit().putBoolean(K_OVERLAY, v).apply()

    fun anyEnabled(c: Context) = notification(c) || overlay(c)
}
