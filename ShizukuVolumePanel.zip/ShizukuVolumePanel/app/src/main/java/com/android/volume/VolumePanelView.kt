package com.android.volume

import android.content.Context
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.max

/**
 * 复刻效果示意图的音量滑块：
 *  - 左侧：蓝紫渐变描边的喇叭 + 两道声波（与 APP 图标同款造型）
 *  - 轨道：深青绿已填充段 + 淡蓝发光，中灰未填充段，两端全圆角
 *  - 滑块：白色大圆环 + 青绿圆芯 + 柔和投影
 *
 * 通知栏与悬浮窗弹出的面板共用这个 View，所以样式必然一致。
 */
class VolumePanelView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    /** 拖动回调，参数为 0..100 的百分比 */
    var onProgressChanged: ((Int) -> Unit)? = null

    private var progress: Int = 0

    private val d = resources.displayMetrics.density
    private fun dp(v: Float) = v * d

    private val emptyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = context.getColor(R.color.track_empty)
        style = Paint.Style.FILL
    }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = context.getColor(R.color.track_glow)
        alpha = 150
        style = Paint.Style.FILL
        maskFilter = BlurMaskFilter(dp(9f), BlurMaskFilter.Blur.NORMAL)
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val thumbShadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
        setShadowLayer(dp(5f), 0f, dp(2f), 0x33000000)
    }
    private val thumbOuterPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }
    private val thumbInnerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = context.getColor(R.color.thumb_core)
        style = Paint.Style.FILL
    }
    private val iconStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(3.2f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    private val trackRect = RectF()
    private val fillRect = RectF()
    private val glowRect = RectF()

    private var trackLeft = 0f
    private var trackRight = 0f
    private var centerY = 0f
    private var trackH = 0f
    private var iconLeft = 0f
    private var iconTop = 0f
    private var iconSize = 0f

    // 滑块缩小，并且圆心始终限制在轨道内「两端各留一个半径」，
    // 否则 100% 时圆会超出 View 右边界被父布局裁掉一小半。
    private val outerR = dp(14f)
    private val innerR = dp(7.5f)
    private var thumbMin = 0f
    private var thumbMax = 0f

    /**
     * 是否绘制左侧蓝渐变喇叭。
     * 音量面板用 true；透明度设置面板左侧要放「100%」文字，用 false，
     * 这样轨道从 View 左边缘开始，但填充色、发光、滑块完全复用同一套绘制代码。
     */
    var showSpeaker: Boolean = true
        set(value) {
            if (field == value) return
            field = value
            if (width > 0 && height > 0) recomputeTrack(width, height)
            invalidate()
        }

    init {
        // BlurMaskFilter 需要软件层才能稳定生效
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    fun setProgress(p: Int) {
        val v = p.coerceIn(0, 100)
        if (v != progress) {
            progress = v
            invalidate()
        }
    }

    fun getProgress() = progress

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        recomputeTrack(w, h)
    }

    private fun recomputeTrack(w: Int, h: Int) {
        centerY = h / 2f
        trackH = dp(10f)
        if (showSpeaker) {
            iconSize = dp(46f)
            iconLeft = paddingLeft + dp(2f)
            iconTop = (h - iconSize) / 2f
            trackLeft = iconLeft + iconSize + dp(22f)
        } else {
            iconSize = 0f
            iconLeft = paddingLeft.toFloat()
            iconTop = 0f
            trackLeft = paddingLeft + dp(2f)
        }
        trackRight = (w - paddingRight - dp(6f)).coerceAtLeast(trackLeft + trackH)
        thumbMin = trackLeft + outerR
        thumbMax = (trackRight - outerR).coerceAtLeast(thumbMin)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        // 1. 灰色未填充轨道
        trackRect.set(trackLeft, centerY - trackH / 2f, trackRight, centerY + trackH / 2f)
        val radius = trackH / 2f
        canvas.drawRoundRect(trackRect, radius, radius, emptyPaint)

        // 2. 已填充段 + 发光
        val thumbX = thumbMin + (thumbMax - thumbMin) * progress / 100f
        // 100% 时让青绿色铺到轨道末端，避免内缩后右端留一截灰
        val fillRight = if (progress >= 100) {
            trackRight
        } else {
            thumbX.coerceIn(trackLeft + trackH, trackRight)
        }
        fillRect.set(trackLeft, trackRect.top, fillRight, trackRect.bottom)
        glowRect.set(
            trackLeft - dp(3f), trackRect.top - dp(4f),
            fillRight + dp(3f), trackRect.bottom + dp(4f)
        )
        canvas.drawRoundRect(glowRect, radius + dp(4f), radius + dp(4f), glowPaint)

        fillPaint.shader = LinearGradient(
            trackLeft, 0f, max(fillRight, trackLeft + 1f), 0f,
            context.getColor(R.color.track_fill_start),
            context.getColor(R.color.track_fill_end),
            Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(fillRect, radius, radius, fillPaint)

        // 3. 滑块：白环 + 青绿芯
        canvas.drawCircle(thumbX, centerY, outerR, thumbShadowPaint)
        canvas.drawCircle(thumbX, centerY, outerR, thumbOuterPaint)
        canvas.drawCircle(thumbX, centerY, innerR, thumbInnerPaint)

        // 4. 左侧蓝渐变喇叭图标（透明度面板不画，左边留给百分比文字）
        if (showSpeaker) {
            iconStroke.shader = LinearGradient(
                iconLeft, iconTop, iconLeft + iconSize, iconTop + iconSize,
                context.getColor(R.color.brand_blue),
                context.getColor(R.color.brand_purple),
                Shader.TileMode.CLAMP
            )
            drawSpeaker(canvas)
        }
    }

    private fun drawSpeaker(canvas: Canvas) {
        fun x(v: Float) = iconLeft + v * iconSize
        fun y(v: Float) = iconTop + v * iconSize

        val body = Path().apply {
            moveTo(x(0.06f), y(0.36f))
            lineTo(x(0.28f), y(0.36f))
            lineTo(x(0.52f), y(0.14f))
            lineTo(x(0.52f), y(0.86f))
            lineTo(x(0.28f), y(0.64f))
            lineTo(x(0.06f), y(0.64f))
            close()
        }
        canvas.drawPath(body, iconStroke)

        val arc1 = RectF(x(0.55f), y(0.30f), x(0.84f), y(0.70f))
        canvas.drawArc(arc1, -68f, 136f, false, iconStroke)
        val arc2 = RectF(x(0.58f), y(0.14f), x(1.00f), y(0.86f))
        canvas.drawArc(arc2, -68f, 136f, false, iconStroke)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN,
            MotionEvent.ACTION_MOVE -> {
                updateFromX(event.x)
                return true
            }
            MotionEvent.ACTION_UP,
            MotionEvent.ACTION_CANCEL -> {
                updateFromX(event.x)
                performClick()
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    private fun updateFromX(x: Float) {
        val span = (thumbMax - thumbMin).coerceAtLeast(1f)
        val p = ((x - thumbMin) / span * 100f + 0.5f).toInt().coerceIn(0, 100)
        if (p != progress) {
            progress = p
            invalidate()
            onProgressChanged?.invoke(p)
        }
    }
}
