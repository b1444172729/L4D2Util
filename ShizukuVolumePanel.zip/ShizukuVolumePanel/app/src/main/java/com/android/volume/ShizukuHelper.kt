package com.android.volume

import android.content.pm.PackageManager
import android.util.Log
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuBinderWrapper
import rikka.shizuku.SystemServiceHelper
import java.lang.reflect.Method

/**
 * 双通道里的 Shizuku 后端，只负责 Shizuku 自身的连接与授权，
 * 以及以 shell 身份执行命令。命令拼接与通道选择统一在 [PrivilegeManager]。
 *
 * 注意：Shizuku 给的是「调用身份」，不是「全局输入拦截」，
 * 所以本方案完全不依赖无障碍服务——面板靠「点击通知/悬浮图标」触发。
 */
object ShizukuHelper {

    private const val TAG = "ShizukuHelper"

    /** Shizuku 服务进程是否已启动并活着 */
    fun isRunning(): Boolean = try {
        Shizuku.getBinder()?.pingBinder() == true
    } catch (t: Throwable) {
        false
    }

    /** 本 App 是否已拿到 Shizuku 授权 */
    fun isGranted(): Boolean = try {
        isRunning() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (t: Throwable) {
        false
    }

    /**
     * 未授权就发起授权弹窗；已授权返回 true。
     * 弹窗结果由 Shizuku.addRequestPermissionResultListener 回调。
     */
    fun ensureGranted(): Boolean {
        if (!isRunning()) return false
        if (isGranted()) return true
        Shizuku.requestPermission(PrivilegeManager.REQ_CODE)
        return false
    }

    /**
     * Shizuku API 13 起把 Shizuku.newProcess(...) 改成 private（官方计划 14 移除），
     * 直接调用会编译报 "it is private in 'rikka/shizuku/Shizuku'"。
     * 这里用反射调用同一个 static 方法：反射的是随 APK 打包的库类，不是 framework 隐藏 API，
     * 不受 Android 9+ 隐藏 API 限制影响。反射失败时返回 false，
     * 调用方已有「跳系统设置页手动授权」的兜底。
     */
    private val newProcessMethod: Method? by lazy {
        runCatching {
            Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            ).apply { isAccessible = true }
        }.getOrElse {
            Log.w(TAG, "Shizuku.newProcess 反射失败，将回退到手动授权", it)
            null
        }
    }

    /** 以 shell(uid 2000) 或 root 身份执行命令 */
    fun exec(command: Array<String>): Boolean {
        if (!isGranted()) return false
        return try {
            val m = newProcessMethod ?: return false
            val args: Array<Any?> = arrayOf(command, null, null)
            val proc = m.invoke(null, *args) ?: return false
            awaitProcess(proc)
            true
        } catch (t: Throwable) {
            Log.w(TAG, "exec failed: ${command.joinToString(" ")}", t)
            false
        }
    }

    /** ShizukuRemoteProcess 不是 java.lang.Process 子类，waitFor() 也用反射调用 */
    private fun awaitProcess(proc: Any) {
        val c = proc.javaClass
        val m = runCatching { c.getMethod("waitFor") }
            .getOrElse { runCatching { c.getDeclaredMethod("waitFor") }.getOrNull() }
            ?: return
        runCatching {
            m.isAccessible = true
            m.invoke(proc)
        }
    }

    /**
     * 预留：拿到 audio 系统服务的 Binder 包装。
     * 后续若要做「按 App 独立音量」，可在此 Binder 上以 shell 身份调用 IAudioService 的隐藏方法。
     * 本版本不调用，避免引入隐藏 API 编译依赖。
     */
    fun audioBinder(): ShizukuBinderWrapper? = try {
        val raw = SystemServiceHelper.getSystemService("audio") ?: return null
        ShizukuBinderWrapper(raw)
    } catch (t: Throwable) {
        null
    }
}
