package com.android.volume

import android.util.Log
import java.util.concurrent.TimeUnit

/**
 * ROOT 通道：用 su 执行命令。
 *
 * 所有方法都必须放在子线程调用（会 waitFor），不要在主线程跑，否则 Magisk / KernelSU
 * 授权弹窗等待期间会 ANR。探测用 `su -c id` 看是否真的拿到 uid=0，
 * 而不是只判断 su 文件是否存在。
 */
object RootHelper {

    private const val TAG = "RootHelper"
    private const val TIMEOUT_SEC = 8L

    /** 探测 ROOT 是否真正可用。授权框由 Magisk / KernelSU / APatch 自己弹。 */
    fun probe(): Boolean = try {
        val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
        val finished = p.waitFor(TIMEOUT_SEC, TimeUnit.SECONDS)
        if (!finished) {
            p.destroyForcibly()
            false
        } else {
            val out = runCatching { p.inputStream.bufferedReader().readText() }.getOrDefault("")
            p.exitValue() == 0 && out.contains("uid=0")
        }
    } catch (t: Throwable) {
        Log.w(TAG, "ROOT 探测失败", t)
        false
    }

    /** 以 root 身份执行一行 shell 命令，返回是否退出码为 0 */
    fun exec(shellLine: String): Boolean = try {
        val p = Runtime.getRuntime().exec(arrayOf("su", "-c", shellLine))
        val finished = p.waitFor(TIMEOUT_SEC, TimeUnit.SECONDS)
        if (!finished) {
            p.destroyForcibly()
            false
        } else {
            p.exitValue() == 0
        }
    } catch (t: Throwable) {
        Log.w(TAG, "su 执行失败: $shellLine", t)
        false
    }
}
