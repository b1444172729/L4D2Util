package com.android.volume

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import rikka.shizuku.Shizuku

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var btnAuthorize: Button
    private lateinit var btnNotification: Button
    private lateinit var btnOverlay: Button

    /** Shizuku 服务连上/断开时刷新状态（ROOT 通道下它只是不触发而已） */
    private val binderListener = Shizuku.OnBinderReceivedListener {
        runOnUiThread { refresh() }
    }

    /** 仅走 Shizuku 分支时会收到这个回调 */
    private val permissionListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == PrivilegeManager.REQ_CODE &&
                grantResult == PackageManager.PERMISSION_GRANTED
            ) {
                grantAsync()
            } else {
                runOnUiThread { refresh() }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tv_status)
        btnAuthorize = findViewById(R.id.btn_authorize)
        btnNotification = findViewById(R.id.btn_notification)
        btnOverlay = findViewById(R.id.btn_overlay)

        Shizuku.addBinderReceivedListenerSticky(binderListener)
        Shizuku.addRequestPermissionResultListener(permissionListener)

        // ① 发起授权：先异步探测 ROOT，可用走 ROOT，不可用再切 Shizuku
        btnAuthorize.setOnClickListener {
            Toast.makeText(this, R.string.priv_probe_toast, Toast.LENGTH_SHORT).show()
            Thread {
                val root = PrivilegeManager.probeRoot()
                runOnUiThread {
                    if (root) {
                        Toast.makeText(this, R.string.priv_root_toast, Toast.LENGTH_SHORT).show()
                        grantAsync()
                    } else {
                        Toast.makeText(this, R.string.priv_fallback_toast, Toast.LENGTH_SHORT).show()
                        when {
                            !ShizukuHelper.isRunning() -> {
                                Toast.makeText(
                                    this, R.string.priv_shizuku_not_running, Toast.LENGTH_LONG
                                ).show()
                                launchShizuku()
                            }
                            ShizukuHelper.isGranted() -> grantAsync()
                            else -> ShizukuHelper.ensureGranted()
                        }
                    }
                    refresh()
                }
            }.start()
        }

        // ② 启用通知栏：开关带 −/+ 的常驻通知
        btnNotification.setOnClickListener {
            val next = !Prefs.notification(this)
            if (next) ensureNotificationPermission()
            Prefs.setNotification(this, next)
            PanelService.sync(this)
            refresh()
        }

        // ③ 启用悬浮窗：开关可点击的圆形图标浮标
        btnOverlay.setOnClickListener {
            val next = !Prefs.overlay(this)
            if (next) ensureOverlayPermissionHere()
            Prefs.setOverlay(this, next)
            PanelService.sync(this)
            refresh()
        }

        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onDestroy() {
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        super.onDestroy()
    }

    /** 子线程跑提权命令，避免 su / 反射调用阻塞主线程造成 ANR */
    private fun grantAsync() {
        Thread {
            val ok = PrivilegeManager.grantAll(this@MainActivity)
            runOnUiThread {
                if (ok) {
                    Toast.makeText(this, R.string.priv_granted_toast, Toast.LENGTH_SHORT).show()
                }
                refresh()
            }
        }.start()
    }

    private fun refresh() {
        tvStatus.text = when (PrivilegeManager.mode()) {
            PrivilegeManager.Mode.ROOT -> getString(R.string.priv_root_ready)
            PrivilegeManager.Mode.SHIZUKU -> getString(R.string.priv_shizuku_ready)
            PrivilegeManager.Mode.NONE -> when {
                !PrivilegeManager.shizukuRunning() && !PrivilegeManager.rootProbed() ->
                    getString(R.string.priv_none)
                !PrivilegeManager.shizukuRunning() ->
                    getString(R.string.priv_shizuku_not_running)
                else -> getString(R.string.priv_shizuku_not_granted)
            }
        }
        if (VolumeController.isFixed(this)) {
            tvStatus.append(" · 该设备为固定音量，流音量不可调")
        }

        val notiOn = Prefs.notification(this)
        btnNotification.text = getString(
            if (notiOn) R.string.btn_notification_off else R.string.btn_notification_on
        )
        btnNotification.background = getDrawable(
            if (notiOn) R.drawable.bg_button else R.drawable.bg_button_off
        )
        btnNotification.setTextColor(
            getColor(if (notiOn) R.color.white else R.color.text_main)
        )

        val overlayOn = Prefs.overlay(this)
        btnOverlay.text = getString(
            if (overlayOn) R.string.btn_overlay_off else R.string.btn_overlay_on
        )
        btnOverlay.background = getDrawable(
            if (overlayOn) R.drawable.bg_button else R.drawable.bg_button_off
        )
        btnOverlay.setTextColor(
            getColor(if (overlayOn) R.color.white else R.color.text_main)
        )
    }

    private fun ensureNotificationPermission() {
        if (Build.VERSION.SDK_INT < 33) return
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED
        ) return
        // 后台走当前通道补权限，仍拿不到再弹系统权限框
        Thread {
            PrivilegeManager.grantAll(this@MainActivity)
            runOnUiThread {
                if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) !=
                    PackageManager.PERMISSION_GRANTED
                ) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2001)
                }
                refresh()
            }
        }.start()
    }

    private fun ensureOverlayPermissionHere() {
        if (Settings.canDrawOverlays(this)) return
        Thread {
            PrivilegeManager.grantAll(this@MainActivity)
            runOnUiThread {
                if (!Settings.canDrawOverlays(this)) {
                    startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")
                        )
                    )
                    Toast.makeText(this, "请开启「显示在其他应用上层」", Toast.LENGTH_LONG).show()
                }
                refresh()
            }
        }.start()
    }

    private fun launchShizuku() {
        val i = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
        if (i != null) {
            startActivity(i)
        } else {
            Toast.makeText(this, "请先安装 Shizuku 并启动服务", Toast.LENGTH_LONG).show()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refresh()
    }
}
