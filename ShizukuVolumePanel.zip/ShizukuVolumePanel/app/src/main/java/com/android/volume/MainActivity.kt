package com.android.volume

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import rikka.shizuku.Shizuku

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var btnAuthorize: Button
    private lateinit var btnNotification: Button
    private lateinit var btnOverlay: Button

    private val binderListener = Shizuku.OnBinderReceivedListener {
        runOnUiThread { refresh() }
    }
    private val permissionListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == ShizukuHelper.REQ_CODE &&
                grantResult == PackageManager.PERMISSION_GRANTED
            ) {
                // 授权成功后立刻把悬浮窗与通知权限用 shell 身份开掉，用户不用再进设置页
                ShizukuHelper.grantOverlay(this@MainActivity)
                ShizukuHelper.grantNotifications(this@MainActivity)
                runOnUiThread {
                    Toast.makeText(this, "Shizuku 已授权，权限已自动配置", Toast.LENGTH_SHORT).show()
                    refresh()
                }
            } else {
                runOnUiThread { refresh() }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tv_status)
        btnAuthorize = findViewById(R.id.btn_authorize)
        btnNotification = findViewById(R.id.btn_notification)
        btnOverlay = findViewById(R.id.btn_overlay)

        Shizuku.addBinderReceivedListenerSticky(binderListener)
        Shizuku.addRequestPermissionResultListener(permissionListener)

        // ① 发起授权：没跑 Shizuku 就引导启动；没授权就弹 Shizuku 授权弹窗
        btnAuthorize.setOnClickListener {
            when {
                !ShizukuHelper.isRunning() -> {
                    Toast.makeText(this, R.string.shizuku_not_running, Toast.LENGTH_LONG).show()
                    launchShizuku()
                }
                ShizukuHelper.isGranted() -> {
                    Toast.makeText(this, R.string.shizuku_ready, Toast.LENGTH_SHORT).show()
                    // 顺手补一次权限，兼容用户撤销后重新点
                    ShizukuHelper.grantOverlay(this)
                    ShizukuHelper.grantNotifications(this)
                }
                else -> ShizukuHelper.ensureGranted()
            }
            refresh()
        }

        // ② 启用通知栏：开关带 −/+ 的常驻通知
        btnNotification.setOnClickListener {
            val next = !Prefs.notification(this)
            if (next) ensureNotificationPermission()
            Prefs.setNotification(this, next)
            PanelService.sync(this)
            refresh()
        }

        // ③ 启用悬浮窗：开关可点击的 APP 图标浮标
        btnOverlay.setOnClickListener {
            val next = !Prefs.overlay(this)
            if (next) ensureOverlayPermissionHere()
            Prefs.setOverlay(this, next)
            PanelService.sync(this)
            refresh()
        }

        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onDestroy() {
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        super.onDestroy()
    }

    private fun refresh() {
        tvStatus.text = when {
            !ShizukuHelper.isRunning() -> getString(R.string.shizuku_not_running)
            ShizukuHelper.isGranted() -> getString(R.string.shizuku_ready)
            else -> getString(R.string.shizuku_not_granted)
        }
        if (VolumeController.isFixed(this)) {
            tvStatus.append(" · 该设备为固定音量，流音量不可调")
        }

        val notiOn = Prefs.notification(this)
        btnNotification.text = getString(
            if (notiOn) R.string.btn_notification_off else R.string.btn_notification_on
        )
        btnNotification.background = getDrawable(
            if (notiOn) R.drawable.bg_button else R.drawable.bg_button_off
        )
        btnNotification.setTextColor(
            getColor(if (notiOn) R.color.white else R.color.text_main)
        )

        val overlayOn = Prefs.overlay(this)
        btnOverlay.text = getString(
            if (overlayOn) R.string.btn_overlay_off else R.string.btn_overlay_on
        )
        btnOverlay.background = getDrawable(
            if (overlayOn) R.drawable.bg_button else R.drawable.bg_button_off
        )
        btnOverlay.setTextColor(
            getColor(if (overlayOn) R.color.white else R.color.text_main)
        )
    }

    private fun ensureNotificationPermission() {
        if (Build.VERSION.SDK_INT < 33) return
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED
        ) return
        // 优先 Shizuku 静默授予，失败再走系统权限框
        if (ShizukuHelper.grantNotifications(this) &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED
        ) return
        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2001)
    }

    private fun ensureOverlayPermissionHere() {
        if (Settings.canDrawOverlays(this)) return
        if (ShizukuHelper.isGranted() && ShizukuHelper.grantOverlay(this) &&
            Settings.canDrawOverlays(this)
        ) return
        startActivity(
            Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
        )
        Toast.makeText(this, "请开启「显示在其他应用上层」", Toast.LENGTH_LONG).show()
    }

    private fun launchShizuku() {
        val i = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
        if (i != null) {
            startActivity(i)
        } else {
            Toast.makeText(this, "请先安装 Shizuku 并启动服务", Toast.LENGTH_LONG).show()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refresh()
    }
}
