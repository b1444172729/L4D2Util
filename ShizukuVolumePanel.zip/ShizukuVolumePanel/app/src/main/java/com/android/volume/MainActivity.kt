package com.android.volume

import android.Manifest
import android.app.Dialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import rikka.shizuku.Shizuku

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var btnAuthorize: Button
    private lateinit var btnNotification: Button
    private lateinit var btnOverlay: Button

    private var opacityDialog: Dialog? = null

    /** Shizuku 服务连上/断开时刷新状态（ROOT 通道下它只是不触发而已） */
    private val binderListener = Shizuku.OnBinderReceivedListener {
        runOnUiThread { refresh() }
    }

    /** 仅走 Shizuku 分支时会收到这个回调 */
    private val permissionListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == PrivilegeManager.REQ_CODE &&
                grantResult == PackageManager.PERMISSION_GRANTED
            ) {
                grantAsync()
            } else {
                runOnUiThread { refresh() }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tv_status)
        btnAuthorize = findViewById(R.id.btn_authorize)
        btnNotification = findViewById(R.id.btn_notification)
        btnOverlay = findViewById(R.id.btn_overlay)

        Shizuku.addBinderReceivedListenerSticky(binderListener)
        Shizuku.addRequestPermissionResultListener(permissionListener)

        // ① 发起授权：先异步探测 ROOT，可用走 ROOT，不可用再切 Shizuku
        btnAuthorize.setOnClickListener {
            Toast.makeText(this, R.string.priv_probe_toast, Toast.LENGTH_SHORT).show()
            Thread {
                val root = PrivilegeManager.probeRoot()
                runOnUiThread {
                    if (root) {
                        Toast.makeText(this, R.string.priv_root_toast, Toast.LENGTH_SHORT).show()
                        grantAsync()
                    } else {
                        Toast.makeText(this, R.string.priv_fallback_toast, Toast.LENGTH_SHORT).show()
                        when {
                            !ShizukuHelper.isRunning() -> {
                                Toast.makeText(
                                    this, R.string.priv_shizuku_not_running, Toast.LENGTH_LONG
                                ).show()
                                launchShizuku()
                            }
                            ShizukuHelper.isGranted() -> grantAsync()
                            else -> ShizukuHelper.ensureGranted()
                        }
                    }
                    refresh()
                }
            }.start()
        }

        // ② 启用通知栏：开关带 −/+ 的常驻通知
        btnNotification.setOnClickListener {
            val next = !Prefs.notification(this)
            if (next) ensureNotificationPermission()
            Prefs.setNotification(this, next)
            PanelService.sync(this)
            refresh()
        }

        // ③ 启用悬浮窗：开关可点击的圆形图标浮标
        btnOverlay.setOnClickListener {
            val next = !Prefs.overlay(this)
            if (next) ensureOverlayPermissionHere()
            Prefs.setOverlay(this, next)
            PanelService.sync(this)
            refresh()
        }

        // ④ 透明度设置：弹出全屏遮罩 + 玻璃卡片面板，拖动滑块实时改变浮标透明度
        // 布局里是 TextView（避免 Material3 把 Button 染成纯蓝底导致蓝字不可见）
        findViewById<TextView>(R.id.btn_opacity).setOnClickListener {
            showOpacityDialog()
        }

        refresh()
    }

    override fun onResume() {
        super.onResume()
        // 冷启动、从最近任务/设置页返回都会走 onResume，统一在这里按上次状态恢复
        restoreState()
        refresh()
    }

    /**
     * 按持久化状态自动恢复通知栏与悬浮窗。
     *
     * 状态本来就存在 SharedPreferences 里（所以重开后按钮仍显示「关闭通知栏」），
     * 但进程被划掉 / 强制停止 / 系统回收后，前台服务和 WindowManager 浮标都会消失，
     * 而 PanelService 是 START_NOT_STICKY，不会自行重建——于是出现「按钮显示开、实际什么都没有」。
     * 这里主动 sync 一次，让服务重新 startForeground 发通知 + addBubble 画浮标。
     *
     * 两个开关都关时不启动服务，避免为了一个全 false 的状态闪一条常驻通知。
     */
    private fun restoreState() {
        if (!Prefs.anyEnabled(this)) return
        PanelService.sync(this)
    }

    override fun onDestroy() {
        opacityDialog?.dismiss()
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        super.onDestroy()
    }

    /** 子线程跑提权命令，避免 su / 反射调用阻塞主线程造成 ANR */
    private fun grantAsync() {
        Thread {
            val ok = PrivilegeManager.grantAll(this@MainActivity)
            runOnUiThread {
                if (ok) {
                    Toast.makeText(this, R.string.priv_granted_toast, Toast.LENGTH_SHORT).show()
                }
                refresh()
            }
        }.start()
    }

    // ---------------------------------------------------------------- 透明度设置

    /**
     * 弹出「透明度设置」面板：全屏遮罩 + 居中玻璃卡片，标题居中、左侧百分比、右侧滑块。
     * 用 Dialog 而不是浮层，所以调透明度不需要悬浮窗权限，任何时候都能打开。
     */
    private fun showOpacityDialog() {
        val view = layoutInflater.inflate(R.layout.layout_opacity_panel, null)
        val dialog = Dialog(this).apply {
            requestWindowFeature(Window.FEATURE_NO_TITLE)
            setContentView(view)
            window?.apply {
                setLayout(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT
                )
                setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                // 布局自带 scrim 遮罩，关掉系统默认变暗，避免叠两层变黑
                clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            }
            setOnDismissListener { opacityDialog = null }
        }

        val tv = view.findViewById<TextView>(R.id.tv_opacity)
        val slider = view.findViewById<VolumePanelView>(R.id.opacity_slider)
        val start = Prefs.opacity(this)

        // 左侧不画喇叭，轨道从 View 左边缘开始；填充色、发光、白环青绿芯与音量面板共用
        slider.showSpeaker = false
        slider.setProgress(start)
        tv.text = "$start%"

        slider.onProgressChanged = { p ->
            tv.text = "$p%"
            Prefs.setOpacity(this, p)
            // 悬浮窗已开启时实时预览；未开启只保存预设值，等开启悬浮窗时应用
            PanelService.syncOpacity(this)
        }

        // 点卡片本身不关闭，点遮罩关闭
        view.findViewById<View>(R.id.opacity_card).setOnClickListener { }
        view.setOnClickListener { dialog.dismiss() }

        dialog.show()
        opacityDialog = dialog
    }

    private fun refresh() {
        tvStatus.text = when (PrivilegeManager.mode()) {
            PrivilegeManager.Mode.ROOT -> getString(R.string.priv_root_ready)
            PrivilegeManager.Mode.SHIZUKU -> getString(R.string.priv_shizuku_ready)
            PrivilegeManager.Mode.NONE -> when {
                !PrivilegeManager.shizukuRunning() && !PrivilegeManager.rootProbed() ->
                    getString(R.string.priv_none)
                !PrivilegeManager.shizukuRunning() ->
                    getString(R.string.priv_shizuku_not_running)
                else -> getString(R.string.priv_shizuku_not_granted)
            }
        }
        if (VolumeController.isFixed(this)) {
            tvStatus.append(" · 该设备为固定音量，流音量不可调")
        }

        val notiOn = Prefs.notification(this)
        btnNotification.text = getString(
            if (notiOn) R.string.btn_notification_off else R.string.btn_notification_on
        )
        btnNotification.background = getDrawable(
            if (notiOn) R.drawable.bg_button else R.drawable.bg_button_off
        )
        btnNotification.setTextColor(
            getColor(if (notiOn) R.color.white else R.color.text_main)
        )

        val overlayOn = Prefs.overlay(this)
        btnOverlay.text = getString(
            if (overlayOn) R.string.btn_overlay_off else R.string.btn_overlay_on
        )
        btnOverlay.background = getDrawable(
            if (overlayOn) R.drawable.bg_button else R.drawable.bg_button_off
        )
        btnOverlay.setTextColor(
            getColor(if (overlayOn) R.color.white else R.color.text_main)
        )
    }

    private fun ensureNotificationPermission() {
        if (Build.VERSION.SDK_INT < 33) return
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED
        ) return
        // 后台走当前通道补权限，仍拿不到再弹系统权限框
        Thread {
            PrivilegeManager.grantAll(this@MainActivity)
            runOnUiThread {
                if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) !=
                    PackageManager.PERMISSION_GRANTED
                ) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2001)
                }
                refresh()
            }
        }.start()
    }

    private fun ensureOverlayPermissionHere() {
        if (Settings.canDrawOverlays(this)) return
        Thread {
            PrivilegeManager.grantAll(this@MainActivity)
            runOnUiThread {
                if (!Settings.canDrawOverlays(this)) {
                    startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")
                        )
                    )
                    Toast.makeText(this, "请开启「显示在其他应用上层」", Toast.LENGTH_LONG).show()
                }
                refresh()
            }
        }.start()
    }

    private fun launchShizuku() {
        val i = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
        if (i != null) {
            startActivity(i)
        } else {
            Toast.makeText(this, "请先安装 Shizuku 并启动服务", Toast.LENGTH_LONG).show()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refresh()
    }
}
