# exec() 通过反射调用 Shizuku.newProcess，混淆后方法名会变，反射就找不到。
# 保留库类及其成员名；ShizukuRemoteProcess.waitFor() 同理。
-keep class rikka.shizuku.Shizuku { *; }
-keep class rikka.shizuku.ShizukuRemoteProcess { *; }
-keepnames class rikka.shizuku.** { *; }
