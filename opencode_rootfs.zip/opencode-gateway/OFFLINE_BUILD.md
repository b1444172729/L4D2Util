# 离线构建指南（不需要访问 github.com）

> 这份源码是 **`dywr888/opencode-gateway-releases`**（原版 OpenCode Android Gateway，包名 `com.ocgw.app`）的完整可编译工程，已打成离线可用版。
> 你访问不了 GitHub 网页没关系：**编译 APK、生成 rootfs、装进手机，全程可以不碰 github.com**。

---

## 一、这个包里有什么

```
app/                            完整 Android 薄壳源码（Kotlin + res + Manifest）
  src/main/java/com/ocgw/app/
    GatewayService.kt           ← 已打离线补丁（下面第二节）
    MainActivity.kt  OpenAiGateway.kt  ProjectStore.kt  ToolRunner.kt
  build.gradle                  targetSdk 28（关键，见第六节）
  src/main/AndroidManifest.xml
rootfs/build-rootfs.sh          ← 已换成增强版（多源回退 / 自检 / SHA256）
.github/workflows/
  build-rootfs.yml              ← 已换成增强版（备用，需要 GitHub Actions 时才用）
  build-apk.yml                 原版，未改动
settings.gradle  gradle.properties  release.keystore  .gitignore  README.md
ROOTFS_BUILD.md                 rootfs 来源与自建的完整背景资料
OFFLINE_BUILD.md                本文件
```

**没有的东西，如实说明**：

| 缺什么 | 为什么 | 怎么办 |
|---|---|---|
| `rootfs-arm64.tar.gz`（100 MB+ 二进制） | 原 Release 已删除（HTTP 404），沙盒出网有白名单也下不到 Ubuntu base / npm / Termux 包，**我不能凭空生成 arm64 二进制** | 用包里的 `build-rootfs.sh` 在你自己的网络里生成，见第四节 |
| `gradlew` / `gradle-wrapper.jar` | 原仓库就没带（它靠 GitHub Actions 预装的 `gradle`） | 见第三节，三种编译方式任选 |
| 编译好的 APK | 沙盒无 Android SDK / Gradle | 见第三节 |

---

## 二、相对原版改了哪 4 处（都在 `GatewayService.kt`）

| # | 改动 | 原因 |
|---|---|---|
| 1 | `ORIGINAL` 常量从写死的 `https://github.com/dormantxxy/.../rootfs-arm64.tar.gz` 改成 **空字符串** | 那个仓库已 404；9 个 ghproxy 镜像只是给同一 URL 加前缀，实测全部 403。留空 = 默认完全不联网 |
| 2 | 新增 `findLocalArchive()`：按 `/sdcard/Download/rootfs-arm64.tar.gz` → `filesDir/import/` → `cacheDir/` 顺序找本地归档，命中就跳过全部测速与下载 | 你只要 `adb push` 一份就能用，不需要 fork / Release / 镜像 |
| 3 | 没填在线地址且没找到本地归档时，**直接给可照做的中文报错**，不再空转 6 次重试 12 秒 | 原版会一直卡在「选择最快镜像…」 |
| 4 | 解包逻辑抽成 `extractArchive()`，在线/本地共用；新增四件套校验 + 自动探测一层顶层目录 + `libandroid-shmem.so` 告警 | 原来只查 `opencode` 一个文件，坏归档会到启动阶段才炸 |

另外 `rootfs/build-rootfs.sh` 与 `.github/workflows/build-rootfs.yml` 换成了工程包里的增强版（Ubuntu base / npm / Termux 三处多源回退、`--skip-apt`、归档自检、SHA256、同时传 artifact）。

**其余全部原样保留**：包名、签名 keystore、`targetSdk 28`、WebView UI、OpenAI 网关 4318、官方 Web UI 4317、前台服务、SAF 项目同步。

---

## 三、编译 APK（三选一）

### 方式 A · Android Studio（最省事）

1. **File → Open** 选这个解压后的目录
2. IDE 会提示「Gradle wrapper missing」→ 点 **OK / 自动生成 wrapper**（它会下载 `gradle-wrapper.jar`，走的是 `services.gradle.org`，不是 github.com）
3. 等 Sync 完成 → **Build → Generate Signed Bundle / APK → APK**
4. 用包里的 `release.keystore`（storepass / keypass / alias 都是 `android` / `ocgw`，见 `build-apk.yml`），或干脆改成 debug 签名
5. 产物在 `app/build/outputs/apk/`，选 **arm64-v8a** 那个

> 需要 JDK 17 + Android SDK Platform 34 + AGP / Kotlin 插件（Android Studio 会自动补齐）。

### 方式 B · 命令行 gradle

本机装了 Gradle（8.x）与 Android SDK 时：

```bash
export ANDROID_HOME=/path/to/android-sdk
gradle assembleRelease \
  -Pandroid.injected.signing.store.file="$PWD/release.keystore" \
  -Pandroid.injected.signing.store.password=android \
  -Pandroid.injected.signing.key.alias=ocgw \
  -Pandroid.injected.signing.key.password=android
```

这条路不需要任何 GitHub 域名。

### 方式 C · GitHub Actions（如果你只是网页打不开、Actions 能用）

把本包完整 push 到你自己的仓库 → Actions → `build-apk` → Run workflow → 下载 `app-arm64-v8a-release.apk`。`build-apk.yml` 用的是 runner 预装的 `gradle`，没改过。

---

## 四、生成 `rootfs-arm64.tar.gz`（关键一步）

### 好消息：`--skip-apt` 版不需要 arm64 机器，也不需要 root

轻量版只是**下载 arm64 包 → 解包 → 重新打包**，全程不执行里面的二进制、不 chroot、不 mount。所以 **x64 Linux / WSL / macOS / 甚至一台能跑 bash 的云主机都能生成**。

```bash
cd <解压目录>
bash rootfs/build-rootfs.sh --skip-apt
# 或指定版本（必须 v2，别填 1.x）
OC_VER=2.2.7 bash rootfs/build-rootfs.sh --skip-apt
```

产物：`./rootfs-arm64.tar.gz` 与 `./rootfs-arm64.tar.gz.sha256`（约 100~150 MB）。

脚本自动按这个顺序找可用源，某个 403 就换下一个：

| 组件 | 候选源 |
|---|---|
| Ubuntu Base 24.04.3 arm64（glibc，~28 MB） | 官方 cdimage → 清华 → 阿里 → 中科大 |
| OpenCode **v2** CLI（arm64） | npm `@opencode/cli-linux-arm64` → npmmirror → 官方 GitHub release `opencode-linux-arm64.tar.gz`（glibc 版） → ghproxy 前缀 |
| Termux proot / loader / libtalloc / libandroid-shmem | 清华 TUNA → 官方 packages.termux.dev → 中科大 → 阿里 |

跑完会自检四件套并打印 SHA256，缺文件直接报错，不会静默产出坏包。

> **完整版**（`sudo -E bash rootfs/build-rootfs.sh`）会 chroot 装 git，供 OpenCode 的 `/api/vcs/init` 用；需要 root + arm64 Linux + 能 mount。**我们的网关和这个 APP 的 OpenAI 桥接都不调那个接口，跳过没问题。**

### 如果你只能在国内网络跑，注意

- npm CLI 包可以用 `https://registry.npmmirror.com/@opencode/cli-linux-arm64/-/cli-linux-arm64-<版本>.tgz` 手动下好，放到 `/tmp/oc.tgz` 再重跑；Ubuntu base 与 Termux 包同理可手动放 `/tmp/ubuntu-base.tar.gz`、`/tmp/proot.deb` 等
- 若某个源一直 403，编辑脚本顶部的 `*_MIRRORS` 数组，把你那边能通的镜像加进去
- 更详细的背景、原配方来源、以及「重建原版 APK」的第三条路，见 `ROOTFS_BUILD.md`

### 生成后立刻备份

```bash
sha256sum -c rootfs-arm64.tar.gz.sha256
cp rootfs-arm64.tar.gz ~/备份/    # 上次就是卸载丢了，别再重来
```

---

## 五、装机与启动（全程不联网）

```bash
# 1. 装 APK（注意保留数据，别先卸载）
adb install -r app-arm64-v8a-release.apk

# 2. 把运行环境推进手机
adb push rootfs-arm64.tar.gz /sdcard/Download/

# 3. 打开 APP → 点「启动」
#    日志里应出现：using local archive: /storage/emulated/0/Download/rootfs-arm64.tar.gz
#    然后进入「正在解压…」→「正在启动…」→ READY
```

APP 会自己 `tar -xzf` 解到 `filesDir/rootfs`，四件套齐全后以后每次启动都走 `rootfs already present; skip download`，**再也不需要网络**。

READY 后主界面会显示：

```
ui=http://127.0.0.1:4317   gateway=http://127.0.0.1:4318/v1
```

RikkaHub 里：类型 OpenAI，Base URL `http://127.0.0.1:4318/v1`，路径 `/chat/completions`，Key 随便填一个非空值，模型 ID 形如 `opencode/big-pickle`。

---

## 六、排障

| 现象 | 原因 | 处理 |
|---|---|---|
| 启动后提示「未找到本地 rootfs-arm64.tar.gz」 | 归档没放到候选路径，或文件 < 1 MB | `adb push` 到 `/sdcard/Download/`，核对文件名完全一致；或改 `findLocalArchive()` 里的路径 |
| 「解压后缺少文件：…」 | 归档不是有效 rootfs（多套了目录 / 打包时没带 proot） | 用 `tar -tzf rootfs-arm64.tar.gz \| head` 看结构；用第四节脚本重打 |
| 「缺 proot/lib/libandroid-shmem.so」（日志告警） | Termux proot 在部分 ROM 上需要 | 增强版脚本会自动带上；老归档可手动补 |
| `spawn EACCES` / proot 起不来 | **targetSdk ≥ 29 的 W^X 限制** | 本工程已固定 `targetSdk 28`（`app/build.gradle`），别改高；`compileSdk 34` 保持不变 |
| `/api/config` 401/403 | 认证方式版本差异 | 这个 APP 自己处理 `auth_token`；若你换了我们 r5b 工程，管理页有 `query ↔ basic` 开关 |
| CLI 报 426 | rootfs 里是 v1 / 0.x CLI | 用 `OC_VER=2.2.7` 重新生成；免费模型只支持 v2 |
| **429 FreeUsageLimitError** | 服务端共享免费额度窗口耗尽，**不是配置错** | 等窗口 / 换一个免费模型，**别连续重试**；同一分钟用官方 v2 客户端交错发一句对照，两边都 429 就是全局窗口 |
| `403 FreeTierError` | 客户端形状门，CLI 没被认成官方客户端 | 多半是版本过旧或第三方构建，换官方 v2 CLI |
| 厂商杀后台 → 4317/4318 一起掉线 | 前台服务被回收 | 电池白名单、锁定后台 |

---

## 七、必须诚实说明的几件事

1. **沙盒没能替你编译或生成 rootfs**：这里没有 Android SDK / Gradle，且出网有域名白名单（Ubuntu cdimage、npm registry、Termux 镜像在我这里都返回 403）。所以交付的是**源码 + 可复现的构建脚本 + 文档**，不是现成 APK 或二进制。代码层面已做静态检查（Kotlin 补丁为局部函数抽取与常量替换，未改签名），但没有编译器验证。
2. **免费层本身可能今天不可用**：2026-11 初 GitHub 上有一串 issue 报告「重置后几秒又 429」，官方 bot 统一归并到 #59387 并说明限制由托管服务按 account / workspace / network 裁决，「a change in the app can't lift it」。先把 APK 和 rootfs 弄好，再发**一句**「你好」验证，别在 429 时反复重试。
3. **合规**：官方写明免费聊天模型只对 OpenCode 客户端开放。这类 APP 是把官方 `opencode serve` 当服务用，个人低频自用可以，长期主力 / 商用不推荐；README 里也写了每台设备应各自登录自己的账号。
4. **我们自己的 r5b 工程**是另一套代码（包名 `com.android.cloudflare`，带管理页 / 自检 / 免费位过滤），它同样支持本地归档导入，并且这一轮也把 `targetSdk` 从 35 改成了 28 修掉 EACCES。两个工程**用同一份 `rootfs-arm64.tar.gz`** 即可，不用生成两次。

---

## 八、事实核对（2026-11-11 实测）

- 原 release 仓库 `dormantxxy/opencode-gateway-releases` → **HTTP 404**
- APK 内置 9 个 ghproxy 镜像 → **全部 403**
- `dywr888/opencode-gateway-releases` → 可访问，167 commits、4 forks、**0 Releases / 0 Tags**，含完整源码与构建脚本（本包即由此而来，并在本地打补丁）
- 官方 `anomalyco/opencode` 最新 v2 tag **v2.2.7**，含 `opencode-linux-arm64.tar.gz` / `-musl.tar.gz`
- 原配方：Ubuntu Base 24.04.3 arm64 + npm `@opencode/cli-linux-arm64@2.2.6` + Termux proot，`tar --hard-dereference` 打包
