#!/usr/bin/env bash
# =============================================================================
# 生成可在 Android(arm64) 上运行的 rootfs-arm64.tar.gz
#
# 配方来源：原 OpenCode Android Gateway 项目的 rootfs/build-rootfs.sh
#   （仓库 dywr888/opencode-gateway-releases，MIT/开源构建脚本）
# 本版增强：
#   · 三个上游（Ubuntu base / OpenCode CLI / Termux proot）都做多源回退，
#     国内机器用镜像、GitHub Actions 用官方源，自动选第一个能下的；
#   · OC_VER 可覆盖，默认取 npm dist-tag latest，失败再回退 GitHub release；
#   · --skip-apt 可跳过 chroot + apt install git（我们的网关不调 /api/vcs/init，
#     所以不需要 root / mount，普通 arm64 Linux 也能跑）；
#   · 打包后做四件套 + 推荐库自检、输出 SHA256，失败直接报错而不是静默产出坏包。
#
# 用法：
#   sudo -E bash scripts/build-rootfs.sh                # 完整版（含 git，需 root + arm64）
#   bash scripts/build-rootfs.sh --skip-apt            # 轻量版（无需 root/chroot）
#   OC_VER=2.2.7 bash scripts/build-rootfs.sh --skip-apt
#
# 产物：./rootfs-arm64.tar.gz  +  ./rootfs-arm64.tar.gz.sha256
# =============================================================================
set -euo pipefail

ARCH="arm64"
OUT="rootfs-${ARCH}.tar.gz"
ROOT="rootfs-${ARCH}"
OC_VER="${OC_VER:-}"
SKIP_APT="${SKIP_APT:-0}"
for a in "$@"; do [ "$a" = "--skip-apt" ] && SKIP_APT=1; done

# ---------------------------------------------------------------- 多源列表
UBUNTU_MIRRORS=(
  "https://cdimage.ubuntu.com/ubuntu-base/releases/24.04/release/ubuntu-base-24.04.3-base-arm64.tar.gz"
  "https://mirrors.tuna.tsinghua.edu.cn/ubuntu-cdimage/ubuntu-base/releases/24.04/release/ubuntu-base-24.04.3-base-arm64.tar.gz"
  "https://mirrors.aliyun.com/ubuntu-cdimage/ubuntu-base/releases/24.04/release/ubuntu-base-24.04.3-base-arm64.tar.gz"
  "https://mirrors.ustc.edu.cn/ubuntu-cdimage/ubuntu-base/releases/24.04/release/ubuntu-base-24.04.3-base-arm64.tar.gz"
)
TERMUX_MIRRORS=(
  "https://mirrors.tuna.tsinghua.edu.cn/termux/apt/termux-main"
  "https://packages.termux.dev/apt/termux-main"
  "https://mirrors.ustc.edu.cn/termux/apt/termux-main"
  "https://mirrors.aliyun.com/termux/apt/termux-main"
)
NPM_REGISTRIES=(
  "https://registry.npmjs.org"
  "https://registry.npmmirror.com"
)
GH_MIRRORS=(
  ""
  "https://gh-proxy.com/"
  "https://ghfast.top/"
  "https://ghproxy.net/"
)

log() { echo "[build-rootfs] $*"; }
die() { echo "❌ $*" >&2; exit 1; }

# 逐个试，返回第一个非空且 HTTP 2xx/3xx 的 URL 对应文件
fetch_first() {
  local dest="$1"; shift
  local u
  for u in "$@"; do
    [ -z "$u" ] && continue
    log "  尝试 $u"
    if curl -fsSL --connect-timeout 12 --max-time 900 -A 'Mozilla/5.0' "$u" -o "$dest" 2>/dev/null && [ -s "$dest" ]; then
      log "  ✓ 拿到 $(du -h "$dest" | cut -f1)"
      return 0
    fi
  done
  return 1
}

# ---------------------------------------------------------------- 0) 环境
log "架构：$(uname -m)（产物固定 arm64；若宿主非 aarch64，只有 --skip-apt 能跑）"
if [ "$SKIP_APT" = "0" ] && [ "$(id -u)" != "0" ]; then
  die "完整版需要 root（chroot + mount + apt）。改用 sudo -E bash $0，或加 --skip-apt 跳过 git 安装。"
fi

rm -rf "$ROOT"
mkdir -p "$ROOT"

# ---------------------------------------------------------------- 1) Ubuntu base
log "1/7 下载 Ubuntu Base 24.04 arm64（glibc rootfs，约 28 MB）"
fetch_first /tmp/ubuntu-base.tar.gz "${UBUNTU_MIRRORS[@]}" \
  || die "Ubuntu base 所有镜像都不可达。检查网络，或手动下载后放到 /tmp/ubuntu-base.tar.gz 再重跑。"
tar -xzf /tmp/ubuntu-base.tar.gz -C "$ROOT" || die "Ubuntu base 解包失败"
rm -f /tmp/ubuntu-base.tar.gz

# ---------------------------------------------------------------- 2) 基础目录
log "2/7 基础目录 / DNS / CA 证书"
mkdir -p "$ROOT/dev" "$ROOT/proc" "$ROOT/sys" "$ROOT/dev/pts" "$ROOT/tmp" "$ROOT/workspace"
chmod 1777 "$ROOT/tmp"
printf 'nameserver 223.5.5.5\nnameserver 8.8.8.8\n' > "$ROOT/etc/resolv.conf"
if [ -f /etc/ssl/certs/ca-certificates.crt ]; then
  mkdir -p "$ROOT/etc/ssl/certs"
  cp -f /etc/ssl/certs/ca-certificates.crt "$ROOT/etc/ssl/certs/ca-certificates.crt"
fi

# ---------------------------------------------------------------- 3) git（可选）
if [ "$SKIP_APT" = "0" ]; then
  log "3/7 chroot 安装 git（OpenCode /api/vcs/init 需要真实 git，否则 503）"
  cat > "$ROOT/etc/apt/sources.list" <<'SRC'
deb http://ports.ubuntu.com/ubuntu-ports noble main universe
deb http://ports.ubuntu.com/ubuntu-ports noble-updates main universe
SRC
  mount -t proc /proc "$ROOT/proc" 2>/dev/null || true
  mount --bind /dev "$ROOT/dev" 2>/dev/null || true
  if chroot "$ROOT" /bin/bash -c "export DEBIAN_FRONTEND=noninteractive; apt-get update -qq && apt-get install -y --no-install-recommends git ca-certificates" >/tmp/git-install.log 2>&1; then
    log "  ✓ git 已安装"
  else
    log "  ⚠ apt 安装 git 失败（不影响 bridge 链路）："; tail -12 /tmp/git-install.log || true
  fi
  umount "$ROOT/proc" 2>/dev/null || true
  umount "$ROOT/dev" 2>/dev/null || true
  rm -rf "$ROOT/var/lib/apt/lists"/* "$ROOT/var/cache/apt/archives"/*.deb 2>/dev/null || true
else
  log "3/7 跳过 git（--skip-apt；网关只用 /api/session|prompt|message，不调 /api/vcs/init）"
fi

# ---------------------------------------------------------------- 4) OpenCode CLI (v2)
log "4/7 获取 OpenCode v2 CLI（arm64）"
if [ -z "$OC_VER" ]; then
  for reg in "${NPM_REGISTRIES[@]}"; do
    OC_VER=$(curl -fsSL --connect-timeout 10 --max-time 20 "$reg/@opencode%2fcli-linux-arm64/latest" 2>/dev/null \
             | python3 -c 'import sys,json;print(json.load(sys.stdin).get("version",""))' 2>/dev/null || true)
    [ -n "$OC_VER" ] && break
  done
  OC_VER="${OC_VER:-2.2.7}"
fi
log "  目标版本：$OC_VER"

mkdir -p "$ROOT/opencode/bin" /tmp/ocpkg
OC_OK=0
for reg in "${NPM_REGISTRIES[@]}"; do
  u="$reg/@opencode/cli-linux-arm64/-/cli-linux-arm64-${OC_VER}.tgz"
  if fetch_first /tmp/oc.tgz "$u"; then OC_OK=1; break; fi
done
# 回退：GitHub 官方 release 的 glibc 版（Ubuntu base 需要 glibc，别用 musl 版）
if [ "$OC_OK" = "0" ]; then
  for pre in "${GH_MIRRORS[@]}"; do
    u="${pre}https://github.com/anomalyco/opencode/releases/download/v${OC_VER}/opencode-linux-arm64.tar.gz"
    if fetch_first /tmp/oc.tgz "$u"; then OC_OK=1; break; fi
  done
fi
[ "$OC_OK" = "1" ] || die "拿不到 OpenCode CLI：npm 与 GitHub release 都不可达。可手动下载后放到 /tmp/oc.tgz 再重跑。"

rm -rf /tmp/ocpkg && mkdir -p /tmp/ocpkg
tar -xzf /tmp/oc.tgz -C /tmp/ocpkg || die "CLI 包解包失败"
OC_BIN=$(find /tmp/ocpkg -type f -name 'opencode' | head -1)
[ -n "$OC_BIN" ] || die "CLI 包里找不到名为 opencode 的可执行文件：$(find /tmp/ocpkg -maxdepth 3 -type f | head -20)"
cp -f "$OC_BIN" "$ROOT/opencode/bin/opencode"
chmod 755 "$ROOT/opencode/bin/opencode"
log "  ✓ CLI $(du -h "$ROOT/opencode/bin/opencode" | cut -f1)（$(file -b "$ROOT/opencode/bin/opencode" | cut -c1-100)）"
rm -rf /tmp/oc.tgz /tmp/ocpkg

# ---------------------------------------------------------------- 5) Termux proot
log "5/7 获取 Termux 版 proot + loader + libtalloc + libandroid-shmem"
mkdir -p "$ROOT/proot/bin" "$ROOT/proot/lib" "$ROOT/proot/libexec"
TX_OK=0
for tm in "${TERMUX_MIRRORS[@]}"; do
  if curl -fsSL --connect-timeout 10 --max-time 120 "$tm/dists/stable/main/binary-aarch64/Packages" -o /tmp/tpkgs 2>/dev/null && [ -s /tmp/tpkgs ]; then
    TX_OK=1; TERMUX_BASE="$tm"; log "  Packages 索引：$tm"; break
  fi
done
[ "$TX_OK" = "1" ] || die "Termux 软件源索引不可达。"

fn() {
  awk -v pkg="$1" '
    $1=="Package:" && $2==pkg {found=1; next}
    found && $1=="Filename:" {print $2; exit}
    found && $1=="Package:" {found=0}
  ' /tmp/tpkgs
}

extract_deb() { # debfile destdir
  python3 - "$1" "$2" <<'PY'
import sys, os, subprocess, tempfile
deb, dest = sys.argv[1], sys.argv[2]
d = open(deb, 'rb').read()
i = 8
while i < len(d):
    hdr = d[i:i+60]
    if len(hdr) < 60: break
    name = hdr[0:16].decode(errors='replace').strip().rstrip('/')
    try: size = int(hdr[48:58].decode().strip())
    except ValueError: break
    data = d[i+60:i+60+size]
    if name.startswith('data.tar'):
        ext = name.split('.', 1)[1] if '.' in name else 'tar'
        tmp = tempfile.mktemp(suffix='.' + ext)
        open(tmp, 'wb').write(data)
        os.makedirs(dest, exist_ok=True)
        subprocess.run(['tar', '-xf', tmp, '-C', dest], check=False)
        os.remove(tmp)
    i += 60 + size
    if i % 2: i += 1
PY
}

for p in proot libtalloc libandroid-shmem; do
  path=$(fn "$p")
  [ -n "$path" ] || die "Termux 索引里找不到包 $p（Packages 格式可能变了）"
  log "  $p -> $path"
  fetch_first "/tmp/$p.deb" "$TERMUX_BASE/$path" || die "下载 $p 失败"
  rm -rf "/tmp/tx_$p"
  extract_deb "/tmp/$p.deb" "/tmp/tx_$p"
done

P="/tmp/tx_proot/data/data/com.termux/files/usr"
cp -f "$P/bin/proot"                 "$ROOT/proot/bin/proot"            || die "缺 proot 可执行文件"
cp -f "$P/libexec/proot/loader"      "$ROOT/proot/libexec/loader"       || die "缺 loader"
[ -f "$P/libexec/proot/loader32" ] && cp -f "$P/libexec/proot/loader32" "$ROOT/proot/libexec/loader32" || true
TL=$(find /tmp/tx_libtalloc -name 'libtalloc.so.*' -type f | head -1)
SH=$(find /tmp/tx_libandroid-shmem -name 'libandroid-shmem.so*' -type f | head -1)
[ -n "$TL" ] || die "缺 libtalloc.so"
[ -n "$SH" ] || die "缺 libandroid-shmem.so"
cp -f "$TL" "$ROOT/proot/lib/libtalloc.so.2"
cp -f "$SH" "$ROOT/proot/lib/libandroid-shmem.so"
chmod 755 "$ROOT/proot/bin/proot" "$ROOT/proot/libexec/"*
chmod 644 "$ROOT/proot/lib/"*.so*

# ---------------------------------------------------------------- 6) 清理
log "6/7 清理残留 .git 与缓存"
find "$ROOT" -name '.git' -type d -exec rm -rf {} + 2>/dev/null || true
rm -rf "$ROOT/var/tmp"/* 2>/dev/null || true
du -sh "$ROOT"

# ---------------------------------------------------------------- 7) 打包 + 校验
log "7/7 打包 $OUT（--hard-dereference 展开硬链接；Android SELinux 禁止 link()）"
tar -czf "$OUT" -C "$ROOT" --hard-dereference .
sha256sum "$OUT" > "$OUT.sha256"

log "校验四件套："
MISS=0
for f in opencode/bin/opencode proot/bin/proot proot/libexec/loader proot/lib/libtalloc.so.2; do
  if [ -f "$ROOT/$f" ]; then echo "  ✅ $f"; else echo "  ❌ $f"; MISS=1; fi
done
for f in proot/lib/libandroid-shmem.so proot/libexec/loader32; do
  [ -f "$ROOT/$f" ] && echo "  ✅ $f（推荐）" || echo "  ⚠ $f（建议补上，proot 在部分 ROM 上需要）"
done
[ "$MISS" = "0" ] || die "四件套不齐，产物不可用"

HL=$(tar -tvf "$OUT" 2>/dev/null | awk '$1 ~ /^h/' | wc -l)
log "归档内硬链接条目：$HL（必须为 0）"
log "完成：$OUT ($(du -h "$OUT" | cut -f1))"
cat "$OUT.sha256"
log "把这个文件交给网关 APP："
echo "  adb push $OUT /sdcard/Download/"
echo "  管理页「本地归档路径」填 /sdcard/Download/$OUT"
echo "  或放进私有目录 ofm-data/import/$OUT"
