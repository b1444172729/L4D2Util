# rootfs-arm64.tar.gz 从哪来（原文件已下架后的完整替代方案）

> 适用：`oc-proot-gateway-r5bb` 及之后所有 bridge-only 版本。
> 结论先说：**原文件拿不回来了，但原项目的构建配方还在，可以原样重新生成一份，产物与原来等价。**

---

## 一、先说坏消息：所有旧下载地址都已经失效

我实测了 2026-11-11 的状态：

| 目标 | 结果 |
|---|---|
| `https://api.github.com/repos/dormantxxy/opencode-gateway-releases/releases` | **HTTP 404**（仓库/Release 已删除） |
| 原 release 直连 URL | **HTTP 403** |
| APK 里内置的 9 个加速镜像（gh-proxy.com / gh-proxy.top / gh.ddlc.top / gh.llkk.cc / gh.nyc3.sosnw.com / ghfast.top / ghproxy.net / git.886.be / git.yiuman.com） | **全部 403**（它们只是给同一个已删除的 release URL 加前缀，源没了就全废） |
| Wayback Machine 存档查询 | 请求被策略拒绝，无法确认有快照 |
| 同名仓库 `dywr888/opencode-gateway-releases` 及其 4 个 fork | 存在，但 **0 个 Release**，不含现成 tar.gz |

另外：你上传给我的那个 APK（`OpenCode_1.0.0-20261109.29.apk.txt`）还在沙盒里，我重新拆过——915 个条目、最大的是 8.6 MB 的 `classes.dex`，**`lib/`、`assets/` 里没有任何二进制**，它本来就只是个下载器，卸载手机上的 APP 不会丢掉任何 rootfs 二进制（二进制从来不在 APK 里）。

> 卸载后能不能从手机里捞回来？基本不能：Android 卸载会删掉 `/data/data/com.ocgw.app/` 整个私有目录。除非你之前把 `rootfs` 目录导出到过 `/sdcard/Download/`、发给过别人、或做过 adb backup / 云备份——先去这几个地方翻一下，比重新构建快。

---

## 二、好消息：找到了原项目的完整源码，包括生成 rootfs 的脚本

仓库 **`https://github.com/dywr888/opencode-gateway-releases`**（约 43 KB 源码），README 描述与你那个 APK 完全一致：Kotlin 薄壳 + WebView、首次启动下载运行环境包、拉起 `opencode serve`、原生层打本地 `/api/*`。里面有：

```
rootfs/build-rootfs.sh                 ← 生成 rootfs-arm64.tar.gz 的完整配方
.github/workflows/build-rootfs.yml     ← 在 GitHub arm64 runner 上自动跑脚本并发布 Release
.github/workflows/build-apk.yml        ← 重建原版 APK
app/src/main/java/com/ocgw/app/*.kt    ← 原版 APP 全部 Kotlin 源码
```

配方还原出来的四件套，和 APK 里校验的路径**完全一致**：

```
opencode/bin/opencode          OpenCode v2 CLI（arm64，来自 npm @opencode/cli-linux-arm64）
proot/bin/proot                Termux 版 proot（bionic/NDK 编译，走 /system/bin/linker64）
proot/libexec/loader           proot loader
proot/lib/libtalloc.so.2       talloc
proot/lib/libandroid-shmem.so  Android shared memory 兼容库（推荐，部分 ROM 必需）
```

底层 rootfs 是 **Ubuntu Base 24.04.3 arm64（glibc，约 28 MB）**，还 chroot 装了 git（`/api/vcs/init` 需要真实 git，否则 503）。打包必须用 `tar --hard-dereference` 展开硬链接——Android 的 `untrusted_app` SELinux 禁止 `link()`，带硬链接的归档在设备端解不开。

**所以「自己写」不必从零琢磨：照这个配方重新跑一次即可。** 本目录已提供增强版脚本与 workflow。

---

## 三、路径 A（推荐）：fork 一下，让 GitHub 替你构建

不需要 arm64 机器、不需要 root、不需要懂 debootstrap。`build-rootfs.yml` 用 GitHub 公共仓库免费的 `ubuntu-24.04-arm` runner。

1. 打开 `https://github.com/dywr888/opencode-gateway-releases` → **Fork** 到自己账号。
   （也可以新建空仓库，只把 `rootfs/build-rootfs.sh` 提交到 `scripts/` 或 `rootfs/` 下，再把 `.github/workflows/build-rootfs.yml` 原样放到 `.github/workflows/`。）
2. fork 仓库 → **Settings → Actions → General**：
   - 启用 workflows（fork 默认可能是禁用状态）
   - **Workflow permissions** 改成 **Read and write permissions**（否则传不上 Release）
3. **Actions → build-rootfs → Run workflow**：
   - `oc_ver` 留空 = 自动取 npm `@opencode/cli-linux-arm64` 的 latest；也可手填 `2.2.7`
   - `skip_apt` 建议勾 **true**（我们的网关只调 `/api/session` `/prompt` `/message`，不调 `/api/vcs/init`，不需要 git，构建更快）
4. 跑完约几分钟，到 **Releases → `rootfs`** 下载 `rootfs-arm64.tar.gz`；同一份也会存在 Actions artifact 里（保留 30 天）。
5. 校验：`sha256sum -c rootfs-arm64.tar.gz.sha256`。

生成的直连 URL 形如：

```
https://github.com/<你的用户名>/opencode-gateway-releases/releases/download/rootfs/rootfs-arm64.tar.gz
```

把它填进网关 APP 管理页「**下载直连 URL**」，或下载后填「**本地归档路径**」。

> 本工程自带的 `.github/workflows/build-rootfs.yml` 相比原版多了：版本输入、skip_apt 开关、归档四件套自查、SHA256、以及**同时上传 Actions artifact**（Release 权限没配好时也能拿到文件）。

---

## 四、路径 B：本地自己跑脚本

```bash
# 完整版（含 git，需要 root + arm64 Linux）
sudo -E bash rootfs/build-rootfs.sh

# 轻量版（跳过 chroot/apt，普通 arm64 Linux 甚至 Termux proot-distro 里都行）
bash rootfs/build-rootfs.sh --skip-apt

# 指定版本
OC_VER=2.2.7 bash rootfs/build-rootfs.sh --skip-apt
```

产物：`./rootfs-arm64.tar.gz` 与 `./rootfs-arm64.tar.gz.sha256`。

增强版脚本相对原配方做了这些加固：

| 项 | 处理 |
|---|---|
| Ubuntu base | 官方 cdimage → 清华 → 阿里 → 中科大，逐个回退 |
| OpenCode CLI | npm `@opencode/cli-linux-arm64` → 官方 GitHub release `opencode-linux-arm64.tar.gz`（glibc 版，别用 musl 版配 Ubuntu base） |
| Termux 软件源 | 清华 / 官方 / 中科大 / 阿里，逐个回退 |
| 版本 | 默认取 npm dist-tag `latest`，失败回退 `2.2.7`；可用 `OC_VER` 覆盖 |
| git | `--skip-apt` 可跳过（网关不需要） |
| 打包 | `--hard-dereference`，并统计归档内硬链接条目，必须为 0 |
| 校验 | 四件套 + `libandroid-shmem.so` / `loader32` 检查，输出 SHA256，缺文件直接失败 |

**注意**：我的沙盒出网有域名白名单，`cdimage.ubuntu.com` / `registry.npmjs.org` / Termux 镜像在我这里都返回 403，**这不代表它们在你的网络或 GitHub Actions runner 上不可达**（GitHub Actions 是境外 runner，直连官方源）。脚本的多源回退就是为不同网络环境准备的。

---

## 五、路径 C：干脆重建原版 APP（最省事的「全都要」）

那个 `dywr888` 仓库里连**原版 APK 的完整 Kotlin 源码**都有。如果你只是想回到「已验证能跑」的状态，不必用我们的 r5 工程：

1. Fork `dywr888/opencode-gateway-releases`
2. 先按路径 A 跑 `build-rootfs.yml`，让它有 `rootfs` tag 的 Release
3. 再跑 `build-apk.yml`（`workflow_dispatch`），产出签名 APK
4. 检查 `app/src/main/java/com/ocgw/app/` 里下载 URL 是否指向**你自己 fork 的仓库**（原版写死的是 `dormantxxy/...`，已 404 —— 这一步必须改，否则装了还是下不到 rootfs）

需要改的字符串在 `MainActivity.kt` / `GatewayService.kt` 里，形如：
`https://github.com/dormantxxy/opencode-gateway-releases/releases/download/rootfs/rootfs-arm64.tar.gz`
→ 换成你自己 fork 的地址。

这条路的优点：完全还原你之前验证成功的那个 APP（包含 WebView UI、工具调用、项目目录），不用适配我们的 r5。缺点：它的 `/v1/chat/completions` 实现和免费层规则仍随上游变化，且要自己维护下载源。

---

## 六、拿到 tar.gz 之后怎么交给 r5 网关

三选一：

| 方式 | 操作 |
|---|---|
| **外部存储（最简单）** | `adb push rootfs-arm64.tar.gz /sdcard/Download/` → 管理页「本地归档路径」填 `/sdcard/Download/rootfs-arm64.tar.gz` |
| **私有目录** | `adb push` 到 `/data/local/tmp/` 再 `run-as com.android.cloudflare cp` 到 `files/ofm-data/import/rootfs-arm64.tar.gz`（release 构建需 root） |
| **在线下载** | 管理页「下载直连 URL」填你 fork 的 release 地址；`rootfs-manager.cjs` 会测速 + 断点续传 |

然后点「**重启 CLI / 重新准备 rootfs**」，`rootfs-manager.cjs` 会用纯 JS 解 tar.gz（不依赖系统 toybox tar），校验四件套后原子 rename 到 `ofm-data/rootfs`。之后点「🔬 端到端自检」。

如果四件套显示 ✅、但 CLI 起不来，重点看 **`proot/lib/libandroid-shmem.so` 是否存在**——原配方里它是必需的（Termux proot 依赖），但 APK 的四件套校验没把它算进去，所以管理页现在会把它列成「⚠ 建议补上」。

---

## 七、还有一条更激进的路（不保证可用，但值得知道）

GitHub 上有第三方 **`guysoft/opencode-termux`**，提供 `opencode2-*-android-aarch64.zip`（约 72 MB），是**原生 Android aarch64 构建的 OpenCode v2**，在 Termux 里不需要 chroot 就能跑。以及官方 release 的 `opencode-linux-arm64-musl.tar.gz`（v2.2.7，约 119 MB，musl 静态单文件）。

理论上：静态 musl 二进制 + 少量目录就能起 `opencode serve`，**连 proot 都可以省掉**，直接把二进制作为 `jniLibs/arm64-v8a/libopencode.so` 放进 APK 执行（还能顺带解决 Android 10+ 私有目录 EACCES）。但免费层校验的是「真实官方客户端进程的连接态」，第三方构建是否被认成官方客户端没有公开实测；musl 版在 Android 内核上的兼容性也要试。

这属于下一步实验，不在本次交付范围内。若你想试，我可以在 r6 里加一个 `native` 上游模式（跳过 proot，直接 spawn jniLibs 里的二进制）。

---

## 八、事实核对清单

- ✅ 原 release 仓库 404、9 个镜像 403 —— 2026-11-11 实测
- ✅ `dywr888/opencode-gateway-releases` 存在、含 `build-rootfs.sh` 与两个 workflow —— 已下载整包核对
- ✅ 官方 `anomalyco/opencode` 最新 v2 tag 为 **v2.2.7**，含 `opencode-linux-arm64.tar.gz` / `-musl.tar.gz` —— GitHub API 实测
- ✅ 原配方用 npm `@opencode/cli-linux-arm64@2.2.6` + Ubuntu Base 24.04.3 arm64 + Termux proot —— 脚本原文
- ⚠ 我无法从沙盒验证 ubuntu-cdimage / npm registry / Termux 镜像的可达性（出网白名单），故脚本做了多源回退
- ⚠ 免费模型仍需 **v2 CLI**；v1/0.x 会 426→429。`build-rootfs.sh` 默认取 npm latest，别手动填 1.x
