# GitHub 管理器（Android）

一个用 Kotlin + Jetpack Compose 写的 GitHub 仓库管理客户端，**全部功能走官方 REST API**，不依赖任何本地 Git 实现（无 JGit），因此不受 Android 版本差异影响，也不会出现克隆卡死的问题。

## 能做什么

### 文件（核心能力）
- **上传**：从手机选任意文件上传到仓库当前目录，**支持二进制**（zip / apk / 图片 / 音频……），单个上限 20 MB
- **下载**：保存文件到手机「下载 / GitHubManager」目录
- **删除**：删除文件；删除文件夹会递归清掉里面所有文件
- **重命名 / 移动**：填新路径即可（实现为「复制到新路径 + 删除旧路径」，产生两次提交）
- **新建**：新建文本文件、新建文件夹（自动带 .gitkeep）
- **编辑**：直接改代码 / yml 并提交，带提交说明
- **复制**：仓库内路径、网页地址一键复制

### 编译（Actions）
- 列出所有工作流，一键手动触发（可指定分支）
- 运行记录列表，实时状态（排队 / 运行中 / 成功 / 失败 / 取消）
- **查看编译日志**：自动下载 zip 并解压成可读文本
- **保存日志**：txt 与 zip 各存一份到手机
- 按任务（job）单独看日志，失败定位更快
- 取消运行、重跑、只重跑失败任务

### 产物与下载地址
- 构建产物列表，显示大小与时间
- **复制下载地址**：网页链接 / API 直链 / curl 命令 / 运行页面，四种任选
- **解析最终直链**：跟随 302 拿到真实下载地址再复制，浏览器直接可用
- **应用内下载**：选「存 APK」会直接从产物 zip 里解出 apk 保存，不用手动解压

### 日常管理
- 仓库列表、搜索、新建仓库、删除仓库、切换星标
- 分支：列表、新建（基于任意分支）、删除
- 提交历史
- Issues：列表、新建、关闭 / 重开
- Pull Requests：列表、合并
- Releases：列表、下载附件

## 技术要点

- 语言：Kotlin 2.2 + Jetpack Compose + Material 3
- 网络：OkHttp 直连 `api.github.com`，用 `org.json` 解析，无第三方封装
- 文件读写：GitHub **Contents API**（`PUT` / `DELETE` `/repos/{o}/{r}/contents/{path}`），天生支持二进制
- 下载保存：MediaStore 写入公共 Downloads 目录，Android 10+ 无需存储权限
- 令牌：存在应用私有 SharedPreferences，其他应用无法读取

## 需要的令牌权限

创建地址：https://github.com/settings/tokens

| 权限 | 用途 |
| --- | --- |
| `repo` | 读写文件、删除、重命名、提交、读写 Issues/PR |
| `workflow` | 触发编译、读取日志与产物 |
| `read:org` | 读取组织内的仓库列表 |
| `delete_repo` | 仅当需要在应用内删除仓库时才要 |

## 编译自己的 APK

1. 把整个目录打包成 zip 上传到 GitHub 仓库根目录
2. `.github/workflows/build.yml` 会自动解压并编译，产物在 Actions 的 Artifacts 里
3. 需要签名 Release 时，配置 4 个 Secrets：`SIGNING_KEYSTORE_BASE64`、`SIGNING_STORE_PASSWORD`、`SIGNING_KEY_ALIAS`、`SIGNING_KEY_PASSWORD`；不配置也能出可直接安装的 Debug APK

## 已知限制

- 单文件上限 20 MB（GitHub 的硬上限是 100 MB，这里保守设小以避免 base64 编码导致内存溢出）
- 文件夹不支持整体重命名，请逐文件操作
- 大仓库的文件列表不做分页，超深目录建议先按目录浏览
