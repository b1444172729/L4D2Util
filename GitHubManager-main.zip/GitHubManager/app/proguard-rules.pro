# 本项目未启用 R8（build.gradle.kts 中 isMinifyEnabled = false），保留此文件以便之后按需开启。
# 开启后需注意：OkHttp 依赖反射读取平台 SSL / DNS 实现，建议保留以下规则。
-dontwarn okhttp3.internal.platform.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-keep class okhttp3.** { *; }
-keep interface okhttp3.** { *; }
