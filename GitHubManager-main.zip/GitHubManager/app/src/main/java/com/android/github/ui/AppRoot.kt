package com.android.github.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.android.github.vm.AppViewModel
import com.android.github.vm.Screen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppRoot(vm: AppViewModel, onOpenUrl: (String) -> Unit, modifier: Modifier = Modifier) {
    val snackbar = remember { SnackbarHostState() }

    // 提示信息：一次性消费后弹出
    LaunchedEffect(vm.message) {
        val text = vm.message ?: return@LaunchedEffect
        snackbar.showSnackbar(text)
        vm.consumeMessage()
    }
    LaunchedEffect(vm.error) {
        val text = vm.error ?: return@LaunchedEffect
        snackbar.showSnackbar("出错了：$text")
        vm.consumeError()
    }

    // 注意：SnackbarHost 不再交给 Scaffold，而是放到下面 Box 的最后一个 child。
    // Scaffold 的 snackbarHost 槽位会被后来的页面内容盖住，
    // 导致「已复制」这类提示被对话框 / 浮层遮掉。放在最后声明才能保证绘制在最上层。
    androidx.compose.material3.Scaffold(
        modifier = modifier
    ) { padding ->
        // padding 由各页面自行处理，这里避免嵌套 Scaffold 造成双重留白
        val unused = padding

        // 页面主体
        Box(Modifier.fillMaxSize()) {
            AnimatedContent(
                targetState = vm.screen,
                transitionSpec = {
                    slideInHorizontally { it } togetherWith slideOutHorizontally { -it }
                },
                label = "screen"
            ) { screen ->
                when (screen) {
                    Screen.LOGIN -> LoginScreen(vm, onOpenUrl)
                    Screen.REPOS -> ReposScreen(vm, onOpenUrl)
                    Screen.DETAIL -> DetailScreen(vm, onOpenUrl)
                }
            }

            // 日志查看器必须在最外层全屏渲染：放在编译页内部会随 HorizontalPager
            // 一起测量和滑动，导致「点击运行不显示、滑到相邻页才显示」。
            // 只用 logViewerOpen 判断：运行中的任务日志可能暂时为空，
            // 若再加 logText != null 会导致「运行中点了没反应」，由 LogViewer 内部显示等待状态。
            // 运行详情页：点击运行记录后打开的一屏
            if (vm.runDetailOpen) {
                RunDetailScreen(vm, onOpenUrl)
            }

            // 完整日志：只有点「打开完整日志」才展示
            if (vm.logViewerOpen) {
                LogViewer(vm)
            }

            // 提示条（「已复制」等）放在最后声明：
            // Compose 里后声明的绘制在上层，这样提示一定盖在页面与所有浮层之上。
            SnackbarHost(
                snackbar,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 16.dp)
            )
        }
    }
}
