package com.android.github.util

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import com.android.github.data.LogBundle
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipInputStream

object Helpers {

    /** 便于阅读的体积文案 */
    fun size(bytes: Long): String = when {
        bytes < 1024 -> "$bytes B"
        bytes < 1024 * 1024 -> "%.1f KB".format(bytes / 1024.0)
        bytes < 1024 * 1024 * 1024 -> "%.2f MB".format(bytes / 1048576.0)
        else -> "%.2f GB".format(bytes / 1073741824.0)
    }

    /** 把 2024-05-01T08:00:00Z 变成 2024-05-01 08:00 */
    fun time(iso: String): String {
        if (iso.isBlank()) return ""
        return iso.replace("T", " ").removeSuffix("Z").take(16)
    }

    fun mimeOf(name: String): String =
        MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substringAfterLast('.', ""))
            ?: "application/octet-stream"

    /**
     * 保存字节到公共 Downloads/GitHubManager 目录。
     * 使用 MediaStore，Android 10 及以上无需任何存储权限。
     * @return 用户可读的保存位置提示
     */
    fun saveToDownloads(context: Context, bytes: ByteArray, fileName: String, mime: String): String {
        val safeName = fileName.replace(Regex("[/\\\\:*?\"<>|]"), "_").ifBlank { "download" }
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, safeName)
            put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/GitHubManager")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val resolver = context.contentResolver
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("无法创建文件")
        return try {
            resolver.openOutputStream(uri)?.use { it.write(bytes) }
                ?: throw IllegalStateException("无法写入文件")
            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            "已保存到 下载/GitHubManager/$safeName"
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            throw e
        }
    }

    /**
     * GitHub 的运行日志是一个 zip（每个 step 一个文本文件）。
     * 这里解压并拼接成可阅读的文本，方便直接查看；同时保留 zip 供保存。
     */
    fun zipToText(bytes: ByteArray): String {
        val output = StringBuilder()
        ZipInputStream(ByteArrayInputStream(bytes)).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                if (entry.isDirectory) {
                    zip.closeEntry()
                    continue
                }
                output.append("\n===== ${entry.name} =====\n")
                val buffer = ByteArrayOutputStream()
                val tmp = ByteArray(8192)
                while (true) {
                    val n = zip.read(tmp)
                    if (n <= 0) break
                    buffer.write(tmp, 0, n)
                }
                output.append(buffer.toString("UTF-8"))
                zip.closeEntry()
            }
        }
        val merged = output.toString()
        return if (merged.isBlank()) PLACEHOLDER_EMPTY_LOG else stripAnsi(merged)
    }

    /** 从 zip 中挑出指定后缀的文件字节（例如从产物 zip 里直接取出 apk） */
    fun extractFirst(bytes: ByteArray, suffix: String): Pair<String, ByteArray>? {
        ZipInputStream(ByteArrayInputStream(bytes)).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                if (entry.isDirectory || !entry.name.endsWith(suffix, true)) {
                    zip.closeEntry()
                    continue
                }
                val buffer = ByteArrayOutputStream()
                val tmp = ByteArray(65536)
                while (true) {
                    val n = zip.read(tmp)
                    if (n <= 0) break
                    buffer.write(tmp, 0, n)
                }
                zip.closeEntry()
                return entry.name.substringAfterLast('/') to buffer.toByteArray()
            }
        }
        return null
    }

    /** 从 Uri 读取全部字节（用于上传） */
    fun readUri(context: Context, uri: Uri): ByteArray {
        val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: throw IllegalStateException("无法读取所选文件")
        if (bytes.isEmpty()) throw IllegalStateException("所选文件为空")
        return bytes
    }

    /**
     * 把已存在的大文件写入 Downloads。
     * 与 saveToDownloads(bytes) 的区别：走流拷贝，不会把整个文件读进内存。
     */
    fun saveFileToDownloads(context: Context, source: File, fileName: String, mime: String): String {
        val safeName = fileName.replace(Regex("[/\\\\:*?\"<>|]"), "_").ifBlank { "download" }
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, safeName)
            put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/GitHubManager")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val resolver = context.contentResolver
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("无法创建文件")
        return try {
            resolver.openOutputStream(uri)?.use { out ->
                source.inputStream().use { input -> input.copyTo(out) }
            } ?: throw IllegalStateException("无法写入文件")
            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            "已保存到 下载/GitHubManager/$safeName"
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            throw e
        }
    }

    /**
     * 从 zip 文件里解出第一个指定后缀的条目，写到 destDir。
     * 返回 (文件名, 文件)；找不到返回 null。同样走流，适合大文件。
     */
    fun extractFirstToFile(zip: File, suffix: String, destDir: File): Pair<String, File>? {
        ZipInputStream(zip.inputStream()).use { stream ->
            while (true) {
                val entry = stream.nextEntry ?: break
                if (entry.isDirectory || !entry.name.endsWith(suffix, true)) {
                    stream.closeEntry()
                    continue
                }
                val name = entry.name.substringAfterLast('/').ifBlank { "app.apk" }
                if (!destDir.exists()) destDir.mkdirs()
                val out = File(destDir, name)
                out.outputStream().use { output -> stream.copyTo(output) }
                stream.closeEntry()
                return name to out
            }
        }
        return null
    }

    /** Uri 对应文件的大小；取不到时返回 -1 */
    fun uriSize(context: Context, uri: Uri): Long {
        runCatching {
            context.contentResolver.openAssetFileDescriptor(uri, "r")?.use { return it.length }
        }
        runCatching {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val index = cursor.getColumnIndex(android.provider.OpenableColumns.SIZE)
                    if (index >= 0 && !cursor.isNull(index)) return cursor.getLong(index)
                }
            }
        }
        return -1L
    }

    /** Uri 对应的显示名 */
    fun displayName(context: Context, uri: Uri): String {
        var name: String? = null
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (index >= 0) name = cursor.getString(index)
            }
        }
        return name ?: uri.lastPathSegment ?: "file"
    }

    /** 判断字节内容是否为文本（不含 0 字节，且能按 UTF-8 解码） */
    fun isText(bytes: ByteArray): Boolean {
        if (bytes.isEmpty()) return true
        if (bytes.any { it == 0.toByte() }) return false
        return runCatching { String(bytes, Charsets.UTF_8) }.isSuccess
    }

    /** 日志为空时的占位文案（不含括号，便于各处统一判断） */
    const val PLACEHOLDER_EMPTY_LOG = "日志为空，可能尚未开始或已过期"

    /** 目录树中的一个文件：relativePath 是相对所选文件夹的路径，用于拼出仓库内的目标路径 */
    data class TreeFile(val relativePath: String, val uri: Uri, val size: Long)

    /** 单次上传文件夹的文件数上限，防止误选根目录导致卡死 */
    const val MAX_TREE_FILES = 300

    /**
     * 申请对目录树 URI 的持久读权限。
     * 不做这一步的话，Activity 结束后再读文件可能会被拒绝。
     */
    fun grantTreePermission(context: Context, treeUri: Uri) {
        runCatching {
            context.contentResolver.takePersistableUriPermission(
                treeUri, Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        }
    }

    /**
     * 递归遍历用户选中的文件夹，返回其中所有文件（含子目录，保留相对路径）。
     *
     * Android 没有「选择整个文件夹」的标准文件选择器，官方做法是用 SAF 的
     * ACTION_OPEN_DOCUMENT_TREE 拿到目录树 URI，再用 DocumentsContract 逐层查询子节点。
     */
    fun listTree(context: Context, treeUri: Uri): List<TreeFile> {
        grantTreePermission(context, treeUri)
        val result = mutableListOf<TreeFile>()
        val rootId = runCatching { DocumentsContract.getTreeDocumentId(treeUri) }.getOrNull()
            ?: return result

        fun walk(docId: String, prefix: String, depth: Int) {
            if (depth > 10 || result.size >= MAX_TREE_FILES) return
            val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, docId)
            val projection = arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE,
                DocumentsContract.Document.COLUMN_SIZE
            )
            val cursor = runCatching {
                context.contentResolver.query(childrenUri, projection, null, null, null)
            }.getOrNull() ?: return
            cursor.use {
                while (it.moveToNext() && result.size < MAX_TREE_FILES) {
                    val id = it.getString(0) ?: continue
                    val name = it.getString(1) ?: continue
                    val mime = it.getString(2) ?: continue
                    val size = if (it.isNull(3)) -1L else it.getLong(3)
                    val rel = if (prefix.isBlank()) name else "$prefix/$name"
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                        walk(id, rel, depth + 1)
                    } else {
                        val fileUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, id)
                        result.add(TreeFile(rel, fileUri, size))
                    }
                }
            }
        }
        walk(rootId, "", 0)
        return result
    }

    /** ANSI 转义序列（终端颜色、光标控制），形如 ESC[31m */
    private val ANSI = Regex("\u001B\\[[0-9;?]*[ -/]*[@-~]")

    /**
     * 去掉终端颜色控制符。
     * GitHub Actions 的日志里混有 ANSI 序列，直接显示会看到乱码字符。
     */
    fun stripAnsi(text: String): String = ANSI.replace(text, "")

    /** zipToText 在没有任何内容时会返回占位提示，这里判断是否真的为空 */
    fun isEmptyLog(text: String): Boolean =
        text.isBlank() || text.startsWith(PLACEHOLDER_EMPTY_LOG)

    /**
     * 把完整日志按「重点 / 错误 / 警告」分级。
     * 目的：手机上不用在几千行里翻，直接看关键结论。
     */
    fun parseLogs(raw: String, sizeBytes: Long): LogBundle {
        val key = LinkedHashSet<String>()
        val errors = LinkedHashSet<String>()
        val warnings = LinkedHashSet<String>()

        // 无意义的行不进重点，避免刷屏
        fun isNoise(line: String): Boolean {
            val t = line.trim()
            return t.isBlank() || t.startsWith("=====") ||
                "UP-TO-DATE" in t || "NO-SOURCE" in t || "SKIPPED" in t ||
                t.startsWith("To honour the JVM settings") ||
                t.startsWith("Daemon will be stopped")
        }

        raw.lineSequence().forEach { line ->
            val t = line.trim()
            if (t.isBlank()) return@forEach

            // 错误：Kotlin e: 、Gradle 失败、异常
            val isError = t.startsWith("e: ") || ": error:" in t ||
                t.startsWith("FAILURE:") || t.endsWith("FAILED") ||
                "Execution failed for task" in t || "Compilation error" in t ||
                (t.contains("Exception") && !t.contains("继续"))

            // 警告：Kotlin w: 、Gradle warning
            val isWarning = t.startsWith("w: ") || ": warning:" in t ||
                t.startsWith("WARNING:") || "warning:" in t.lowercase() ||
                "is deprecated" in t.lowercase()

            when {
                isError -> errors += t
                isWarning -> warnings += t
            }

            // 重点：构建结论、实际执行的任务、产物路径、耗时
            val isKey = "BUILD SUCCESSFUL" in t || "BUILD FAILED" in t ||
                "actionable tasks" in t || "actionable task" in t ||
                (t.startsWith("> Task") && !isNoise(t)) ||
                (".apk" in t && ("/" in t || "outputs" in t))
            if (isKey && !isNoise(t)) key += t
        }

        // 完全没有重点时（例如日志还没开始），给一句提示
        if (key.isEmpty()) key += "（暂无关键输出，运行可能尚未开始或日志为空）"
        return LogBundle(raw, key.toList(), errors.toList(), warnings.toList(), sizeBytes)
    }
}
