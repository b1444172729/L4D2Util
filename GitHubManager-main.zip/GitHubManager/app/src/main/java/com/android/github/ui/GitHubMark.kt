package com.android.github.ui

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

/**
 * GitHub 官方 Octocat（GitHub Mark）徽标底色与前景色。
 *
 * 取自 APP 启动图标 ic_launcher_background(#24292F) + 白色前景剪影，
 * 固定颜色不随明暗主题变化 —— 否则深色主题下 onPrimary 可能变成深色，
 * 白猫画在深色底上会看不清。
 */
val GitHubBrandDark = Color(0xFF24292F)
val GitHubBrandOnDark = Color.White

/**
 * GitHub 官方 Octocat（GitHub Mark）矢量图形，与 APP 启动图标同源。
 *
 * pathData 用的是 ic_launcher_foreground.xml 里那份官方 24x24 路径，
 * 这里改写成纯 Compose ImageVector 的 Path DSL，原因有两点：
 *  1. 桌面版没有 Android 的 drawable / R 资源系统，引用不了 XML vector；
 *  2. 启动图标那份带 108x108 画布的 translate/scale（为了安全区），
 *     直接拿来当界面图标会缩得很小，24x24 视口才能铺满图标框。
 *
 * 与 Material 图标的做法一致：fill 只是占位色，
 * Icon(imageVector = GitHubMark, tint = ...) 会用 tint 覆盖它。
 */
val GitHubMark: ImageVector by lazy {
    ImageVector.Builder(
        name = "GitHubMark",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(
            fill = SolidColor(Color.Black),
            pathFillType = PathFillType.NonZero
        ) {
            moveTo(12f, 0.297f)
            curveTo(5.37f, 0.297f, 0f, 5.67f, 0f, 12.297f)
            curveTo(0f, 17.6f, 3.438f, 22.097f, 8.205f, 23.682f)
            curveTo(8.805f, 23.795f, 9.025f, 23.424f, 9.025f, 23.105f)
            curveTo(9.025f, 22.82f, 9.015f, 22.065f, 9.01f, 21.065f)
            curveTo(5.672f, 21.789f, 4.968f, 19.455f, 4.968f, 19.455f)
            curveTo(4.422f, 18.07f, 3.633f, 17.7f, 3.633f, 17.7f)
            curveTo(2.546f, 16.956f, 3.717f, 16.971f, 3.717f, 16.971f)
            curveTo(4.922f, 17.055f, 5.555f, 18.207f, 5.555f, 18.207f)
            curveTo(6.625f, 20.042f, 8.364f, 19.512f, 9.05f, 19.205f)
            curveTo(9.158f, 18.429f, 9.467f, 17.9f, 9.81f, 17.6f)
            curveTo(7.145f, 17.3f, 4.344f, 16.268f, 4.344f, 11.67f)
            curveTo(4.344f, 10.36f, 4.809f, 9.29f, 5.579f, 8.45f)
            curveTo(5.444f, 8.147f, 5.039f, 6.927f, 5.684f, 5.274f)
            curveTo(5.684f, 5.274f, 6.689f, 4.952f, 8.984f, 6.504f)
            curveTo(9.944f, 6.237f, 10.964f, 6.105f, 11.984f, 6.099f)
            curveTo(13.004f, 6.105f, 14.024f, 6.237f, 14.984f, 6.504f)
            curveTo(17.264f, 4.952f, 18.269f, 5.274f, 18.269f, 5.274f)
            curveTo(18.914f, 6.927f, 18.509f, 8.147f, 18.389f, 8.45f)
            curveTo(19.154f, 9.29f, 19.619f, 10.36f, 19.619f, 11.67f)
            curveTo(19.619f, 16.28f, 16.814f, 17.295f, 14.144f, 17.59f)
            curveTo(14.564f, 17.95f, 14.954f, 18.686f, 14.954f, 19.81f)
            curveTo(14.954f, 21.416f, 14.939f, 22.706f, 14.939f, 23.096f)
            curveTo(14.939f, 23.411f, 15.149f, 23.786f, 15.764f, 23.666f)
            curveTo(20.565f, 22.092f, 24f, 17.592f, 24f, 12.297f)
            curveTo(24f, 5.67f, 18.627f, 0.297f, 12f, 0.297f)
            close()
        }
    }.build()
}
