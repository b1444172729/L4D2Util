package com.android.github.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.android.github.data.Repo
import com.android.github.util.Helpers
import com.android.github.vm.AppViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReposScreen(vm: AppViewModel, onOpenUrl: (String) -> Unit) {
    var query by remember { mutableStateOf("") }
    var showCreate by remember { mutableStateOf(false) }
    var menuRepo by remember { mutableStateOf<Repo?>(null) }
    var confirmDelete by remember { mutableStateOf<Repo?>(null) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showCreate = true },
                shape = RoundedCornerShape(18.dp),
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            ) {
                Icon(Icons.Rounded.Add, "新建仓库")
                Spacer(Modifier.width(6.dp))
                Text("新建仓库", fontWeight = FontWeight.SemiBold)
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            // 顶部：渐变徽标 + 用户名 + 操作图标
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                listOf(
                                    MaterialTheme.colorScheme.primary,
                                    MaterialTheme.colorScheme.tertiary
                                )
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Rounded.Code, null, Modifier.size(22.dp),
                        tint = MaterialTheme.colorScheme.onPrimary
                    )
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        "仓库",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    vm.user?.let {
                        Text(
                            it.login,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                CircleIconButton(
                    if (vm.darkTheme) Icons.Rounded.LightMode else Icons.Rounded.DarkMode,
                    "主题"
                ) { vm.toggleTheme() }
                Spacer(Modifier.width(8.dp))
                CircleIconButton(Icons.Rounded.Logout, "退出") { vm.logout() }
            }

            BusyBar(if (vm.busy) vm.busyLabel else "")

            // 搜索框：填充式胶囊（TextField 默认即填充底，无需自定义 colors，兼容性更好）
            TextField(
                query, {
                    query = it
                    if (it.length >= 2 || it.isEmpty()) vm.search(it)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                placeholder = { Text("搜索我的仓库或公开仓库", style = MaterialTheme.typography.bodyMedium) },
                singleLine = true,
                shape = RoundedCornerShape(24.dp),
                leadingIcon = { Icon(Icons.Rounded.Search, null, Modifier.size(20.dp)) },
                trailingIcon = if (query.isNotEmpty()) {
                    { IconButton(onClick = { query = ""; vm.search("") }) { Icon(Icons.Rounded.Close, "清空") } }
                } else null
            )

            if (vm.repos.isEmpty() && !vm.busy) {
                EmptyState(
                    Icons.Rounded.FolderOff,
                    "没有仓库",
                    "点击右下角「新建仓库」创建，或换个搜索关键字试试"
                )
            }

            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 96.dp)
            ) {
                items(vm.repos, key = { it.id }) { repo ->
                    RepoItem(
                        repo = repo,
                        onClick = { vm.openRepo(repo) },
                        onMenu = { menuRepo = repo }
                    )
                }
            }
        }
    }

    if (showCreate) {
        var name by remember { mutableStateOf("") }
        var description by remember { mutableStateOf("") }
        var privateRepo by remember { mutableStateOf(true) }
        AlertDialog(
            onDismissRequest = { showCreate = false },
            shape = RoundedCornerShape(Dimens.SheetRadius),
            title = { Text("新建仓库", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        name, { name = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("仓库名称") },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        placeholder = { Text("例如 my-android-app") }
                    )
                    OutlinedTextField(
                        description, { description = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("描述（可选）") },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp)
                    )
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surfaceContainerHigh,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(privateRepo, { privateRepo = it })
                            Spacer(Modifier.width(6.dp))
                            Text("私有仓库", style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                    InfoText("会自动创建 README 和 main 分支，方便立刻上传文件。")
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.createRepo(name, description, privateRepo)
                    showCreate = false
                }, enabled = name.isNotBlank()) { Text("创建", fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { showCreate = false }) { Text("取消") } }
        )
    }

    menuRepo?.let { target ->
        AlertDialog(
            onDismissRequest = { menuRepo = null },
            shape = RoundedCornerShape(Dimens.SheetRadius),
            title = {
                Text(
                    target.fullName,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    MenuAction(Icons.Rounded.OpenInNew, "在浏览器打开") {
                        onOpenUrl(target.htmlUrl); menuRepo = null
                    }
                    MenuAction(Icons.Rounded.ContentCopy, "复制仓库地址") {
                        vm.copy(target.htmlUrl); menuRepo = null
                    }
                    MenuAction(Icons.Rounded.Star, "切换星标") {
                        vm.toggleStar(target); menuRepo = null
                    }
                    MenuAction(
                        Icons.Rounded.DeleteOutline,
                        "删除仓库",
                        tint = MaterialTheme.colorScheme.error
                    ) {
                        menuRepo = null; confirmDelete = target
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { menuRepo = null }) { Text("关闭") } }
        )
    }

    confirmDelete?.let { target ->
        ConfirmDialog(
            title = "删除 ${target.fullName}？",
            text = "这是不可逆操作，仓库内的所有文件、Issues 和 Actions 记录都会被删除。",
            confirmLabel = "确认删除",
            onDismiss = { confirmDelete = null },
            onConfirm = { vm.deleteRepo(target) }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MenuAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    tint: androidx.compose.ui.graphics.Color = MaterialTheme.colorScheme.onSurface,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        color = androidx.compose.ui.graphics.Color.Transparent,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            Modifier.padding(horizontal = 8.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, null, Modifier.size(20.dp), tint = tint)
            Spacer(Modifier.width(12.dp))
            Text(label, style = MaterialTheme.typography.bodyMedium, color = tint)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RepoItem(repo: Repo, onClick: () -> Unit, onMenu: () -> Unit) {
    ItemCard(
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 5.dp),
        onClick = onClick
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            // 渐变图标底座：私有仓库用琥珀色，公开用主色
            Box(
                Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(13.dp))
                    .background(
                        Brush.linearGradient(
                            if (repo.isPrivate) listOf(
                                MaterialTheme.colorScheme.tertiary,
                                MaterialTheme.colorScheme.primary
                            ) else listOf(
                                MaterialTheme.colorScheme.primary,
                                MaterialTheme.colorScheme.secondary
                            )
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    if (repo.isPrivate) Icons.Rounded.Lock else Icons.Rounded.Folder,
                    null,
                    Modifier.size(21.dp),
                    tint = MaterialTheme.colorScheme.onPrimary
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    repo.name,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (repo.description.isNotBlank()) {
                    Spacer(Modifier.height(2.dp))
                    Text(
                        repo.description,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        lineHeight = 15.sp
                    )
                }
                Spacer(Modifier.height(6.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (repo.language.isNotBlank()) {
                        StatusChip(repo.language, MaterialTheme.colorScheme.primary)
                    }
                    StatusChip("★ ${repo.stars}", MaterialTheme.colorScheme.tertiary)
                    MetaLine(Helpers.size(repo.size * 1024), Helpers.time(repo.pushedAt))
                }
            }
            IconButton(onClick = onMenu) {
                Icon(Icons.Rounded.MoreVert, null, Modifier.size(20.dp))
            }
        }
    }
}
