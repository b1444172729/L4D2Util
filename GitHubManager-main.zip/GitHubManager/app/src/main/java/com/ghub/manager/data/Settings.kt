package com.ghub.manager.data

import android.content.Context

/**
 * 轻量偏好存储：令牌、最近使用的仓库与分支、主题。
 * 令牌属于敏感信息，但本应用是单机自用工具，使用应用私有 SharedPreferences 已足够
 * （其他应用无法读取），避免引入额外加密库带来的构建与兼容风险。
 */
class Settings(context: Context) {

    private val prefs = context.getSharedPreferences("ghub", Context.MODE_PRIVATE)

    var token: String
        get() = prefs.getString("token", "").orEmpty()
        set(value) = prefs.edit().putString("token", value.trim()).apply()

    var lastOwner: String
        get() = prefs.getString("owner", "").orEmpty()
        set(value) = prefs.edit().putString("owner", value).apply()

    var lastRepo: String
        get() = prefs.getString("repo", "").orEmpty()
        set(value) = prefs.edit().putString("repo", value).apply()

    var darkTheme: Boolean
        get() = prefs.getBoolean("dark", false)
        set(value) = prefs.edit().putBoolean("dark", value).apply()

    /** 提交文件时使用的默认提交信息前缀 */
    var commitPrefix: String
        get() = prefs.getString("prefix", "").orEmpty()
        set(value) = prefs.edit().putString("prefix", value).apply()

    fun remember(owner: String, repo: String) {
        lastOwner = owner
        lastRepo = repo
    }

    fun clear() = prefs.edit().remove("token").apply()
}
