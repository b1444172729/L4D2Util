package com.ghub.manager.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.ghub.manager.data.ContentEntry
import com.ghub.manager.util.Helpers
import com.ghub.manager.vm.AppViewModel

@Composable
fun FilesScreen(vm: AppViewModel, onOpenUrl: (String) -> Unit) {
    var menuEntry by remember { mutableStateOf<ContentEntry?>(null) }
    var renameTarget by remember { mutableStateOf<ContentEntry?>(null) }
    var deleteTarget by remember { mutableStateOf<ContentEntry?>(null) }
    var showNewFile by remember { mutableStateOf(false) }
    var showNewFolder by remember { mutableStateOf(false) }
    var pendingUploadName by remember { mutableStateOf<String?>(null) }
    var pendingUri by remember { mutableStateOf<android.net.Uri?>(null) }
    var branchMenu by remember { mutableStateOf(false) }
    val context = androidx.compose.ui.platform.LocalContext.current

    // 选择本地文件上传
    val pickFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            pendingUri = uri
            pendingUploadName = Helpers.displayName(context, uri)
        }
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            // 分支与目录导航
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(onClick = { branchMenu = true }, enabled = !vm.busy) {
                    Icon(Icons.Rounded.AccountTree, null, Modifier.size(16.dp))
                    Spacer(Modifier.width(5.dp))
                    Text(vm.branch.ifBlank { "main" }, maxLines = 1)
                }
                Spacer(Modifier.width(8.dp))
                IconButton(onClick = vm::refreshFiles, enabled = !vm.busy) {
                    Icon(Icons.Rounded.Refresh, "刷新")
                }
                if (vm.path.isNotBlank()) {
                    IconButton(onClick = vm::goUp, enabled = !vm.busy) {
                        Icon(Icons.Rounded.ArrowUpward, "上一级")
                    }
                }
                Spacer(Modifier.weight(1f))
                Text("${vm.entries.size} 项", style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            if (vm.path.isNotBlank()) Breadcrumbs(vm.path) { vm.openFolder(it) }

            // 快捷操作
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(onClick = { pickFile.launch(arrayOf("*/*")) }, modifier = Modifier.weight(1f), enabled = !vm.busy) {
                    Icon(Icons.Rounded.Upload, null, Modifier.size(17.dp))
                    Spacer(Modifier.width(5.dp))
                    Text("上传文件")
                }
                OutlinedButton(onClick = { showNewFile = true }, modifier = Modifier.weight(1f), enabled = !vm.busy) {
                    Icon(Icons.Rounded.NoteAdd, null, Modifier.size(17.dp))
                    Spacer(Modifier.width(5.dp))
                    Text("新建文件")
                }
                OutlinedButton(onClick = { showNewFolder = true }, modifier = Modifier.weight(1f), enabled = !vm.busy) {
                    Icon(Icons.Rounded.CreateNewFolder, null, Modifier.size(17.dp))
                    Spacer(Modifier.width(5.dp))
                    Text("文件夹")
                }
            }

            if (vm.entries.isEmpty() && !vm.busy) {
                EmptyState(Icons.Rounded.FolderOpen, "空目录", "点「上传文件」把 zip / apk / 图片 / 代码传上来")
            }

            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
                items(vm.entries, key = { it.path }) { entry ->
                    FileItem(entry, vm, { menuEntry = it })
                }
            }
        }
    }

    // 分支选择
    if (branchMenu) {
        AlertDialog(
            onDismissRequest = { branchMenu = false },
            title = { Text("切换分支") },
            text = {
                LazyColumn {
                    items(vm.branches) { b ->
                        TextButton(onClick = { vm.switchBranch(b.name); branchMenu = false }, modifier = Modifier.fillMaxWidth()) {
                            Text(b.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            if (b.name == vm.branch) Spacer(Modifier.width(6.dp))
                            if (b.name == vm.branch) Icon(Icons.Rounded.Check, null, Modifier.size(16.dp))
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { branchMenu = false }) { Text("关闭") } }
        )
    }

    // 上传确认：可改名 + 填写提交信息
    pendingUploadName?.let { defaultName ->
        var name by remember { mutableStateOf(defaultName) }
        var commitMessage by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { pendingUploadName = null },
            title = { Text("上传文件") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(name, { name = it }, modifier = Modifier.fillMaxWidth(),
                        label = { Text("保存到仓库的文件名") }, singleLine = true)
                    OutlinedTextField(commitMessage, { commitMessage = it }, modifier = Modifier.fillMaxWidth(),
                        label = { Text("提交说明（可选）") }, singleLine = true, placeholder = { Text("Upload $defaultName") })
                    InfoText("当前目录：${vm.path.ifBlank { "仓库根目录" }}\n支持任意类型文件，单个最大 20 MB。")
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val uri = pendingUri
                    if (uri != null) vm.uploadUri(uri, vm.path, name, commitMessage)
                    pendingUploadName = null
                    pendingUri = null
                }, enabled = name.isNotBlank()) { Text("上传") }
            },
            dismissButton = { TextButton(onClick = { pendingUploadName = null }) { Text("取消") } }
        )
    }

    if (showNewFile) {
        var name by remember { mutableStateOf("") }
        var content by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showNewFile = false },
            title = { Text("新建文件") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(name, { name = it }, modifier = Modifier.fillMaxWidth(),
                        label = { Text("文件名") }, singleLine = true, placeholder = { Text("README.md") })
                    OutlinedTextField(content, { content = it }, modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp),
                        label = { Text("内容") })
                }
            },
            confirmButton = {
                TextButton(onClick = { vm.createTextFile(name, content); showNewFile = false },
                    enabled = name.isNotBlank()) { Text("创建") }
            },
            dismissButton = { TextButton(onClick = { showNewFile = false }) { Text("取消") } }
        )
    }

    if (showNewFolder) {
        TextInputDialog(
            title = "新建文件夹",
            label = "文件夹名称",
            hint = "会同时创建一个 .gitkeep 文件，因为 Git 不跟踪空目录",
            onDismiss = { showNewFolder = false },
            onConfirm = { vm.createFolder(it); showNewFolder = false }
        )
    }

    // 文件操作菜单
    menuEntry?.let { entry ->
        AlertDialog(
            onDismissRequest = { menuEntry = null },
            title = { Text(entry.name) },
            text = {
                Column {
                    if (!entry.isDir) {
                        TextButton(onClick = { vm.downloadEntry(entry); menuEntry = null }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Rounded.Download, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text("下载到手机")
                        }
                        TextButton(onClick = { vm.openFile(entry); menuEntry = null }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Rounded.Edit, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text("查看 / 编辑")
                        }
                        TextButton(onClick = { menuEntry = null; renameTarget = entry }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Rounded.EditNote, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text("重命名 / 移动")
                        }
                    }
                    TextButton(onClick = { vm.copy(entry.path); menuEntry = null }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Rounded.ContentCopy, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text("复制仓库内路径")
                    }
                    TextButton(onClick = { vm.copy(vm.fileWebUrl(entry)); menuEntry = null }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Rounded.Link, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text("复制网页地址")
                    }
                    TextButton(onClick = { onOpenUrl(vm.fileWebUrl(entry)); menuEntry = null }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Rounded.OpenInNew, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text("在浏览器打开")
                    }
                    TextButton(onClick = { menuEntry = null; deleteTarget = entry }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Rounded.DeleteOutline, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp))
                        Text("删除", color = MaterialTheme.colorScheme.error)
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { menuEntry = null }) { Text("关闭") } }
        )
    }

    renameTarget?.let { entry ->
        TextInputDialog(
            title = "重命名 / 移动",
            label = "新的完整路径",
            hint = "例如 src/Main.kt 或 ${entry.path}。GitHub 无重命名接口，将执行「复制到新路径 + 删除旧路径」，产生两次提交。",
            initial = entry.path,
            onDismiss = { renameTarget = null },
            onConfirm = { vm.renameEntry(entry, it); renameTarget = null }
        )
    }

    deleteTarget?.let { entry ->
        ConfirmDialog(
            title = if (entry.isDir) "删除文件夹？" else "删除文件？",
            text = if (entry.isDir) "「${entry.name}」及其下所有文件都会被删除，且不可恢复。"
            else "「${entry.name}」将从仓库删除。历史提交中仍会保留旧版本。",
            confirmLabel = "删除",
            onDismiss = { deleteTarget = null },
            onConfirm = { vm.deleteEntry(entry) }
        )
    }

    // 编辑器
    vm.editorPath?.let { EditorPanel(vm, it) }
}

@Composable
private fun FileItem(entry: ContentEntry, vm: AppViewModel, onMenu: (ContentEntry) -> Unit) {
    ItemCard(
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 5.dp),
        onClick = { if (entry.isDir) vm.openFolder(entry.path) else vm.openFile(entry) }
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                if (entry.isDir) Icons.Rounded.Folder else Icons.Rounded.Description,
                null,
                tint = if (entry.isDir) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(entry.name, style = MaterialTheme.typography.bodyMedium, maxLines = 2,
                    overflow = TextOverflow.Ellipsis)
                if (!entry.isDir) MetaLine(Helpers.size(entry.size), entry.path)
                else MetaLine("文件夹", entry.path)
            }
            IconButton(onClick = { onMenu(entry) }) { Icon(Icons.Rounded.MoreVert, null, Modifier.size(20.dp)) }
        }
    }
}

/** 文本编辑器：可直接改代码 / yml 并提交 */
@Composable
private fun EditorPanel(vm: AppViewModel, path: String) {
    var showCommit by remember { mutableStateOf(false) }
    var commitMessage by remember { mutableStateOf("") }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = vm::closeEditor, enabled = !vm.busy) {
                    Icon(Icons.Rounded.Close, "关闭")
                }
                Column(Modifier.weight(1f)) {
                    Text(path.substringAfterLast('/'), style = MaterialTheme.typography.titleSmall,
                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(path.substringBeforeLast('/'), style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1,
                        overflow = TextOverflow.Ellipsis)
                }
                TextButton(onClick = { showCommit = true }, enabled = vm.editorDirty && !vm.busy && !vm.editorBinary) {
                    Icon(Icons.Rounded.Check, null, Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("提交")
                }
                TextButton(onClick = { vm.downloadEntry(ContentEntry(path.substringAfterLast('/'), path, "file", 0, "", "", "")) },
                    enabled = !vm.busy) {
                    Icon(Icons.Rounded.Download, null, Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("下载")
                }
            }
            if (vm.editorBinary) {
                EmptyState(Icons.Rounded.Image, "二进制文件", "无法在应用内编辑，可点「下载」保存到手机")
            } else {
                OutlinedTextField(
                    vm.editorText, { vm.updateEditor(it) },
                    enabled = !vm.busy,
                    modifier = Modifier.weight(1f).fillMaxWidth().padding(10.dp),
                    shape = RoundedCornerShape(12.dp),
                    textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace)
                )
            }
        }
    }

    if (showCommit) {
        AlertDialog(
            onDismissRequest = { showCommit = false },
            title = { Text("提交修改") },
            text = {
                OutlinedTextField(commitMessage, { commitMessage = it }, modifier = Modifier.fillMaxWidth(),
                    label = { Text("提交说明") }, singleLine = true,
                    placeholder = { Text("Update ${path.substringAfterLast('/')}") })
            },
            confirmButton = {
                TextButton(onClick = { vm.saveEditor(commitMessage); showCommit = false }) { Text("提交") }
            },
            dismissButton = { TextButton(onClick = { showCommit = false }) { Text("取消") } }
        )
    }
}
