package com.ghub.manager.util

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipInputStream

object Helpers {

    /** 便于阅读的体积文案 */
    fun size(bytes: Long): String = when {
        bytes < 1024 -> "$bytes B"
        bytes < 1024 * 1024 -> "%.1f KB".format(bytes / 1024.0)
        bytes < 1024 * 1024 * 1024 -> "%.2f MB".format(bytes / 1048576.0)
        else -> "%.2f GB".format(bytes / 1073741824.0)
    }

    /** 把 2024-05-01T08:00:00Z 变成 2024-05-01 08:00 */
    fun time(iso: String): String {
        if (iso.isBlank()) return ""
        return iso.replace("T", " ").removeSuffix("Z").take(16)
    }

    fun mimeOf(name: String): String =
        MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substringAfterLast('.', ""))
            ?: "application/octet-stream"

    /**
     * 保存字节到公共 Downloads/GitHubManager 目录。
     * 使用 MediaStore，Android 10 及以上无需任何存储权限。
     * @return 用户可读的保存位置提示
     */
    fun saveToDownloads(context: Context, bytes: ByteArray, fileName: String, mime: String): String {
        val safeName = fileName.replace(Regex("[/\\\\:*?\"<>|]"), "_").ifBlank { "download" }
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, safeName)
            put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/GitHubManager")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val resolver = context.contentResolver
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("无法创建文件")
        return try {
            resolver.openOutputStream(uri)?.use { it.write(bytes) }
                ?: throw IllegalStateException("无法写入文件")
            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            "已保存到 下载/GitHubManager/$safeName"
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            throw e
        }
    }

    /**
     * GitHub 的运行日志是一个 zip（每个 step 一个文本文件）。
     * 这里解压并拼接成可阅读的文本，方便直接查看；同时保留 zip 供保存。
     */
    fun zipToText(bytes: ByteArray): String {
        val output = StringBuilder()
        ZipInputStream(ByteArrayInputStream(bytes)).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                if (entry.isDirectory) {
                    zip.closeEntry()
                    continue
                }
                output.append("\n===== ${entry.name} =====\n")
                val buffer = ByteArrayOutputStream()
                val tmp = ByteArray(8192)
                while (true) {
                    val n = zip.read(tmp)
                    if (n <= 0) break
                    buffer.write(tmp, 0, n)
                }
                output.append(buffer.toString("UTF-8"))
                zip.closeEntry()
            }
        }
        return if (output.isBlank()) "(日志为空，可能尚未开始或已过期)" else output.toString()
    }

    /** 从 zip 中挑出指定后缀的文件字节（例如从产物 zip 里直接取出 apk） */
    fun extractFirst(bytes: ByteArray, suffix: String): Pair<String, ByteArray>? {
        ZipInputStream(ByteArrayInputStream(bytes)).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                if (entry.isDirectory || !entry.name.endsWith(suffix, true)) {
                    zip.closeEntry()
                    continue
                }
                val buffer = ByteArrayOutputStream()
                val tmp = ByteArray(65536)
                while (true) {
                    val n = zip.read(tmp)
                    if (n <= 0) break
                    buffer.write(tmp, 0, n)
                }
                zip.closeEntry()
                return entry.name.substringAfterLast('/') to buffer.toByteArray()
            }
        }
        return null
    }

    /** 从 Uri 读取全部字节（用于上传） */
    fun readUri(context: Context, uri: Uri): ByteArray {
        val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: throw IllegalStateException("无法读取所选文件")
        if (bytes.isEmpty()) throw IllegalStateException("所选文件为空")
        return bytes
    }

    /** Uri 对应的显示名 */
    fun displayName(context: Context, uri: Uri): String {
        var name: String? = null
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (index >= 0) name = cursor.getString(index)
            }
        }
        return name ?: uri.lastPathSegment ?: "file"
    }

    /** 判断字节内容是否为文本（不含 0 字节，且能按 UTF-8 解码） */
    fun isText(bytes: ByteArray): Boolean {
        if (bytes.isEmpty()) return true
        if (bytes.any { it == 0.toByte() }) return false
        return runCatching { String(bytes, Charsets.UTF_8) }.isSuccess
    }
}
