package com.ghub.manager.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ghub.manager.vm.AppViewModel

@Composable
fun LoginScreen(vm: AppViewModel, onOpenUrl: (String) -> Unit) {
    var token by remember { mutableStateOf("") }
    var visible by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Spacer(Modifier.height(24.dp))
        Icon(Icons.Rounded.Code, null, Modifier.size(64.dp), tint = MaterialTheme.colorScheme.primary)
        Text("GitHub Manager", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(
            "上传、下载、删除、重命名、编译、取下载地址，一个应用全搞定",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(8.dp))

        OutlinedTextField(
            token, { token = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Personal Access Token") },
            placeholder = { Text("ghp_ 或 github_pat_ 开头") },
            singleLine = true,
            visualTransformation = if (visible) androidx.compose.ui.text.input.VisualTransformation.None
            else androidx.compose.ui.text.input.PasswordVisualTransformation(),
            trailingIcon = {
                IconButton(onClick = { visible = !visible }) {
                    Icon(if (visible) Icons.Rounded.Visibility else Icons.Rounded.VisibilityOff, null)
                }
            }
        )

        Button(
            onClick = { vm.login(token) },
            modifier = Modifier.fillMaxWidth().heightIn(min = 50.dp),
            enabled = token.isNotBlank() && !vm.busy
        ) { Text(if (vm.busy) "登录中…" else "登录") }

        TextButton(onClick = { onOpenUrl("https://github.com/settings/tokens/new?scopes=repo,workflow,read:org,delete_repo") }) {
            Icon(Icons.Rounded.Key, null, Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text("创建新令牌（自动勾选所需权限）")
        }

        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("令牌需要勾选：", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                InfoText("• repo —— 读写文件、删除、重命名、提交")
                InfoText("• workflow —— 触发编译、读取日志与产物")
                InfoText("• delete_repo —— 仅当你需要在应用内删除仓库")
                InfoText("• read:org —— 读取组织内的仓库列表")
            }
        }

        InfoText("令牌只保存在本应用的私有存储中，不会上传任何第三方服务器。")
        Spacer(Modifier.height(24.dp))
    }
}
