package com.ghub.manager.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.ghub.manager.vm.AppViewModel
import com.ghub.manager.vm.Screen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppRoot(vm: AppViewModel, onOpenUrl: (String) -> Unit, modifier: Modifier = Modifier) {
    val snackbar = remember { SnackbarHostState() }

    // 提示信息：一次性消费后弹出
    LaunchedEffect(vm.message) {
        val text = vm.message ?: return@LaunchedEffect
        snackbar.showSnackbar(text)
        vm.consumeMessage()
    }
    LaunchedEffect(vm.error) {
        val text = vm.error ?: return@LaunchedEffect
        snackbar.showSnackbar("出错了：$text")
        vm.consumeError()
    }

    androidx.compose.material3.Scaffold(
        modifier = modifier,
        snackbarHost = { SnackbarHost(snackbar) }
    ) { padding ->
        // padding 由各页面自行处理，这里避免嵌套 Scaffold 造成双重留白
        val unused = padding

        // 页面主体
        androidx.compose.foundation.layout.Box(Modifier.fillMaxSize()) {
            AnimatedContent(
                targetState = vm.screen,
                transitionSpec = {
                    slideInHorizontally { it } togetherWith slideOutHorizontally { -it }
                },
                label = "screen"
            ) { screen ->
                when (screen) {
                    Screen.LOGIN -> LoginScreen(vm, onOpenUrl)
                    Screen.REPOS -> ReposScreen(vm, onOpenUrl)
                    Screen.DETAIL -> DetailScreen(vm, onOpenUrl)
                }
            }

            // 日志查看器必须在最外层全屏渲染：放在编译页内部会随 HorizontalPager
            // 一起测量和滑动，导致「点击运行不显示、滑到相邻页才显示」。
            if (vm.logViewerOpen && vm.logText != null) {
                LogViewer(vm)
            }
        }
    }
}
