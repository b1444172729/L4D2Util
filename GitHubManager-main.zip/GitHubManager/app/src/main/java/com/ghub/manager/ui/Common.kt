package com.ghub.manager.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.ghub.manager.util.Helpers

/** 顶部标题 + 可选操作区 */
@Composable
fun SectionHeader(title: String, subtitle: String = "", actions: @Composable RowScope.() -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            if (subtitle.isNotBlank()) {
                Text(subtitle, style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2,
                    overflow = TextOverflow.Ellipsis)
            }
        }
        Row(content = actions)
    }
}

/** 空状态占位 */
@Composable
fun EmptyState(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String = "") {
    Column(
        Modifier.fillMaxWidth().padding(vertical = 48.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(icon, null, Modifier.size(48.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f))
        Text(title, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (subtitle.isNotBlank()) {
            Text(subtitle, style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f))
        }
    }
}

/** 忙碌进度条 */
@Composable
fun BusyBar(label: String) {
    AnimatedVisibility(visible = label.isNotBlank(), enter = fadeIn(), exit = fadeOut()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(10.dp))
            LinearProgressIndicator(Modifier.weight(1f).height(3.dp))
        }
    }
}

/** 单行文本输入对话框 */
@Composable
fun TextInputDialog(
    title: String,
    label: String,
    hint: String = "",
    initial: String = "",
    singleLine: Boolean = true,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(
                    text, { text = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text(label) },
                    singleLine = singleLine,
                    maxLines = if (singleLine) 1 else 8
                )
                if (hint.isNotBlank()) {
                    Text(hint, style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(text) }, enabled = text.isNotBlank()) { Text("确定") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("取消") } }
    )
}

/** 危险操作确认框 */
@Composable
fun ConfirmDialog(title: String, text: String, confirmLabel: String = "确定", onDismiss: () -> Unit, onConfirm: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(text) },
        confirmButton = {
            TextButton(onClick = { onConfirm(); onDismiss() }) {
                Text(confirmLabel, color = MaterialTheme.colorScheme.error)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("取消") } }
    )
}

/** 通用卡片容器 */
@Composable
fun ItemCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(16.dp)
    val border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
    val base = modifier.fillMaxWidth()
    if (onClick != null) {
        Surface(onClick = onClick, shape = shape, border = border,
            color = MaterialTheme.colorScheme.surfaceContainerLow, modifier = base) {
            Column(Modifier.padding(14.dp), content = content)
        }
    } else {
        Surface(shape = shape, border = border,
            color = MaterialTheme.colorScheme.surfaceContainerLow, modifier = base) {
            Column(Modifier.padding(14.dp), content = content)
        }
    }
}

/** 状态小标签 */
@Composable
fun StatusChip(text: String, color: androidx.compose.ui.graphics.Color) {
    Surface(shape = RoundedCornerShape(50), color = color.copy(alpha = 0.15f)) {
        Text(
            text,
            Modifier.padding(horizontal = 9.dp, vertical = 3.dp),
            style = MaterialTheme.typography.labelSmall,
            color = color,
            maxLines = 1
        )
    }
}

@Composable
@ReadOnlyComposable
fun statusColor(status: String, conclusion: String): androidx.compose.ui.graphics.Color {
    if (status != "completed") return MaterialTheme.colorScheme.primary
    return when (conclusion) {
        "success" -> androidx.compose.ui.graphics.Color(0xFF2E7D32)
        "failure" -> MaterialTheme.colorScheme.error
        "cancelled" -> MaterialTheme.colorScheme.onSurfaceVariant
        "timed_out" -> MaterialTheme.colorScheme.error
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }
}

/** 面包屑：显示当前所在目录层级 */
@Composable
fun Breadcrumbs(path: String, onNavigate: (String) -> Unit) {
    val parts = path.split('/').filter { it.isNotBlank() }
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())
            .padding(horizontal = 12.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TextButton(onClick = { onNavigate("") }) { Text("根目录") }
        var acc = ""
        parts.forEachIndexed { index, part ->
            acc = if (acc.isBlank()) part else "$acc/$part"
            val target = acc
            Icon(Icons.Rounded.ChevronRight, null, Modifier.size(14.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant)
            TextButton(onClick = { onNavigate(target) }) { Text(part, maxLines = 1) }
            if (index == parts.lastIndex) Spacer(Modifier.width(2.dp))
        }
    }
}

/** 体积 / 时间的次要信息行 */
@Composable
fun MetaLine(vararg items: String) {
    val text = items.filter { it.isNotBlank() }.joinToString(" · ")
    if (text.isNotBlank()) {
        Text(text, style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

/** 复制按钮 */
@Composable
fun CopyButton(text: String, label: String = "复制", onCopy: (String) -> Unit) {
    TextButton(onClick = { onCopy(text) }) {
        Icon(Icons.Rounded.ContentCopy, null, Modifier.size(16.dp))
        Spacer(Modifier.width(5.dp))
        Text(label)
    }
}

@Composable
fun InfoText(text: String) {
    Text(text, style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant)
}

fun formatSize(bytes: Long) = Helpers.size(bytes)
