package com.ghub.manager.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.ghub.manager.data.Artifact
import com.ghub.manager.data.LogLevel
import com.ghub.manager.data.TransferKind
import com.ghub.manager.data.Workflow
import com.ghub.manager.data.WorkflowRun
import com.ghub.manager.util.Helpers
import com.ghub.manager.vm.AppViewModel
import com.ghub.manager.vm.Tab
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ActionsScreen(vm: AppViewModel, onOpenUrl: (String) -> Unit) {
    var dispatchTarget by remember { mutableStateOf<Workflow?>(null) }
    var linkTarget by remember { mutableStateOf<Artifact?>(null) }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
            item {
                SectionHeader("工作流", "${vm.workflows.size} 个 · 可手动触发编译") {
                    IconButton(onClick = vm::loadActions, enabled = !vm.busy) {
                        Icon(Icons.Rounded.Refresh, "刷新")
                    }
                }
            }
            if (vm.workflows.isEmpty()) {
                item {
                    EmptyState(Icons.Rounded.Terminal, "没有工作流",
                        "仓库里需要有 .github/workflows/*.yml，上传一个即可在这里编译")
                }
            }
            items(vm.workflows, key = { it.id }) { workflow ->
                WorkflowCard(workflow, vm) { dispatchTarget = workflow }
            }

            item { SectionHeader("运行记录", "查看日志与产物") }

            if (vm.runs.isEmpty() && !vm.busy) {
                item { EmptyState(Icons.Rounded.History, "暂无运行记录", "触发一次工作流后会自动出现") }
            }
            items(vm.runs, key = { it.id }) { run ->
                RunCard(run, vm, selected = run.id == vm.selectedRunId, onOpenUrl = onOpenUrl)
            }

            // 选中运行后的详情区
            if (vm.selectedRunId != null) {
                item { RunDetail(vm, { linkTarget = it }, vm::cancelRun, onOpenUrl) }
            }
        }
    }

    dispatchTarget?.let { workflow ->
        var ref by remember { mutableStateOf(vm.branch.ifBlank { "main" }) }
        AlertDialog(
            onDismissRequest = { dispatchTarget = null },
            title = { Text("运行 ${workflow.name}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(ref, { ref = it }, modifier = Modifier.fillMaxWidth(),
                        label = { Text("分支 / 标签") }, singleLine = true)
                    InfoText("文件：${workflow.path}\n触发后约几秒才会出现在运行列表，可下拉刷新。")
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.triggerWorkflow(workflow, ref, emptyMap())
                    dispatchTarget = null
                }, enabled = ref.isNotBlank()) { Text("开始运行") }
            },
            dismissButton = { TextButton(onClick = { dispatchTarget = null }) { Text("取消") } }
        )
    }

    linkTarget?.let { artifact ->
        val options = vm.artifactLinks(artifact)
        AlertDialog(
            onDismissRequest = { linkTarget = null },
            title = { Text("下载地址 · ${artifact.name}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    options.forEach { (label, value) ->
                        OutlinedButton(onClick = { vm.copy(value, label) }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Rounded.ContentCopy, null, Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(label, maxLines = 1)
                        }
                    }
                    OutlinedButton(onClick = { vm.resolveArtifactUrl(artifact) }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Rounded.Link, null, Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("复制最终直链（解析 302）")
                    }
                    InfoText("网页链接：手机浏览器登录 GitHub 后可直接下载；API 直链与 curl 含令牌，请勿外传。")
                }
            },
            confirmButton = { TextButton(onClick = { linkTarget = null }) { Text("关闭") } },
            dismissButton = null
        )
    }

    // 注意：日志查看器不再放在这里渲染。
    // 原先 `vm.logText?.let { LogViewer(vm) }` 是本页 Box 内的浮层，会随 HorizontalPager
    // 一起被测量和滑动，出现「点运行不显示、滑到相邻页一半才显示」的问题。
    // 现在改由 AppRoot 在最外层全屏渲染，见 vm.logViewerOpen。
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun WorkflowCard(workflow: Workflow, vm: AppViewModel, onRun: () -> Unit) {
    ItemCard(modifier = Modifier.padding(horizontal = 16.dp, vertical = 5.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(13.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(
                                MaterialTheme.colorScheme.primary,
                                MaterialTheme.colorScheme.tertiary
                            )
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Rounded.PlayCircleOutline, null, Modifier.size(21.dp),
                    tint = MaterialTheme.colorScheme.onPrimary
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    workflow.name,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(2.dp))
                MetaLine(workflow.path, workflow.state)
            }
            Spacer(Modifier.width(6.dp))
            Button(
                onClick = onRun,
                enabled = !vm.busy && workflow.state == "active",
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Rounded.PlayArrow, null, Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("运行", fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RunCard(run: WorkflowRun, vm: AppViewModel, selected: Boolean, onOpenUrl: (String) -> Unit) {
    val color = statusColor(run.status, run.conclusion)
    val border = if (selected) androidx.compose.foundation.BorderStroke(2.dp, MaterialTheme.colorScheme.primary)
    else androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
    Surface(
        onClick = { vm.selectRun(run) },
        shape = RoundedCornerShape(16.dp),
        border = border,
        color = if (selected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceContainerLow,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                DotStatusChip(run.displayStatus, color)
                Spacer(Modifier.width(8.dp))
                Text("#${run.number}", style = MaterialTheme.typography.labelMedium)
                Spacer(Modifier.weight(1f))
                IconButton(onClick = { onOpenUrl(run.htmlUrl) }, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Rounded.OpenInNew, null, Modifier.size(16.dp))
                }
            }
            Spacer(Modifier.height(6.dp))
            Text(run.name, style = MaterialTheme.typography.bodyMedium, maxLines = 2,
                overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(4.dp))
            MetaLine(run.branch, run.event, run.sha, Helpers.time(run.createdAt))
            if (run.status != "completed") {
                Spacer(Modifier.height(4.dp))
                Text(
                    "进行中 · 点击查看实时日志",
                    style = MaterialTheme.typography.labelSmall,
                    color = color
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RunDetail(
    vm: AppViewModel,
    onLinks: (Artifact) -> Unit,
    onCancel: () -> Unit,
    onOpenUrl: (String) -> Unit
) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
        HorizontalDivider(Modifier.padding(vertical = 8.dp))
        SectionHeader("本次运行", "运行 #${vm.selectedRunId}")

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = vm::viewLogs, modifier = Modifier.weight(1f), enabled = !vm.busy) {
                Icon(Icons.Rounded.Description, null, Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("查看日志")
            }
            OutlinedButton(onClick = vm::saveLogs, modifier = Modifier.weight(1f), enabled = !vm.busy) {
                Icon(Icons.Rounded.Download, null, Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("保存日志")
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { vm.rerunRun(false) }, modifier = Modifier.weight(1f), enabled = !vm.busy) {
                Icon(Icons.Rounded.Refresh, null, Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("重跑")
            }
            OutlinedButton(onClick = { vm.rerunRun(true) }, modifier = Modifier.weight(1f), enabled = !vm.busy) {
                Icon(Icons.Rounded.Refresh, null, Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("跑失败")
            }
            OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f), enabled = !vm.busy) {
                Icon(Icons.Rounded.Cancel, null, Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("取消")
            }
        }

        // 日志摘要：选中运行后直接展示，不必再点一次「查看日志」
        val bundle = vm.logBundle
        if (bundle != null) {
            SectionHeader("日志摘要", "重点 ${bundle.key.size} · 错误 ${bundle.errors.size} · 警告 ${bundle.warnings.size}")
            ItemCard {
                val preview = if (bundle.errors.isNotEmpty()) bundle.errors.takeLast(8)
                else bundle.key.takeLast(8)
                preview.forEach { line ->
                    Text(
                        line,
                        style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        color = if (bundle.errors.isNotEmpty()) MaterialTheme.colorScheme.error
                        else MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(Modifier.height(2.dp))
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = vm::openLogViewer, modifier = Modifier.weight(1f), enabled = !vm.busy) {
                        Icon(Icons.Rounded.Description, null, Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("打开完整日志")
                    }
                    OutlinedButton(onClick = { vm.copy(bundle.raw, "完整日志") }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Rounded.ContentCopy, null, Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("复制全文")
                    }
                }
                OutlinedButton(onClick = vm::saveLogs, modifier = Modifier.fillMaxWidth(), enabled = !vm.busy) {
                    Icon(Icons.Rounded.Download, null, Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("下载完整日志（zip + txt）")
                }
            }
        } else if (vm.logError != null) {
            // 失败原因直接摆在界面上，并提供重试 / 浏览器打开 / 按任务查看 三种出路
            SectionHeader("日志加载失败", "可按下面提示处理")
            ItemCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.ErrorOutline, null, Modifier.size(18.dp),
                        tint = MaterialTheme.colorScheme.error)
                    Spacer(Modifier.width(6.dp))
                    Text("日志加载失败", style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.error)
                }
                Spacer(Modifier.height(6.dp))
                Text(vm.logError.orEmpty(),
                    style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = vm::viewLogs, modifier = Modifier.weight(1f), enabled = !vm.busy) {
                        Icon(Icons.Rounded.Refresh, null, Modifier.size(15.dp))
                        Spacer(Modifier.width(4.dp)); Text("重试")
                    }
                    OutlinedButton(onClick = {
                        val run = vm.runs.firstOrNull { it.id == vm.selectedRunId }
                        if (run != null) onOpenUrl(run.htmlUrl)
                    }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Rounded.OpenInNew, null, Modifier.size(15.dp))
                        Spacer(Modifier.width(4.dp)); Text("浏览器打开")
                    }
                }
                Spacer(Modifier.height(6.dp))
                InfoText("若整体日志一直下不来，可点下方「任务」里的「日志」按钮，按单个任务分别查看。")
            }
        } else if (!vm.busy) {
            EmptyState(Icons.Rounded.Description, "暂无日志",
                "运行可能尚未开始，或日志已过期（GitHub 只保留 90 天）")
        }

        if (vm.jobs.isNotEmpty()) {
            SectionHeader("任务", "${vm.jobs.size} 个 · 可单独看日志")
            vm.jobs.forEach { job ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StatusChip(
                        if (job.status == "completed") when (job.conclusion) {
                            "success" -> "成功"; "failure" -> "失败"; else -> job.conclusion
                        } else job.status,
                        statusColor(job.status, job.conclusion)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(job.name, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall,
                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                    TextButton(onClick = { vm.viewJobLogs(job) }, enabled = !vm.busy) { Text("日志") }
                }
            }
        }

        SectionHeader("构建产物", "${vm.artifacts.size} 个 · 可复制下载地址或保存到手机")
        if (vm.artifacts.isEmpty()) {
            EmptyState(Icons.Rounded.Inventory2, "暂无产物",
                "工作流里需要有 actions/upload-artifact 步骤才会产出")
        }
        vm.artifacts.forEach { artifact ->
            ItemCard(modifier = Modifier.padding(vertical = 5.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(13.dp))
                            .background(
                                Brush.linearGradient(
                                    listOf(
                                        MaterialTheme.colorScheme.tertiary,
                                        MaterialTheme.colorScheme.primary
                                    )
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Rounded.Inventory2, null, Modifier.size(21.dp),
                            tint = MaterialTheme.colorScheme.onPrimary
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            artifact.name,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            maxLines = 2
                        )
                        MetaLine(Helpers.size(artifact.sizeInBytes), Helpers.time(artifact.createdAt),
                            if (artifact.expired) "已过期" else "")
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            vm.startTransfer(artifact, TransferKind.APK)
                            vm.switchTab(Tab.DOWNLOADS)
                        },
                        modifier = Modifier.weight(1f).heightIn(min = 46.dp),
                        enabled = !artifact.expired,
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(Icons.Rounded.Android, null, Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("下载APK")
                    }
                    Button(
                        onClick = {
                            vm.startTransfer(artifact, TransferKind.ZIP)
                            vm.switchTab(Tab.DOWNLOADS)
                        },
                        modifier = Modifier.weight(1f).heightIn(min = 46.dp),
                        enabled = !artifact.expired,
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(Icons.Rounded.Inventory2, null, Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("下载ZIP")
                    }
                }
                OutlinedButton(onClick = { onLinks(artifact) }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Rounded.Link, null, Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("复制下载地址")
                }
            }
        }
    }
}

/**
 * 日志查看器：重点 / 错误 / 警告 / 完整 四档切换，
 * 支持紧跟最新（自动刷新并滚到底部）、复制与下载。
 */
@Composable
fun LogViewer(vm: AppViewModel) {
    var level by remember { mutableStateOf(LogLevel.KEY) }
    var follow by remember { mutableStateOf(true) }
    var copied by remember { mutableStateOf(false) }

    // 全屏浮层：拦截系统返回键，先关闭日志，避免直接退出仓库页面
    androidx.activity.compose.BackHandler(enabled = true) { vm.closeLogViewer() }

    val bundle = vm.logBundle
    val lines = bundle?.linesOf(level).orEmpty()
    val vertical = rememberScrollState()
    val horizontal = rememberScrollState()

    // 紧跟最新：内容变化或切换分类时自动滚到底部
    LaunchedEffect(lines.size, level, follow) {
        if (follow) {
            vertical.animateScrollTo(vertical.maxValue)
        }
    }

    // 运行状态：queued / in_progress 都算「进行中」，需要持续跟进
    val selected = vm.runs.firstOrNull { it.id == vm.selectedRunId }
    val running = selected != null && selected.status != "completed"

    // 紧跟最新开启且运行未结束时，交给 ViewModel 每 5 秒轮询一次（不占用 busy）
    LaunchedEffect(vm.selectedRunId, follow, running) {
        if (follow && running) vm.startLogPolling(5000L) else vm.stopLogPolling()
    }
    DisposableEffect(Unit) { onDispose { vm.stopLogPolling() } }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxSize()) {
            // 顶栏：关闭 / 标题。全屏浮层需自行避让状态栏，否则会被刘海 / 状态栏盖住
            Row(
                Modifier.fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = vm::closeLogViewer) { Icon(Icons.Rounded.Close, "关闭") }
                Column(Modifier.weight(1f)) {
                    Text(vm.logTitle, style = MaterialTheme.typography.titleSmall,
                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                    // 第一行：下载体积 / 耗时 / 行数
                    val info = vm.logInfo ?: bundle?.let { "原始 ${Helpers.size(it.sizeBytes)}" }.orEmpty()
                    if (info.isNotBlank()) {
                        Text(
                            info,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    // 第二行：分级统计。与上一行同样左对齐，避免全部挤在一行被截断
                    bundle?.let {
                        Text(
                            "重点 ${it.key.size} · 错误 ${it.errors.size} · 警告 ${it.warnings.size}" +
                                if (running) " · 运行中" else "",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            // 分类切换 + 紧跟最新
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())
                    .padding(horizontal = 10.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                LogChip("重点", LogLevel.KEY, level) { level = it }
                Spacer(Modifier.width(6.dp))
                LogChip("错误", LogLevel.ERROR, level) { level = it }
                Spacer(Modifier.width(6.dp))
                LogChip("警告", LogLevel.WARNING, level) { level = it }
                Spacer(Modifier.width(6.dp))
                LogChip("完整", LogLevel.ALL, level) { level = it }
                Spacer(Modifier.width(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = follow, onCheckedChange = { follow = it }, Modifier.height(24.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("紧跟最新", style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            // 操作：三个按钮原本挤在一行，文字只能显示「复制完 / 复制本 / 下载完」。
            // 改成两行布局，按钮文字即可完整展示。
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        vm.copy(vm.logText.orEmpty(), "完整日志")
                        copied = true
                    },
                    modifier = Modifier.weight(1f).heightIn(min = 44.dp)
                ) {
                    Icon(Icons.Rounded.ContentCopy, null, Modifier.size(15.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(if (copied) "已复制" else "复制完整输出", maxLines = 1)
                }
                OutlinedButton(
                    onClick = { vm.copy(lines.joinToString("\n"), "日志") },
                    modifier = Modifier.weight(1f).heightIn(min = 44.dp)
                ) {
                    Icon(Icons.Rounded.ContentCopy, null, Modifier.size(15.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("复制本页", maxLines = 1)
                }
            }
            OutlinedButton(
                onClick = vm::saveLogs,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 44.dp)
                    .padding(horizontal = 10.dp, vertical = 2.dp),
                enabled = !vm.busy
            ) {
                Icon(Icons.Rounded.Download, null, Modifier.size(15.dp))
                Spacer(Modifier.width(6.dp))
                Text("下载完整日志", maxLines = 1)
            }

            // 内容区
            if (bundle == null && !running) {
                // 既没日志也没在跑：多半是拉取失败，把原因摆出来
                EmptyState(
                    Icons.Rounded.ErrorOutline,
                    "暂无日志",
                    vm.logError ?: "点上方「刷新」重新拉取，或确认令牌包含 Actions 读权限"
                )
            } else if (lines.isEmpty()) {
                EmptyState(
                    Icons.Rounded.Description,
                    if (running) "等待日志产出…" else "该分类下没有内容",
                    if (running) "任务刚启动，日志稍后自动出现（无需手动刷新）"
                    else if (level == LogLevel.ERROR) "没有错误行，构建可能是成功的"
                    else "尝试切换到「完整」查看全部输出"
                )
            } else {
                Surface(
                    Modifier.fillMaxSize().padding(8.dp)
                        .verticalScroll(vertical)
                        .horizontalScroll(horizontal),
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerLow
                ) {
                    Text(
                        lines.joinToString("\n"),
                        Modifier.padding(12.dp),
                        style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace)
                    )
                }
            }
        }
    }
}

@Composable
fun LogChip(label: String, target: LogLevel, current: LogLevel, onSelect: (LogLevel) -> Unit) {
    FilterChip(
        selected = current == target,
        onClick = { onSelect(target) },
        label = { Text(label, style = MaterialTheme.typography.labelMedium) }
    )
}