package com.ghub.manager.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.ghub.manager.data.Artifact
import com.ghub.manager.data.LogLevel
import com.ghub.manager.data.Workflow
import com.ghub.manager.data.WorkflowRun
import com.ghub.manager.util.Helpers
import com.ghub.manager.vm.AppViewModel
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ActionsScreen(vm: AppViewModel, onOpenUrl: (String) -> Unit) {
    var dispatchTarget by remember { mutableStateOf<Workflow?>(null) }
    var linkTarget by remember { mutableStateOf<Artifact?>(null) }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
            item {
                SectionHeader("工作流", "${vm.workflows.size} 个 · 可手动触发编译") {
                    IconButton(onClick = vm::loadActions, enabled = !vm.busy) {
                        Icon(Icons.Rounded.Refresh, "刷新")
                    }
                }
            }
            if (vm.workflows.isEmpty()) {
                item {
                    EmptyState(Icons.Rounded.Terminal, "没有工作流",
                        "仓库里需要有 .github/workflows/*.yml，上传一个即可在这里编译")
                }
            }
            items(vm.workflows, key = { it.id }) { workflow ->
                WorkflowCard(workflow, vm) { dispatchTarget = workflow }
            }

            item { SectionHeader("运行记录", "点击一次运行可查看日志与产物") }

            if (vm.runs.isEmpty() && !vm.busy) {
                item { EmptyState(Icons.Rounded.History, "暂无运行记录", "触发一次工作流后会自动出现") }
            }
            items(vm.runs, key = { it.id }) { run ->
                RunCard(run, vm, selected = run.id == vm.selectedRunId, onOpenUrl = onOpenUrl)
            }

            // 选中运行后的详情区
            if (vm.selectedRunId != null) {
                item { RunDetail(vm, { linkTarget = it }, vm::cancelRun) }
            }
        }
    }

    dispatchTarget?.let { workflow ->
        var ref by remember { mutableStateOf(vm.branch.ifBlank { "main" }) }
        AlertDialog(
            onDismissRequest = { dispatchTarget = null },
            title = { Text("运行 ${workflow.name}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(ref, { ref = it }, modifier = Modifier.fillMaxWidth(),
                        label = { Text("分支 / 标签") }, singleLine = true)
                    InfoText("文件：${workflow.path}\n触发后约几秒才会出现在运行列表，可下拉刷新。")
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.triggerWorkflow(workflow, ref, emptyMap())
                    dispatchTarget = null
                }, enabled = ref.isNotBlank()) { Text("开始运行") }
            },
            dismissButton = { TextButton(onClick = { dispatchTarget = null }) { Text("取消") } }
        )
    }

    linkTarget?.let { artifact ->
        val options = vm.artifactLinks(artifact)
        AlertDialog(
            onDismissRequest = { linkTarget = null },
            title = { Text("下载地址 · ${artifact.name}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    options.forEach { (label, value) ->
                        OutlinedButton(onClick = { vm.copy(value, label) }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Rounded.ContentCopy, null, Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(label, maxLines = 1)
                        }
                    }
                    OutlinedButton(onClick = { vm.resolveArtifactUrl(artifact) }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Rounded.Link, null, Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("复制最终直链（解析 302）")
                    }
                    InfoText("网页链接：手机浏览器登录 GitHub 后可直接下载；API 直链与 curl 含令牌，请勿外传。")
                }
            },
            confirmButton = { TextButton(onClick = { linkTarget = null }) { Text("关闭") } },
            dismissButton = null
        )
    }

    vm.logText?.let { LogViewer(vm) }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun WorkflowCard(workflow: Workflow, vm: AppViewModel, onRun: () -> Unit) {
    ItemCard(modifier = Modifier.padding(horizontal = 16.dp, vertical = 5.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.PlayCircleOutline, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(workflow.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                MetaLine(workflow.path, workflow.state)
            }
            Button(onClick = onRun, enabled = !vm.busy && workflow.state == "active") {
                Icon(Icons.Rounded.PlayArrow, null, Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("运行")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RunCard(run: WorkflowRun, vm: AppViewModel, selected: Boolean, onOpenUrl: (String) -> Unit) {
    val color = statusColor(run.status, run.conclusion)
    val border = if (selected) androidx.compose.foundation.BorderStroke(2.dp, MaterialTheme.colorScheme.primary)
    else androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
    Surface(
        onClick = { vm.selectRun(run) },
        shape = RoundedCornerShape(16.dp),
        border = border,
        color = if (selected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceContainerLow,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                StatusChip(run.displayStatus, color)
                Spacer(Modifier.width(8.dp))
                Text("#${run.number}", style = MaterialTheme.typography.labelMedium)
                Spacer(Modifier.weight(1f))
                IconButton(onClick = { onOpenUrl(run.htmlUrl) }, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Rounded.OpenInNew, null, Modifier.size(16.dp))
                }
            }
            Spacer(Modifier.height(6.dp))
            Text(run.name, style = MaterialTheme.typography.bodyMedium, maxLines = 2,
                overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(4.dp))
            MetaLine(run.branch, run.event, run.sha, Helpers.time(run.createdAt))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RunDetail(vm: AppViewModel, onLinks: (Artifact) -> Unit, onCancel: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
        HorizontalDivider(Modifier.padding(vertical = 8.dp))
        SectionHeader("本次运行", "运行 #${vm.selectedRunId}")

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = vm::viewLogs, modifier = Modifier.weight(1f), enabled = !vm.busy) {
                Icon(Icons.Rounded.Description, null, Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("查看日志")
            }
            OutlinedButton(onClick = vm::saveLogs, modifier = Modifier.weight(1f), enabled = !vm.busy) {
                Icon(Icons.Rounded.Download, null, Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("保存日志")
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { vm.rerunRun(false) }, modifier = Modifier.weight(1f), enabled = !vm.busy) {
                Icon(Icons.Rounded.Refresh, null, Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("重跑")
            }
            OutlinedButton(onClick = { vm.rerunRun(true) }, modifier = Modifier.weight(1f), enabled = !vm.busy) {
                Icon(Icons.Rounded.Refresh, null, Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("重跑失败")
            }
            OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f), enabled = !vm.busy) {
                Icon(Icons.Rounded.Cancel, null, Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("取消")
            }
        }

        // 日志摘要：选中运行后直接展示，不必再点一次「查看日志」
        val bundle = vm.logBundle
        if (bundle != null) {
            SectionHeader("日志摘要", "重点 ${bundle.key.size} · 错误 ${bundle.errors.size} · 警告 ${bundle.warnings.size}")
            ItemCard {
                val preview = if (bundle.errors.isNotEmpty()) bundle.errors.takeLast(8)
                else bundle.key.takeLast(8)
                preview.forEach { line ->
                    Text(
                        line,
                        style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        color = if (bundle.errors.isNotEmpty()) MaterialTheme.colorScheme.error
                        else MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(Modifier.height(2.dp))
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = vm::viewLogs, modifier = Modifier.weight(1f), enabled = !vm.busy) {
                        Icon(Icons.Rounded.Description, null, Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("打开完整日志")
                    }
                    OutlinedButton(onClick = { vm.copy(bundle.raw, "完整日志") }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Rounded.ContentCopy, null, Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("复制全文")
                    }
                }
                OutlinedButton(onClick = vm::saveLogs, modifier = Modifier.fillMaxWidth(), enabled = !vm.busy) {
                    Icon(Icons.Rounded.Download, null, Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("下载完整日志（zip + txt）")
                }
            }
        } else if (!vm.busy) {
            EmptyState(Icons.Rounded.Description, "暂无日志",
                "运行可能尚未开始，或令牌缺少 workflow 权限")
        }

        if (vm.jobs.isNotEmpty()) {
            SectionHeader("任务", "${vm.jobs.size} 个 · 可单独看日志")
            vm.jobs.forEach { job ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StatusChip(
                        if (job.status == "completed") when (job.conclusion) {
                            "success" -> "成功"; "failure" -> "失败"; else -> job.conclusion
                        } else job.status,
                        statusColor(job.status, job.conclusion)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(job.name, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall,
                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                    TextButton(onClick = { vm.viewJobLogs(job) }, enabled = !vm.busy) { Text("日志") }
                }
            }
        }

        SectionHeader("构建产物", "${vm.artifacts.size} 个 · 可复制下载地址或保存到手机")
        if (vm.artifacts.isEmpty()) {
            EmptyState(Icons.Rounded.Inventory2, "暂无产物",
                "工作流里需要有 actions/upload-artifact 步骤才会产出")
        }
        vm.artifacts.forEach { artifact ->
            ItemCard(modifier = Modifier.padding(vertical = 5.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Inventory2, null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(artifact.name, style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold, maxLines = 2)
                        MetaLine(Helpers.size(artifact.sizeInBytes), Helpers.time(artifact.createdAt),
                            if (artifact.expired) "已过期" else "")
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.downloadArtifact(artifact, true) }, modifier = Modifier.weight(1f),
                        enabled = !vm.busy && !artifact.expired) {
                        Icon(Icons.Rounded.Android, null, Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("存 APK")
                    }
                    OutlinedButton(onClick = { vm.downloadArtifact(artifact, false) }, modifier = Modifier.weight(1f),
                        enabled = !vm.busy && !artifact.expired) {
                        Text("存 ZIP")
                    }
                }
                OutlinedButton(onClick = { onLinks(artifact) }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Rounded.Link, null, Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("复制下载地址")
                }
            }
        }
    }
}

/**
 * 日志查看器：重点 / 错误 / 警告 / 完整 四档切换，
 * 支持紧跟最新（自动刷新并滚到底部）、复制与下载。
 */
@Composable
private fun LogViewer(vm: AppViewModel) {
    var level by remember { mutableStateOf(LogLevel.KEY) }
    var follow by remember { mutableStateOf(true) }
    var copied by remember { mutableStateOf(false) }

    val bundle = vm.logBundle
    val lines = bundle?.linesOf(level).orEmpty()
    val vertical = rememberScrollState()
    val horizontal = rememberScrollState()

    // 紧跟最新：内容变化或切换分类时自动滚到底部
    LaunchedEffect(lines.size, level, follow) {
        if (follow) {
            vertical.animateScrollTo(vertical.maxValue)
        }
    }

    // 运行未结束时定时自动刷新（约 10 秒一次），实现日志实时跟进
    val selected = vm.runs.firstOrNull { it.id == vm.selectedRunId }
    val running = selected != null && selected.status != "completed"
    LaunchedEffect(vm.selectedRunId, follow, running) {
        while (follow && running && vm.selectedRunId != null) {
            delay(10_000L)
            vm.pollSelectedRun()
        }
    }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxSize()) {
            // 顶栏：关闭 / 标题 / 复制 / 下载
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = vm::clearLogs) { Icon(Icons.Rounded.Close, "关闭日志") }
                Column(Modifier.weight(1f)) {
                    Text(vm.logTitle, style = MaterialTheme.typography.titleSmall,
                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                    bundle?.let {
                        Text(
                            "原始 ${Helpers.size(it.sizeBytes)} · 重点 ${it.key.size} · 错误 ${it.errors.size} · 警告 ${it.warnings.size}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            // 分类切换 + 紧跟最新
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())
                    .padding(horizontal = 10.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                LogChip("重点", LogLevel.KEY, level) { level = it }
                Spacer(Modifier.width(6.dp))
                LogChip("错误", LogLevel.ERROR, level) { level = it }
                Spacer(Modifier.width(6.dp))
                LogChip("警告", LogLevel.WARNING, level) { level = it }
                Spacer(Modifier.width(6.dp))
                LogChip("完整", LogLevel.ALL, level) { level = it }
                Spacer(Modifier.width(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = follow, onCheckedChange = { follow = it }, Modifier.height(24.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("紧跟最新", style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            // 操作：复制完整输出 / 复制当前分类 / 下载完整日志
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                OutlinedButton(onClick = {
                    vm.copy(vm.logText.orEmpty(), "完整日志")
                    copied = true
                }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Rounded.ContentCopy, null, Modifier.size(15.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(if (copied) "已复制" else "复制完整输出", maxLines = 1)
                }
                OutlinedButton(onClick = { vm.copy(lines.joinToString("\n"), "日志") },
                    modifier = Modifier.weight(1f)) {
                    Icon(Icons.Rounded.ContentCopy, null, Modifier.size(15.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("复制本页", maxLines = 1)
                }
                OutlinedButton(onClick = vm::saveLogs, modifier = Modifier.weight(1f), enabled = !vm.busy) {
                    Icon(Icons.Rounded.Download, null, Modifier.size(15.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("下载完整日志", maxLines = 1)
                }
            }

            // 内容区
            if (lines.isEmpty()) {
                EmptyState(Icons.Rounded.Description, "该分类下没有内容",
                    if (level == LogLevel.ERROR) "没有错误行，构建可能是成功的" else "尝试切换到「完整」查看全部输出")
            } else {
                Surface(
                    Modifier.fillMaxSize().padding(8.dp)
                        .verticalScroll(vertical)
                        .horizontalScroll(horizontal),
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerLow
                ) {
                    Text(
                        lines.joinToString("\n"),
                        Modifier.padding(12.dp),
                        style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace)
                    )
                }
            }
        }
    }
}

@Composable
private fun LogChip(label: String, target: LogLevel, current: LogLevel, onSelect: (LogLevel) -> Unit) {
    FilterChip(
        selected = current == target,
        onClick = { onSelect(target) },
        label = { Text(label, style = MaterialTheme.typography.labelMedium) }
    )
}