package com.ghub.manager.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.ghub.manager.data.TransferKind
import com.ghub.manager.data.TransferState
import com.ghub.manager.data.TransferTask
import com.ghub.manager.util.Helpers
import com.ghub.manager.vm.AppViewModel

/**
 * 传输列表：展示 APK / ZIP 下载任务，可暂停、继续、取消，并能复制当前下载地址。
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TransfersScreen(vm: AppViewModel) {
    if (vm.transfers.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            EmptyState(
                Icons.Rounded.Download,
                "没有传输任务",
                "在「编译」页的产物卡片上点「下载APK」或「下载ZIP」即可开始"
            )
        }
        return
    }

    val active = vm.transfers.count { !it.isFinished }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            SectionHeader("传输列表", "$active 个进行中 · 共 ${vm.transfers.size} 个") {
                TextButton(onClick = vm::clearFinishedTransfers, enabled = vm.transfers.any { it.isFinished }) {
                    Text("清理已完成")
                }
            }
        }
        items(vm.transfers, key = { it.id }) { task ->
            TransferCard(vm, task)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TransferCard(vm: AppViewModel, task: TransferTask) {
    val color = transferColor(task)
    ItemCard(modifier = Modifier.padding(horizontal = 16.dp, vertical = 5.dp)) {
        // 标题行：图标 + 名称 + 状态
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                if (task.kind == TransferKind.APK) Icons.Rounded.Android else Icons.Rounded.Inventory2,
                null,
                tint = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    task.artifactName,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                MetaLine(
                    if (task.kind == TransferKind.APK) "解出 APK" else "原始 ZIP",
                    stateText(task)
                )
            }
            StatusChip(stateText(task), color)
        }

        Spacer(Modifier.height(8.dp))

        // 进度条：自绘，避免依赖不同版本 LinearProgressIndicator 的 API 差异
        Box(
            Modifier
                .fillMaxWidth()
                .height(6.dp)
                .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(3.dp))
        ) {
            Box(
                Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(if (task.progress > 0f) task.progress else 0.001f)
                    .background(color, RoundedCornerShape(3.dp))
            )
        }

        Spacer(Modifier.height(6.dp))

        MetaLine(
            "${(task.progress * 100).toInt()}%",
            if (task.totalBytes > 0) "${Helpers.size(task.receivedBytes)} / ${Helpers.size(task.totalBytes)}"
            else Helpers.size(task.receivedBytes),
            if (task.state == TransferState.DOWNLOADING && task.speedBytesPerSec > 0)
                "${Helpers.size(task.speedBytesPerSec)}/s" else ""
        )

        // 下载地址（当前实际请求的地址），可复制
        if (task.url.isNotBlank()) {
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Rounded.Link,
                    null,
                    Modifier.size(14.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.width(4.dp))
                Text(
                    task.url,
                    Modifier.weight(1f),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        if (task.savedPath != null) {
            Spacer(Modifier.height(4.dp))
            InfoText(task.savedPath)
        }
        if (task.error != null) {
            Spacer(Modifier.height(4.dp))
            Text(
                task.error,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )
        }

        Spacer(Modifier.height(8.dp))

        // 操作区
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            if (task.canPause) {
                OutlinedButton(onClick = { vm.pauseTransfer(task.id) }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Rounded.Pause, null, Modifier.size(15.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("暂停", maxLines = 1)
                }
            }
            if (task.canResume) {
                Button(onClick = { vm.resumeTransfer(task.id) }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Rounded.PlayArrow, null, Modifier.size(15.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("继续", maxLines = 1)
                }
            }
            if (task.canCancel) {
                OutlinedButton(onClick = { vm.cancelTransfer(task.id) }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Rounded.Close, null, Modifier.size(15.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("取消", maxLines = 1)
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedButton(
                onClick = { vm.copy(task.url, "下载地址") },
                modifier = Modifier.weight(1f),
                enabled = task.url.isNotBlank()
            ) {
                Icon(Icons.Rounded.ContentCopy, null, Modifier.size(15.dp))
                Spacer(Modifier.width(4.dp))
                Text("复制地址", maxLines = 1)
            }
            OutlinedButton(onClick = { vm.removeTransfer(task.id) }, modifier = Modifier.weight(1f)) {
                Icon(Icons.Rounded.Delete, null, Modifier.size(15.dp))
                Spacer(Modifier.width(4.dp))
                Text("移除", maxLines = 1)
            }
        }
    }
}

@Composable
private fun stateText(task: TransferTask): String = when (task.state) {
    TransferState.QUEUED -> "排队中"
    TransferState.DOWNLOADING -> "下载中"
    TransferState.PAUSED -> "已暂停"
    TransferState.EXTRACTING -> "处理中"
    TransferState.COMPLETED -> "已完成"
    TransferState.FAILED -> "失败"
    TransferState.CANCELED -> "已取消"
}

@Composable
private fun transferColor(task: TransferTask): androidx.compose.ui.graphics.Color = when (task.state) {
    TransferState.COMPLETED -> MaterialTheme.colorScheme.primary
    TransferState.FAILED -> MaterialTheme.colorScheme.error
    TransferState.PAUSED -> MaterialTheme.colorScheme.tertiary
    TransferState.DOWNLOADING, TransferState.EXTRACTING, TransferState.QUEUED -> MaterialTheme.colorScheme.secondary
    TransferState.CANCELED -> MaterialTheme.colorScheme.outline
}
