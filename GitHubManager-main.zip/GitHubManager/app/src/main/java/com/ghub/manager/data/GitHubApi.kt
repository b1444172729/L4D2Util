package com.ghub.manager.data

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

class ApiException(val code: Int, message: String) : IOException(message)

/**
 * GitHub REST API 客户端。
 *
 * 设计要点：
 * 1. 全部通过官方 REST API 完成，不依赖任何本地 Git 实现，因此不受 Android 版本限制。
 * 2. 文件读写走 Contents API，天然支持任意二进制文件（zip / apk / 图片），上限 100 MB。
 * 3. 日志与产物下载会 302 跳转到 Azure Blob，跳转后的请求不能携带令牌，否则会被拒绝，
 *    因此这里统一用「先拿 Location，再用无令牌客户端下载」的两段式下载。
 */
class GitHubApi(private val tokenProvider: () -> String) {

    private val jsonMedia = "application/json; charset=utf-8".toMediaType()

    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .callTimeout(60, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    // 不跟随重定向：用于解析 Location
    private val noRedirect = http.newBuilder().followRedirects(false).followSslRedirects(false).build()

    // 无令牌、超时更长：用于流式下载大文件
    private val transfer = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .callTimeout(0, TimeUnit.SECONDS)
        .followSslRedirects(true)
        .build()

    // 上传 / 下载大文件：超时放宽，且不做整体 callTimeout 限制
    private val transferLong = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(300, TimeUnit.SECONDS)
        .writeTimeout(300, TimeUnit.SECONDS)
        .callTimeout(0, TimeUnit.SECONDS)
        .build()

    private fun token(): String {
        val t = tokenProvider().trim()
        if (t.isBlank()) throw ApiException(401, "未登录或令牌为空")
        return t
    }

    private fun url(path: String) = "https://api.github.com$path"

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8").replace("+", "%20")

    private fun headers(builder: Request.Builder): Request.Builder = builder
        .header("Authorization", "Bearer ${token()}")
        .header("Accept", "application/vnd.github+json")
        .header("X-GitHub-Api-Version", "2022-11-28")
        .header("User-Agent", "GitHubManager-Android")

    private fun call(path: String, method: String = "GET", body: String? = null): String {
        val builder = Request.Builder().url(url(path))
        headers(builder)
        if (body != null) {
            builder.method(method, body.toRequestBody(jsonMedia))
        } else if (method != "GET") {
            builder.method(method, "".toRequestBody(jsonMedia))
        }
        http.newCall(builder.build()).execute().use { resp ->
            val text = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) throw ApiException(resp.code, parseError(resp.code, text))
            return text
        }
    }

    private fun parseError(code: Int, text: String): String {
        val msg = runCatching { JSONObject(text).optString("message") }.getOrDefault("").orEmpty()
        val friendly = when (code) {
            401 -> "令牌无效或已过期（401）"
            403 -> if (text.contains("rate limit", true)) "API 调用频率超限，请稍后再试（403）" else "没有权限，请检查令牌是否勾选 repo / workflow 权限（403）"
            404 -> "资源不存在，或令牌无权访问（404）"
            409 -> "冲突：$msg"
            422 -> "请求被拒绝：${msg.ifBlank { "可能是同名文件已存在，或内容为空" }}"
            else -> msg
        }
        return friendly.ifBlank { "HTTP $code" }
    }

    private fun repo(owner: String, name: String) = "/repos/${enc(owner)}/${enc(name)}"

    // ---------- 账户 ----------

    fun user(): User {
        val j = JSONObject(call("/user"))
        return User(
            j.optString("login"),
            j.optString("name").ifBlank { j.optString("login") },
            j.optString("avatar_url"),
            j.optInt("public_repos"),
            j.optString("html_url")
        )
    }

    fun repos(): List<Repo> {
        val all = mutableListOf<Repo>()
        for (page in 1..3) {
            val a = JSONArray(call("/user/repos?sort=updated&per_page=100&page=$page&affiliation=owner,collaborator,organization_member"))
            for (i in 0 until a.length()) all += parseRepo(a.getJSONObject(i))
            if (a.length() < 100) break
        }
        return all
    }

    fun searchRepos(query: String): List<Repo> {
        if (query.isBlank()) return emptyList()
        val j = JSONObject(call("/search/repositories?q=${enc(query)}&per_page=50&sort=updated"))
        val a = j.optJSONArray("items") ?: return emptyList()
        return (0 until a.length()).map { parseRepo(a.getJSONObject(it)) }
    }

    private fun parseRepo(j: JSONObject) = Repo(
        j.optLong("id"),
        j.optString("name"),
        j.optString("full_name"),
        j.optJSONObject("owner")?.optString("login").orEmpty(),
        j.optString("description").orEmpty(),
        j.optBoolean("private"),
        j.optString("default_branch", "main"),
        j.optString("language").orEmpty(),
        j.optInt("stargazers_count"),
        j.optInt("forks_count"),
        j.optLong("size"),
        j.optString("pushed_at").orEmpty(),
        j.optString("html_url")
    )

    fun createRepo(name: String, description: String, privateRepo: Boolean): Repo {
        val body = JSONObject().put("name", name).put("description", description).put("private", privateRepo)
            .put("auto_init", true)
        return parseRepo(JSONObject(call("/user/repos", "POST", body.toString())))
    }

    fun deleteRepo(owner: String, name: String) {
        call(repo(owner, name), "DELETE")
    }

    fun star(owner: String, name: String) = call("/user/starred/${enc(owner)}/${enc(name)}", "PUT")
    fun unstar(owner: String, name: String) = call("/user/starred/${enc(owner)}/${enc(name)}", "DELETE")

    /** 204 表示已星标，404 表示未星标 */
    fun isStarred(owner: String, name: String): Boolean {
        val request = headers(Request.Builder().url(url("/user/starred/${enc(owner)}/${enc(name)}"))).build()
        http.newCall(request).execute().use { resp ->
            when (resp.code) {
                204 -> return true
                404 -> return false
                else -> throw ApiException(resp.code, parseError(resp.code, resp.body?.string().orEmpty()))
            }
        }
    }

    // ---------- 分支 ----------

    fun branches(owner: String, name: String): List<Branch> {
        val a = JSONArray(call("${repo(owner, name)}/branches?per_page=100"))
        return (0 until a.length()).map {
            val j = a.getJSONObject(it)
            Branch(j.optString("name"), j.optJSONObject("commit")?.optString("sha").orEmpty(), j.optBoolean("protected"))
        }
    }

    /** 基于某个分支创建新分支（用 sha 建 ref，不需要本地仓库） */
    fun createBranch(owner: String, name: String, newBranch: String, from: String) {
        val source = if (from.isBlank()) {
            JSONObject(call(repo(owner, name))).optString("default_branch", "main")
        } else from
        val sha = JSONObject(call("${repo(owner, name)}/git/ref/heads/${enc(source)}"))
            .optJSONObject("object")?.optString("sha")
            ?: throw ApiException(404, "找不到源分支 $source")
        val body = JSONObject().put("ref", "refs/heads/$newBranch").put("sha", sha)
        call("${repo(owner, name)}/git/refs", "POST", body.toString())
    }

    fun deleteBranch(owner: String, name: String, branch: String) {
        call("${repo(owner, name)}/git/refs/heads/${enc(branch)}", "DELETE")
    }

    // ---------- 文件（Contents API） ----------

    fun contents(owner: String, name: String, path: String, ref: String): List<ContentEntry> {
        val query = if (ref.isBlank()) "" else "?ref=${enc(ref)}"
        val raw = call("${repo(owner, name)}/contents/${path.encodePath()}$query")
        // 单文件时返回对象，目录时返回数组
        val array = if (raw.trimStart().startsWith("[")) JSONArray(raw) else JSONArray().put(JSONObject(raw))
        val list = mutableListOf<ContentEntry>()
        for (i in 0 until array.length()) {
            val j = array.getJSONObject(i)
            list += ContentEntry(
                j.optString("name"),
                j.optString("path"),
                j.optString("type"),
                j.optLong("size"),
                j.optString("sha"),
                j.optString("html_url"),
                j.optString("download_url")
            )
        }
        // 目录在前、文件在后，各自按名排序
        return list.sortedWith(compareBy({ !it.isDir }, { it.name.lowercase() }))
    }

    /** 读取单个文件；大文件（>1MB）content 为 null，需要用 rawBytes 下载 */
    fun file(owner: String, name: String, path: String, ref: String): FileContent {
        val query = if (ref.isBlank()) "" else "?ref=${enc(ref)}"
        val j = JSONObject(call("${repo(owner, name)}/contents/${path.encodePath()}$query"))
        return FileContent(
            j.optString("name"),
            j.optString("path"),
            j.optString("sha"),
            j.optLong("size"),
            j.optString("content").takeIf { it.isNotBlank() },
            j.optString("encoding").takeIf { it.isNotBlank() },
            j.optString("download_url").takeIf { it.isNotBlank() }
        )
    }

    /** 用 raw 形式取原始字节（支持私有仓库，且不受 base64 体积膨胀影响） */
    fun rawBytes(owner: String, name: String, path: String, ref: String): ByteArray {
        val query = if (ref.isBlank()) "" else "?ref=${enc(ref)}"
        val builder = Request.Builder().url(url("${repo(owner, name)}/contents/${path.encodePath()}$query"))
            .header("Authorization", "Bearer ${token()}")
            .header("Accept", "application/vnd.github.raw")
            .header("X-GitHub-Api-Version", "2022-11-28")
            .header("User-Agent", "GitHubManager-Android")
        http.newCall(builder.build()).execute().use { resp ->
            if (!resp.isSuccessful) throw ApiException(resp.code, parseError(resp.code, resp.body?.string().orEmpty()))
            return resp.body?.bytes() ?: throw ApiException(500, "空响应")
        }
    }

    /**
     * 创建或更新文件。sha 为空表示新建，非空表示更新（GitHub 用它做并发校验）。
     * content 必须是原始字节的 base64。
     */
    fun putFile(
        owner: String, name: String, path: String, message: String,
        contentBase64: String, sha: String?, branch: String
    ): CommitResult {
        val body = JSONObject()
            .put("message", message.ifBlank { "Update ${path.substringAfterLast('/')}" })
            .put("content", contentBase64)
        if (!sha.isNullOrBlank()) body.put("sha", sha)
        if (branch.isNotBlank()) body.put("branch", branch)
        val j = JSONObject(call("${repo(owner, name)}/contents/${path.encodePath()}", "PUT", body.toString()))
        val content = j.optJSONObject("content")
        val commit = j.optJSONObject("commit")
        return CommitResult(
            commit?.optString("sha").orEmpty(),
            content?.optString("sha"),
            commit?.optString("html_url").orEmpty()
        )
    }

    /**
     * 流式上传本地文件（支持最大 100 MB）。
     *
     * 为什么不用 putFile：putFile 需要先把整个文件读成 ByteArray 再做 base64，
     * 100 MB 文件编码后约 133 MB 字符串，加上原始数组会直接 OOM。
     * 这里边读 Uri 边编码边写入请求体，内存占用恒定在几十 KB。
     */
    fun putFileStream(
        context: Context, uri: Uri, owner: String, name: String, path: String,
        message: String, sha: String?, branch: String
    ): CommitResult {
        val size = uriSize(context, uri)
        val body = StreamUploadBody(context, uri, message, sha, branch, size)
        val request = headers(Request.Builder().url(url("${repo(owner, name)}/contents/${path.encodePath()}")))
            .method("PUT", body).build()
        transferLong.newCall(request).execute().use { resp ->
            val text = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) throw ApiException(resp.code, parseError(resp.code, text))
            return parseCommitResult(text)
        }
    }

    /** 文件大小；拿不到时返回 -1（此时 contentLength 走 chunked） */
    private fun uriSize(context: Context, uri: Uri): Long {
        runCatching {
            context.contentResolver.openAssetFileDescriptor(uri, "r")?.use { return it.length }
        }
        runCatching {
            context.contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val i = c.getColumnIndex(android.provider.OpenableColumns.SIZE)
                    if (i >= 0 && !c.isNull(i)) return c.getLong(i)
                }
            }
        }
        return -1L
    }

    private fun parseCommitResult(text: String): CommitResult {
        val j = JSONObject(text)
        return CommitResult(
            j.optJSONObject("commit")?.optString("sha").orEmpty(),
            j.optJSONObject("content")?.optString("sha"),
            j.optJSONObject("commit")?.optString("html_url").orEmpty()
        )
    }

    /** 删除文件：必须带 sha */
    fun deleteFile(owner: String, name: String, path: String, message: String, sha: String, branch: String): CommitResult {
        val body = JSONObject()
            .put("message", message.ifBlank { "Delete ${path.substringAfterLast('/')}" })
            .put("sha", sha)
        if (branch.isNotBlank()) body.put("branch", branch)
        val j = JSONObject(call("${repo(owner, name)}/contents/${path.encodePath()}", "DELETE", body.toString()))
        return CommitResult(
            j.optJSONObject("commit")?.optString("sha").orEmpty(),
            null,
            j.optJSONObject("commit")?.optString("html_url").orEmpty()
        )
    }

    // ---------- 提交历史 ----------

    fun commits(owner: String, name: String, branch: String): List<Commit> {
        val query = if (branch.isBlank()) "" else "?sha=${enc(branch)}&per_page=50"
        val a = JSONArray(call("${repo(owner, name)}/commits$query"))
        return (0 until a.length()).map {
            val j = a.getJSONObject(it)
            val c = j.optJSONObject("commit")
            Commit(
                j.optString("sha").take(7),
                c?.optString("message").orEmpty().substringBefore("\n"),
                c?.optJSONObject("author")?.optString("name").orEmpty(),
                c?.optJSONObject("author")?.optString("date").orEmpty(),
                j.optString("html_url")
            )
        }
    }

    // ---------- Actions ----------

    fun workflows(owner: String, name: String): List<Workflow> {
        val j = JSONObject(call("${repo(owner, name)}/actions/workflows?per_page=100"))
        val a = j.optJSONArray("workflows") ?: return emptyList()
        return (0 until a.length()).map {
            val w = a.getJSONObject(it)
            Workflow(w.optLong("id"), w.optString("name"), w.optString("path").substringAfterLast('/'), w.optString("state"))
        }
    }

    /** 触发 workflow_dispatch。inputs 为空对象时也必须传 {} */
    fun dispatch(owner: String, name: String, workflowId: Long, ref: String, inputs: Map<String, String>) {
        val body = JSONObject().put("ref", ref).put("inputs", JSONObject().apply {
            inputs.forEach { (k, v) -> put(k, v) }
        })
        call("${repo(owner, name)}/actions/workflows/$workflowId/dispatches", "POST", body.toString())
    }

    fun runs(owner: String, name: String): List<WorkflowRun> {
        val j = JSONObject(call("${repo(owner, name)}/actions/runs?per_page=30"))
        return parseRuns(j.optJSONArray("workflow_runs"))
    }

    /** 只看某个工作流的运行记录 */
    fun runsFor(owner: String, name: String, workflowId: Long): List<WorkflowRun> {
        val j = JSONObject(call("${repo(owner, name)}/actions/workflows/$workflowId/runs?per_page=30"))
        return parseRuns(j.optJSONArray("workflow_runs"))
    }

    private fun parseRuns(a: JSONArray?): List<WorkflowRun> {
        a ?: return emptyList()
        return (0 until a.length()).map {
            val j = a.getJSONObject(it)
            WorkflowRun(
                j.optLong("id"),
                j.optString("name").ifBlank { j.optString("display_title") },
                j.optInt("run_number"),
                j.optString("status"),
                j.optString("conclusion").takeIf { s -> s != "null" }.orEmpty(),
                j.optString("head_branch"),
                j.optString("head_sha").take(7),
                j.optString("event"),
                j.optString("created_at"),
                j.optString("updated_at"),
                j.optString("html_url")
            )
        }
    }

    fun jobs(owner: String, name: String, runId: Long): List<WorkflowJob> {
        val j = JSONObject(call("${repo(owner, name)}/actions/runs/$runId/jobs?per_page=100"))
        val a = j.optJSONArray("jobs") ?: return emptyList()
        return (0 until a.length()).map {
            val x = a.getJSONObject(it)
            WorkflowJob(
                x.optLong("id"),
                x.optString("name"),
                x.optString("status"),
                x.optString("conclusion").takeIf { s -> s != "null" }.orEmpty(),
                x.optString("started_at"),
                x.optString("completed_at")
            )
        }
    }

    fun cancelRun(owner: String, name: String, runId: Long) =
        call("${repo(owner, name)}/actions/runs/$runId/cancel", "POST")

    fun rerunRun(owner: String, name: String, runId: Long) =
        call("${repo(owner, name)}/actions/runs/$runId/rerun", "POST")

    fun rerunFailed(owner: String, name: String, runId: Long) =
        call("${repo(owner, name)}/actions/runs/$runId/rerun-failed-jobs", "POST")

    /** 运行日志（zip 压缩包） */
    fun runLogsZip(owner: String, name: String, runId: Long): ByteArray =
        binary("${repo(owner, name)}/actions/runs/$runId/logs")

    /** 单个任务的日志（同样是 zip，通常只有一个条目） */
    fun jobLogsZip(owner: String, name: String, jobId: Long): ByteArray =
        binary("${repo(owner, name)}/actions/jobs/$jobId/logs")

    fun artifacts(owner: String, name: String, runId: Long): List<Artifact> {
        val j = JSONObject(call("${repo(owner, name)}/actions/runs/$runId/artifacts?per_page=100"))
        val a = j.optJSONArray("artifacts") ?: return emptyList()
        return (0 until a.length()).map {
            val x = a.getJSONObject(it)
            Artifact(
                x.optLong("id"),
                x.optString("name"),
                x.optLong("size_in_bytes"),
                x.optBoolean("expired"),
                x.optString("created_at"),
                x.optString("updated_at")
            )
        }
    }

    /** 产物下载：返回可直接粘到浏览器的最终地址（已跟随 302，不含令牌） */
    fun artifactDownloadUrl(owner: String, name: String, artifactId: Long): String {
        val path = "${repo(owner, name)}/actions/artifacts/$artifactId/zip"
        val request = headers(Request.Builder().url(url(path))).build()
        noRedirect.newCall(request).execute().use { resp ->
            val location = resp.header("Location")
            return when {
                location != null -> resp.request.url.resolve(location)?.toString() ?: location
                resp.isSuccessful -> url(path)
                else -> throw ApiException(resp.code, parseError(resp.code, resp.body?.string().orEmpty()))
            }
        }
    }

    fun artifactWebUrl(owner: String, name: String, runId: Long, artifactId: Long) =
        "https://github.com/$owner/$name/actions/runs/$runId/artifacts/$artifactId"

    fun artifactApiUrl(owner: String, name: String, artifactId: Long) =
        url("${repo(owner, name)}/actions/artifacts/$artifactId/zip")

    fun artifactCurl(owner: String, name: String, artifactId: Long): String =
        "curl -L -o artifact.zip -H 'Authorization: Bearer ${token()}' " +
            "-H 'Accept: application/vnd.github+json' '${artifactApiUrl(owner, name, artifactId)}'"

    /** 产物二进制内容（用于「应用内下载后分享」） */
    fun artifactBytes(owner: String, name: String, artifactId: Long): ByteArray =
        binary("${repo(owner, name)}/actions/artifacts/$artifactId/zip")

    // ---------- Issues / Pull Requests ----------

    fun issues(owner: String, name: String, state: String): List<Issue> {
        val a = JSONArray(call("${repo(owner, name)}/issues?state=$state&per_page=50&sort=updated"))
        return (0 until a.length()).map { parseIssue(a.getJSONObject(it)) }
    }

    fun pulls(owner: String, name: String, state: String): List<Issue> {
        val a = JSONArray(call("${repo(owner, name)}/pulls?state=$state&per_page=50&sort=updated"))
        return (0 until a.length()).map { index ->
            // range.map 的 lambda 参数是索引 Int，必须先取出 JSONObject 再使用
            val j = a.getJSONObject(index)
            parseIssue(j).copy(isPull = true, draft = j.optBoolean("draft"), merged = j.optBoolean("merged"))
        }
    }

    private fun parseIssue(j: JSONObject) = Issue(
        j.optInt("number"),
        j.optString("title"),
        j.optString("state"),
        j.optJSONObject("user")?.optString("login").orEmpty(),
        j.optString("created_at"),
        j.optString("updated_at"),
        j.optInt("comments"),
        j.optString("body").orEmpty(),
        j.optString("html_url")
    )

    fun createIssue(owner: String, name: String, title: String, body: String): Int {
        val payload = JSONObject().put("title", title).put("body", body)
        return JSONObject(call("${repo(owner, name)}/issues", "POST", payload.toString())).optInt("number")
    }

    fun setIssueState(owner: String, name: String, number: Int, state: String) {
        call("${repo(owner, name)}/issues/$number", "PATCH", JSONObject().put("state", state).toString())
    }

    fun comments(owner: String, name: String, number: Int): List<Comment> {
        val a = JSONArray(call("${repo(owner, name)}/issues/$number/comments?per_page=100"))
        return (0 until a.length()).map {
            val j = a.getJSONObject(it)
            Comment(
                j.optLong("id"),
                j.optJSONObject("user")?.optString("login").orEmpty(),
                j.optString("body"),
                j.optString("created_at")
            )
        }
    }

    fun addComment(owner: String, name: String, number: Int, body: String) {
        call("${repo(owner, name)}/issues/$number/comments", "POST", JSONObject().put("body", body).toString())
    }

    fun mergePull(owner: String, name: String, number: Int, method: String = "merge") {
        call("${repo(owner, name)}/pulls/$number/merge", "PUT", JSONObject().put("merge_method", method).toString())
    }

    // ---------- Releases ----------

    fun releases(owner: String, name: String): List<Release> {
        val a = JSONArray(call("${repo(owner, name)}/releases?per_page=30"))
        return (0 until a.length()).map {
            val j = a.getJSONObject(it)
            val assets = j.optJSONArray("assets")
            val list = mutableListOf<ReleaseAsset>()
            if (assets != null) {
                for (i in 0 until assets.length()) {
                    val x = assets.getJSONObject(i)
                    list += ReleaseAsset(
                        x.optLong("id"), x.optString("name"), x.optLong("size"),
                        x.optInt("download_count"), "${repo(owner, name)}/releases/assets/${x.optLong("id")}"
                    )
                }
            }
            Release(
                j.optLong("id"), j.optString("tag_name"), j.optString("name").ifBlank { j.optString("tag_name") },
                j.optString("body"), j.optString("published_at"), j.optString("html_url"),
                j.optBoolean("draft"), j.optBoolean("prerelease"), list
            )
        }
    }

    fun releaseAssetBytes(owner: String, name: String, assetId: Long): ByteArray {
        val path = "${repo(owner, name)}/releases/assets/$assetId"
        val request = headers(Request.Builder().url(url(path)))
            .header("Accept", "application/octet-stream").build()
        noRedirect.newCall(request).execute().use { resp ->
            if (resp.code in 301..308) {
                val location = resp.header("Location") ?: throw ApiException(500, "缺少下载地址")
                return transfer.newCall(Request.Builder().url(location).header("Accept", "application/octet-stream").build())
                    .execute().use { it.body?.bytes() ?: throw ApiException(500, "空响应") }
            }
            if (!resp.isSuccessful) throw ApiException(resp.code, parseError(resp.code, resp.body?.string().orEmpty()))
            return resp.body?.bytes() ?: throw ApiException(500, "空响应")
        }
    }

    // ---------- 通用二进制下载（两段式，跳转后不带令牌） ----------

    private fun binary(path: String): ByteArray {
        val request = headers(Request.Builder().url(url(path))).build()
        noRedirect.newCall(request).execute().use { first ->
            if (first.code in 301..308) {
                val location = first.header("Location") ?: throw ApiException(500, "下载链接为空")
                val resolved = first.request.url.resolve(location)?.toString() ?: location
                require(resolved.startsWith("https://")) { "拒绝非 HTTPS 下载地址" }
                return transfer.newCall(Request.Builder().url(resolved).header("User-Agent", "GitHubManager-Android").build())
                    .execute().use { resp ->
                        if (!resp.isSuccessful) throw ApiException(resp.code, "下载失败（HTTP ${resp.code}）")
                        resp.body?.bytes() ?: throw ApiException(500, "空响应")
                    }
            }
            if (!first.isSuccessful) throw ApiException(first.code, parseError(first.code, first.body?.string().orEmpty()))
            return first.body?.bytes() ?: throw ApiException(500, "空响应")
        }
    }

    /** 路径分段各自的 URL 编码，保留 "/" 作为层级分隔 */
    private fun String.encodePath(): String = split("/").joinToString("/") { enc(it) }
}

/** JSON 字符串转义，避免提交信息里的引号 / 换行破坏结构 */
private fun jsonEscape(s: String): String {
    val sb = StringBuilder(s.length + 8)
    for (c in s) {
        when {
            c == '"' -> sb.append("\\\"")
            c == '\\' -> sb.append("\\\\")
            c == '\n' -> sb.append("\\n")
            c == '\r' -> sb.append("\\r")
            c == '\t' -> sb.append("\\t")
            c.code < 0x20 -> sb.append("\\u").append(c.code.toString(16).padStart(4, '0'))
            else -> sb.append(c)
        }
    }
    return sb.toString()
}

/**
 * 边读边编码的 Base64 写入器：把输入流直接编码进 Okio sink，
 * 不需要把整个文件读进内存，因此支持上传 100 MB 的文件。
 */
private class Base64Encoder(private val sink: okio.BufferedSink) {
    private val table = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".toByteArray()
    private var acc = 0
    private var bits = 0
    private val buf = ByteArray(4)
    private var pos = 0

    private fun emit(value: Int) {
        buf[pos++] = value.toByte()
        if (pos == 4) {
            sink.write(buf, 0, 4)
            pos = 0
        }
    }

    fun update(bytes: ByteArray, length: Int) {
        for (i in 0 until length) {
            acc = (acc shl 8) or (bytes[i].toInt() and 0xFF)
            bits += 8
            while (bits >= 6) {
                bits -= 6
                emit(table[(acc shr bits) and 0x3F].toInt())
            }
        }
    }

    /** 写出剩余位并补 '=' 填充，使总长度为 4 的倍数 */
    fun finish() {
        if (bits > 0) emit(table[(acc shl (6 - bits)) and 0x3F].toInt())
        while (pos != 0) emit('='.code)
    }
}

/** 流式上传请求体：JSON 头 → Base64 正文 → JSON 尾，全程不落地、不整体驻留内存 */
private class StreamUploadBody(
    private val context: android.content.Context,
    private val uri: android.net.Uri,
    message: String,
    sha: String?,
    branch: String,
    private val fileSize: Long
) : okhttp3.RequestBody() {

    private val head: String = buildString {
        append("{\"message\":\"").append(jsonEscape(message)).append('"')
        if (!sha.isNullOrBlank()) append(",\"sha\":\"").append(jsonEscape(sha)).append('"')
        if (branch.isNotBlank()) append(",\"branch\":\"").append(jsonEscape(branch)).append('"')
        append(",\"content\":\"")
    }
    private val tail = "\"}"

    override fun contentType() = "application/json; charset=utf-8".toMediaType()

    override fun contentLength(): Long {
        if (fileSize < 0) return -1L
        val encoded = ((fileSize + 2) / 3) * 4
        return head.length.toLong() + encoded + tail.length
    }

    override fun writeTo(sink: okio.BufferedSink) {
        sink.writeUtf8(head)
        val encoder = Base64Encoder(sink)
        val input = context.contentResolver.openInputStream(uri)
            ?: throw java.io.IOException("无法读取所选文件")
        input.use { stream ->
            val buffer = ByteArray(64 * 1024)
            while (true) {
                val n = stream.read(buffer)
                if (n <= 0) break
                encoder.update(buffer, n)
            }
        }
        encoder.finish()
        sink.writeUtf8(tail)
    }
}
