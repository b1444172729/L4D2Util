package com.ghub.manager.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.ghub.manager.vm.AppViewModel
import com.ghub.manager.vm.Tab as PageTab
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(vm: AppViewModel, onOpenUrl: (String) -> Unit) {
    val tabs = PageTab.entries
    val scope = rememberCoroutineScope()
    val pagerState = rememberPagerState(initialPage = vm.tab.ordinal) { tabs.size }

    // 外部切换 Tab（例如打开仓库时）同步到分页
    LaunchedEffect(vm.tab) {
        val target = vm.tab.ordinal
        if (pagerState.currentPage != target) pagerState.animateScrollToPage(target)
    }
    // 分页滑动同步回 ViewModel
    LaunchedEffect(pagerState.currentPage) {
        val next = tabs[pagerState.currentPage]
        if (vm.tab != next) vm.switchTab(next)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(vm.repo?.name.orEmpty(), style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(vm.repo?.fullName.orEmpty(), style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1,
                            overflow = TextOverflow.Ellipsis)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = vm::backToRepos) { Icon(Icons.Rounded.ArrowBack, "返回") }
                },
                actions = {
                    IconButton(onClick = { onOpenUrl(vm.repo?.htmlUrl ?: "https://github.com") }) {
                        Icon(Icons.Rounded.OpenInNew, "浏览器打开")
                    }
                }
            )
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            BusyBar(if (vm.busy) vm.busyLabel else "")

            ScrollableTabRow(
                selectedTabIndex = pagerState.currentPage,
                modifier = Modifier.fillMaxWidth(),
                edgePadding = 8.dp
            ) {
                tabs.forEachIndexed { index, tab ->
                    Tab(
                        selected = pagerState.currentPage == index,
                        onClick = { scope.launch { pagerState.animateScrollToPage(index) } },
                        text = { Text(tab.label()) }
                    )
                }
            }

            HorizontalPager(state = pagerState, modifier = Modifier.fillMaxSize()) { page ->
                when (tabs[page]) {
                    PageTab.FILES -> FilesScreen(vm, onOpenUrl)
                    PageTab.ACTIONS -> ActionsScreen(vm, onOpenUrl)
                    PageTab.DOWNLOADS -> TransfersScreen(vm)
                    PageTab.ISSUES -> IssuesScreen(vm, onOpenUrl)
                    PageTab.PULLS -> PullsScreen(vm, onOpenUrl)
                    PageTab.RELEASES -> ReleasesScreen(vm, onOpenUrl)
                    PageTab.COMMITS -> CommitsScreen(vm, onOpenUrl)
                    PageTab.BRANCHES -> BranchesScreen(vm)
                }
            }
        }
    }
}

private fun PageTab.label(): String = when (this) {
    PageTab.FILES -> "文件"
    PageTab.ACTIONS -> "编译"
    PageTab.DOWNLOADS -> "传输"
    PageTab.ISSUES -> "Issues"
    PageTab.PULLS -> "PR"
    PageTab.RELEASES -> "版本"
    PageTab.COMMITS -> "提交"
    PageTab.BRANCHES -> "分支"
}
