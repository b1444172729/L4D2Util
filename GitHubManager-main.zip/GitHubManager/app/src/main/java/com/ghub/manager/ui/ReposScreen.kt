package com.ghub.manager.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.ghub.manager.data.Repo
import com.ghub.manager.util.Helpers
import com.ghub.manager.vm.AppViewModel

// TopAppBar 等 Material3 API 仍处于实验阶段，需在使用处显式声明。
// 注意：文件级注解只允许写成 @file:OptIn(...) 且必须位于 package 之前，
// 写在 package 与 import 之间会导致 import 报语法错误，因此这里改用函数级注解。
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReposScreen(vm: AppViewModel, onOpenUrl: (String) -> Unit) {
    var query by remember { mutableStateOf("") }
    var showCreate by remember { mutableStateOf(false) }
    var menuRepo by remember { mutableStateOf<Repo?>(null) }
    var confirmDelete by remember { mutableStateOf<Repo?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("仓库", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                        vm.user?.let {
                            Text(it.login, style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                },
                actions = {
                    IconButton(onClick = vm::refreshRepos, enabled = !vm.busy) {
                        Icon(Icons.Rounded.Refresh, "刷新")
                    }
                    IconButton(onClick = vm::toggleTheme) {
                        Icon(if (vm.darkTheme) Icons.Rounded.LightMode else Icons.Rounded.DarkMode, "主题")
                    }
                    IconButton(onClick = vm::logout) { Icon(Icons.Rounded.Logout, "退出") }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showCreate = true }) {
                Icon(Icons.Rounded.Add, "新建仓库")
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            BusyBar(if (vm.busy) vm.busyLabel else "")

            OutlinedTextField(
                query, {
                    query = it
                    if (it.length >= 2 || it.isEmpty()) vm.search(it)
                },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                placeholder = { Text("搜索我的仓库，或输入关键字搜公开仓库") },
                singleLine = true,
                leadingIcon = { Icon(Icons.Rounded.Search, null) },
                trailingIcon = if (query.isNotEmpty()) {
                    { IconButton(onClick = { query = ""; vm.search("") }) { Icon(Icons.Rounded.Close, "清空") } }
                } else null,
                shape = RoundedCornerShape(14.dp)
            )

            if (vm.repos.isEmpty() && !vm.busy) {
                EmptyState(Icons.Rounded.FolderOff, "没有仓库", "点击右下角 + 创建一个，或调整搜索关键字")
            }

            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 88.dp)) {
                items(vm.repos, key = { it.id }) { repo ->
                    RepoItem(
                        repo = repo,
                        onClick = { vm.openRepo(repo) },
                        onMenu = { menuRepo = repo }
                    )
                }
            }
        }
    }

    if (showCreate) {
        var name by remember { mutableStateOf("") }
        var description by remember { mutableStateOf("") }
        var privateRepo by remember { mutableStateOf(true) }
        AlertDialog(
            onDismissRequest = { showCreate = false },
            title = { Text("新建仓库") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(name, { name = it }, modifier = Modifier.fillMaxWidth(),
                        label = { Text("仓库名称") }, singleLine = true, placeholder = { Text("例如 my-android-app") })
                    OutlinedTextField(description, { description = it }, modifier = Modifier.fillMaxWidth(),
                        label = { Text("描述（可选）") }, singleLine = true)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(privateRepo, { privateRepo = it })
                        Spacer(Modifier.width(6.dp))
                        Text("私有仓库", style = MaterialTheme.typography.bodyMedium)
                    }
                    InfoText("会自动创建 README 和 main 分支，方便立刻上传文件。")
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.createRepo(name, description, privateRepo)
                    showCreate = false
                }, enabled = name.isNotBlank()) { Text("创建") }
            },
            dismissButton = { TextButton(onClick = { showCreate = false }) { Text("取消") } }
        )
    }

    menuRepo?.let { target ->
        AlertDialog(
            onDismissRequest = { menuRepo = null },
            title = { Text(target.fullName) },
            text = {
                Column {
                    TextButton(onClick = { onOpenUrl(target.htmlUrl); menuRepo = null }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Rounded.OpenInNew, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text("在浏览器打开")
                    }
                    TextButton(onClick = { vm.copy(target.htmlUrl); menuRepo = null }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Rounded.ContentCopy, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text("复制仓库地址")
                    }
                    TextButton(onClick = { vm.toggleStar(target); menuRepo = null }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Rounded.Star, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text("切换星标")
                    }
                    TextButton(onClick = { menuRepo = null; confirmDelete = target }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Rounded.DeleteOutline, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp))
                        Text("删除仓库", color = MaterialTheme.colorScheme.error)
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { menuRepo = null }) { Text("关闭") } }
        )
    }

    confirmDelete?.let { target ->
        ConfirmDialog(
            title = "删除 ${target.fullName}？",
            text = "这是不可逆操作，仓库内的所有文件、Issues 和 Actions 记录都会被删除。",
            confirmLabel = "确认删除",
            onDismiss = { confirmDelete = null },
            onConfirm = { vm.deleteRepo(target) }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RepoItem(repo: Repo, onClick: () -> Unit, onMenu: () -> Unit) {
    ItemCard(
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
        onClick = onClick
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                if (repo.isPrivate) Icons.Rounded.Lock else Icons.Rounded.Folder,
                null, tint = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(repo.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (repo.description.isNotBlank()) {
                    Text(repo.description, style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2,
                        overflow = TextOverflow.Ellipsis)
                }
                Spacer(Modifier.height(3.dp))
                MetaLine(
                    repo.language.ifBlank { "无语言" },
                    "★ ${repo.stars}",
                    Helpers.size(repo.size * 1024),
                    Helpers.time(repo.pushedAt)
                )
            }
            IconButton(onClick = onMenu) { Icon(Icons.Rounded.MoreVert, null) }
        }
    }
}
