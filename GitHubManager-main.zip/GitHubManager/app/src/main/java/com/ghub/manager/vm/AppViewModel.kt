package com.ghub.manager.vm

import android.app.Application
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.util.Base64
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ghub.manager.data.*
import com.ghub.manager.util.Helpers
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** 当前处于哪个页面 */
enum class Screen { LOGIN, REPOS, DETAIL }

/** 仓库详情内的子页面 */
enum class Tab { FILES, ACTIONS, ISSUES, PULLS, RELEASES, COMMITS, BRANCHES }

class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val settings = Settings(app)
    private val api = GitHubApi { settings.token }

    // ---------- 全局状态 ----------
    var screen by mutableStateOf(if (settings.token.isBlank()) Screen.LOGIN else Screen.REPOS)
        private set
    var busy by mutableStateOf(false)
        private set
    var busyLabel by mutableStateOf("")
        private set
    var message by mutableStateOf<String?>(null)
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var darkTheme by mutableStateOf(settings.darkTheme)
        private set

    var user by mutableStateOf<User?>(null)
        private set
    var repos by mutableStateOf<List<Repo>>(emptyList())
        private set
    var repoQuery by mutableStateOf("")

    // ---------- 当前仓库 ----------
    var repo by mutableStateOf<Repo?>(null)
        private set
    var branch by mutableStateOf("")
        private set
    var branches by mutableStateOf<List<Branch>>(emptyList())
        private set
    var tab by mutableStateOf(Tab.FILES)
        private set

    // ---------- 文件 ----------
    var path by mutableStateOf("")
        private set
    var entries by mutableStateOf<List<ContentEntry>>(emptyList())
        private set
    /** 编辑器：打开的文件 */
    var editorPath by mutableStateOf<String?>(null)
        private set
    var editorText by mutableStateOf("")
        private set
    var editorSha by mutableStateOf<String?>(null)
        private set
    var editorDirty by mutableStateOf(false)
        private set
    var editorBinary by mutableStateOf(false)
        private set

    // ---------- Actions ----------
    var workflows by mutableStateOf<List<Workflow>>(emptyList())
        private set
    var runs by mutableStateOf<List<WorkflowRun>>(emptyList())
        private set
    var selectedRunId by mutableStateOf<Long?>(null)
        private set
    var jobs by mutableStateOf<List<WorkflowJob>>(emptyList())
        private set
    var artifacts by mutableStateOf<List<Artifact>>(emptyList())
        private set
    var logText by mutableStateOf<String?>(null)
        private set
    var logTitle by mutableStateOf("")
        private set

    // ---------- 协作 ----------
    var issues by mutableStateOf<List<Issue>>(emptyList())
        private set
    var pulls by mutableStateOf<List<Issue>>(emptyList())
        private set
    var releases by mutableStateOf<List<Release>>(emptyList())
        private set
    var commits by mutableStateOf<List<Commit>>(emptyList())
        private set

    init {
        if (settings.token.isNotBlank()) {
            bootstrap()
        }
    }

    // ============================================================
    // 基础
    // ============================================================

    private fun run(label: String, block: suspend () -> Unit) {
        if (busy) {
            message = "请等待「$busyLabel」完成"
            return
        }
        viewModelScope.launch {
            busy = true
            busyLabel = label
            error = null
            try {
                block()
            } catch (e: Exception) {
                error = e.message ?: "操作失败"
            } finally {
                busy = false
                busyLabel = ""
            }
        }
    }

    fun consumeMessage() { message = null }
    fun consumeError() { error = null }

    fun copy(text: String, label: String = "GitHubManager") {
        val ctx = getApplication<Application>()
        val manager = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        manager?.setPrimaryClip(ClipData.newPlainText(label, text))
        message = "已复制"
    }

    fun toggleTheme() {
        darkTheme = !darkTheme
        settings.darkTheme = darkTheme
    }

    private fun requireRepo(): Repo = repo ?: throw IllegalStateException("请先选择仓库")

    private fun bootstrap() {
        run("加载中") {
            user = withContext(Dispatchers.IO) { api.user() }
            repos = withContext(Dispatchers.IO) { api.repos() }
            screen = Screen.REPOS
            // 恢复上次打开的仓库
            val o = settings.lastOwner
            val r = settings.lastRepo
            if (o.isNotBlank() && r.isNotBlank()) {
                val found = repos.firstOrNull { it.owner == o && it.name == r }
                if (found != null) openRepoInternal(found, false)
            }
        }
    }

    fun login(token: String) = run("登录中") {
        if (token.isBlank()) throw IllegalStateException("请输入令牌")
        settings.token = token
        val me = withContext(Dispatchers.IO) { api.user() }
        user = me
        repos = withContext(Dispatchers.IO) { api.repos() }
        screen = Screen.REPOS
        message = "已登录：${me.login}"
    }

    fun logout() {
        settings.clear()
        repo = null
        repos = emptyList()
        user = null
        screen = Screen.LOGIN
        message = "已退出登录"
    }

    fun refreshRepos() = run("刷新仓库") {
        repos = withContext(Dispatchers.IO) { api.repos() }
    }

    fun search(q: String) = run("搜索") {
        repoQuery = q
        repos = if (q.isBlank()) withContext(Dispatchers.IO) { api.repos() }
        else withContext(Dispatchers.IO) { api.searchRepos(q) }
    }

    fun createRepo(name: String, description: String, privateRepo: Boolean) = run("创建仓库") {
        if (name.isBlank()) throw IllegalStateException("请输入仓库名")
        val created = withContext(Dispatchers.IO) { api.createRepo(name.trim(), description.trim(), privateRepo) }
        repos = listOf(created) + repos
        message = "仓库已创建：${created.fullName}"
    }

    fun deleteRepo(target: Repo) = run("删除仓库") {
        withContext(Dispatchers.IO) { api.deleteRepo(target.owner, target.name) }
        repos = repos.filterNot { it.id == target.id }
        if (repo?.id == target.id) backToRepos()
        message = "已删除 ${target.fullName}"
    }

    fun toggleStar(target: Repo) = run("更新星标") {
        val starred = withContext(Dispatchers.IO) { api.isStarred(target.owner, target.name) }
        withContext(Dispatchers.IO) {
            if (starred) api.unstar(target.owner, target.name) else api.star(target.owner, target.name)
        }
        message = if (starred) "已取消星标" else "已添加星标"
    }

    fun backToRepos() {
        repo = null
        screen = Screen.REPOS
    }

    // ============================================================
    // 仓库与分支
    // ============================================================

    fun openRepo(target: Repo, remember: Boolean = true) = run("打开仓库") {
        openRepoInternal(target, remember)
    }

    /** 内部版本：bootstrap 等已在 run() 中的场景直接调用，避免被防重入拦截 */
    private suspend fun openRepoInternal(target: Repo, remember: Boolean) {
        repo = target
        branch = target.defaultBranch
        path = ""
        tab = Tab.FILES
        editorPath = null
        runs = emptyList()
        artifacts = emptyList()
        jobs = emptyList()
        selectedRunId = null
        logText = null
        screen = Screen.DETAIL
        if (remember) settings.remember(target.owner, target.name)
        withContext(Dispatchers.IO) { api.branches(target.owner, target.name) }.let { branches = it }
        reloadFiles()
    }

    fun switchBranch(name: String) = run("切换分支") {
        val r = requireRepo()
        branch = name
        path = ""
        editorPath = null
        withContext(Dispatchers.IO) { api.commits(r.owner, r.name, name) }.let { commits = it }
        reloadFiles()
    }

    fun loadBranches() = run("加载分支") {
        loadBranchesInternal()
    }

    private suspend fun loadBranchesInternal() {
        val r = requireRepo()
        branches = withContext(Dispatchers.IO) { api.branches(r.owner, r.name) }
    }

    fun createBranch(name: String, from: String) = run("创建分支") {
        val r = requireRepo()
        if (name.isBlank()) throw IllegalStateException("请输入分支名")
        withContext(Dispatchers.IO) { api.createBranch(r.owner, r.name, name.trim(), from) }
        branches = withContext(Dispatchers.IO) { api.branches(r.owner, r.name) }
        message = "分支已创建：$name"
    }

    fun deleteBranch(name: String) = run("删除分支") {
        val r = requireRepo()
        withContext(Dispatchers.IO) { api.deleteBranch(r.owner, r.name, name) }
        branches = branches.filterNot { it.name == name }
        if (branch == name) branch = r.defaultBranch
        message = "已删除分支 $name"
    }

    fun loadCommits() = run("加载提交") {
        loadCommitsInternal()
    }

    private suspend fun loadCommitsInternal() {
        val r = requireRepo()
        commits = withContext(Dispatchers.IO) { api.commits(r.owner, r.name, branch) }
    }

    // ============================================================
    // 文件：浏览 / 上传 / 下载 / 删除 / 重命名
    // ============================================================

    /** 内部版本：供其他任务在执行过程中直接刷新，不经过防重入的 run() */
    private suspend fun reloadFiles() {
        val r = requireRepo()
        entries = withContext(Dispatchers.IO) { api.contents(r.owner, r.name, path, branch) }
    }

    fun refreshFiles() = run("加载文件") { reloadFiles() }

    fun openFolder(next: String) = run("打开目录") {
        path = next
        editorPath = null
        reloadFiles()
    }

    fun goUp() {
        if (path.isBlank()) return
        val parent = path.substringBeforeLast('/', "")
        openFolder(parent)
    }

    fun openFile(entry: ContentEntry) = run("读取文件") {
        val r = requireRepo()
        val bytes = withContext(Dispatchers.IO) { api.rawBytes(r.owner, r.name, entry.path, branch) }
        val meta = withContext(Dispatchers.IO) { api.file(r.owner, r.name, entry.path, branch) }
        editorSha = meta.sha
        editorPath = entry.path
        editorBinary = !Helpers.isText(bytes)
        editorText = if (Helpers.isText(bytes)) String(bytes, Charsets.UTF_8) else "(二进制文件，共 ${Helpers.size(bytes.size.toLong())})"
        editorDirty = false
    }

    fun updateEditor(text: String) {
        editorText = text
        editorDirty = true
    }

    fun closeEditor() {
        editorPath = null
        editorText = ""
        editorDirty = false
        editorSha = null
        editorBinary = false
    }

    fun saveEditor(commitMessage: String) = run("保存文件") {
        val r = requireRepo()
        val target = editorPath ?: throw IllegalStateException("没有打开的文件")
        val sha = editorSha
        val encoded = Base64.encodeToString(editorText.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        withContext(Dispatchers.IO) {
            api.putFile(r.owner, r.name, target, commitMessage.ifBlank { "Update $target" }, encoded, sha, branch)
        }
        editorDirty = false
        val updated = withContext(Dispatchers.IO) { api.file(r.owner, r.name, target, branch) }
        editorSha = updated.sha
        message = "已提交：$target"
        reloadFiles()
    }

    /** 上传任意文件（二进制也可）：字节 -> base64 -> Contents API */
    fun uploadBytes(dirPath: String, fileName: String, bytes: ByteArray, commitMessage: String) = run("上传文件") {
        val r = requireRepo()
        if (fileName.isBlank()) throw IllegalStateException("请输入文件名")
        if (bytes.size > MAX_UPLOAD) throw IllegalStateException("文件超过 ${Helpers.size(MAX_UPLOAD)}，GitHub 单文件上限 100 MB，为避免内存溢出请控制在 20 MB 内")
        val full = if (dirPath.isBlank()) fileName.trim() else "${dirPath.trimEnd('/')}/${fileName.trim()}"
        val encoded = withContext(Dispatchers.IO) {
            Base64.encodeToString(bytes, Base64.NO_WRAP)
        }
        withContext(Dispatchers.IO) {
            api.putFile(r.owner, r.name, full, commitMessage.ifBlank { "Upload $fileName" }, encoded, null, branch)
        }
        message = "已上传：$full"
        reloadFiles()
    }

    /** 由界面拿到 Uri 后调用：读取字节并上传 */
    fun uploadUri(uri: Uri, dirPath: String, fileName: String, commitMessage: String) {
        val ctx = getApplication<Application>()
        run("上传文件") {
            val bytes = withContext(Dispatchers.IO) { Helpers.readUri(ctx, uri) }
            val name = fileName.ifBlank { Helpers.displayName(ctx, uri) }
            val r = requireRepo()
            if (bytes.size > MAX_UPLOAD) throw IllegalStateException("文件超过 ${Helpers.size(MAX_UPLOAD)}，请控制在 20 MB 内")
            val full = if (dirPath.isBlank()) name.trim() else "${dirPath.trimEnd('/')}/${name.trim()}"
            val encoded = withContext(Dispatchers.IO) { Base64.encodeToString(bytes, Base64.NO_WRAP) }
            withContext(Dispatchers.IO) {
                api.putFile(r.owner, r.name, full, commitMessage.ifBlank { "Upload $name" }, encoded, null, branch)
            }
            message = "已上传：$full"
            reloadFiles()
        }
    }

    fun createFolder(name: String) = run("创建文件夹") {
        val r = requireRepo()
        if (name.isBlank()) throw IllegalStateException("请输入文件夹名")
        val clean = name.trim().trim('/')
        val full = if (path.isBlank()) "$clean/.gitkeep" else "${path.trimEnd('/')}/$clean/.gitkeep"
        val encoded = Base64.encodeToString(ByteArray(0), Base64.NO_WRAP)
        withContext(Dispatchers.IO) {
            api.putFile(r.owner, r.name, full, "Create $clean", encoded, null, branch)
        }
        message = "已创建文件夹：$clean"
        reloadFiles()
    }

    fun createTextFile(name: String, content: String) = run("创建文件") {
        val r = requireRepo()
        if (name.isBlank()) throw IllegalStateException("请输入文件名")
        val full = if (path.isBlank()) name.trim() else "${path.trimEnd('/')}/${name.trim()}"
        val encoded = Base64.encodeToString(content.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        withContext(Dispatchers.IO) {
            api.putFile(r.owner, r.name, full, "Create ${name.trim()}", encoded, null, branch)
        }
        message = "已创建：$full"
        reloadFiles()
    }

    /** 下载文件到手机「下载」目录 */
    fun downloadEntry(entry: ContentEntry) = run("下载文件") {
        val r = requireRepo()
        val ctx = getApplication<Application>()
        if (entry.isDir) throw IllegalStateException("文件夹请逐个文件下载")
        val bytes = withContext(Dispatchers.IO) { api.rawBytes(r.owner, r.name, entry.path, branch) }
        val saved = Helpers.saveToDownloads(ctx, bytes, entry.name, Helpers.mimeOf(entry.name))
        message = saved
    }

    /** 删除文件或文件夹（文件夹会逐个子文件删除） */
    fun deleteEntry(entry: ContentEntry) = run("删除") {
        val r = requireRepo()
        if (entry.isDir) {
            val removed = withContext(Dispatchers.IO) { deleteRecursive(r, entry.path) }
            message = "已删除文件夹 ${entry.name}（共 $removed 个文件）"
        } else {
            val meta = withContext(Dispatchers.IO) { api.file(r.owner, r.name, entry.path, branch) }
            withContext(Dispatchers.IO) {
                api.deleteFile(r.owner, r.name, entry.path, "Delete ${entry.name}", meta.sha, branch)
            }
            message = "已删除 ${entry.name}"
        }
        reloadFiles()
    }

    private fun deleteRecursive(r: Repo, dir: String): Int {
        var count = 0
        val list = api.contents(r.owner, r.name, dir, branch)
        for (item in list) {
            if (item.isDir) {
                count += deleteRecursive(r, item.path)
            } else {
                val meta = api.file(r.owner, r.name, item.path, branch)
                api.deleteFile(r.owner, r.name, item.path, "Delete ${item.path}", meta.sha, branch)
                count++
            }
        }
        return count
    }

    /**
     * 重命名 / 移动：GitHub 没有重命名接口，这里实现为「取原内容 -> 写到新路径 -> 删除旧路径」。
     * 会产生两次提交，界面已提示。
     */
    fun renameEntry(entry: ContentEntry, newPath: String) = run("重命名") {
        val r = requireRepo()
        val target = newPath.trim().trim('/')
        if (target.isBlank()) throw IllegalStateException("请输入新路径")
        if (target == entry.path) throw IllegalStateException("新路径与原路径相同")
        if (entry.isDir) throw IllegalStateException("暂不支持直接重命名文件夹，请逐文件操作")
        val bytes = withContext(Dispatchers.IO) { api.rawBytes(r.owner, r.name, entry.path, branch) }
        val encoded = withContext(Dispatchers.IO) { Base64.encodeToString(bytes, Base64.NO_WRAP) }
        withContext(Dispatchers.IO) {
            api.putFile(r.owner, r.name, target, "Rename ${entry.name} -> ${target.substringAfterLast('/')}", encoded, null, branch)
            val meta = api.file(r.owner, r.name, entry.path, branch)
            api.deleteFile(r.owner, r.name, entry.path, "Remove ${entry.name} (renamed)", meta.sha, branch)
        }
        message = "已重命名为 $target（两次提交）"
        reloadFiles()
    }

    fun fileWebUrl(entry: ContentEntry): String {
        val r = requireRepo()
        return "https://github.com/${r.owner}/${r.name}/blob/$branch/${entry.path}"
    }

    // ============================================================
    // Actions：编译 / 日志 / 产物
    // ============================================================

    fun loadActions() = run("加载 Actions") {
        loadActionsInternal()
    }

    private suspend fun loadActionsInternal() {
        val r = requireRepo()
        workflows = withContext(Dispatchers.IO) { api.workflows(r.owner, r.name) }
        runs = withContext(Dispatchers.IO) { api.runs(r.owner, r.name) }
    }

    fun triggerWorkflow(workflow: Workflow, ref: String, inputs: Map<String, String>) = run("触发编译") {
        val r = requireRepo()
        withContext(Dispatchers.IO) { api.dispatch(r.owner, r.name, workflow.id, ref.ifBlank { branch }, inputs) }
        message = "已触发 ${workflow.name}，稍后刷新查看进度"
        runs = withContext(Dispatchers.IO) { api.runs(r.owner, r.name) }
    }

    fun refreshRuns() = run("刷新运行") {
        val r = requireRepo()
        runs = withContext(Dispatchers.IO) { api.runs(r.owner, r.name) }
    }

    fun selectRun(run: WorkflowRun) = run("加载详情") {
        selectedRunId = run.id
        val r = requireRepo()
        jobs = withContext(Dispatchers.IO) { api.jobs(r.owner, r.name, run.id) }
        artifacts = withContext(Dispatchers.IO) { api.artifacts(r.owner, r.name, run.id) }
        logText = null
    }

    fun cancelRun() = run("取消运行") {
        val r = requireRepo()
        val id = selectedRunId ?: throw IllegalStateException("请先选择一次运行")
        withContext(Dispatchers.IO) { api.cancelRun(r.owner, r.name, id) }
        message = "已请求取消"
        runs = withContext(Dispatchers.IO) { api.runs(r.owner, r.name) }
    }

    fun rerunRun(failedOnly: Boolean) = run("重跑") {
        val r = requireRepo()
        val id = selectedRunId ?: throw IllegalStateException("请先选择一次运行")
        withContext(Dispatchers.IO) {
            if (failedOnly) api.rerunFailed(r.owner, r.name, id) else api.rerunRun(r.owner, r.name, id)
        }
        message = if (failedOnly) "已重跑失败任务" else "已重新运行"
        runs = withContext(Dispatchers.IO) { api.runs(r.owner, r.name) }
    }

    /** 查看日志：下载 zip 并解压成文本 */
    fun viewLogs() = run("下载日志") {
        val r = requireRepo()
        val id = selectedRunId ?: throw IllegalStateException("请先选择一次运行")
        val bytes = withContext(Dispatchers.IO) { api.runLogsZip(r.owner, r.name, id) }
        logText = Helpers.zipToText(bytes)
        logTitle = "运行 #$id 日志"
        message = "日志已载入（${Helpers.size(bytes.size.toLong())}）"
    }

    /** 保存日志到手机（原始 zip + 文本各一份） */
    fun saveLogs() = run("保存日志") {
        val r = requireRepo()
        val id = selectedRunId ?: throw IllegalStateException("请先选择一次运行")
        val ctx = getApplication<Application>()
        val bytes = withContext(Dispatchers.IO) { api.runLogsZip(r.owner, r.name, id) }
        Helpers.saveToDownloads(ctx, bytes, "run-$id-logs.zip", "application/zip")
        val text = Helpers.zipToText(bytes)
        Helpers.saveToDownloads(ctx, text.toByteArray(Charsets.UTF_8), "run-$id-logs.txt", "text/plain")
        message = "日志已保存到 下载/GitHubManager/"
    }

    /** 单个任务的日志（更精确，失败时定位更快） */
    fun viewJobLogs(job: WorkflowJob) = run("下载日志") {
        val r = requireRepo()
        val bytes = withContext(Dispatchers.IO) { api.jobLogsZip(r.owner, r.name, job.id) }
        logText = Helpers.zipToText(bytes)
        logTitle = "${job.name} 日志"
    }

    fun clearLogs() { logText = null }

    /** 产物可复制的各类地址 */
    fun artifactLinks(artifact: Artifact): List<Pair<String, String>> {
        val r = requireRepo()
        val runId = selectedRunId ?: 0L
        return listOf(
            "网页下载链接" to api.artifactWebUrl(r.owner, r.name, runId, artifact.id),
            "API 直链（需令牌）" to api.artifactApiUrl(r.owner, r.name, artifact.id),
            "curl 命令（含令牌）" to api.artifactCurl(r.owner, r.name, artifact.id),
            "运行页面" to (runs.firstOrNull { it.id == runId }?.htmlUrl
                ?: "https://github.com/${r.owner}/${r.name}/actions")
        )
    }

    /** 解析出的直链（跟随 302 后的最终地址），供复制后直接在浏览器打开 */
    fun resolveArtifactUrl(artifact: Artifact) = run("解析地址") {
        val r = requireRepo()
        val link = withContext(Dispatchers.IO) { api.artifactDownloadUrl(r.owner, r.name, artifact.id) }
        copy(link, "产物下载地址")
        message = "已复制下载地址（1 分钟内有效）"
    }

    /**
     * 应用内下载产物。产物本身是 zip，extractApk=true 时直接解出里面的 apk 保存。
     */
    fun downloadArtifact(artifact: Artifact, extractApk: Boolean) = run("下载产物") {
        val r = requireRepo()
        val ctx = getApplication<Application>()
        val bytes = withContext(Dispatchers.IO) { api.artifactBytes(r.owner, r.name, artifact.id) }
        if (!extractApk) {
            val saved = Helpers.saveToDownloads(ctx, bytes, "${artifact.name}.zip", "application/zip")
            message = saved
            return@run
        }
        val found = Helpers.extractFirst(bytes, ".apk")
        if (found == null) {
            val saved = Helpers.saveToDownloads(ctx, bytes, "${artifact.name}.zip", "application/zip")
            message = "未找到 APK，已保存原始 zip：$saved"
        } else {
            val saved = Helpers.saveToDownloads(ctx, found.second, found.first, "application/vnd.android.package-archive")
            message = saved
        }
    }

    // ============================================================
    // Issues / PR / Release
    // ============================================================

    fun loadIssues(state: String) = run("加载 Issues") {
        loadIssuesInternal(state)
    }

    private suspend fun loadIssuesInternal(state: String) {
        val r = requireRepo()
        issues = withContext(Dispatchers.IO) { api.issues(r.owner, r.name, state) }
    }

    fun createIssue(title: String, body: String) = run("创建 Issue") {
        val r = requireRepo()
        if (title.isBlank()) throw IllegalStateException("请输入标题")
        val number = withContext(Dispatchers.IO) { api.createIssue(r.owner, r.name, title.trim(), body) }
        issues = withContext(Dispatchers.IO) { api.issues(r.owner, r.name, "open") }
        message = "已创建 #$number"
    }

    fun setIssueState(issue: Issue, state: String) = run("更新状态") {
        val r = requireRepo()
        withContext(Dispatchers.IO) { api.setIssueState(r.owner, r.name, issue.number, state) }
        issues = withContext(Dispatchers.IO) { api.issues(r.owner, r.name, "open") }
        message = "#${issue.number} 已${if (state == "closed") "关闭" else "重新打开"}"
    }

    fun loadPulls(state: String) = run("加载 PR") {
        loadPullsInternal(state)
    }

    private suspend fun loadPullsInternal(state: String) {
        val r = requireRepo()
        pulls = withContext(Dispatchers.IO) { api.pulls(r.owner, r.name, state) }
    }

    fun mergePull(pull: Issue) = run("合并 PR") {
        val r = requireRepo()
        withContext(Dispatchers.IO) { api.mergePull(r.owner, r.name, pull.number) }
        pulls = withContext(Dispatchers.IO) { api.pulls(r.owner, r.name, "open") }
        message = "已合并 #${pull.number}"
    }

    fun loadReleases() = run("加载 Release") {
        loadReleasesInternal()
    }

    private suspend fun loadReleasesInternal() {
        val r = requireRepo()
        releases = withContext(Dispatchers.IO) { api.releases(r.owner, r.name) }
    }

    fun downloadAsset(asset: ReleaseAsset) = run("下载附件") {
        val r = requireRepo()
        val ctx = getApplication<Application>()
        val bytes = withContext(Dispatchers.IO) { api.releaseAssetBytes(r.owner, r.name, asset.id) }
        val saved = Helpers.saveToDownloads(ctx, bytes, asset.name, Helpers.mimeOf(asset.name))
        message = saved
    }

    /**
     * 切换子页面。这里必须调用内部 suspend 版本：若调用公开的 run() 包装函数，
     * 会因为外层 run 已把 busy 置为 true 而被防重入逻辑直接返回，导致切页不加载数据。
     */
    fun setTab(next: Tab) {
        tab = next
        run("加载") {
            when (next) {
                Tab.FILES -> if (entries.isEmpty()) reloadFiles()
                Tab.ACTIONS -> loadActionsInternal()
                Tab.ISSUES -> loadIssuesInternal("open")
                Tab.PULLS -> loadPullsInternal("open")
                Tab.RELEASES -> loadReleasesInternal()
                Tab.COMMITS -> loadCommitsInternal()
                Tab.BRANCHES -> loadBranchesInternal()
            }
        }
    }

    companion object {
        /** 上传体积上限：GitHub 限制 100 MB，这里保守设 20 MB 以避免 base64 编码导致内存溢出 */
        const val MAX_UPLOAD = 20L * 1024 * 1024
    }
}
