# OC网关 · 改包名后必读

本次相对 r5d 只改了**外观与身份**，网关逻辑一行没动：

| 项 | 旧值 | 新值 |
|---|---|---|
| 应用显示名 / 主页顶栏大字 | 限量网关 | **OC网关** |
| 包名 / namespace / applicationId | `com.android.cloudflare` | **`com.android.opencoderootfs`** |
| APP 图标 / 悬浮窗图标 / 通知栏图标 | 旧漏斗图 | 用户提供的青绿渐变管道插画 |

同步改掉的还有：JNI 函数名（`Java_com_android_opencoderootfs_core_NodeBridge_*`）、
proguard 规则、四个 Action 常量、`MainActivity` 的包名提示、文档里的 adb 命令、
Gradle 项目名（`OCGateway`，保持 ASCII 以免 CI locale 问题）。

## ⚠ 改包名 = 全新应用，数据不共享

`com.android.opencoderootfs` 与手机上正在用的 `com.android.cloudflare` 是**两个独立 APP**：
私有目录、配置、已解压的 rootfs、认证方式设置全部不继承。

按这个顺序做，避免端口冲突：

1. **先停旧 APP**：在旧「限量网关」里点「停止网关」，再在系统设置里强制停止；
   确认后可以直接卸载它（卸载不会删 `/sdcard/Download/` 里的归档）。
   > 两个 APP 都占用 `4317`（opencode serve）和 `18900`（网关），绝不能同时运行。
2. **装新 APK**：`adb install -r` 或文件管理器点击安装。这是全新安装，不覆盖旧 APP。
3. **首次启动**：允许存储权限 → 主界面「启动网关」→「打开管理页」。
4. **导入同一份归档**：`/sdcard/Download/rootfs-arm64.tar.gz`（或 `rootfs-arm64.zip`）保持不变，
   管理页顶部会探测到 → 点「📥 一键导入并重启」→ 等 1~3 分钟解包。
5. **认证方式切 `basic`**（关键）：管理页 ② opencode serve → 「认证方式」由默认的 `query`
   改成 **`basic`** → 保存 → 点「重启 CLI」。这正是上一轮验证通过的做法，r5d 默认值仍是 `query`。
6. 点「🔬 端到端自检」，通了再回 RikkaHub 发一句「你好」。

## RikkaHub 不用改

| 项 | 值 |
|---|---|
| Base URL | `http://127.0.0.1:18900/v1` |
| 请求路径 | `/chat/completions` |
| API Key | `Rikka-2026-CF-Proxy-Key-8f3b` |

本机 Key 是工程里的**固定默认值**，不是按包名随机生成的，所以新 APP 装完仍是同一串，
RikkaHub 里已经配好的不用动。

## 图标说明

母版 `docs/icon-source.png` 就是你上传的图（1256×1115，完全不透明）。
`scripts/render_icons.py` 会从中生成：

- `drawable-nodpi/ic_gateway_art.png`：居中裁成正方形 512×512（左右各裁 5.6%，
  橙色节点与右侧管线端点都在安全区）→ APP 图标 / 悬浮窗 / 通知大图标共用；
- `drawable-nodpi/ic_gateway_status.png`：白色管线剪影，用于**状态栏小图标**与
  Android 12+ 主题图标。系统按 alpha 染色、忽略 RGB，所以这里必须是剪影；
  直接塞彩色位图会在状态栏变成一坨白方块。剪影仍是你这张图的管线形状；
- `mipmap-*/ic_launcher.png` / `ic_launcher_round.png`：5 个密度的传统图标；
- `mipmap-anydpi-v26/*.xml`：自适应图标，foreground 铺满 108dp 画布由系统遮罩裁切，
  background 用同色系青绿→蓝渐变补遮罩外一圈。

`docs/icon-preview.png` 是三格预览（彩色主图 / 剪影 / 桌面效果）。

其余排障（429 别连点、别卸载 APP、归档别删）与 `PROOT_README.md` 一致。
