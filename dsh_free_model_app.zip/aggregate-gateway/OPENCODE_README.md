# 限量网关 → OpenCode 免费模型本地网关（oc-free-gateway-r1）

## 一句话结论

**能改，壳一行没动。** 这个工程本来就是「Android 里跑 Node 服务 → 只在 `127.0.0.1` 暴露 OpenAI 兼容端点 → RikkaHub 对接」。本次只把 `cf-proxy.cjs` 换成 `oc-proxy.cjs`：前台服务、唤醒锁、悬浮窗、开机自启、健康探活、管理页 WebView、RikkaHub 交接、二维码、日志自检**全部原样复用**。

但有一句必须写在最前面：

> **OpenCode 官方明确不允许把免费层当 API 用。** Harnesses 文档原话：「Free-tier chat models are only available from within OpenCode. Other harnesses receive HTTP 403 for those models, **even with a Console API key**.」
> 所以本网关的免费模式是**客户端指纹桥接**，不是官方接口；规则由服务端动态调整，随时可能失效。已在管理页保留了 `console` 模式与自动降级，用你自己创建的 Console Key 走官方付费/Go 网关才是稳定路径。

---

## 这次到底改了什么

| 文件 | 处理 |
|---|---|
| `app/src/main/assets/node/oc-proxy.cjs` | **新增**：网关核心（零 npm 依赖）。免费层指纹、SSE↔JSON 双向适配、三种模式、模型清单、管理页全在这里 |
| `app/src/main/assets/node/cf-proxy.cjs` | **删除**：旧 CF 版含硬编码 Cloudflare 账户 ID / API 令牌，已一并移除 |
| `app/src/main/assets/node/bootstrap.cjs` | 改为 `require('./oc-proxy.cjs')`，日志前缀 `[oc-proxy]`，其余启动/回写/自检逻辑不变 |
| `app/src/main/assets/node/package.json` | 名称与描述改为 OpenCode 版 |
| `app/src/main/assets/node/bundle-version.txt` | `oc-free-gateway-r1`：与旧值不同，**覆盖安装会强制重建 nodeHome**，不会残留旧 `cf-proxy.cjs` |
| `app/src/main/assets/node/packages/standalone/cli.mjs` | 占位注释更新（文件本身仍保留，只为满足完整性判据） |
| `core/AssetInstaller.kt` | 完整性判据加入 `oc-proxy.cjs` |
| `core/SourceUpdater.kt` | 文案改版；「更新上游源码」仍然禁用，避免覆盖网关代码 |
| `res/values/strings.xml` | 副标题 / 管理页副标题 / 页脚 / 帮助文案改为 OpenCode 版 |
| `scripts/prepare-node-bundle.sh` | 校验 `oc-proxy.cjs`，刷新版本标记，CI 流程不变 |
| `.github/workflows/build.yml` | 第 6 步名称与构建前自检的判据改成 OpenCode 版（编译逻辑未动） |
| `README.md` | 顶部说明指向本文档 |
| `OPENCODE_README.md` | 本文件（原 `CLOUDFLARE_README.md` 已删除） |

**未改动**：包名 `com.android.cloudflare`（JNI 函数名绑定，改包名要连 C 胶水一起改，风险大）、全部其它 Kotlin / Java / C 胶水 / CMake / Manifest / 图标 / Gradle 配置。包名只是历史遗留，与 Cloudflare 已无关系。

---

## 管理页：自己填 Key（你要的那一步）

装好 APK → 启动网关 → 主界面点「打开管理页」（`http://127.0.0.1:<端口>/`）→ 第一个输入框就是 **OpenCode Console API Key**。

```
① OpenCode Console API Key   [ 粘贴你在 opencode.ai 控制台创建的 key ]
② 本机 API Key（RikkaHub 用）[ 留空 = 不修改，默认沿用旧版值 ]
③ 调用模式                   [ auto / free / console ]
④ Console 网关路径           [ /inference/openai/v1/chat/completions ]
                              （Go 订阅改成 /inference/go/openai/v1/chat/completions）
保存并清空模型缓存
```

- Key 写入 APP 私有目录 `ofm-data/oc-config.json`（权限 `0600`），页面只显示掩码，**不会**出现在二维码 / 分享串 / 日志里。
- 改 `consoleKey` / 模式 / 指纹参数**即时生效**，不用重启；改「本机 API Key」后请回主界面「停止网关 → 启动网关」让状态栏与二维码刷新，并同步改 RikkaHub。
- 免费层本身**不需要任何 key**。填 key 的用途是：自动降级、或显式切到 `console` 模式用付费模型。

### 三种模式

| 模式 | 走哪条路 | 需要 key | 说明 |
|---|---|---|---|
| `free` | `opencode.ai/inference/openai/v1/chat/completions`，`Bearer public` + 指纹 | 不需要 | 纯免费层；被拒就直接报错 |
| `console` | 官方 Console 网关，诚实 UA + 稳定 session | **需要** | 只调付费/Go 模型（官方明确支持第三方 harness） |
| `auto`（默认） | 先 `free`；遇 403/429/426 且已填 key → 自动把模型 ID 去掉 `-free` 后缀重发到 Console | 填了才降级 | 免费被风控时还能继续聊 |

降级时模型映射默认规则：`xxx-free → xxx`。可在管理页「免费 → 付费模型映射」里逐行覆盖，例如 `big-pickle=glm-5.3-flash`。**隐身模型（Big Pickle 等）没有同名付费版，不写映射就会降级失败**，这是正常的。

---

## 原理：为什么免费层「不要账号」却还是会被拒

OpenCode 免费层把鉴权从「你是谁」换成了「这个请求像不像 OpenCode 客户端发的」。`oc-proxy.cjs` 做的事：

| 层 | 实现 |
|---|---|
| `User-Agent` | `opencode/1.18.31`（管理页可改；版本过低会 426） |
| session 头 | `x-opencode-session` / `x-opencode-session-id` / `x-session-id` / `x-session-affinity`，用 `ses_` + 12 位 hex + 14 位 base62 的 descending identifier；按「首条 user 消息 + 模型」哈希，让同一段对话复用同一个 ID |
| 请求体 | 强制 `stream:true`；注入 `tools` 数组（含 `bash`/`read`/`glob`/`grep`）；再插一条 system 提示「不要真调工具，用纯文本回答」 |
| 认证 | `Authorization: Bearer public`（免费层不校验，只为对齐客户端） |
| 响应适配 | 免费层强制流式 → 客户端要非流式时把 SSE 聚合成 `chat.completion`；客户端要流式时逐帧透传；上游若给 JSON 则转成 SSE |
| 稳定会话 | 30 分钟内同一对话复用同一 session，利于上游路由与 prompt cache |

`stream:true` 是硬要求（`false` 直接 403），所以**非流式聚合是必须的**，这也是改造版和旧 CF 版「原样 pipe」最大的差别。另外免费模式会覆盖 `tools`，因此 **RikkaHub 的工具 / MCP 调用在免费模式下不可用**，要用工具请切 `console` 模式。

管理页还留了 `ua` / `client` / `sidStyle` / `extraHeaders` 四个可调项：上游哪天加新校验头，不用重编译 APK，填进「追加请求头（JSON）」即可。

---

## 模型清单

`GET /v1/models` 的优先级：

1. 管理页「自定义模型 ID」（每行一个）→ 整份覆盖；
2. 否则尝试上游 `GET /inference/openai/v1/models`（带指纹头），失败/超时 8 秒 → 回退；
3. 内置 2026-11-11 抓自 `opencode.ai/docs/zen` 的 20 个免费位（中英两版合并）。

默认会**隐藏对中国大陆/港澳不可用的模型**（Beam Free），可在管理页关掉。免费模式只暴露免费位；`console` 模式列上游全部模型。缓存 30 分钟，`/v1/models?refresh=1` 或管理页链接可强制刷新。

⚠️ 免费位**限时轮换**，Crouton Alpha Free 已在 2026-11-09 下线。别把某个 `-free` ID 当长期常量写死；建议每次用主界面「复制模型 ID」重新拉一次。

---

## 编译（沿用原来的 GitHub Actions）

1. 把本工程包按原习惯命名为 **`dsh_free_model_app.zip`** 放到仓库根目录（zip 里套一层 `aggregate-gateway/`）；`.github/workflows/build.yml` 必须作为**明文文件**单独提交，GitHub 不执行压缩包里的 workflow。
2. 提交触发 Actions，或手动 Run workflow。
3. CI：解压 → JDK/SDK/NDK → `prepare-node-bundle.sh` 离线校验两个 `.cjs` 语法 → 下载 `libnode.so`（Node 22+）→ `assembleDebug` → 产出 `AggregateGateway-*.apk`。
4. 安装 APK，点「启动网关」，状态 READY 后点「打开管理页」填 Console Key。

`libnode.so` 仍由 CI 下载，改造只把 `assets/node` 从 CF 版 4 个文本换成 OC 版 4 个文本，体积几乎不变。

---

## RikkaHub 配置

| 项 | 值 |
|---|---|
| 供应商类型 | OpenAI |
| API Base Url | `http://127.0.0.1:18900/v1`（以主界面端口为准，占用会顺延） |
| API 路径 | `/chat/completions` |
| API Key | 主界面「复制 API Key」那个**本机 Key**（不是 Console Key） |
| Response API | 关 |
| 自定义 Header | 不需要 |
| 模型 | 「复制模型 ID」后手动添加，或管理页看清单 |

---

## 排障：免费层被拒怎么办

| 现象 | 原因 | 处理 |
|---|---|---|
| `403 FreeTierError: only be used from within OpenCode` | 指纹校验没过 / 官方收紧规则 | 管理页改 UA、`client=desktop`、`sidStyle=random`；`auto` 模式会自动降级；仍不行切 `console` |
| `429 FreeUsageLimitError` | **Node/OpenSSL 的 TLS Client Hello 指纹**被判非官方客户端（社区实测 Bun 能过、Node 易挂），或网关侧限流 | 这是本方案在 nodejs-mobile 上最大的不确定性；换网络、稍后重试，或直接用 `console` 模式 |
| `detected abusive traffic from this IP address` | IP 级风控，与公司/学校 NAT、VPN、代理有关 | 关代理、换蜂窝网络；官方不按账号解封 |
| `426` | UA 版本过低 | 管理页把 UA 调到较新版本 |
| 一直转圈 / 空回复 | 免费层强制 SSE，聚合失败 | 看 `bootstrap.log` 的 `[oc-proxy]` 行；RikkaHub 里先关流式试一次 |
| 某个模型突然 404 | 限时免费位下架 | 刷新模型清单，换一个 |
| 中国大陆选 Beam Free 报错 | 官方地区排除 | 管理页默认已隐藏，别手动打开 |

排查顺序：`bootstrap.log`（`[oc-proxy]` 行）→ `node-output.log` → `node-fatal.txt`。
自检命令：手机浏览器 `curl http://127.0.0.1:18900/health`，应返回 `{"ok":true,"service":"opencode-free-gateway",...}`。

---

## 安全与隐私（请务必看）

1. **旧版 `cf-proxy.cjs` 里硬编码了真实的 Cloudflare 账户 ID 与 API 令牌（`cfut_…`）**。改造版已删除该文件与所有凭据。**建议去 Cloudflare 控制台轮换那枚令牌**，因为它曾随源码/APK 明文分发过。
2. 本版**不内置任何 OpenCode key**；你的 Console Key 由自己在管理页填写，只存本机私有目录。不要把 key 写进 `oc-proxy.cjs` 的 `DEFAULTS`（assets 不加密，拿到 APK 就能解出）。
3. 免费模型的数据条款**不一致**：GLM-5.3-Flash Free / DeepSeek V4.1 Flash Free / MiniMax M3.1 Flash Free / Space Bunny / LongCat 系列标注零留存、不用于训练；Big Pickle、Iceman、MiMo、Nemotron 等明确会收集反馈改进模型。**写公司代码优先选零留存那几款**。
4. 用免费模型时，聊天内容会经过 `opencode.ai` 网关（官方称 Zen 模型托管 US/EU）。敏感仓库建议 `console` 模式 + 自带 provider key，或干脆本地 Ollama。
5. 管理页 `/config` 不鉴权，因此网关固定只监听 `127.0.0.1`；「局域网中继」开关依旧无效，别把它暴露到 LAN。

---

## 合规提醒

免费层桥接属于对未公开客户端校验的模拟，**不保证长期可用**，也不代表官方授权。若你要稳定、可商用、能给别的工具当 API 用，正确路径是：

- OpenCode Console **按量付费 key** → `/inference/openai/v1/chat/completions`
- **Go / Go Plus 订阅** → `/inference/go/openai/v1/chat/completions`（$10 / $40 每月，按模型分月度额度）
- 或干脆接 OpenRouter 免费位、本地 Ollama / LM Studio 这类本来就提供公开 OpenAI 兼容端点的源

这套网关最适合当**周末实验**：验证「RikkaHub 能不能用上 OpenCode 免费模型」，并给你留好一条一键切到正规付费路的后路。
