# OpenCode 网关说明（历史文档入口）

> 本文件已过时，保留仅为便于老用户查找。
>
> **当前版本：`oc-proot-gateway-r5d`（方案 C / bridge-only / 只用免费模型）。**
> 完整说明、rootfs 来源与自建步骤、导入方式、排障表请看 **[`PROOT_README.md`](PROOT_README.md)**。

版本演进摘要：

| 版本 | 出网进程 | 免费模型 | 结果 |
|---|---|---|---|
| r1 | Node 独立进程直连 | 裸请求 / 缺指纹 | 429 |
| r2 | 同上 | 补齐 UA / session / TLS cipher / `<environment>` / tools | 429 |
| r3 | 同上，改走官方付费 / Go 端点 | 不用免费模型 | 可 200（需充值 / 订阅） |
| **r5** | **proot 里的官方 OpenCode CLI（`opencode serve`）** | **是** | **实证可 200，免账号 Key** |

结论没变：免费层校验的是**真实客户端进程的连接态**，不是请求里能携带的任何字段。所以 r5 不再伪造任何东西，直接让官方进程替我们出网。
