# 限量网关 → OpenCode 免费模型本地网关（oc-free-gateway-r2）

## 一句话结论

**r2 是专门修「只想用免费模型却一直 429」的版本。** 壳（前台服务 / JNI / 悬浮窗 / 探活 / 二维码 / 日志）一行没动，只重写了 `oc-proxy.cjs`。

默认模式已改成 **`free`**：只用免费层，即使上游 403/429 也**绝不偷偷降级到付费模型**。Console Key 可以完全不填。

---

## r2 修了什么：429 FreeUsageLimitError 不是「额度用完」

这是最容易误判的一点。官方对**非 OpenCode 客户端**的所有拒绝都统一回 `429 FreeUsageLimitError`，还附带一个指向 `00:00 UTC` 的 retry-after，看起来跟额度耗尽一模一样。社区实测确认它其实是「你不是 OpenCode 客户端」的意思。

免费层有三道门，r1 只过了一道：

| 门 | 要求 | r1 | r2 |
|---|---|---|---|
| ① TLS ClientHello | cipher list 必须是 Bun/BoringSSL 的 **17 个套件、顺序一致**（含末尾 8 个 legacy）；Node 默认 hello 被拒 | ❌ 完全没设 | ✅ `https.request({ ciphers })` 直接调，**不需要 Bun / 原生插件** |
| ② 会话头 | `x-opencode-session` 必须是合法 `ses_` 形状 | ✅ | ✅ 另补 `x-opencode-project: global`、`x-opencode-request: msg_…` |
| ③ 请求体 | 必须有名为 `read` 的工具；system 里必须有官方 `<environment>` 块且带**真实** `Working directory:` 行；`stream:true` | ❌ 只有 4 个 stub 工具，且塞了一句 "Do NOT call any tools" | ✅ 官方 10 工具名（read 带完整定义）+ 真实环境块，且**合并进已有 system** 不产生第二条 |

第 ③ 条最致命：有社区实测记录，**缺 `<environment>` 块的非官方请求每天只有很小一份 allowance，用完就 429 直到 UTC 0 点（北京时间 08:00）重置**；而 `Working directory: unknown` 这种固定占位自 2026-10-29 起会被立刻拒。r1 那句 `TOOL_GUARD` 恰好是「另一个 agent」的典型标志。

> **更正 r1 文档的说法**：「Node/OpenSSL 的 TLS 指纹在安卓上无解」是错的。Node 的 `https.request` 支持 `ciphers` 选项，`dsh-opencode-freeaccess` 实测「调好 cipher 列表的纯 node:https 就够了，不需要 Bun、不需要原生插件、不需要代理」。r2 已内置该列表；若本机 OpenSSL 不接受某个套件名导致握手失败，网关会自动去掉 ciphers 回退重试一次并写日志。

### 其它 r2 改动

- UA 改成抓包自真实客户端的完整串 `opencode/1.19.5 ai-sdk/provider-utils/4.0.23 runtime/bun/1.3.14`（r1 是裸 `opencode/1.18.31`）。
- 新增 **`GET /selftest`** 与管理页「🔬 一键测试免费层」按钮：用与真实聊天**完全相同**的请求体、请求头和 TLS 设置发一句 `hi`，直接回报 HTTP 状态码、本次发出的完整指纹快照、上游返回原文。**别再用 RikkaHub 连点重试**——连续重试只会把 allowance 窗口推远。
- 429/403 错误中文化，明确写出「这不是额度用完」和 UTC 0 点重置时间，同时保留上游原文。
- `envPrompt` / `toolsJson` / `ciphers` / `extraHeaders` / `project` / `useRequestId` 全部外置成管理页可编辑字段：上游哪天改规则，不用重编译 APK。Windows 客户端抓包到的完整 tools JSON 可以直接粘进去。
- `bundle-version.txt` → `oc-free-gateway-r2`，覆盖安装强制重建 `nodeHome`，不会残留 r1 代码。

---

## 这次工程里改了哪些文件

| 文件 | 处理 |
|---|---|
| `assets/node/oc-proxy.cjs` | **重写为 r2**：cipher list、environment 块、官方 10 工具、完整 UA/头、free 默认、一键自检、错误中文化 |
| `assets/node/bootstrap.cjs` | 加载 `oc-proxy.cjs`，日志前缀 `[oc-proxy]`（r1 已改，r2 未动） |
| `assets/node/bundle-version.txt` | `oc-free-gateway-r2` |
| `assets/node/package.json` / `packages/standalone/cli.mjs` | 占位，满足 AssetInstaller / CI 完整性判据 |
| `core/AssetInstaller.kt` | 完整性判据含 `oc-proxy.cjs` |
| `core/SourceUpdater.kt` | 「更新上游源码」仍禁用，避免覆盖网关代码 |
| `res/values/strings.xml` | 副标题 / 管理页副标题 / 帮助文案 |
| `scripts/prepare-node-bundle.sh` | 离线校验两个 `.cjs`，刷新版本标记 |
| `.github/workflows/build.yml` | 第 6 步名称与自检判据（编译逻辑未动） |
| `README.md` | 顶部指向本文档 |
| `cf-proxy.cjs` / `CLOUDFLARE_README.md` | **已删除**（旧 CF 版含硬编码真实凭据） |

**未改动**：包名 `com.android.cloudflare`（JNI 函数名绑定，改包名要连 C 胶水一起改）、全部其它 Kotlin / Java / C 胶水 / CMake / Manifest / 图标 / Gradle 配置。

---

## 只想用免费模型：装好后的操作顺序

1. 编译安装 APK → 主界面「启动网关」→ 状态 READY。
2. 点「打开管理页」→ **Console Key 那一整段直接跳过**；确认「调用模式」是 `free`（r2 默认）。
3. **先点「🔬 一键测试免费层」**，看返回：
   - `HTTP 200` → 免费层已放行，回 RikkaHub 正常聊天。
   - `HTTP 429 / 403` → 看「上游返回原文」和「本次发出的指纹」，按下方排障表处理。
4. RikkaHub 配置：类型 OpenAI，Base URL `http://127.0.0.1:18900/v1`，路径 `/chat/completions`，Key 用主界面「复制 API Key」那个**本机 Key**（不是 Console Key），模型从「复制模型 ID」里选。

管理页「当前模型清单」默认取上游 `/inference/openai/v1/models`，失败回退内置 20 个免费位；默认隐藏 Beam Free（不对中国大陆/港澳提供）。

---

## 排障表（免费层）

| 现象 | 原因 | 处理 |
|---|---|---|
| 自检 `429 FreeUsageLimitError` | 非官方客户端的通用拒绝语；或当日小额 allowance 已耗 | **先停手**，等 UTC 0 点（北京时间 08:00）再试一次；不要连点 |
| 自检 `403 FreeTierError` | 请求体形状没过 | 确认 `injectTools=开`、environment 块内含真实 `Working directory: /…`、tools 里有 `read`；把 Windows 客户端抓包的完整 tools JSON 粘进「tools 数组覆盖」 |
| 自检 `status 0` / TLS 报错 | 本机 OpenSSL 不接受 cipher list 里的某个套件名 | 网关会自动回退默认列表重试一次；若仍失败，把「TLS cipher list」清空、或只保留前 9 个 ECDHE 套件 |
| 自检 200 但 RikkaHub 仍失败 | 多半是本机 Key / Base URL / 模型 ID 不一致 | 回主界面重新复制 Base URL 与 Key，RikkaHub 里新开一个聊天 |
| `426` | UA 版本过低 | 管理页把 UA 调到较新版本 |
| 一直转圈 / 空回复 | 免费层强制 SSE | 看 `bootstrap.log` 的 `[oc-proxy]` 行；RikkaHub 里先关流式试一次 |
| 某个模型突然 404 | 限时免费位下架 | 刷新模型清单换一个 |
| `detected abusive traffic from this IP` | IP 级风控，与共享 NAT / VPN / 代理有关 | 关代理、换蜂窝网络；官方不按账号解封 |

**最有价值的对照实验**：在同一网络下，用你已成功的 **Windows 版 OpenCode 客户端**此刻再发一句「你好」。
- Windows 也 429 → 是出口 IP / 当日窗口问题，跟网关无关，等冷却或换网络；
- Windows 正常 200、Android 429 → 是客户端连接态校验，本网关补不齐，见下方「必须接受的可能」。

排查顺序：管理页一键自检 → `bootstrap.log`（`[oc-proxy]` 行）→ `node-output.log` → `node-fatal.txt`。
手机浏览器直接开 `http://127.0.0.1:18900/selftest` 也能看自检 JSON。

---

## 必须接受的可能

11 月初有实测记录：同一时刻真实 `opencode serve` 进程稳定 200，而**所有独立脚本直连一律 429**——Bun / Node、cli/desktop 全套头、JA3/JA4 指纹、真或假 session、2KB 到 234KB 原报文、官方 system prompt 全试过都救不回来，结论是网关放行的是「真实客户端进程的连接态」，不是请求里能带的任何字段。另一份用真实账号 token + org + 完整重放头的测试也得到同样结论。

**所以 r2 不保证能过。** 它把三道门里所有能从 JS 层补齐的都补齐了、把每次请求的指纹摊开给你看、并且不再偷偷花你的钱。若一键自检 + Windows 对照实验都指向「连接态」，那 Android 这条直连路就走不通了——继续调 UA / session / cipher list 是浪费时间。

真要在手机上跑真实客户端进程，得把 arm64 的 Bun + 完整 OpenCode CLI 塞进 APK 并让 `opencode serve` 无头常驻，这与当前「零依赖单文件网关」的壳是两套架构，工作量不在同一量级。

---

## 编译（沿用原来的 GitHub Actions）

1. 工程包按原习惯命名为 **`dsh_free_model_app.zip`** 放仓库根目录（zip 里套一层 `aggregate-gateway/`）；`.github/workflows/build.yml` 必须作为**明文文件**单独提交，GitHub 不执行压缩包里的 workflow。
2. 提交触发 Actions，或手动 Run workflow。CI：解压 → JDK/SDK/NDK → 离线校验两个 `.cjs` 语法 → 下载 `libnode.so`（Node 22+）→ `assembleDebug` → 产出 `AggregateGateway-*.apk`。
3. 覆盖安装即可，`bundle-version.txt` 已换值，会强制重建 `nodeHome`。

沙盒无 Android SDK，**没实机编译 APK**；JS 侧已通过 `node --check` 与两套本地 mock 上游自测（共 40+ 项：SSE 聚合、流式透传、指纹头、environment 块、17 套件 cipher、free 不降级、auto 降级、console 直连、一键自检、配置落盘与掩码）。

---

## 安全与隐私

1. 旧版 `cf-proxy.cjs` 里硬编码过真实 Cloudflare 账户 ID 与 API 令牌（`cfut_…`）。改造版已删除该文件与全部凭据。**建议去 Cloudflare 控制台轮换那枚令牌**，它曾随源码 / APK 明文分发过。
2. 本版**不内置任何 OpenCode key**；只想用免费模型时完全不用填。别把 key 写进 `oc-proxy.cjs` 的 `DEFAULTS`（assets 不加密，拿到 APK 就能解出）。
3. 用免费模型时聊天内容会经 `opencode.ai` 网关，且各模型条款不一致：GLM-5.3-Flash Free、DeepSeek V4.1 Flash Free、MiniMax M3.1 Flash Free、Space Bunny、LongCat 系列标注零留存、不用于训练；Big Pickle、Iceman、MiMo、Nemotron 等明确会收集反馈改进模型。写公司代码优先选零留存那几款。
4. 免费层要求 `stream:true`，网关已自动把 SSE 聚合回非流式；同时会覆盖 `tools`，所以免费模式下 RikkaHub 的工具 / MCP 调用不可用。
5. 管理页 `/config` 与 `/selftest` 不鉴权，因此网关固定只监听 `127.0.0.1`；「局域网中继」开关依旧无效，别把它暴露到 LAN。

---

## 合规提醒

官方 Harnesses 文档原话：「Free-tier chat models are only available from within OpenCode. Other harnesses receive HTTP 403 for those models, **even with a Console API key**.」免费层桥接属于对未公开客户端校验的模拟，**不保证长期可用，也不代表官方授权**。

稳定、可商用的路径只有三条：Console 按量付费 key、Go / Go Plus 订阅（用 `/inference/go/…` 端点）、或本来提供公开 OpenAI 兼容端点的免费源（OpenRouter `:free`、本地 Ollama / LM Studio）。当前代码保留了 `console` 模式作为后路，但**默认 `free` 不会碰它**。
