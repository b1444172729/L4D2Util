# 限量网关 → OpenCode Console 本地网关（oc-console-gateway-r3 / key-only）

## 一句话结论

**r3 按你的要求彻底改成 key-only**：删除全部匿名免费层代码，每一次上游请求都带你在管理页填的 Console / Go API Key，走官方公开端点。壳（前台服务 / JNI / 悬浮窗 / 探活 / 二维码 / 日志）一行没动，只重写了 `oc-proxy.cjs`。

---

## 必须先看清的三件事

### 1. 带 Key 也调不了 `-free` 模型

官方 Inference API 与 Harnesses 文档原话：

> "Free-tier chat models are only available from within OpenCode. Other clients receive HTTP 403 for those models, **even with a Console API key**."

免费层的准入凭据**不是 Key**，而是「真实 OpenCode 客户端进程的连接态」。这正是 r1（裸请求）、r2（补齐 UA / `ses_` 会话 / 17 套 TLS cipher / 官方 `<environment>` 块 / 10 个工具定义）连试两轮都拿到 429 `FreeUsageLimitError` 的原因——不是额度用完，是官方对非 OpenCode 客户端的统一拒绝语，还附带一个指向 `00:00 UTC` 的 retry-after 伪装成额度耗尽。

所以「以后一律使用 key」的正确落法不是"用 key 调免费模型"，而是**砍掉整条免费层路径，全部走付费/Go 端点**。r3 就是这么做的。

### 2. 创建 Key ≠ 充值，不充值装上 r3 仍会失败

你第一次用 `auto` 模式时看到的 `org-…/billing?credits=1` 402 就是这么来的。官方 Billing 文档：**新账户余额默认 $0**，付费请求在余额归零时统一回 HTTP 402 `Insufficient account funds`，余额不会变负。

装 r3 后必须二选一：

| 方案 | 操作 | 端点 |
|---|---|---|
| Console 按量 | Settings › Billing › Add credits，$10/$50/$100 或自定义，另加 4.6% + $0.31 手续费，支持支付宝 / 微信 | `/inference/openai/v1/chat/completions` |
| Go 订阅 | 订阅 Go $10 / Go Plus $40 / Go Teams $20 每人每月 | `/inference/go/openai/v1/chat/completions` |

**两者用同一把 Key**，区别只在端点。管理页「计费方案」一个下拉就能切。

### 3. 两层 Key 别混

| Key | 谁用 | 从哪来 |
|---|---|---|
| Console / Go Key | 网关 → `opencode.ai` | 管理页填，`oc_sk_…`，不进二维码、不进日志明文 |
| 本机 API Key | RikkaHub → `127.0.0.1:18900` | 主界面「复制 API Key」，沿用旧默认值 `Rikka-2026-CF-Proxy-Key-8f3b` |

RikkaHub 里**继续填本机 Key**，别把 Console Key 填进去。

---

## r3 相对 r2 删了什么

| 删除项 | r2 里的作用 | r3 |
|---|---|---|
| 匿名公共凭据通道 | 免费层入口 | ❌ 全部删除，没 Key 直接 400 |
| `auto` / `free` / `console` 三模式 | 遇 429 自动降级付费 | ❌ 只剩 `plan = console \| go` |
| 17 套 BoringSSL cipher list | TLS ClientHello 伪装 | ❌ 用 Node 默认，不再伪装 |
| 官方 `<environment>` 块 / `Working directory` | 请求体形状校验 | ❌ 完全尊重 RikkaHub 发来的 body |
| 10 个官方 tools 注入 / `read` 完整定义 | 工具表校验 | ❌ 不再注入，`tools` 由客户端自己决定 |
| 强制 `stream:true` + SSE 聚合 | 免费层硬性要求 | ❌ 不再强制；付费端点支持非流式，网关仍双向适配 |
| 伪造 UA `opencode/1.19.5 ai-sdk/…` | 客户端指纹 | ❌ 改成诚实 UA `RikkaHub-OpenCode-Gateway/3.0`（官方要求第三方 harness 诚实标识自己） |
| `x-opencode-project` / `x-opencode-request` 伪造 | 指纹 | ❌ 删除 |
| 429「不是额度用完」的中文解释 | 免费层误判 | ❌ 换成真·计费错误提示（401/402/403/429/404 各自给可照做的动作） |

**保留并加强**的：

- 稳定 `x-opencode-session: ses_…`，按对话首条 user 消息自动复用（**Go 强制要求**，Console 也利于复用 prompt cache）。
- 模型清单带 Key 从上游 `/v1/models` 拉取，失败回退内置 19 个付费/Go 模型 ID。
- **Console 模式自动过滤 `-free` 模型**——带 Key 也 403，留在清单里只会让人反复踩坑。Go 模式不过滤（Go 计划内含 `Beam Free`、`Iceman Contributor Free` 等限时位，可尝试；Beam Free 不对中国大陆/港澳提供）。
- 「🔬 一键测试」改成验 **Key 是否有效 / 余额是否充足 / 端点是否选对**，回报状态码、配置快照、上游原文与判定文案。
- `customModels` / `extraHeaders` / 各端点路径 / UA 仍外置成管理页可编辑，上游改规则不用重编译 APK。
- `bundle-version.txt` → `oc-console-gateway-r3`，覆盖安装强制重建 `nodeHome`，不会残留 r1/r2 代码。**旧 `oc-config.json` 里的 `mode` / `ciphers` / `envPrompt` 等字段会被自动忽略，`consoleKey` 会保留**（你已经填过，覆盖安装不用重填）。

---

## 装好后的操作顺序（照做，别跳步）

1. 编译安装 APK（覆盖安装即可）→ 主界面「启动网关」→ 状态 READY。
2. 点「打开管理页」→ 确认 **Console / Go Key** 已填（掩码显示 `oc_sk****…`）；没填就粘贴保存。
3. **先点「🔬 一键测试」**，看判定：
   - `✅ Key 有效、余额充足、端点正确` → 直接进第 5 步。
   - `❌ 402 余额为 $0` → **去 Console 充值或订阅 Go**，回来再测。不充值后面一定还是失败。
   - `❌ 401 Key 无效` → Console → Account → Personal API keys 重建一把（旧 key 在 Console 迁移后有一批集中失效过）。
   - `❌ 403 策略拒绝` → 检查是不是选了 `-free` 模型、Workspace 隐私里的 Regions（默认只放行 EU/US，可改 Global）、或 IP 风控。
   - `❌ status 0` → 网络层失败，检查能否访问 `opencode.ai`、是否挂了代理。
4. 若订阅了 Go：管理页把「计费方案」切到 `go`（端点自动变成 `/inference/go/openai/v1/chat/completions`），再测一次。
5. RikkaHub 配置：类型 OpenAI，Base URL `http://127.0.0.1:18900/v1`，路径 `/chat/completions`，Key 用主界面「复制 API Key」那个**本机 Key**，模型从「复制模型 ID」里选**付费 ID**（例如 `glm-5.3-flash`、`deepseek-v4.1-flash`、`kimi-k3`），**别再选 `-free` 结尾的**。

---

## 排障表（r3 全是真·计费/配置错误）

| 现象 | 原因 | 处理 |
|---|---|---|
| 自检 `402 Insufficient account funds` | Console 余额 $0 | Settings › Billing › Add credits，或订阅 Go 并切方案 |
| 自检 `401 Invalid credential` / `api_key_expired` | Key 填错 / 迁移后失效 | Console → Account → Personal API keys 重建 |
| 自检 `403 FreeTierError` | 模型是 `-free` | 换付费 ID（去掉 `-free`），或订阅 Go 走 `/inference/go/…` |
| 自检 `403 abusive traffic` | 出口 IP 被风控（共享 NAT / VPN / 代理） | 关代理、换蜂窝网络；与 Key 和余额无关 |
| 自检 `403` 其它 | Key 权限 / Workspace Regions | Console → Workspace Settings › Privacy，Regions 改 Global |
| 自检 `429` | 按量或 Go 速率/额度触顶 | 稍后重试；Go 用户可开 Extra Usage 用余额续量 |
| `400 ModelProtocolUnsupported` | 该模型归别的 API family | Console 通常自动转换；仍报错就换 Chat Completions 系模型（`glm-5.3-flash` 等） |
| `404` | 模型 ID 下架或写错 | 管理页「刷新模型清单」 |
| RikkaHub 里 401 | 本机 Key 不一致 | 回主界面重新复制 Base URL 与本机 Key |
| 一直转圈 / 空回复 | 流式适配 | RikkaHub 里先关流式试一次；看 `bootstrap.log` 的 `[oc-proxy]` 行 |

排查顺序：管理页一键测试 → `bootstrap.log`（`[oc-proxy]` 行）→ `node-output.log` → `node-fatal.txt`。
手机浏览器直接开 `http://127.0.0.1:18900/selftest` 也能看自检 JSON。

---

## 这次工程里改了哪些文件

| 文件 | 处理 |
|---|---|
| `assets/node/oc-proxy.cjs` | **重写为 r3 key-only**：删除免费层与全部指纹伪造，统一带 Key 走官方端点，错误提示按状态码中文化，模型清单过滤 `-free`，一键自检改为验 Key/余额/端点 |
| `assets/node/bootstrap.cjs` | 头部注释改为 r3 key-only；加载逻辑与日志体系未动 |
| `assets/node/bundle-version.txt` | `oc-console-gateway-r3` |
| `assets/node/package.json` / `packages/standalone/cli.mjs` | 占位，满足 AssetInstaller / CI 完整性判据 |
| `core/AssetInstaller.kt` | 完整性判据含 `oc-proxy.cjs`（未动） |
| `core/SourceUpdater.kt` | 「更新上游源码」仍禁用，文案改 Console key-only |
| `res/values/strings.xml` | 副标题 / 页脚 / 管理页副标题 / 帮助文案改为 Console key-only |
| `scripts/prepare-node-bundle.sh` | 离线校验两个 `.cjs`，版本标记刷新 |
| `.github/workflows/build.yml` | 版本注释与自检判据（编译逻辑未动） |
| `README.md` | 顶部指向本文档 |
| `cf-proxy.cjs` / `CLOUDFLARE_README.md` | **已删除**（旧 CF 版含硬编码真实凭据） |

**未改动**：包名 `com.android.cloudflare`（JNI 函数名绑定）、全部其它 Kotlin / Java / C 胶水 / CMake / Manifest / 图标 / Gradle 配置。

---

## 编译（沿用原来的 GitHub Actions）

1. 工程包按原习惯命名为 **`dsh_free_model_app.zip`** 放仓库根目录（zip 里套一层 `aggregate-gateway/`）；`.github/workflows/build.yml` 必须作为**明文文件**单独提交，GitHub 不执行压缩包里的 workflow。
2. 提交触发 Actions，或手动 Run workflow。CI：解压 → JDK/SDK/NDK → 离线校验两个 `.cjs` 语法 → 下载 `libnode.so`（Node 22+）→ `assembleDebug` → 产出 `AggregateGateway-*.apk`。
3. 覆盖安装即可，`bundle-version.txt` 已换值，会强制重建 `nodeHome`。

沙盒无 Android SDK，**没实机编译 APK**；JS 侧已通过 `node --check` 与本地 mock 上游自测（含：非流式 JSON / 流式 SSE 透传 / SSE 聚合 / 每次请求都带 Key / 无 Key 直接 400 / 402 与 401 与 403 中文提示 / plan 切换端点 / 过滤 `-free` / 一键自检 / 配置落盘与掩码）。

---

## 安全与隐私

1. 旧版 `cf-proxy.cjs` 里硬编码过真实 Cloudflare 账户 ID 与 API 令牌（`cfut_…`）。改造版已删除该文件与全部凭据。**建议去 Cloudflare 控制台轮换那枚令牌**，它曾随源码 / APK 明文分发过。
2. 本版**不内置任何 OpenCode key**；`oc-config.json` 写 0600，管理页只显示掩码，二维码与分享串只含本机 Key。别把 key 写进 `oc-proxy.cjs` 的 `DEFAULTS`（assets 不加密，拿到 APK 就能解出）。
3. 使用自带 Key 时，官方 FAQ 说明「数据和信息仅在使用免费模型时才会被存储」——走付费/Go 端点反而不存储聊天内容，比免费层更适合写公司代码。
4. 管理页 `/config` 与 `/selftest` 不鉴权，因此网关固定只监听 `127.0.0.1`；「局域网中继」开关依旧无效，别把它暴露到 LAN。

---

## 还想白嫖免费模型？只剩这几条正经路

r3 不再提供，也不再尝试。可选：

- **在 OpenCode 官方客户端里用**（你 Windows 版已经成功）——免费模型本来就是给它准备的。
- **订阅 Go**，其模型列表含 `Iceman Contributor Free` 等限时免费位，走 `/inference/go/…` 端点可尝试（Beam Free 不对大陆/港澳）。这是唯一「带 Key 且可能不额外扣费」的路径。
- **换本来就公开免费的源**：RikkaHub 直接指 OpenRouter 的 `:free` 模型、本地 Ollama / LM Studio，都是正经 OpenAI 兼容端点，不需要任何指纹桥接。

官方 Harnesses 文档对第三方 harness 的正规支持只有一句：「Point a harness at the Console gateway with an API key to use any **paid or Go model**」。r3 就是严格照这句做的。
