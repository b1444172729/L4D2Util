# r5d · 用已编译好的 rootfs-arm64.tar.gz（最短路径）

> 这一节是为你写的：你已经用 GitHub Actions 编译出 `rootfs-arm64.tar.gz`（或 Artifact 下载的
> `rootfs-arm64.zip`），并且**不想装 OCGW 那个 `app-arm64-v8a-release.apk`**。
> 本工程（包名 `com.android.opencoderootfs`）现在可以直接吃同一份归档，独立跑 proot + `opencode serve`。

## 三步

1. **把归档放到手机固定路径**（二选一，文件名精确一致）：
   ```
   /sdcard/Download/rootfs-arm64.tar.gz     ← 推荐
   /sdcard/Download/rootfs-arm64.zip        ← GitHub Artifact 外层，APP 会自动解出内层 tar.gz
   ```
   用 `adb push rootfs-arm64.tar.gz /sdcard/Download/` 或文件管理器拷贝。**原文件别删**，APP 不移动也不删除它。

2. **编译安装本工程 APK**（沿用原来的 Actions / Android Studio，无需改参数）。装完启动网关 → 主界面「打开管理页」。

3. 管理页顶部会列出探测到的归档 → 点 **「📥 一键导入并重启」** → 等 1~3 分钟解包四件套 →
   再点 **「🔬 端到端自检」**。通过后 RikkaHub 填 `http://127.0.0.1:18900/v1` + 主界面那个本机 Key + 免费位 ID。

**默认 `rootfsSource = local`，一次网络请求都不发。** 已删除的 `dormantxxy` release 与 9 个镜像都不再被访问；
只有把来源手动切成 `url` 且填了你自己的直链时才会联网。

> 首次启动会弹 **存储权限**（读 `/sdcard/Download/`），请点允许；不给权限 APP 看不到归档。
> 解包优先走系统 `tar`（流式，和 OCGW 一样），不会把 300 MB 归档整体读进内存；系统 tar 不可用时才回退纯 JS。

## 与 OCGW APK 的关系

| | OCGW（com.ocgw.app） | 本工程（com.android.opencoderootfs） |
|---|---|---|
| 拉起 proot | Kotlin `ProcessBuilder` | nodejs-mobile `child_process.spawn` |
| 归档入口 | `/sdcard/Download/rootfs-arm64.tar.gz` | **同一个路径，外加 .zip 自动解包** |
| 对外网关 | `127.0.0.1:4318/v1` | `127.0.0.1:18900/v1` |
| opencode serve | `127.0.0.1:4317` | `127.0.0.1:4317`（可改成 4319） |
| 管理页 / 自检 / 模型过滤 | 简版 WebView | 有，且可调 prompt 形状、超时、重试 |

⚠ **两个 APP 不要同时跑**：都会占 `4317`。如果 OCGW 还在运行，先停止它，或把本工程管理页的
「端口」改成 `4319`。本工程不依赖 OCGW，卸载它也不影响。

## r5d 相对 r5c 改了什么

| # | 改动 | 为什么 |
|---|---|---|
| 1 | 新增归档自动发现：`/sdcard/Download/`、`/sdcard/Downloads/`、`import/`，支持 `.zip` 外层纯 JS 解包 | 直接复用你已编译出的产物，不用重新生成 / 重新压缩源码包 |
| 2 | 默认 `rootfsSource` 从 `auto` 改为 `local`，只有显式选 `url` 才联网 | 原 release 404 + 9 镜像 403，默认测速纯属浪费与误导 |
| 3 | `/api/session → prompt → message` 翻译**对齐实测跑通的 OCGW 实现**：v2 完整 prompt 形状（id/text/files/agents/skills/delivery/metadata）、`finish` 判定、`error` 分类与限流重试、`content`/`parts` 两种文本提取 | r5c 的 parts/text 形状与新版 CLI 未必匹配；这是能否真正聊起来的关键 |
| 4 | proot 环境改为**干净 env**（不继承 nodejs-mobile 的 `process.env`） | 对齐 OCGW 的 `environment().clear()`，避免 `NODE_*` / Android 变量干扰 |
| 5 | 管理页新增归档清单 + 一键导入；`POST /rootfs/import`；端口冲突提示 | 少填字段、少踩坑 |
| 6 | `scripts/build-rootfs.sh` 同步为 Termux 多镜像独立回退修复版 | 避免以后重建再踩 run #246 的「清华索引能下、pool 里 deb 取不到」 |
| 7 | 补 `READ/WRITE_EXTERNAL_STORAGE` + 运行时申请 + `requestLegacyExternalStorage` | 否则读不到 `/sdcard/Download/` |
| 8 | 大归档优先系统 `tar` 流式解包，失败回退纯 JS | 300 MB 归档用 `gunzipSync` 会占满内存被系统杀掉 |
| 9 | `targetSdk = 28`（r5c 已修，保留） | Android 10+ 的 W^X 限制会禁止执行私有目录 ELF |

## 风险（如实说明）

- 本工程**没在真机上编译验证过**（沙盒无 Android SDK / Gradle）。OCGW 是 Kotlin 原生 `ProcessBuilder` 且你已实测跑通；
  本工程是 nodejs-mobile 里 `spawn` proot，多一层运行时。虽然 env、命令、四件套、targetSdk 都已对齐，
  仍建议先点「端到端自检」再接 RikkaHub。
- 免费层本身可能 429（服务端共享额度窗口），与用哪个 APP 无关。429 别连点，等窗口或换一个 free 模型。

---

# proot 桥接网关（方案 C / oc-proot-gateway-r5d / bridge-only）

> **只使用免费模型。** 本版没有任何付费 / Go 通道，不会自动降级，也不会向你要 OpenCode 账号 Key。
> 唯一对 `opencode.ai` 发请求的，是 **proot 里运行的官方 OpenCode CLI 进程**；本 APP 只做本机回环翻译。

---

## 一、架构

```
RikkaHub（或任意 OpenAI 兼容客户端）
   │  http://127.0.0.1:18900/v1/chat/completions
   ▼
[oc-proxy.cjs]  nodejs-mobile :node 进程 · OpenAI 兼容端点 / 管理页 / 模型过滤
   │  纯回环 HTTP，不构造任何对 opencode.ai 的请求
   ▼
[rootfs-manager.cjs]  child_process.spawn → proot
   │
   ▼
proot -r <rootfs> … /opencode/bin/opencode serve --hostname 127.0.0.1 --port 4317
   │  ← 官方 CLI 进程，免费层认证在这里完成
   ▼
https://opencode.ai
```

协议翻译：`POST /api/session` → `POST /api/session/{id}/prompt` → 轮询 `GET …/message` → `DELETE …/session` → 拼回 `chat.completion` / SSE。模型清单来自 `GET /api/model`，**只保留免费位**。

为什么这样能成：2026-11-06 的同一时刻对照实测，本机真实 `opencode serve` 进程 200，而所有独立脚本直连（Bun/Node、全套请求头、JA3/JA4 TLS 指纹、真或假 session、2 KB 到 234 KB 原报文）一律 `429 FreeUsageLimitError`——网关放行的是**真实客户端进程的连接态**，不是报文里能携带的任何字段。r1/r2 补 UA / cipher / `<environment>` / tools 全败的原因就在这里。

---

## 二、必须先接受的一件事：APK 里没有任何二进制

这个工程包只有源码（约 1.3 MB）。**proot、`libtalloc.so.2`、官方 OpenCode CLI 都不在 APK 里**，需要你提供。原因：

- 原 OCGW APK 的 `rootfs-arm64.tar.gz` 托管在 `dormantxxy/opencode-gateway-releases` 的 release 上，该仓库现在访问不了；
- 沙盒里没有这些 arm64 二进制，也无法凭空生成；
- 内置到 APK 会让体积从 ~1.3 MB 涨到 100 MB+。
- 好消息是原项目构建脚本已找到，见第三节，无需从零琢磨目录结构。

**四件套校验**（缺一即 `rootfs incomplete`）：

```
<rootfs>/opencode/bin/opencode         官方 OpenCode CLI（arm64，必须 v2）
<rootfs>/proot/bin/proot               proot 可执行文件（arm64）
<rootfs>/proot/libexec/loader          proot loader
<rootfs>/proot/lib/libtalloc.so.2      proot 依赖
```

管理页顶部会逐个显示 ✅/❌。四项齐全就**跳过下载和解压**，直接启动。

---

## 三、rootfs 从哪来（原文件已下架，但配方找到了）

**先说结论**：原来那个 `rootfs-arm64.tar.gz` 已经拿不回来了。2026-11-11 实测原 release 仓库 HTTP 404，APK 里内置的 9 个 ghproxy 镜像全部 403（它们只是给同一个已删除的 URL 加前缀）。卸载 APK 也不会留下 rootfs——Android 会删掉整个私有目录，而且 APK 里本来就只有下载器、没有任何二进制。

**但原项目的完整源码还在**：`https://github.com/dywr888/opencode-gateway-releases`（约 43 KB），README 描述与那个 APK 完全一致，里面包含 `rootfs/build-rootfs.sh`、`build-rootfs.yml`、以及原版 APP 的全部 Kotlin 源码。配方还原出的正是我们校验的四件套：

```
opencode/bin/opencode          OpenCode v2 CLI（arm64，npm @opencode/cli-linux-arm64）
proot/bin/proot                Termux 版 proot（bionic/NDK 编译）
proot/libexec/loader           proot loader
proot/lib/libtalloc.so.2       talloc（+ 建议同时放 libandroid-shmem.so）
```

底层是 Ubuntu Base 24.04.3 arm64（glibc，约 28 MB）+ chroot 装的 git；打包必须用 `--hard-dereference` 展开硬链接，否则 Android SELinux 禁止 `link()` 会解不开。

### 路线 1 · fork + GitHub Actions（推荐，不需要 arm64 机器 / 不需要 root）

工程包里已提供 **`scripts/build-rootfs.yml`** 与增强版 **`scripts/build-rootfs.sh`**。fork 源码仓库（或新建仓库只放这两个文件）→ Settings 打开 Actions 的 Read/Write 权限 → 手动 Run workflow（建议勾 `skip_apt`）→ 到 Releases 的 `rootfs` tag 下载 `rootfs-arm64.tar.gz`，Actions artifact 里也留了一份。完整步骤、URL 模板、权限坑见 **[`scripts/ROOTFS_BUILD.md`](scripts/ROOTFS_BUILD.md)**。

### 路线 2 · 本地自己跑脚本

```bash
sudo -E bash scripts/build-rootfs.sh                # 完整版（含 git，需 root + arm64）
bash scripts/build-rootfs.sh --skip-apt            # 轻量版（网关不需要 /api/vcs/init）
OC_VER=2.2.7 bash scripts/build-rootfs.sh --skip-apt
```

增强版对 Ubuntu base / npm / Termux 三处都做了多源回退（官方 + 清华 + 阿里 + 中科大），版本默认取 npm latest、失败回退 `2.2.7`，打包后自检四件套并输出 SHA256。**必须是 v2 CLI**（免费模型 v1/0.x 会 426→429）。

### 路线 3 · 干脆重建原版 APP

那个源码仓库里连 `build-apk.yml` 和全部 Kotlin 源码都有。想回到「已验证能跑」的原版，fork 后先按路线 1 产出 rootfs，再跑 `build-apk.yml`，**并把 `MainActivity.kt` / `GatewayService.kt` 里写死的 `dormantxxy/...` 下载 URL 改成你自己 fork 的地址**（否则装了还是 404）。详见 `ROOTFS_BUILD.md` 第五节。

> 关于沙盒验证：我的出网有域名白名单，`cdimage.ubuntu.com` / `registry.npmjs.org` / Termux 镜像在这里返回 403，所以**无法替你实测下载**；这不代表它们在你的网络或 GitHub Actions（境外 runner）上不可达。脚本的多源回退正是为此准备的。

## 四、怎么把 rootfs 交给 APP

管理页「① rootfs 来源」有两条并存的路径，优先级由「来源优先级」决定：

| 方式 | 填什么 | 适用 |
|---|---|---|
| **已解压目录** | rootfs 目录的绝对路径，例如 `/storage/emulated/0/ocgw/rootfs` 或已放进私有目录的 `ofm-data/rootfs` | 从旧设备导出、或按第三节构建后解开的目录；四件套齐全即跳过下载 |
| **本地 tar.gz** | 归档路径，例如 `/storage/emulated/0/Download/rootfs-arm64.tar.gz`；留空则默认找 `ofm-data/import/rootfs-arm64.tar.gz` | 路线 2/3 打好的包 |

放进私有目录的办法（`com.android.opencoderootfs` 是包名）：

```bash
adb push rootfs-arm64.tar.gz /data/local/tmp/
adb shell run-as com.android.opencoderootfs sh -c \
  'mkdir -p files/ofm-data/import && cp /data/local/tmp/rootfs-arm64.tar.gz files/ofm-data/import/'
```

> release 构建无 `run-as`：可在主界面用「打开管理页」填外部存储路径（需要 READ_EXTERNAL_STORAGE，Manifest 里已有），或 root 后直接 cp。

**纯 JS 解包**：`rootfs-manager.cjs` 自己用 `zlib.gunzipSync` + tar 头解析完成解压，不依赖系统的 `toybox tar` / `busybox`，支持 GNU longname、PAX path、symlink，并拒绝 `..` 路径穿越。解压到 `<dir>.staging`，校验四件套通过后才原子 rename 成正式目录。

---

## 五、启动参数（按 OCGW APK 的 DEX 常量 1:1 还原）

```sh
proot/bin/proot \
  -r <rootfs> \
  -b /dev -b /proc -b /sys -b /dev/pts \
  -b <workspace>:/workspace \
  --kill-on-exit \
  -w /workspace \
  /opencode/bin/opencode serve --hostname 127.0.0.1 --port 4317
```

注入环境变量：

| 变量 | 值 |
|---|---|
| `OPENCODE_PASSWORD` | 随机 24 位 hex，回写 `oc-config.json`，本地 API 用 |
| `HOME` | `/root` |
| `PATH` | `/usr/local/bin:/usr/bin:/bin` |
| `TMPDIR` | `/tmp` |
| `LD_LIBRARY_PATH` | `<rootfs>/proot/lib` |
| `PROOT_LOADER` | `<rootfs>/proot/libexec/loader` |
| `PROOT_TMP_DIR` | `ofm-data/proot-tmp` |
| `OPENCODE_PORT` / `GATEWAY_PORT` | 4317 / 18900 |

DNS：优先用管理页填的，否则读 `getprop net.dns1/2/3`，再退 `223.5.5.5 / 119.29.29.29 / 8.8.8.8`，写进 `<rootfs>/etc/resolv.conf`。不写 proot 里解析不了域名。

就绪探测：轮询 `GET /api/config` 最多 60 次 × 500ms。停止时 `kill` 子进程 + `pkill -9 -f proot` / `pkill -9 -f "opencode serve"`。CLI stdout 写 `ofm-data/opencode.log`，管理页直接显示尾部。

### 认证方式（版本差异的关键）

| apiStyle | 请求 | 适用 |
|---|---|---|
| `query`（默认） | `/api/config?auth_token=<password>` | 旧版 serve / OCGW APK 同款 |
| `basic` | `Authorization: Basic base64("opencode:<password>")`，无 query | OpenCode v2 的 `/api/*` 文档口径 |

**就绪探测一直 401/403，就在管理页把这两项切一下再点「重启 CLI」。**

---

## 六、装好后的操作顺序

1. 编译安装 APK（覆盖安装即可，版本 `oc-proot-gateway-r5d` 会强制重建 `nodeHome`）。
2. 启动网关 → 主界面 READY → 点「打开管理页」。
3. 看顶部四件套。全 ❌ → 按第三节导入 rootfs / 归档，点「重启 CLI / 重新准备 rootfs」，等解压完成（首次可能要 100 MB+ 下载或解包十几秒）。
4. **点「🔬 端到端自检」**，它回报每一步状态码：`/api/config` → `/api/model` → 建会话 → prompt → 取回复 → 删会话。
   - `✅ 端到端通了` → 进第 6 步。
   - `❌ /api/config 未就绪` → 切 `apiStyle`，或看 `opencode.log`；多半是 CLI 版本 / 认证方式 / proot 起不来。
   - `❌ 四件套缺失` → 回第三节。
5. 若自检里 `GET /message` 一直超时，把管理页「认证方式」切一下；仍不行说明 CLI 版本较新，需要把 `prompt` 改成同步 `POST /api/session/{id}/message` 或订阅 `GET /api/event` 的 SSE——把 `opencode.log` 和自检 JSON 发我，我针对性改 `chatViaServe()`。
6. RikkaHub：类型 OpenAI，Base URL `http://127.0.0.1:18900/v1`，路径 `/chat/completions`，Key 用主界面「复制 API Key」那个**本机 Key**（默认值沿用旧版，原来配好的不用重填），模型从「复制模型 ID 清单」里挑**免费位**。

---

## 七、排障表

| 现象 | 原因 | 处理 |
|---|---|---|
| 四件套 ❌ / `rootfs incomplete after extract` | 归档缺文件或多套了一层目录 | 检查归档结构；解压器会自动探测一层顶层目录，超过一层要重新打包 |
| 所有下载源不可达 | 原仓库下架 | 走路线 1 / 2，别再调镜像 |
| `spawn EACCES` | **Android 10+ 禁止 targetSdk≥29 的 app 执行私有目录 ELF** | r5d 已把 `targetSdk` 降到 28；若仍报错见第八节，改用 jniLibs |
| `spawn ENOENT` / CLI 立刻退出 | proot 依赖库缺失 / 架构不对 | `readelf -h` 核对 AArch64；检查 `LD_LIBRARY_PATH` / `PROOT_LOADER` |
| `/api/config` 401 / 403 | 认证方式不匹配 | 管理页切 `query ↔ basic` 后重启 CLI |
| CLI 报 426 | v1 / 0.x 版本过旧 | 换 v2 CLI 重新打包 rootfs |
| **429 FreeUsageLimitError** | **服务端共享免费额度窗口耗尽**，不是配置错 | 等窗口 / 换一个免费模型，**不要连续重试**；同一分钟用官方 v2 客户端交错发一句对照，两边都 429 就是全局窗口 |
| `403 FreeTierError` | 客户端形状门 | CLI 没被认成官方客户端（版本过旧 / 被改过），换 rootfs |
| RikkaHub 一直转圈 / 空回复 | 流式适配 | 先关流式试一次；看自检 steps 里 `GET /message` 是否 `found:true` |
| RikkaHub 401 | 本机 Key 不一致 | 主界面重新复制 Base URL 与本机 Key |
| 厂商杀后台 → 4317/18900 一起掉线 | 前台服务被杀 | 电池白名单、锁定后台；必要时降低保活策略冲突 |

排查顺序：管理页自检 → `opencode.log` → `bootstrap.log`（`[rootfs]` 行）→ `node-output.log` → `node-fatal.txt`。

---

## 八、Android 执行权限（最大的不确定性）

Android 10 起对 app 私有目录（`getFilesDir()`）里的 ELF 执行有 W^X 类限制，**只对 `targetSdk >= 29` 的 app 施加**。我们的 `rootfs` 就放在 `filesDir` 下，所以这是必须处理的硬条件。

**r5d 已修复**：`app/build.gradle.kts` 里 `targetSdk` 从 35 改为 **28**（`compileSdk` 仍 35，不影响编译）。这与原版 OpenCode Android Gateway 的做法完全一致——它的 `app/build.gradle` 注释原文：「targetSdk 必须 <= 28，Android 10+ 对 targetSdk>=29 的 app 施加 W^X 限制，禁止执行 app 可写数据目录内的可执行文件，Termux 同样固定 targetSdk 28」。

备选（若因其它原因必须保持高 targetSdk）：把 `proot`、`loader`、`opencode` 作为 `jniLibs/arm64-v8a/*.so` 放进 APK，系统会把它们解到 `nativeLibraryDir`（可执行），启动命令改指该目录。

> 副作用：`targetSdk 28` 会让 `POST_NOTIFICATIONS` 无需运行时申请、Scoped Storage 走 legacy 行为，对本 APP 反而更简单；但 Google Play 上架会要求更高 targetSdk——这是自用 APK，不影响。

---

## 九、本次工程改了哪些文件

| 文件 | 处理 |
|---|---|
| `scripts/build-rootfs.sh` | **新增**：原配方增强版，多源回退 / 可选 skip-apt / 四件套自检 / SHA256 |
| `scripts/build-rootfs.yml` | **新增**：放进 fork 仓库，GitHub arm64 runner 一键产出 Release asset |
| `scripts/ROOTFS_BUILD.md` | **新增**：rootfs 获取的三种路径、确切 URL 模板、事实核对清单 |
| `assets/node/rootfs-manager.cjs` | **新增**：下载/测速/断点续传、纯 JS tar.gz 解压、四件套校验、chmod、DNS、spawn proot、就绪探测、停止清理、`apiRequest()` |
| `assets/node/oc-proxy.cjs` | **重写为 bridge-only**：删除全部付费/Go 通道与指纹逻辑；新增 OpenAI ↔ `/api/*` 翻译、免费位过滤、SSE/JSON 适配、自检、rootfs 管理页 |
| `assets/node/bootstrap.cjs` | 注释与加载日志改为 r5；加载链路、日志体系、冒烟测试未动 |
| `assets/node/bundle-version.txt` | `oc-proot-gateway-r5d` |
| `core/AssetInstaller.kt` | 完整性判据加入 `rootfs-manager.cjs` |
| `core/SourceUpdater.kt` / `res/values/strings.xml` | 文案改为 proot 桥接 |
| `scripts/prepare-node-bundle.sh` | 校验清单加入第三个 `.cjs` |
| `.github/workflows/build.yml` | 散放清单与完整性判据同步 |
| `README.md` | 顶部指向本文档 |

**r5d 之后的本次改动**：应用显示名与主页大字改为「OC网关」；包名 / namespace / applicationId 改为 `com.android.opencoderootfs`（JNI 函数名、proguard 规则、Action 常量、文档 adb 命令同步）；APP 图标、悬浮窗图标、通知栏图标统一换成用户提供的青绿渐变插画。网关逻辑、JNI 胶水本体、CMake、Manifest 权限与端口配置均未改动。旧 `oc-config.json` 里付费通道相关的遗留字段会被自动忽略，`proxyKey` 保留。

---

## 十、编译与验证

1. 工程包 **`dsh_free_model_app.zip`** 放仓库根（zip 里套一层 `aggregate-gateway/`）；`.github/workflows/build.yml` 必须作为**明文文件**单独提交。
2. 提交触发 Actions 或手动 Run：解压 → JDK/SDK/NDK → 离线校验三个 `.cjs` 语法 → 下载 `libnode.so`（Node 22+）→ `assembleDebug` → 产出 APK。
3. 覆盖安装即可；`bundle-version.txt` 已换值，`AssetInstaller` 会强制重建 `nodeHome`。

沙盒无 Android SDK，**没实机编译 APK**。JS 侧已通过 `node --check` 与本地 mock 自测（mock 一个假的 `opencode serve` 实现 `/api/config`、`/api/model`、`/api/session`、`/prompt`、`/message`、`DELETE`，并生成测试 tar.gz 验证纯 JS 解包与四件套校验）。

---

## 十一、风险与合规

1. 官方明确：免费聊天模型只对 OpenCode 客户端开放，第三方 harness 即使带 Console API Key 也 403。本方案是「利用 `serve` 也是 OpenCode」把官方进程当服务用，**个人低频自用可以，长期主力 / 商用不推荐**。
2. 免费层由服务端按 account / workspace / network 裁决，2026-11 初有一串 GitHub issue 报告「重置后几秒又 429」，官方 bot 统一归并到 #59387 并说明「a change in the app can't lift it」。**客户端能做的只有：升级到 v2、换模型、等窗口。**
3. proot 是纯用户态系统调用翻译，Bun CLI 常驻 + 前台服务会明显耗电占内存；Android 12+ 后台限制与厂商杀后台都可能导致掉线。
4. rootfs 里是固定版本 CLI，免费位轮换 / 服务端加严都会让它失效，必须能更新 rootfs 才能长期用。
5. 本地 4317 / 18900 只监听 `127.0.0.1`，`auth_token` 只防同机误连，不是安全边界；别把端口转发到 LAN。
6. 隐私：官方 FAQ 说明「数据和信息仅在使用免费模型时才会被存储」。本方案只用免费模型，别往里送公司代码 / 密钥 / 个人信息。

---

## 十二、如果还是不通，给我这些

- 管理页「端到端自检」的完整 JSON（含 `steps` 每步状态码）
- `opencode.log` 尾部 50 行
- `bootstrap.log` 里 `[rootfs]` 开头的行
- rootfs 里 `opencode --version` 的输出（或 `opencode/bin/opencode` 的文件大小 / 来源）
- 手机型号、Android 版本、是否 root

有这些就能定位是「proot 起不来」「认证方式不对」「协议端点变了」还是「服务端 429 窗口」——四者处理方式完全不同。
