plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.android.dsh"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.android.dsh"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    // 不显式声明 sourceSets：
    //  · AGP 默认 jniLibs 目录就是 src/main/jniLibs、assets 就是 src/main/assets，
    //    这两行本来就多余；
    //  · Kotlin DSL 里 AndroidSourceSet.jniLibs / assets 为可空类型，
    //    直接写 jniLibs.srcDirs(...) 会在配置阶段报 "Only safe calls are allowed
    //    on a nullable receiver"，导致 Gradle 还没编译就失败。
    // scripts/fetch-libnode.sh 与 prepare-node-bundle.sh 仍按原路径放置产物。

    packaging {
        jniLibs { useLegacyPackaging = true }
        // 用逐项 .add() 而非 += setOf(...)：AGP 8.x 的 resources.excludes
        // 在不同小版本里可能是 MutableSet 或 SetProperty，.add() 对两者都成立，
        // 而 += Collection 只对前者成立。这里是最保险的写法。
        resources {
            excludes.add("META-INF/DEPENDENCIES")
            excludes.add("META-INF/LICENSE*")
        }
    }

    // assets/node/bundle.zip 已是压缩包，避免 aapt 再做一次无意义压缩
    androidResources { noCompress.add("zip") }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("com.google.android.material:material:1.12.0")
    implementation("com.google.zxing:core:3.5.3")

    // nodejs-mobile 运行时：把官方 aar / jar 放进 app/libs 即可自动参与编译；
    // 源码通过反射调用 NodeJS.start(...)，因此即便未放入 aar 也能编译通过，
    // 只是运行时会提示缺少运行时（见 README「运行时依赖」）。
    implementation(fileTree(mapOf("dir" to "libs", "include" to listOf("*.jar", "*.aar"))))
}
