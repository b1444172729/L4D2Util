plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.android.dsh"
    compileSdk = 35

    // 自建 JNI 胶水需要 NDK；钉死版本让 CI 与本地一致，避免 AGP 临时下载别的版本
    ndkVersion = "27.0.12077973"

    defaultConfig {
        applicationId = "com.android.dsh"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"

        // libnode.so 只提供 arm64-v8a，胶水也只编这一个 ABI
        ndk { abiFilters.add("arm64-v8a") }
    }

    // 编译 app/src/main/cpp/dsh-node.c → libdsh-node.so。
    // 它是纯 C，不链接 libnode.so、不需要 node 头文件，
    // 所以即使本次构建没拿到 libnode.so，APK 也照样能编译出来。
    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    // 不显式声明 sourceSets：
    //  · AGP 默认 jniLibs 目录就是 src/main/jniLibs、assets 就是 src/main/assets，
    //    这两行本来就多余；
    //  · Kotlin DSL 里 AndroidSourceSet.jniLibs / assets 为可空类型，
    //    直接写 jniLibs.srcDirs(...) 会在配置阶段报 "Only safe calls are allowed
    //    on a nullable receiver"，导致 Gradle 还没编译就失败。
    // scripts/fetch-libnode.sh 与 prepare-node-bundle.sh 仍按原路径放置产物。

    packaging {
        jniLibs {
            useLegacyPackaging = true
            // 兜底：万一工程包里已带、workflow 又复制了一份，
            // 避免 mergeNativeLibs 报 "2 files found with path ..."。
            // 用逐项 .add() 而非 += setOf(...)，兼容 AGP 8.x 的集合类型差异。
            pickFirsts.add("**/libc++_shared.so")
            pickFirsts.add("**/libnode.so")
        }
        // 用逐项 .add() 而非 += setOf(...)：AGP 8.x 的 resources.excludes
        // 在不同小版本里可能是 MutableSet 或 SetProperty，.add() 对两者都成立，
        // 而 += Collection 只对前者成立。这里是最保险的写法。
        resources {
            excludes.add("META-INF/DEPENDENCIES")
            excludes.add("META-INF/LICENSE*")
        }
    }

    // assets/node/bundle.zip 已是压缩包，避免 aapt 再做一次无意义压缩
    androidResources { noCompress.add("zip") }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("com.google.android.material:material:1.12.0")
    implementation("com.google.zxing:core:3.5.3")

    // 不再需要任何 nodejs-mobile 的 aar：Java 桥接层是本工程自己的
    // NodeBridge.java + CMake 编出的 libdsh-node.so。
    // 保留这条只为兼容用户自行放入的额外 jar/aar（可选，不影响启动）。
    implementation(fileTree(mapOf("dir" to "libs", "include" to listOf("*.jar", "*.aar"))))
}
