plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.android.dsh"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.android.dsh"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    sourceSets {
        getByName("main") {
            // nodejs-mobile 的 libnode.so / aar 由 scripts/fetch-libnode.sh 放到 libs/
            // assets/node 内容由 scripts/prepare-node-bundle.sh 从原仓库生成后覆盖
            jniLibs.srcDirs("src/main/jniLibs")
            assets.srcDirs("src/main/assets")
        }
    }

    packaging {
        jniLibs { useLegacyPackaging = true }
        resources { excludes += setOf("META-INF/DEPENDENCIES", "META-INF/LICENSE*") }
    }

    // assets/node/bundle.zip 已是压缩包，避免 aapt 再做一次无意义压缩
    androidResources { noCompress += "zip" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("com.google.android.material:material:1.12.0")
    implementation("com.google.zxing:core:3.5.3")

    // nodejs-mobile 运行时：把官方 aar / jar 放进 app/libs 即可自动参与编译；
    // 源码通过反射调用 NodeJS.start(...)，因此即便未放入 aar 也能编译通过，
    // 只是运行时会提示缺少运行时（见 README「运行时依赖」）。
    implementation(fileTree(mapOf("dir" to "libs", "include" to listOf("*.jar", "*.aar"))))
}
