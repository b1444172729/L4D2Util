# nodejs-mobile 通过 JNI 加载，禁止混淆 native 方法名
-keep class com.janeasystems.** { *; }
-keep class com.android.cloudflare.core.NodeRuntime { *; }
