'use strict';
/**
 * rootfs-manager.cjs —— proot + 官方 OpenCode CLI 生命周期管理（方案 C 核心）
 *
 * 跑在 APP 自带的 nodejs-mobile (Node 22) 里，与 oc-proxy.cjs 同进程。
 * 设计要点：
 *   · 全部逻辑在 JS 侧（child_process + zlib + fs），不动 Kotlin / JNI / C 胶水；
 *   · APK 不内置任何二进制 —— rootfs 从「本地导入 / 自定义 URL / 已解压目录」来；
 *   · 纯 JS 解 tar.gz，不依赖系统 toybox/busybox tar，兼容性与报错都可控；
 *   · 启动命令按 OCGW APK 的 DEX 常量序列 1:1 还原；
 *   · 失败时给出可照做的中文原因，绝不静默降级到付费通道。
 *
 * 为什么不让 Kotlin 侧做：Node 跑在 :node 独立进程，同一 UID / 同一网络命名空间 /
 * 共享 filesDir，spawn 出来的 proot 与网关同生命周期，无需跨进程同步。
 */

const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const https = require('https');
const http = require('http');
const crypto = require('crypto');
const { spawn, spawnSync, execFileSync } = require('child_process');

// ------------------------------------------------------------------ 常量
// 原仓库 release 地址（可能已下架，仅作默认候选；管理页可改 / 可用本地导入绕过）。
const DEFAULT_ROOTFS_URL =
    'https://github.com/dormantxxy/opencode-gateway-releases/releases/download/rootfs/rootfs-arm64.tar.gz';

const DEFAULT_MIRRORS = [
    'https://gh-proxy.com/', 'https://gh-proxy.top/', 'https://gh.ddlc.top/',
    'https://gh.llkk.cc/', 'https://gh.nyc3.sosnw.com/', 'https://ghfast.top/',
    'https://ghproxy.net/', 'https://git.886.be/', 'https://git.yiuman.com/'
];

// OCGW APK 校验的四件套，缺一即视为解压不完整。
const QUAD = [
    'opencode/bin/opencode',
    'proot/bin/proot',
    'proot/libexec/loader',
    'proot/lib/libtalloc.so.2'
];

const EXECUTABLES = [
    'opencode/bin/opencode',
    'proot/bin/proot',
    'proot/libexec/loader'
];

// 不在原 APK 的四件套校验里，但 proot 在部分 ROM 上确实需要。
// 只作为告警展示，不阻塞启动；缺了会让 CLI 起不来却显示「四件套 ✅」，很难排查。
const RECOMMENDED = [
    'proot/lib/libandroid-shmem.so',
    'proot/libexec/loader32'
];

let child = null;
let state = {
    phase: 'idle',            // idle | preparing | downloading | extracting | starting | ready | failed
    message: '',
    rootfsDir: '',
    servePort: 0,
    token: '',
    cliVersion: '',
    startedAt: 0,
    pid: 0
};
let cfgRef = {};
let logFn = () => {};

function log(m) {
    try { logFn('[rootfs] ' + m); } catch (_) {}
}
function setPhase(p, m) {
    state.phase = p;
    state.message = m;
    log(p + ' · ' + m);
}

// ------------------------------------------------------------------ 工具
function realOr(p) { try { return fs.realpathSync.native(p); } catch (_) { return p; } }

function human(bytes) {
    if (bytes > 1024 * 1024) return (bytes / 1024 / 1024).toFixed(1) + ' MB';
    if (bytes > 1024) return (bytes / 1024).toFixed(0) + ' KB';
    return bytes + ' B';
}

function randomToken(n) {
    const a = '0123456789abcdef';
    let s = '';
    for (let i = 0; i < n; i++) s += a[crypto.randomInt(0, 16)];
    return s;
}

function dataDir() { return cfgRef.dataDir || process.cwd(); }
function setDataDir(dir) { if (dir) cfgRef.dataDir = String(dir); }
function defaultRootfsDir() { return path.join(dataDir(), 'rootfs'); }
function defaultArchive() { return path.join(dataDir(), 'import', 'rootfs-arm64.tar.gz'); }
function defaultWorkspace() { return path.join(dataDir(), 'workspace'); }
function cliLogPath() { return path.join(dataDir(), 'opencode.log'); }

function resolveRootfsDir(cfg) {
    const d = (cfg.rootfsDir || '').trim();
    return d ? path.resolve(d) : defaultRootfsDir();
}

/** 四件套校验，返回 { ok, missing[], dir } */
function checkQuad(dir) {
    const missing = [];
    for (const rel of QUAD) {
        const p = path.join(dir, rel);
        if (!fs.existsSync(p) || !fs.statSync(p).isFile()) missing.push(rel);
    }
    return { ok: missing.length === 0, missing: missing, dir: dir };
}

function chmodExecutables(dir) {
    const out = [];
    for (const rel of EXECUTABLES) {
        const p = path.join(dir, rel);
        try {
            fs.chmodSync(p, 0o755);
            out.push(rel + ' ✓');
        } catch (e) {
            out.push(rel + ' chmod 失败: ' + e.message);
        }
    }
    // loader 依赖的同目录 .so 也要可读
    try { fs.chmodSync(path.join(dir, 'proot/lib/libtalloc.so.2'), 0o644); } catch (_) {}
    return out;
}

// ------------------------------------------------------------------ 本地归档发现（r5d）
/**
 * 用户已经用 GitHub Actions 编译出 rootfs-arm64.tar.gz；从网页 Artifacts 下载时
 * GitHub 会再套一层 zip（rootfs-arm64.zip）。本版默认就在下面这些位置找，
 * **不访问任何在线源**（原 dormantxxy release 已 404、9 个镜像全 403）。
 */
const DOWNLOAD_DIRS = [
    '/storage/emulated/0/Download',
    '/sdcard/Download',
    '/sdcard/Downloads'
];
const ARCHIVE_NAMES = [
    'rootfs-arm64.tar.gz',
    'rootfs-arm64.zip',
    'opencode_rootfs.zip'
];

/** 纯 JS 读 zip：只取里面第一个 rootfs-arm64.tar.gz（GitHub artifact 外层）。 */
function unwrapZip(zipPath, outTarGz) {
    const buf = fs.readFileSync(zipPath);
    let eocd = -1;
    for (let i = buf.length - 22; i >= Math.max(0, buf.length - 65558); i--) {
        if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
    }
    if (eocd < 0) throw new Error('不是有效的 zip（找不到 EOCD）');
    const count = buf.readUInt16LE(eocd + 10);
    let off = buf.readUInt32LE(eocd + 16);
    let picked = null;
    const names = [];
    for (let n = 0; n < count && off + 46 <= buf.length; n++) {
        if (buf.readUInt32LE(off) !== 0x02014b50) break;
        const method = buf.readUInt16LE(off + 10);
        const csize = buf.readUInt32LE(off + 20);
        const usize = buf.readUInt32LE(off + 24);
        const nameLen = buf.readUInt16LE(off + 28);
        const extraLen = buf.readUInt16LE(off + 30);
        const commentLen = buf.readUInt16LE(off + 32);
        const localOff = buf.readUInt32LE(off + 42);
        const name = buf.toString('utf8', off + 46, off + 46 + nameLen);
        names.push(name);
        if (/rootfs-arm64\.tar\.gz$/i.test(name) && !name.includes('__MACOSX') && !picked) {
            picked = { name, method, csize, usize, localOff };
        }
        off += 46 + nameLen + extraLen + commentLen;
    }
    if (!picked) {
        throw new Error('zip 里没有 rootfs-arm64.tar.gz（可能下到的是 APK artifact 而不是 rootfs artifact）。内容：' +
            names.slice(0, 8).join('、'));
    }
    const lo = picked.localOff;
    if (lo + 30 > buf.length || buf.readUInt32LE(lo) !== 0x04034b50) throw new Error('zip local header 损坏');
    const lnLen = buf.readUInt16LE(lo + 26);
    const leLen = buf.readUInt16LE(lo + 28);
    const start = lo + 30 + lnLen + leLen;
    const comp = buf.subarray(start, start + picked.csize);
    let data;
    if (picked.method === 0) data = comp;
    else if (picked.method === 8) data = zlib.inflateRawSync(comp);
    else throw new Error('不支持的 zip 压缩方式 method=' + picked.method);
    if (data.length < 1024 * 1024) throw new Error('解出的 tar.gz 太小（' + human(data.length) + '），不像有效归档');
    fs.mkdirSync(path.dirname(outTarGz), { recursive: true });
    fs.writeFileSync(outTarGz, data);
    return { file: outTarGz, bytes: data.length, from: zipPath, entry: picked.name };
}

function archiveCandidates(cfg) {
    const out = [];
    const explicit = (cfg.rootfsLocalPath || '').trim();
    if (explicit) out.push(explicit);
    for (const d of DOWNLOAD_DIRS) for (const n of ARCHIVE_NAMES) out.push(path.join(d, n));
    out.push(defaultArchive());
    out.push(path.join(dataDir(), 'import', 'rootfs-arm64.zip'));
    return out.filter((v, i, a) => a.indexOf(v) === i);
}

/** 只探测，返回列表供管理页显示，不写盘。 */
function probeArchives(cfg) {
    return archiveCandidates(cfg).map((p) => {
        try {
            const st = fs.statSync(p);
            return { path: p, exists: true, bytes: st.size, mtime: st.mtimeMs,
                     kind: /\.zip$/i.test(p) ? 'zip 外层（会自动解出 tar.gz）' : 'tar.gz' };
        } catch (_) { return { path: p, exists: false, bytes: 0, mtime: 0, kind: '' }; }
    });
}

/** 返回 { file, bytes, unwrapped, seen }；找不到时 file=null。 */
function findLocalArchive(cfg) {
    const seen = [];
    for (const p of archiveCandidates(cfg)) {
        try {
            if (!fs.existsSync(p) || !fs.statSync(p).isFile()) { seen.push(p + ' · 不存在'); continue; }
            const st = fs.statSync(p);
            if (st.size < 1024 * 1024) { seen.push(p + ' · 太小 ' + human(st.size)); continue; }
            if (/\.zip$/i.test(p)) {
                const dest = path.join(dataDir(), 'import', 'rootfs-arm64.tar.gz');
                if (fs.existsSync(dest) && fs.statSync(dest).mtimeMs >= st.mtimeMs && fs.statSync(dest).size > 1024 * 1024) {
                    log('复用已解出的归档：' + dest + '（zip 未更新）');
                    return { file: dest, bytes: fs.statSync(dest).size, unwrapped: p, seen };
                }
                const r = unwrapZip(p, dest);
                log('已从 zip 解出：' + r.entry + ' → ' + r.file + ' (' + human(r.bytes) + ')');
                return { file: r.file, bytes: r.bytes, unwrapped: p, seen };
            }
            return { file: p, bytes: st.size, unwrapped: null, seen };
        } catch (e) {
            seen.push(p + ' · 读取失败：' + e.message);
        }
    }
    return { file: null, bytes: 0, unwrapped: null, seen };
}

/** 清除已解压目录，强制下次重新导入/解包。 */
function invalidateRootfs(cfg) {
    const dir = resolveRootfsDir(cfg || cfgRef);
    for (const d of [dir, dir + '.staging']) {
        try { if (fs.existsSync(d)) fs.rmSync(d, { recursive: true, force: true }); } catch (_) {}
    }
    state.rootfsDir = '';
    state.phase = 'idle';
    state.message = '已清除旧 rootfs，等待重新导入';
    log('已清除 ' + dir);
    return dir;
}

// ------------------------------------------------------------------ 纯 JS tar.gz 解压
/**
 * 解析 GNU tar / ustar / PAX。支持普通文件、目录、symlink、GNU longname、
 * PAX extended header 的 path 覆盖；拒绝路径穿越与绝对路径。
 */
function extractTarGz(archive, destDir, onProgress) {
    const raw = fs.readFileSync(archive);
    let buf;
    try { buf = zlib.gunzipSync(raw); }
    catch (e) { throw new Error('gunzip 失败（文件不是 gzip 或损坏）：' + e.message); }

    fs.mkdirSync(destDir, { recursive: true });
    const destReal = realOr(destDir);
    let off = 0;
    let longName = null;
    let paxPath = null;
    let count = 0;
    let written = 0;

    function octal(b, o, len) {
        const s = b.toString('ascii', o, o + len).replace(/\0.*$/, '').trim();
        if (!s) return 0;
        return parseInt(s, 8) || 0;
    }
    function safeJoin(name) {
        if (!name || path.isAbsolute(name)) return null;
        const p = path.resolve(destDir, name);
        const rel = path.relative(destReal, p);
        if (rel.startsWith('..') || path.isAbsolute(rel)) return null;
        return p;
    }
    function parsePax(b, o, len) {
        const text = b.toString('utf8', o, o + len);
        let p = 0;
        while (p < text.length) {
            const sp = text.indexOf(' ', p);
            if (sp < 0) break;
            const n = parseInt(text.slice(p, sp), 10);
            if (!Number.isFinite(n) || n <= 0) break;
            const rec = text.slice(sp + 1, p + n);
            const eq = rec.indexOf('=');
            if (eq > 0 && rec.slice(0, eq) === 'path') paxPath = rec.slice(eq + 1).replace(/\n$/, '');
            p += n;
        }
    }

    while (off + 512 <= buf.length) {
        const h = buf.subarray(off, off + 512);
        off += 512;
        // 全零块 = 结束
        if (h.every((v) => v === 0)) break;

        let name = h.toString('utf8', 0, 100).replace(/\0.*$/, '');
        const prefix = h.toString('utf8', 345, 500).replace(/\0.*$/, '');
        if (prefix) name = prefix + '/' + name;
        const size = octal(h, 124, 12);
        const type = String.fromCharCode(h[156] || 0x30);
        const linkname = h.toString('utf8', 157, 257).replace(/\0.*$/, '');
        const mode = octal(h, 100, 8) || 0o644;
        const dataOff = off;
        off += Math.ceil(size / 512) * 512;

        if (type === 'L') { // GNU long name
            longName = buf.toString('utf8', dataOff, dataOff + size).replace(/\0.*$/, '');
            continue;
        }
        if (type === 'K') { continue; } // GNU long link name，忽略
        if (type === 'x' || type === 'g') { // PAX
            parsePax(buf, dataOff, size);
            continue;
        }
        const finalName = paxPath || longName || name;
        longName = null; paxPath = null;
        if (!finalName) continue;

        const target = safeJoin(finalName);
        if (!target) { log('跳过不安全路径: ' + finalName); continue; }

        try {
            if (type === '5') {
                fs.mkdirSync(target, { recursive: true });
            } else if (type === '2') {
                fs.mkdirSync(path.dirname(target), { recursive: true });
                try { fs.unlinkSync(target); } catch (_) {}
                fs.symlinkSync(linkname, target);
            } else if (type === '0' || type === '\0' || type === '7') {
                fs.mkdirSync(path.dirname(target), { recursive: true });
                fs.writeFileSync(target, buf.subarray(dataOff, dataOff + size));
                try { fs.chmodSync(target, mode & 0o777); } catch (_) {}
                written += size;
            }
            count++;
            if (onProgress && count % 200 === 0) onProgress(count, written);
        } catch (e) {
            log('解包条目失败 ' + finalName + ': ' + e.message);
        }
    }
    return { files: count, bytes: written };
}

// ------------------------------------------------------------------ 下载
function httpsGet(url, headers, timeoutMs) {
    return new Promise((resolve, reject) => {
        const req = https.get(url, { headers: headers || {}, timeout: timeoutMs || 15000 }, (res) => resolve(res));
        req.on('timeout', () => req.destroy(new Error('timeout')));
        req.on('error', reject);
    });
}

async function probeMirror(url) {
    const t0 = Date.now();
    try {
        const res = await httpsGet(url, { Range: 'bytes=0-1023' }, 6000);
        res.resume();
        const ok = res.statusCode === 200 || res.statusCode === 206;
        return { url, ms: Date.now() - t0, ok, status: res.statusCode };
    } catch (e) {
        return { url, ms: 999999, ok: false, status: 0, err: e.message };
    }
}

/**
 * 候选 = 管理页「下载直连 URL」多行列表里的每个 URL，
 * 每个 github.com 链接再叠加各加速镜像前缀；对象存储 / 自建源不加前缀。
 * 测速取最快可用者。
 */
async function pickFastest(cfg) {
    const rawUrls = (cfg.rootfsUrls || '').trim();
    const bases = rawUrls
        ? rawUrls.split(/\r?\n/).map((s) => s.trim()).filter((s) => s && !s.startsWith('#'))
        : [(cfg.rootfsUrl || DEFAULT_ROOTFS_URL).trim()];
    const mirrors = (cfg.rootfsMirrors || DEFAULT_MIRRORS.join('\n'))
        .split(/\r?\n/).map((s) => s.trim()).filter((s) => s && !s.startsWith('#'));

    const candidates = [];
    for (const base of bases) {
        if (!base) continue;
        candidates.push(base);
        // 镜像前缀只对 GitHub release 直链有意义
        if (/^https:\/\/github\.com\//i.test(base)) {
            for (const m of mirrors) candidates.push(m.endsWith('/') ? m + base : m + '/' + base);
        }
    }
    if (!candidates.length) return null;

    log('测速 ' + candidates.length + ' 个候选源…');
    const results = await Promise.all(candidates.map(probeMirror));
    for (const r of results) log('  ' + (r.ok ? '✓' : '✗') + ' ' + r.status + ' ' + r.ms + 'ms ' + r.url.slice(0, 90));
    const ok = results.filter((r) => r.ok).sort((a, b) => a.ms - b.ms);
    return ok[0] || null;
}

async function download(url, dest, onProgress) {
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    const tmp = dest + '.part';
    let existing = 0;
    if (fs.existsSync(tmp)) existing = fs.statSync(tmp).size;

    return new Promise((resolve, reject) => {
        const headers = existing > 0 ? { Range: 'bytes=' + existing + '-' } : {};
        const req = https.get(url, { headers, timeout: 30000 }, (res) => {
            if (res.statusCode === 416) { // 断点越界，重头下
                try { fs.unlinkSync(tmp); } catch (_) {}
                res.resume();
                return download(url, dest, onProgress).then(resolve, reject);
            }
            if (res.statusCode !== 200 && res.statusCode !== 206) {
                res.resume();
                return reject(new Error('HTTP ' + res.statusCode + '（源不可达或资源已下架）'));
            }
            const total = Number(res.headers['content-length'] || 0) + (res.statusCode === 206 ? existing : 0);
            const mode = res.statusCode === 206 && existing > 0 ? 'a' : 'w';
            const ws = fs.createWriteStream(tmp, { flags: mode });
            let got = existing;
            let lastLog = 0;
            res.on('data', (c) => {
                got += c.length;
                const now = Date.now();
                if (now - lastLog > 1200) {
                    lastLog = now;
                    const pct = total ? ' ' + Math.min(100, (got / total * 100).toFixed(0)) + '%' : '';
                    log('下载 ' + human(got) + (total ? ' / ' + human(total) : '') + pct);
                    if (onProgress) onProgress(got, total);
                }
            });
            res.pipe(ws);
            ws.on('finish', () => {
                try { fs.renameSync(tmp, dest); } catch (e) { return reject(e); }
                resolve({ bytes: got });
            });
            ws.on('error', reject);
        });
        req.on('timeout', () => req.destroy(new Error('下载超时')));
        req.on('error', reject);
    });
}

/**
 * 大归档（真实 rootfs 约 300 MB）优先用系统 toybox tar 流式解包，
 * 避免 gunzipSync 把整个 gzip + tar 一次性读进内存触发低内存终止。
 * 这与 OCGW APK 的 ProcessBuilder("tar","-xzf",...) 完全一致；
 * 系统 tar 不可用或失败时才回退纯 JS 实现。
 */
function extractArchiveSmart(archive, destDir) {
    try {
        const r = spawnSync('tar', ['-xzf', archive, '-C', destDir], {
            timeout: 15 * 60 * 1000, maxBuffer: 4 * 1024 * 1024, encoding: 'utf8'
        });
        if (r.status === 0) {
            log('解包引擎：系统 tar（流式，避免大归档占满内存）');
            return { files: -1, bytes: 0, engine: 'system-tar' };
        }
        log('系统 tar 返回 ' + r.status + '（' + String(r.stderr || r.error || '').slice(0, 200) + '），回退纯 JS');
    } catch (e) {
        log('系统 tar 不可用（' + e.message + '），回退纯 JS');
    }
    // 清掉可能残留的半截文件再解一次
    try { fs.rmSync(destDir, { recursive: true, force: true }); } catch (_) {}
    fs.mkdirSync(destDir, { recursive: true });
    const r = extractTarGz(archive, destDir, (n, b) => log('  已解 ' + n + ' 项 / ' + human(b)));
    return Object.assign(r, { engine: 'pure-js' });
}

// ------------------------------------------------------------------ DNS
function writeResolvConf(dir, cfg) {
    let dns = [];
    const explicit = (cfg.dns || '').split(/[\s,]+/).filter(Boolean);
    if (explicit.length) {
        dns = explicit;
    } else {
        for (const k of ['net.dns1', 'net.dns2', 'net.dns3']) {
            try {
                const v = execFileSync('/system/bin/getprop', [k], { encoding: 'utf8', timeout: 2000 }).trim();
                if (v && /^[\d.]+$/.test(v)) dns.push(v);
            } catch (_) {}
        }
        if (!dns.length) dns = ['223.5.5.5', '119.29.29.29', '8.8.8.8'];
    }
    const etc = path.join(dir, 'etc');
    try {
        fs.mkdirSync(etc, { recursive: true });
        fs.writeFileSync(path.join(etc, 'resolv.conf'), dns.map((d) => 'nameserver ' + d).join('\n') + '\n');
        log('resolv.conf: ' + dns.join(', '));
    } catch (e) {
        log('写 resolv.conf 失败: ' + e.message);
    }
    return dns;
}

// ------------------------------------------------------------------ 启动
function buildSpawn(cfg, dir, password, port) {
    const workspace = (cfg.bindWorkspace || '').trim() || defaultWorkspace();
    fs.mkdirSync(workspace, { recursive: true });
    const prootAbs = path.join(dir, 'proot/bin/proot');
    const opencodeInside = '/' + (cfg.opencodeBin || 'opencode/bin/opencode').replace(/^\/+/, '');

    const args = [
        '-r', dir,
        '-b', '/dev', '-b', '/proc', '-b', '/sys', '-b', '/dev/pts',
        '-b', workspace + ':/workspace',
        '--kill-on-exit',
        '-w', '/workspace',
        opencodeInside,
        'serve', '--hostname', (cfg.serveHost || '127.0.0.1'), '--port', String(port)
    ];
    const extra = (cfg.extraProotArgs || '').trim();
    if (extra) args.splice(args.indexOf('--kill-on-exit'), 0, ...extra.split(/\s+/));

    // 【r5d】对齐 OCGW APK 实测通过的 ProcessBuilder.environment().clear()：
    // 不继承 nodejs-mobile 的整份环境（NODE_* / Android 变量会干扰 proot），
    // 只给 proot 与 CLI 必需的 8 个变量。
    const env = {
        OPENCODE_PASSWORD: password,
        HOME: '/root',
        PATH: '/usr/local/bin:/usr/bin:/bin',
        TMPDIR: '/tmp',
        LD_LIBRARY_PATH: path.join(dir, 'proot/lib'),
        PROOT_LOADER: path.join(dir, 'proot/libexec/loader'),
        PROOT_TMP_DIR: path.join(dataDir(), 'proot-tmp'),
        OPENCODE_PORT: String(port)
    };
    fs.mkdirSync(env.PROOT_TMP_DIR, { recursive: true });
    return { prootAbs, args, env, workspace };
}

function localGet(pathname, port, headers, timeoutMs) {
    return new Promise((resolve) => {
        const req = http.get({ host: '127.0.0.1', port, path: pathname, headers: headers || {}, timeout: timeoutMs || 2500 }, (res) => {
            const cs = [];
            res.on('data', (c) => cs.push(c));
            res.on('end', () => resolve({ status: res.statusCode, raw: Buffer.concat(cs).toString('utf8') }));
        });
        req.on('error', (e) => resolve({ status: 0, raw: e.message }));
        req.on('timeout', () => { req.destroy(); resolve({ status: 0, raw: 'timeout' }); });
    });
}

function apiAuth(cfg, token) {
    if (cfg.apiStyle === 'basic') {
        return { query: '', headers: { Authorization: 'Basic ' + Buffer.from('opencode:' + token).toString('base64') } };
    }
    return { query: '?auth_token=' + encodeURIComponent(token), headers: {} };
}

async function waitForReady(cfg, token, port, tries) {
    const a = apiAuth(cfg, token);
    for (let i = 0; i < (tries || 60); i++) {
        const r = await localGet('/api/config' + a.query, port, a.headers, 2000);
        if (i % 10 === 0) {
            log('就绪探测 #' + i + ' → ' + r.status +
                (r.status === 401 || r.status === 403 ? '\n（认证方式可能不对，试切 apiStyle）' : ''));
        }
        if (r.status === 200) return { ok: true, status: 200, raw: r.raw.slice(0, 400) };
        await new Promise((r2) => setTimeout(r2, 500));
    }
    return { ok: false, status: 0, raw: 'waitForReady timeout' };
}

/**
 * 准备 rootfs（幂等）：已解压目录四件套齐全 → 直接复用。
 * 否则按 source 优先级：local(tar.gz) → url(下载) → dir(报错让用户放目录)。
 */
async function ensureRootfs(cfg) {
    const dir = resolveRootfsDir(cfg);
    const q = checkQuad(dir);
    if (q.ok) {
        setPhase('ready', 'rootfs 已就绪（跳过下载）：' + dir);
        chmodExecutables(dir);
        writeResolvConf(dir, cfg);
        state.rootfsDir = dir;
        return { ok: true, dir, reused: true };
    }

    const source = (cfg.rootfsSource || 'local');
    let archive = null;

    // ① 本地归档优先：显式路径 → /sdcard/Download/ → import/；.zip 外层自动解出 tar.gz
    if (source !== 'url' && source !== 'dir') {
        const found = findLocalArchive(cfg);
        for (const line of (found.seen || [])) log('  候选 ' + line);
        if (found.file) {
            archive = found.file;
            log('使用本地归档：' + archive + ' (' + human(found.bytes) + ')' +
                (found.unwrapped ? ' ← 由 ' + found.unwrapped + ' 解出' : ''));
        }
    }

    // ② 只有显式选 url 才联网。默认绝不访问已删除的 release 与 9 个失效镜像。
    if (!archive && source === 'url') {
        const urls = (cfg.rootfsUrls || '').trim() || (cfg.rootfsUrl || '').trim();
        if (!urls || /dormantxxy\/opencode-gateway-releases/i.test(urls)) {
            const msg = '当前是 url 模式，但填的是已删除的 dormantxxy 原地址（404）。' +
                '请切回 local，把 rootfs-arm64.tar.gz 放到 /sdcard/Download/；' +
                '或填你自己 fork 生成的 Release 直链。';
            setPhase('failed', msg);
            return { ok: false, reason: msg };
        }
        setPhase('downloading', '正在测速并下载 rootfs…');
        const best = await pickFastest(cfg);
        if (!best) {
            const msg = '所有下载源都不可达。请改用本地归档：把已有的 rootfs-arm64.tar.gz 放到 /sdcard/Download/，' +
                '管理页切回 local 后点「一键导入」。';
            setPhase('failed', msg);
            return { ok: false, reason: msg };
        }
        log('选定源：' + best.url);
        try {
            await download(best.url, defaultArchive(), null);
            archive = defaultArchive();
        } catch (e) {
            setPhase('failed', '下载失败：' + e.message + '；可改用本地导入。');
            return { ok: false, reason: e.message };
        }
    }

    if (!archive) {
        const cands = archiveCandidates(cfg).slice(0, 6).join('\n  ');
        const msg = '没有可用的 rootfs：目录 ' + dir + ' 缺 ' + q.missing.join('、') + '，且这些位置都没找到归档：\n  ' + cands +
            '\n把已编译好的 rootfs-arm64.tar.gz（或 Artifact 的 rootfs-arm64.zip）放到 /sdcard/Download/，' +
            '然后点管理页「📥 一键导入」。';
        setPhase('failed', msg);
        return { ok: false, reason: msg, missing: q.missing, dir };
    }

    setPhase('extracting', '解包 ' + path.basename(archive) + ' …');
    const staging = dir + '.staging';
    try {
        if (fs.existsSync(staging)) fs.rmSync(staging, { recursive: true, force: true });
        fs.mkdirSync(staging, { recursive: true });
        const r = extractArchiveSmart(archive, staging);
        log('解包完成（' + r.engine + '）：' + (r.files >= 0 ? r.files + ' 项 / ' + human(r.bytes) : '由系统 tar 完成'));
        // 兼容归档里多套一层顶层目录（如 rootfs-arm64/…）
        let src = staging;
        if (!checkQuad(staging).ok) {
            const inner = fs.readdirSync(staging).find((n) => fs.statSync(path.join(staging, n)).isDirectory() && checkQuad(path.join(staging, n)).ok);
            if (inner) src = path.join(staging, inner);
        }
        const q2 = checkQuad(src);
        if (!q2.ok) {
            setPhase('failed', 'rootfs incomplete after extract：缺 ' + q2.missing.join('、'));
            return { ok: false, reason: '解压后缺文件：' + q2.missing.join(', '), missing: q2.missing };
        }
        if (fs.existsSync(dir)) fs.rmSync(dir, { recursive: true, force: true });
        fs.mkdirSync(path.dirname(dir), { recursive: true });
        fs.renameSync(src, dir);
        if (fs.existsSync(staging)) fs.rmSync(staging, { recursive: true, force: true });
    } catch (e) {
        setPhase('failed', '解包失败：' + e.message);
        return { ok: false, reason: e.message };
    }

    const perms = chmodExecutables(dir);
    log('可执行权限：' + perms.join(' | '));
    writeResolvConf(dir, cfg);
    state.rootfsDir = dir;
    setPhase('ready', 'rootfs 已就绪：' + dir);
    return { ok: true, dir, reused: false };
}

async function start(cfg, opts) {
    cfgRef = Object.assign({}, cfg, opts || {});
    logFn = cfgRef.log || logFn;
    stop(true);

    const prepared = await ensureRootfs(cfgRef);
    if (!prepared.ok) return { ok: false, reason: prepared.reason, missing: prepared.missing };

    const dir = prepared.dir;
    const port = Number(cfgRef.servePort) || 4317;
    const token = (cfgRef.servePassword || '').trim() || randomToken(24);
    cfgRef.servePassword = token;
    state.token = token;
    state.servePort = port;

    setPhase('starting', '拉起 proot → opencode serve …');
    const { prootAbs, args, env, workspace } = buildSpawn(cfgRef, dir, token, port);
    log('命令：' + prootAbs + ' ' + args.join(' '));
    log('工作区：' + workspace);

    let out;
    try {
        out = fs.openSync(cliLogPath(), 'a');
        child = spawn(prootAbs, args, { env, cwd: dir, stdio: ['ignore', out, out], detached: false });
    } catch (e) {
        setPhase('failed', 'spawn 失败：' + e.message);
        return { ok: false, reason: 'spawn 失败：' + e.message, hint: spawnHint(e) };
    }

    child.on('error', (e) => {
        log('CLI 进程错误：' + e.message);
        setPhase('failed', 'CLI 进程错误：' + e.message);
    });
    child.on('exit', (code, sig) => {
        log('CLI 进程退出 code=' + code + ' sig=' + sig);
        if (state.phase === 'ready' || state.phase === 'starting') {
            setPhase('failed', 'opencode serve 意外退出（code=' + code + '），日志见 opencode.log');
        }
        child = null;
    });

    const ready = await waitForReady(cfgRef, token, port, Number(cfgRef.readyTries) || 60);
    if (!ready.ok) {
        const tail = readLogTail(30);
        setPhase('failed', '就绪探测超时。检查 opencode.log 与 apiStyle（query / basic）。');
        return { ok: false, reason: 'waitForReady timeout', logTail: tail };
    }

    state.phase = 'ready';
    state.message = 'opencode serve 就绪 · 127.0.0.1:' + port;
    state.pid = child ? child.pid : 0;
    state.startedAt = Date.now();
    state.cliVersion = parseVersion(ready.raw);
    log('READY ui=http://127.0.0.1:' + port + ' gateway=http://127.0.0.1:' + (cfgRef.gatewayPort || 18900) + '/v1');
    return { ok: true, port, token, pid: state.pid, version: state.cliVersion };
}

function spawnHint(e) {
    if (/EACCES|permission denied/i.test(String(e && e.message))) {
        return 'Android 10+ 可能禁止从 app 私有目录执行 ELF。缓解：把 proot / opencode 二进制作为 jniLibs 放进 APK 的 lib/arm64-v8a/（nativeLibraryDir 可执行），或降低 targetSdk；详见 PROOT_README.md。';
    }
    if (/ENOENT/.test(String(e && e.message))) {
        return 'proot 二进制路径不存在或依赖的动态库缺失，检查四件套与 LD_LIBRARY_PATH。';
    }
    return '检查 opencode.log 与 rootfs 架构（必须 arm64）。';
}

function parseVersion(raw) {
    try {
        const j = JSON.parse(raw);
        const s = JSON.stringify(j);
        const m = s.match(/"?version"?\s*:\s*"([^"]+)"/);
        return m ? m[1] : '';
    } catch (_) { return ''; }
}

function readLogTail(n) {
    try {
        const s = fs.readFileSync(cliLogPath(), 'utf8');
        return s.split(/\r?\n/).slice(-n).join('\n');
    } catch (_) { return '(opencode.log 为空)'; }
}

function stop(quiet) {
    if (child) {
        try { child.kill('SIGTERM'); } catch (_) {}
        child = null;
    }
    // proot/opencode 可能留下孙进程；仅在非静默时清理
    if (!quiet) {
        try {
            spawnSync('/system/bin/sh', ['-c', 'pkill -9 -f proot; pkill -9 -f "opencode serve"'], { timeout: 4000 });
        } catch (_) {}
    }
    if (!quiet) {
        setPhase('idle', '已停止');
        state.pid = 0;
    }
}

function status() {
    const dir = state.rootfsDir;
    const warnings = [];
    if (dir) {
        for (const rel of RECOMMENDED) {
            if (!fs.existsSync(path.join(dir, rel))) warnings.push('缺少 ' + rel + '（proot 在部分 ROM 上需要，四件套仍显示 ✅ 但 CLI 可能起不来）');
        }
    }
    return Object.assign({}, state, {
        alive: !!(child && !child.killed),
        quad: dir ? checkQuad(dir) : { ok: false, missing: QUAD },
        warnings,
        logTail: readLogTail(20)
    });
}

function apiRequest(cfg, method, pathname, body, timeoutMs) {
    const port = Number(cfg.servePort) || 4317;
    const a = apiAuth(cfg, cfg.servePassword || state.token);
    const full = pathname + a.query;
    const payload = body == null ? null : JSON.stringify(body);
    const headers = Object.assign({ 'Content-Type': 'application/json' }, a.headers);
    if (payload) headers['Content-Length'] = Buffer.byteLength(payload);
    return new Promise((resolve) => {
        const req = http.request({ host: '127.0.0.1', port, path: full, method, headers, timeout: timeoutMs || 30000 }, (res) => {
            const cs = [];
            res.on('data', (c) => cs.push(c));
            res.on('end', () => {
                const raw = Buffer.concat(cs).toString('utf8');
                let json = null;
                try { json = JSON.parse(raw); } catch (_) {}
                resolve({ status: res.statusCode, raw, json });
            });
        });
        req.on('error', (e) => resolve({ status: 0, raw: e.message, json: null }));
        req.on('timeout', () => { req.destroy(); resolve({ status: 0, raw: 'timeout', json: null }); });
        if (payload) req.write(payload);
        req.end();
    });
}

module.exports = {
    ensureRootfs, start, stop, status, apiRequest,
    checkQuad, extractTarGz, writeResolvConf, readLogTail,
    DEFAULT_ROOTFS_URL, DEFAULT_MIRRORS, QUAD, RECOMMENDED,
    findLocalArchive, probeArchives, unwrapZip, invalidateRootfs, setDataDir,
    state: () => state,
    setLog: (fn) => { logFn = fn; }
};
