'use strict';
/**
 * 聚合网关 · Node 侧启动入口（由 nodejs-mobile 以 `node bootstrap.cjs` 执行）
 *
 * ★ 扩展名必须是 .cjs，不能叫 .js：
 *   本文件与上游仓库根 package.json 同目录，而上游是 ESM 项目
 *   （package.json 含 "type": "module"）。若命名为 .js，Node 会按 ESM
 *   解析本文件，第一行 `const fs = require('fs')` 直接抛
 *     ReferenceError: require is not defined in ES module scope
 *   → 未捕获异常 → node::DefaultProcessExitHandler → exit(1)。
 *   这正是此前「atext 触发、日志一片空白」的真正原因：nodejs-mobile 把
 *   ESM loader 的错误直接以 logcat tag `nodejs` 输出，不写 fd 1/2，
 *   所以 C 层的 stdio pipe pump 接不到任何文本。
 *   .cjs 强制 CommonJS，require 可用；上游的 type:module 保持不变，
 *   standalone 的 ESM 模块照常由下方 require→ERR_REQUIRE_ESM→import() 回退加载。
 *
 * 职责只有三件，绝不改写原仓库逻辑：
 *   1. 把安卓私有目录映射成 standalone 的 OFM_HOME，并透传端口 / 数据目录；
 *   2. 找到并加载原仓库 packages/standalone 的真实入口，让原插件能力全量跑起来；
 *   3. 把「实际端口 / API Key / 一次性管理链接」回写成 gateway-runtime.json，
 *      供安卓壳与 WebView 读取（端口顺延、Key 不回显这两条原插件行为因此得以保留）。
 *
 * 注意：standalone 的安装制品与 Release 尚未发布，必须从完整源码仓库运行，
 * 因此 assets/node 里是「完整仓库剪掉 .git、再裁掉纯构建期文件」的散放源码，
 * 不能只拷 packages/standalone。r6 起不再打 bundle.zip、不再带 node_modules
 * （上游 standalone 运行时零裸包依赖），由 AssetInstaller 逐个复制到 filesDir。
 */

const fs = require('fs');
const path = require('path');
// r5：ROOT 会在 main() 里被 realpath 覆盖，必须是 let。
let ROOT = __dirname;

// ---------------------------------------------------------------- 参数
// 安卓侧由 C 胶水把配置 setenv 成 OFM_*，argv 只保留 ["node", 本脚本]。
// 命令行参数仍保留兼容（桌面端/手工运行），且优先级高于环境变量。
function parseArgs(argv) {
  const positive = (v, d) => {
    const n = parseInt(v || '', 10);
    return Number.isFinite(n) && n > 0 ? n : d;
  };
  const out = {
    port: positive(process.env.OFM_PORT, 18900),
    dataDir: process.env.OFM_DATA_DIR || '',
    host: process.env.OFM_HOST || '127.0.0.1',
    lanRelay: process.env.OFM_LAN_RELAY === '1'
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--') continue;
    if (a === '--port') out.port = positive(argv[++i], out.port);
    else if (a === '--data-dir') out.dataDir = argv[++i];
    else if (a === '--host') out.host = argv[++i];
    else if (a === '--lan-relay') out.lanRelay = true;
  }
  return out;
}

const opts = parseArgs(process.argv.slice(2));
const DATA_DIR = opts.dataDir || path.join(process.env.HOME || ROOT, '.our-free-model');
fs.mkdirSync(DATA_DIR, { recursive: true });

// standalone 认 OFM_HOME / --data-dir，这里把安卓路径统一喂进去
process.env.OFM_HOME = DATA_DIR;
process.env.OFM_HOST = opts.host;
process.env.OFM_PORT = String(opts.port);

const RUNTIME_FILE = path.join(DATA_DIR, 'gateway-runtime.json');
const ERROR_LOG = path.join(DATA_DIR, 'node-errors.log');
const OUTPUT_LOG = path.join(DATA_DIR, 'node-output.log');
const BOOT_LOG = path.join(DATA_DIR, 'bootstrap.log');
const FATAL_FILE = path.join(DATA_DIR, 'node-fatal.txt');
const SETTINGS_FILE = path.join(DATA_DIR, 'settings.json');

// ★ 独立诊断日志：C 层 watchdog 每 0.5s 往 node-output.log 写一行心跳，
// 上一轮截图里 tail 22 行全被 tick=10..30 占满，standalone 的真实报错
// 完全看不见。所有 JS 层关键行同时写一份到 bootstrap.log，界面优先读它。
function bootlog(msg) {
  try { fs.appendFileSync(BOOT_LOG, '[bootstrap] ' + msg + '\n'); } catch (_) {}
}

// ★ JS 层心跳：用 fs 直接写，不依赖 stdout。
// 日志里若出现这一行，说明 Node/V8 初始化成功、脚本已被执行；
// 没有这一行则是引擎层就挂了。这是区分两层故障的关键分界线。
function jsbeat(msg) {
  const line = '[bootstrap] ' + msg + '\n';
  try { fs.appendFileSync(OUTPUT_LOG, line); } catch (_) {}
  try { fs.appendFileSync(BOOT_LOG, line); } catch (_) {}
}

// 致命失败：写 node-fatal.txt 让 HealthProbe 下一轮（≤400ms）立刻收尾，
// 不再干等 30 秒超时，同时把原因写进 bootstrap.log 供界面直接显示。
function fatal(msg) {
  bootlog('致命失败：' + msg);
  try { fs.appendFileSync(ERROR_LOG, '[' + new Date().toISOString() + '] ' + msg + '\n'); } catch (_) {}
  try { fs.writeFileSync(FATAL_FILE, msg); } catch (_) {}
}
jsbeat('JS 层已启动 pid=' + process.pid +
  ' node=' + process.version +
  ' cwd=' + process.cwd() +
  ' port=' + opts.port +
  ' OFM_HOME=' + DATA_DIR);

// ------------------------------------------------- Node 引擎冒烟测试
// 安卓壳写 ofm-data/smoke.flag 后再启动 :node，本分支只验证
// 「V8 能否初始化并执行任意 JS」，完全不碰上游源码树 / standalone /
// 依赖 / 网络 / 端口。若连这一步都 exit()，问题就 100% 在 libnode.so
// 二进制本身，与网关代码无关；若通过，则故障在 standalone 或其依赖。
const SMOKE_FLAG = path.join(DATA_DIR, 'smoke.flag');
const SMOKE_RESULT = path.join(DATA_DIR, 'smoke-result.txt');
if (fs.existsSync(SMOKE_FLAG)) {
  const info = 'SMOKE_OK node=' + process.version +
    ' pid=' + process.pid +
    ' cwd=' + process.cwd() +
    ' icu=' + (process.config.variables.icu_small_icu === false ? 'full' : 'small/none') +
    ' intl=' + (typeof Intl === 'object' ? 'yes' : 'no');
  try { fs.writeFileSync(SMOKE_RESULT, info); } catch (_) {}
  jsbeat('SMOKE OK → ' + info);
  console.log('[bootstrap] ' + info);
  process.exit(0);
}

// ------------------------------------------------- 异常退出后的锁残留处理
// 桌面文档：异常退出若 service.lock 仍在，先核对 PID，确认旧进程已停再移除。
(function clearStaleLock() {
  const lock = path.join(DATA_DIR, 'service.lock');
  if (!fs.existsSync(lock)) return;
  try {
    const raw = JSON.parse(fs.readFileSync(lock, 'utf8'));
    const pid = Number(raw.pid || raw.PID || 0);
    if (pid && pid !== process.pid) {
      let alive = false;
      try { process.kill(pid, 0); alive = true; } catch (_) { alive = false; }
      if (!alive) fs.unlinkSync(lock);
      else logError('service.lock 指向仍存活的进程，未自动清理：pid=' + pid);
    }
  } catch (_) {
    // 锁文件内容不可解析时保守保留，由用户在管理页手动处理
    logError('service.lock 无法解析，保留原样');
  }
})();

function logError(msg) {
  const line = `[${new Date().toISOString()}] ${msg}\n`;
  try { fs.appendFileSync(ERROR_LOG, line); } catch (_) {}
  try { fs.appendFileSync(BOOT_LOG, line); } catch (_) {}
}

// Node 崩溃不能直接 exit()：在安卓里会连同宿主 App 一起被结束
process.on('uncaughtException', (e) => logError('uncaughtException: ' + (e && e.stack || e)));
process.on('unhandledRejection', (e) => logError('unhandledRejection: ' + (e && e.stack || e)));

// ------------------------------------------------- 运行信息回写（原子写）
const runtime = {
  port: opts.port,
  requestedPort: opts.port,
  apiKey: '',
  manageUrl: '',
  host: opts.host,
  pid: process.pid,
  startedAt: new Date().toISOString()
};

function publish() {
  const tmp = RUNTIME_FILE + '.tmp';
  try {
    fs.writeFileSync(tmp, JSON.stringify(runtime, null, 2), { mode: 0o600 });
    fs.renameSync(tmp, RUNTIME_FILE);
  } catch (e) {
    logError('写 gateway-runtime.json 失败: ' + e.message);
  }
}
// 同步先读一次：standalone 通常在 listen 之前就已落盘 settings.json
runtime.apiKey = readKey();
publish();

// ------------------------------------------------- 从 stdout 抓运行信息
// standalone 启动时会打印：API 地址、一次性管理登录链接、密钥文件位置（不打印 Key）。
// 我们不改它的输出，只在同一行里做只读匹配，顺带捕获「实际监听端口」。
const originalLog = console.log.bind(console);
const originalError = console.error.bind(console);

function observe(line) {
  const s = String(line);
  const api = s.match(/https?:\/\/127\.0\.0\.1:(\d+)\/v1/);
  if (api) { runtime.port = parseInt(api[1], 10); publish(); }

  const shifted = s.match(/实际监听\s*(\d+)/) || s.match(/actual\s+port\s*[:=]?\s*(\d+)/i);
  if (shifted) { runtime.port = parseInt(shifted[1], 10); publish(); }

  const url = s.match(/https?:\/\/127\.0\.0\.1:\d+[^\s"'<>]*/);
  if (url && !runtime.manageUrl) {
    runtime.manageUrl = url[0];
    originalLog('[bootstrap] 捕获管理页一次性链接');
    publish();
  }
}

// 除了走 stdout（C 层已 dup2 到日志文件），再用 fs 直写一份带 [js] 前缀的副本。
// Node 内部可能重新接管 stdio，直写能保证无论怎样都留得下 standalone 的输出。
console.log = (...args) => {
  const s = args.map(String).join(' ');
  observe(s);
  try { fs.appendFileSync(OUTPUT_LOG, '[js] ' + s + '\n'); } catch (_) {}
  try { fs.appendFileSync(BOOT_LOG, '[js] ' + s + '\n'); } catch (_) {}
  originalLog(...args);
};
console.error = (...args) => {
  const s = args.map(String).join(' ');
  observe(s);
  try { fs.appendFileSync(OUTPUT_LOG, '[js:err] ' + s + '\n'); } catch (_) {}
  try { fs.appendFileSync(BOOT_LOG, '[js:err] ' + s + '\n'); } catch (_) {}
  originalError(...args);
};

// ★ r5：上游 cli.mjs 的 `启动失败: Symlinks are not allowed in managed storage`
// 是直接 write(2) 出来的，绕过了上面的 console hook，只落在 node-output.log，
// 而界面优先显示 bootstrap.log —— 于是真实原因被我们猜测的三条旧文案盖住。
// 这里把原始流写入也镜像一份，保证任何形式的报错都能在界面上看到。
['stdout', 'stderr'].forEach((name) => {
  const stream = process[name];
  if (!stream || typeof stream.write !== 'function') return;
  const rawWrite = stream.write.bind(stream);
  stream.write = function (chunk) {
    try {
      const s = typeof chunk === 'string'
        ? chunk
        : (chunk && typeof chunk.toString === 'function' ? chunk.toString('utf8') : '');
      const t = s.replace(/\n+$/, '');
      if (t.trim()) fs.appendFileSync(BOOT_LOG, '[raw:' + name + '] ' + t + '\n');
    } catch (_) {}
    return rawWrite.apply(stream, arguments);
  };
});

// ------------------------------------------------- Key 读取（60 秒轮询）
// 字段名随版本可能变化，这里做宽松探测；绝不在日志里输出 Key 内容。
function readKey() {
  try {
    if (!fs.existsSync(SETTINGS_FILE)) return '';
    const o = JSON.parse(fs.readFileSync(SETTINGS_FILE, 'utf8'));
    const candidates = ['forwardKey', 'apiKey', 'localKey', 'key', 'token'];
    for (const k of candidates) {
      if (typeof o[k] === 'string' && o[k].trim()) return o[k].trim();
    }
    // 有些版本把 Key 放在嵌套对象里
    for (const v of Object.values(o)) {
      if (v && typeof v === 'object') {
        for (const k of candidates) {
          if (typeof v[k] === 'string' && v[k].trim()) return v[k].trim();
        }
      }
    }
  } catch (_) {}
  return '';
}

const keyTimer = setInterval(() => {
  if (runtime.apiKey) { clearInterval(keyTimer); return; }
  const k = readKey();
  if (k) {
    runtime.apiKey = k;
    publish();
    originalLog('[bootstrap] 已读取本机 API Key（内容不回显）');
    clearInterval(keyTimer);
  }
}, 500);
setTimeout(() => clearInterval(keyTimer), 60_000);

// ------------------------------------------------- 定位 standalone 入口
function resolveEntry() {
  // 优先按根 package.json 的 npm script 推断，避免硬编码随版本变化的文件名。
  // ★ 把 script 原文写进诊断日志：上游若用 `tsx` / `node --experimental-*`
  // / `--env-file` / `--import` 等包装器，直接 require 入口会缺少前置条件，
  // 表现为「模块加载了但服务没起来、也不抛异常」。这一行能一眼看出来。
  try {
    const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
    const script = (pkg.scripts || {})['start:standalone'];
    bootlog('上游 start:standalone = ' + (script || '(未声明)'));
    bootlog('上游 package.json type = ' + (pkg.type || '(未声明)') +
      ' | engines.node = ' + ((pkg.engines && pkg.engines.node) || '(未声明)') +
      ' | 当前 Node = ' + process.version);
    if (script) {
      // 上游是 ESM 项目，入口可能是 .mjs / .cjs，不能只认 .js
      const m = script.match(/(?:node|nodejs)\s+([^\s]+\.(?:js|mjs|cjs))/i);
      if (m) {
        const p = path.resolve(ROOT, m[1]);
        if (fs.existsSync(p)) {
          bootlog('按 script 命中入口：' + p);
          return p;
        }
        bootlog('script 里的入口不存在：' + p);
      }
    }
  } catch (e) {
    bootlog('读取根 package.json 失败：' + (e && e.message || e));
  }

  const candidates = [
    'packages/standalone/src/index.js',
    'packages/standalone/src/index.mjs',
    'packages/standalone/index.js',
    'packages/standalone/index.mjs',
    'packages/standalone/dist/index.js',
    'packages/standalone/dist/index.mjs',
    'packages/standalone/server.js',
    'packages/standalone/server.mjs',
    'packages/standalone/src/server.js',
    'packages/standalone/src/server.mjs',
    'packages/standalone/main.js',
    'packages/standalone/main.mjs'
  ];
  for (const c of candidates) {
    const p = path.resolve(ROOT, c);
    if (fs.existsSync(p)) {
      bootlog('按候选列表命中入口：' + p);
      return p;
    }
  }
  bootlog('候选列表全部未命中：' + candidates.join(', '));
  throw new Error(
    '未找到 standalone 入口。请检查 packages/standalone 的实际文件名，' +
    '并修改 bootstrap.cjs 的 candidates 或根 package.json 的 start:standalone 脚本。'
  );
}

// 引擎版本核对：上游独立服务文档明确要求「符合仓库 engines 的 Node.js」，
// 社区实测为 Node 22+；而 nodejs-mobile 官方 Android 构建是 v18.20.4。
// 版本不匹配时 standalone 可能用 Node 20/22 的 API 直接失败，或安静地不启动。
(function checkEngines() {
  try {
    const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
    const req = (pkg.engines && pkg.engines.node) || '';
    const m = req.match(/(\d+)/);
    if (m && parseInt(process.versions.node, 10) < parseInt(m[1], 10)) {
      bootlog(
        '⚠️ 运行时版本不足：上游 engines.node=' + req +
        '，当前 libnode 仅 ' + process.version +
        '。standalone 很可能因此拒绝启动；需要换 Node 22+ 的 Android libnode.so。'
      );
    }
  } catch (_) {}
})();

// ------------------------------------------------- 启动
(async function main() {
  try {
    // ------------------------------------------------------------ r5
    // 上游 standalone 启动时会校验「managed storage」里不允许符号链接：
    //   启动失败: Symlinks are not allowed in managed storage
    // Android 上 /data/data 常是 /data/user/0 的符号链接 / bind mount，
    // 同一个物理目录却有两种字符串表示（截图里 cwd=/data/data/...，
    // OFM_HOME=/data/user/0/...）。C 胶水已用 getcwd() 统一到真实视角，
    // 这里再把 JS 层看到的 ROOT / 各环境变量全部 realpath 化，确保
    // 上游逐级 lstat 父链时一个符号链接都碰不到。
    function realOr(p) {
      try { return fs.realpathSync.native(p); } catch (_) { return p; }
    }
    function parentLinks(p) {
      const out = [];
      let cur = p;
      for (let i = 0; i < 12; i++) {
        try {
          const st = fs.lstatSync(cur);
          if (st.isSymbolicLink()) out.push(cur + ' -> ' + fs.readlinkSync(cur));
        } catch (_) {}
        const up = path.dirname(cur);
        if (up === cur) break;
        cur = up;
      }
      return out;
    }
    const RAW_ROOT = ROOT;
    const RAW_DATA = DATA_DIR;
    ROOT = realOr(ROOT);
    const REAL_DATA = realOr(DATA_DIR);
    try { process.chdir(ROOT); } catch (_) {}
    process.env.OFM_HOME = REAL_DATA;
    process.env.OFM_DATA_DIR = REAL_DATA;
    process.env.HOME = REAL_DATA;
    // r6：上游 standalone 零裸包依赖，正常情况下没有 node_modules。
    // 仅当自适应探测确实装了运行时依赖时才指过去，避免留一个不存在的路径。
    const MODULES = path.join(ROOT, 'node_modules');
    if (fs.existsSync(MODULES)) process.env.NODE_PATH = MODULES;
    process.env.TMPDIR = realOr(process.env.TMPDIR || REAL_DATA);
    bootlog('r5 路径规范化 ROOT: ' + RAW_ROOT + ' -> ' + ROOT);
    bootlog('r5 路径规范化 DATA: ' + RAW_DATA + ' -> ' + REAL_DATA);
    bootlog('r5 ROOT 父链符号链接：' + JSON.stringify(parentLinks(ROOT)));
    bootlog('r5 DATA 父链符号链接：' + JSON.stringify(parentLinks(REAL_DATA)));
    bootlog('r5 规范化后 cwd=' + process.cwd() + ' | OFM_HOME=' + process.env.OFM_HOME);

    const entry = resolveEntry();
    jsbeat('standalone entry=' + entry);
    bootlog('OFM_HOME=' + process.env.OFM_HOME);
    bootlog('requested port=' + opts.port + ', lanRelay=' + opts.lanRelay);
    originalLog('[bootstrap] OFM_HOME=' + DATA_DIR);
    originalLog('[bootstrap] standalone entry=' + entry);

    // 把参数以命令行形式传给原入口（原入口读 process.argv 时也能拿到）。
    // 环境变量 OFM_* 已由 C 层设好，这里双通道兼容 standalone 的版本差异。
    process.argv = [
      process.argv[0],
      entry,
      '--port', String(opts.port),
      '--data-dir', DATA_DIR,
      ...(opts.lanRelay ? ['--lan-relay'] : [])
    ];
    jsbeat('即将加载 entry，此后交给 standalone');

    // r5：上游 managed storage 校验会扫描代码目录/数据目录里的符号链接。
    // npm install 生成的 node_modules/.bin 是符号链接重灾区；CI 打包时已用
    // tar --dereference 实体化，这里再兜一层：发现链接就替换成真实文件副本，
    // 并把处理数量写进 bootstrap.log，便于核对上游是否还看得到链接。
    function defuseSymlinks(dir, label, maxDepth) {
      let fixed = 0;
      const seen = new Set();
      function walk(d, depth) {
        if (depth > maxDepth || fixed > 400) return;
        let items = [];
        try { items = fs.readdirSync(d, { withFileTypes: true }); } catch (_) { return; }
        for (const it of items) {
          const p = path.join(d, it.name);
          if (seen.has(p)) continue;
          seen.add(p);
          if (it.isSymbolicLink()) {
            try {
              const target = fs.realpathSync(p);
              const st = fs.statSync(target);
              fs.unlinkSync(p);
              if (st.isFile()) fs.copyFileSync(target, p);
              else fs.mkdirSync(p, { recursive: true });
              fixed++;
            } catch (_) {
              try { fs.unlinkSync(p); fixed++; } catch (_) {}
            }
          } else if (it.isDirectory() && depth < maxDepth) {
            walk(p, depth + 1);
          }
        }
      }
      walk(dir, 0);
      bootlog('r5 ' + label + ' 符号链接实体化：' + fixed + ' 处（目录 ' + dir + '）');
      return fixed;
    }
    defuseSymlinks(path.join(ROOT, 'node_modules/.bin'), 'node_modules/.bin', 1);
    defuseSymlinks(ROOT, 'ROOT 顶层', 1);
    defuseSymlinks(process.env.OFM_HOME, 'OFM_HOME 顶层', 1);

    try {
      if (/\.(mjs|js)$/i.test(entry)) {
        // 根 package.json 是 type:module，入口必须按 ESM 主模块语义加载。
        // Node 22 虽允许 require(esm)，但那不是上游 `node cli.mjs` 的形态，
        // 会让 import.meta 相关判断失真；显式走动态 import 更贴近官方启动。
        bootlog('入口是 ESM，使用动态 import()');
        await import(require('url').pathToFileURL(entry).href);
        bootlog('动态 import() 已返回');
      } else {
        require(entry);
        bootlog('require(entry) 已返回（CommonJS 路径）');
      }
    } catch (e) {
      if (e && e.code === 'ERR_REQUIRE_ESM') {
        await import(require('url').pathToFileURL(entry).href);
        bootlog('回退动态 import() 已返回');
      } else {
        throw e;
      }
    }

    // ★ 关键自检：加载「成功」不代表服务起来了。
    // 上游若把入口写成「导出 start() 而不自启动」、或用 import.meta.main
    // 之类 Node 20+ 特性判断，模块会安静加载完、不抛异常、也不 listen ——
    // 这正是上一轮「node::Start 返回 rc=1、日志无任何报错」的形态。
    // 8 秒后探测一次 /health，没监听就写 fatal，让界面立刻显示真实原因。
    setTimeout(() => {
      try {
        const http = require('http');
        const req = http.get(
          { host: opts.host, port: opts.port, path: '/health', timeout: 1500 },
          (res) => {
            bootlog('启动自检：/health HTTP ' + res.statusCode + ' ✅ 服务已监听');
            res.resume();
          }
        );
        req.on('error', (e) => {
          // 把上游直接写 stderr 的真实原因捞出来放在最前面，不再用猜的三条盖住它
          let upstream = '';
          try {
            const raw = fs.readFileSync(OUTPUT_LOG, 'utf8').split('\n').slice(-120);
            const hits = raw.filter((l) =>
              /启动失败|Symlinks|not allowed|managed storage|ERR_|Error:|EACCES|ENOENT/i.test(l) &&
              !/^\s*$/.test(l));
            if (hits.length) upstream = '上游原始报错：' + hits.slice(-3).join(' | ') + '\n';
          } catch (_) {}
          fatal(
            upstream +
            '入口已加载但 ' + opts.port + ' 端口没有服务监听（/health: ' + e.message + '）。\n' +
            '优先看 bootstrap.log 的 [raw:stderr] 行与 r5 路径规范化/符号链接诊断：\n' +
            '① 上游 managed storage 闸门拒绝符号链接（/data/data 与 /data/user/0 混用、\n' +
            '   或 bundle 内 node_modules/.bin 链接）——本版已在 C/Kotlin/JS/打包四层消除；\n' +
            '② 入口为 ESM 却按 CommonJS 加载，导致 import.meta.main 判断不成立；\n' +
            '③ 上游自身启动异常（原文见 [raw:stderr]）。'
          );
        });
        req.on('timeout', () => req.destroy(new Error('timeout')));
      } catch (e) {
        bootlog('启动自检无法发起：' + (e && e.message || e));
      }
    }, 8000);

  } catch (e) {
    const msg = '启动 standalone 失败: ' + (e && e.stack || e);
    logError(msg);
    fatal(msg);
    originalError('[bootstrap] 启动失败，详情见 ofm-data/bootstrap.log');
  }
})();
