'use strict';
/**
 * OpenCode Console 网关（r3 key-only） · Node 侧启动入口
 * 由 nodejs-mobile 以 `node bootstrap.cjs` 执行（必须 .cjs：同目录 package.json
 * 若声明 type:module，.js 会被按 ESM 解析导致 require 不可用）。
 *
 * 本版不加载上游 standalone，直接 require('./oc-proxy.cjs')：
 *   · 端口 / host / 数据目录仍走 C 胶水 setenv 的 OFM_*；
 *   · 运行信息仍写 gateway-runtime.json，供 HealthProbe / MainActivity 读取；
 *   · /health、/v1/models、/v1/chat/completions、/ 管理页全部由 oc-proxy.cjs 提供；
 *   · 实际端口顺延后通过 onListening 回写，状态栏与 RikkaHub 交接照常可用。
 *
 * 保留原壳的日志体系（bootstrap.log / node-output.log / node-fatal.txt）与
 * 冒烟测试分支，方便沿用「运行时自检 / 冒烟测试」按钮排障。
 *
 * 注意：r3 为 key-only —— OpenCode Console/Go Key 不在这里、也不在 assets 里，
 * 由用户在管理页填写，落盘在 APP 私有目录 ofm-data/oc-config.json（0600）。
 * 没填 Key 时网关会直接报 400，不再尝试任何匿名免费通道。
 */

const fs = require('fs');
const path = require('path');
let ROOT = __dirname;

// 本机 API Key 沿用旧版默认值，避免用户已配好的 RikkaHub 需要重填。
// 需要更换时打开管理页改「本机 API Key」即可。
const DEFAULT_PROXY_KEY = 'Rikka-2026-CF-Proxy-Key-8f3b';

// ---------------------------------------------------------------- 参数
function parseArgs(argv) {
  const positive = (v, d) => {
    const n = parseInt(v || '', 10);
    return Number.isFinite(n) && n > 0 ? n : d;
  };
  const out = {
    port: positive(process.env.OFM_PORT, 18900),
    dataDir: process.env.OFM_DATA_DIR || '',
    host: process.env.OFM_HOST || '127.0.0.1',
    lanRelay: process.env.OFM_LAN_RELAY === '1'
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--') continue;
    if (a === '--port') out.port = positive(argv[++i], out.port);
    else if (a === '--data-dir') out.dataDir = argv[++i];
    else if (a === '--host') out.host = argv[++i];
    else if (a === '--lan-relay') out.lanRelay = true;
  }
  return out;
}

const opts = parseArgs(process.argv.slice(2));
const DATA_DIR = opts.dataDir || path.join(process.env.HOME || ROOT, '.our-free-model');
fs.mkdirSync(DATA_DIR, { recursive: true });

process.env.OFM_HOME = DATA_DIR;
process.env.OFM_HOST = opts.host;
process.env.OFM_PORT = String(opts.port);

const RUNTIME_FILE = path.join(DATA_DIR, 'gateway-runtime.json');
const ERROR_LOG = path.join(DATA_DIR, 'node-errors.log');
const OUTPUT_LOG = path.join(DATA_DIR, 'node-output.log');
const BOOT_LOG = path.join(DATA_DIR, 'bootstrap.log');
const FATAL_FILE = path.join(DATA_DIR, 'node-fatal.txt');
const SETTINGS_FILE = path.join(DATA_DIR, 'settings.json');

function bootlog(msg) {
  try { fs.appendFileSync(BOOT_LOG, '[bootstrap] ' + msg + '\n'); } catch (_) {}
}
function jsbeat(msg) {
  const line = '[bootstrap] ' + msg + '\n';
  try { fs.appendFileSync(OUTPUT_LOG, line); } catch (_) {}
  try { fs.appendFileSync(BOOT_LOG, line); } catch (_) {}
}
function logError(msg) {
  const line = '[' + new Date().toISOString() + '] ' + msg + '\n';
  try { fs.appendFileSync(ERROR_LOG, line); } catch (_) {}
  try { fs.appendFileSync(BOOT_LOG, line); } catch (_) {}
}
function fatal(msg) {
  bootlog('致命失败：' + msg);
  logError(msg);
  try { fs.writeFileSync(FATAL_FILE, msg); } catch (_) {}
}
jsbeat('JS 层已启动 pid=' + process.pid + ' node=' + process.version +
  ' cwd=' + process.cwd() + ' port=' + opts.port + ' OFM_HOME=' + DATA_DIR);

// ------------------------------------------------- 冒烟测试（沿用原壳按钮）
const SMOKE_FLAG = path.join(DATA_DIR, 'smoke.flag');
const SMOKE_RESULT = path.join(DATA_DIR, 'smoke-result.txt');
if (fs.existsSync(SMOKE_FLAG)) {
  const info = 'SMOKE_OK node=' + process.version + ' pid=' + process.pid +
    ' cwd=' + process.cwd() +
    ' icu=' + (process.config.variables.icu_small_icu === false ? 'full' : 'small/none') +
    ' intl=' + (typeof Intl === 'object' ? 'yes' : 'no');
  try { fs.writeFileSync(SMOKE_RESULT, info); } catch (_) {}
  jsbeat('SMOKE OK → ' + info);
  console.log('[bootstrap] ' + info);
  process.exit(0);
}

// Node 崩溃不能直接 exit()：在安卓里会连同宿主 App 一起被结束
process.on('uncaughtException', (e) => logError('uncaughtException: ' + (e && e.stack || e)));
process.on('unhandledRejection', (e) => logError('unhandledRejection: ' + (e && e.stack || e)));

// ------------------------------------------------- 运行信息回写
const runtime = {
  port: opts.port,
  requestedPort: opts.port,
  apiKey: '',
  manageUrl: '',
  host: opts.host,
  pid: process.pid,
  startedAt: new Date().toISOString()
};

function publish() {
  const tmp = RUNTIME_FILE + '.tmp';
  try {
    fs.writeFileSync(tmp, JSON.stringify(runtime, null, 2), { mode: 0o600 });
    fs.renameSync(tmp, RUNTIME_FILE);
  } catch (e) {
    logError('写 gateway-runtime.json 失败: ' + e.message);
  }
}

// 原壳从 settings.json 读 Key（readKey 轮询）。这里直接落一份，
// 让 HealthProbe 在第一次轮询就能拿到非空 apiKey，立刻置为 READY。
function ensureKeyFile(key) {
  try {
    fs.writeFileSync(SETTINGS_FILE, JSON.stringify({ forwardKey: key }, null, 2), { mode: 0o600 });
  } catch (e) {
    logError('写 settings.json 失败: ' + e.message);
  }
}
function readKey() {
  try {
    if (!fs.existsSync(SETTINGS_FILE)) return '';
    const o = JSON.parse(fs.readFileSync(SETTINGS_FILE, 'utf8'));
    for (const k of ['forwardKey', 'apiKey', 'localKey', 'key', 'token']) {
      if (typeof o[k] === 'string' && o[k].trim()) return o[k].trim();
    }
  } catch (_) {}
  return '';
}

ensureKeyFile(DEFAULT_PROXY_KEY);
runtime.apiKey = readKey() || DEFAULT_PROXY_KEY;
publish();

// ------------------------------------------------- stdout 镜像到诊断日志
const originalLog = console.log.bind(console);
const originalError = console.error.bind(console);
console.log = (...args) => {
  const s = args.map(String).join(' ');
  try { fs.appendFileSync(OUTPUT_LOG, '[js] ' + s + '\n'); } catch (_) {}
  try { fs.appendFileSync(BOOT_LOG, '[js] ' + s + '\n'); } catch (_) {}
  originalLog(...args);
};
console.error = (...args) => {
  const s = args.map(String).join(' ');
  try { fs.appendFileSync(OUTPUT_LOG, '[js:err] ' + s + '\n'); } catch (_) {}
  try { fs.appendFileSync(BOOT_LOG, '[js:err] ' + s + '\n'); } catch (_) {}
  originalError(...args);
};

// ------------------------------------------------- 启动 OpenCode 网关
(async function main() {
  try {
    // /data/data 与 /data/user/0 在安卓上常互为符号链接；统一 realpath，
    // 保证 require 路径与私有目录写法一致（原壳 r5 的兼容处理）。
    function realOr(p) { try { return fs.realpathSync.native(p); } catch (_) { return p; } }
    ROOT = realOr(ROOT);
    const REAL_DATA = realOr(DATA_DIR);
    try { process.chdir(ROOT); } catch (_) {}
    process.env.OFM_HOME = REAL_DATA;
    process.env.OFM_DATA_DIR = REAL_DATA;
    process.env.HOME = REAL_DATA;
    process.env.TMPDIR = realOr(process.env.TMPDIR || REAL_DATA);
    bootlog('路径规范化 ROOT=' + ROOT + ' | DATA=' + REAL_DATA);

    const proxyPath = path.join(ROOT, 'oc-proxy.cjs');
    if (!fs.existsSync(proxyPath)) {
      throw new Error('oc-proxy.cjs 缺失：请确认 assets/node 已包含该文件，且 APK 为改造版');
    }
    bootlog('加载 OpenCode 网关模块：' + proxyPath);
    const proxy = require(proxyPath);

    proxy.start({
      port: opts.port,
      host: opts.host,
      dataDir: REAL_DATA,
      log: (m) => bootlog('[oc-proxy] ' + m),
      onListening: (actualPort) => {
        runtime.port = actualPort;
        runtime.manageUrl = 'http://127.0.0.1:' + actualPort + '/';
        publish();
        jsbeat('OpenCode 网关已监听 port=' + actualPort + '，管理页 ' + runtime.manageUrl);
      },
      onKeyChanged: (newKey) => {
        // 管理页改了本机 Key：同步 settings.json，让主界面状态/二维码刷新后一致
        ensureKeyFile(newKey);
        runtime.apiKey = newKey;
        publish();
        bootlog('本机 API Key 已在管理页更新');
      },
      onFatal: (m) => fatal('OpenCode 网关监听失败：' + m)
    });

    // 8 秒后自检：确认 /health 真的能握手，失败就写 fatal 让界面立刻报错
    setTimeout(() => {
      try {
        const req = require('http').get(
          { host: opts.host, port: runtime.port, path: '/health', timeout: 1500 },
          (res) => { bootlog('启动自检：/health HTTP ' + res.statusCode + ' ✅'); res.resume(); }
        );
        req.on('error', (e) => fatal('入口已加载但 ' + runtime.port + ' 端口没有服务监听：' + e.message));
        req.on('timeout', () => req.destroy(new Error('timeout')));
      } catch (e) {
        bootlog('启动自检无法发起：' + (e && e.message || e));
      }
    }, 8000);

  } catch (e) {
    const msg = '启动 OpenCode 网关失败: ' + (e && e.stack || e);
    logError(msg);
    fatal(msg);
    originalError('[bootstrap] 启动失败，详情见 ofm-data/bootstrap.log');
  }
})();
