'use strict';
/**
 * 聚合网关 · Node 侧启动入口（由 libnode.so 以 `node bootstrap.cjs` 执行）
 *
 * ★ 必须是 .cjs：nodejs-mobile 的启动期错误走 logcat tag `nodejs`，
 *   若命名 .js 且同目录 package.json 带 "type":"module"，第一行 require
 *   会抛 ReferenceError 并让整进程 exit(1)，日志一片空白。
 *
 * B 方案改造后，这个入口不再 clone / 加载任何上游独立服务，只做四件事：
 *   1. 统一路径（realpath），把 OFM_* 环境变量对齐到无符号链接的真实前缀；
 *   2. 保留冒烟测试分支（主界面「Node 引擎冒烟测试」依赖 smoke-result.txt）；
 *   3. 把 stdout/stderr 镜像进 bootstrap.log / node-output.log 供界面诊断；
 *   4. require('./opencode-gateway.cjs') 启动本机网关。
 *
 * 不写 gateway-runtime.json：由网关自己写（含本地 Key 与实际端口），
 * 避免两个写者互相覆盖 HealthProbe 读到的快照。
 */

const fs = require('fs');
const path = require('path');

let ROOT = __dirname;
function realOr(p) { try { return fs.realpathSync.native(p); } catch (_) { return p; } }
ROOT = realOr(ROOT);

const DATA = realOr(process.env.OFM_DATA_DIR || process.env.OFM_HOME ||
  path.join(process.env.HOME || ROOT, '.our-free-model'));
try { fs.mkdirSync(DATA, { recursive: true }); } catch (_) {}

const F = {
  bootLog: path.join(DATA, 'bootstrap.log'),
  outLog: path.join(DATA, 'node-output.log'),
  errLog: path.join(DATA, 'node-errors.log'),
  fatal: path.join(DATA, 'node-fatal.txt'),
  smokeFlag: path.join(DATA, 'smoke.flag'),
  smokeResult: path.join(DATA, 'smoke-result.txt')
};

function append(file, line) { try { fs.appendFileSync(file, line + '\n'); } catch (_) {} }
function bootlog(m) { append(F.bootLog, '[bootstrap] ' + m); append(F.outLog, '[js] ' + m); }
function jsbeat(m) { bootlog(m); }
function logError(m) {
  const line = '[' + new Date().toISOString() + '] ' + m;
  append(F.errLog, line); append(F.bootLog, line); append(F.outLog, '[js:err] ' + line);
}
function fatal(m) {
  bootlog('致命失败：' + m);
  logError(m);
  try { fs.writeFileSync(F.fatal, m); } catch (_) {}
}

// 异常一律只记日志：Android 里 process.exit() 会连宿主 App 一起结束
process.on('uncaughtException', (e) => logError('uncaughtException: ' + (e && e.stack || e)));
process.on('unhandledRejection', (e) => logError('unhandledRejection: ' + (e && e.stack || e)));

jsbeat('JS 层已启动 pid=' + process.pid +
  ' node=' + process.version +
  ' cwd=' + process.cwd() +
  ' OFM_HOME=' + DATA);

// ------------------------------------------------- Node 引擎冒烟测试
// 只验证 V8 能初始化并执行 JS，不加载网关、不占端口、不联网。
if (fs.existsSync(F.smokeFlag)) {
  const info = 'SMOKE_OK node=' + process.version +
    ' pid=' + process.pid + ' cwd=' + process.cwd() +
    ' icu=' + (process.config.variables.icu_small_icu === false ? 'full' : 'small/none') +
    ' intl=' + (typeof Intl === 'object' ? 'yes' : 'no');
  try { fs.writeFileSync(F.smokeResult, info); } catch (_) {}
  jsbeat('SMOKE OK → ' + info);
  console.log('[bootstrap] ' + info);
  // 冒烟是有意结束，且 HealthProbe.awaitSmoke() 会把 pid 消失判为失败；
  // 因此先落盘 result 再退出，结果文件优先被读到。
  process.exit(0);
}

// ------------------------------------------------- 路径 / 环境变量规范化
// /data/data 常是 /data/user/0 的符号链接，统一到内核真实视角。
try {
  process.chdir(ROOT);
  process.env.OFM_HOME = DATA;
  process.env.OFM_DATA_DIR = DATA;
  process.env.HOME = DATA;
  process.env.TMPDIR = realOr(process.env.TMPDIR || DATA);
  const modules = path.join(ROOT, 'node_modules');
  if (fs.existsSync(modules)) process.env.NODE_PATH = modules;
  bootlog('路径规范化 ROOT=' + ROOT + ' | DATA=' + process.env.OFM_DATA_DIR + ' | cwd=' + process.cwd());
  bootlog('OFM_PORT=' + (process.env.OFM_PORT || '(默认 18900)') +
    ' | OFM_HOST=' + (process.env.OFM_HOST || '127.0.0.1') +
    ' | OFM_LAN_RELAY=' + (process.env.OFM_LAN_RELAY || '0'));
} catch (e) {
  logError('路径规范化失败（继续启动）：' + e.message);
}

// ------------------------------------------------- stdout/stderr 镜像
// nodejs-mobile 可能把 stdio 重新接管到 /dev/null；用 fs 直写保证界面能看到。
const originalLog = console.log.bind(console);
const originalError = console.error.bind(console);
console.log = (...args) => {
  const s = args.map(String).join(' ');
  append(F.outLog, '[js] ' + s); append(F.bootLog, '[js] ' + s);
  originalLog(...args);
};
console.error = (...args) => {
  const s = args.map(String).join(' ');
  append(F.outLog, '[js:err] ' + s); append(F.bootLog, '[js:err] ' + s);
  originalError(...args);
};
['stdout', 'stderr'].forEach((name) => {
  const stream = process[name];
  if (!stream || typeof stream.write !== 'function') return;
  const rawWrite = stream.write.bind(stream);
  stream.write = function (chunk) {
    try {
      const s = typeof chunk === 'string' ? chunk
        : (chunk && typeof chunk.toString === 'function' ? chunk.toString('utf8') : '');
      const t = s.replace(/\n+$/, '');
      if (t.trim()) append(F.bootLog, '[raw:' + name + '] ' + t);
    } catch (_) {}
    return rawWrite.apply(stream, arguments);
  };
});

// ------------------------------------------------- 启动本机网关
try {
  const entry = path.join(ROOT, 'opencode-gateway.cjs');
  if (!fs.existsSync(entry)) throw new Error('缺少 opencode-gateway.cjs：' + entry);
  bootlog('加载本地网关：' + entry);
  bootlog('上游目录端点：' + (process.env.ZEN_BASE_URL || 'https://opencode.ai/zen/v1') + '/models');
  require(entry);
  bootlog('opencode-gateway.cjs 已加载，等待 /health 握手');
} catch (e) {
  fatal('启动本地网关失败: ' + (e && e.stack || e));
  originalError('[bootstrap] 启动失败，详情见 ofm-data/bootstrap.log');
}
