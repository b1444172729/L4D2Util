'use strict';
/**
 * cf-proxy.cjs —— Cloudflare Workers AI → OpenAI 兼容本地网关
 *
 * 由 bootstrap.cjs 以 require('./cf-proxy.cjs') 加载，跑在 APP 自带的
 * nodejs-mobile (Node 22) 里，只监听 127.0.0.1，不依赖任何 npm 包。
 *
 * 对外路由（与CF网关原壳的 HealthProbe / RikkaHubHandoff 完全对齐）：
 *   GET  /health                → 200 JSON（探活，不鉴权）
 *   GET  /v1/models             → OpenAI 形状的模型清单（Bearer 鉴权）
 *   POST /v1/chat/completions   → 原样转发到 Workers AI（Bearer 鉴权，SSE 透传）
 *   GET  /                      → 极简管理页（可改账户 ID / 令牌 / 本机 Key）
 *   POST /config                → 保存配置到私有目录 cf-config.json
 *
 * 上游只走 api.cloudflare.com（HTTPS，Node 内置根证书），完全不涉及
 * *.workers.dev，因此在国内网络下也能用。
 */

const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');

// ------------------------------------------------------------------ 默认配置
// 按需求把账户 ID 与令牌直接内置，开箱即用。
// 轮换令牌后不必重编译：打开管理页 http://127.0.0.1:<端口>/ 改配置即可，
// 覆盖值写在 APP 私有目录 ofm-data/cf-config.json（权限 0600），优先级更高。
const DEFAULTS = {
  accountId: '57ba08afa07496728a02275fdaedd837',
  apiToken: 'cfut_olMiXaJrxXn4kNOwFo5ucg5k59BqZNJX4yBLO6im8e0a847f',
  proxyKey: 'Rikka-2026-CF-Proxy-Key-8f3b',
  includeDeprecated: false,
  hideKnownPaid: false
};

// 官方目录没有「免费档可用」标志；这些是实测需要 Workers Paid 的，默认只做标记不隐藏。
const KNOWN_PAID = new Set([
  '@cf/zai-org/glm-5.2',
  '@cf/zai-org/glm-5.3',
  '@cf/zai-org/glm-5.3-flash',
  '@cf/moonshotai/kimi-k2.6',
  '@cf/moonshotai/kimi-k2.7-code'
]);

const CF_HOST = 'api.cloudflare.com';
const MAX_BODY = 20 * 1024 * 1024;
const CACHE_MS = 60 * 60 * 1000;

let cfg = Object.assign({}, DEFAULTS);
let modelCache = null;
let modelCacheAt = 0;
let optsRef = {};

// ------------------------------------------------------------------ 配置读写
function loadConfig(dataDir) {
  const out = Object.assign({}, DEFAULTS);
  try {
    const f = path.join(dataDir, 'cf-config.json');
    if (fs.existsSync(f)) {
      const o = JSON.parse(fs.readFileSync(f, 'utf8'));
      for (const k of ['accountId', 'apiToken', 'proxyKey']) {
        if (typeof o[k] === 'string' && o[k].trim()) out[k] = o[k].trim();
      }
      for (const k of ['includeDeprecated', 'hideKnownPaid']) {
        if (typeof o[k] === 'boolean') out[k] = o[k];
      }
    }
  } catch (_) {}
  // 预留：将来 C 层若 setenv CF_*，环境变量优先级最高
  if (process.env.CF_ACCOUNT_ID) out.accountId = process.env.CF_ACCOUNT_ID.trim();
  if (process.env.CF_API_TOKEN) out.apiToken = process.env.CF_API_TOKEN.trim();
  if (process.env.CF_PROXY_KEY) out.proxyKey = process.env.CF_PROXY_KEY.trim();
  return out;
}

function saveConfig(dataDir, next) {
  const f = path.join(dataDir, 'cf-config.json');
  const tmp = f + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(next, null, 2), { mode: 0o600 });
  fs.renameSync(tmp, f);
  cfg = Object.assign({}, cfg, next);
  modelCache = null;
  modelCacheAt = 0;
}

function mask(s) {
  if (!s) return '(未设置)';
  if (s.length <= 10) return '****';
  return s.slice(0, 5) + '****' + s.slice(-4);
}

// ------------------------------------------------------------------ 上游请求
function cfJson(method, pathname) {
  return new Promise((resolve, reject) => {
    const req = https.request({
      host: CF_HOST, port: 443, method, path: pathname,
      headers: {
        Authorization: 'Bearer ' + cfg.apiToken,
        Accept: 'application/json'
      },
      timeout: 30000
    }, (res) => {
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => {
        const raw = Buffer.concat(chunks).toString('utf8');
        let j = null;
        try { j = JSON.parse(raw); } catch (_) {}
        resolve({ status: res.statusCode, json: j, raw });
      });
    });
    req.on('timeout', () => req.destroy(new Error('upstream timeout')));
    req.on('error', reject);
    req.end();
  });
}

function cfStream(pathname, body) {
  return new Promise((resolve, reject) => {
    const req = https.request({
      host: CF_HOST, port: 443, method: 'POST', path: pathname,
      headers: {
        Authorization: 'Bearer ' + cfg.apiToken,
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(body)
      },
      timeout: 120000
    }, resolve);
    req.on('timeout', () => req.destroy(new Error('upstream timeout')));
    req.on('error', reject);
    req.end(body);
  });
}

// ------------------------------------------------------------------ 模型清单
function deprecatingSoon(m, now) {
  const p = (m.properties || []).find((x) => x.property_id === 'planned_deprecation_date');
  if (!p) return false;
  const t = Date.parse(String(p.value));
  return Number.isFinite(t) && t <= now + 30 * 86400 * 1000;
}

async function listModels(force) {
  if (!force && modelCache && Date.now() - modelCacheAt < CACHE_MS) return modelCache;

  const base = '/client/v4/accounts/' + encodeURIComponent(cfg.accountId) + '/ai/models/search';
  const all = [];
  let page = 1, pages = 1;
  while (page <= pages && page <= 10) {
    const r = await cfJson('GET', base + '?per_page=1000&page=' + page);
    if (!r.json || !r.json.success) {
      throw new Error('models/search HTTP ' + r.status + '：' +
        JSON.stringify((r.json && r.json.errors) || r.raw.slice(0, 300)));
    }
    all.push(...(r.json.result || []));
    pages = (r.json.result_info && r.json.result_info.total_pages) || 1;
    page++;
  }

  const now = Date.now();
  const data = all
    .filter((m) => m.task && m.task.name === 'Text Generation')
    .filter((m) => cfg.includeDeprecated || !deprecatingSoon(m, now))
    .filter((m) => !(cfg.hideKnownPaid && KNOWN_PAID.has(m.name)))
    .map((m) => {
      const p = Object.fromEntries((m.properties || []).map((x) => [x.property_id, x.value]));
      const t = Date.parse(String(m.created_at || '').replace(' ', 'T') + 'Z');
      return {
        id: m.name,
        object: 'model',
        created: Number.isFinite(t) ? Math.floor(t / 1000) : 0,
        owned_by: 'cloudflare',
        name: pretty(m.name),
        metadata: {
          task: m.task.name,
          context_window: p.context_window ?? null,
          function_calling: truthy(p.function_calling),
          reasoning: truthy(p.reasoning),
          planned_deprecation_date: p.planned_deprecation_date ?? null,
          paid_hint: KNOWN_PAID.has(m.name)
        }
      };
    });

  modelCache = { object: 'list', data: data, total: data.length };
  modelCacheAt = Date.now();
  if (optsRef.log) optsRef.log('模型清单已刷新：' + data.length + ' 个 Text Generation 模型');
  return modelCache;
}

function truthy(v) { return v === true || String(v).toLowerCase() === 'true'; }
function pretty(id) {
  const s = String(id).split('/').pop() || id;
  return s.replace(/-/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
}

// ------------------------------------------------------------------ HTTP 工具
function sendJson(res, status, obj, extra) {
  const body = JSON.stringify(obj);
  res.writeHead(status, Object.assign({
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
  }, extra || {}));
  res.end(status === 204 ? undefined : body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (c) => {
      size += c.length;
      if (size > MAX_BODY) { reject(new Error('body too large')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

function authorized(req) {
  const a = req.headers.authorization || '';
  return cfg.proxyKey === '' || a === 'Bearer ' + cfg.proxyKey;
}

// ------------------------------------------------------------------ 管理页
function managePage(port) {
  return `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Cloudflare Workers AI 本地网关</title>
<style>
body{background:#0f1220;color:#e8ecff;font:15px/1.6 system-ui,sans-serif;padding:18px;max-width:720px;margin:auto}
h1{font-size:20px;color:#8ad8ff} .card{background:#1b2140;border-radius:14px;padding:16px;margin:14px 0}
code{color:#9ae6b4} label{display:block;margin:10px 0 4px;color:#b9c3ff;font-size:13px}
input{width:100%;box-sizing:border-box;background:#0d1024;color:#fff;border:1px solid #39406e;border-radius:8px;padding:10px;font-size:14px}
button{background:linear-gradient(90deg,#22d3ee,#8b5cf6);color:#fff;border:0;border-radius:10px;padding:11px 20px;font-size:15px;margin-top:12px;cursor:pointer}
a{color:#8ad8ff} .muted{color:#8b93bd;font-size:13px}
</style></head><body>
<h1>☁️ Cloudflare Workers AI 本地网关</h1>
<div class="card">
  <div>状态：<code style="color:#9ae6b4">运行中</code> · 端口 <code>${port}</code></div>
  <div>RikkaHub Base URL：<code>http://127.0.0.1:${port}/v1</code></div>
  <div>账户 ID：<code>${mask(cfg.accountId)}</code> · API 令牌：<code>${mask(cfg.apiToken)}</code></div>
  <div>本机 API Key：<code>${mask(cfg.proxyKey)}</code></div>
  <div class="muted">模型缓存：${modelCache ? modelCache.data.length + ' 个' : '未加载'} ·
    <a href="/v1/models?refresh=1">刷新模型清单</a></div>
</div>
<div class="card">
  <h1 style="font-size:16px">修改配置（令牌轮换后在这里改，无需重新编译 APK）</h1>
  <form method="POST" action="/config">
    <label>Cloudflare 账户 ID（32 位十六进制，当前 ${escapeHtml(mask(cfg.accountId))}）</label>
    <input name="accountId" value="" placeholder="留空 = 不修改">
    <label>Cloudflare API 令牌（cfut_...）</label>
    <input name="apiToken" type="password" placeholder="留空 = 不修改">
    <label>RikkaHub 用的本机 API Key</label>
    <input name="proxyKey" type="password" placeholder="留空 = 不修改">
    <button type="submit">保存并清空模型缓存</button>
  </form>
  <div class="muted">保存后若改了 API Key，请回主界面「停止网关 → 启动网关」，让状态栏与二维码更新。</div>
</div>
<div class="card muted">
  上游：<code>api.cloudflare.com</code>（HTTPS，不经过 workers.dev）<br>
  模型只列 Text Generation，并自动隐藏 30 天内计划弃用的；付费档模型在 /v1/models 的 metadata.paid_hint 里标注。<br>
  本页仅回环可访问；网关停止后页面也随之关闭。
</div></body></html>`;
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

// ------------------------------------------------------------------ 主服务
function start(opts) {
  optsRef = opts || {};
  const dataDir = optsRef.dataDir || process.cwd();
  cfg = loadConfig(dataDir);

  const server = http.createServer(async (req, res) => {
    try {
      const u = new URL(req.url, 'http://' + (req.headers.host || '127.0.0.1'));
      const p = u.pathname.replace(/\/+$/, '') || '/';

      if (req.method === 'OPTIONS') return sendJson(res, 204, {});

      // 探活：HealthProbe.pingHealth() 不带 Authorization，必须放行
      if (req.method === 'GET' && p === '/health') {
        return sendJson(res, 200, {
          ok: true,
          service: 'cf-ai-gateway',
          accountId: mask(cfg.accountId),
          models: modelCache ? modelCache.data.length : 0,
          upstream: CF_HOST
        });
      }

      // 管理页：只对回环开放
      if (req.method === 'GET' && (p === '/' || p === '/index.html')) {
        const body = managePage(server.address() ? server.address().port : optsRef.port);
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Content-Length': Buffer.byteLength(body) });
        return res.end(body);
      }

      if (req.method === 'POST' && p === '/config') {
        const raw = (await readBody(req)).toString('utf8');
        let next = {};
        if (raw.trim().startsWith('{')) {
          next = JSON.parse(raw);
        } else {
          const params = new URLSearchParams(raw);
          next = {
            accountId: (params.get('accountId') || '').trim(),
            apiToken: (params.get('apiToken') || '').trim(),
            proxyKey: (params.get('proxyKey') || '').trim()
          };
        }
        const merged = Object.assign({}, cfg);
        // 管理页里掩码占位不算新值；留空也表示不修改
        for (const k of ['accountId', 'apiToken', 'proxyKey']) {
          const v = next[k];
          if (typeof v === 'string' && v && !v.includes('****')) merged[k] = v;
        }
        saveConfig(dataDir, merged);
        if (optsRef.onKeyChanged) optsRef.onKeyChanged(cfg.proxyKey);
        if (optsRef.log) optsRef.log('配置已更新：account=' + mask(cfg.accountId) + ' key=' + mask(cfg.proxyKey));
        res.writeHead(303, { Location: '/' });
        return res.end();
      }

      // 以下路由都要鉴权
      if (!authorized(req)) return sendJson(res, 401, { error: 'unauthorized' });

      if (req.method === 'GET' && (p === '/v1/models' || p === '/models')) {
        const list = await listModels(u.searchParams.get('refresh') === '1');
        return sendJson(res, 200, list);
      }

      if (req.method === 'POST' && (p === '/v1/chat/completions' || p === '/chat/completions')) {
        const body = await readBody(req);
        const up = '/client/v4/accounts/' + encodeURIComponent(cfg.accountId) + '/ai/v1/chat/completions';
        const upstream = await cfStream(up, body);
        res.writeHead(upstream.statusCode, {
          'Content-Type': upstream.headers['content-type'] || 'application/json; charset=utf-8',
          'Cache-Control': 'no-cache',
          'Access-Control-Allow-Origin': '*'
        });
        // 直接 pipe：stream:true 的 SSE 逐帧透传，不缓冲、不改写
        return upstream.pipe(res);
      }

      return sendJson(res, 404, {
        error: 'not_found',
        routes: ['GET /health', 'GET /v1/models', 'POST /v1/chat/completions', 'GET /']
      });
    } catch (e) {
      if (optsRef.log) optsRef.log('请求异常 ' + req.method + ' ' + req.url + '：' + (e && e.message || e));
      if (!res.headersSent) {
        return sendJson(res, 502, { error: 'proxy_error', message: String((e && e.message) || e) });
      }
      try { res.end(); } catch (_) {}
    }
  });

  // 端口被占用时顺延，实际端口通过 onListening 回写给安卓壳
  let port = Number(optsRef.port) || 18900;
  // 固定回环：管理页 /config 不鉴权（同源表单），开 LAN 中继会把它暴露到局域网。
  // 本版只服务本机 RikkaHub，因此忽略 OFM_HOST，原壳的「局域网中继」开关不生效。
  const host = '127.0.0.1';
  let tries = 0;
  server.on('error', (e) => {
    if (e.code === 'EADDRINUSE' && tries++ < 12) {
      port += 1;
      if (optsRef.log) optsRef.log('端口被占用，顺延到 ' + port);
      setTimeout(() => server.listen(port, host), 200);
    } else {
      if (optsRef.log) optsRef.log('监听失败：' + (e && e.message || e));
      if (optsRef.onFatal) optsRef.onFatal(String(e && e.message || e));
    }
  });
  server.listen(port, host, () => {
    const actual = server.address().port;
    if (optsRef.log) optsRef.log('CF 网关已监听 http://' + host + ':' + actual + '/v1');
    if (optsRef.onListening) optsRef.onListening(actual);
  });
  return server;
}

module.exports = { start: start, listModels: listModels, config: () => cfg };
