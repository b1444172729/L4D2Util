'use strict';
/**
 * oc-proxy.cjs —— OpenCode Console / Go → OpenAI 兼容本地网关
 *                  Android 版 / r3「key-only」
 *
 * 由 bootstrap.cjs 以 require('./oc-proxy.cjs') 加载，跑在 APP 自带的
 * nodejs-mobile (Node 22) 里，只监听 127.0.0.1，零 npm 依赖。
 *
 * ══════════════════════════════════════════════════════════════════
 * r3 的设计前提（用户指令：以后修改一律使用 key）
 *   · 彻底删除免费层：没有匿名凭据、没有 UA 伪造、没有 TLS cipher
 *     调优、没有 <environment> 块、没有 tools 注入、没有 auto 降级。
 *   · 每一次上游请求都必须带用户在管理页填的 Console / Go API Key；
 *     没填就直接报错，绝不静默退回匿名免费通道。
 *   · 走官方公开端点，诚实 UA，稳定 x-opencode-session。
 *
 * ⚠️ 必须知道：带 key 也调不了 -free 模型。官方原话：
 *    "Free-tier chat models are only available from within OpenCode.
 *     Other harnesses receive HTTP 403 for those models, even with a
 *     Console API key."  免费层不是公开 API，key 只能开付费/Go 的门。
 *    因此 Console 模式下模型清单会自动过滤 -free ID。
 *
 * 两层 Key 别混：
 *   · Console/Go Key：管理页填，网关拿它请求 opencode.ai，不进二维码。
 *   · 本机 Key：RikkaHub 填，只用于校验本机网关，沿用旧默认值。
 * ══════════════════════════════════════════════════════════════════
 *
 * 对外路由：
 *   GET  /health                → 200 JSON（探活，不鉴权）
 *   GET  /selftest              → 用当前 key 发最小请求，验 key / 余额 / 端点
 *   GET  /v1/models             → OpenAI 形状的模型清单（Bearer 本机 Key）
 *   POST /v1/chat/completions   → 转发到 opencode.ai（Bearer 本机 Key）
 *   GET  /                      → 管理页
 *   POST /config                → 保存到私有目录 oc-config.json（0600）
 */

const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// ------------------------------------------------------------------ 默认配置
// APP 的 assets 不加密：这里不内置任何第三方真实凭据。
// Console / Go Key 一律由用户在管理页填写，落盘到私有目录。
const DEFAULTS = {
    consoleKey: '',                       // 必填：Console 创建的 API Key
    proxyKey: 'Rikka-2026-CF-Proxy-Key-8f3b',
    plan: 'console',                      // console（按量）| go（订阅）
    upstream: 'opencode.ai',              // 只填 host，固定 https:443
    consolePath: '/inference/openai/v1/chat/completions',
    goPath: '/inference/go/openai/v1/chat/completions',
    modelsPath: '/inference/openai/v1/models',
    // 官方要求第三方 harness「带自己的 UA，别伪装成 SDK 默认名」，诚实标识。
    ua: 'RikkaHub-OpenCode-Gateway/3.0',
    sidStyle: 'desc',                     // desc | random
    hideFreeModels: true,                 // Console 模式过滤 -free（带 key 也 403）
    customModels: '',                     // 每行一个模型 ID，覆盖内置/上游清单
    extraHeaders: ''                      // JSON 对象，追加/覆盖请求头
};

const MAX_BODY = 20 * 1024 * 1024;
const CACHE_MS = 30 * 60 * 1000;
const SESSION_TTL = 30 * 60 * 1000;

// 内置付费/Go 模型兜底清单。联网时 /v1/models 会优先取上游带 key 的真实清单。
// 注意：官方每个模型归一个 API family，但 Console 端点会自动做协议转换，
// 所以 Chat Completions 形状下所有文本模型都能用（Harnesses 文档）。
const BUILTIN_MODELS = [
    ['glm-5.3-flash', 'GLM-5.3-Flash', '低价 / 中文强'],
    ['glm-5.3', 'GLM-5.3', '通用'],
    ['glm-5.2', 'GLM-5.2', '通用'],
    ['deepseek-v4.1-flash', 'DeepSeek V4.1 Flash', '按量最便宜之一'],
    ['kimi-k3', 'Kimi K3', '长上下文'],
    ['kimi-k3.1-pro', 'Kimi K3.1 Pro', '长上下文 / 进阶'],
    ['kimi-k2.7-code', 'Kimi K2.7 Code', '编程'],
    ['minimax-m3.1-flash', 'MiniMax M3.1 Flash', '低价'],
    ['mimo-v2.6-flash', 'MiMo-V2.6-Flash', '低价'],
    ['mimo-v2.6-pro', 'MiMo-V2.6-Pro', '进阶'],
    ['longcat-2.0', 'LongCat-2.0', '通用'],
    ['step-5-preview', 'Step 5 Preview', '预览'],
    ['claude-haiku-5.5', 'Claude Haiku 5.5', '轻量'],
    ['claude-sonnet-5-5', 'Claude Sonnet 5.5', '进阶（原价较高）'],
    ['gemini-4-argon', 'Gemini 4 Argon', '通用'],
    ['grok-4.7', 'Grok 4.7', '通用'],
    ['gpt-6.1-sol', 'GPT 6.1 Sol', '通用'],
    ['gpt-6-luna', 'GPT 6 Luna', '轻量'],
    ['gpt-5.6-luna', 'GPT 5.6 Luna', '轻量']
];

let cfg = Object.assign({}, DEFAULTS);
let modelCache = null;
let modelCacheAt = 0;
let optsRef = {};
const sessionCache = new Map();
let sidCounter = 0;

// ------------------------------------------------------------------ 配置读写
function loadConfig(dataDir) {
    const out = Object.assign({}, DEFAULTS);
    try {
        const f = path.join(dataDir, 'oc-config.json');
        if (fs.existsSync(f)) {
            const o = JSON.parse(fs.readFileSync(f, 'utf8'));
            for (const k of Object.keys(DEFAULTS)) {
                const v = o[k];
                const def = DEFAULTS[k];
                if (typeof def === 'boolean') {
                    if (typeof v === 'boolean') out[k] = v;
                    else if (v === '1' || v === 1 || v === '0' || v === 0) out[k] = (v === true || v === 1 || v === '1');
                } else if (typeof v === 'string') {
                    out[k] = v;
                }
            }
            // r1/r2 的旧配置里若存过 mode，统一忽略：r3 只有 plan。
        }
    } catch (_) {}
    const envMap = {
        OC_CONSOLE_KEY: 'consoleKey', OC_PROXY_KEY: 'proxyKey', OC_PLAN: 'plan',
        OC_UPSTREAM: 'upstream', OC_CONSOLE_PATH: 'consolePath', OC_GO_PATH: 'goPath',
        OC_UA: 'ua'
    };
    for (const [e, k] of Object.entries(envMap)) {
        if (process.env[e] && process.env[e].trim()) out[k] = process.env[e].trim();
    }
    return out;
}

function saveConfig(dataDir, next) {
    const f = path.join(dataDir, 'oc-config.json');
    const tmp = f + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(next, null, 2), { mode: 0o600 });
    try { fs.chmodSync(tmp, 0o600); } catch (_) {}
    fs.renameSync(tmp, f);
    try { fs.chmodSync(f, 0o600); } catch (_) {}
    cfg = Object.assign({}, cfg, next);
    modelCache = null;
    modelCacheAt = 0;
}

function mask(s) {
    if (!s) return '(未设置)';
    if (s.length <= 10) return '****';
    return s.slice(0, 5) + '****' + s.slice(-4);
}

function parseBool(v, fallback) {
    if (v === '1' || v === 1 || v === true || v === 'true') return true;
    if (v === '0' || v === 0 || v === false || v === 'false') return false;
    return fallback;
}

// ------------------------------------------------------------------ 小工具
function stripPrefix(id) {
    return String(id || '').trim()
        .replace(/^opencode-go\//i, '')
        .replace(/^opencode\//i, '');
}

function pretty(id) {
    const s = stripPrefix(id).split('/').pop() || id;
    return s.replace(/[-_]/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
}

function safeJson(raw) {
    try { return JSON.parse(raw); } catch (_) { return null; }
}

function extraHeaders() {
    if (!cfg.extraHeaders.trim()) return {};
    try {
        const o = JSON.parse(cfg.extraHeaders);
        return (o && typeof o === 'object' && !Array.isArray(o)) ? o : {};
    } catch (_) { return {}; }
}

/** 当前生效的上游 chat 路径。plan 是唯一决定因素，不再有任何免费层路径。 */
function chatPath() {
    return cfg.plan === 'go' ? cfg.goPath : cfg.consolePath;
}

function modelsPath() {
    // Go 端点同样支持 OpenAI 兼容的 /v1/models；若用户没改过默认路径就自动映射。
    if (cfg.plan === 'go' && cfg.modelsPath === DEFAULTS.modelsPath) {
        return cfg.modelsPath.replace('/inference/openai/', '/inference/go/openai/');
    }
    return cfg.modelsPath;
}

// ------------------------------------------------------------------ session 头
const B62 = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';

function randomTail(n) {
    let s = '';
    for (let i = 0; i < n; i++) s += B62[crypto.randomInt(0, 62)];
    return s;
}

function newSessionId() {
    const c = sidCounter++ & 63;
    const m = (1n << 48n) - 1n;
    let head;
    if (cfg.sidStyle === 'random') {
        head = crypto.randomBytes(6).toString('hex');
    } else {
        const raw = (BigInt(Date.now()) * 4096n + BigInt(0xfff - c)) & m;
        head = (~raw & m).toString(16).padStart(12, '0');
    }
    return 'ses_' + head + randomTail(cfg.sidStyle === 'random' ? 16 : 14);
}

/** 同一段对话复用同一个 session ID：Go 强制要求，也利于 Console 复用 prompt cache。 */
function sessionFor(body) {
    const msgs = Array.isArray(body.messages) ? body.messages : [];
    const first = msgs.find((m) => m && m.role === 'user');
    const seed = JSON.stringify(first && first.content != null ? first.content : '') + '|' + stripPrefix(body.model || '');
    const key = crypto.createHash('sha1').update(seed).digest('hex');
    const now = Date.now();
    const hit = sessionCache.get(key);
    if (hit && now - hit.at < SESSION_TTL) return hit.id;
    const id = newSessionId();
    sessionCache.set(key, { id: id, at: now });
    if (sessionCache.size > 256) {
        for (const [k, v] of sessionCache) {
            if (now - v.at > SESSION_TTL) sessionCache.delete(k);
        }
    }
    return id;
}

// ------------------------------------------------------------------ 上游请求
function upstreamRequest(method, pathname, headers, body, timeoutMs) {
    return new Promise((resolve, reject) => {
        const req = https.request({
            host: cfg.upstream,
            port: 443,
            method: method,
            path: pathname,
            headers: headers,
            timeout: timeoutMs || 120000
        }, resolve);
        req.on('timeout', () => req.destroy(new Error('upstream timeout')));
        req.on('error', reject);
        if (body) req.end(body); else req.end();
    });
}

function upstreamGet(pathname, headers) {
    return new Promise((resolve) => {
        upstreamRequest('GET', pathname, headers, null, 8000)
            .then(async (res) => resolve({ status: res.statusCode, raw: await collect(res) }))
            .catch(() => resolve({ status: 0, raw: '' }));
    });
}

function collect(res) {
    return new Promise((resolve, reject) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
        res.on('error', reject);
    });
}

/** 唯一的请求头构造：必须带 key，诚实 UA，稳定 session。没有任何指纹伪造。 */
function authHeaders(bodyLen, sid) {
    const h = {
        'Content-Type': 'application/json',
        'Content-Length': bodyLen,
        'Accept': 'text/event-stream, application/json',
        'User-Agent': cfg.ua || DEFAULTS.ua,
        'x-opencode-session': sid,
        'x-opencode-session-id': sid,
        'x-session-id': sid,
        'x-session-affinity': sid,
        'Authorization': 'Bearer ' + cfg.consoleKey
    };
    return Object.assign(h, extraHeaders());
}

// ------------------------------------------------------------------ 模型清单
function builtinModels() {
    return BUILTIN_MODELS.map(([id, name, note]) => ({
        id: id,
        object: 'model',
        created: 0,
        owned_by: 'opencode',
        name: name,
        metadata: { plan: cfg.plan, note: note, source: 'builtin' }
    }));
}

function parseCustomModels(text) {
    return text.split(/\r?\n/)
        .map((s) => s.trim())
        .filter((s) => s && !s.startsWith('#'))
        .map((id) => ({
            id: stripPrefix(id),
            object: 'model',
            created: 0,
            owned_by: 'opencode',
            name: pretty(id),
            metadata: { plan: cfg.plan, note: '管理页自定义', source: 'custom' }
        }));
}

// 少数免费位不带 -free 后缀（big-pickle 等），带 Console Key 调它同样 403。
const KNOWN_FREE_IDS = new Set(['big-pickle', 'bigpickle', 'space-bunny']);
function isFreeId(id) {
    const s = String(id).toLowerCase();
    return /-free$/.test(s) || KNOWN_FREE_IDS.has(s);
}

async function fetchUpstreamModels() {
    if (!cfg.consoleKey) return null;           // key-only：没 key 就不请求上游
    const headers = authHeaders(0, newSessionId());
    delete headers['Content-Length'];
    const r = await upstreamGet(modelsPath(), headers);
    if (r.status !== 200) {
        if (optsRef.log) optsRef.log('上游 /models HTTP ' + r.status + '（将用内置清单兜底）');
        return null;
    }
    const j = safeJson(r.raw);
    const arr = j && (Array.isArray(j.data) ? j.data : (Array.isArray(j) ? j : null));
    if (!arr || !arr.length) return null;
    const out = arr.map((m) => {
        const id = stripPrefix(m.id || m.name || '');
        if (!id) return null;
        return {
            id: id,
            object: 'model',
            created: Number(m.created) || 0,
            owned_by: 'opencode',
            name: m.name || pretty(id),
            metadata: {
                plan: cfg.plan,
                free: isFreeId(id),
                note: isFreeId(id) ? '免费位：Console 按量端点带 key 也 403，请改用付费 ID' : '来自上游 ' + modelsPath(),
                source: 'upstream'
            }
        };
    }).filter(Boolean);
    return out.length ? out : null;
}

async function listModels(force) {
    if (!force && modelCache && Date.now() - modelCacheAt < CACHE_MS) return modelCache;
    let data;
    if (cfg.customModels.trim()) {
        data = parseCustomModels(cfg.customModels);
    } else {
        data = await fetchUpstreamModels();
        if (!data || !data.length) data = builtinModels();
    }
    // Console 按量默认隐藏 -free：带 key 也 403，留在清单里只会让人反复踩坑。
    // Go 计划内含 Beam Free / Iceman Contributor Free 等限时位，保留供尝试。
    if (cfg.hideFreeModels && cfg.plan === 'console') {
        data = data.filter((m) => !isFreeId(m.id));
    }
    modelCache = { object: 'list', data: data, total: data.length };
    modelCacheAt = Date.now();
    if (optsRef.log) optsRef.log('模型清单已刷新：' + data.length + ' 个（来源 ' + (data[0] && data[0].metadata.source || 'custom') + ' / plan=' + cfg.plan + '）');
    return modelCache;
}

// ------------------------------------------------------------------ 请求体
function buildBody(clientBody) {
    const up = Object.assign({}, clientBody);
    up.model = stripPrefix(up.model || '');
    // 不再强制 stream、不再注入 tools、不再注入 system 提示词。
    // 完全尊重 RikkaHub 发来的形状，由官方 Console 做协议转换。
    return JSON.stringify(up);
}

// ------------------------------------------------------------------ 响应适配
function aggregateSse(raw, model) {
    let content = '';
    let reasoning = '';
    let usage = null;
    let finish = 'stop';
    let id = 'chatcmpl-' + crypto.randomBytes(8).toString('hex');
    for (const line of String(raw).split(/\r?\n/)) {
        if (!line.startsWith('data:')) continue;
        const data = line.slice(5).trim();
        if (!data || data === '[DONE]') continue;
        const o = safeJson(data);
        if (!o) continue;
        if (o.id) id = o.id;
        if (o.usage) usage = o.usage;
        const ch = o.choices && o.choices[0];
        if (!ch) continue;
        if (ch.finish_reason) finish = ch.finish_reason;
        const d = ch.delta || ch.message || {};
        if (typeof d.content === 'string') content += d.content;
        else if (Array.isArray(d.content)) {
            for (const part of d.content) {
                if (part && typeof part.text === 'string') content += part.text;
            }
        }
        if (typeof d.reasoning_content === 'string') reasoning += d.reasoning_content;
        else if (typeof d.reasoning === 'string') reasoning += d.reasoning;
    }
    const message = { role: 'assistant', content: content };
    if (reasoning) message.reasoning_content = reasoning;
    return {
        id: id,
        object: 'chat.completion',
        created: Math.floor(Date.now() / 1000),
        model: model,
        choices: [{ index: 0, message: message, finish_reason: finish }],
        usage: usage || { prompt_tokens: 0, completion_tokens: 0, total_tokens: 0 }
    };
}

function sendSse(res, status, obj) {
    res.writeHead(status, {
        'Content-Type': 'text/event-stream; charset=utf-8',
        'Cache-Control': 'no-cache, no-transform',
        'Connection': 'keep-alive',
        'X-Accel-Buffering': 'no',
        'Access-Control-Allow-Origin': '*'
    });
    res.write('data: ' + JSON.stringify(obj) + '\n\n');
    res.write('data: [DONE]\n\n');
    res.end();
}

async function relay(res, upRes, wantsStream, model) {
    const ct = upRes.headers['content-type'] || '';
    const isSse = /text\/event-stream/i.test(ct);
    if (wantsStream && isSse) {
        res.writeHead(upRes.statusCode, {
            'Content-Type': 'text/event-stream; charset=utf-8',
            'Cache-Control': 'no-cache, no-transform',
            'Connection': 'keep-alive',
            'X-Accel-Buffering': 'no',
            'Access-Control-Allow-Origin': '*'
        });
        return upRes.pipe(res);
    }
    const raw = await collect(upRes);
    if (wantsStream && !isSse) {
        const obj = safeJson(raw) || { error: { message: 'upstream returned non-JSON: ' + raw.slice(0, 200) } };
        return sendSse(res, upRes.statusCode, obj);
    }
    if (!wantsStream && isSse) {
        return sendJson(res, upRes.statusCode, aggregateSse(raw, model));
    }
    res.writeHead(upRes.statusCode, {
        'Content-Type': ct || 'application/json; charset=utf-8',
        'Content-Length': Buffer.byteLength(raw),
        'Access-Control-Allow-Origin': '*'
    });
    return res.end(raw);
}

/**
 * 把上游错误翻译成能直接照做的中文提示，并保留原文。
 * 免费层那套「429 不是额度用完」的解释在 r3 里已无意义——这里全是真·计费错误。
 */
function humanError(status, raw) {
    const s = String(raw || '');
    if (status === 401 || /invalid credential|api_key_expired|invalid api key/i.test(s)) {
        return '【401 Key 无效或已过期】去 opencode.ai/console → Account → Personal API keys 重建一把，' +
            '粘回管理页保存。旧 key 在 Console 迁移后有一批集中失效过。';
    }
    if (status === 402 || /insufficient (account )?funds|insufficient balance|insufficient credits/i.test(s)) {
        return '【402 余额不足】新账户默认余额 $0，创建 Key 不等于充值。' +
            '去 Console → Settings › Billing › Add credits 充值（$10 起，另加 4.6% + $0.31 手续费，支持支付宝/微信），' +
            '或订阅 Go（$10/月）后把「计费方案」切到 go。余额归零时所有付费请求统一回 402，不会变负。';
    }
    if (status === 403 && /freetiererror|free tier|free-tier/i.test(s)) {
        return '【403 免费模型策略拒绝】官方规定：免费模型只对 OpenCode 客户端开放，' +
            '其它客户端即使带 Console API Key 也 403。请把模型 ID 换成付费版（去掉 -free 后缀，' +
            '例如 glm-5.3-flash-free → glm-5.3-flash），或订阅 Go 后走 /inference/go/… 端点。';
    }
    if (status === 403 && /abusive traffic/i.test(s)) {
        return '【403 IP 风控】当前出口 IP 被判定异常（共享 NAT / VPN / 代理常见）。关掉代理、换蜂窝网络再试；' +
            '这与 Key 和余额无关，只有官方能解封。';
    }
    if (status === 403) {
        return '【403 被拒】检查 Key 权限、Workspace 隐私里的 Regions 设置（默认只放行 EU/US，可改 Global），' +
            '以及模型是否对你的账号可用。';
    }
    if (status === 429) {
        return '【429 限流】按量或 Go 的速率/额度触顶。稍后重试；Go 用户可在 Console 开 Extra Usage 用余额续量。';
    }
    if (/ModelProtocolUnsupported/i.test(s)) {
        return '【400 协议不匹配】该模型归别的 API family（GPT 走 Responses、Claude/Qwen 走 Messages）。' +
            'Console 通常会自动转换，若仍报这个错，换一个 Chat Completions 系模型（如 glm-5.3-flash）。';
    }
    if (status === 404) {
        return '【404 模型不存在】这个 ID 已下架或写错。管理页点「刷新模型清单」拿当前可用 ID。';
    }
    return '【上游 HTTP ' + status + '】请求未成功，详见下方上游原文。';
}

function sendUpstreamError(res, status, raw) {
    const j = safeJson(raw);
    const orig = (j && (j.error && (j.error.message || (j.error.error && j.error.error.message)) || j.message)) || String(raw || '').slice(0, 500);
    const body = JSON.stringify({
        error: {
            type: 'opencode_upstream_error',
            message: humanError(status, raw) + '\n上游原文：' + orig,
            upstream_status: status,
            upstream_raw: j || String(raw || '').slice(0, 1200)
        }
    });
    res.writeHead(status, {
        'Content-Type': 'application/json; charset=utf-8',
        'Content-Length': Buffer.byteLength(body),
        'Access-Control-Allow-Origin': '*'
    });
    return res.end(body);
}

// ------------------------------------------------------------------ 分发
async function dispatchUpstream(res, clientBody, wantsStream) {
    if (!cfg.consoleKey) {
        return sendJson(res, 400, {
            error: { message: '本版本为 key-only：请先在「打开管理页」填写 OpenCode Console / Go API Key 并保存。网关不会再尝试任何匿名免费通道。' }
        });
    }
    const sid = sessionFor(clientBody);
    const model = stripPrefix(clientBody.model || '');
    const body = buildBody(clientBody);
    const p = chatPath();
    const upRes = await upstreamRequest('POST', p, authHeaders(Buffer.byteLength(body), sid), body, 120000);
    if (upRes.statusCode >= 400) {
        const raw = await collect(upRes);
        if (optsRef.log) optsRef.log('上游 HTTP ' + upRes.statusCode + '（' + p + '）：' + raw.slice(0, 300));
        return sendUpstreamError(res, upRes.statusCode, raw);
    }
    return relay(res, upRes, wantsStream, model);
}

/** 一键自检：用当前 key 与当前端点发最小请求，判定 key / 余额 / 端点是否正常。 */
async function selfTest() {
    const sent = {
        plan: cfg.plan,
        endpoint: 'https://' + cfg.upstream + chatPath(),
        key: mask(cfg.consoleKey),
        ua: cfg.ua || DEFAULTS.ua,
        session: newSessionId(),
        note: '所有请求均带 Authorization: Bearer <你的 Key>，无匿名免费通道'
    };
    if (!cfg.consoleKey) {
        return { ok: false, status: 0, sent: sent, upstream: '(未发请求)', verdict: '❌ 尚未填写 Console / Go API Key，请先在管理页保存' };
    }
    const list = await listModels(false).catch(() => null);
    const model = (list && list.data && list.data[0] && list.data[0].id) || 'glm-5.3-flash';
    sent.model = model;
    const body = JSON.stringify({ model: model, messages: [{ role: 'user', content: 'hi' }] });
    try {
        const r = await upstreamRequest('POST', chatPath(), authHeaders(Buffer.byteLength(body), sent.session), body, 20000);
        const raw = await collect(r);
        let verdict;
        if (r.statusCode === 200) verdict = '✅ Key 有效、余额充足、端点正确。可以回 RikkaHub 聊天了';
        else if (r.statusCode === 402) verdict = '❌ Key 有效但余额为 $0 —— 去 Console 充值或订阅 Go，否则所有请求都会 402';
        else if (r.statusCode === 401) verdict = '❌ Key 无效 / 已过期 —— 去 Console 重建一把';
        else if (r.statusCode === 403) verdict = '❌ 被策略拒绝 —— 检查是否选了 -free 模型、Workspace Regions 或 IP 风控';
        else verdict = '❌ HTTP ' + r.statusCode + '，看下方上游原文';
        return { ok: r.statusCode === 200, status: r.statusCode, sent: sent, upstream: raw.slice(0, 900), verdict: verdict };
    } catch (e) {
        return {
            ok: false, status: 0, sent: sent,
            upstream: String((e && e.message) || e),
            verdict: '❌ 网络层失败（不是业务拒绝），检查手机能否访问 opencode.ai、是否挂了代理'
        };
    }
}

// ------------------------------------------------------------------ HTTP 工具
function sendJson(res, status, obj, extra) {
    const body = JSON.stringify(obj);
    res.writeHead(status, Object.assign({
        'Content-Type': 'application/json; charset=utf-8',
        'Content-Length': Buffer.byteLength(body),
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': '*',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
    }, extra || {}));
    res.end(status === 204 ? undefined : body);
}

function readBody(req) {
    return new Promise((resolve, reject) => {
        const chunks = [];
        let size = 0;
        req.on('data', (c) => {
            size += c.length;
            if (size > MAX_BODY) { reject(new Error('body too large')); req.destroy(); return; }
            chunks.push(c);
        });
        req.on('end', () => resolve(Buffer.concat(chunks)));
        req.on('error', reject);
    });
}

function authorized(req) {
    const a = req.headers.authorization || '';
    return cfg.proxyKey === '' || a === 'Bearer ' + cfg.proxyKey;
}

function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

// ------------------------------------------------------------------ 管理页
function managePage(port) {
    const models = modelCache ? modelCache.data : [];
    const rows = models.slice(0, 40).map((m) =>
        '<tr><td><code>' + escapeHtml(m.id) + '</code></td><td>' + escapeHtml(m.name) + '</td><td>' +
        escapeHtml(m.metadata.note || '') + '</td></tr>'
    ).join('');
    const sel = (name, cur, options) => '<select name="' + name + '">' + options.map(([v, t]) =>
        '<option value="' + v + '"' + (String(cur) === String(v) ? ' selected' : '') + '>' + t + '</option>'
    ).join('') + '</select>';

    return `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>OpenCode Console 网关 · 管理 (r3 key-only)</title>
<style>
body{background:#0f1220;color:#e8ecff;font:15px/1.6 system-ui,sans-serif;padding:18px;max-width:780px;margin:auto}
h1{font-size:20px;color:#8ad8ff} h2{font-size:16px;color:#b9c3ff;margin:0 0 8px}
.card{background:#1b2140;border-radius:14px;padding:16px;margin:14px 0}
code{color:#9ae6b4} label{display:block;margin:10px 0 4px;color:#b9c3ff;font-size:13px}
input,select,textarea{width:100%;box-sizing:border-box;background:#0d1024;color:#fff;border:1px solid #39406e;border-radius:8px;padding:10px;font-size:14px}
textarea{min-height:76px;resize:vertical;font-family:monospace;font-size:12px}
button{background:linear-gradient(90deg,#22d3ee,#8b5cf6);color:#fff;border:0;border-radius:10px;padding:11px 20px;font-size:15px;margin-top:12px;cursor:pointer}
a{color:#8ad8ff} .muted{color:#8b93bd;font-size:12.5px} .warn{color:#ffd08a}
table{width:100%;border-collapse:collapse;font-size:12px} td,th{padding:5px 6px;border-bottom:1px solid #2a3158;text-align:left;vertical-align:top}
pre{background:#0d1024;border:1px solid #39406e;border-radius:8px;padding:12px;font-size:11px;white-space:pre-wrap;word-break:break-all;max-height:420px;overflow:auto;color:#cfe3ff}
</style></head><body>
<h1>🔑 OpenCode Console 网关 <span class="muted">r3 · key-only</span></h1>
<div class="card">
  <div>状态：<code style="color:#9ae6b4">运行中</code> · 端口 <code>${port}</code> · 方案 <code>${escapeHtml(cfg.plan)}</code></div>
  <div>RikkaHub Base URL：<code>http://127.0.0.1:${port}/v1</code></div>
  <div>Console / Go Key：<code>${mask(cfg.consoleKey)}</code> · 本机 API Key：<code>${mask(cfg.proxyKey)}</code></div>
  <div>上游：<code>https://${escapeHtml(cfg.upstream)}${escapeHtml(chatPath())}</code></div>
  <div class="muted">模型：${models.length} 个 · <a href="/v1/models?refresh=1">刷新模型清单</a></div>
</div>

<div class="card">
  <h2>🔬 一键测试（先点这个）</h2>
  <div class="muted">用你填的 Key 与当前端点发一句 "hi"，直接判定：Key 是否有效、余额是否充足、端点是否选对。不用切到 RikkaHub 反复重试。</div>
  <button type="button" onclick="runTest()">发送最小请求并查看结果</button>
  <pre id="testout">尚未测试</pre>
</div>

<div class="card">
  <h2>① API Key（必填）</h2>
  <form method="POST" action="/config">
    <label>OpenCode Console / Go API Key（opencode.ai/console 创建；留空 = 不修改）</label>
    <input name="consoleKey" type="password" placeholder="oc_sk_… 留空 = 不修改" autocomplete="off">
    <div class="muted">本版本<b>所有上游请求都带这把 Key</b>，不再有任何匿名免费通道。Key 存本机私有目录 0600，页面只显示掩码，不进二维码。</div>
    <label>清除已保存的 Key</label>
    ${sel('clearConsoleKey', 0, [[0, '否'], [1, '是 · 清空']])}
    <label>本机 API Key（RikkaHub 里填的那个；留空 = 不修改）</label>
    <input name="proxyKey" type="password" placeholder="留空 = 不修改" autocomplete="off">

    <h2 style="margin-top:18px">② 计费方案与端点</h2>
    <label>计费方案</label>
    ${sel('plan', cfg.plan, [['console', 'console · 按量付费，用 Console 余额（需先充值）'], ['go', 'go · Go / Go Plus / Teams 订阅']])}
    <div class="muted">两者用<b>同一把 Key</b>，区别只在端点：按量走 <code>/inference/openai/v1/…</code>，Go 走 <code>/inference/go/openai/v1/…</code>。选错端点同样会报错。</div>
    <label>Console 端点路径</label>
    <input name="consolePath" value="${escapeHtml(cfg.consolePath)}">
    <label>Go 端点路径</label>
    <input name="goPath" value="${escapeHtml(cfg.goPath)}">
    <label>模型清单路径</label>
    <input name="modelsPath" value="${escapeHtml(cfg.modelsPath)}">
    <label>上游 host</label>
    <input name="upstream" value="${escapeHtml(cfg.upstream)}">
    <label>User-Agent（官方要求第三方 harness 诚实标识自己，别伪装官方客户端）</label>
    <input name="ua" value="${escapeHtml(cfg.ua)}">
    <label>Console 模式隐藏 -free 模型（带 key 也 403，默认开）</label>
    ${sel('hideFreeModels', cfg.hideFreeModels ? 1 : 0, [[1, '开'], [0, '关']])}
    <label>session ID 形状（Go 要求每轮稳定 ses_ ID；网关已按对话自动复用）</label>
    ${sel('sidStyle', cfg.sidStyle, [['desc', 'desc · ses_ + 12hex + 14base62'], ['random', 'random · ses_ + 12hex + 16base62']])}

    <h2 style="margin-top:18px">③ 高级（可留空）</h2>
    <label>自定义模型 ID（每行一个；填了就覆盖内置/上游清单）</label>
    <textarea name="customModels" placeholder="glm-5.3-flash&#10;deepseek-v4.1-flash">${escapeHtml(cfg.customModels)}</textarea>
    <label>追加请求头（JSON 对象）</label>
    <textarea name="extraHeaders" placeholder='{"x-opencode-request":"..."}'>${escapeHtml(cfg.extraHeaders)}</textarea>
    <button type="submit">保存并清空模型缓存</button>
  </form>
  <div class="muted">保存后若改了「本机 API Key」，回主界面「停止网关 → 启动网关」刷新状态栏与二维码，并同步修改 RikkaHub 里的 Key。其它参数即时生效，可直接再点「一键测试」。</div>
</div>

<div class="card">
  <h2>当前模型清单</h2>
  <table><tr><th>ID</th><th>名称</th><th>备注</th></tr>${rows || '<tr><td colspan="3">尚未加载</td></tr>'}</table>
</div>

<div class="card warn">
  <b>关于「用 Key 调免费模型」：</b><br>
  1. 官方写死：「免费模型只对 OpenCode 客户端开放，其它客户端<b>即使带 Console API Key 也 403</b>」。免费层的凭据不是 Key，所以 r3 直接删掉了整条匿名通道，不再伪装 UA / TLS / 请求体。<br>
  2. <b>新账户余额默认 $0</b>，创建 Key ≠ 充值。若一键测试返回 <code>402 Insufficient account funds</code>，去 Console → Settings › Billing › Add credits（$10 起，支持支付宝/微信），或订阅 Go $10/月。这一步不做，装上 r3 仍会失败。<br>
  3. Go 计划里含 Beam Free / Iceman Contributor Free 等限时免费位，选中 <code>go</code> 方案后可在清单里看到；Beam Free 不对中国大陆/港澳提供。<br>
  4. 按量与 Go 用同一把 Key，端点不同；<code>x-opencode-session</code> 网关已按对话自动复用，Go 强制要求它。<br>
  5. 本页只对回环开放，<code>/config</code> 与 <code>/selftest</code> 不鉴权，网关固定只监听 127.0.0.1。
</div>
<script>
function runTest(){
  var o=document.getElementById('testout');
  o.textContent='请求中…（最多 20 秒）';
  fetch('/selftest').then(function(r){return r.json();}).then(function(j){
    o.textContent = j.verdict + '\\nHTTP ' + j.status +
      '\\n\\n【本次配置】\\n' + JSON.stringify(j.sent,null,2) +
      '\\n\\n【上游返回原文】\\n' + j.upstream;
  }).catch(function(e){o.textContent='自检请求失败：'+e;});
}
</script>
</body></html>`;
}

// ------------------------------------------------------------------ 主服务
function start(opts) {
    optsRef = opts || {};
    const dataDir = optsRef.dataDir || process.cwd();
    cfg = loadConfig(dataDir);

    const server = http.createServer(async (req, res) => {
        try {
            const u = new URL(req.url, 'http://' + (req.headers.host || '127.0.0.1'));
            const p = u.pathname.replace(/\/+$/, '') || '/';

            if (req.method === 'OPTIONS') return sendJson(res, 204, {});

            if (req.method === 'GET' && p === '/health') {
                return sendJson(res, 200, {
                    ok: true,
                    service: 'opencode-console-gateway',
                    version: 'r3-key-only',
                    plan: cfg.plan,
                    hasConsoleKey: !!cfg.consoleKey,
                    endpoint: chatPath(),
                    models: modelCache ? modelCache.data.length : 0,
                    upstream: cfg.upstream,
                    note: 'all upstream requests are authenticated with the Console/Go API key; no anonymous free tier'
                });
            }

            if (req.method === 'GET' && p === '/selftest') {
                return sendJson(res, 200, await selfTest());
            }

            if (req.method === 'GET' && (p === '/' || p === '/index.html')) {
                const body = managePage(server.address() ? server.address().port : optsRef.port);
                res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Content-Length': Buffer.byteLength(body) });
                return res.end(body);
            }

            if (req.method === 'POST' && p === '/config') {
                const raw = (await readBody(req)).toString('utf8');
                let next = {};
                if (raw.trim().startsWith('{')) {
                    next = safeJson(raw) || {};
                } else {
                    const params = new URLSearchParams(raw);
                    next = Object.fromEntries(params.entries());
                }
                const merged = Object.assign({}, cfg);
                const CLEARABLE = { customModels: 1, extraHeaders: 1 };
                for (const k of Object.keys(DEFAULTS)) {
                    const v = next[k];
                    if (typeof DEFAULTS[k] === 'boolean') {
                        if (v !== undefined) merged[k] = parseBool(v, cfg[k]);
                    } else if (typeof v === 'string') {
                        if (v === '' && !CLEARABLE[k]) continue;
                        if (v.includes('****')) continue;
                        merged[k] = v;
                    }
                }
                if (next.clearConsoleKey === '1' || next.clearConsoleKey === 1) merged.consoleKey = '';
                saveConfig(dataDir, merged);
                if (optsRef.onKeyChanged) optsRef.onKeyChanged(cfg.proxyKey);
                if (optsRef.log) optsRef.log('配置已更新：plan=' + cfg.plan + ' key=' + mask(cfg.consoleKey) + ' proxyKey=' + mask(cfg.proxyKey));
                res.writeHead(303, { Location: '/' });
                return res.end();
            }

            if (!authorized(req)) return sendJson(res, 401, { error: 'unauthorized' });

            if (req.method === 'GET' && (p === '/v1/models' || p === '/models')) {
                const list = await listModels(u.searchParams.get('refresh') === '1');
                return sendJson(res, 200, list);
            }

            if (req.method === 'POST' && (p === '/v1/chat/completions' || p === '/chat/completions')) {
                const body = await readBody(req);
                const clientBody = safeJson(body.toString('utf8'));
                if (!clientBody || !Array.isArray(clientBody.messages)) {
                    return sendJson(res, 400, { error: { message: 'invalid chat.completions body: messages required' } });
                }
                const wantsStream = clientBody.stream === true;
                return await dispatchUpstream(res, clientBody, wantsStream);
            }

            return sendJson(res, 404, {
                error: 'not_found',
                routes: ['GET /health', 'GET /selftest', 'GET /v1/models', 'POST /v1/chat/completions', 'GET /', 'POST /config']
            });
        } catch (e) {
            if (optsRef.log) optsRef.log('请求异常 ' + req.method + ' ' + req.url + '：' + (e && e.message || e));
            if (!res.headersSent) {
                return sendJson(res, 502, { error: 'proxy_error', message: String((e && e.message) || e) });
            }
            try { res.end(); } catch (_) {}
        }
    });

    let port = Number(optsRef.port) || 18900;
    const host = '127.0.0.1';
    let tries = 0;
    server.on('error', (e) => {
        if (e.code === 'EADDRINUSE' && tries++ < 12) {
            port += 1;
            if (optsRef.log) optsRef.log('端口被占用，顺延到 ' + port);
            setTimeout(() => server.listen(port, host), 200);
        } else {
            if (optsRef.log) optsRef.log('监听失败：' + (e && e.message || e));
            if (optsRef.onFatal) optsRef.onFatal(String(e && e.message || e));
        }
    });
    server.listen(port, host, () => {
        const actual = server.address().port;
        if (optsRef.log) optsRef.log('OpenCode Console 网关已监听 http://' + host + ':' + actual + '/v1（r3 key-only / plan=' + cfg.plan + ' / key=' + mask(cfg.consoleKey) + '）');
        if (optsRef.onListening) optsRef.onListening(actual);
    });
    return server;
}

module.exports = { start: start, listModels: listModels, config: () => cfg };
