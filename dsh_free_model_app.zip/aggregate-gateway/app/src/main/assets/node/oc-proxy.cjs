'use strict';
/**
 * oc-proxy.cjs —— proot 复刻版网关（方案 C / r5「bridge-only」）
 *
 * 由 bootstrap.cjs require 加载，跑在 APP 自带的 nodejs-mobile (Node 22) 里，
 * 只监听 127.0.0.1，零 npm 依赖。
 *
 * ══════════════════════════════════════════════════════════════════
 * 本版只使用免费模型，不提供任何付费 / Go 通道，失败绝不静默降级。
 *
 * 出网链路（唯一对 opencode.ai 发请求的，是 rootfs 里的官方 CLI 进程）：
 *
 *   RikkaHub
 *     → 127.0.0.1:18900/v1            （本网关，OpenAI 兼容）
 *     → 127.0.0.1:4317 /api/*        （opencode serve，纯回环）
 *     → https://opencode.ai          （由官方 OpenCode CLI 进程发出）
 *
 * 免费层认证由官方 CLI 自己完成，本网关不构造任何对 opencode.ai 的 HTTP 请求，
 * 因此不需要 UA 伪造 / TLS cipher / session 形状 / 请求体注入 —— 那套在
 * r1/r2 已实证必败（校验的是「真实客户端进程的连接态」，不是报文）。
 *
 * 两层 Key：
 *   · 本机 Key：RikkaHub 填，只校验本机网关，沿用旧默认值。
 *   · servePassword：本地 opencode serve 的 auth_token，随机生成，只在本机用。
 * 两者都不是 OpenCode 账号 Key。
 * ══════════════════════════════════════════════════════════════════
 *
 * 路由：
 *   GET  /health                 探活 + rootfs/CLI 状态
 *   GET  /selftest               端到端自检（走完整 /api/* 链路发一句 hi）
 *   GET  /v1/models              只列免费模型
 *   POST /v1/chat/completions    翻译成本地 opencode serve 会话调用
 *   GET  /                       管理页
 *   POST /config                 保存配置
 *   POST /rootfs/restart         重启 CLI（会重新校验/下载 rootfs）
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const rootfs = require('./rootfs-manager.cjs');

// ------------------------------------------------------------------ 默认配置
// APK assets 不加密：这里不内置任何凭据、不内置任何二进制。
const DEFAULTS = {
    proxyKey: 'Rikka-2026-CF-Proxy-Key-8f3b',

    // --- rootfs 来源 ---
    rootfsSource: 'local',                // local（默认，纯离线）| auto | url | dir
    rootfsUrl: rootfs.DEFAULT_ROOTFS_URL,
    rootfsUrls: '',                       // 每行一个完整 URL；填了优先于 rootfsUrl
    rootfsMirrors: rootfs.DEFAULT_MIRRORS.join('\n'),
    rootfsLocalPath: '',                  // 留空 = ofm-data/import/rootfs-arm64.tar.gz
    rootfsDir: '',                        // 留空 = ofm-data/rootfs
    opencodeBin: 'opencode/bin/opencode',

    // --- opencode serve ---
    serveHost: '127.0.0.1',
    servePort: '4317',
    servePassword: '',                    // 留空 = 每次随机生成并回写配置
    apiStyle: 'query',                    // query（?auth_token=）| basic（HTTP Basic）
    readyTries: '60',
    bindWorkspace: '',
    dns: '',
    extraProotArgs: '',

    // --- 模型过滤（只保留免费位）---
    freeModelPattern: '(-free$|big-pickle|bigpickle|space-bunny|flint-40b)',
    modelAllowlist: '',                   // 每行一个 ID，强制保留
    modelDenylist: '',                    // 每行一个 ID，强制剔除
    customModels: '',                     // 填了就完全覆盖上游清单

    // --- 翻译参数 ---
    promptTimeoutMs: '120000',
    pollIntervalMs: '400',
    rateRetries: '3',
    stablePolls: '2',
    autoStart: true
};

const MAX_BODY = 20 * 1024 * 1024;
const CACHE_MS = 10 * 60 * 1000;

let cfg = Object.assign({}, DEFAULTS);
let optsRef = {};
let modelCache = null;
let modelCacheAt = 0;
let serverRef = null;
let bootError = '';

// ------------------------------------------------------------------ 配置
function loadConfig(dataDir) {
    const out = Object.assign({}, DEFAULTS);
    try {
        const f = path.join(dataDir, 'oc-config.json');
        if (fs.existsSync(f)) {
            const o = JSON.parse(fs.readFileSync(f, 'utf8'));
            for (const k of Object.keys(DEFAULTS)) {
                const v = o[k];
                if (typeof DEFAULTS[k] === 'boolean') {
                    if (typeof v === 'boolean') out[k] = v;
                    else if (v === '1' || v === 1 || v === '0' || v === 0) out[k] = (v === true || v === 1 || v === '1');
                } else if (typeof v === 'string') {
                    out[k] = v;
                }
            }
            // 旧版遗留的付费通道相关字段一律忽略（本版不使用）。
        }
    } catch (_) {}
    return out;
}

function saveConfig(dataDir, next) {
    const f = path.join(dataDir, 'oc-config.json');
    const tmp = f + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(next, null, 2), { mode: 0o600 });
    try { fs.chmodSync(tmp, 0o600); } catch (_) {}
    fs.renameSync(tmp, f);
    try { fs.chmodSync(f, 0o600); } catch (_) {}
    cfg = Object.assign({}, cfg, next);
    modelCache = null;
    modelCacheAt = 0;
}

function humanBytes(b) {
    if (b > 1024 * 1024) return (b / 1024 / 1024).toFixed(1) + ' MB';
    if (b > 1024) return (b / 1024).toFixed(0) + ' KB';
    return b + ' B';
}

function mask(s) {
    if (!s) return '(未设置)';
    if (s.length <= 10) return '****';
    return s.slice(0, 5) + '****' + s.slice(-4);
}

function parseBool(v, fallback) {
    if (v === '1' || v === 1 || v === true || v === 'true') return true;
    if (v === '0' || v === 0 || v === false || v === 'false') return false;
    return fallback;
}

function safeJson(raw) {
    try { return JSON.parse(raw); } catch (_) { return null; }
}

function lines(s) {
    return String(s || '').split(/\r?\n/).map((x) => x.trim()).filter((x) => x && !x.startsWith('#'));
}

// ------------------------------------------------------------------ 模型
function isFreeId(id, m) {
    const s = String(id).toLowerCase();
    const allow = lines(cfg.modelAllowlist).map((x) => x.toLowerCase());
    const deny = lines(cfg.modelDenylist).map((x) => x.toLowerCase());
    if (deny.some((d) => s === d || s.endsWith('/' + d))) return false;
    if (allow.some((a) => s === a || s.endsWith('/' + a))) return true;
    // 上游若明确标注 cost=0 / free，也算免费位
    if (m) {
        const cost = m.cost || m.pricing || {};
        if (m.free === true || cost.input === 0 || cost.input === '0' || m.cost === 0) return true;
    }
    try { return new RegExp(cfg.freeModelPattern, 'i').test(s); }
    catch (_) { return /-free$/.test(s); }
}

function normalizeId(providerID, modelID) {
    const p = String(providerID || 'opencode').trim();
    const m = String(modelID || '').trim();
    if (!m) return '';
    return m.startsWith(p + '/') ? m : p + '/' + m;
}

function pretty(id) {
    const s = String(id).split('/').pop() || id;
    return s.replace(/[-_]/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
}

/** GET /api/model → 只保留免费位。上游挂了用内置兜底，绝不列付费模型。 */
const BUILTIN_FREE = [
    'opencode/glm-5.3-flash-free',
    'opencode/deepseek-v4.1-flash-free',
    'opencode/minimax-m3.1-flash-free',
    'opencode/mimo-v2.6-flash-free',
    'opencode/big-pickle',
    'opencode/flint-40b-free',
    'opencode/nemotron-3-ultra-free',
    'opencode/longcat-2.5-preview-free'
];

async function listModels(force) {
    if (!force && modelCache && Date.now() - modelCacheAt < CACHE_MS) return modelCache;

    if (cfg.customModels.trim()) {
        const data = lines(cfg.customModels).map((id) => ({
            id: normalizeId('opencode', id), object: 'model', created: 0, owned_by: 'opencode',
            metadata: { free: true, source: 'custom' }
        }));
        modelCache = { object: 'list', data, total: data.length };
        modelCacheAt = Date.now();
        return modelCache;
    }

    let data = [];
    let source = 'builtin';
    const r = await rootfs.apiRequest(cfg, 'GET', '/api/model', null, 8000);
    if (r.status === 200 && r.json) {
        const arr = Array.isArray(r.json.data) ? r.json.data : (Array.isArray(r.json) ? r.json : []);
        for (const m of arr) {
            const id = normalizeId(m.providerID || m.provider || m.id, m.modelID || m.id);
            if (!id || !isFreeId(id, m)) continue;
            data.push({
                id, object: 'model', created: 0, owned_by: 'opencode',
                name: m.name || pretty(id),
                metadata: { free: true, source: 'upstream', providerID: m.providerID || 'opencode', modelID: m.modelID || m.id }
            });
        }
        if (data.length) source = 'upstream';
    }
    if (!data.length) {
        data = BUILTIN_FREE.filter((id) => isFreeId(id))
            .map((id) => ({ id, object: 'model', created: 0, owned_by: 'opencode', metadata: { free: true, source: 'builtin' } }));
    }
    // 去重
    const seen = new Set();
    data = data.filter((m) => !seen.has(m.id) && seen.add(m.id));
    modelCache = { object: 'list', data, total: data.length };
    modelCacheAt = Date.now();
    if (optsRef.log) optsRef.log('模型清单：' + data.length + ' 个免费位（来源 ' + source + '）');
    return modelCache;
}

function splitModel(id) {
    const s = String(id || '').trim().replace(/^opencode-go\//i, '');
    const i = s.indexOf('/');
    if (i > 0) return { providerID: s.slice(0, i), modelID: s.slice(i + 1) };
    return { providerID: 'opencode', modelID: s };
}

function resolveModel(id) {
    const { providerID, modelID } = splitModel(id);
    const list = modelCache ? modelCache.data : [];
    const hit = list.find((m) => m.id === id || m.id.endsWith('/' + modelID));
    if (hit && hit.metadata && hit.metadata.modelID) {
        return { providerID: hit.metadata.providerID || providerID, modelID: hit.metadata.modelID };
    }
    return { providerID, modelID };
}

// ------------------------------------------------------------------ 请求文本
/**
 * RikkaHub 每轮带完整 messages。opencode session 是新建的，所以把历史拼成
 * 一段带角色标记的文本；system 放最前，最后一条必须是 user。
 */
function contentText(m) {
    const c = m && m.content;
    if (typeof c === 'string') return c;
    if (Array.isArray(c)) {
        let t = '';
        for (const p of c) {
            if (!p || typeof p !== 'object') continue;
            if ((p.type === 'text' || p.type === 'input_text' || !p.type) && typeof p.text === 'string') t += p.text;
            else if (typeof p.text === 'string') t += p.text;
        }
        return t;
    }
    return '';
}

/** 对齐 OCGW APK 实测通过的 flatten() 形状。 */
function buildPrompt(messages) {
    const parts = [];
    for (const m of messages) {
        if (!m || !m.role) continue;
        const text = contentText(m).trim();
        if (!text && m.role !== 'assistant') continue;
        switch (m.role) {
            case 'system': case 'developer': parts.push(text); break;
            case 'tool': parts.push('[tool result] ' + text); break;
            case 'assistant': parts.push('<assistant>\n' + text + '\n</assistant>'); break;
            default: parts.push('<user>\n' + text + '\n</user>');
        }
    }
    return parts.join('\n\n').trim() || 'hello';
}

function freshMsgId() {
    return 'msg_' + crypto.randomBytes(12).toString('hex');
}

// ------------------------------------------------------------------ 会话翻译
/**
 * OCGW APK 实测通过的 v2 prompt 形状（每次调用都要生成新的 msg_ id）。
 * 参考 GatewayService.kt / OpenAiGateway.kt 里 sendPrompt 的 JSONObject。
 */
function makeOcBody(text, providerID, modelID) {
    return {
        id: freshMsgId(),
        text,
        files: [], agents: [], skills: [],
        delivery: 'queue',
        metadata: {
            displayText: String(text).replace(/\n/g, ' ').slice(0, 120),
            comments: [], attachments: [],
            agent: 'build',
            model: { providerID, modelID }
        }
    };
}

/**
 * 解析 /api/session/{id}/message：兼容三种上游形状
 *  · { info: { role, time:{created}, finish, error }, parts:[{type:'text',text}] }（新版）
 *  · { type:'assistant', content:[{type:'text',text}], finish, error }（OCGW 同款）
 *  · { role:'assistant', content:'...' } / parts 数组（旧版）
 * 返回 { text, error, rate, done }。
 */
function parseAssistantMessages(res) {
    const j = res && res.json;
    const data = j && (Array.isArray(j.data) ? j.data : (Array.isArray(j) ? j : null));
    if (!data) return { text: null };

    let best = null, bestT = -1;
    for (const rec of data) {
        if (!rec || typeof rec !== 'object') continue;
        const info = (rec.info && typeof rec.info === 'object') ? rec.info : rec;
        const role = String(info.role || info.type || rec.type || '').toLowerCase();
        if (role !== 'assistant') continue;
        const t = (info.time && Number(info.time.created)) || Number(info.created) || 0;
        if (t >= bestT) { bestT = t; best = { rec, info }; }
    }
    if (!best) return { text: null };

    const { rec, info } = best;
    const err = info.error || rec.error || null;
    if (err && typeof err === 'object') {
        const type = String(err.type || err.name || '');
        const msg = String(err.message || type || '上游返回错误');
        const status = Number(err.status || 0);
        const rate = /limit|rate|quota/i.test(type + ' ' + msg) || status === 429;
        return { text: null, error: msg, rate };
    }

    const finish = String(info.finish || rec.finish || '');
    const parts = (Array.isArray(info.content) ? info.content : null)
        || (Array.isArray(rec.content) ? rec.content : null)
        || (Array.isArray(rec.parts) ? rec.parts : null)
        || (Array.isArray(info.parts) ? info.parts : null)
        || [];
    let text = '';
    for (const part of parts) {
        if (!part || typeof part !== 'object') continue;
        if ((part.type === 'text' || part.type === 'input_text' || !part.type) && typeof part.text === 'string') text += part.text;
    }
    if (!text && typeof info.content === 'string') text = info.content;
    if (!text && typeof rec.content === 'string') text = rec.content;
    text = text.trim();

    // OCGW：finish 非空且不以 tool 开头才算完成；文本允许为空串
    if (!finish) return { text: text || null, finish: '' };
    return { text: text || '', finish, done: !/^tool/i.test(finish) };
}

/** 一次完整的 OpenAI → /api/* → OpenAI 翻译。绝不发起任何外部 HTTP 请求。 */
async function chatViaServe(clientBody) {
    const steps = [];
    const { providerID, modelID } = resolveModel(clientBody.model || '');
    const text = buildPrompt(clientBody.messages);
    const timeoutMs = Number(cfg.promptTimeoutMs) || 120000;
    const pollMs = Number(cfg.pollIntervalMs) || 400;
    const rateTries = Number(cfg.rateRetries) || 3;

    // 1. 建会话（OCGW：POST /api/session  body {}）
    let r = await rootfs.apiRequest(cfg, 'POST', '/api/session', {}, 15000);
    steps.push({ step: 'POST /api/session', status: r.status, raw: r.raw.slice(0, 200) });
    if (r.status >= 400 || r.status === 0) return { ok: false, steps, error: '创建会话失败：' + r.raw.slice(0, 300) };
    const sessionId = r.json && ((r.json.data && r.json.data.id) || r.json.id);
    if (!sessionId) return { ok: false, steps, error: '创建会话成功但没拿到 id：' + r.raw.slice(0, 300) };

    const base = '/api/session/' + encodeURIComponent(sessionId);
    let reply = null;

    try {
        // 2. 发 prompt：首选 OCGW 实测通过的完整 v2 形状，另备两种旧形状回退
        const bodies = [
            makeOcBody(text, providerID, modelID),
            { id: freshMsgId(), parts: [{ type: 'text', text }], agent: 'build',
              model: { providerID, modelID }, providerID, modelID, metadata: {} },
            { id: freshMsgId(), text, agent: 'build',
              model: { providerID, modelID }, providerID, modelID, metadata: {} }
        ];
        let sent = false;
        for (const body of bodies) {
            r = await rootfs.apiRequest(cfg, 'POST', base + '/prompt', body, 15000);
            steps.push({ step: 'POST /prompt (' + (body.metadata && body.metadata.displayText !== undefined ? 'ocgw-v2' : body.parts ? 'parts' : 'text') + ')',
                         status: r.status, raw: r.raw.slice(0, 200) });
            if (r.status < 400 && r.status > 0) { sent = true; break; }
        }
        if (!sent) return { ok: false, steps, error: '发送 prompt 失败（三种 body 都被拒）：' + r.raw.slice(0, 300) };

        // 3. 轮询取回复：检查 error / finish，限流时按 OCGW 的做法重发 prompt
        let rateCount = 0;
        let lastText = null, stableCount = 0;
        const stableNeeded = Number(cfg.stablePolls) || 2;
        const deadline = Date.now() + timeoutMs;
        while (Date.now() < deadline) {
            await new Promise((res) => setTimeout(res, pollMs));
            r = await rootfs.apiRequest(cfg, 'GET', base + '/message', null, 15000);
            if (r.status !== 200) {
                if (r.status >= 400 && r.status !== 404) {
                    steps.push({ step: 'GET /message', status: r.status, raw: r.raw.slice(0, 200) });
                    break;
                }
                continue;
            }
            const parsed = parseAssistantMessages(r);
            if (parsed.error) {
                if (parsed.rate && rateCount++ < rateTries) {
                    steps.push({ step: '限流重试 #' + rateCount, msg: parsed.error });
                    const again = await rootfs.apiRequest(cfg, 'POST', base + '/prompt', makeOcBody(text, providerID, modelID), 15000);
                    steps.push({ step: 'POST /prompt (retry)', status: again.status });
                    continue;
                }
                return { ok: false, steps, error: parsed.error };
            }
            if (parsed.done) { reply = parsed.text || ''; break; }
            // 旧版 CLI 的 /message 可能不带 finish 字段：文本连续 N 次不变即视为完成，
            // 避免一直轮询到 120s 超时（同时不会把还在增长中的流式文本提前返回）。
            if (parsed.text && !parsed.finish) {
                if (parsed.text === lastText) stableCount++;
                else { lastText = parsed.text; stableCount = 1; }
                if (stableCount >= stableNeeded) { reply = parsed.text; break; }
            }
        }
        steps.push({ step: 'GET /message (poll)', status: r.status, found: reply !== null,
                     raw: reply !== null ? String(reply).slice(0, 200) : r.raw.slice(0, 200) });
        if (reply === null) {
            return { ok: false, steps, error: '等待回复超时（或上游一直没给 finish）。' +
                '看 opencode.log 尾部；若是 429，那是服务端共享额度窗口，不是配置错，别连续重试。' };
        }
    } finally {
        // 4. 收尾删会话
        const del = await rootfs.apiRequest(cfg, 'DELETE', base, null, 8000);
        steps.push({ step: 'DELETE /api/session', status: del.status, raw: del.raw.slice(0, 120) });
    }

    return { ok: true, steps, reply, model: clientBody.model };
}

function completion(id, model, content, usage) {
    return {
        id: id, object: 'chat.completion', created: Math.floor(Date.now() / 1000), model,
        choices: [{ index: 0, message: { role: 'assistant', content }, finish_reason: 'stop' }],
        usage: usage || { prompt_tokens: 0, completion_tokens: 0, total_tokens: 0 }
    };
}

function sendJson(res, status, obj, extra) {
    const body = JSON.stringify(obj);
    res.writeHead(status, Object.assign({
        'Content-Type': 'application/json; charset=utf-8',
        'Content-Length': Buffer.byteLength(body),
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': '*',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
    }, extra || {}));
    res.end(status === 204 ? undefined : body);
}

function sendSseCompletion(res, model, content) {
    const id = 'chatcmpl-' + crypto.randomBytes(8).toString('hex');
    res.writeHead(200, {
        'Content-Type': 'text/event-stream; charset=utf-8',
        'Cache-Control': 'no-cache, no-transform',
        'Connection': 'keep-alive',
        'X-Accel-Buffering': 'no',
        'Access-Control-Allow-Origin': '*'
    });
    res.write('data: ' + JSON.stringify({
        id, object: 'chat.completion.chunk', created: Math.floor(Date.now() / 1000), model,
        choices: [{ index: 0, delta: { role: 'assistant', content }, finish_reason: null }]
    }) + '\n\n');
    res.write('data: ' + JSON.stringify({
        id, object: 'chat.completion.chunk', created: Math.floor(Date.now() / 1000), model,
        choices: [{ index: 0, delta: {}, finish_reason: 'stop' }],
        usage: { prompt_tokens: 0, completion_tokens: 0, total_tokens: 0 }
    }) + '\n\n');
    res.write('data: [DONE]\n\n');
    res.end();
}

function bridgeError(res, out) {
    const st = rootfs.status();
    const body = JSON.stringify({
        error: {
            type: 'bridge_error',
            message: out.error + '\n\n【排查】rootfs=' + st.phase + ' · ' + st.message +
                '\nCLI 日志尾部：\n' + st.logTail.slice(-1200) +
                '\n若 /api/config 返回 401/403，把管理页「认证方式」在 query / basic 间切换。' +
                '\n本版只走免费模型，不会自动切到付费通道。',
            steps: out.steps
        }
    });
    res.writeHead(502, {
        'Content-Type': 'application/json; charset=utf-8',
        'Content-Length': Buffer.byteLength(body),
        'Access-Control-Allow-Origin': '*'
    });
    res.end(body);
}

// ------------------------------------------------------------------ 自检
async function selfTest() {
    const st = rootfs.status();
    const sent = {
        mode: 'bridge (proot → opencode serve → opencode.ai)',
        rootfsPhase: st.phase,
        rootfsDir: st.rootfsDir,
        quad: st.quad,
        servePort: Number(cfg.servePort) || 4317,
        apiStyle: cfg.apiStyle,
        keyUsed: '无（免费层认证由官方 CLI 进程完成）'
    };
    if (!st.quad.ok) return { ok: false, sent, verdict: '❌ rootfs 四件套缺失：' + st.quad.missing.join('、') + ' —— 先在管理页导入归档或解压目录。' };

    const ping = await rootfs.apiRequest(cfg, 'GET', '/api/config', null, 5000);
    sent.configStatus = ping.status;
    if (ping.status !== 200) return { ok: false, sent, verdict: '❌ opencode serve 未就绪（/api/config → ' + ping.status + '）。点「重启 CLI」或切换认证方式。' };

    const list = await listModels(true);
    sent.modelCount = list.data.length;
    sent.firstModel = list.data[0] && list.data[0].id;
    if (!list.data.length) return { ok: false, sent, verdict: '❌ 免费模型清单为空，检查 /api/model 与管理页「免费位匹配规则」。' };

    const out = await chatViaServe({ model: list.data[0].id, messages: [{ role: 'user', content: 'hi' }] });
    sent.steps = out.steps;
    return {
        ok: out.ok,
        sent,
        upstream: out.reply ? out.reply.slice(0, 300) : out.error,
        verdict: out.ok
            ? '✅ 端到端通了：官方 CLI 进程已代发请求并返回回复。可以回 RikkaHub 聊天。'
            : '❌ ' + out.error
    };
}

// ------------------------------------------------------------------ 管理页
function escapeHtml(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function managePage(port) {
    const st = rootfs.status();
    const models = modelCache ? modelCache.data : [];
    const rows = models.slice(0, 40).map((m) =>
        '<tr><td><code>' + escapeHtml(m.id) + '</code></td><td>' + escapeHtml(m.metadata.source) + '</td></tr>'
    ).join('');
    const sel = (name, cur, options) => '<select name="' + name + '">' + options.map(([v, t]) =>
        '<option value="' + v + '"' + (String(cur) === String(v) ? ' selected' : '') + '>' + t + '</option>'
    ).join('') + '</select>';
    const quadRows = rootfs.QUAD.map((q) => {
        const ok = st.quad && st.quad.ok || (st.quad && st.quad.missing && !st.quad.missing.includes(q));
        return '<div>' + (ok ? '✅' : '❌') + ' <code>' + escapeHtml(q) + '</code></div>';
    }).join('');
    const warnRows = (st.warnings || []).map((w) => '<div class="warn">⚠ ' + escapeHtml(w) + '</div>').join('');
    const archRows = rootfs.probeArchives(cfg).filter((a) => a.exists).map((a) =>
        '<div>✅ <code>' + escapeHtml(a.path) + '</code> · ' + escapeHtml(humanBytes(a.bytes)) + ' · ' + escapeHtml(a.kind) + '</div>'
    ).join('') || '<div class="bad">❌ 未在任何默认路径发现归档（把文件放到 /sdcard/Download/ 后点下面「一键导入」）</div>';

    return `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>proot 网关 · 管理 (r5d · 本地归档)</title>
<style>
body{background:#0f1220;color:#e8ecff;font:15px/1.6 system-ui,sans-serif;padding:18px;max-width:820px;margin:auto}
h1{font-size:20px;color:#8ad8ff} h2{font-size:16px;color:#b9c3ff;margin:0 0 8px}
.card{background:#1b2140;border-radius:14px;padding:16px;margin:14px 0}
code{color:#9ae6b4} label{display:block;margin:10px 0 4px;color:#b9c3ff;font-size:13px}
input,select,textarea{width:100%;box-sizing:border-box;background:#0d1024;color:#fff;border:1px solid #39406e;border-radius:8px;padding:10px;font-size:14px}
textarea{min-height:70px;resize:vertical;font-family:monospace;font-size:12px}
button{background:linear-gradient(90deg,#22d3ee,#8b5cf6);color:#fff;border:0;border-radius:10px;padding:11px 18px;font-size:14px;margin:8px 8px 0 0;cursor:pointer}
a{color:#8ad8ff} .muted{color:#8b93bd;font-size:12.5px} .warn{color:#ffd08a}
table{width:100%;border-collapse:collapse;font-size:12px} td{padding:5px 6px;border-bottom:1px solid #2a3158}
pre{background:#0d1024;border:1px solid #39406e;border-radius:8px;padding:12px;font-size:11px;white-space:pre-wrap;word-break:break-all;max-height:360px;overflow:auto;color:#cfe3ff}
.bad{color:#ff9a9a}.good{color:#9ae6b4}
</style></head><body>
<h1>🧱 proot 网关 <span class="muted">r5d · 本地归档 · 只用免费模型</span></h1>

<div class="card">
  <div>网关：<code class="good">运行中</code> · <code>http://127.0.0.1:${port}/v1</code></div>
  <div>rootfs：<b class="${st.quad.ok ? 'good' : 'bad'}">${escapeHtml(st.phase)}</b> · ${escapeHtml(st.message)}</div>
  <div>目录：<code>${escapeHtml(st.rootfsDir || '(未就绪)')}</code></div>
  <div>opencode serve：<code>127.0.0.1:${escapeHtml(cfg.servePort)}</code> · token <code>${mask(cfg.servePassword)}</code> · pid ${st.pid || '—'}</div>
  <div style="margin-top:8px">${quadRows}</div>
  <div style="margin-top:6px">${warnRows}</div>
  <div class="muted" style="margin-top:8px">本机 API Key：<code>${mask(cfg.proxyKey)}</code>（RikkaHub 填这个，不是 OpenCode 账号 Key）</div>
</div>

<div class="card">
  <h2>📥 本地归档（你已编译出的 rootfs）</h2>
  <div class="muted">默认自动找 <code>/sdcard/Download/rootfs-arm64.tar.gz</code>，也支持 GitHub Artifact 的 <code>rootfs-arm64.zip</code>（会自动解出内层 tar.gz）。<b>不需要联网、不需要 key、不需要 OCGW 那个 APK。</b></div>
  <div style="margin-top:8px">${archRows}</div>
  <button type="button" onclick="doImport()">📥 一键导入并重启（用这份归档）</button>
  <div class="muted">导入会清除已解压的旧 rootfs 再重新解包，约 1~3 分钟；原归档文件不会被删除。</div>
</div>

<div class="card">
  <h2>🔬 一键自检（先点这个）</h2>
  <div class="muted">走完整链路：/api/config → /api/model → 建会话 → prompt → 取回复，逐步回报状态码。不用去 RikkaHub 连点。</div>
  <button type="button" onclick="runTest()">端到端自检</button>
  <button type="button" onclick="restart()">重启 CLI / 重新准备 rootfs</button>
  <pre id="out">尚未测试</pre>
</div>

<div class="card">
  <h2>① rootfs 来源（默认纯本地，已配好）</h2>
  <form method="POST" action="/config">
    <label>来源优先级</label>
    ${sel('rootfsSource', cfg.rootfsSource, [['local', 'local · 自动找本地归档（默认，推荐）'], ['auto', 'auto · 同 local（兼容旧配置）'], ['url', 'url · 强制在线下载（需自己填直链）'], ['dir', 'dir · 只用已解压目录']])}
    <label>已解压 rootfs 目录（四件套齐全就跳过下载；留空 = ofm-data/rootfs）</label>
    <input name="rootfsDir" value="${escapeHtml(cfg.rootfsDir)}" placeholder="留空 = ofm-data/rootfs">
    <label>本地归档路径（tar.gz；留空 = ofm-data/import/rootfs-arm64.tar.gz）</label>
    <input name="rootfsLocalPath" value="${escapeHtml(cfg.rootfsLocalPath)}" placeholder="/storage/emulated/0/Download/rootfs-arm64.tar.gz">
    <div class="muted" style="margin:8px 0">✅ 你已经用 GitHub Actions 编译出 <code>rootfs-arm64.tar.gz</code>，把它（或 Artifact 的 <code>rootfs-arm64.zip</code>）放到 <code>/sdcard/Download/</code> 即可，<b>不用重新生成、不用填 URL、不用重新压缩源码包</b>。本版默认 <code>local</code> 一次网络请求都不发。</div>
    <div class="warn" style="margin:8px 0">⚠ 原 <code>dormantxxy</code> release 已删除（404），下面默认 URL 和所有镜像都会 403，仅作历史参考；只有把来源切成 <code>url</code> 且填了你自己的直链时才会联网。</div>
    <div class="muted">也可用 adb / 文件管理器把 tar.gz 放到上面路径；若手上有解压好的 <code>rootfs/</code> 目录，直接填「已解压目录」会跳过下载与解包。</div>
    <label>下载直连 URL（默认这个已失效，仅保留作历史参考）</label>
    <input name="rootfsUrl" value="${escapeHtml(cfg.rootfsUrl)}">
    <label>URL 列表（每行一个完整地址，优先于上面单个 URL；填你 fork 生成的 release 地址或多个备份源）</label>
    <textarea name="rootfsUrls" placeholder="https://github.com/你的用户名/opencode-gateway-releases/releases/download/rootfs/rootfs-arm64.tar.gz">${escapeHtml(cfg.rootfsUrls)}</textarea>
    <label>加速镜像前缀（每行一个；仅对 github.com 直链叠加，测速取最快）</label>
    <textarea name="rootfsMirrors">${escapeHtml(cfg.rootfsMirrors)}</textarea>
    <label>CLI 在 rootfs 内的相对路径</label>
    <input name="opencodeBin" value="${escapeHtml(cfg.opencodeBin)}">

    <h2 style="margin-top:18px">② opencode serve</h2>
    <label>端口</label><input name="servePort" value="${escapeHtml(cfg.servePort)}">
    <div class="muted">⚠ 若同时装了 OpenCode Gateway APP（<code>com.ocgw.app</code>）且它在运行，会占掉 4317。请停止它，或把端口改成 <code>4319</code>。</div>
    <label>认证方式（就绪探测 401/403 时切另一个）</label>
    ${sel('apiStyle', cfg.apiStyle, [['query', 'query · ?auth_token=（旧版 / OCGW APK 同款）'], ['basic', 'basic · HTTP Basic opencode:<password>（v2）']])}
    <label>serve 密码（留空 = 随机生成并回写）</label>
    <input name="servePassword" type="password" placeholder="留空 = 不修改" autocomplete="off">
    <label>就绪探测次数</label><input name="readyTries" value="${escapeHtml(cfg.readyTries)}">
    <label>bind 到 /workspace 的手机目录（留空 = ofm-data/workspace）</label>
    <input name="bindWorkspace" value="${escapeHtml(cfg.bindWorkspace)}">
    <label>DNS（空格/逗号分隔；留空读 getprop net.dns*，再退国内公共 DNS）</label>
    <input name="dns" value="${escapeHtml(cfg.dns)}">
    <label>额外 proot 参数（插在 --kill-on-exit 前）</label>
    <input name="extraProotArgs" value="${escapeHtml(cfg.extraProotArgs)}">

    <h2 style="margin-top:18px">③ 免费模型过滤</h2>
    <label>免费位匹配正则</label>
    <input name="freeModelPattern" value="${escapeHtml(cfg.freeModelPattern)}">
    <label>强制保留 ID（每行一个）</label>
    <textarea name="modelAllowlist">${escapeHtml(cfg.modelAllowlist)}</textarea>
    <label>强制剔除 ID（每行一个）</label>
    <textarea name="modelDenylist">${escapeHtml(cfg.modelDenylist)}</textarea>
    <label>自定义模型 ID（填了完全覆盖 /api/model 清单）</label>
    <textarea name="customModels">${escapeHtml(cfg.customModels)}</textarea>

    <h2 style="margin-top:18px">④ 翻译与本机</h2>
    <label>等待回复超时(ms)</label><input name="promptTimeoutMs" value="${escapeHtml(cfg.promptTimeoutMs)}">
    <label>轮询间隔(ms)</label><input name="pollIntervalMs" value="${escapeHtml(cfg.pollIntervalMs)}">
    <label>限流重试次数</label><input name="rateRetries" value="${escapeHtml(cfg.rateRetries)}">
    <label>无 finish 时的文本稳定轮询次数</label><input name="stablePolls" value="${escapeHtml(cfg.stablePolls)}">
    <label>本机 API Key（RikkaHub 填；留空 = 不修改）</label>
    <input name="proxyKey" type="password" placeholder="留空 = 不修改" autocomplete="off">
    <button type="submit">保存配置（下次重启 CLI 生效）</button>
  </form>
  <div class="muted">改完 rootfs / serve 相关参数请点上面的「重启 CLI」。改「本机 API Key」后回主界面停止→启动网关刷新二维码。</div>
</div>

<div class="card">
  <h2>免费模型清单（${models.length}）</h2>
  <table><tr><th>ID</th><th>来源</th></tr>${rows || '<tr><td colspan="2">尚未加载，点「端到端自检」或<a href="/v1/models?refresh=1">刷新</a></td></tr>'}</table>
</div>

<div class="card">
  <h2>opencode.log 尾部</h2>
  <pre>${escapeHtml(st.logTail)}</pre>
</div>

<div class="card warn">
  <b>必须知道的五件事：</b><br>
  1. <b>APK 不含任何二进制</b>。把已编译的 <code>rootfs-arm64.tar.gz</code> 放到 <code>/sdcard/Download/</code>，点「📥 一键导入」即可；四件套不齐就起不来。<br>
  2. <b>本版只走免费模型</b>，没有任何付费 / Go 通道，失败也<b>不会</b>自动降级花钱。免费层的凭据不是账号 Key。<br>
  3. <b>必须是 v2 CLI</b>：v1/0.x 已不支持免费模型，会 426→429。rootfs 里的 CLI 版本过旧请换 rootfs。<br>
  4. <b>429 是服务端共享额度窗口</b>，不是配置错。所有免费模型都 429 时等窗口 / 换模型，别连续重试；<code>403 FreeTierError</code> 才是客户端形状门。<br>
  5. <b>Android 10+ 可能禁止从 app 私有目录执行 ELF</b>。本工程已把 <code>targetSdk</code> 固定为 28（与原版一致），正常不会遇到 EACCES；详见 PROOT_README.md。<br>
  6. <b>r5d 的 /api/* 翻译已对齐实测跑通的 OCGW 实现</b>：v2 prompt 形状、finish / error 判定、限流重试、干净的 proot env。
</div>
<script>
function runTest(){
  var o=document.getElementById('out');o.textContent='请求中…（最多 '+(parseInt(${JSON.stringify(cfg.promptTimeoutMs)}||'120000')/1000)+' 秒）';
  fetch('/selftest').then(function(r){return r.json()}).then(function(j){
    o.textContent=j.verdict+'\n\n【配置快照】\n'+JSON.stringify(j.sent,null,2)+(j.upstream?'\n\n【回复/错误】\n'+j.upstream:'');
  }).catch(function(e){o.textContent='自检请求失败：'+e});
}
function doImport(){
  var o=document.getElementById('out');o.textContent='正在导入本地归档并重新解包…（100 MB+，约 1~3 分钟，请勿切走）';
  fetch('/rootfs/import',{method:'POST'}).then(function(r){return r.json()}).then(function(j){
    o.textContent=(j.ok?'✅ 导入并启动成功':'❌ 导入失败')+'\n\n'+JSON.stringify(j,null,2);
  }).catch(function(e){o.textContent='导入请求失败：'+e});
}
function restart(){
  var o=document.getElementById('out');o.textContent='正在重启 CLI…（首次可能要解包 100 MB+，请等）';
  fetch('/rootfs/restart',{method:'POST'}).then(function(r){return r.json()}).then(function(j){
    o.textContent=(j.ok?'✅ ':'❌ ')+JSON.stringify(j,null,2);
  }).catch(function(e){o.textContent='重启请求失败：'+e});
}
</script>
</body></html>`;
}

// ------------------------------------------------------------------ HTTP 服务
function readBody(req) {
    return new Promise((resolve, reject) => {
        const chunks = [];
        let size = 0;
        req.on('data', (c) => {
            size += c.length;
            if (size > MAX_BODY) { reject(new Error('body too large')); req.destroy(); return; }
            chunks.push(c);
        });
        req.on('end', () => resolve(Buffer.concat(chunks)));
        req.on('error', reject);
    });
}

function authorized(req) {
    const a = req.headers.authorization || '';
    return cfg.proxyKey === '' || a === 'Bearer ' + cfg.proxyKey;
}

/** 一键导入：探测本地归档 → 清掉旧 rootfs → 强制重新解包 → 拉起 CLI。 */
async function doImport() {
    const found = rootfs.findLocalArchive(cfg);
    if (!found || !found.file) {
        return { ok: false, reason: '未找到本地归档', probed: (found && found.seen) || [],
                 hint: '把已编译的 rootfs-arm64.tar.gz（或 rootfs-arm64.zip）放到 /sdcard/Download/ 后重试。' };
    }
    rootfs.stop();
    rootfs.invalidateRootfs(cfg);
    const r = await doRestart();
    return Object.assign({ archive: { file: found.file, bytes: found.bytes,
                                     unwrapped: found.unwrapped || null } }, r);
}

async function doRestart() {
    rootfs.stop();
    const r = await rootfs.start(Object.assign({}, cfg, {
        dataDir: optsRef.dataDir,
        gatewayPort: serverRef && serverRef.address() ? serverRef.address().port : optsRef.port,
        log: optsRef.log
    }));
    // 回写随机生成的 servePassword，避免每次重启都换
    if (r.ok && !cfg.servePassword) {
        saveConfig(optsRef.dataDir, { servePassword: r.token });
    }
    modelCache = null; modelCacheAt = 0;
    return r;
}

function start(opts) {
    optsRef = opts || {};
    const dataDir = optsRef.dataDir || process.cwd();
    cfg = loadConfig(dataDir);
    rootfs.setDataDir(dataDir);
    rootfs.setLog((m) => { if (optsRef.log) optsRef.log(m); });

    const server = http.createServer(async (req, res) => {
        try {
            const u = new URL(req.url, 'http://' + (req.headers.host || '127.0.0.1'));
            const p = u.pathname.replace(/\/+$/, '') || '/';
            if (req.method === 'OPTIONS') return sendJson(res, 204, {});

            if (req.method === 'GET' && p === '/health') {
                const st = rootfs.status();
                return sendJson(res, 200, {
                    ok: true, service: 'opencode-proot-gateway', version: 'r5d-local-archive',
                    mode: 'free-models-only', rootfs: st.phase, rootfsMessage: st.message,
                    quad: st.quad, warnings: st.warnings, servePort: Number(cfg.servePort) || 4317,
                    cliPid: st.pid, cliVersion: st.cliVersion,
                    models: modelCache ? modelCache.data.length : 0,
                    bootError: bootError,
                    note: 'all upstream requests are made by the official OpenCode CLI process inside proot; no anonymous direct HTTP, no paid fallback'
                });
            }

            if (req.method === 'GET' && p === '/selftest') return sendJson(res, 200, await selfTest());

            if (req.method === 'POST' && p === '/rootfs/restart') return sendJson(res, 200, await doRestart());

            if (req.method === 'POST' && p === '/rootfs/import') return sendJson(res, 200, await doImport());

            if (req.method === 'GET' && (p === '/' || p === '/index.html')) {
                const body = managePage(server.address() ? server.address().port : optsRef.port);
                res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Content-Length': Buffer.byteLength(body) });
                return res.end(body);
            }

            if (req.method === 'POST' && p === '/config') {
                const raw = (await readBody(req)).toString('utf8');
                let next = {};
                if (raw.trim().startsWith('{')) next = safeJson(raw) || {};
                else next = Object.fromEntries(new URLSearchParams(raw).entries());
                const merged = Object.assign({}, cfg);
                const CLEARABLE = {
                    rootfsMirrors: 1, rootfsUrls: 1, modelAllowlist: 1, modelDenylist: 1, customModels: 1,
                    rootfsLocalPath: 1, rootfsDir: 1, dns: 1, extraProotArgs: 1, bindWorkspace: 1, rateRetries: 1, stablePolls: 1
                };
                for (const k of Object.keys(DEFAULTS)) {
                    const v = next[k];
                    if (typeof DEFAULTS[k] === 'boolean') {
                        if (v !== undefined) merged[k] = parseBool(v, cfg[k]);
                    } else if (typeof v === 'string') {
                        if (v === '' && !CLEARABLE[k]) continue;
                        if (v.includes('****')) continue;
                        merged[k] = v;
                    }
                }
                saveConfig(dataDir, merged);
                if (optsRef.onKeyChanged) optsRef.onKeyChanged(cfg.proxyKey);
                if (optsRef.log) optsRef.log('配置已保存：source=' + cfg.rootfsSource + ' port=' + cfg.servePort + ' apiStyle=' + cfg.apiStyle);
                res.writeHead(303, { Location: '/' });
                return res.end();
            }

            if (!authorized(req)) return sendJson(res, 401, { error: 'unauthorized' });

            if (req.method === 'GET' && (p === '/v1/models' || p === '/models')) {
                return sendJson(res, 200, await listModels(u.searchParams.get('refresh') === '1'));
            }

            if (req.method === 'POST' && (p === '/v1/chat/completions' || p === '/chat/completions')) {
                const clientBody = safeJson((await readBody(req)).toString('utf8'));
                if (!clientBody || !Array.isArray(clientBody.messages)) {
                    return sendJson(res, 400, { error: { message: 'invalid chat.completions body: messages required' } });
                }
                const st = rootfs.status();
                if (!st.quad.ok || st.phase === 'failed') {
                    return bridgeError(res, { error: 'opencode serve 未就绪：' + st.message, steps: [] });
                }
                const out = await chatViaServe(clientBody);
                if (!out.ok) return bridgeError(res, out);
                if (clientBody.stream === true) return sendSseCompletion(res, out.model, out.reply);
                return sendJson(res, 200, completion('chatcmpl-' + crypto.randomBytes(8).toString('hex'), out.model, out.reply));
            }

            return sendJson(res, 404, {
                error: 'not_found',
                routes: ['GET /health', 'GET /selftest', 'POST /rootfs/import', 'POST /rootfs/restart', 'GET /v1/models', 'POST /v1/chat/completions', 'GET /', 'POST /config']
            });
        } catch (e) {
            if (optsRef.log) optsRef.log('请求异常 ' + req.method + ' ' + req.url + '：' + (e && e.message || e));
            if (!res.headersSent) return sendJson(res, 502, { error: 'proxy_error', message: String((e && e.message) || e) });
            try { res.end(); } catch (_) {}
        }
    });

    serverRef = server;
    let port = Number(optsRef.port) || 18900;
    const host = '127.0.0.1';
    let tries = 0;
    server.on('error', (e) => {
        if (e.code === 'EADDRINUSE' && tries++ < 12) {
            port += 1;
            if (optsRef.log) optsRef.log('端口被占用，顺延到 ' + port);
            setTimeout(() => server.listen(port, host), 200);
        } else {
            if (optsRef.log) optsRef.log('监听失败：' + (e && e.message || e));
            if (optsRef.onFatal) optsRef.onFatal(String(e && e.message || e));
        }
    });

    server.listen(port, host, async () => {
        const actual = server.address().port;
        if (optsRef.log) optsRef.log('网关已监听 http://' + host + ':' + actual + '/v1（r5d 本地归档 / 只用免费模型）');
        if (optsRef.onListening) optsRef.onListening(actual);

        // 自动拉起 proot → opencode serve。失败不阻塞网关，管理页会显示原因。
        if (cfg.autoStart) {
            try {
                const r = await rootfs.start(Object.assign({}, cfg, {
                    dataDir,
                    gatewayPort: server.address() ? server.address().port : actual,
                    log: optsRef.log
                }));
                if (r.ok) {
                    if (!cfg.servePassword) saveConfig(dataDir, { servePassword: r.token });
                    if (optsRef.log) optsRef.log('READY · opencode serve 127.0.0.1:' + r.port + ' · pid=' + r.pid + (r.version ? ' · v' + r.version : ''));
                    await listModels(true).catch(() => null);
                } else {
                    bootError = r.reason || r.message || '未知原因';
                    if (optsRef.log) optsRef.log('CLI 未就绪：' + bootError);
                }
            } catch (e) {
                bootError = String(e && e.message || e);
                if (optsRef.log) optsRef.log('CLI 启动异常：' + bootError);
            }
        }
    });

    // Node 进程退出时清理 proot 子进程
    process.on('exit', () => { try { rootfs.stop(); } catch (_) {} });
    return server;
}

module.exports = { start, listModels, config: () => cfg, rootfsStatus: () => rootfs.status() };
