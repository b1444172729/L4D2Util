'use strict';
/**
 * oc-proxy.cjs —— OpenCode 免费模型 → OpenAI 兼容本地网关（Android 版）
 *
 * 由 bootstrap.cjs 以 require('./oc-proxy.cjs') 加载，跑在 APP 自带的
 * nodejs-mobile (Node 22) 里，只监听 127.0.0.1，零 npm 依赖。
 *
 * 对外路由（与原壳 HealthProbe / RikkaHubHandoff 完全对齐）：
 *   GET  /health                → 200 JSON（探活，不鉴权）
 *   GET  /v1/models             → OpenAI 形状的模型清单（Bearer 鉴权）
 *   POST /v1/chat/completions   → 转发到 opencode.ai（Bearer 鉴权，SSE/JSON 双向适配）
 *   GET  /                      → 管理页（在这里自己填 OpenCode Console Key）
 *   POST /config                → 保存到私有目录 oc-config.json（0600）
 *
 * ── 三条调用路径 ────────────────────────────────────────────────
 *  mode=free    仅走免费层。伪造 OpenCode 客户端指纹（UA / x-opencode-session /
 *               tools / stream:true / Bearer public）。不需要任何 key。
 *  mode=console 用管理页填写的 Console API Key 走官方付费/Go 网关，
 *               诚实 UA + 稳定 session，按官方 Harnesses 文档调用付费模型。
 *  mode=auto    默认。免费优先；遇到 403 FreeTierError / 429 限流且已填
 *               Console Key 时，自动把模型 ID 映射成付费 ID 重发一次。
 *
 * ⚠️ 官方明确写着「Free-tier chat models are only available from within OpenCode」，
 *    免费层不是对外 API。本网关属于客户端指纹桥接，规则由服务端动态调整，
 *    随时可能失效；生产/长期使用请用 Console Key + 付费模型。
 *    详见 OPENCODE_README.md。
 */

const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// ------------------------------------------------------------------ 默认配置
// 说明：APP 的 assets 不加密。这里【不再内置任何第三方真实凭据】，
// OpenCode Console Key 一律由用户在管理页自己填写，落盘到私有目录。
// 本机 proxyKey 沿用旧版默认值，避免用户已配好的 RikkaHub 需要重填；可随时改。
const DEFAULTS = {
    consoleKey: '',
    proxyKey: 'Rikka-2026-CF-Proxy-Key-8f3b',
    mode: 'auto',                        // auto | free | console
    upstream: 'opencode.ai',             // 只填 host，固定 https:443
    freePath: '/inference/openai/v1/chat/completions',
    consolePath: '/inference/openai/v1/chat/completions', // Go 订阅改成 /inference/go/openai/v1/chat/completions
    modelsPath: '/inference/openai/v1/models',
    ua: 'opencode/1.18.31',
    consoleUa: 'RikkaHub-OpenCode-Gateway/1.0',
    client: 'cli',                       // cli | desktop
    sidStyle: 'desc',                    // desc | random
    hideRegionBlocked: true,
    injectTools: true,
    customModels: '',                    // 每行一个模型 ID，覆盖内置清单
    fallbackMap: '',                     // 每行 "free-id=pay-id"
    extraHeaders: ''                     // JSON 对象，追加/覆盖请求头
};

const MAX_BODY = 20 * 1024 * 1024;
const CACHE_MS = 30 * 60 * 1000;
const SESSION_TTL = 30 * 60 * 1000;

// 免费层硬性要求：tools 数组里必须出现这些原生工具名（社区实测内容无关）。
// 若上游某天改成校验完整定义，可在管理页 extraHeaders / 源码里替换本数组。
const OPENCODE_TOOLS = [
    {
        type: 'function',
        function: {
            name: 'bash',
            description: 'Execute a shell command',
            parameters: { type: 'object', properties: { command: { type: 'string' } }, required: ['command'] }
        }
    },
    {
        type: 'function',
        function: {
            name: 'read',
            description: 'Read a file',
            parameters: { type: 'object', properties: { filePath: { type: 'string' } }, required: ['filePath'] }
        }
    },
    {
        type: 'function',
        function: {
            name: 'glob',
            description: 'Find files by pattern',
            parameters: { type: 'object', properties: { pattern: { type: 'string' } }, required: ['pattern'] }
        }
    },
    {
        type: 'function',
        function: {
            name: 'grep',
            description: 'Search file contents',
            parameters: { type: 'object', properties: { pattern: { type: 'string' } }, required: ['pattern'] }
        }
    }
];

// 注入 tools 只是为了满足网关校验，并不想让模型真的去调工具。
const TOOL_GUARD = 'You are accessed through a compatible chat client. ' +
    'Do NOT call any tools. Always answer with plain text in the message content.';

// 2026-11-11 抓自 opencode.ai/docs/zen（中英两版合并）。
// 免费位轮换极快，这份清单只是离线兜底：联网时 /v1/models 会优先取上游清单，
// 也可在管理页「自定义模型 ID」里整份覆盖。
const BUILTIN_MODELS = [
    ['glm-5.3-flash-free', 'GLM-5.3-Flash Free', true, false, '零留存 / 不用于训练'],
    ['deepseek-v4.1-flash-free', 'DeepSeek V4.1 Flash Free', true, false, '零留存 / 不用于训练 / 200K 上下文'],
    ['minimax-m3.1-flash-free', 'MiniMax M3.1 Flash Free', true, false, '零留存 / 不用于训练'],
    ['space-bunny-free', 'Space Bunny Free', true, false, '零留存 / 隐身模型'],
    ['longcat-2.5-preview-free', 'LongCat 2.5 Preview Free', true, false, '零留存 / 托管在中国'],
    ['longcat-2.5-free', 'LongCat 2.5 Free', true, false, '零留存 / 100 次请求每天'],
    ['exo-free', 'Exo Free', null, false, '收集反馈改进模型'],
    ['mimo-v2.6-flash-free', 'MiMo-V2.6-Flash Free', null, false, '收集反馈改进模型'],
    ['mimo-v2.5-free', 'MiMo-V2.5 Free', null, false, '收集反馈改进模型'],
    ['nemotron-3-ultra-free', 'Nemotron 3 Ultra Free', null, false, 'NVIDIA 试用条款，勿提交机密'],
    ['nemotron-3.5-lightning-free', 'Nemotron 3.5 Lightning Free', null, false, 'NVIDIA 试用条款'],
    ['nemotron-3.5-super-vl-free', 'Nemotron 3.5 Super VL Free', null, false, 'NVIDIA 试用条款'],
    ['big-pickle', 'Big Pickle', null, false, '隐身模型；数据可能用于改进模型'],
    ['iceman-free', 'Iceman Free', null, false, '隐身模型；数据可能用于改进模型'],
    ['flint-40b-free', 'Flint 40B Free', null, false, '保留 30 天'],
    ['inkling-2-small-free', 'Inkling 2 Small Free', null, false, '会留存并可能用于训练；EU 等地不可用'],
    ['beam-free', 'Beam Free', null, true, '不向中国大陆/港澳提供；保留 30 天'],
    ['ll-alpha-free', 'LL Alpha Free', null, false, '隐身模型'],
    ['muse-spark-1.3-contributor-free', 'Muse Spark 1.3 Contributor Free', null, false, '收集反馈改进模型'],
    ['jev-1.13-free', 'Jev 1.13 Free', null, false, '结构化决策用途']
];

let cfg = Object.assign({}, DEFAULTS);
let modelCache = null;
let modelCacheAt = 0;
let optsRef = {};
const sessionCache = new Map();
let sidCounter = 0;

// ------------------------------------------------------------------ 配置读写
function loadConfig(dataDir) {
    const out = Object.assign({}, DEFAULTS);
    try {
        const f = path.join(dataDir, 'oc-config.json');
        if (fs.existsSync(f)) {
            const o = JSON.parse(fs.readFileSync(f, 'utf8'));
            for (const k of Object.keys(DEFAULTS)) {
                const v = o[k];
                const def = DEFAULTS[k];
                if (typeof def === 'boolean') {
                    if (typeof v === 'boolean') out[k] = v;
                    else if (v === '1' || v === 0 || v === '0' || v === 1) out[k] = (v === true || v === 1 || v === '1');
                } else if (typeof v === 'string') {
                    out[k] = v;
                }
            }
        }
    } catch (_) {}
    // 环境变量优先级最高（C 胶水目前不设置这些，保留给桌面端/调试用）
    const envMap = {
        OC_CONSOLE_KEY: 'consoleKey', OC_PROXY_KEY: 'proxyKey', OC_MODE: 'mode',
        OC_UPSTREAM: 'upstream', OC_FREE_PATH: 'freePath', OC_CONSOLE_PATH: 'consolePath',
        OC_UA: 'ua', OC_CLIENT: 'client'
    };
    for (const [e, k] of Object.entries(envMap)) {
        if (process.env[e] && process.env[e].trim()) out[k] = process.env[e].trim();
    }
    return out;
}

function saveConfig(dataDir, next) {
    const f = path.join(dataDir, 'oc-config.json');
    const tmp = f + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(next, null, 2), { mode: 0o600 });
    // 少数文件系统会忽略 writeFile 的 mode，落盘后再显式收紧一次
    try { fs.chmodSync(tmp, 0o600); } catch (_) {}
    fs.renameSync(tmp, f);
    try { fs.chmodSync(f, 0o600); } catch (_) {}
    cfg = Object.assign({}, cfg, next);
    modelCache = null;
    modelCacheAt = 0;
}

function mask(s) {
    if (!s) return '(未设置)';
    if (s.length <= 10) return '****';
    return s.slice(0, 5) + '****' + s.slice(-4);
}

function parseBool(v, fallback) {
    if (v === '1' || v === 1 || v === true || v === 'true') return true;
    if (v === '0' || v === 0 || v === false || v === 'false') return false;
    return fallback;
}

// ------------------------------------------------------------------ 小工具
function stripPrefix(id) {
    return String(id || '').trim().replace(/^opencode\//i, '');
}

function pretty(id) {
    const s = stripPrefix(id).split('/').pop() || id;
    return s.replace(/[-_]/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
}

function safeJson(raw) {
    try { return JSON.parse(raw); } catch (_) { return null; }
}

function extraHeaders() {
    if (!cfg.extraHeaders.trim()) return {};
    try {
        const o = JSON.parse(cfg.extraHeaders);
        return (o && typeof o === 'object' && !Array.isArray(o)) ? o : {};
    } catch (_) { return {}; }
}

// ------------------------------------------------------------------ session 头
// OpenCode 的 descending identifier：ses_ + 12 位 hex(~(ts*4096 + counter) 低 48 位)
// + 14 位 base62。低 12 位编码 0xfff-counter，counter 需 <= 63。
// 网关按「首条 user 消息 + 模型」做哈希，让同一段对话复用同一个 ID（利于路由/cache）。
const B62 = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';

function newSessionId() {
    const c = sidCounter++ & 63;
    const m = (1n << 48n) - 1n;
    let head;
    if (cfg.sidStyle === 'random') {
        head = crypto.randomBytes(6).toString('hex');
    } else {
        const raw = (BigInt(Date.now()) * 4096n + BigInt(0xfff - c)) & m;
        head = (~raw & m).toString(16).padStart(12, '0');
    }
    const tailLen = cfg.sidStyle === 'random' ? 16 : 14;
    let tail = '';
    for (let i = 0; i < tailLen; i++) tail += B62[crypto.randomInt(0, 62)];
    return 'ses_' + head + tail;
}

function sessionFor(body) {
    const msgs = Array.isArray(body.messages) ? body.messages : [];
    const first = msgs.find((m) => m && m.role === 'user');
    const seed = JSON.stringify(first && first.content != null ? first.content : '') + '|' + String(body.model || '');
    const key = crypto.createHash('sha1').update(seed).digest('hex');
    const now = Date.now();
    const hit = sessionCache.get(key);
    if (hit && now - hit.at < SESSION_TTL) return hit.id;
    const id = newSessionId();
    sessionCache.set(key, { id: id, at: now });
    if (sessionCache.size > 256) {
        for (const [k, v] of sessionCache) {
            if (now - v.at > SESSION_TTL) sessionCache.delete(k);
        }
    }
    return id;
}

// ------------------------------------------------------------------ 上游请求
function upstreamRequest(method, pathname, headers, body, timeoutMs) {
    return new Promise((resolve, reject) => {
        const req = https.request({
            host: cfg.upstream,
            port: 443,
            method: method,
            path: pathname,
            headers: headers,
            timeout: timeoutMs || 120000
        }, resolve);
        req.on('timeout', () => req.destroy(new Error('upstream timeout')));
        req.on('error', reject);
        if (body) req.end(body); else req.end();
    });
}

function upstreamGet(pathname, headers) {
    return new Promise((resolve) => {
        upstreamRequest('GET', pathname, headers, null, 8000)
            .then(async (res) => resolve({ status: res.statusCode, raw: await collect(res) }))
            .catch(() => resolve({ status: 0, raw: '' }));
    });
}

function collect(res) {
    return new Promise((resolve, reject) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
        res.on('error', reject);
    });
}

function freeHeaders(bodyLen, sid) {
    return Object.assign({
        'Content-Type': 'application/json',
        'Content-Length': bodyLen,
        'Accept': 'text/event-stream, application/json',
        'User-Agent': cfg.ua,
        'x-opencode-client': cfg.client,
        'x-opencode-session': sid,
        'x-opencode-session-id': sid,
        'x-session-id': sid,
        'x-session-affinity': sid,
        'Authorization': 'Bearer public'
    }, extraHeaders());
}

function consoleHeaders(bodyLen, sid) {
    return Object.assign({
        'Content-Type': 'application/json',
        'Content-Length': bodyLen,
        'Accept': 'text/event-stream, application/json',
        'User-Agent': cfg.consoleUa || 'RikkaHub-OpenCode-Gateway/1.0',
        'x-opencode-client': 'gateway',
        'x-opencode-session': sid,
        'x-opencode-session-id': sid,
        'x-session-id': sid,
        'x-session-affinity': sid,
        'Authorization': 'Bearer ' + cfg.consoleKey
    }, extraHeaders());
}

// ------------------------------------------------------------------ 模型清单
function isRegionBlocked(id) {
    // Beam Free 明确排除中国大陆/香港/澳门；其余地区排除项不影响国内用户
    return /beam/i.test(String(id));
}

function builtinModels() {
    return BUILTIN_MODELS.map(([id, name, zero, blocked, note]) => ({
        id: id,
        object: 'model',
        created: 0,
        owned_by: 'opencode',
        name: name,
        metadata: {
            free: true,
            zero_retention: zero,
            region_blocked: !!blocked,
            note: note,
            source: 'builtin'
        }
    }));
}

function parseCustomModels(text) {
    return text.split(/\r?\n/)
        .map((s) => s.trim())
        .filter((s) => s && !s.startsWith('#'))
        .map((id) => ({
            id: stripPrefix(id),
            object: 'model',
            created: 0,
            owned_by: 'opencode',
            name: pretty(id),
            metadata: { free: true, zero_retention: null, region_blocked: isRegionBlocked(id), note: '管理页自定义', source: 'custom' }
        }));
}

async function fetchUpstreamModels() {
    const sid = newSessionId();
    const headers = cfg.mode === 'console' && cfg.consoleKey
        ? consoleHeaders(0, sid)
        : freeHeaders(0, sid);
    delete headers['Content-Length'];
    const r = await upstreamGet(cfg.modelsPath, headers);
    if (r.status !== 200) return null;
    const j = safeJson(r.raw);
    const arr = j && (Array.isArray(j.data) ? j.data : (Array.isArray(j) ? j : null));
    if (!arr || !arr.length) return null;
    const out = arr.map((m) => {
        const id = stripPrefix(m.id || m.name || '');
        if (!id) return null;
        const zeroPrice = !!(m.pricing && (m.pricing.prompt === 0 || m.pricing.input === 0)) ||
            m.input_price === 0 || m.cost === 0;
        return {
            id: id,
            object: 'model',
            created: Number(m.created) || 0,
            owned_by: 'opencode',
            name: m.name || pretty(id),
            metadata: {
                free: /free/i.test(id) || zeroPrice,
                zero_retention: null,
                region_blocked: isRegionBlocked(id),
                note: '来自上游 ' + cfg.modelsPath,
                source: 'upstream'
            }
        };
    }).filter(Boolean);
    return out.length ? out : null;
}

async function listModels(force) {
    if (!force && modelCache && Date.now() - modelCacheAt < CACHE_MS) return modelCache;
    let data = null;
    if (cfg.customModels.trim()) {
        data = parseCustomModels(cfg.customModels);
    } else {
        data = await fetchUpstreamModels();
        if (!data || !data.length) data = builtinModels();
    }
    if (cfg.mode !== 'console') {
        // 免费模式只暴露免费位，避免用户误选付费模型
        data = data.filter((m) => m.metadata && m.metadata.free);
    }
    if (cfg.hideRegionBlocked) {
        data = data.filter((m) => !(m.metadata && m.metadata.region_blocked));
    }
    modelCache = { object: 'list', data: data, total: data.length };
    modelCacheAt = Date.now();
    if (optsRef.log) optsRef.log('模型清单已刷新：' + data.length + ' 个（来源 ' + (data[0] && data[0].metadata.source || 'custom') + '）');
    return modelCache;
}

// ------------------------------------------------------------------ 请求体构造
function buildFreeBody(clientBody, model) {
    const up = Object.assign({}, clientBody);
    up.model = model;
    up.stream = true;                 // 免费层硬性要求，false 直接 403
    delete up.stream_options;         // 聚合由本网关自己做
    delete up.tool_choice;            // 不强制工具调用
    if (cfg.injectTools) up.tools = OPENCODE_TOOLS;
    const msgs = Array.isArray(up.messages) ? up.messages.slice() : [];
    msgs.unshift({ role: 'system', content: TOOL_GUARD });
    up.messages = msgs;
    return JSON.stringify(up);
}

function buildConsoleBody(clientBody, model) {
    const up = Object.assign({}, clientBody);
    up.model = model;
    return JSON.stringify(up);
}

function parseFallbackMap() {
    const map = {};
    for (const line of cfg.fallbackMap.split(/\r?\n/)) {
        const s = line.trim();
        if (!s || s.startsWith('#')) continue;
        const i = s.indexOf('=');
        if (i > 0) map[stripPrefix(s.slice(0, i).trim())] = stripPrefix(s.slice(i + 1).trim());
    }
    return map;
}

function fallbackModel(id) {
    const clean = stripPrefix(id);
    const map = parseFallbackMap();
    if (map[clean]) return map[clean];
    if (map[id]) return map[id];
    return clean.replace(/-free$/, '') || clean;
}

function shouldFallback(status, raw) {
    return status === 403 || status === 429 || status === 426 ||
        /FreeTierError|FreeUsageLimitError|abusive traffic|only be used from within OpenCode/i.test(String(raw));
}

// ------------------------------------------------------------------ 响应适配
function aggregateSse(raw, model) {
    let content = '';
    let reasoning = '';
    let usage = null;
    let finish = 'stop';
    let id = 'chatcmpl-' + crypto.randomBytes(8).toString('hex');
    for (const line of String(raw).split(/\r?\n/)) {
        if (!line.startsWith('data:')) continue;
        const data = line.slice(5).trim();
        if (!data || data === '[DONE]') continue;
        const o = safeJson(data);
        if (!o) continue;
        if (o.id) id = o.id;
        if (o.usage) usage = o.usage;
        const ch = o.choices && o.choices[0];
        if (!ch) continue;
        if (ch.finish_reason) finish = ch.finish_reason;
        const d = ch.delta || ch.message || {};
        if (typeof d.content === 'string') content += d.content;
        else if (Array.isArray(d.content)) {
            for (const part of d.content) {
                if (part && typeof part.text === 'string') content += part.text;
            }
        }
        if (typeof d.reasoning_content === 'string') reasoning += d.reasoning_content;
        else if (typeof d.reasoning === 'string') reasoning += d.reasoning;
    }
    const message = { role: 'assistant', content: content };
    if (reasoning) message.reasoning_content = reasoning;
    return {
        id: id,
        object: 'chat.completion',
        created: Math.floor(Date.now() / 1000),
        model: model,
        choices: [{ index: 0, message: message, finish_reason: finish }],
        usage: usage || { prompt_tokens: 0, completion_tokens: 0, total_tokens: 0 }
    };
}

function sendSse(res, status, obj) {
    res.writeHead(status, {
        'Content-Type': 'text/event-stream; charset=utf-8',
        'Cache-Control': 'no-cache, no-transform',
        'Connection': 'keep-alive',
        'X-Accel-Buffering': 'no',
        'Access-Control-Allow-Origin': '*'
    });
    res.write('data: ' + JSON.stringify(obj) + '\n\n');
    res.write('data: [DONE]\n\n');
    res.end();
}

async function relay(res, upRes, wantsStream, model) {
    const ct = upRes.headers['content-type'] || '';
    const isSse = /text\/event-stream/i.test(ct);
    if (wantsStream && isSse) {
        res.writeHead(upRes.statusCode, {
            'Content-Type': 'text/event-stream; charset=utf-8',
            'Cache-Control': 'no-cache, no-transform',
            'Connection': 'keep-alive',
            'X-Accel-Buffering': 'no',
            'Access-Control-Allow-Origin': '*'
        });
        return upRes.pipe(res);
    }
    const raw = await collect(upRes);
    if (wantsStream && !isSse) {
        const obj = safeJson(raw) || { error: { message: 'upstream returned non-JSON: ' + raw.slice(0, 200) } };
        return sendSse(res, upRes.statusCode, obj);
    }
    if (!wantsStream && isSse) {
        return sendJson(res, upRes.statusCode, aggregateSse(raw, model));
    }
    res.writeHead(upRes.statusCode, {
        'Content-Type': ct || 'application/json; charset=utf-8',
        'Content-Length': Buffer.byteLength(raw),
        'Access-Control-Allow-Origin': '*'
    });
    return res.end(raw);
}

function sendUpstreamError(res, status, raw) {
    const ct = /^\s*\{/.test(raw) ? 'application/json; charset=utf-8' : 'text/plain; charset=utf-8';
    const body = ct.startsWith('application/json')
        ? raw
        : JSON.stringify({ error: { message: 'OpenCode 上游 HTTP ' + status, upstream: raw.slice(0, 800) } });
    res.writeHead(status, {
        'Content-Type': ct.startsWith('application/json') ? ct : 'application/json; charset=utf-8',
        'Content-Length': Buffer.byteLength(body),
        'Access-Control-Allow-Origin': '*'
    });
    return res.end(body);
}

// ------------------------------------------------------------------ 分发
async function dispatchConsole(res, clientBody, wantsStream) {
    const sid = sessionFor(clientBody);
    const model = fallbackModel(clientBody.model || '');
    const body = buildConsoleBody(clientBody, model);
    const upRes = await upstreamRequest('POST', cfg.consolePath, consoleHeaders(Buffer.byteLength(body), sid), body, 120000);
    if (upRes.statusCode >= 400) {
        const raw = await collect(upRes);
        if (optsRef.log) optsRef.log('Console 网关 HTTP ' + upRes.statusCode + '：' + raw.slice(0, 300));
        return sendUpstreamError(res, upRes.statusCode, raw);
    }
    return relay(res, upRes, wantsStream, model);
}

async function dispatchFree(res, clientBody, wantsStream) {
    const sid = sessionFor(clientBody);
    const model = stripPrefix(clientBody.model || '') || (BUILTIN_MODELS[0] && BUILTIN_MODELS[0][0]);
    const body = buildFreeBody(clientBody, model);
    const upRes = await upstreamRequest('POST', cfg.freePath, freeHeaders(Buffer.byteLength(body), sid), body, 120000);
    if (upRes.statusCode >= 400) {
        const raw = await collect(upRes);
        if (optsRef.log) optsRef.log('免费层 HTTP ' + upRes.statusCode + '：' + raw.slice(0, 300));
        if (cfg.mode === 'auto' && cfg.consoleKey && shouldFallback(upRes.statusCode, raw)) {
            if (optsRef.log) optsRef.log('免费层被拒，已填 Console Key → 自动降级到付费/Go 网关');
            return dispatchConsole(res, clientBody, wantsStream);
        }
        return sendUpstreamError(res, upRes.statusCode, raw);
    }
    return relay(res, upRes, wantsStream, model);
}

// ------------------------------------------------------------------ HTTP 工具
function sendJson(res, status, obj, extra) {
    const body = JSON.stringify(obj);
    res.writeHead(status, Object.assign({
        'Content-Type': 'application/json; charset=utf-8',
        'Content-Length': Buffer.byteLength(body),
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': '*',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
    }, extra || {}));
    res.end(status === 204 ? undefined : body);
}

function readBody(req) {
    return new Promise((resolve, reject) => {
        const chunks = [];
        let size = 0;
        req.on('data', (c) => {
            size += c.length;
            if (size > MAX_BODY) { reject(new Error('body too large')); req.destroy(); return; }
            chunks.push(c);
        });
        req.on('end', () => resolve(Buffer.concat(chunks)));
        req.on('error', reject);
    });
}

function authorized(req) {
    const a = req.headers.authorization || '';
    return cfg.proxyKey === '' || a === 'Bearer ' + cfg.proxyKey;
}

function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

// ------------------------------------------------------------------ 管理页
function managePage(port) {
    const models = modelCache ? modelCache.data : [];
    const rows = models.slice(0, 40).map((m) =>
        '<tr><td><code>' + escapeHtml(m.id) + '</code></td><td>' + escapeHtml(m.name) + '</td><td>' +
        (m.metadata.zero_retention === true ? '✅ 零留存' : (m.metadata.zero_retention === null ? '—' : '⚠️')) +
        '</td><td>' + escapeHtml(m.metadata.note || '') + '</td></tr>'
    ).join('');
    const sel = (name, cur, options) => '<select name="' + name + '">' + options.map(([v, t]) =>
        '<option value="' + v + '"' + (String(cur) === String(v) ? ' selected' : '') + '>' + t + '</option>'
    ).join('') + '</select>';

    return `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>OpenCode 免费模型网关 · 管理</title>
<style>
body{background:#0f1220;color:#e8ecff;font:15px/1.6 system-ui,sans-serif;padding:18px;max-width:780px;margin:auto}
h1{font-size:20px;color:#8ad8ff} h2{font-size:16px;color:#b9c3ff;margin:0 0 8px}
.card{background:#1b2140;border-radius:14px;padding:16px;margin:14px 0}
code{color:#9ae6b4} label{display:block;margin:10px 0 4px;color:#b9c3ff;font-size:13px}
input,select,textarea{width:100%;box-sizing:border-box;background:#0d1024;color:#fff;border:1px solid #39406e;border-radius:8px;padding:10px;font-size:14px}
textarea{min-height:76px;resize:vertical;font-family:monospace;font-size:12px}
button{background:linear-gradient(90deg,#22d3ee,#8b5cf6);color:#fff;border:0;border-radius:10px;padding:11px 20px;font-size:15px;margin-top:12px;cursor:pointer}
a{color:#8ad8ff} .muted{color:#8b93bd;font-size:12.5px} .warn{color:#ffd08a}
table{width:100%;border-collapse:collapse;font-size:12px} td,th{padding:5px 6px;border-bottom:1px solid #2a3158;text-align:left;vertical-align:top}
</style></head><body>
<h1>🧩 OpenCode 免费模型 · 本地网关</h1>
<div class="card">
  <div>状态：<code style="color:#9ae6b4">运行中</code> · 端口 <code>${port}</code> · 模式 <code>${escapeHtml(cfg.mode)}</code></div>
  <div>RikkaHub Base URL：<code>http://127.0.0.1:${port}/v1</code></div>
  <div>OpenCode Console Key：<code>${mask(cfg.consoleKey)}</code> · 本机 API Key：<code>${mask(cfg.proxyKey)}</code></div>
  <div>上游：<code>${escapeHtml(cfg.upstream)}</code> · UA：<code>${escapeHtml(cfg.ua)}</code></div>
  <div class="muted">模型：${models.length} 个 · <a href="/v1/models?refresh=1">刷新模型清单</a>（上游优先，失败回退内置）</div>
</div>

<div class="card">
  <h2>① 填 OpenCode Console Key（可选，但建议填）</h2>
  <form method="POST" action="/config">
    <label>Console API Key（opencode.ai 控制台创建；留空 = 不修改）</label>
    <input name="consoleKey" type="password" placeholder="留空 = 不修改" autocomplete="off">
    <div class="muted">免费层本身<b>不需要任何 key</b>。填了它之后：<code>auto</code> 模式遇到 403/429 会自动降级到官方付费/Go 网关；也可直接在下面切到 <code>console</code> 模式。Key 存本机私有目录 0600，页面只显示掩码。</div>

    <label>清除已保存的 Console Key（填错了想重来）</label>
    ${sel('clearConsoleKey', 0, [[0, '否'], [1, '是 · 清空']])}

    <label>本机 API Key（RikkaHub 里填的那个；留空 = 不修改）</label>
    <input name="proxyKey" type="password" placeholder="留空 = 不修改" autocomplete="off">

    <label>调用模式</label>
    ${sel('mode', cfg.mode, [['auto', 'auto · 免费优先，被拒时自动降级（推荐）'], ['free', 'free · 只用免费层'], ['console', 'console · 只用 Console Key 付费/Go 模型']])}

    <label>Console 网关路径（Go 订阅改为 /inference/go/openai/v1/chat/completions）</label>
    <input name="consolePath" value="${escapeHtml(cfg.consolePath)}">
    <label>免费层路径</label>
    <input name="freePath" value="${escapeHtml(cfg.freePath)}">
    <label>上游 host</label>
    <input name="upstream" value="${escapeHtml(cfg.upstream)}">

    <h2 style="margin-top:18px">② 指纹参数（免费层 403/429 时调这里）</h2>
    <label>User-Agent</label>
    <input name="ua" value="${escapeHtml(cfg.ua)}">
    <label>x-opencode-client</label>
    ${sel('client', cfg.client, [['cli', 'cli'], ['desktop', 'desktop']])}
    <label>session ID 形状</label>
    ${sel('sidStyle', cfg.sidStyle, [['desc', 'desc · ses_ + 12hex + 14base62'], ['random', 'random · ses_ + 12hex + 16base62']])}
    <label>注入 OpenCode 原生 tools（免费层硬性要求，别关）</label>
    ${sel('injectTools', cfg.injectTools ? 1 : 0, [[1, '开'], [0, '关']])}
    <label>隐藏对中国大陆不可用的模型（Beam Free 等）</label>
    ${sel('hideRegionBlocked', cfg.hideRegionBlocked ? 1 : 0, [[1, '开'], [0, '关']])}

    <h2 style="margin-top:18px">③ 高级（可留空）</h2>
    <label>自定义模型 ID（每行一个；填了就覆盖内置/上游清单）</label>
    <textarea name="customModels" placeholder="deepseek-v4.1-flash-free&#10;glm-5.3-flash-free">${escapeHtml(cfg.customModels)}</textarea>
    <label>免费 → 付费模型映射（每行 free-id=pay-id；留空默认去掉 -free 后缀）</label>
    <textarea name="fallbackMap" placeholder="big-pickle=glm-5.3-flash">${escapeHtml(cfg.fallbackMap)}</textarea>
    <label>追加请求头（JSON 对象，网关加新校验头时不用重编译）</label>
    <textarea name="extraHeaders" placeholder='{"x-opencode-request":"..."}'>${escapeHtml(cfg.extraHeaders)}</textarea>
    <button type="submit">保存并清空模型缓存</button>
  </form>
  <div class="muted">保存后若改了「本机 API Key」，回主界面「停止网关 → 启动网关」刷新状态栏与二维码，并同步修改 RikkaHub 里的 Key。改 Console Key / 模式 / 指纹参数即时生效。</div>
</div>

<div class="card">
  <h2>当前模型清单</h2>
  <table><tr><th>ID</th><th>名称</th><th>数据</th><th>备注</th></tr>${rows || '<tr><td colspan="4">尚未加载</td></tr>'}</table>
</div>

<div class="card warn">
  <b>使用前请看清这几条：</b><br>
  1. 官方原话「Free-tier chat models are only available from within OpenCode」——免费层不是公开 API，本网关是客户端指纹桥接，规则随服务端更新随时可能失效。<br>
  2. Node/OpenSSL 的 TLS 指纹可能被判为非官方客户端，返回 <code>429 FreeUsageLimitError</code>；共享 NAT / VPN / 代理还会触发 IP 级风控。遇到就换网络或切 <code>console</code> 模式。<br>
  3. 免费模型是<b>限时</b>轮换的，且只有部分承诺零留存；写公司代码优先选 GLM / DeepSeek / MiniMax 那几款。<br>
  4. 免费层要求 <code>stream:true</code>，网关已自动把 SSE 聚合回非流式响应；同时会覆盖 <code>tools</code>，因此免费模式下 RikkaHub 的工具/MCP 调用不可用。<br>
  5. 本页只对回环开放，<code>/config</code> 不鉴权，网关固定只监听 127.0.0.1。
</div></body></html>`;
}

// ------------------------------------------------------------------ 主服务
function start(opts) {
    optsRef = opts || {};
    const dataDir = optsRef.dataDir || process.cwd();
    cfg = loadConfig(dataDir);

    const server = http.createServer(async (req, res) => {
        try {
            const u = new URL(req.url, 'http://' + (req.headers.host || '127.0.0.1'));
            const p = u.pathname.replace(/\/+$/, '') || '/';

            if (req.method === 'OPTIONS') return sendJson(res, 204, {});

            // 探活：HealthProbe.pingHealth() 不带 Authorization，必须放行
            if (req.method === 'GET' && p === '/health') {
                return sendJson(res, 200, {
                    ok: true,
                    service: 'opencode-free-gateway',
                    mode: cfg.mode,
                    hasConsoleKey: !!cfg.consoleKey,
                    models: modelCache ? modelCache.data.length : 0,
                    upstream: cfg.upstream,
                    freeTierNote: 'free-tier models are restricted to the OpenCode client by policy'
                });
            }

            // 管理页：只对回环开放
            if (req.method === 'GET' && (p === '/' || p === '/index.html')) {
                const body = managePage(server.address() ? server.address().port : optsRef.port);
                res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Content-Length': Buffer.byteLength(body) });
                return res.end(body);
            }

            if (req.method === 'POST' && p === '/config') {
                const raw = (await readBody(req)).toString('utf8');
                let next = {};
                if (raw.trim().startsWith('{')) {
                    next = safeJson(raw) || {};
                } else {
                    const params = new URLSearchParams(raw);
                    next = Object.fromEntries(params.entries());
                }
                const merged = Object.assign({}, cfg);
                // 只有这三个多行高级字段允许被清空；其余字段留空一律表示「不修改」。
                const CLEARABLE = { customModels: 1, fallbackMap: 1, extraHeaders: 1 };
                for (const k of Object.keys(DEFAULTS)) {
                    const v = next[k];
                    if (typeof DEFAULTS[k] === 'boolean') {
                        if (v !== undefined) merged[k] = parseBool(v, cfg[k]);
                    } else if (typeof v === 'string') {
                        if (v === '' && !CLEARABLE[k]) continue;
                        if (v.includes('****')) continue;   // 掩码占位不算新值
                        merged[k] = v;
                    }
                }
                // 填错了想重来：显式清空已保存的 Console Key
                if (next.clearConsoleKey === '1' || next.clearConsoleKey === 1) merged.consoleKey = '';
                saveConfig(dataDir, merged);
                if (optsRef.onKeyChanged) optsRef.onKeyChanged(cfg.proxyKey);
                if (optsRef.log) optsRef.log('配置已更新：mode=' + cfg.mode + ' consoleKey=' + mask(cfg.consoleKey) + ' key=' + mask(cfg.proxyKey));
                res.writeHead(303, { Location: '/' });
                return res.end();
            }

            // 以下路由都要鉴权
            if (!authorized(req)) return sendJson(res, 401, { error: 'unauthorized' });

            if (req.method === 'GET' && (p === '/v1/models' || p === '/models')) {
                const list = await listModels(u.searchParams.get('refresh') === '1');
                return sendJson(res, 200, list);
            }

            if (req.method === 'POST' && (p === '/v1/chat/completions' || p === '/chat/completions')) {
                const body = await readBody(req);
                const clientBody = safeJson(body.toString('utf8'));
                if (!clientBody || !Array.isArray(clientBody.messages)) {
                    return sendJson(res, 400, { error: { message: 'invalid chat.completions body: messages required' } });
                }
                const wantsStream = clientBody.stream === true;
                if (cfg.mode === 'console') {
                    if (!cfg.consoleKey) {
                        return sendJson(res, 400, {
                            error: { message: 'console 模式需要 OpenCode Console Key，请在管理页填写后保存' }
                        });
                    }
                    return await dispatchConsole(res, clientBody, wantsStream);
                }
                return await dispatchFree(res, clientBody, wantsStream);
            }

            return sendJson(res, 404, {
                error: 'not_found',
                routes: ['GET /health', 'GET /v1/models', 'POST /v1/chat/completions', 'GET /', 'POST /config']
            });
        } catch (e) {
            if (optsRef.log) optsRef.log('请求异常 ' + req.method + ' ' + req.url + '：' + (e && e.message || e));
            if (!res.headersSent) {
                return sendJson(res, 502, { error: 'proxy_error', message: String((e && e.message) || e) });
            }
            try { res.end(); } catch (_) {}
        }
    });

    // 端口被占用时顺延，实际端口通过 onListening 回写给安卓壳
    let port = Number(optsRef.port) || 18900;
    // 固定回环：管理页 /config 不鉴权（同源表单），开 LAN 中继会把它暴露到局域网。
    const host = '127.0.0.1';
    let tries = 0;
    server.on('error', (e) => {
        if (e.code === 'EADDRINUSE' && tries++ < 12) {
            port += 1;
            if (optsRef.log) optsRef.log('端口被占用，顺延到 ' + port);
            setTimeout(() => server.listen(port, host), 200);
        } else {
            if (optsRef.log) optsRef.log('监听失败：' + (e && e.message || e));
            if (optsRef.onFatal) optsRef.onFatal(String(e && e.message || e));
        }
    });
    server.listen(port, host, () => {
        const actual = server.address().port;
        if (optsRef.log) optsRef.log('OpenCode 网关已监听 http://' + host + ':' + actual + '/v1（mode=' + cfg.mode + '）');
        if (optsRef.onListening) optsRef.onListening(actual);
    });
    return server;
}

module.exports = { start: start, listModels: listModels, config: () => cfg };
