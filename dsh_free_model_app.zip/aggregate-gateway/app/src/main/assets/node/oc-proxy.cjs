'use strict';
/**
 * oc-proxy.cjs —— OpenCode 免费模型 → OpenAI 兼容本地网关（Android 版 / r2）
 *
 * 由 bootstrap.cjs 以 require('./oc-proxy.cjs') 加载，跑在 APP 自带的
 * nodejs-mobile (Node 22) 里，只监听 127.0.0.1，零 npm 依赖。
 *
 * 对外路由：
 *   GET  /health                → 200 JSON（探活，不鉴权）
 *   GET  /selftest              → 一键发最小请求到免费层，回报指纹与上游原文
 *   GET  /v1/models             → OpenAI 形状的模型清单（Bearer 鉴权）
 *   POST /v1/chat/completions   → 转发到 opencode.ai（Bearer 鉴权，SSE/JSON 双向适配）
 *   GET  /                      → 管理页（指纹参数全部可编辑）
 *   POST /config                → 保存到私有目录 oc-config.json（0600）
 *
 * ── r2 修复：免费层 429 FreeUsageLimitError ──────────────────────────
 * 这个 429 不是「额度用完」。官方对非 OpenCode 客户端的所有拒绝都回它，
 * 还附带指向 00:00 UTC 的 retry-after，看起来像额度耗尽。社区实测的三道门：
 *   ① TLS ClientHello 的 cipher list（Bun/BoringSSL 的 17 个套件，顺序也要对）
 *      —— Node 的 https.request 支持 ciphers 选项，可直接调，不需要 Bun/原生插件。
 *   ② x-opencode-session 必须是合法 ses_ 形状（r1 已做）。
 *   ③ 请求体：必须有名为 read 的工具、system 里必须有官方 <environment> 块
 *      且带真实的 Working directory: 行、stream 必须为 true。
 * r1 的缺陷正好在 ①③：完全没有 environment 块，还塞了一句
 * "Do NOT call any tools" 的 TOOL_GUARD —— 那恰恰是「另一个 agent」的标志。
 * 非官方请求若缺 environment 块，每天只有很小一份 allowance，用完就 429
 * 直到 00:00 UTC（北京时间 08:00）重置。r2 全部补齐并外置成可编辑字段。
 *
 * ⚠️ 官方仍写着「Free-tier chat models are only available from within OpenCode」。
 *    放行规则由服务端动态调整，r2 不保证能过；/selftest 用来现场判定。
 */

const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// Bun/BoringSSL ClientHello 的 17 个套件（含末尾 8 个 legacy）。
// 不同 OpenSSL 版本对个别套件名支持有差异，握手失败时会自动回退默认列表重试。
// 若你的抓包结果与此不同，直接在管理页「TLS cipher list」里整串替换。
const DEFAULT_CIPHERS = [
    'TLS_AES_128_GCM_SHA256', 'TLS_AES_256_GCM_SHA384', 'TLS_CHACHA20_POLY1305_SHA256',
    'ECDHE-ECDSA-AES128-GCM-SHA256', 'ECDHE-RSA-AES128-GCM-SHA256',
    'ECDHE-ECDSA-AES256-GCM-SHA384', 'ECDHE-RSA-AES256-GCM-SHA384',
    'ECDHE-ECDSA-CHACHA20-POLY1305', 'ECDHE-RSA-CHACHA20-POLY1305',
    'ECDHE-ECDSA-AES128-SHA', 'ECDHE-RSA-AES128-SHA', 'ECDHE-RSA-AES256-SHA',
    'AES128-GCM-SHA256', 'AES256-GCM-SHA384', 'AES128-SHA', 'AES256-SHA', 'DES-CBC3-SHA'
].join(':');

// ------------------------------------------------------------------ 默认配置
// APP 的 assets 不加密：这里不内置任何第三方真实凭据。
// 只想用免费模型的话，Console Key 整段可以完全跳过。
const DEFAULTS = {
    consoleKey: '',
    proxyKey: 'Rikka-2026-CF-Proxy-Key-8f3b',
    mode: 'free',                        // free（默认，只用免费）| auto | console
    upstream: 'opencode.ai',             // 只填 host，固定 https:443
    freePath: '/inference/openai/v1/chat/completions',
    consolePath: '/inference/openai/v1/chat/completions', // Go 订阅改成 /inference/go/openai/v1/chat/completions
    modelsPath: '/inference/openai/v1/models',
    // 抓包自真实客户端的完整 UA（不再是裸 opencode/x.y.z）
    ua: 'opencode/1.19.5 ai-sdk/provider-utils/4.0.23 runtime/bun/1.3.14',
    consoleUa: 'RikkaHub-OpenCode-Gateway/1.0',
    client: 'cli',                       // cli | desktop
    project: 'global',                   // x-opencode-project
    sidStyle: 'desc',                    // desc | random
    hideRegionBlocked: true,
    injectTools: true,
    useRequestId: true,                  // 每轮发 x-opencode-request: msg_...
    customModels: '',                    // 每行一个模型 ID，覆盖内置清单
    fallbackMap: '',                     // 每行 "free-id=pay-id"
    extraHeaders: '',                    // JSON 对象，追加/覆盖请求头
    envPrompt: '',                       // 覆盖官方 <environment> 块；留空=自动生成
    toolsJson: '',                       // 覆盖 tools 数组（抓包粘贴）；留空=内置 10 工具
    ciphers: DEFAULT_CIPHERS             // 留空 = 用 Node 默认列表
};

const MAX_BODY = 20 * 1024 * 1024;
const CACHE_MS = 30 * 60 * 1000;
const SESSION_TTL = 30 * 60 * 1000;

// 官方 CLI 的 10 个工具名（社区实测这 10 个被放行；带 terminal /
// run_code / working_directory / subagent_fork 等名字会被按名拒绝）。
// read 给一份较完整的官方形状定义，其余保持简洁但名字齐全。
const OPENCODE_TOOLS = [
    {
        type: 'function',
        function: {
            name: 'read',
            description: 'Read a file from the local filesystem. The file_path must be an absolute path, not a relative path. ' +
                'By default, it reads up to 2000 lines starting from the beginning of the file. You can optionally specify ' +
                'a line offset and limit (especially handy for long files), but it is recommended to read the whole file ' +
                'by not providing these parameters. Any lines longer than 2000 characters will be truncated. ' +
                'For image files, the tool will display the image for you.',
            parameters: {
                type: 'object',
                properties: {
                    file_path: { type: 'string', description: 'The absolute path to the file to read' },
                    offset: { type: 'number', description: 'The line number to start reading from. Only provide if the file is too large to read at once' },
                    limit: { type: 'number', description: 'The number of lines to read. Only provide if the file is too large to read at once' }
                },
                required: ['file_path']
            }
        }
    },
    {
        type: 'function',
        function: {
            name: 'bash',
            description: 'Executes a given bash command and returns its output. The working directory persists between commands, ' +
                'but shell state does not. The shell environment is initialized from the user\'s profile.',
            parameters: {
                type: 'object',
                properties: {
                    command: { type: 'string', description: 'The command to execute' },
                    timeout: { type: 'number', description: 'Optional timeout in milliseconds' },
                    description: { type: 'string', description: 'Clear, concise description of what this command does' }
                },
                required: ['command']
            }
        }
    },
    { type: 'function', function: { name: 'edit', description: 'Edit a file by replacing an exact string with a new string.', parameters: { type: 'object', properties: { file_path: { type: 'string' }, old_string: { type: 'string' }, new_string: { type: 'string' } }, required: ['file_path', 'old_string', 'new_string'] } } },
    { type: 'function', function: { name: 'glob', description: 'Find files by glob pattern. Returns matching file paths sorted by modification time.', parameters: { type: 'object', properties: { pattern: { type: 'string' }, path: { type: 'string' } }, required: ['pattern'] } } },
    { type: 'function', function: { name: 'grep', description: 'Search file contents with a regular expression.', parameters: { type: 'object', properties: { pattern: { type: 'string' }, path: { type: 'string' }, include: { type: 'string' } }, required: ['pattern'] } } },
    { type: 'function', function: { name: 'write', description: 'Write content to a file, creating it if it does not exist.', parameters: { type: 'object', properties: { file_path: { type: 'string' }, content: { type: 'string' } }, required: ['file_path', 'content'] } } },
    { type: 'function', function: { name: 'skill', description: 'Load a skill by name and follow its instructions.', parameters: { type: 'object', properties: { name: { type: 'string' } }, required: ['name'] } } },
    { type: 'function', function: { name: 'task', description: 'Launch a subagent to handle a complex, multi-step task independently.', parameters: { type: 'object', properties: { description: { type: 'string' }, prompt: { type: 'string' }, subagent_type: { type: 'string' } }, required: ['description', 'prompt'] } } },
    { type: 'function', function: { name: 'todowrite', description: 'Update the todo list for the current session.', parameters: { type: 'object', properties: { todos: { type: 'array', items: { type: 'object' } } }, required: ['todos'] } } },
    { type: 'function', function: { name: 'webfetch', description: 'Fetch a URL and convert its content to markdown.', parameters: { type: 'object', properties: { url: { type: 'string' }, format: { type: 'string' } }, required: ['url'] } } }
];

// 2026-11-11 抓自 opencode.ai/docs/zen（中英两版合并）。
// 免费位轮换极快，这份清单只是离线兜底：联网时 /v1/models 会优先取上游清单。
const BUILTIN_MODELS = [
    ['glm-5.3-flash-free', 'GLM-5.3-Flash Free', true, false, '零留存 / 不用于训练'],
    ['deepseek-v4.1-flash-free', 'DeepSeek V4.1 Flash Free', true, false, '零留存 / 不用于训练 / 200K 上下文'],
    ['minimax-m3.1-flash-free', 'MiniMax M3.1 Flash Free', true, false, '零留存 / 不用于训练'],
    ['space-bunny-free', 'Space Bunny Free', true, false, '零留存 / 隐身模型'],
    ['longcat-2.5-preview-free', 'LongCat 2.5 Preview Free', true, false, '零留存 / 托管在中国'],
    ['longcat-2.5-free', 'LongCat 2.5 Free', true, false, '零留存 / 100 次请求每天'],
    ['exo-free', 'Exo Free', null, false, '收集反馈改进模型'],
    ['mimo-v2.6-flash-free', 'MiMo-V2.6-Flash Free', null, false, '收集反馈改进模型'],
    ['mimo-v2.5-free', 'MiMo-V2.5 Free', null, false, '收集反馈改进模型'],
    ['nemotron-3-ultra-free', 'Nemotron 3 Ultra Free', null, false, 'NVIDIA 试用条款，勿提交机密'],
    ['nemotron-3.5-lightning-free', 'Nemotron 3.5 Lightning Free', null, false, 'NVIDIA 试用条款'],
    ['nemotron-3.5-super-vl-free', 'Nemotron 3.5 Super VL Free', null, false, 'NVIDIA 试用条款'],
    ['big-pickle', 'Big Pickle', null, false, '隐身模型；数据可能用于改进模型'],
    ['iceman-free', 'Iceman Free', null, false, '隐身模型；数据可能用于改进模型'],
    ['flint-40b-free', 'Flint 40B Free', null, false, '保留 30 天'],
    ['inkling-2-small-free', 'Inkling 2 Small Free', null, false, '会留存并可能用于训练；EU 等地不可用'],
    ['beam-free', 'Beam Free', null, true, '不向中国大陆/港澳提供；保留 30 天'],
    ['ll-alpha-free', 'LL Alpha Free', null, false, '隐身模型'],
    ['muse-spark-1.3-contributor-free', 'Muse Spark 1.3 Contributor Free', null, false, '收集反馈改进模型'],
    ['jev-1.13-free', 'Jev 1.13 Free', null, false, '结构化决策用途']
];

let cfg = Object.assign({}, DEFAULTS);
let modelCache = null;
let modelCacheAt = 0;
let optsRef = {};
const sessionCache = new Map();
let sidCounter = 0;

// ------------------------------------------------------------------ 配置读写
function loadConfig(dataDir) {
    const out = Object.assign({}, DEFAULTS);
    try {
        const f = path.join(dataDir, 'oc-config.json');
        if (fs.existsSync(f)) {
            const o = JSON.parse(fs.readFileSync(f, 'utf8'));
            for (const k of Object.keys(DEFAULTS)) {
                const v = o[k];
                const def = DEFAULTS[k];
                if (typeof def === 'boolean') {
                    if (typeof v === 'boolean') out[k] = v;
                    else if (v === '1' || v === 0 || v === '0' || v === 1) out[k] = (v === true || v === 1 || v === '1');
                } else if (typeof v === 'string') {
                    out[k] = v;
                }
            }
        }
    } catch (_) {}
    const envMap = {
        OC_CONSOLE_KEY: 'consoleKey', OC_PROXY_KEY: 'proxyKey', OC_MODE: 'mode',
        OC_UPSTREAM: 'upstream', OC_FREE_PATH: 'freePath', OC_CONSOLE_PATH: 'consolePath',
        OC_UA: 'ua', OC_CLIENT: 'client', OC_CIPHERS: 'ciphers'
    };
    for (const [e, k] of Object.entries(envMap)) {
        if (process.env[e] && process.env[e].trim()) out[k] = process.env[e].trim();
    }
    return out;
}

function saveConfig(dataDir, next) {
    const f = path.join(dataDir, 'oc-config.json');
    const tmp = f + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(next, null, 2), { mode: 0o600 });
    // 少数文件系统会忽略 writeFile 的 mode，落盘后再显式收紧一次
    try { fs.chmodSync(tmp, 0o600); } catch (_) {}
    fs.renameSync(tmp, f);
    try { fs.chmodSync(f, 0o600); } catch (_) {}
    cfg = Object.assign({}, cfg, next);
    modelCache = null;
    modelCacheAt = 0;
}

function mask(s) {
    if (!s) return '(未设置)';
    if (s.length <= 10) return '****';
    return s.slice(0, 5) + '****' + s.slice(-4);
}

function parseBool(v, fallback) {
    if (v === '1' || v === 1 || v === true || v === 'true') return true;
    if (v === '0' || v === 0 || v === false || v === 'false') return false;
    return fallback;
}

// ------------------------------------------------------------------ 小工具
function stripPrefix(id) {
    return String(id || '').trim().replace(/^opencode\//i, '');
}

function pretty(id) {
    const s = stripPrefix(id).split('/').pop() || id;
    return s.replace(/[-_]/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
}

function safeJson(raw) {
    try { return JSON.parse(raw); } catch (_) { return null; }
}

function extraHeaders() {
    if (!cfg.extraHeaders.trim()) return {};
    try {
        const o = JSON.parse(cfg.extraHeaders);
        return (o && typeof o === 'object' && !Array.isArray(o)) ? o : {};
    } catch (_) { return {}; }
}

// ------------------------------------------------------------------ session / request id
const B62 = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';

function randomTail(n) {
    let s = '';
    for (let i = 0; i < n; i++) s += B62[crypto.randomInt(0, 62)];
    return s;
}

function newSessionId() {
    const c = sidCounter++ & 63;
    const m = (1n << 48n) - 1n;
    let head;
    if (cfg.sidStyle === 'random') {
        head = crypto.randomBytes(6).toString('hex');
    } else {
        const raw = (BigInt(Date.now()) * 4096n + BigInt(0xfff - c)) & m;
        head = (~raw & m).toString(16).padStart(12, '0');
    }
    const tailLen = cfg.sidStyle === 'random' ? 16 : 14;
    return 'ses_' + head + randomTail(tailLen);
}

function newRequestId() {
    return 'msg_' + randomTail(24);
}

function sessionFor(body) {
    const msgs = Array.isArray(body.messages) ? body.messages : [];
    const first = msgs.find((m) => m && m.role === 'user');
    const seed = JSON.stringify(first && first.content != null ? first.content : '') + '|' + String(body.model || '');
    const key = crypto.createHash('sha1').update(seed).digest('hex');
    const now = Date.now();
    const hit = sessionCache.get(key);
    if (hit && now - hit.at < SESSION_TTL) return hit.id;
    const id = newSessionId();
    sessionCache.set(key, { id: id, at: now });
    if (sessionCache.size > 256) {
        for (const [k, v] of sessionCache) {
            if (now - v.at > SESSION_TTL) sessionCache.delete(k);
        }
    }
    return id;
}

// ------------------------------------------------------------------ 上游请求
// r2：ciphers 直接进 https.request 的 TLS options；若本机 OpenSSL 不接受
// 其中某个套件名导致握手失败，自动去掉 ciphers 重试一次，不拖垮网关。
function upstreamRequest(method, pathname, headers, body, timeoutMs, noCiphers) {
    return new Promise((resolve, reject) => {
        const options = {
            host: cfg.upstream,
            port: 443,
            method: method,
            path: pathname,
            headers: headers,
            timeout: timeoutMs || 120000
        };
        if (!noCiphers && cfg.ciphers.trim()) options.ciphers = cfg.ciphers.trim();
        const req = https.request(options, resolve);
        req.on('timeout', () => req.destroy(new Error('upstream timeout')));
        req.on('error', (e) => {
            if (!noCiphers && cfg.ciphers.trim() && /SSL|TLS|cipher|handshake|no cipher/i.test(String(e && e.message || e))) {
                if (optsRef.log) optsRef.log('TLS cipher list 被本机 OpenSSL 拒绝，回退默认列表重试一次：' + (e && e.message));
                upstreamRequest(method, pathname, headers, body, timeoutMs, true).then(resolve, reject);
            } else {
                reject(e);
            }
        });
        if (body) req.end(body); else req.end();
    });
}

function upstreamGet(pathname, headers) {
    return new Promise((resolve) => {
        upstreamRequest('GET', pathname, headers, null, 8000)
            .then(async (res) => resolve({ status: res.statusCode, raw: await collect(res) }))
            .catch(() => resolve({ status: 0, raw: '' }));
    });
}

function collect(res) {
    return new Promise((resolve, reject) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
        res.on('error', reject);
    });
}

function freeHeaders(bodyLen, sid) {
    const h = {
        'Content-Type': 'application/json',
        'Content-Length': bodyLen,
        'Accept': 'text/event-stream, application/json',
        'User-Agent': cfg.ua,
        'x-opencode-client': cfg.client,
        'x-opencode-project': cfg.project || 'global',
        'x-opencode-session': sid,
        'x-opencode-session-id': sid,
        'x-session-id': sid,
        'x-session-affinity': sid,
        'Authorization': 'Bearer public'
    };
    if (cfg.useRequestId) h['x-opencode-request'] = newRequestId();
    return Object.assign(h, extraHeaders());
}

function consoleHeaders(bodyLen, sid) {
    return Object.assign({
        'Content-Type': 'application/json',
        'Content-Length': bodyLen,
        'Accept': 'text/event-stream, application/json',
        'User-Agent': cfg.consoleUa || 'RikkaHub-OpenCode-Gateway/1.0',
        'x-opencode-client': 'gateway',
        'x-opencode-session': sid,
        'x-opencode-session-id': sid,
        'x-session-id': sid,
        'x-session-affinity': sid,
        'Authorization': 'Bearer ' + cfg.consoleKey
    }, extraHeaders());
}

// ------------------------------------------------------------------ 模型清单
function isRegionBlocked(id) {
    return /beam/i.test(String(id));
}

function builtinModels() {
    return BUILTIN_MODELS.map(([id, name, zero, blocked, note]) => ({
        id: id,
        object: 'model',
        created: 0,
        owned_by: 'opencode',
        name: name,
        metadata: {
            free: true,
            zero_retention: zero,
            region_blocked: !!blocked,
            note: note,
            source: 'builtin'
        }
    }));
}

function parseCustomModels(text) {
    return text.split(/\r?\n/)
        .map((s) => s.trim())
        .filter((s) => s && !s.startsWith('#'))
        .map((id) => ({
            id: stripPrefix(id),
            object: 'model',
            created: 0,
            owned_by: 'opencode',
            name: pretty(id),
            metadata: { free: true, zero_retention: null, region_blocked: isRegionBlocked(id), note: '管理页自定义', source: 'custom' }
        }));
}

async function fetchUpstreamModels() {
    const sid = newSessionId();
    const headers = cfg.mode === 'console' && cfg.consoleKey
        ? consoleHeaders(0, sid)
        : freeHeaders(0, sid);
    delete headers['Content-Length'];
    const r = await upstreamGet(cfg.modelsPath, headers);
    if (r.status !== 200) return null;
    const j = safeJson(r.raw);
    const arr = j && (Array.isArray(j.data) ? j.data : (Array.isArray(j) ? j : null));
    if (!arr || !arr.length) return null;
    const out = arr.map((m) => {
        const id = stripPrefix(m.id || m.name || '');
        if (!id) return null;
        const zeroPrice = !!(m.pricing && (m.pricing.prompt === 0 || m.pricing.input === 0)) ||
            m.input_price === 0 || m.cost === 0;
        return {
            id: id,
            object: 'model',
            created: Number(m.created) || 0,
            owned_by: 'opencode',
            name: m.name || pretty(id),
            metadata: {
                free: /free/i.test(id) || zeroPrice,
                zero_retention: null,
                region_blocked: isRegionBlocked(id),
                note: '来自上游 ' + cfg.modelsPath,
                source: 'upstream'
            }
        };
    }).filter(Boolean);
    return out.length ? out : null;
}

async function listModels(force) {
    if (!force && modelCache && Date.now() - modelCacheAt < CACHE_MS) return modelCache;
    let data = null;
    if (cfg.customModels.trim()) {
        data = parseCustomModels(cfg.customModels);
    } else {
        data = await fetchUpstreamModels();
        if (!data || !data.length) data = builtinModels();
    }
    if (cfg.mode !== 'console') {
        data = data.filter((m) => m.metadata && m.metadata.free);
    }
    if (cfg.hideRegionBlocked) {
        data = data.filter((m) => !(m.metadata && m.metadata.region_blocked));
    }
    modelCache = { object: 'list', data: data, total: data.length };
    modelCacheAt = Date.now();
    if (optsRef.log) optsRef.log('模型清单已刷新：' + data.length + ' 个（来源 ' + (data[0] && data[0].metadata.source || 'custom') + '）');
    return modelCache;
}

// ------------------------------------------------------------------ 请求体构造
/**
 * 官方 <environment> 块。必须带真实的 Working directory: 行；
 * 固定占位 "unknown" 自 2026-10-29 起会被立刻 429。
 */
function environmentBlock() {
    if (cfg.envPrompt.trim()) return cfg.envPrompt;
    let dir;
    try { dir = process.cwd(); } catch (_) { dir = '/data/local/tmp'; }
    return '<environment>\n' +
        '  Working directory: ' + dir + '\n' +
        '  Is directory a git repo: no\n' +
        '  Platform: android\n' +
        '  Shell: /system/bin/sh\n' +
        "  Today's date: " + new Date().toISOString().slice(0, 10) + '\n' +
        '</environment>';
}

function currentTools() {
    if (cfg.toolsJson.trim()) {
        try {
            const o = JSON.parse(cfg.toolsJson);
            if (Array.isArray(o)) return o;
            if (o && Array.isArray(o.tools)) return o.tools;
        } catch (_) {}
    }
    return OPENCODE_TOOLS;
}

function buildFreeBody(clientBody, model) {
    const up = Object.assign({}, clientBody);
    up.model = model;
    up.stream = true;                 // 免费层硬性要求
    delete up.stream_options;
    delete up.tool_choice;            // 不强制工具调用，避免模型真去调
    if (cfg.injectTools) up.tools = currentTools();
    const msgs = Array.isArray(up.messages) ? up.messages.slice() : [];
    const env = environmentBlock();
    // 合并进已有 system，而不是再 unshift 一条：官方客户端只有一条 system。
    const idx = msgs.findIndex((m) => m && m.role === 'system' && typeof m.content === 'string');
    if (idx >= 0) {
        msgs[idx] = Object.assign({}, msgs[idx], { content: msgs[idx].content + '\n\n' + env });
    } else {
        msgs.unshift({ role: 'system', content: env });
    }
    up.messages = msgs;
    return JSON.stringify(up);
}

function buildConsoleBody(clientBody, model) {
    const up = Object.assign({}, clientBody);
    up.model = model;
    return JSON.stringify(up);
}

function parseFallbackMap() {
    const map = {};
    for (const line of cfg.fallbackMap.split(/\r?\n/)) {
        const s = line.trim();
        if (!s || s.startsWith('#')) continue;
        const i = s.indexOf('=');
        if (i > 0) map[stripPrefix(s.slice(0, i).trim())] = stripPrefix(s.slice(i + 1).trim());
    }
    return map;
}

function fallbackModel(id) {
    const clean = stripPrefix(id);
    const map = parseFallbackMap();
    if (map[clean]) return map[clean];
    if (map[id]) return map[id];
    return clean.replace(/-free$/, '') || clean;
}

function shouldFallback(status, raw) {
    return status === 403 || status === 429 || status === 426 ||
        /FreeTierError|FreeUsageLimitError|abusive traffic|only be used from within OpenCode/i.test(String(raw));
}

// ------------------------------------------------------------------ 响应适配
function aggregateSse(raw, model) {
    let content = '';
    let reasoning = '';
    let usage = null;
    let finish = 'stop';
    let id = 'chatcmpl-' + crypto.randomBytes(8).toString('hex');
    for (const line of String(raw).split(/\r?\n/)) {
        if (!line.startsWith('data:')) continue;
        const data = line.slice(5).trim();
        if (!data || data === '[DONE]') continue;
        const o = safeJson(data);
        if (!o) continue;
        if (o.id) id = o.id;
        if (o.usage) usage = o.usage;
        const ch = o.choices && o.choices[0];
        if (!ch) continue;
        if (ch.finish_reason) finish = ch.finish_reason;
        const d = ch.delta || ch.message || {};
        if (typeof d.content === 'string') content += d.content;
        else if (Array.isArray(d.content)) {
            for (const part of d.content) {
                if (part && typeof part.text === 'string') content += part.text;
            }
        }
        if (typeof d.reasoning_content === 'string') reasoning += d.reasoning_content;
        else if (typeof d.reasoning === 'string') reasoning += d.reasoning;
    }
    const message = { role: 'assistant', content: content };
    if (reasoning) message.reasoning_content = reasoning;
    return {
        id: id,
        object: 'chat.completion',
        created: Math.floor(Date.now() / 1000),
        model: model,
        choices: [{ index: 0, message: message, finish_reason: finish }],
        usage: usage || { prompt_tokens: 0, completion_tokens: 0, total_tokens: 0 }
    };
}

function sendSse(res, status, obj) {
    res.writeHead(status, {
        'Content-Type': 'text/event-stream; charset=utf-8',
        'Cache-Control': 'no-cache, no-transform',
        'Connection': 'keep-alive',
        'X-Accel-Buffering': 'no',
        'Access-Control-Allow-Origin': '*'
    });
    res.write('data: ' + JSON.stringify(obj) + '\n\n');
    res.write('data: [DONE]\n\n');
    res.end();
}

async function relay(res, upRes, wantsStream, model) {
    const ct = upRes.headers['content-type'] || '';
    const isSse = /text\/event-stream/i.test(ct);
    if (wantsStream && isSse) {
        res.writeHead(upRes.statusCode, {
            'Content-Type': 'text/event-stream; charset=utf-8',
            'Cache-Control': 'no-cache, no-transform',
            'Connection': 'keep-alive',
            'X-Accel-Buffering': 'no',
            'Access-Control-Allow-Origin': '*'
        });
        return upRes.pipe(res);
    }
    const raw = await collect(upRes);
    if (wantsStream && !isSse) {
        const obj = safeJson(raw) || { error: { message: 'upstream returned non-JSON: ' + raw.slice(0, 200) } };
        return sendSse(res, upRes.statusCode, obj);
    }
    if (!wantsStream && isSse) {
        return sendJson(res, upRes.statusCode, aggregateSse(raw, model));
    }
    res.writeHead(upRes.statusCode, {
        'Content-Type': ct || 'application/json; charset=utf-8',
        'Content-Length': Buffer.byteLength(raw),
        'Access-Control-Allow-Origin': '*'
    });
    return res.end(raw);
}

/** 把 429 FreeUsageLimitError 翻译成人话，保留上游原文供排查。 */
function sendUpstreamError(res, status, raw) {
    let body = raw;
    let contentType = /^\s*\{/.test(raw) ? 'application/json; charset=utf-8' : 'application/json; charset=utf-8';
    if (/FreeUsageLimitError|FreeTierError/i.test(raw)) {
        const j = safeJson(raw);
        const orig = (j && j.error && (j.error.message ||
            (j.error.error && j.error.error.message))) || raw.slice(0, 400);
        body = JSON.stringify({
            error: {
                type: 'free_tier_rejected',
                message: '【免费层拒绝 429】OpenCode 没有把本网关识别为官方客户端。\n' +
                    '这不是「额度用完」：官方对非 OpenCode 请求统一回 429 FreeUsageLimitError，' +
                    '并附带指向 00:00 UTC 的 retry-after，看起来像额度耗尽。\n' +
                    'r2 已补齐三道门（官方 <environment> 块、read 工具、BoringSSL 17 套 TLS cipher list），' +
                    '请在管理页点「一键测试免费层」看实时结果。\n' +
                    '若刚连续重试过，非官方客户端的每日小额 allowance 可能已耗尽，需等 UTC 0 点（北京时间 08:00）重置。\n' +
                    '上游原文：' + orig,
                upstream_status: status,
                upstream_raw: j || raw.slice(0, 1000)
            }
        });
    } else if (!/^\s*\{/.test(raw)) {
        body = JSON.stringify({ error: { message: 'OpenCode 上游 HTTP ' + status, upstream: raw.slice(0, 800) } });
    }
    res.writeHead(status, {
        'Content-Type': contentType,
        'Content-Length': Buffer.byteLength(body),
        'Access-Control-Allow-Origin': '*'
    });
    return res.end(body);
}

// ------------------------------------------------------------------ 分发
async function dispatchConsole(res, clientBody, wantsStream) {
    const sid = sessionFor(clientBody);
    const model = fallbackModel(clientBody.model || '');
    const body = buildConsoleBody(clientBody, model);
    const upRes = await upstreamRequest('POST', cfg.consolePath, consoleHeaders(Buffer.byteLength(body), sid), body, 120000);
    if (upRes.statusCode >= 400) {
        const raw = await collect(upRes);
        if (optsRef.log) optsRef.log('Console 网关 HTTP ' + upRes.statusCode + '：' + raw.slice(0, 300));
        return sendUpstreamError(res, upRes.statusCode, raw);
    }
    return relay(res, upRes, wantsStream, model);
}

async function dispatchFree(res, clientBody, wantsStream) {
    const sid = sessionFor(clientBody);
    const model = stripPrefix(clientBody.model || '') || (BUILTIN_MODELS[0] && BUILTIN_MODELS[0][0]);
    const body = buildFreeBody(clientBody, model);
    const upRes = await upstreamRequest('POST', cfg.freePath, freeHeaders(Buffer.byteLength(body), sid), body, 120000);
    if (upRes.statusCode >= 400) {
        const raw = await collect(upRes);
        if (optsRef.log) optsRef.log('免费层 HTTP ' + upRes.statusCode + '：' + raw.slice(0, 300));
        // 只有显式选了 auto 且填了 Console Key 才降级；默认 free 绝不碰付费。
        if (cfg.mode === 'auto' && cfg.consoleKey && shouldFallback(upRes.statusCode, raw)) {
            if (optsRef.log) optsRef.log('免费层被拒，已填 Console Key → 自动降级到付费/Go 网关');
            return dispatchConsole(res, clientBody, wantsStream);
        }
        return sendUpstreamError(res, upRes.statusCode, raw);
    }
    return relay(res, upRes, wantsStream, model);
}

/** 一键自检：用与真实请求完全相同的构造发一个最小请求，回报指纹与上游原文。 */
async function selfTest() {
    const model = (modelCache && modelCache.data[0] && modelCache.data[0].id) ||
        (await listModels(false).then((l) => l.data[0] && l.data[0].id).catch(() => null)) ||
        'deepseek-v4.1-flash-free';
    const body = buildFreeBody({ model: model, messages: [{ role: 'user', content: 'hi' }] }, model);
    const sid = newSessionId();
    const headers = freeHeaders(Buffer.byteLength(body), sid);
    const parsed = safeJson(body);
    const sent = {
        endpoint: 'https://' + cfg.upstream + cfg.freePath,
        model: model,
        ua: headers['User-Agent'],
        session: sid,
        project: headers['x-opencode-project'],
        request: headers['x-opencode-request'] || '(未发)',
        tools: (parsed.tools || []).map((t) => t.function && t.function.name),
        environment_block: (parsed.messages[0] || {}).content,
        stream: parsed.stream,
        ciphers: cfg.ciphers.trim() ? cfg.ciphers.trim() : '(Node 默认)'
    };
    try {
        const r = await upstreamRequest('POST', cfg.freePath, headers, body, 20000);
        const raw = await collect(r);
        return {
            ok: r.statusCode === 200,
            status: r.statusCode,
            sent: sent,
            upstream: raw.slice(0, 800),
            verdict: r.statusCode === 200
                ? '✅ 免费层已放行，可以回 RikkaHub 聊天了'
                : '❌ 仍被拒。若刚连续重试过，等 UTC 0 点（北京时间 08:00）再试；否则对照上方指纹逐项排查。'
        };
    } catch (e) {
        return {
            ok: false, status: 0, sent: sent,
            upstream: String((e && e.message) || e),
            verdict: '❌ 网络 / TLS 层失败（不是业务拒绝），检查网络与 cipher list'
        };
    }
}

// ------------------------------------------------------------------ HTTP 工具
function sendJson(res, status, obj, extra) {
    const body = JSON.stringify(obj);
    res.writeHead(status, Object.assign({
        'Content-Type': 'application/json; charset=utf-8',
        'Content-Length': Buffer.byteLength(body),
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': '*',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
    }, extra || {}));
    res.end(status === 204 ? undefined : body);
}

function readBody(req) {
    return new Promise((resolve, reject) => {
        const chunks = [];
        let size = 0;
        req.on('data', (c) => {
            size += c.length;
            if (size > MAX_BODY) { reject(new Error('body too large')); req.destroy(); return; }
            chunks.push(c);
        });
        req.on('end', () => resolve(Buffer.concat(chunks)));
        req.on('error', reject);
    });
}

function authorized(req) {
    const a = req.headers.authorization || '';
    return cfg.proxyKey === '' || a === 'Bearer ' + cfg.proxyKey;
}

function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

// ------------------------------------------------------------------ 管理页
function managePage(port) {
    const models = modelCache ? modelCache.data : [];
    const rows = models.slice(0, 40).map((m) =>
        '<tr><td><code>' + escapeHtml(m.id) + '</code></td><td>' + escapeHtml(m.name) + '</td><td>' +
        (m.metadata.zero_retention === true ? '✅ 零留存' : (m.metadata.zero_retention === null ? '—' : '⚠️')) +
        '</td><td>' + escapeHtml(m.metadata.note || '') + '</td></tr>'
    ).join('');
    const sel = (name, cur, options) => '<select name="' + name + '">' + options.map(([v, t]) =>
        '<option value="' + v + '"' + (String(cur) === String(v) ? ' selected' : '') + '>' + t + '</option>'
    ).join('') + '</select>';

    return `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>OpenCode 免费模型网关 · 管理 (r2)</title>
<style>
body{background:#0f1220;color:#e8ecff;font:15px/1.6 system-ui,sans-serif;padding:18px;max-width:780px;margin:auto}
h1{font-size:20px;color:#8ad8ff} h2{font-size:16px;color:#b9c3ff;margin:0 0 8px}
.card{background:#1b2140;border-radius:14px;padding:16px;margin:14px 0}
code{color:#9ae6b4} label{display:block;margin:10px 0 4px;color:#b9c3ff;font-size:13px}
input,select,textarea{width:100%;box-sizing:border-box;background:#0d1024;color:#fff;border:1px solid #39406e;border-radius:8px;padding:10px;font-size:14px}
textarea{min-height:76px;resize:vertical;font-family:monospace;font-size:12px}
button{background:linear-gradient(90deg,#22d3ee,#8b5cf6);color:#fff;border:0;border-radius:10px;padding:11px 20px;font-size:15px;margin-top:12px;cursor:pointer}
a{color:#8ad8ff} .muted{color:#8b93bd;font-size:12.5px} .warn{color:#ffd08a}
table{width:100%;border-collapse:collapse;font-size:12px} td,th{padding:5px 6px;border-bottom:1px solid #2a3158;text-align:left;vertical-align:top}
pre{background:#0d1024;border:1px solid #39406e;border-radius:8px;padding:12px;font-size:11px;white-space:pre-wrap;word-break:break-all;max-height:420px;overflow:auto;color:#cfe3ff}
</style></head><body>
<h1>🧩 OpenCode 免费模型 · 本地网关 <span class="muted">r2</span></h1>
<div class="card">
  <div>状态：<code style="color:#9ae6b4">运行中</code> · 端口 <code>${port}</code> · 模式 <code>${escapeHtml(cfg.mode)}</code></div>
  <div>RikkaHub Base URL：<code>http://127.0.0.1:${port}/v1</code></div>
  <div>Console Key：<code>${mask(cfg.consoleKey)}</code> · 本机 API Key：<code>${mask(cfg.proxyKey)}</code></div>
  <div>上游：<code>${escapeHtml(cfg.upstream)}</code> · TLS cipher：<code>${cfg.ciphers.trim() ? 'r2 调优列表' : 'Node 默认'}</code></div>
  <div class="muted">模型：${models.length} 个 · <a href="/v1/models?refresh=1">刷新模型清单</a></div>
</div>

<div class="card">
  <h2>🔬 一键测试免费层（先点这个）</h2>
  <div class="muted">用与真实聊天完全相同的请求体、请求头和 TLS 设置发一句 "hi"，直接看上游放行没有。不用切到 RikkaHub 反复重试——连续重试会把非官方客户端的每日小额 allowance 耗光。</div>
  <button type="button" onclick="runTest()">发送最小请求并查看结果</button>
  <pre id="testout">尚未测试</pre>
</div>

<div class="card">
  <h2>① Console Key（只想用免费 → 整段跳过）</h2>
  <form method="POST" action="/config">
    <label>Console API Key（留空 = 不修改；免费层不需要任何 key）</label>
    <input name="consoleKey" type="password" placeholder="留空 = 不修改" autocomplete="off">
    <label>清除已保存的 Console Key</label>
    ${sel('clearConsoleKey', 0, [[0, '否'], [1, '是 · 清空']])}
    <label>本机 API Key（RikkaHub 里填的那个；留空 = 不修改）</label>
    <input name="proxyKey" type="password" placeholder="留空 = 不修改" autocomplete="off">
    <label>调用模式</label>
    ${sel('mode', cfg.mode, [['free', 'free · 只用免费层（推荐，绝不降级）'], ['auto', 'auto · 免费优先，被拒时降级（需 Console Key）'], ['console', 'console · 只用付费/Go 模型']])}
    <div class="muted">r2 默认 <code>free</code>：即使上游 429 也不会偷偷改走付费模型。只有显式切到 <code>auto</code> 且填了 Console Key 才会降级。</div>

    <h2 style="margin-top:18px">② 免费层路径与端点</h2>
    <label>免费层路径（官方 Inference API 用 /inference/openai/v1/…；旧 /zen/v1 已被弃用）</label>
    <input name="freePath" value="${escapeHtml(cfg.freePath)}">
    <label>Console 网关路径（Go 订阅改为 /inference/go/openai/v1/chat/completions）</label>
    <input name="consolePath" value="${escapeHtml(cfg.consolePath)}">
    <label>上游 host</label>
    <input name="upstream" value="${escapeHtml(cfg.upstream)}">

    <h2 style="margin-top:18px">③ 指纹参数（r2 已补齐，仍 429 时逐项试）</h2>
    <label>User-Agent（抓包自真实客户端的完整 UA）</label>
    <input name="ua" value="${escapeHtml(cfg.ua)}">
    <label>x-opencode-client</label>
    ${sel('client', cfg.client, [['cli', 'cli'], ['desktop', 'desktop']])}
    <label>x-opencode-project</label>
    <input name="project" value="${escapeHtml(cfg.project)}">
    <label>每轮发 x-opencode-request: msg_…</label>
    ${sel('useRequestId', cfg.useRequestId ? 1 : 0, [[1, '开'], [0, '关']])}
    <label>session ID 形状</label>
    ${sel('sidStyle', cfg.sidStyle, [['desc', 'desc · ses_ + 12hex + 14base62'], ['random', 'random · ses_ + 12hex + 16base62']])}
    <label>注入官方 10 个 tools（免费层硬性要求，别关）</label>
    ${sel('injectTools', cfg.injectTools ? 1 : 0, [[1, '开'], [0, '关']])}
    <label>隐藏对中国大陆不可用的模型（Beam Free 等）</label>
    ${sel('hideRegionBlocked', cfg.hideRegionBlocked ? 1 : 0, [[1, '开'], [0, '关']])}
    <label>TLS cipher list（BoringSSL 17 套件；留空 = 用 Node 默认，几乎必被拒）</label>
    <textarea name="ciphers">${escapeHtml(cfg.ciphers)}</textarea>
    <div class="muted">Node 的 <code>https.request</code> 支持 <code>ciphers</code> 选项，不需要 Bun / 原生插件。若本机 OpenSSL 不接受某个套件名导致握手失败，网关会自动回退默认列表重试一次，并在日志里留一行。</div>
    <label>官方 &lt;environment&gt; 块（留空 = 自动生成本机真实工作目录）</label>
    <textarea name="envPrompt" placeholder="留空 = 自动生成">${escapeHtml(cfg.envPrompt)}</textarea>
    <div class="muted">必须含真实 <code>Working directory:</code> 行；写 <code>unknown</code> 自 2026-10-29 起会被立刻 429。</div>
    <label>请求头追加 / 覆盖（JSON 对象，上游加新校验头时不用重编译）</label>
    <textarea name="extraHeaders" placeholder='{"x-opencode-request":"..."}'>${escapeHtml(cfg.extraHeaders)}</textarea>

    <h2 style="margin-top:18px">④ 高级（可留空）</h2>
    <label>tools 数组覆盖（从 Windows 客户端抓包粘贴完整 JSON；留空 = 内置 10 工具）</label>
    <textarea name="toolsJson" placeholder='[{"type":"function","function":{...}}]'>${escapeHtml(cfg.toolsJson)}</textarea>
    <label>自定义模型 ID（每行一个；填了就覆盖内置/上游清单）</label>
    <textarea name="customModels" placeholder="deepseek-v4.1-flash-free&#10;glm-5.3-flash-free">${escapeHtml(cfg.customModels)}</textarea>
    <label>免费 → 付费模型映射（auto 降级用；每行 free-id=pay-id）</label>
    <textarea name="fallbackMap" placeholder="big-pickle=glm-5.3-flash">${escapeHtml(cfg.fallbackMap)}</textarea>
    <button type="submit">保存并清空模型缓存</button>
  </form>
  <div class="muted">保存后若改了「本机 API Key」，回主界面「停止网关 → 启动网关」刷新状态栏与二维码，并同步修改 RikkaHub 里的 Key。其它参数即时生效，可直接再点「一键测试免费层」。</div>
</div>

<div class="card">
  <h2>当前模型清单</h2>
  <table><tr><th>ID</th><th>名称</th><th>数据</th><th>备注</th></tr>${rows || '<tr><td colspan="4">尚未加载</td></tr>'}</table>
</div>

<div class="card warn">
  <b>关于 429 FreeUsageLimitError：</b><br>
  1. 它<b>不是</b>「公共池额度耗尽」的统一说法，而是官方对非 OpenCode 客户端的通用拒绝语，还会附一个指向 <code>00:00 UTC</code> 的 retry-after 伪装成额度。<br>
  2. 三道门：TLS ClientHello 的 17 套件 cipher list、合法 <code>ses_</code> 会话头、请求体里的 <code>read</code> 工具 + <code>&lt;environment&gt;</code> 块 + <code>stream:true</code>。r2 已全部补齐。<br>
  3. 缺 <code>&lt;environment&gt;</code> 块的非官方请求每天只有很小一份 allowance，用完就 429 直到 UTC 0 点（北京时间 08:00）。<b>不要连续重试</b>，只会把窗口推远。<br>
  4. 官方仍写着免费模型只对 OpenCode 客户端开放；11 月初有实测显示完整原报文直连也照样 429，放行的是真实客户端进程的连接态。<b>r2 不保证能过</b>，请用上面的自检现场判定。<br>
  5. 免费层要求 <code>stream:true</code>，网关已把 SSE 聚合回非流式响应；同时会覆盖 <code>tools</code>，所以免费模式下 RikkaHub 的工具 / MCP 调用不可用。<br>
  6. 本页只对回环开放，<code>/config</code> 与 <code>/selftest</code> 不鉴权，网关固定只监听 127.0.0.1。
</div>
<script>
function runTest(){
  var o=document.getElementById('testout');
  o.textContent='请求中…（最多 20 秒，请勿连点）';
  fetch('/selftest').then(function(r){return r.json();}).then(function(j){
    o.textContent = j.verdict + '\\nHTTP ' + j.status +
      '\\n\\n【本次发出的指纹】\\n' + JSON.stringify(j.sent,null,2) +
      '\\n\\n【上游返回原文】\\n' + j.upstream;
  }).catch(function(e){o.textContent='自检请求失败：'+e;});
}
</script>
</body></html>`;
}

// ------------------------------------------------------------------ 主服务
function start(opts) {
    optsRef = opts || {};
    const dataDir = optsRef.dataDir || process.cwd();
    cfg = loadConfig(dataDir);

    const server = http.createServer(async (req, res) => {
        try {
            const u = new URL(req.url, 'http://' + (req.headers.host || '127.0.0.1'));
            const p = u.pathname.replace(/\/+$/, '') || '/';

            if (req.method === 'OPTIONS') return sendJson(res, 204, {});

            // 探活：HealthProbe.pingHealth() 不带 Authorization，必须放行
            if (req.method === 'GET' && p === '/health') {
                return sendJson(res, 200, {
                    ok: true,
                    service: 'opencode-free-gateway',
                    version: 'r2',
                    mode: cfg.mode,
                    hasConsoleKey: !!cfg.consoleKey,
                    models: modelCache ? modelCache.data.length : 0,
                    upstream: cfg.upstream,
                    freeTierNote: 'free-tier models are restricted to the OpenCode client by policy'
                });
            }

            // 一键自检：与 /config 一样只对回环开放、不鉴权
            if (req.method === 'GET' && p === '/selftest') {
                return sendJson(res, 200, await selfTest());
            }

            if (req.method === 'GET' && (p === '/' || p === '/index.html')) {
                const body = managePage(server.address() ? server.address().port : optsRef.port);
                res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Content-Length': Buffer.byteLength(body) });
                return res.end(body);
            }

            if (req.method === 'POST' && p === '/config') {
                const raw = (await readBody(req)).toString('utf8');
                let next = {};
                if (raw.trim().startsWith('{')) {
                    next = safeJson(raw) || {};
                } else {
                    const params = new URLSearchParams(raw);
                    next = Object.fromEntries(params.entries());
                }
                const merged = Object.assign({}, cfg);
                // 这些多行 / 长文本字段允许被清空；其余字段留空一律表示「不修改」。
                const CLEARABLE = {
                    customModels: 1, fallbackMap: 1, extraHeaders: 1,
                    envPrompt: 1, toolsJson: 1, ciphers: 1
                };
                for (const k of Object.keys(DEFAULTS)) {
                    const v = next[k];
                    if (typeof DEFAULTS[k] === 'boolean') {
                        if (v !== undefined) merged[k] = parseBool(v, cfg[k]);
                    } else if (typeof v === 'string') {
                        if (v === '' && !CLEARABLE[k]) continue;
                        if (v.includes('****')) continue;
                        merged[k] = v;
                    }
                }
                if (next.clearConsoleKey === '1' || next.clearConsoleKey === 1) merged.consoleKey = '';
                saveConfig(dataDir, merged);
                if (optsRef.onKeyChanged) optsRef.onKeyChanged(cfg.proxyKey);
                if (optsRef.log) optsRef.log('配置已更新：mode=' + cfg.mode + ' consoleKey=' + mask(cfg.consoleKey) + ' key=' + mask(cfg.proxyKey));
                res.writeHead(303, { Location: '/' });
                return res.end();
            }

            // 以下路由都要鉴权
            if (!authorized(req)) return sendJson(res, 401, { error: 'unauthorized' });

            if (req.method === 'GET' && (p === '/v1/models' || p === '/models')) {
                const list = await listModels(u.searchParams.get('refresh') === '1');
                return sendJson(res, 200, list);
            }

            if (req.method === 'POST' && (p === '/v1/chat/completions' || p === '/chat/completions')) {
                const body = await readBody(req);
                const clientBody = safeJson(body.toString('utf8'));
                if (!clientBody || !Array.isArray(clientBody.messages)) {
                    return sendJson(res, 400, { error: { message: 'invalid chat.completions body: messages required' } });
                }
                const wantsStream = clientBody.stream === true;
                if (cfg.mode === 'console') {
                    if (!cfg.consoleKey) {
                        return sendJson(res, 400, {
                            error: { message: 'console 模式需要 OpenCode Console Key，请在管理页填写后保存' }
                        });
                    }
                    return await dispatchConsole(res, clientBody, wantsStream);
                }
                return await dispatchFree(res, clientBody, wantsStream);
            }

            return sendJson(res, 404, {
                error: 'not_found',
                routes: ['GET /health', 'GET /selftest', 'GET /v1/models', 'POST /v1/chat/completions', 'GET /', 'POST /config']
            });
        } catch (e) {
            if (optsRef.log) optsRef.log('请求异常 ' + req.method + ' ' + req.url + '：' + (e && e.message || e));
            if (!res.headersSent) {
                return sendJson(res, 502, { error: 'proxy_error', message: String((e && e.message) || e) });
            }
            try { res.end(); } catch (_) {}
        }
    });

    let port = Number(optsRef.port) || 18900;
    const host = '127.0.0.1';
    let tries = 0;
    server.on('error', (e) => {
        if (e.code === 'EADDRINUSE' && tries++ < 12) {
            port += 1;
            if (optsRef.log) optsRef.log('端口被占用，顺延到 ' + port);
            setTimeout(() => server.listen(port, host), 200);
        } else {
            if (optsRef.log) optsRef.log('监听失败：' + (e && e.message || e));
            if (optsRef.onFatal) optsRef.onFatal(String(e && e.message || e));
        }
    });
    server.listen(port, host, () => {
        const actual = server.address().port;
        if (optsRef.log) optsRef.log('OpenCode 网关已监听 http://' + host + ':' + actual + '/v1（r2 / mode=' + cfg.mode + '）');
        if (optsRef.onListening) optsRef.onListening(actual);
    });
    return server;
}

module.exports = { start: start, listModels: listModels, config: () => cfg };
