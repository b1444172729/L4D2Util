'use strict';
/**
 * OpenCode Zen 免费模型 · 本机网关（B 方案）
 *
 * 把 yu-wenchao/dsh-opencode-free-models 在 DSH 里做的两件事搬到手机本机：
 *   ① 模型清单：原插件从作者后端 GET /api/models 拉，DSH 宿主把它写进模型选择器；
 *      这里由本机 GET /api/models 提供，并注册进 GET /v1/models。
 *   ② 模型调用：原插件生成 llm-pi-ai provider 条目（baseURL=opencode.ai/zen/v1，
 *      apiKeyEnv=OPENCODE_ZEN_API_KEY，宿主注入 Bearer public），由 DSH 直连上游；
 *      这里由本机 /v1/* 统一转发，客户端只认 127.0.0.1 与一把本地 Key。
 *
 * 因此这是「等价重写」，不是移植插件代码：插件本身没有 HTTP 服务端，
 * 面板、18766 授权桥、cordis.patch.yml 都是 DSH 宿主里的东西，手机上不存在。
 *
 * 与 Android 壳的契约（一行都不能破）：
 *   · 环境变量 OFM_PORT / OFM_HOST / OFM_HOME / OFM_DATA_DIR / OFM_LAN_RELAY
 *     （由 app/src/main/cpp/dsh-node.c 的 setenv 注入）
 *   · 写 ofm-data/gateway-runtime.json：{port,requestedPort,apiKey,manageUrl,...}
 *     → HealthProbe.awaitRuntime() 读它，并 GET /health 握手，apiKey 必须非空
 *   · GET /v1/models 需接受 Authorization: Bearer <apiKey>
 *     → HealthProbe.fetchModelIds() 用它拉模型 ID 清单
 *   · GET / 提供管理页 → ManageActivity 的 WebView 打开
 *   · 任何异常都写日志，绝不 process.exit()（Android 上会连宿主 App 一起结束）
 */

const fs = require('fs');
const path = require('path');
const http = require('http');
const https = require('https');
const crypto = require('crypto');

const VERSION = '1.0.0-local';
const ROOT = __dirname;

function realOr(p) { try { return fs.realpathSync.native(p); } catch (_) { return p; } }
function positive(v, d) { const n = parseInt(v || '', 10); return Number.isFinite(n) && n > 0 ? n : d; }
function nowIso() { return new Date().toISOString(); }

const DATA = realOr(process.env.OFM_DATA_DIR || process.env.OFM_HOME ||
  path.join(process.env.HOME || ROOT, '.our-free-model'));
fs.mkdirSync(DATA, { recursive: true });

const REQUESTED_PORT = positive(process.env.OFM_PORT, 18900);
const LOOPBACK_HOST = process.env.OFM_HOST || '127.0.0.1';
const LAN_RELAY = process.env.OFM_LAN_RELAY === '1';
const BIND_HOST = LAN_RELAY ? '0.0.0.0' : LOOPBACK_HOST;

// 官方 Zen 网关：https://opencode.ai/zen/v1（/models 为公开目录端点）
const ZEN_BASE = (process.env.ZEN_BASE_URL || 'https://opencode.ai/zen/v1').replace(/\/+$/, '');
// 匿名免费档使用字面量密钥 public；也可填自己的 Zen key（只改认证与额度，不改模型清单）
const ZEN_KEY = process.env.OPENCODE_ZEN_API_KEY || 'public';

const F = {
  settings: path.join(DATA, 'settings.json'),
  runtime: path.join(DATA, 'gateway-runtime.json'),
  catalog: path.join(DATA, 'models.json'),
  builtin: path.join(ROOT, 'models.builtin.json'),
  usage: path.join(DATA, 'usage.json'),
  bootLog: path.join(DATA, 'bootstrap.log'),
  outLog: path.join(DATA, 'node-output.log'),
  errLog: path.join(DATA, 'node-errors.log'),
  fatal: path.join(DATA, 'node-fatal.txt'),
  web: path.join(ROOT, 'web', 'index.html')
};

// ---------------------------------------------------------------- 日志
function append(file, line) { try { fs.appendFileSync(file, line + '\n'); } catch (_) {} }
function bootlog(m) { append(F.bootLog, '[gateway] ' + m); append(F.outLog, '[js] ' + m); }
function logError(m) {
  const line = '[' + nowIso() + '] ' + m;
  append(F.errLog, line); append(F.bootLog, line); append(F.outLog, '[js:err] ' + line);
}
function fatal(m) {
  bootlog('致命失败：' + m);
  logError(m);
  try { fs.writeFileSync(F.fatal, m); } catch (_) {}
}
process.on('uncaughtException', (e) => logError('uncaughtException: ' + (e && e.stack || e)));
process.on('unhandledRejection', (e) => logError('unhandledRejection: ' + (e && e.stack || e)));

function readJson(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch (_) { return fallback; }
}
function writeJson(file, obj, mode) {
  const tmp = file + '.tmp';
  try {
    fs.writeFileSync(tmp, JSON.stringify(obj, null, 2), { mode: mode || 0o600 });
    fs.renameSync(tmp, file);
    return true;
  } catch (e) { logError('写 ' + path.basename(file) + ' 失败: ' + e.message); return false; }
}

// ---------------------------------------------------------------- 本地 Key 与设置
// 原插件的 Key 是上游的 public，本机网关必须另发一把自己的 Key，
// 否则局域网/其它 App 都能直接打 /v1。字段名沿用 forwardKey，兼容旧 settings.json。
const settings = readJson(F.settings, {});
if (typeof settings.forwardKey !== 'string' || !settings.forwardKey.trim()) {
  settings.forwardKey = 'gw-' + crypto.randomBytes(24).toString('hex');
}
if (typeof settings.lanKey !== 'string' || !settings.lanKey.trim()) {
  settings.lanKey = 'lan-' + crypto.randomBytes(24).toString('hex');
}
if (typeof settings.opencodeEnabled !== 'boolean') settings.opencodeEnabled = true;
if (typeof settings.authorized !== 'boolean') settings.authorized = true;
if (typeof settings.hideUnavailable !== 'boolean') settings.hideUnavailable = true;
settings.updatedAt = nowIso();
writeJson(F.settings, settings, 0o600);

const LOCAL_KEY = settings.forwardKey;
const LAN_KEY = settings.lanKey;
const SESSION_ID = crypto.createHash('sha256').update(LOCAL_KEY).digest('hex').slice(0, 32);

let usage = readJson(F.usage, { requests: 0, errors: 0, byModel: {}, lastAt: null });
if (typeof usage !== 'object' || !usage) usage = { requests: 0, errors: 0, byModel: {}, lastAt: null };
if (!usage.byModel || typeof usage.byModel !== 'object') usage.byModel = {};

// ---------------------------------------------------------------- 运行信息回写
const runtime = {
  port: REQUESTED_PORT,
  requestedPort: REQUESTED_PORT,
  apiKey: LOCAL_KEY,
  manageUrl: '',
  host: LOOPBACK_HOST,
  pid: process.pid,
  startedAt: nowIso(),
  gateway: 'opencode-zen-free-local',
  version: VERSION
};
function publish() { writeJson(F.runtime, runtime, 0o600); }
publish();

// ---------------------------------------------------------------- 模型清单
// 原插件后端 /api/models 的 items 结构在这里本地复刻：
// {id,title,api_base_url,model_name[],status,usable,disabled_reason,
//  available_from,available_until}；hidden 是本机管理页新增的开关。
function loadCatalog() {
  const custom = readJson(F.catalog, null);
  if (custom && Array.isArray(custom.items) && custom.items.length) return custom;
  const builtin = readJson(F.builtin, { items: [] });
  return { updatedAt: builtin.snapshot || '', source: 'builtin', items: builtin.items || [] };
}
let catalog = loadCatalog();

function inTimeWindow(it) {
  const now = Date.now();
  if (it.available_from) {
    const t = Date.parse(String(it.available_from).replace(' ', 'T'));
    if (!Number.isNaN(t) && now < t) return false;
  }
  if (it.available_until) {
    const t = Date.parse(String(it.available_until).replace(' ', 'T'));
    if (!Number.isNaN(t) && now > t) return false;
  }
  return true;
}

/** 三层开关取交集（本地等价物）：总开关 → 授权 → 单模型状态/时间窗 */
function effectiveModels() {
  if (!settings.opencodeEnabled || !settings.authorized) return [];
  return (catalog.items || []).filter((it) =>
    it && typeof it.id === 'string' && it.id.trim() &&
    it.hidden !== true &&
    (it.status || 'enabled') === 'enabled' &&
    it.usable !== false &&
    inTimeWindow(it)
  );
}

function openAiModels() {
  const created = Math.floor(Date.parse(catalog.updatedAt || nowIso()) / 1000) || 0;
  return {
    object: 'list',
    data: effectiveModels().map((it) => ({
      id: it.id,
      object: 'model',
      created,
      owned_by: 'opencode-zen-free',
      metadata: {
        title: it.title || it.id,
        base_url: it.api_base_url || ZEN_BASE,
        context: it.context || null
      }
    }))
  };
}

/** 面板兼容格式：把原作者后端的 /api/models 搬到 127.0.0.1 */
function panelModels(page, pageSize) {
  const all = (catalog.items || []).map((it, i) => ({
    id: it.id ? String(it.id) : String(i + 1),
    title: it.title || it.id,
    api_base_url: it.api_base_url || ZEN_BASE,
    model_name: Array.isArray(it.model_name) && it.model_name.length ? it.model_name : [it.id],
    status: it.status || 'enabled',
    disabled_reason: it.disabled_reason || '',
    usable: it.usable !== false && inTimeWindow(it),
    hidden: it.hidden === true,
    available_from: it.available_from || '',
    available_until: it.available_until || '',
    inserted: it.hidden !== true && (it.status || 'enabled') === 'enabled'
  }));
  const total = all.length;
  const pages = Math.max(1, Math.ceil(total / pageSize));
  const p = Math.min(Math.max(1, page), pages);
  return {
    ok: true,
    total,
    total_pages: pages,
    page: p,
    page_size: pageSize,
    opencode_enabled: settings.opencodeEnabled && settings.authorized,
    items: all.slice((p - 1) * pageSize, p * pageSize)
  };
}

/**
 * 从官方目录刷新免费模型。免费判据只做两件有公开依据的事：
 *   · 目录条目 pricing 全为 0；
 *   · 或 id 以 -free 结尾 / 等于 big-pickle 等已知免费 id。
 * 刷新失败一律保留现有缓存（和原插件「刷新失败保留缓存」一致），不阻塞启动。
 */
function refreshCatalog(timeoutMs) {
  return new Promise((resolve) => {
    let u;
    try { u = new URL(ZEN_BASE + '/models'); } catch (_) { resolve(false); return; }
    const mod = u.protocol === 'https:' ? https : http;
    const req = mod.request(u, {
      method: 'GET',
      headers: {
        'Authorization': 'Bearer ' + ZEN_KEY,
        'Accept': 'application/json',
        'User-Agent': 'AggregateGateway/' + VERSION,
        'x-opencode-session': SESSION_ID
      },
      timeout: timeoutMs || 8000
    }, (res) => {
      let body = '';
      res.setEncoding('utf8');
      res.on('data', (c) => { if (body.length < 2 * 1024 * 1024) body += c; });
      res.on('end', () => {
        if (res.statusCode < 200 || res.statusCode >= 300) {
          bootlog('目录刷新 HTTP ' + res.statusCode + '，保留现有清单');
          resolve(false); return;
        }
        let parsed;
        try { parsed = JSON.parse(body); } catch (_) { bootlog('目录刷新返回非 JSON，保留现有清单'); resolve(false); return; }
        const rows = Array.isArray(parsed) ? parsed :
          (Array.isArray(parsed.data) ? parsed.data :
            (Array.isArray(parsed.models) ? parsed.models : []));
        if (!rows.length) { bootlog('目录刷新返回空列表，保留现有清单'); resolve(false); return; }
        const knownFree = new Set(['big-pickle']);
        const free = rows.filter((m) => {
          const id = String((m && (m.id || m.name)) || '');
          if (!id) return false;
          if (knownFree.has(id) || /-free$/i.test(id)) return true;
          const p = m && (m.pricing || m.cost || m.price);
          if (p && typeof p === 'object') {
            const nums = Object.values(p).filter((v) => typeof v === 'number');
            return nums.length > 0 && nums.every((v) => v === 0);
          }
          return false;
        });
        if (!free.length) { bootlog('目录里未筛出免费模型，保留现有清单'); resolve(false); return; }
        const oldById = {};
        (catalog.items || []).forEach((it) => { if (it && it.id) oldById[it.id] = it; });
        const items = free.map((m) => {
          const id = String(m.id || m.name);
          const old = oldById[id] || {};
          return {
            id,
            title: (m.name && m.name !== id ? m.name : (m.display_name || old.title || id)),
            api_base_url: ZEN_BASE,
            model_name: [id],
            status: 'enabled',
            usable: true,
            disabled_reason: '',
            hidden: old.hidden === true,
            context: (m.context_window || m.context || old.context) || null
          };
        });
        catalog = { updatedAt: nowIso(), source: ZEN_BASE + '/models', items };
        writeJson(F.catalog, catalog, 0o600);
        bootlog('目录刷新成功：' + items.length + ' 个免费模型 → models.json');
        resolve(true);
      });
    });
    req.on('timeout', () => { req.destroy(new Error('timeout')); });
    req.on('error', (e) => { bootlog('目录刷新失败（' + e.message + '），保留现有清单'); resolve(false); });
    req.end();
  });
}

// ---------------------------------------------------------------- HTTP 工具
function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Authorization, Content-Type');
  res.setHeader('Cache-Control', 'no-store');
}
function json(res, code, obj) {
  cors(res);
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(obj));
}
function isLoopback(addr) {
  if (!addr) return false;
  return addr === '127.0.0.1' || addr === '::1' || addr === '::ffff:127.0.0.1' || addr.startsWith('127.');
}
function bearer(req) {
  const h = String(req.headers.authorization || '');
  const m = h.match(/^Bearer\s+(.+)$/i);
  return m ? m[1].trim() : '';
}
/** /v1/* 必须带本地 Key；LAN 模式下额外接受独立 LAN Key */
function v1Authorized(req) {
  const k = bearer(req);
  if (!k) return false;
  if (k === LOCAL_KEY) return true;
  return LAN_RELAY && k === LAN_KEY;
}
/** /api/* 控制面：回环随便改；LAN 来源必须带 LAN Key（防止局域网别人关你的模型） */
function apiAuthorized(req) {
  if (isLoopback(req.socket && req.socket.remoteAddress)) return true;
  return LAN_RELAY && bearer(req) === LAN_KEY;
}
function readBody(req, res, cb) {
  const chunks = [];
  let size = 0;
  let done = false;
  req.on('data', (c) => {
    size += c.length;
    // 图片内联时请求体可能较大；超限要显式回 413，
    // 只 destroy() 而不回调会让客户端一直挂着等响应。
    if (size > 32 * 1024 * 1024) {
      if (!done) {
        done = true;
        json(res, 413, { error: { message: '请求体超过 32 MB', type: 'payload_too_large' } });
        req.destroy();
      }
      return;
    }
    chunks.push(c);
  });
  req.on('end', () => { if (!done) { done = true; cb(Buffer.concat(chunks)); } });
  req.on('error', () => { if (!done) { done = true; cb(Buffer.alloc(0)); } });
}

// ---------------------------------------------------------------- 上游转发
// 不做 TLS 指纹 / CLI 身份伪装：那套东西没有公开契约，写死只会随时间失效。
// 如需补充上游要求的请求头，用 ZEN_EXTRA_HEADERS（JSON 字符串）注入。
let extraHeaders = {};
try {
  const raw = process.env.ZEN_EXTRA_HEADERS || '';
  if (raw) extraHeaders = JSON.parse(raw);
} catch (_) { logError('ZEN_EXTRA_HEADERS 不是合法 JSON，已忽略'); }

function proxy(req, res, upstreamPath) {
  readBody(req, res, (body) => {
    let parsed = {};
    try { parsed = body.length ? JSON.parse(body.toString('utf8')) : {}; } catch (_) {}
    const model = String(parsed.model || '');
    const isStream = parsed.stream === true;

    let u;
    try { u = new URL(ZEN_BASE + upstreamPath); } catch (_) {
      json(res, 500, { error: { message: 'ZEN_BASE_URL 非法', type: 'gateway_config' } }); return;
    }
    const mod = u.protocol === 'https:' ? https : http;
    const headers = Object.assign({
      'Authorization': 'Bearer ' + ZEN_KEY,
      'Content-Type': 'application/json',
      'Accept': isStream ? 'text/event-stream' : 'application/json',
      'Content-Length': String(body.length),
      'User-Agent': 'AggregateGateway/' + VERSION,
      // OpenCode 文档要求每个会话带一个稳定的 x-opencode-session 以优化路由与缓存
      'x-opencode-session': SESSION_ID
    }, extraHeaders);

    const up = mod.request(u, { method: 'POST', headers }, (upRes) => {
      cors(res);
      const out = {};
      for (const [k, v] of Object.entries(upRes.headers)) {
        if (/^(transfer-encoding|connection|content-length|content-encoding|access-control-)/i.test(k)) continue;
        out[k] = v;
      }
      res.writeHead(upRes.statusCode || 502, out);
      upRes.pipe(res);

      usage.requests += 1;
      if (model) usage.byModel[model] = (usage.byModel[model] || 0) + 1;
      usage.lastAt = nowIso();
      if ((upRes.statusCode || 0) >= 400) usage.errors += 1;
      writeJson(F.usage, usage, 0o600);

      if ((upRes.statusCode || 0) >= 400) {
        bootlog('上游返回 HTTP ' + upRes.statusCode + '（model=' + (model || '?') + '），原样透传给客户端');
      }
    });
    up.on('timeout', () => { bootlog('上游连接超时'); up.destroy(new Error('upstream timeout')); });
    up.on('error', (e) => {
      usage.errors += 1; writeJson(F.usage, usage, 0o600);
      logError('上游请求失败：' + e.message);
      if (!res.headersSent) {
        json(res, 502, { error: { message: '上游不可达：' + e.message, type: 'upstream_unavailable' } });
      } else { try { res.end(); } catch (_) {} }
    });
    // 客户端断开（RikkaHub 取消 / 切后台被杀）→ 立即停掉上游，别白烧额度
    res.on('close', () => { if (!res.writableEnded) { try { up.destroy(); } catch (_) {} } });
    up.end(body);
  });
}

// ---------------------------------------------------------------- 管理页
function servePage(res) {
  cors(res);
  let html;
  try { html = fs.readFileSync(F.web, 'utf8'); }
  catch (_) { html = '<!doctype html><meta charset="utf-8"><h1>管理页缺失</h1>'; }
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
  res.end(html);
}

// ---------------------------------------------------------------- 路由
const ROUTES = {
  '/v1/chat/completions': '/chat/completions',
  '/v1/responses': '/responses',
  '/v1/messages': '/messages',
  '/v1/messages/count_tokens': '/messages/count_tokens'
};

const handler = (req, res) => {
  let pathname = '/';
  try { pathname = new URL(req.url, 'http://127.0.0.1').pathname; } catch (_) {}
  const method = req.method || 'GET';

  if (method === 'OPTIONS') { cors(res); res.writeHead(204); res.end(); return; }

  // 探活：HealthProbe.pingHealth 不带 Key，必须无条件 2xx
  if (pathname === '/health') {
    json(res, 200, {
      ok: true, gateway: runtime.gateway, version: VERSION,
      port: runtime.port, models: effectiveModels().length,
      catalogSource: catalog.source || 'builtin',
      catalogUpdatedAt: catalog.updatedAt || null,
      zenBase: ZEN_BASE, lanRelay: LAN_RELAY, uptime: Math.floor(process.uptime())
    });
    return;
  }

  // ---------------- OpenAI 兼容数据面 ----------------
  if (pathname === '/v1/models') {
    if (!v1Authorized(req)) { json(res, 401, { error: { message: '需要本地 API Key', type: 'invalid_api_key' } }); return; }
    json(res, 200, openAiModels()); return;
  }
  if (ROUTES[pathname]) {
    if (!v1Authorized(req)) { json(res, 401, { error: { message: '需要本地 API Key', type: 'invalid_api_key' } }); return; }
    if (method !== 'POST') { json(res, 405, { error: { message: '仅支持 POST' } }); return; }
    proxy(req, res, ROUTES[pathname]); return;
  }
  if (pathname.startsWith('/v1/')) {
    json(res, 404, { error: { message: '本网关仅提供 /v1/models、/v1/chat/completions、/v1/responses、/v1/messages' } });
    return;
  }

  // ---------------- 本地控制面（原作者后端的等价物） ----------------
  if (!apiAuthorized(req)) {
    json(res, 401, { error: { message: '控制面仅允许回环访问（或带 LAN Key）' } }); return;
  }
  if (pathname === '/api/version') { json(res, 200, { version: VERSION, local: true }); return; }
  if (pathname === '/api/articles') { json(res, 200, { ok: true, items: [] }); return; }
  if (pathname === '/api/license') {
    const act = new URL(req.url, 'http://127.0.0.1').searchParams.get('act');
    if (method === 'POST' && act === 'toggle') {
      readBody(req, res, (b) => {
        let o = {}; try { o = JSON.parse(b.toString('utf8')); } catch (_) {}
        if (typeof o.authorized === 'boolean') settings.authorized = o.authorized;
        writeJson(F.settings, settings, 0o600);
        json(res, 200, { ok: true, authorized: settings.authorized });
      }); return;
    }
    // 本地即授权方：默认已授权。原插件的 fail-closed 是「等远端信号」，
    // 这里没有远端，等价于把授权开关留在用户自己手里。
    json(res, 200, { ok: true, act: act || 'status', authorized: settings.authorized, local: true });
    return;
  }
  if (pathname === '/api/models') {
    if (method === 'POST') {
      readBody(req, res, (b) => {
        let o = {}; try { o = JSON.parse(b.toString('utf8')); } catch (_) {}
        const q = new URL(req.url, 'http://127.0.0.1').searchParams;
        const action = o.action || q.get('action') || '';
        if (action === 'toggle-global') {
          settings.opencodeEnabled = o.enabled === true;
          writeJson(F.settings, settings, 0o600);
          json(res, 200, { ok: true, opencode_enabled: settings.opencodeEnabled }); return;
        }
        if (action === 'toggle-model' && typeof o.id === 'string') {
          const it = (catalog.items || []).find((x) => x && x.id === o.id);
          if (!it) { json(res, 404, { ok: false, error: '模型不存在' }); return; }
          it.hidden = o.hidden === true;
          writeJson(F.catalog, catalog, 0o600);
          json(res, 200, { ok: true, id: o.id, hidden: it.hidden }); return;
        }
        json(res, 400, { ok: false, error: '未知 action' });
      }); return;
    }
    const q = new URL(req.url, 'http://127.0.0.1').searchParams;
    const page = positive(q.get('page'), 1);
    const size = Math.min(100, Math.max(1, positive(q.get('page_size'), 20)));
    json(res, 200, panelModels(page, size)); return;
  }
  if (pathname === '/api/refresh' && method === 'POST') {
    refreshCatalog(10000).then((ok) => json(res, 200, { ok, items: (catalog.items || []).length, source: catalog.source }));
    return;
  }
  if (pathname === '/api/usage') {
    json(res, 200, {
      ok: true, requests: usage.requests || 0, errors: usage.errors || 0,
      byModel: usage.byModel || {}, lastAt: usage.lastAt || null,
      keyFingerprint: crypto.createHash('sha256').update(LOCAL_KEY).digest('hex').slice(0, 12)
    });
    return;
  }
  if (pathname === '/api/settings') {
    json(res, 200, {
      ok: true, opencode_enabled: settings.opencodeEnabled, authorized: settings.authorized,
      lan_relay: LAN_RELAY, zen_base: ZEN_BASE, zen_key_is_public: ZEN_KEY === 'public',
      key_fingerprint: crypto.createHash('sha256').update(LOCAL_KEY).digest('hex').slice(0, 12)
    });
    return;
  }

  if (pathname === '/' || pathname === '/index.html') { servePage(res); return; }
  json(res, 404, { error: { message: 'Not Found' } });
};

// ---------------------------------------------------------------- 启动 + 端口顺延
let actualPort = REQUESTED_PORT;
let attempts = 0;
let started = false;

/**
 * ★ 端口顺延时必须【新建一个 Server 实例】。
 * Node 的 net.Server 在 listen() 抛 EADDRINUSE 后，对同一个实例再次调用
 * listen() 不会重新触发 'listening'（内部 handle 已处于失败态），表现为
 * 日志写了「顺延到 18901」但 runtime 永远停在 18900、/health 无人监听。
 * 每次 start() 都 http.createServer(handler) 并重新注册事件即可避开。
 */
function start(port) {
  const s = http.createServer(handler);

  s.on('listening', () => {
    actualPort = s.address().port;
    runtime.port = actualPort;
    runtime.manageUrl = 'http://' + LOOPBACK_HOST + ':' + actualPort + '/';
    publish();
    if (started) return;
    started = true;
    bootlog('本地网关已监听 http://' + LOOPBACK_HOST + ':' + actualPort +
      '/v1（绑定 ' + BIND_HOST + '，LAN 中继=' + LAN_RELAY + '）');
    bootlog('内置/缓存免费模型 ' + effectiveModels().length + ' 个，来源=' + (catalog.source || 'builtin'));
    bootlog('上游 ' + ZEN_BASE + '，认证=' + (ZEN_KEY === 'public' ? 'Bearer public（匿名免费档）' : '自有 Zen Key'));

    // 后台刷新目录：失败保留缓存，绝不影响 /health 握手
    refreshCatalog(8000).then((ok) => {
      if (ok) publish();
      bootlog('目录刷新' + (ok ? '完成' : '未生效（使用缓存）') + '，当前可用模型 ' + effectiveModels().length + ' 个');
    });
  });

  s.on('error', (e) => {
    if (e && e.code === 'EADDRINUSE' && attempts < 20) {
      attempts += 1;
      const next = actualPort + 1;
      bootlog('端口 ' + actualPort + ' 被占用，顺延到 ' + next);
      actualPort = next;
      setTimeout(() => {
        // 失败的实例不再复用；close 未监听的 server 会抛，忽略即可
        try { s.close(); } catch (_) {}
        start(actualPort);
      }, 120);
    } else {
      fatal('无法监听端口：' + (e && e.message || e));
    }
  });

  s.listen(port, BIND_HOST);
}

start(actualPort);
