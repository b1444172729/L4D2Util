'use strict';
/**
 * 聚合网关 · Node 侧启动入口（由 nodejs-mobile 以 `node bootstrap.js ...` 执行）
 *
 * 职责只有三件，绝不改写原仓库逻辑：
 *   1. 把安卓私有目录映射成 standalone 的 OFM_HOME，并透传端口 / 数据目录；
 *   2. 找到并 require 原仓库 packages/standalone 的真实入口，让原插件能力全量跑起来；
 *   3. 把「实际端口 / API Key / 一次性管理链接」回写成 gateway-runtime.json，
 *      供安卓壳与 WebView 读取（端口顺延、Key 不回显这两条原插件行为因此得以保留）。
 *
 * 注意：standalone 的安装制品与 Release 尚未发布，必须从完整源码仓库运行，
 * 因此 assets/node 里放的是「完整仓库剪掉 .git」，不能只拷 packages/standalone。
 */

const fs = require('fs');
const path = require('path');
const ROOT = __dirname;

// ---------------------------------------------------------------- 参数
// 安卓侧由 C 胶水把配置 setenv 成 OFM_*，argv 只保留 ["node", 本脚本]。
// 命令行参数仍保留兼容（桌面端/手工运行），且优先级高于环境变量。
function parseArgs(argv) {
  const positive = (v, d) => {
    const n = parseInt(v || '', 10);
    return Number.isFinite(n) && n > 0 ? n : d;
  };
  const out = {
    port: positive(process.env.OFM_PORT, 18900),
    dataDir: process.env.OFM_DATA_DIR || '',
    host: process.env.OFM_HOST || '127.0.0.1',
    lanRelay: process.env.OFM_LAN_RELAY === '1'
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--') continue;
    if (a === '--port') out.port = positive(argv[++i], out.port);
    else if (a === '--data-dir') out.dataDir = argv[++i];
    else if (a === '--host') out.host = argv[++i];
    else if (a === '--lan-relay') out.lanRelay = true;
  }
  return out;
}

const opts = parseArgs(process.argv.slice(2));
const DATA_DIR = opts.dataDir || path.join(process.env.HOME || ROOT, '.our-free-model');
fs.mkdirSync(DATA_DIR, { recursive: true });

// standalone 认 OFM_HOME / --data-dir，这里把安卓路径统一喂进去
process.env.OFM_HOME = DATA_DIR;
process.env.OFM_HOST = opts.host;
process.env.OFM_PORT = String(opts.port);

const RUNTIME_FILE = path.join(DATA_DIR, 'gateway-runtime.json');
const ERROR_LOG = path.join(DATA_DIR, 'node-errors.log');
const OUTPUT_LOG = path.join(DATA_DIR, 'node-output.log');
const SETTINGS_FILE = path.join(DATA_DIR, 'settings.json');

// ★ JS 层心跳：用 fs 直接写，不依赖 stdout。
// 日志里若出现这一行，说明 Node/V8 初始化成功、脚本已被执行；
// 没有这一行则是引擎层就挂了。这是区分两层故障的关键分界线。
function jsbeat(msg) {
  try { fs.appendFileSync(OUTPUT_LOG, '[bootstrap] ' + msg + '\n'); } catch (_) {}
}
jsbeat('JS 层已启动 pid=' + process.pid +
  ' node=' + process.version +
  ' cwd=' + process.cwd() +
  ' port=' + opts.port +
  ' OFM_HOME=' + DATA_DIR);

// ------------------------------------------------- 异常退出后的锁残留处理
// 桌面文档：异常退出若 service.lock 仍在，先核对 PID，确认旧进程已停再移除。
(function clearStaleLock() {
  const lock = path.join(DATA_DIR, 'service.lock');
  if (!fs.existsSync(lock)) return;
  try {
    const raw = JSON.parse(fs.readFileSync(lock, 'utf8'));
    const pid = Number(raw.pid || raw.PID || 0);
    if (pid && pid !== process.pid) {
      let alive = false;
      try { process.kill(pid, 0); alive = true; } catch (_) { alive = false; }
      if (!alive) fs.unlinkSync(lock);
      else logError('service.lock 指向仍存活的进程，未自动清理：pid=' + pid);
    }
  } catch (_) {
    // 锁文件内容不可解析时保守保留，由用户在管理页手动处理
    logError('service.lock 无法解析，保留原样');
  }
})();

function logError(msg) {
  try { fs.appendFileSync(ERROR_LOG, `[${new Date().toISOString()}] ${msg}\n`); } catch (_) {}
}

// Node 崩溃不能直接 exit()：在安卓里会连同宿主 App 一起被结束
process.on('uncaughtException', (e) => logError('uncaughtException: ' + (e && e.stack || e)));
process.on('unhandledRejection', (e) => logError('unhandledRejection: ' + (e && e.stack || e)));

// ------------------------------------------------- 运行信息回写（原子写）
const runtime = {
  port: opts.port,
  requestedPort: opts.port,
  apiKey: '',
  manageUrl: '',
  host: opts.host,
  pid: process.pid,
  startedAt: new Date().toISOString()
};

function publish() {
  const tmp = RUNTIME_FILE + '.tmp';
  try {
    fs.writeFileSync(tmp, JSON.stringify(runtime, null, 2), { mode: 0o600 });
    fs.renameSync(tmp, RUNTIME_FILE);
  } catch (e) {
    logError('写 gateway-runtime.json 失败: ' + e.message);
  }
}
// 同步先读一次：standalone 通常在 listen 之前就已落盘 settings.json
runtime.apiKey = readKey();
publish();

// ------------------------------------------------- 从 stdout 抓运行信息
// standalone 启动时会打印：API 地址、一次性管理登录链接、密钥文件位置（不打印 Key）。
// 我们不改它的输出，只在同一行里做只读匹配，顺带捕获「实际监听端口」。
const originalLog = console.log.bind(console);
const originalError = console.error.bind(console);

function observe(line) {
  const s = String(line);
  const api = s.match(/https?:\/\/127\.0\.0\.1:(\d+)\/v1/);
  if (api) { runtime.port = parseInt(api[1], 10); publish(); }

  const shifted = s.match(/实际监听\s*(\d+)/) || s.match(/actual\s+port\s*[:=]?\s*(\d+)/i);
  if (shifted) { runtime.port = parseInt(shifted[1], 10); publish(); }

  const url = s.match(/https?:\/\/127\.0\.0\.1:\d+[^\s"'<>]*/);
  if (url && !runtime.manageUrl) {
    runtime.manageUrl = url[0];
    originalLog('[bootstrap] 捕获管理页一次性链接');
    publish();
  }
}

// 除了走 stdout（C 层已 dup2 到日志文件），再用 fs 直写一份带 [js] 前缀的副本。
// Node 内部可能重新接管 stdio，直写能保证无论怎样都留得下 standalone 的输出。
console.log = (...args) => {
  const s = args.map(String).join(' ');
  observe(s);
  try { fs.appendFileSync(OUTPUT_LOG, '[js] ' + s + '\n'); } catch (_) {}
  originalLog(...args);
};
console.error = (...args) => {
  const s = args.map(String).join(' ');
  observe(s);
  try { fs.appendFileSync(OUTPUT_LOG, '[js:err] ' + s + '\n'); } catch (_) {}
  originalError(...args);
};

// ------------------------------------------------- Key 读取（60 秒轮询）
// 字段名随版本可能变化，这里做宽松探测；绝不在日志里输出 Key 内容。
function readKey() {
  try {
    if (!fs.existsSync(SETTINGS_FILE)) return '';
    const o = JSON.parse(fs.readFileSync(SETTINGS_FILE, 'utf8'));
    const candidates = ['forwardKey', 'apiKey', 'localKey', 'key', 'token'];
    for (const k of candidates) {
      if (typeof o[k] === 'string' && o[k].trim()) return o[k].trim();
    }
    // 有些版本把 Key 放在嵌套对象里
    for (const v of Object.values(o)) {
      if (v && typeof v === 'object') {
        for (const k of candidates) {
          if (typeof v[k] === 'string' && v[k].trim()) return v[k].trim();
        }
      }
    }
  } catch (_) {}
  return '';
}

const keyTimer = setInterval(() => {
  if (runtime.apiKey) { clearInterval(keyTimer); return; }
  const k = readKey();
  if (k) {
    runtime.apiKey = k;
    publish();
    originalLog('[bootstrap] 已读取本机 API Key（内容不回显）');
    clearInterval(keyTimer);
  }
}, 500);
setTimeout(() => clearInterval(keyTimer), 60_000);

// ------------------------------------------------- 定位 standalone 入口
function resolveEntry() {
  // 优先按根 package.json 的 npm script 推断，避免硬编码随版本变化的文件名
  try {
    const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
    const script = (pkg.scripts || {})['start:standalone'];
    if (script) {
      const m = script.match(/(?:node|nodejs)\s+([^\s]+\.js)/i);
      if (m) {
        const p = path.resolve(ROOT, m[1]);
        if (fs.existsSync(p)) return p;
      }
    }
  } catch (_) {}

  const candidates = [
    'packages/standalone/src/index.js',
    'packages/standalone/index.js',
    'packages/standalone/dist/index.js',
    'packages/standalone/server.js',
    'packages/standalone/src/server.js',
    'packages/standalone/main.js'
  ];
  for (const c of candidates) {
    const p = path.resolve(ROOT, c);
    if (fs.existsSync(p)) return p;
  }
  throw new Error(
    '未找到 standalone 入口。请检查 packages/standalone 的实际文件名，' +
    '并修改 bootstrap.js 的 candidates 或根 package.json 的 start:standalone 脚本。'
  );
}

// ------------------------------------------------- 启动
(async function main() {
  try {
    const entry = resolveEntry();
    jsbeat('standalone entry=' + entry);
    originalLog('[bootstrap] OFM_HOME=' + DATA_DIR);
    originalLog('[bootstrap] standalone entry=' + entry);
    originalLog('[bootstrap] requested port=' + opts.port + ', lanRelay=' + opts.lanRelay);

    // 把参数以命令行形式传给原入口（原入口读 process.argv 时也能拿到）。
    // 环境变量 OFM_* 已由 C 层设好，这里双通道兼容 standalone 的版本差异。
    process.argv = [
      process.argv[0],
      entry,
      '--port', String(opts.port),
      '--data-dir', DATA_DIR,
      ...(opts.lanRelay ? ['--lan-relay'] : [])
    ];
    jsbeat('即将 require(entry)，此后交给 standalone');

    try {
      require(entry);
    } catch (e) {
      if (e && e.code === 'ERR_REQUIRE_ESM') {
        await import(require('url').pathToFileURL(entry).href);
      } else {
        throw e;
      }
    }
  } catch (e) {
    logError('启动 standalone 失败: ' + (e && e.stack || e));
    originalError('[bootstrap] 启动失败，详情见 ofm-data/node-errors.log');
  }
})();
