// 占位文件：本改造版由 bootstrap.cjs 直接加载 oc-proxy.cjs，
// 不再运行上游 standalone。保留此路径仅为满足 AssetInstaller / CI 的完整性判据。
export {};
