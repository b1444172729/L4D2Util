package com.android.dsh.ui

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.dsh.GatewayApp
import com.android.dsh.R
import com.android.dsh.core.GatewayConfig

/**
 * 内嵌管理页容器。
 *
 * 真正的管理页由 standalone 自己提供（模型 / 统计 / 渠道 / EAC / 设置 / API Key），
 * 这里只是一个 WebView 壳，不做任何业务逻辑，保证原插件功能不被改写。
 */
class ManageActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var errorText: TextView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        bar.addView(Button(this).apply {
            text = "返回"
            isAllCaps = false
            setOnClickListener { finish() }
        })
        bar.addView(Button(this).apply {
            text = "刷新"
            isAllCaps = false
            setOnClickListener { load() }
        })
        bar.addView(Button(this).apply {
            text = "外部浏览器"
            isAllCaps = false
            setOnClickListener {
                val url = currentUrl()
                if (url != null) startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            }
        })
        root.addView(bar, LinearLayout.LayoutParams(-1, -2))

        val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            isIndeterminate = false
        }
        root.addView(progress, LinearLayout.LayoutParams(-1, dp(3)))

        errorText = TextView(this).apply {
            setPadding(dp(16), dp(12), dp(16), dp(12))
            textSize = 14f
            visibility = View.GONE
        }
        root.addView(errorText)

        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.useWideViewPort = true
            settings.loadWithOverviewMode = true
            settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                    // 只在本 WebView 内跟进回环地址，其它一律交给系统浏览器
                    return if (url.startsWith("http://${GatewayConfig.LOOPBACK}") ||
                        url.startsWith("http://localhost")
                    ) {
                        false
                    } else {
                        runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
                        true
                    }
                }

                override fun onReceivedError(
                    view: WebView, errorCode: Int, description: String?, failingUrl: String?
                ) {
                    showError("管理页加载失败：$description\n请先确认前台服务处于「运行中」状态")
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView, newProgress: Int) {
                    progress.progress = newProgress
                    progress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
                }
            }
        }
        root.addView(webView, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        load()
    }

    private fun currentUrl(): String? {
        val s = GatewayApp.instance.status.value
        if (s.state != GatewayApp.State.READY || s.port <= 0) return null
        return s.manageUrl.ifBlank { "http://${GatewayConfig.LOOPBACK}:${s.port}/" }
    }

    private fun load() {
        val url = currentUrl()
        if (url == null) {
            showError("网关尚未就绪。请先在「聚合网关」主界面点击「启动网关」，再回来打开管理页。")
            Toast.makeText(this, "网关未就绪", Toast.LENGTH_SHORT).show()
            return
        }
        errorText.visibility = View.GONE
        webView.visibility = View.VISIBLE
        webView.loadUrl(url)
    }

    private fun showError(msg: String) {
        errorText.text = msg
        errorText.visibility = View.VISIBLE
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
