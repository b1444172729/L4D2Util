package com.android.dsh

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class GatewayApp : Application() {

    enum class State { STOPPED, STARTING, READY, ERROR }

    data class Status(
        val state: State = State.STOPPED,
        val port: Int = 0,
        val apiKey: String = "",
        val manageUrl: String = "",
        val message: String = ""
    ) {
        val baseUrl: String get() = "http://127.0.0.1:$port/v1"
    }

    companion object {
        const val CHANNEL_ID = "gateway_foreground"
        lateinit var instance: GatewayApp
            private set
    }

    private val _status = MutableStateFlow(Status())
    val status: StateFlow<Status> get() = _status

    fun post(status: Status) {
        _status.value = status
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.O) return
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.channel_name),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = getString(R.string.channel_desc)
            setShowBadge(false)
        }
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(channel)
    }
}
