package com.android.dsh.ui

import android.content.Context
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.ShapeDrawable
import android.graphics.drawable.shapes.PathShape
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

/**
 * 主页视觉基元（r17）。全部用代码绘制，不引入新的 layout XML / 第三方 UI 库，
 * 避免影响已经验证过的悬浮窗、管理页与通知资源。
 *
 * 配色取自图标母版：深蓝紫底 + 青色轨道 + 紫色弧，整体走暗色玻璃卡片风格。
 * 这里只提供「画什么」，不持有任何业务状态；交互与状态仍全在 MainActivity。
 */
object UiTheme {

    val BG_TOP = Color.parseColor("#080D20")
    val BG_MID = Color.parseColor("#0D1430")
    val BG_BOTTOM = Color.parseColor("#121C3C")

    val CARD = Color.parseColor("#161F3B")
    val CARD_INNER = Color.parseColor("#0E1730")
    val STROKE = Color.parseColor("#2A3A63")

    val TEXT = Color.parseColor("#EDF3FF")
    val TEXT_SUB = Color.parseColor("#9AAACB")
    val TEXT_DIM = Color.parseColor("#64739A")

    val ACCENT = Color.parseColor("#34D9F0")
    val ACCENT_2 = Color.parseColor("#7B76F2")

    val OK = Color.parseColor("#4BE3A2")
    val WARN = Color.parseColor("#FFC46B")
    val ERROR = Color.parseColor("#FF7A8A")
    val IDLE = Color.parseColor("#8A97B8")

    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()
    fun dpF(ctx: Context, v: Float): Float = v * ctx.resources.displayMetrics.density

    /** 页面背景：三段竖向渐变，比纯黑更有层次。 */
    fun pageBackground(): GradientDrawable = GradientDrawable(
        GradientDrawable.Orientation.TOP_BOTTOM,
        intArrayOf(BG_TOP, BG_MID, BG_BOTTOM)
    )

    /** 通用玻璃卡片。 */
    fun card(ctx: Context, radius: Float = 20f, fill: Int = CARD, stroke: Int = STROKE) =
        GradientDrawable().apply {
            setCornerRadius(dpF(ctx, radius))
            setColor(fill)
            setStroke(dp(ctx, 1), stroke)
        }

    /** 顶部主状态卡：斜向深蓝渐变 + 冷色描边。 */
    fun hero(ctx: Context) = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(
            Color.parseColor("#1C355C"),
            Color.parseColor("#152142"),
            Color.parseColor("#1A2350")
        )
    ).apply {
        setCornerRadius(dpF(ctx, 22f))
        setStroke(dp(ctx, 1), Color.parseColor("#35507F"))
    }

    /** 主按钮：青 → 紫横向渐变。 */
    fun primary(ctx: Context) = GradientDrawable(
        GradientDrawable.Orientation.LEFT_RIGHT,
        intArrayOf(ACCENT, ACCENT_2)
    ).apply { setCornerRadius(dpF(ctx, 15f)) }

    /** 次级按钮：深色描边幽灵按钮。 */
    fun ghost(ctx: Context) = GradientDrawable().apply {
        setCornerRadius(dpF(ctx, 13f))
        setColor(Color.parseColor("#1B2846"))
        setStroke(dp(ctx, 1), STROKE)
    }

    /** 胶囊标签 / 小按钮。 */
    fun pill(ctx: Context, fill: Int, radius: Float = 999f) = GradientDrawable().apply {
        setCornerRadius(dpF(ctx, radius))
        setColor(fill)
    }

    /** 状态圆点。 */
    fun dot(color: Int, sizePx: Int) = GradientDrawable().apply {
        setShape(GradientDrawable.OVAL)
        setColor(color)
        setSize(sizePx, sizePx)
    }

    /**
     * 折叠箭头：用 Path 画实心三角形，不依赖系统字体是否含 ▾/▴ 字形，
     * 避免出现「豆腐块」。up=true 为收起方向（▲），false 为展开方向（▼）。
     */
    fun chevron(up: Boolean, color: Int = ACCENT) = ShapeDrawable(
        PathShape(Path().apply {
            if (up) {
                moveTo(0f, 1f); lineTo(0.5f, 0f); lineTo(1f, 1f)
            } else {
                moveTo(0f, 0f); lineTo(1f, 0f); lineTo(0.5f, 1f)
            }
            close()
        }, 1f, 1f)
    ).apply {
        paint.setColor(color)
        paint.setStyle(Paint.Style.FILL)
        paint.setAntiAlias(true)
    }

    fun divider(ctx: Context) = View(ctx).apply {
        background = ColorDrawable(STROKE)
    }

    /** 按钮统一用 TextView：没有系统 Button 的默认内边距与全大写，圆角和渐变完全可控。 */
    fun button(
        ctx: Context,
        label: String,
        bg: GradientDrawable,
        textColor: Int = TEXT,
        sizeSp: Float = 13.5f,
        heightDp: Int = 46,
        bold: Boolean = true
    ) = TextView(ctx).apply {
        text = label
        setTextColor(textColor)
        textSize = sizeSp
        if (bold) typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        background = bg
        isClickable = true
        isFocusable = true
        minimumHeight = dp(ctx, heightDp)
        setPadding(dp(ctx, 12), dp(ctx, 8), dp(ctx, 12), dp(ctx, 8))
    }

    /** 小胶囊按钮（显示 / 复制 / 设置）。 */
    fun chip(ctx: Context, label: String, fill: Int, textColor: Int) = TextView(ctx).apply {
        text = label
        setTextColor(textColor)
        textSize = 11f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        background = pill(ctx, fill)
        setPadding(dp(ctx, 12), dp(ctx, 6), dp(ctx, 12), dp(ctx, 6))
        isClickable = true
        isFocusable = true
    }

    /** 分区标题：左侧青色小竖条 + 标题文字。 */
    fun section(ctx: Context, label: String) = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        addView(View(ctx).apply {
            background = GradientDrawable().apply {
                setCornerRadius(dpF(ctx, 2f))
                setColor(ACCENT)
            }
        }, LinearLayout.LayoutParams(dp(ctx, 3), dp(ctx, 15)).apply {
            marginEnd = dp(ctx, 9)
        })
        addView(TextView(ctx).apply {
            text = label
            textSize = 13f
            setTextColor(TEXT)
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.06f
        })
    }

    /** 说明小字。 */
    fun note(ctx: Context, text: String) = TextView(ctx).apply {
        this.text = text
        textSize = 11.5f
        setTextColor(TEXT_DIM)
        setLineSpacing(dpF(ctx, 3f), 1f)
    }
}
