package com.android.dsh.core

import android.content.Context
import java.io.File

/**
 * 运行时自检。
 *
 * 背景：nodejs-mobile 在「原生 Android App」里的集成方式与 React Native 插件不同。
 * 官方只发布 libnode.so + node 头文件，Java 桥接类属于 RN 插件且依赖插件自编的
 * 另一份 .so，并不存在可直接塞进 app/libs/ 的独立 aar。
 * 因此「只差一个文件」的假设不成立，缺运行时是一类结构性缺失。
 *
 * 这个类的作用是把这类缺失从一串类名（ClassNotFoundException 的 message）
 * 变成界面上能看懂的三项状态，避免用户对着 com.janeasystems... 无从下手。
 */
object RuntimeDiagnostics {

    data class Report(
        val upstreamBundle: Boolean,
        val libnode: Boolean,
        val bridge: Boolean,
        val released: Boolean
    ) {
        val canStartNode: Boolean get() = upstreamBundle && libnode && bridge

        fun summary(): String = buildString {
            appendLine("运行时自检")
            appendLine("  上游仓库 bundle.zip：${mark(upstreamBundle)}")
            appendLine("  Node 原生库 libnode.so：${mark(libnode)}")
            appendLine("  Java 桥接层：${mark(bridge)}")
            appendLine("  已释放代码目录：${mark(released)}")
        }

        /** 缺哪几项、意味着什么、能做什么，全部用中文说清 */
        fun advice(): String {
            if (canStartNode) return "运行时齐备。"
            return buildString {
                if (!upstreamBundle) {
                    appendLine("· 缺上游仓库 bundle.zip：需由 CI 执行 prepare-node-bundle.sh 生成并打进 assets。")
                }
                if (!libnode) {
                    appendLine("· 缺 libnode.so：APK 内没有 Node.js 引擎，网关无法启动。")
                    appendLine("  这不是漏放一个文件，而是需要原生集成（NDK/CMake 编一层 JNI 胶水调用 node::Start）。")
                }
                if (!bridge) {
                    appendLine("· 缺 Java 桥接层：没有能调用 native 方法的类。")
                    appendLine("  官方未发布独立 aar，RN 插件的类还依赖另一份自编 .so，不能只靠 app/libs/ 补齐。")
                }
                if (released && !canStartNode) {
                    appendLine("· 上游源码已成功释放到私有目录，问题只在 Node 运行时这一侧。")
                }
                append("结论：当前 APK 是「壳」，能装能开界面，但启动不了网关。")
            }
        }

        private fun mark(b: Boolean) = if (b) "✅ 已就位" else "❌ 缺失"
    }

    fun check(ctx: Context): Report {
        // 用 list() 而不是 open().read()：bundle.zip 可能有几十 MB，
        // 自检只判断存在性，不实际读取内容。
        val assetNames = runCatching { ctx.assets.list("node").orEmpty().toSet() }
            .getOrDefault(emptySet())
        val upstreamBundle = assetNames.contains("bundle.zip")

        // libnode.so 若随 APK 打包，会被系统解压到 nativeLibraryDir；
        // 同时兼容直接从 classpath 探测的情形。
        val nativeDir = ctx.applicationInfo.nativeLibraryDir.orEmpty()
        val libnode = (nativeDir.isNotBlank() && File(nativeDir, "libnode.so").isFile) ||
            runCatching {
                System.getProperty("java.library.path").orEmpty()
                    .split(File.pathSeparator)
                    .any { File(it, "libnode.so").isFile }
            }.getOrDefault(false)

        val bridge = runCatching {
            Class.forName(NodeRuntime.NODE_CLASS, false, ctx.classLoader)
            true
        }.getOrDefault(false)

        val nodeHome = GatewayConfig.nodeHome(ctx)
        val released = File(nodeHome, "bootstrap.js").isFile &&
            File(nodeHome, "package.json").isFile

        return Report(upstreamBundle, libnode, bridge, released)
    }
}
