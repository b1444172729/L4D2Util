package com.android.dsh.core

import android.content.Context
import com.android.dsh.GatewayApp
import java.io.File
import org.json.JSONObject

/**
 * 运行时自检（r11 / Node 22 + JNI 路线）。四项缺一不可：
 *   上游源码（散放 assets/node）/ libnode.so / 自建 JNI 胶水 / 已释放代码目录。
 *
 * r11：源码判据从「assets/node 里有 bundle.zip」改成散放三件套；
 * libnode / 胶水 / 符号探测 / ICU 兜底保持 r5 已验证的形态不变。
 *
 * 注意：官方 nodejs-mobile 只发布 libnode.so + headers，Java 桥接类属于
 * React Native 插件，没有可独立使用的 aar。因此这一层必须由本工程自己
 * 用 CMake 编（见 app/src/main/cpp/dsh-node.c），不能靠往 app/libs/ 丢文件补齐。
 */
object RuntimeDiagnostics {

    data class Report(
        val upstreamBundle: Boolean,
        val libnode: Boolean,
        val glue: Boolean,
        val released: Boolean,
        val probe: String,
        val libnodeInfo: String,
        val icuInfo: String,
        val notifyInfo: String = "",
        val extraInfo: String = ""
    ) {
        val canStartNode: Boolean get() = upstreamBundle && libnode && glue && released

        fun summary(): String = buildString {
            appendLine("运行时自检")
            appendLine("  上游源码（散放 assets/node）：${mark(upstreamBundle)}")
            appendLine("  Node 原生库 libnode.so：${mark(libnode)}")
            if (libnodeInfo.isNotBlank()) appendLine("  $libnodeInfo")
            appendLine("  $icuInfo")
            appendLine("  自建 JNI 胶水：${mark(glue)}")
            appendLine("  已释放代码目录：${mark(released)}")
            appendLine("  符号探测：$probe")
            if (notifyInfo.isNotBlank()) appendLine("  $notifyInfo")
            if (extraInfo.isNotBlank()) appendLine("  $extraInfo")
        }

        fun advice(): String {
            if (canStartNode) return "运行时齐备，可以启动网关。"
            return buildString {
                if (!upstreamBundle) {
                    appendLine("· 缺上游源码：需由 CI 执行 prepare-node-bundle.sh 生成散放源码并打进 assets/node。")
                }
                if (!libnode) {
                    appendLine("· 缺 libnode.so：在 Run workflow 里填 libnode_url，或把 arm64 的 libnode.so 放进 app/src/main/jniLibs/arm64-v8a/。")
                }
                if (!glue) {
                    appendLine("· 缺自建 JNI 胶水：本次 APK 是用不含 app/src/main/cpp/ 的旧源码编译的，请替换为最新完整包。")
                }
                if (!released) {
                    appendLine("· 代码目录未释放：启动一次网关后会自动从 assets 解压。")
                }
                append("结论：当前 APK 运行时尚未齐备，网关起不来。")
            }
        }

        private fun mark(b: Boolean) = if (b) "✅ 已就位" else "❌ 缺失"
    }

    fun check(ctx: Context): Report {
        // r11：源码散放，判据是三件套都在（cli.mjs 需实际可 open，
        // 避免 assets.list 对深层目录返回空导致误判）。
        val assetNames = runCatching { ctx.assets.list("node").orEmpty().toSet() }
            .getOrDefault(emptySet())
        val upstreamBundle = assetNames.contains("package.json") &&
            assetNames.contains("bootstrap.cjs") &&
            runCatching {
                ctx.assets.open("node/packages/standalone/cli.mjs").close()
                true
            }.getOrDefault(false)

        val nativeDir = ctx.applicationInfo.nativeLibraryDir.orEmpty()
        val libnode = nativeDir.isNotBlank() && File(nativeDir, "libnode.so").isFile

        val glue = NodeBridge.isAvailable()
        val probe = if (glue && libnode) {
            NodeBridge.probe(NodeRuntime.libnodePath(ctx))
        } else {
            "跳过（${if (!glue) "胶水未加载" else "libnode.so 缺失"}）"
        }

        val nodeHome = GatewayConfig.nodeHome(ctx)
        val released = File(nodeHome, "bootstrap.cjs").isFile &&
            File(nodeHome, "package.json").isFile

        // 只读取 ELF 头前 20 字节，不扫 60MB 全文：能核对是不是 arm64 的 64 位 ELF，
        // 避免「下载到了 x86_64 或别的项目的 .so」却一直不知道。
        val libnodeInfo = if (libnode) {
            val f = File(nativeDir, "libnode.so")
            val sizeMb = f.length() / 1024.0 / 1024.0
            val elf = runCatching {
                val h = ByteArray(20)
                f.inputStream().use { it.read(h) }
                val isElf = h[0] == 0x7f.toByte() && h[1] == 'E'.code.toByte() &&
                    h[2] == 'L'.code.toByte() && h[3] == 'F'.code.toByte()
                val is64 = h[4] == 2.toByte()
                val machine = (h[18].toInt() and 0xff) or ((h[19].toInt() and 0xff) shl 8)
                val arch = when (machine) {
                    0xB7 -> "AArch64 ✅"
                    0x3E -> "x86_64 ❌"
                    0x28 -> "ARMv7 ❌"
                    else -> "0x${machine.toString(16)}"
                }
                "${if (isElf) "ELF" else "非 ELF ❌"} / ${if (is64) "64位" else "32位 ❌"} / $arch"
            }.getOrDefault("ELF 头读取失败")
            "二进制核对：${"%.1f".format(sizeMb)} MB · $elf"
        } else ""

        val icuReady = File(nodeHome, "icudtl.dat").isFile ||
            File(nodeHome, "icu/icudtl.dat").isFile
        val icuInfo = if (icuReady) {
            "ICU 数据 icudtl.dat：✅ 已释放（NODE_ICU_DATA 会自动指向）"
        } else {
            "ICU 数据 icudtl.dat：未随包提供（v22 已内嵌 full-icu，属正常）"
        }

        // r16：实际探测 APK 里有没有新通知图标资源，避免「改了工程包但 APK 里没有」。
        // 这一行会显示在界面自检区，用户截图即可确认装的是不是新包。
        val hasStatus = ctx.resources.getIdentifier(
            "ic_gateway_status", "drawable", ctx.packageName) != 0
        val hasArt = ctx.resources.getIdentifier(
            "ic_gateway_art", "drawable", ctx.packageName) != 0
        val notifyInfo = "通知图标(r16)：${GatewayApp.CHANNEL_ID} · " +
            "smallIcon=${if (hasStatus) "✅ 新轨道" else "❌ 缺失"} · " +
            "largeIcon=${if (hasArt) "✅ 彩色主图" else "❌ 缺失"}"

        // r19：直接读 Node 侧写的 patch-status.json。三段判据分别是
        // 「配置/内置默认 → 是否真的写进 catalog.js → /v1/models 是否广播」，
        // 不再靠「文件是否存在」猜，也不会把空转显示成「⏳ 启动后生效」。
        val extraInfo = runCatching {
            val statusFile = File(GatewayConfig.dataDir(ctx), "patch-status.json")
            if (!statusFile.isFile) {
                "模型声明补丁(r19)：⏳ 尚未启动网关（启动后写状态）"
            } else {
                val j = JSONObject(statusFile.readText())
                val ids = j.optJSONArray("ids")?.length() ?: 0
                val injected = j.optBoolean("injected", false)
                val source = j.optString("source", "?")
                val reason = j.optString("reason", "")
                val bc = j.optJSONObject("broadcast")
                val bcText = when {
                    bc == null -> " · /v1/models 待启动自检"
                    bc.has("error") -> " · /v1/models ❌ ${bc.optString("error")}"
                    else -> " · /v1/models 命中 ${bc.optInt("hit")}/$ids" +
                        if (bc.optJSONArray("missing")?.length() ?: 0 > 0)
                            "（缺 ${bc.optJSONArray("missing")?.length()} 个）" else " ✅"
                }
                "模型声明补丁(r19)：${if (injected) "✅ 注入生效" else "❌ 未注入"}" +
                    " · $ids 个 ID · 来源 $source$bcText" +
                    (if (!injected && reason.isNotBlank()) " · $reason" else "")
            }
        }.getOrDefault("模型声明补丁(r19)：状态读取失败")

        return Report(
            upstreamBundle, libnode, glue, released, probe,
            libnodeInfo, icuInfo, notifyInfo, extraInfo
        )
    }
}
