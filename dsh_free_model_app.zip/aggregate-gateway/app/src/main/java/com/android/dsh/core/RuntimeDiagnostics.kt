package com.android.dsh.core

import android.content.Context
import java.io.File

/**
 * 运行时自检。四项缺一不可：
 *   上游仓库 bundle.zip / libnode.so / 自建 JNI 胶水 / 已释放代码目录。
 *
 * 注意：官方 nodejs-mobile 只发布 libnode.so + headers，Java 桥接类属于
 * React Native 插件，没有可独立使用的 aar。因此这一层必须由本工程自己
 * 用 CMake 编（见 app/src/main/cpp/dsh-node.c），不能靠往 app/libs/ 丢文件补齐。
 */
object RuntimeDiagnostics {

    data class Report(
        val upstreamBundle: Boolean,
        val libnode: Boolean,
        val glue: Boolean,
        val released: Boolean,
        val probe: String
    ) {
        val canStartNode: Boolean get() = upstreamBundle && libnode && glue && released

        fun summary(): String = buildString {
            appendLine("运行时自检")
            appendLine("  上游仓库 bundle.zip：${mark(upstreamBundle)}")
            appendLine("  Node 原生库 libnode.so：${mark(libnode)}")
            appendLine("  自建 JNI 胶水：${mark(glue)}")
            appendLine("  已释放代码目录：${mark(released)}")
            appendLine("  符号探测：$probe")
        }

        fun advice(): String {
            if (canStartNode) return "运行时齐备，可以启动网关。"
            return buildString {
                if (!upstreamBundle) {
                    appendLine("· 缺上游仓库 bundle.zip：需由 CI 执行 prepare-node-bundle.sh 生成并打进 assets。")
                }
                if (!libnode) {
                    appendLine("· 缺 libnode.so：在 Run workflow 里填 libnode_url，或把 arm64 的 libnode.so 放进 app/src/main/jniLibs/arm64-v8a/。")
                }
                if (!glue) {
                    appendLine("· 缺自建 JNI 胶水：本次 APK 是用不含 app/src/main/cpp/ 的旧源码编译的，请替换为最新完整包。")
                }
                if (!released) {
                    appendLine("· 代码目录未释放：启动一次网关后会自动从 assets 解压。")
                }
                append("结论：当前 APK 运行时尚未齐备，网关起不来。")
            }
        }

        private fun mark(b: Boolean) = if (b) "✅ 已就位" else "❌ 缺失"
    }

    fun check(ctx: Context): Report {
        // 用 list() 而非 open().read()：bundle.zip 可能有几十 MB，只判断存在性。
        val assetNames = runCatching { ctx.assets.list("node").orEmpty().toSet() }
            .getOrDefault(emptySet())
        val upstreamBundle = assetNames.contains("bundle.zip")

        val nativeDir = ctx.applicationInfo.nativeLibraryDir.orEmpty()
        val libnode = nativeDir.isNotBlank() && File(nativeDir, "libnode.so").isFile

        val glue = NodeBridge.isAvailable()
        val probe = if (glue && libnode) {
            NodeBridge.probe(NodeRuntime.libnodePath(ctx))
        } else {
            "跳过（${if (!glue) "胶水未加载" else "libnode.so 缺失"}）"
        }

        val nodeHome = GatewayConfig.nodeHome(ctx)
        val released = File(nodeHome, "bootstrap.js").isFile &&
            File(nodeHome, "package.json").isFile

        return Report(upstreamBundle, libnode, glue, released, probe)
    }
}
