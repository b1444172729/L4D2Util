package com.android.dsh.core

import android.content.Context
import java.io.File

/**
 * 运行时自检。四项缺一不可：
 *   上游仓库 bundle.zip / libnode.so / 自建 JNI 胶水 / 已释放代码目录。
 *
 * 注意：官方 nodejs-mobile 只发布 libnode.so + headers，Java 桥接类属于
 * React Native 插件，没有可独立使用的 aar。因此这一层必须由本工程自己
 * 用 CMake 编（见 app/src/main/cpp/dsh-node.c），不能靠往 app/libs/ 丢文件补齐。
 */
object RuntimeDiagnostics {

    data class Report(
        val upstreamBundle: Boolean,
        val libnode: Boolean,
        val glue: Boolean,
        val released: Boolean,
        val probe: String,
        val libnodeInfo: String,
        val icuInfo: String
    ) {
        val canStartNode: Boolean get() = upstreamBundle && libnode && glue && released

        fun summary(): String = buildString {
            appendLine("运行时自检")
            appendLine("  上游仓库 bundle.zip：${mark(upstreamBundle)}")
            appendLine("  Node 原生库 libnode.so：${mark(libnode)}")
            if (libnodeInfo.isNotBlank()) appendLine("  $libnodeInfo")
            appendLine("  $icuInfo")
            appendLine("  自建 JNI 胶水：${mark(glue)}")
            appendLine("  已释放代码目录：${mark(released)}")
            appendLine("  符号探测：$probe")
        }

        fun advice(): String {
            if (canStartNode) return "运行时齐备，可以启动网关。"
            return buildString {
                if (!upstreamBundle) {
                    appendLine("· 缺上游仓库 bundle.zip：需由 CI 执行 prepare-node-bundle.sh 生成并打进 assets。")
                }
                if (!libnode) {
                    appendLine("· 缺 libnode.so：在 Run workflow 里填 libnode_url，或把 arm64 的 libnode.so 放进 app/src/main/jniLibs/arm64-v8a/。")
                }
                if (!glue) {
                    appendLine("· 缺自建 JNI 胶水：本次 APK 是用不含 app/src/main/cpp/ 的旧源码编译的，请替换为最新完整包。")
                }
                if (!released) {
                    appendLine("· 代码目录未释放：启动一次网关后会自动从 assets 解压。")
                }
                append("结论：当前 APK 运行时尚未齐备，网关起不来。")
            }
        }

        private fun mark(b: Boolean) = if (b) "✅ 已就位" else "❌ 缺失"
    }

    fun check(ctx: Context): Report {
        // 用 list() 而非 open().read()：bundle.zip 可能有几十 MB，只判断存在性。
        val assetNames = runCatching { ctx.assets.list("node").orEmpty().toSet() }
            .getOrDefault(emptySet())
        val upstreamBundle = assetNames.contains("bundle.zip")

        val nativeDir = ctx.applicationInfo.nativeLibraryDir.orEmpty()
        val libnode = nativeDir.isNotBlank() && File(nativeDir, "libnode.so").isFile

        val glue = NodeBridge.isAvailable()
        val probe = if (glue && libnode) {
            NodeBridge.probe(NodeRuntime.libnodePath(ctx))
        } else {
            "跳过（${if (!glue) "胶水未加载" else "libnode.so 缺失"}）"
        }

        val nodeHome = GatewayConfig.nodeHome(ctx)
        val released = File(nodeHome, "bootstrap.cjs").isFile &&
            File(nodeHome, "package.json").isFile

        // 只读取 ELF 头前 20 字节，不扫 60MB 全文：能核对是不是 arm64 的 64 位 ELF，
        // 避免「下载到了 x86_64 或别的项目的 .so」却一直不知道。
        val libnodeInfo = if (libnode) {
            val f = File(nativeDir, "libnode.so")
            val sizeMb = f.length() / 1024.0 / 1024.0
            val elf = runCatching {
                val h = ByteArray(20)
                f.inputStream().use { it.read(h) }
                val isElf = h[0] == 0x7f.toByte() && h[1] == 'E'.code.toByte() &&
                    h[2] == 'L'.code.toByte() && h[3] == 'F'.code.toByte()
                val is64 = h[4] == 2.toByte()
                val machine = (h[18].toInt() and 0xff) or ((h[19].toInt() and 0xff) shl 8)
                val arch = when (machine) {
                    0xB7 -> "AArch64 ✅"
                    0x3E -> "x86_64 ❌"
                    0x28 -> "ARMv7 ❌"
                    else -> "0x${machine.toString(16)}"
                }
                "${if (isElf) "ELF" else "非 ELF ❌"} / ${if (is64) "64位" else "32位 ❌"} / $arch"
            }.getOrDefault("ELF 头读取失败")
            "二进制核对：${"%.1f".format(sizeMb)} MB · $elf"
        } else ""

        val icuReady = File(nodeHome, "icudtl.dat").isFile ||
            File(nodeHome, "icu/icudtl.dat").isFile
        val icuInfo = if (icuReady) {
            "ICU 数据 icudtl.dat：✅ 已释放（NODE_ICU_DATA 会自动指向）"
        } else {
            "ICU 数据 icudtl.dat：未随包提供（官方 v18 --with-intl=none 属正常）"
        }

        return Report(upstreamBundle, libnode, glue, released, probe, libnodeInfo, icuInfo)
    }
}
