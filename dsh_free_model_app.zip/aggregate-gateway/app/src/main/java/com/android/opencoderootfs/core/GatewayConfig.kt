package com.android.opencoderootfs.core

import android.content.Context
import java.io.File

/**
 * 全机唯一配置源。所有路径都落在 app 私有目录，不写 sdcard。
 * 数据目录 ofm-data 对应 standalone 的 OFM_HOME（桌面端默认 ~/.our-free-model）。
 */
object GatewayConfig {

    private const val PREF = "gateway_config"
    const val DEFAULT_PORT = 18900
    const val LOOPBACK = "127.0.0.1"

    private fun prefs(ctx: Context) =
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun requestedPort(ctx: Context): Int = prefs(ctx).getInt("port", DEFAULT_PORT)
    fun setRequestedPort(ctx: Context, port: Int) =
        prefs(ctx).edit().putInt("port", port).apply()

    fun floatingEnabled(ctx: Context): Boolean = prefs(ctx).getBoolean("floating", true)
    fun setFloatingEnabled(ctx: Context, enabled: Boolean) =
        prefs(ctx).edit().putBoolean("floating", enabled).apply()

    fun bootEnabled(ctx: Context): Boolean = prefs(ctx).getBoolean("boot", false)
    fun setBootEnabled(ctx: Context, enabled: Boolean) =
        prefs(ctx).edit().putBoolean("boot", enabled).apply()

    fun lanRelayEnabled(ctx: Context): Boolean = prefs(ctx).getBoolean("lan_relay", false)
    fun setLanRelayEnabled(ctx: Context, enabled: Boolean) =
        prefs(ctx).edit().putBoolean("lan_relay", enabled).apply()

    /**
     * r5：Android 上 /data/data 与 /data/user/0 常互为符号链接/bind mount，
     * 同一个目录可能出现两种字符串表示（截图里 cwd=/data/data/...，
     * OFM_HOME=/data/user/0/...）。上游 standalone 的 managed storage
     * 自检会拒绝路径链上的符号链接，抛
     *   "Symlinks are not allowed in managed storage"
     * 后安静返回、不监听 18900。统一用 canonicalFile 拿到真实路径。
     */
    private fun baseDir(ctx: Context): File = ctx.filesDir.canonicalFile

    /** standalone 的数据目录：settings.json / 用量统计 / 账号凭据都放这里 */
    fun dataDir(ctx: Context): File = File(baseDir(ctx), "ofm-data").apply { mkdirs() }

    /** 从 assets 释放出来的 Node 代码根目录 */
    fun nodeHome(ctx: Context): File = File(baseDir(ctx), "gateway/node")

    /** bootstrap.cjs 回写给安卓壳的运行信息 */
    fun runtimeFile(ctx: Context): File = File(dataDir(ctx), "gateway-runtime.json")

    fun nodeErrorLog(ctx: Context): File = File(dataDir(ctx), "node-errors.log")

    /**
     * Node 线程启动失败时写入的短标记。HealthProbe 每轮轮询都会检查它，
     * 一旦出现立刻结束等待并把真实原因显示到界面，不用干等 45 秒超时。
     */
    fun nodeFatalFile(ctx: Context): File = File(dataDir(ctx), "node-fatal.txt")

    /** Node/V8 的 stdout + stderr 原始输出（含 FATAL ERROR、bad option 等）。 */
    fun nodeOutputLog(ctx: Context): File = File(dataDir(ctx), "node-output.log")

    /**
     * JS 层专属诊断日志，独立文件。
     * node-output.log 会被 C 层 watchdog 心跳刷屏，standalone 的真实报错容易被
     * tail 挤掉（上一轮截图里只剩 tick=10..30，看不到任何 [bootstrap] 行）。
     * 界面优先显示这个文件，保证入口定位与异常栈永远可见。
     */
    fun bootstrapLogFile(ctx: Context): File = File(dataDir(ctx), "bootstrap.log")

    /** 独立 :node 进程的 pid，主进程据此判断它是否还活着、以及停止时 kill 它。 */
    fun nodePidFile(ctx: Context): File = File(dataDir(ctx), "node-pid.txt")

    /** 冒烟标记：存在时 bootstrap.cjs 只验证 V8 能否执行 JS，不加载 standalone。 */
    fun smokeFlagFile(ctx: Context): File = File(dataDir(ctx), "smoke.flag")

    /** 冒烟结果：由 bootstrap.cjs 在 JS 真正跑起来后写入。 */
    fun smokeResultFile(ctx: Context): File = File(dataDir(ctx), "smoke-result.txt")
}
