package com.android.dsh.core

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * 探活与运行信息读取。
 *
 * 端口不是写死的：原插件在端口被占用时会顺延并把实际端口写回设置。
 * 因此安卓侧一律以 bootstrap.js 回写的 gateway-runtime.json 为准，
 * 再对 /health 做一次真实握手，确认 listen 完成才置为 READY。
 */
object HealthProbe {

    data class RuntimeInfo(
        val port: Int,
        val apiKey: String,
        val manageUrl: String,
        val requestedPort: Int,
        val healthOk: Boolean
    ) {
        val baseUrl: String get() = "http://${GatewayConfig.LOOPBACK}:$port/v1"
        val portShifted: Boolean get() = port != requestedPort
    }

    suspend fun awaitRuntime(ctx: Context, requestedPort: Int, timeoutMs: Long = 45_000): RuntimeInfo? =
        withContext(Dispatchers.IO) {
            // 冷启动先清掉上一轮的陈旧快照，避免读到旧 Key / 旧端口
            val file = GatewayConfig.runtimeFile(ctx)
            val fatal = GatewayConfig.nodeFatalFile(ctx)
            val pidFile = GatewayConfig.nodePidFile(ctx)
            val deadline = System.currentTimeMillis() + timeoutMs
            var parsed: RuntimeInfo? = null

            while (System.currentTimeMillis() < deadline) {
                // Node 线程已经明确失败，没必要再干等到超时
                if (fatal.isFile) return@withContext null

                // :node 进程若已消失（V8 abort / exit / 被系统杀），立刻收尾。
                // pid 文件由 NodeService 启动时写入，同 UID 可读 /proc/<pid>。
                if (pidFile.isFile) {
                    val pid = runCatching { pidFile.readText().trim().toIntOrNull() }.getOrNull()
                    if (pid != null && pid > 0 && !File("/proc/$pid").exists()) {
                        return@withContext null
                    }
                }

                if (file.isFile) {
                    parsed = runCatching { parse(file.readText(), requestedPort) }.getOrNull()
                }
                // Key 可能比 /health 晚半拍落盘；等它一起到齐再宣布 READY，
                // 否则 RikkaHub 侧会拿到一个空 Key。
                if (parsed != null && parsed.apiKey.isNotBlank() && pingHealth(parsed.port)) {
                    return@withContext parsed.copy(healthOk = true)
                }
                delay(400)
            }
            // 超时兜底：仍把已解析到的端口交出去，由界面显示「未就绪/错误」而不是黑盒
            parsed
        }

    /**
     * 冒烟测试：只等 bootstrap.js 写出的 smoke-result.txt。
     * 不看端口、不看 Key、不看 /health、不加载任何 standalone 代码。
     * 返回 true 即证明 V8 能初始化并执行 JS，故障必在网关 JS 层；
     * 返回 false 则证明 libnode.so 引擎本身就在初始化阶段退出。
     */
    suspend fun awaitSmoke(ctx: Context, timeoutMs: Long = 20_000): Boolean =
        withContext(Dispatchers.IO) {
            val result = GatewayConfig.smokeResultFile(ctx)
            val fatal = GatewayConfig.nodeFatalFile(ctx)
            val pidFile = GatewayConfig.nodePidFile(ctx)
            val deadline = System.currentTimeMillis() + timeoutMs
            while (System.currentTimeMillis() < deadline) {
                if (result.isFile) return@withContext true
                if (fatal.isFile) return@withContext false
                if (pidFile.isFile) {
                    val pid = runCatching { pidFile.readText().trim().toIntOrNull() }.getOrNull()
                    if (pid != null && pid > 0 && !File("/proc/$pid").exists()) {
                        return@withContext false
                    }
                }
                delay(300)
            }
            false
        }

    private fun parse(raw: String, requestedPort: Int): RuntimeInfo {
        val o = JSONObject(raw)
        return RuntimeInfo(
            port = o.optInt("port", requestedPort),
            apiKey = o.optString("apiKey", ""),
            manageUrl = o.optString("manageUrl", ""),
            requestedPort = o.optInt("requestedPort", requestedPort),
            healthOk = false
        )
    }

    private fun pingHealth(port: Int): Boolean = try {
        val conn = (URL("http://${GatewayConfig.LOOPBACK}:$port/health").openConnection() as HttpURLConnection).apply {
            connectTimeout = 1200
            readTimeout = 1200
            requestMethod = "GET"
        }
        val ok = conn.responseCode in 200..299
        conn.disconnect()
        ok
    } catch (e: Exception) {
        false
    }

    /** POST /v1/chat/completions 之前，先把可选模型 ID 拉出来给 RikkaHub 手动添加 */
    fun fetchModelIds(port: Int, apiKey: String): List<String> {
        // 必须用块体：Kotlin 表达式体函数（= try {...}）里不允许写 return，
        // 否则 Gradle 编译阶段会报 "Returns are not allowed for functions
        // with expression body"。
        return try {
            val conn = (URL("http://${GatewayConfig.LOOPBACK}:$port/v1/models").openConnection() as HttpURLConnection).apply {
                connectTimeout = 3000
                readTimeout = 5000
                setRequestProperty("Authorization", "Bearer $apiKey")
            }
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()
            val data = JSONObject(body).optJSONArray("data") ?: return emptyList()
            (0 until data.length()).mapNotNull { i ->
                data.optJSONObject(i)?.optString("id")?.takeIf { it.isNotBlank() }
            }.distinct()
        } catch (e: Exception) {
            emptyList()
        }
    }
}
