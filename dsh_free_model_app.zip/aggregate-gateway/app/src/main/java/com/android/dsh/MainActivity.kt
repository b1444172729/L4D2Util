package com.android.dsh

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.android.dsh.core.GatewayConfig
import com.android.dsh.core.GatewayService
import com.android.dsh.ui.FloatingWindow
import com.android.dsh.ui.ManageActivity
import com.android.dsh.util.QrCodeUtil
import com.android.dsh.util.RikkaHubHandoff
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var stateText: TextView
    private lateinit var detailText: TextView
    private lateinit var keyText: TextView
    private lateinit var qrImage: ImageView
    private var keyVisible = false
    private var lastStatus = GatewayApp.Status()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
        requestNotificationPermissionIfNeeded()

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                GatewayApp.instance.status.collect { render(it) }
            }
        }
    }

    private fun buildUi(): View {
        val pad = dp(16)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, dp(24), pad, pad)
        }

        box.addView(TextView(this).apply {
            text = "聚合网关"
            textSize = 26f
            setTextColor(ContextCompat.getColor(this@MainActivity, R.color.gateway_blue))
        })
        box.addView(TextView(this).apply {
            text = "本机模型网关 · 供 RikkaHub 等客户端通过 127.0.0.1 调用"
            textSize = 13f
            setPadding(0, dp(4), 0, dp(18))
        })

        // ---- 状态卡 ----
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = ContextCompat.getDrawable(this@MainActivity, R.drawable.bg_panel)
            setPadding(pad, pad, pad, pad)
        }
        stateText = TextView(this).apply { textSize = 18f }
        detailText = TextView(this).apply { textSize = 13f; setPadding(0, dp(8), 0, 0) }
        keyText = TextView(this).apply { textSize = 12f; setPadding(0, dp(6), 0, 0) }
        card.addView(stateText)
        card.addView(detailText)
        card.addView(keyText)
        box.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(16) })

        // ---- 服务控制 ----
        fun action(label: String, block: () -> Unit) {
            box.addView(Button(this).apply {
                text = label
                isAllCaps = false
                setOnClickListener { block() }
            }, LinearLayout.LayoutParams(-1, -2))
        }

        action(getString(R.string.action_start)) {
            ensureOverlayAndBattery()
            GatewayService.start(this)
        }
        action(getString(R.string.action_stop)) { GatewayService.stop(this) }
        action(getString(R.string.action_restart_node)) {
            GatewayService.stop(this)
            GatewayService.start(this)
        }
        action(getString(R.string.action_manage)) {
            startActivity(Intent(this, ManageActivity::class.java))
        }
        action(getString(R.string.action_floating)) {
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
        }
        action(getString(R.string.action_battery)) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                runCatching {
                    startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                        data = Uri.parse("package:$packageName")
                    })
                }
            }
        }

        // ---- 与 RikkaHub 交接 ----
        box.addView(sectionTitle("交给 RikkaHub"))
        action(getString(R.string.action_copy_baseurl)) {
            if (lastStatus.port > 0)
                RikkaHubHandoff.copy(this, "Base URL", RikkaHubHandoff.baseUrl(lastStatus.port))
            else Toast.makeText(this, "网关未就绪", Toast.LENGTH_SHORT).show()
        }
        action(getString(R.string.action_copy_key)) {
            if (lastStatus.apiKey.isNotBlank())
                RikkaHubHandoff.copy(this, "API Key", lastStatus.apiKey)
        }
        action("显示 / 隐藏 Key") {
            keyVisible = !keyVisible
            render(lastStatus)
        }
        action(getString(R.string.action_copy_models)) {
            if (lastStatus.port <= 0 || lastStatus.apiKey.isBlank()) {
                Toast.makeText(this, "网关未就绪", Toast.LENGTH_SHORT).show()
            } else {
                lifecycleScope.launch {
                    val ids = RikkaHubHandoff.modelIds(lastStatus.port, lastStatus.apiKey)
                    if (ids.isEmpty()) Toast.makeText(this@MainActivity, "未取到模型清单，请稍后重试", Toast.LENGTH_LONG).show()
                    else RikkaHubHandoff.copy(this@MainActivity, "模型 ID", ids.joinToString("\n"))
                }
            }
        }
        action(getString(R.string.action_qr)) {
            if (lastStatus.port > 0 && lastStatus.apiKey.isNotBlank()) {
                qrImage.setImageBitmap(
                    QrCodeUtil.encode(RikkaHubHandoff.configText(lastStatus.port, lastStatus.apiKey))
                )
                qrImage.visibility = View.VISIBLE
            }
        }
        qrImage = ImageView(this).apply {
            visibility = View.GONE
            setPadding(dp(24), dp(16), dp(24), dp(16))
        }
        box.addView(qrImage, LinearLayout.LayoutParams(dp(220), dp(220)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
        })

        // ---- 说明 ----
        box.addView(sectionTitle("使用提示"))
        box.addView(note(getString(R.string.hint_rikkahub)))
        box.addView(note(getString(R.string.hint_qr)))
        box.addView(note(getString(R.string.hint_key)))
        box.addView(note(getString(R.string.hint_cleartext)))
        box.addView(note("包名 com.android.dsh；数据目录 ofm-data 不参与备份。"))

        return ScrollView(this).apply { addView(box) }
    }

    private fun sectionTitle(t: String) = TextView(this).apply {
        text = t
        textSize = 15f
        setPadding(0, dp(20), 0, dp(8))
        setTextColor(ContextCompat.getColor(this@MainActivity, R.color.gateway_blue))
    }

    private fun note(t: String) = TextView(this).apply {
        text = t
        textSize = 12f
        setPadding(0, dp(4), 0, dp(4))
        setTextColor(ContextCompat.getColor(this@MainActivity, R.color.gateway_text_secondary))
    }

    private fun render(s: GatewayApp.Status) {
        lastStatus = s
        val color = when (s.state) {
            GatewayApp.State.READY -> R.color.gateway_ok
            GatewayApp.State.ERROR -> R.color.gateway_error
            GatewayApp.State.STARTING -> R.color.gateway_warn
            else -> R.color.gateway_text_secondary
        }
        stateText.text = when (s.state) {
            GatewayApp.State.READY -> "● ${getString(R.string.state_ready)}"
            GatewayApp.State.STARTING -> "● ${getString(R.string.state_starting)}"
            GatewayApp.State.ERROR -> "● ${getString(R.string.state_error)}"
            else -> "○ ${getString(R.string.state_stopped)}"
        }
        stateText.setTextColor(ContextCompat.getColor(this, color))

        detailText.text = if (s.port > 0) {
            buildString {
                appendLine("实际端口：${s.port}${if (s.message.isNotBlank()) "（${s.message}）" else ""}")
                append("Base URL：${RikkaHubHandoff.baseUrl(s.port)}")
            }
        } else {
            s.message.ifBlank { "端口 18900 起的本地服务；被占用时会自动顺延并在界面标注实际端口。" }
        }

        keyText.text = if (s.apiKey.isBlank()) {
            "API Key：尚未生成"
        } else {
            val shown = if (keyVisible) s.apiKey else "••••••••" + s.apiKey.takeLast(4)
            "API Key：$shown"
        }
    }

    private fun ensureOverlayAndBattery() {
        if (GatewayConfig.floatingEnabled(this) && !FloatingWindow(this).canShow()) {
            Toast.makeText(this, "未授予悬浮窗权限，前台服务仍会运行", Toast.LENGTH_SHORT).show()
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2001
            )
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2001
            )
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
