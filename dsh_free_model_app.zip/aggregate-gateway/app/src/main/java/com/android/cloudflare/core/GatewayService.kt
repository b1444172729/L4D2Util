package com.android.cloudflare.core

import android.app.PendingIntent
import android.app.Service
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.android.cloudflare.GatewayApp
import com.android.cloudflare.MainActivity
import com.android.cloudflare.R
import com.android.cloudflare.ui.FloatingWindow
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class GatewayService : Service() {

    companion object {
        const val ACTION_START = "com.android.cloudflare.action.START"
        const val ACTION_STOP = "com.android.cloudflare.action.STOP"
        const val ACTION_RESTART = "com.android.cloudflare.action.RESTART"
        const val ACTION_SMOKE = "com.android.cloudflare.action.SMOKE"
        // r16：换 ID，强制系统替换掉覆盖安装后残留在 SystemUI 里的旧通知
        private const val NOTIF_ID = 1002

        fun start(ctx: Context) {
            val i = Intent(ctx, GatewayService::class.java).setAction(ACTION_START)
            ctx.startForegroundService(i)
        }

        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, GatewayService::class.java).setAction(ACTION_STOP))
        }

        /** 只验证 Node 引擎能否执行 JS，不启动正式网关 */
        fun smoke(ctx: Context) {
            ctx.startForegroundService(
                Intent(ctx, GatewayService::class.java).setAction(ACTION_SMOKE)
            )
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var wakeLock: PowerManager.WakeLock? = null
    private var floating: FloatingWindow? = null

    override fun onCreate() {
        super.onCreate()
        ServiceCompat.startForeground(
            this, NOTIF_ID, buildNotification(null),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        )
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                runCatching { GatewayConfig.smokeFlagFile(this).delete() }
                shutdown()
                stopSelf()
                // Android Service 的 onStartCommand 只有四个合法返回常量：
                // START_STICKY / START_NOT_STICKY / START_REDELIVER_INTENT /
                // START_STICKY_COMPATIBILITY。此前误写了一个不存在的标识符，
                // 导致 Kotlin 编译报 Unresolved reference。
                // 用户主动停止后不应被系统重启，故用 START_NOT_STICKY。
                return START_NOT_STICKY
            }
            ACTION_RESTART -> {
                shutdown(keepForeground = true)
                boot(smoke = false)
            }
            ACTION_SMOKE -> {
                shutdown(keepForeground = true)
                boot(smoke = true)
            }
            else -> boot(smoke = false)
        }
        return START_STICKY
    }

    private fun boot(smoke: Boolean) {
        scope.launch {
            val app = GatewayApp.instance
            app.post(GatewayApp.Status(GatewayApp.State.STARTING, message = getString(R.string.state_starting)))
            acquireWakeLock()

            try {
                // 释放代码目录必须在启动 :node 前完成（两个进程共享 filesDir）
                AssetInstaller.installIfNeeded(this@GatewayService)
                val port = GatewayConfig.requestedPort(this@GatewayService)
                val dataDir = GatewayConfig.dataDir(this@GatewayService)

                // 清掉上一轮快照，避免 HealthProbe 读到旧的端口 / Key / 失败标记
                GatewayConfig.runtimeFile(this@GatewayService).delete()
                GatewayConfig.nodeFatalFile(this@GatewayService).delete()
                GatewayConfig.nodePidFile(this@GatewayService).delete()
                GatewayConfig.smokeResultFile(this@GatewayService).delete()
                runCatching { GatewayConfig.nodeOutputLog(this@GatewayService).writeText("") }
                runCatching { GatewayConfig.bootstrapLogFile(this@GatewayService).writeText("") }
                // 冒烟模式写标记，正式模式务必清掉，否则下次启动会误进冒烟分支
                if (smoke) {
                    GatewayConfig.smokeFlagFile(this@GatewayService).writeText("1")
                } else {
                    GatewayConfig.smokeFlagFile(this@GatewayService).delete()
                }
                // 让 .git / 旧版残留不干扰：dataDir 本身由 GatewayConfig 保证存在
                dataDir.mkdirs()

                // ★ 不再在主进程里跑 Node：改由 :node 独立进程承载。
                // node::Start 里的 abort()/exit() 因此不会再结束 UI 进程。
                startService(Intent(this@GatewayService, NodeService::class.java))

                if (smoke) {
                    val ok = HealthProbe.awaitSmoke(this@GatewayService)
                    val result = runCatching {
                        GatewayConfig.smokeResultFile(this@GatewayService).readText().trim()
                    }.getOrDefault("")
                    GatewayApp.instance.post(
                        GatewayApp.Status(
                            state = if (ok) GatewayApp.State.READY else GatewayApp.State.ERROR,
                            message = if (ok) {
                                "Node 冒烟测试通过：$result\n" +
                                    "引擎能执行 JS，故障在 standalone/依赖层。点「停止网关」后再正常启动即可。"
                            } else {
                                "Node 冒烟测试失败：V8 在初始化阶段就退出，未执行任何 JS。\n" +
                                    "结论：问题在 libnode.so 二进制本身，与 bundle/standalone/RikkaHub 无关。\n\n" +
                                    buildFailureMessage()
                            }
                        )
                    )
                    return@launch
                }

                val info = HealthProbe.awaitRuntime(this@GatewayService, port)
                    ?: error(buildFailureMessage())

                // 双保险：即便将来有人改回超时返回 parsed，这里也不会误报 READY。
                if (!info.healthOk) {
                    error(
                        "网关未真正就绪：30 秒内 /health 始终未通过，standalone 没有监听 " +
                            "${info.port} 端口。\n" +
                            "界面此前显示「运行中」是超时误报，管理页与 RikkaHub 连不上均源于此。\n\n" +
                            buildFailureMessage()
                    )
                }

                GatewayApp.instance.post(
                    GatewayApp.Status(
                        state = GatewayApp.State.READY,
                        port = info.port,
                        apiKey = info.apiKey,
                        manageUrl = info.manageUrl,
                        message = if (info.portShifted) getString(R.string.state_port_changed) else ""
                    )
                )
                ServiceCompat.startForeground(
                    this@GatewayService, NOTIF_ID, buildNotification(info),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
                withContext(Dispatchers.Main) { attachFloatingWindow() }
            } catch (t: Throwable) {
                // 用户已点「停止」时，boot 的残留协程不该把状态改回 ERROR
                if (GatewayApp.instance.status.value.state == GatewayApp.State.STOPPED) {
                    return@launch
                }
                val raw = t.message ?: t.javaClass.simpleName
                val diag = RuntimeDiagnostics.check(this@GatewayService)
                // ClassNotFoundException 的 message 只有类名，对用户毫无意义
                val friendly = if (t is ClassNotFoundException ||
                    raw == NodeRuntime.NODE_CLASS ||
                    t is UnsatisfiedLinkError
                ) {
                    "APK 的 Node.js 运行时未就绪。\n${diag.advice()}\n${diag.probe}"
                } else {
                    raw
                }
                GatewayApp.instance.post(
                    GatewayApp.Status(
                        state = GatewayApp.State.ERROR,
                        message = friendly
                    )
                )
                GatewayConfig.nodeErrorLog(this@GatewayService).appendText(
                    "[${System.currentTimeMillis()}] $friendly\n" +
                        diag.summary() + "\n" + t.stackTraceToString() + "\n"
                )
            }
        }
    }

    /**
     * 把 Node 的真实死因拼成可直接显示的文案。
     * node-output.log 是 stdout+stderr 的原始输出（含 V8 的 FATAL ERROR、
     * Node 的 bad option、模块加载失败），比任何猜测都准。
     */
    private fun buildFailureMessage(): String {
        val fatal = GatewayConfig.nodeFatalFile(this)
            .takeIf { it.isFile }?.readText()?.trim().orEmpty()
        val bootTail = readTail(GatewayConfig.bootstrapLogFile(this), 30)
        val outTail = readTail(GatewayConfig.nodeOutputLog(this), 22)
        val errTail = readTail(GatewayConfig.nodeErrorLog(this), 8)
        return buildString {
            appendLine("网关未就绪：/health 从未握手成功，端口上没有服务监听（UI 进程未受影响）。")
            // 阶段判定：把「引擎层」与「脚本层」分开，下一轮能直接对症下药
            appendLine(
                when {
                    (bootTail + "\n" + outTail).contains("Symlinks are not allowed in managed storage", true) ->
                        "阶段判定：★ 命中上游 managed storage 符号链接闸门 —— " +
                            "它检测到路径链或 bundle 里有符号链接后拒绝监听 18900。" +
                            "本版已在 C/Kotlin/JS/打包四层消除：路径统一 realpath、删除 .bin 链接、tar -h 实体化。" +
                            "看下方 bootstrap.log 的 r5 父链符号链接与符号链接实体化行。"
                    bootTail.contains("上游 start:standalone") ->
                        "阶段判定：★ Node/V8 与 JS 层均已启动，故障在 standalone 加载/监听环节。" +
                            "看下方 bootstrap.log 的「上游 start:standalone」「engines.node」「入口」三行，以及 [raw:stderr] 行。"
                    bootTail.contains("没有服务监听") ->
                        "阶段判定：★ 入口已加载但没 listen —— 常见于上游 managed storage 闸门、" +
                            "ESM 入口被按 CommonJS 加载，或上游自身启动异常。看 [raw:stderr] 原文。"
                    bootTail.contains("[bootstrap] JS 层已启动") ->
                        "阶段判定：Node/V8 初始化成功、JS 已执行；问题出在 standalone 或其依赖。"
                    outTail.contains("[bootstrap] JS 层已启动") ->
                        "阶段判定：Node/V8 初始化成功、JS 已执行；问题出在 standalone 或其依赖。"
                    outTail.contains("could not initialize ICU") ->
                        "阶段判定：★ 命中 Node 源码的 ICU 初始化失败分支（exit(9)）：" +
                            "说明下载到的是 small-icu 构建。v22.23.2 默认内嵌 full-icu，" +
                            "本版已默认跳过外部 icudtl.dat 以省约 12 MB；" +
                            "若确需外部数据，构建时设 KEEP_EXTERNAL_ICU=1 让它随 assets 打进并设 NODE_ICU_DATA。"
                    outTail.contains("bad option") || outTail.contains("invalid option") ->
                        "阶段判定：★ Node 参数解析失败（exit(9)），见下方 Node 原始输出的具体选项名。"
                    outTail.contains("atexit 触发") ->
                        "阶段判定：node::Start 内部调用 exit() 直接退出（不是崩溃、不是被杀）。" +
                            "多为 Node 参数/平台初始化内部主动退出，请连同日志尾部一起反馈。"
                    outTail.contains("!!! 原生崩溃 signal=") ->
                        "阶段判定：捕获到原生崩溃信号（见下方日志）。" +
                            "SIGSEGV 多为线程栈/内存，SIGABRT 多为 C++ CHECK 失败或 STL 版本不匹配。"
                    outTail.contains("watchdog tick=") ->
                        "阶段判定：进程在 watchdog 心跳后消失，既无 exit() 也无崩溃信号。" +
                            "可能是 SIGKILL / 系统内存回收，或 V8 覆盖了我们的 signal handler；" +
                            "看最后 tick 数可估算存活秒数。"
                    outTail.contains("回退 dlopen 绝对路径") ->
                        "阶段判定：本次 APK 未走成官方 DT_NEEDED 形态（libnode.so 未参与链接），" +
                            "仍靠 dlopen 取符号。请把 CI 构建日志里 CMake 的那行一起反馈。"
                    outTail.contains("8MB 栈 pthread") ->
                        "阶段判定：已进入 8MB 栈 pthread，但 node::Start 未进入 JS 层（引擎层失败）。"
                    outTail.contains("[dsh-node] env:") ->
                        "阶段判定：原生层环境已就绪，但 node::Start 未进入 JS 层（引擎层失败）。"
                    outTail.isNotBlank() ->
                        "阶段判定：已进入原生层，但环境初始化未完成。"
                    else -> "阶段判定：日志为空，:node 进程可能在加载阶段即被结束。"
                }
            )
            if (fatal.isNotBlank()) appendLine("启动层：$fatal")
            // bootstrap.log 不含 C 层 watchdog 心跳，是排查 standalone 的第一手证据
            if (bootTail.isNotBlank()) {
                appendLine("── bootstrap.log（JS 层诊断，优先看这个）──")
                appendLine(bootTail)
            }
            if (outTail.isNotBlank()) {
                appendLine("── node-output.log（Node 原始输出）──")
                appendLine(outTail)
            }
            if (errTail.isNotBlank()) {
                appendLine("── node-errors.log ──")
                appendLine(errTail)
            }
            if (fatal.isBlank() && outTail.isBlank() && errTail.isBlank()) {
                append("ofm-data/node-output.log 为空：Node 可能在 V8 初始化阶段直接 abort，" +
                    "或 :node 进程尚未写入 pid。请把此截图与自检结果一并反馈。")
            }
        }.trim()
    }

    private fun readTail(f: java.io.File, maxLines: Int): String {
        if (!f.isFile || f.length() == 0L) return ""
        val tail = ArrayDeque<String>(maxLines + 1)
        f.useLines { seq ->
            seq.forEach { line ->
                if (tail.size >= maxLines) tail.removeFirst()
                tail.addLast(line)
            }
        }
        return tail.joinToString("\n")
    }

    /** 悬浮窗只做「可见 + 可操作」，真正的保活靠前台服务 + 唤醒锁 + 电池白名单 */
    private fun attachFloatingWindow() {
        if (!GatewayConfig.floatingEnabled(this)) return
        if (!android.provider.Settings.canDrawOverlays(this)) return
        if (floating == null) floating = FloatingWindow(this)
        floating?.show()
    }

    private fun shutdown(keepForeground: Boolean = false) {
        // Node 现在在 :node 独立进程里，node::Start 阻塞时收不到任何 Intent，
        // 因此停止动作由主进程直接结束那个进程（同一 UID，允许 kill）。
        runCatching {
            val pf = GatewayConfig.nodePidFile(this)
            if (pf.isFile) {
                val pid = pf.readText().trim().toIntOrNull()
                if (pid != null && pid > 0 && pid != android.os.Process.myPid()) {
                    android.os.Process.killProcess(pid)
                }
                pf.delete()
            }
            stopService(Intent(this, NodeService::class.java))
        }
        floating?.hide()
        floating = null
        wakeLock?.takeIf { it.isHeld }?.release()
        wakeLock = null
        if (!keepForeground) {
            GatewayApp.instance.post(GatewayApp.Status(GatewayApp.State.STOPPED))
        }
    }

    @Suppress("MissingPermission")
    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AggregateGateway::Node").apply { acquire() }
    }

    private fun buildNotification(info: HealthProbe.RuntimeInfo?): android.app.Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val text = if (info != null) {
            "${GatewayConfig.LOOPBACK}:${info.port}${if (info.portShifted) " · ${getString(R.string.state_port_changed)}" else ""}"
        } else {
            getString(R.string.notif_text)
        }
        val stopPi = PendingIntent.getService(
            this, 1, Intent(this, GatewayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        // r16 修复：之前只调了 setSmallIcon()，通知头部那枚彩色图标其实是
        // 国产 ROM 在 largeIcon 位置拿「应用图标」顶上的，走 SystemUI 进程缓存，
        // 覆盖安装 / 重新编译都不刷新，所以一直显示旧的信号塔。
        // 现在显式给 largeIcon（与桌面/悬浮窗同一张彩色位图），并让 smallIcon
        // 改用全新的透明底资源名，配合新的 CHANNEL_ID + NOTIF_ID 三重打破缓存。
        val largeIcon = runCatching {
            val src = BitmapFactory.decodeResource(resources, R.drawable.ic_gateway_art)
            Bitmap.createScaledBitmap(src, 192, 192, true)
        }.getOrNull()

        return NotificationCompat.Builder(this, GatewayApp.CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_gateway_status)
            .apply { largeIcon?.let { setLargeIcon(it) } }
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(text)
            .setContentIntent(pi)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(android.R.drawable.ic_media_pause, getString(R.string.action_stop), stopPi)
            .build()
    }

    override fun onDestroy() {
        shutdown()
        scope.cancel()
        super.onDestroy()
    }
}
