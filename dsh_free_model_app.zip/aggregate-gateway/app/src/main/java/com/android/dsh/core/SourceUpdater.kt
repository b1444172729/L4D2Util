package com.android.dsh.core

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipInputStream

/**
 * 应用内更新上游源码（选项 5）。
 *
 * 从 GitHub codeload 拉 main 分支的源码 zip，按与 CI 打包脚本一致的规则
 * 裁剪后，原子替换 filesDir/gateway/node，下次启动网关即生效。
 * 不需要重新编译 APK，也不触碰 ofm-data/（Key、统计、账号凭据全部保留）。
 *
 * ★ 信任边界（务必如实告知用户）：
 *   下载的是 GitHub main 分支源码，**不做签名校验**（本工程没有上游的
 *   Ed25519 发布公钥）。只做结构校验：必须有 package.json、
 *   packages/standalone/cli.mjs 与 src/。信任程度等同于「信任该仓库
 *   当前 main 分支的内容」。这与上游插件自身「应用内升级用 pin 的公钥 +
 *   SHA-256 清单」的信任模型不同，属于本移植版的明确折衷。
 *
 * ★ 版本共存：替换后写 `.ofm-local-update`（内容 = 当时 APK 内的
 *   bundle-version.txt）。AssetInstaller 见到它就保留本地源码；APK 一换，
 *   incoming 变化，标记自动失效并回退到新 APK 的内置源码。
 */
object SourceUpdater {

    const val DEFAULT_URL =
        "https://codeload.github.com/Ebony-Vinyl/dsh-our-free-model/zip/refs/heads/main"

    private const val PREF = "gateway_config"
    private const val KEY_URL = "update_url"
    private const val MAX_DOWNLOAD = 100L * 1024 * 1024
    private const val LOCAL_UPDATE_FLAG = ".ofm-local-update"

    data class UpdateResult(
        val version: String,
        val files: Int,
        val bytes: Long,
        val sourceUrl: String
    ) {
        fun description(): String =
            "已更新到 $version\n来源：$sourceUrl\n源码 $files 个文件 / ${"%.1f".format(bytes / 1048576.0)} MB\n" +
                "点「启动网关」后生效（Key 与统计保持不变）"
    }

    /** 允许在设置里覆盖更新源（例如国内镜像 / 自建代理），留空则用默认。 */
    fun url(ctx: Context): String =
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getString(KEY_URL, "").orEmpty().ifBlank { DEFAULT_URL }

    fun setUrl(ctx: Context, value: String) =
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit().putString(KEY_URL, value.trim()).apply()

    /** 清除本地更新标记，下次启动网关时 AssetInstaller 会用 APK 内置源码重建。 */
    fun restoreBuiltin(ctx: Context): Boolean {
        val flag = File(GatewayConfig.nodeHome(ctx), LOCAL_UPDATE_FLAG)
        return if (flag.isFile) flag.delete() else false
    }

    fun hasLocalUpdate(ctx: Context): Boolean =
        File(GatewayConfig.nodeHome(ctx), LOCAL_UPDATE_FLAG).isFile

    fun currentVersion(ctx: Context): String {
        val f = File(GatewayConfig.nodeHome(ctx), "bundle-version.txt")
        return if (f.isFile) f.readText().trim() else "（内置源码，尚未释放）"
    }

    suspend fun update(ctx: Context, onProgress: (String) -> Unit = {}): UpdateResult =
        withContext(Dispatchers.IO) {
            val nodeHome = GatewayConfig.nodeHome(ctx)
            val parent = nodeHome.parentFile
                ?: throw IOException("无法定位 gateway 目录")
            val staging = File(parent, ".ofm-staging")
            val backup = File(parent, "node.bak")
            val zip = File(ctx.cacheDir, "ofm-update.zip")

            fun clean() {
                runCatching { staging.deleteRecursively() }
                runCatching { zip.delete() }
            }

            try {
                clean()
                staging.mkdirs()

                // ---------------------------------------------------- 1 下载
                val sourceUrl = url(ctx)
                onProgress("正在下载上游源码…\n$sourceUrl")
                val conn = (URL(sourceUrl).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 20_000
                    readTimeout = 90_000
                    instanceFollowRedirects = true
                    requestMethod = "GET"
                    setRequestProperty("User-Agent", "AggregateGateway/1.0")
                }
                val code = conn.responseCode
                if (code !in 200..299) {
                    conn.disconnect()
                    throw IOException("下载失败：HTTP $code（国内网络可能需要代理，或稍后重试）")
                }
                val buf = ByteArray(64 * 1024)
                var total = 0L
                FileOutputStream(zip).use { out ->
                    conn.inputStream.use { input ->
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            total += n
                            if (total > MAX_DOWNLOAD) throw IOException("下载超过 100 MB，已中止")
                            out.write(buf, 0, n)
                        }
                    }
                }
                conn.disconnect()
                if (total < 10_000) throw IOException("下载内容异常（仅 ${total} 字节），已中止")
                onProgress("下载完成 ${"%.1f".format(total / 1048576.0)} MB，正在解压并校验…")

                // ---------------------------------------------------- 2 解压 + 裁剪
                // GitHub codeload 的 zip 有一层 <repo>-<ref>/ 顶层目录，剥掉它。
                // ZipInputStream 是顺序流，必须边读边写，不能先探测再回头取数据。
                ZipInputStream(zip.inputStream().buffered()).use { zis ->
                    while (true) {
                        val entry = zis.nextEntry ?: break
                        val raw = entry.name.replace('\\', '/')
                        val slash = raw.indexOf('/')
                        val rel = if (slash >= 0) raw.substring(slash + 1) else raw
                        if (rel.isEmpty() || rel.startsWith("__MACOSX") || excluded(rel)) {
                            zis.closeEntry()
                            continue
                        }
                        val dest = File(staging, rel).canonicalFile
                        if (!dest.path.startsWith(staging.canonicalPath + File.separator)) {
                            zis.closeEntry()
                            continue
                        }
                        if (entry.isDirectory) {
                            dest.mkdirs()
                        } else {
                            dest.parentFile?.mkdirs()
                            dest.outputStream().use { zis.copyTo(it) }
                        }
                        zis.closeEntry()
                    }
                }

                // ---------------------------------------------------- 3 结构校验
                val required = listOf(
                    "package.json",
                    "packages/standalone/cli.mjs",
                    "packages/standalone/service.mjs"
                )
                for (r in required) {
                    if (!File(staging, r).isFile) {
                        throw IOException("下载内容不是有效的上游源码（缺少 $r），已放弃更新")
                    }
                }
                if (!File(staging, "src").isDirectory) {
                    throw IOException("下载内容缺少 src/，已放弃更新")
                }

                // ---------------------------------------------------- 4 保留本地入口与版本
                // bootstrap.cjs 永远以当前 APK 内置的为准，避免上游源码里
                // 混进同名文件把我们定制的启动逻辑覆盖掉。
                File(staging, "bootstrap.cjs").outputStream().use { out ->
                    ctx.assets.open("node/bootstrap.cjs").use { it.copyTo(out) }
                }
                val stamp = SimpleDateFormat("yyyyMMddHHmmss", Locale.US).format(Date())
                val version = "update-$stamp-${sha256Hex(zip).take(8)}"
                File(staging, "bundle-version.txt").writeText(version)
                File(staging, LOCAL_UPDATE_FLAG).writeText(AssetInstaller.assetVersion(ctx))

                val files = staging.walkTopDown().count { it.isFile }
                val bytes = staging.walkTopDown().filter { it.isFile }.sumOf { it.length() }

                // ---------------------------------------------------- 5 原子替换
                // staging 与 nodeHome 同父目录，renameTo 不会跨挂载点失败。
                onProgress("校验通过，$files 个文件，正在替换源码目录…")
                if (backup.exists()) backup.deleteRecursively()
                val hadOld = nodeHome.exists()
                if (hadOld && !nodeHome.renameTo(backup)) {
                    throw IOException("无法备份现有源码目录，更新已取消")
                }
                if (!staging.renameTo(nodeHome)) {
                    if (hadOld) backup.renameTo(nodeHome)
                    throw IOException("无法替换源码目录，已回滚")
                }
                backup.deleteRecursively()
                // 删除下载缓存失败不应把「已成功替换」误报成失败
                runCatching { zip.delete() }

                onProgress("更新完成，重启网关后生效")
                UpdateResult(version, files, bytes, sourceUrl)
            } catch (t: Throwable) {
                clean()
                // 万一已经备份但还没换回来，恢复现场
                if (backup.exists() && !nodeHome.exists()) backup.renameTo(nodeHome)
                throw t
            }
        }

    /** 与 scripts/prepare-node-bundle.sh 的裁剪规则保持一致。 */
    private fun excluded(rel: String): Boolean {
        val r = rel.replace('\\', '/')
        if (r == "scripts" || r.startsWith("scripts/")) return true
        if (r == "packages/desktop" || r.startsWith("packages/desktop/")) return true
        if (r == "vendor/channel-pack/src" || r.startsWith("vendor/channel-pack/src/")) return true
        if (r.startsWith("vendor/channel-pack/scripts/")) return true
        if (r.startsWith(".git/") || r.startsWith(".github/") || r.startsWith("docs/")) return true
        if (r == "node_modules" || r.startsWith("node_modules/")) return true
        if (r.endsWith(".ts") && !r.endsWith(".d.ts")) return true
        if (r.endsWith(".map") || r.endsWith(".icns") || r.endsWith(".bmp")) return true
        if (r == "tsconfig.json" || r.endsWith("/tsconfig.json")) return true
        if (r == "package-lock.json") return true
        if (r == "README.md" || r == "README_EN.md" || r == "PACKAGING.md") return true
        return false
    }

    private fun sha256Hex(f: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        f.inputStream().use { input ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it.toInt() and 0xff) }
    }
}
