package com.android.dsh.core

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * 「更新上游源码」→「刷新免费模型目录」（B 方案）。
 *
 * 旧版会从 GitHub 下载 Ebony-Vinyl/dsh-our-free-model 整仓源码并替换
 * filesDir/gateway/node。本机网关的代码已经在 APK 里、不依赖任何上游仓库，
 * 所以这里改成只拉一份**模型目录 JSON**，写到 ofm-data/models.json：
 *   · 不下载、不执行任何外部代码（信任边界比旧版更窄）；
 *   · 不动 nodeHome，网关代码永远以 APK 内置为准；
 *   · 不动 ofm-data/settings.json，本地 Key 与用量统计全部保留。
 *
 * 网关启动时若发现 models.json 就用它，否则回退 assets 里的
 * models.builtin.json；刷新失败时同样保留缓存。可在设置里把更新源改成
 * 任意返回 OpenAI `{data:[...]}`、裸数组、或插件面板 `{items:[...]}` 的地址。
 *
 * 公开 API 与 MainActivity 的调用点保持逐字不变：
 *   url / setUrl / restoreBuiltin / hasLocalUpdate / currentVersion / update。
 */
object SourceUpdater {

    const val DEFAULT_URL = "https://opencode.ai/zen/v1/models"

    private const val PREF = "gateway_config"
    private const val KEY_URL = "update_url"
    private const val MAX_DOWNLOAD = 4L * 1024 * 1024
    private const val LOCAL_UPDATE_FLAG = ".ofm-local-update"
    private const val ZEN_BASE = "https://opencode.ai/zen/v1"

    data class UpdateResult(
        val version: String,
        val files: Int,
        val bytes: Long,
        val sourceUrl: String
    ) {
        fun description(): String =
            "已刷新免费模型目录\n来源：$sourceUrl\n共 $files 个模型 / ${"%.1f".format(bytes / 1024.0)} KB\n" +
                "点「启动网关」后网关会读取新清单（Key 与统计保持不变）"
    }

    /** 允许在设置里覆盖更新源（例如镜像 / 自建清单），留空则用官方目录。 */
    fun url(ctx: Context): String =
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getString(KEY_URL, "").orEmpty().ifBlank { DEFAULT_URL }

    fun setUrl(ctx: Context, value: String) =
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit().putString(KEY_URL, value.trim()).apply()

    private fun catalogFile(ctx: Context): File = File(GatewayConfig.dataDir(ctx), "models.json")

    /** 删除本地清单 → 网关回退到 APK 内置的 models.builtin.json。 */
    fun restoreBuiltin(ctx: Context): Boolean {
        val had = catalogFile(ctx).isFile
        catalogFile(ctx).delete()
        runCatching { File(GatewayConfig.nodeHome(ctx), LOCAL_UPDATE_FLAG).delete() }
        return had
    }

    fun hasLocalUpdate(ctx: Context): Boolean = catalogFile(ctx).isFile

    fun currentVersion(ctx: Context): String {
        val f = catalogFile(ctx)
        if (!f.isFile) return "APK 内置快照（2026-11-10）"
        return runCatching {
            JSONObject(f.readText()).optString("updatedAt", "").ifBlank { "本地清单" }
        }.getOrDefault("本地清单")
    }

    suspend fun update(ctx: Context, onProgress: (String) -> Unit = {}): UpdateResult =
        withContext(Dispatchers.IO) {
            val sourceUrl = url(ctx)
            onProgress("正在下载免费模型目录…\n$sourceUrl")

            val conn = (URL(sourceUrl).openConnection() as HttpURLConnection).apply {
                connectTimeout = 20_000
                readTimeout = 60_000
                instanceFollowRedirects = true
                requestMethod = "GET"
                setRequestProperty("Accept", "application/json")
                setRequestProperty("User-Agent", "AggregateGateway/1.0")
                // 匿名档用字面量 public；若用户填的是自家镜像，多带一个头也无妨
                setRequestProperty("Authorization", "Bearer public")
            }
            val code = conn.responseCode
            if (code !in 200..299) {
                conn.disconnect()
                throw IOException("下载失败：HTTP $code（国内网络可能需要代理，或稍后重试）")
            }
            val buf = ByteArray(16 * 1024)
            val sb = StringBuilder()
            var total = 0L
            conn.inputStream.use { input ->
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    total += n
                    if (total > MAX_DOWNLOAD) throw IOException("目录超过 4 MB，已中止")
                    sb.append(String(buf, 0, n, Charsets.UTF_8))
                }
            }
            conn.disconnect()
            val text = sb.toString().trim()
            if (text.length < 20) throw IOException("下载内容异常（仅 ${text.length} 字节），已中止")

            onProgress("下载完成 ${"%.1f".format(total / 1024.0)} KB，正在解析免费模型…")
            val items = parseCatalog(text)
            if (items.isEmpty()) {
                throw IOException("目录里没筛出免费模型，已放弃更新（现有清单保持不变）")
            }

            // 保留用户此前在管理页设置的 hidden 状态
            val hidden = HashMap<String, Boolean>()
            val old = catalogFile(ctx)
            if (old.isFile) runCatching {
                val arr = JSONObject(old.readText()).optJSONArray("items")
                if (arr != null) for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val id = o.optString("id")
                    if (id.isNotBlank()) hidden[id] = o.optBoolean("hidden", false)
                }
            }
            items.forEach { it.put("hidden", hidden[it.optString("id")] == true) }

            val stamp = SimpleDateFormat("yyyyMMddHHmmss", Locale.US).format(Date())
            val iso = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
                timeZone = TimeZone.getTimeZone("UTC")
            }.format(Date())
            val payload = JSONObject().apply {
                put("updatedAt", iso)
                put("source", sourceUrl)
                put("items", JSONArray(items))
            }
            val json = payload.toString()
            val dest = catalogFile(ctx)
            val tmp = File(dest.parentFile, "models.json.tmp")
            tmp.writeText(json)
            if (!tmp.renameTo(dest)) throw IOException("无法写入 models.json，已放弃更新")

            onProgress("校验通过，${items.size} 个免费模型，已写入本地清单")
            UpdateResult("catalog-$stamp-${sha256Hex(json).take(8)}", items.size, json.toByteArray().size.toLong(), sourceUrl)
        }

    /** 兼容三种目录形态：OpenAI {data:[]} / 裸数组 / 插件面板 {items:[{model_name:[]}]}。 */
    private fun parseCatalog(text: String): List<JSONObject> {
        val rows = JSONArray()
        val root = text.trim()
        when {
            root.startsWith("[") -> {
                val a = JSONArray(root)
                for (i in 0 until a.length()) rows.put(a.get(i))
            }
            root.startsWith("{") -> {
                val o = JSONObject(root)
                val arr = o.optJSONArray("data") ?: o.optJSONArray("models") ?: o.optJSONArray("items")
                if (arr != null) for (i in 0 until arr.length()) rows.put(arr.get(i))
            }
            else -> return emptyList()
        }

        val out = LinkedHashMap<String, JSONObject>()
        val knownFree = setOf("big-pickle")
        for (i in 0 until rows.length()) {
            val r = rows.get(i)
            if (r is String) {
                addFree(out, r, r)
                continue
            }
            if (r !is JSONObject) continue
            val id = r.optString("id").ifBlank { r.optString("name") }
            val names = r.optJSONArray("model_name")
            if (names != null && names.length() > 0) {
                for (j in 0 until names.length()) {
                    val n = names.optString(j)
                    val enabled = r.optString("status", "enabled") == "enabled" && r.optBoolean("usable", true)
                    if (n.isNotBlank() && enabled) addFree(out, n, r.optString("title").ifBlank { n })
                }
                continue
            }
            if (id.isBlank()) continue
            if (isFree(id, r, knownFree)) {
                addFree(out, id, r.optString("display_name").ifBlank {
                    r.optString("name").ifBlank { id }
                })
            }
        }
        return out.values.toList()
    }

    /** 免费判据与 Node 侧 refreshCatalog 保持一致，只认有公开依据的两类。 */
    private fun isFree(id: String, o: JSONObject, knownFree: Set<String>): Boolean {
        if (id in knownFree || id.endsWith("-free", ignoreCase = true)) return true
        val p = o.optJSONObject("pricing") ?: o.optJSONObject("cost") ?: o.optJSONObject("price")
        if (p != null) {
            var nums = 0
            var allZero = true
            val it = p.keys()
            while (it.hasNext()) {
                val v = p.opt(it.next())
                if (v is Number) { nums++; if (v.toDouble() != 0.0) allZero = false }
            }
            if (nums > 0 && allZero) return true
        }
        return false
    }

    private fun addFree(out: LinkedHashMap<String, JSONObject>, id: String, title: String) {
        if (out.containsKey(id)) return
        out[id] = JSONObject().apply {
            put("id", id)
            put("title", title)
            put("api_base_url", ZEN_BASE)
            put("model_name", JSONArray().put(id))
            put("status", "enabled")
            put("usable", true)
            put("disabled_reason", "")
            put("hidden", false)
        }
    }

    private fun sha256Hex(s: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        val d = md.digest(s.toByteArray(Charsets.UTF_8))
        return d.joinToString("") { "%02x".format(it.toInt() and 0xff) }
    }
}
