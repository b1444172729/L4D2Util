package com.android.dsh.core

import android.content.Context
import android.util.Log
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Node 运行时启动器。
 *
 * 两条路径，按顺序尝试：
 *  1. 自建 JNI 胶水 NodeBridge（本工程自带 CMake 源码编译，不依赖 RN 插件）；
 *  2. 兼容旧形态：若用户确实塞进了 nodejs-mobile RN 插件的 aar，仍用反射调用。
 *
 * 【重要】Node 在一个进程里只能初始化一次，重复调用会触发 V8 assert 直接 abort。
 * 因此 started 用 AtomicBoolean 守住；node::Start 是阻塞调用，必须放在独立线程。
 */
object NodeRuntime {

    const val NODE_CLASS = "com.janeasystems.rn_nodejs_mobile.NodeJS"
    private const val TAG = "NodeRuntime"
    private val started = AtomicBoolean(false)

    data class Launch(
        val nodeHome: File,
        val port: Int,
        val dataDir: File,
        val lanRelay: Boolean
    )

    fun isRunning(): Boolean = started.get()

    fun libnodePath(ctx: Context): String =
        File(ctx.applicationInfo.nativeLibraryDir.orEmpty(), "libnode.so").absolutePath

    fun start(ctx: Context, launch: Launch): Result<Unit> {
        if (!started.compareAndSet(false, true)) {
            return Result.failure(IllegalStateException("Node 运行时已在本进程初始化，重复启动被拒绝"))
        }

        val diag = RuntimeDiagnostics.check(ctx)
        if (!diag.canStartNode) {
            started.set(false)
            return Result.failure(
                IllegalStateException("APK 未内置可运行的 Node.js 运行时，网关无法启动。\n" + diag.advice())
            )
        }

        return try {
            val entry = File(launch.nodeHome, "bootstrap.js")
            require(entry.isFile) { "缺少 bootstrap.js：${entry.absolutePath}" }

            val args = buildList {
                add("node")
                add(entry.absolutePath)
                add("--port"); add(launch.port.toString())
                add("--data-dir"); add(launch.dataDir.absolutePath)
                add("--host"); add(GatewayConfig.LOOPBACK)
                if (launch.lanRelay) add("--lan-relay")
            }.toTypedArray()

            val libnode = libnodePath(ctx)

            if (NodeBridge.isAvailable()) {
                // node::Start 会一直阻塞到 Node 主循环结束，绝不能占着协程线程池。
                Thread({
                    try {
                        val rc = NodeBridge.start(args, libnode, launch.nodeHome.absolutePath)
                        Log.i(TAG, "node::Start 返回 $rc")
                    } catch (t: Throwable) {
                        Log.e(TAG, "Node 线程异常", t)
                        runCatching {
                            GatewayConfig.nodeErrorLog(ctx).appendText(
                                "[${System.currentTimeMillis()}] Node 线程异常: ${t.stackTraceToString()}\n"
                            )
                        }
                    }
                }, "dsh-nodejs-mobile").apply { isDaemon = true }.start()
            } else {
                // 兼容：用户自行放入 RN 插件 aar 的老形态
                val clazz = Class.forName(NODE_CLASS)
                val startMethod = clazz.declaredMethods.firstOrNull { m ->
                    m.name == "start" && m.parameterTypes.any { p ->
                        p.isArray && p.componentType == String::class.java
                    }
                } ?: throw NoSuchMethodException("未找到 NodeJS.start(String[]...)")
                val callArgs: Array<Any?> = when (startMethod.parameterTypes.size) {
                    1 -> arrayOf<Any?>(args)
                    else -> arrayOf<Any?>(args, ctx)
                }
                startMethod.invoke(null, *callArgs)
            }
            Result.success(Unit)
        } catch (t: Throwable) {
            started.set(false)
            Result.failure(t)
        }
    }

    /**
     * Node 单实例无法真正停：这里只复位标志并通知旧形态的 stop（若存在）。
     * 进程内真正关闭需重启 App，这一点已写进 README。
     */
    fun requestStop() {
        try {
            val clazz = Class.forName(NODE_CLASS)
            clazz.declaredMethods.firstOrNull { it.name == "stop" && it.parameterTypes.isEmpty() }
                ?.invoke(null)
        } catch (ignored: Throwable) {
            // 自建胶水没有 stop，忽略
        }
        started.set(false)
    }
}
