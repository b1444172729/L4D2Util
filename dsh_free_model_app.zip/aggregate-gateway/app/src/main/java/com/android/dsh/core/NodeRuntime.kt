package com.android.dsh.core

import android.content.Context
import android.util.Log
import java.io.File

/**
 * Node 运行时启动器，只应运行在 :node 独立进程里（见 NodeService）。
 *
 * 两条路径，按顺序尝试：
 *  1. 自建 JNI 胶水 NodeBridge（本工程自带 CMake 源码编译，不依赖 RN 插件）；
 *  2. 兼容旧形态：若用户确实塞进了 nodejs-mobile RN 插件的 aar，仍用反射调用。
 *
 * 原先这里用 AtomicBoolean 守「V8 一个进程只能初始化一次」。现在 Node 跑在
 * 独立进程，重启时是由主进程 kill 掉整个 :node 再拉起一个全新的进程，
 * 每次都是全新的 V8 实例，因此不再需要这层守卫 —— 保留它反而会在
 * 「重启 Node 服务」时误报「重复启动被拒绝」。
 *
 * node::Start 是阻塞调用，必须放在独立线程；它一旦 abort()/exit()，
 * 结束的只是 :node 进程，UI 主进程与前台服务不受影响。
 */
object NodeRuntime {

    const val NODE_CLASS = "com.janeasystems.rn_nodejs_mobile.NodeJS"
    private const val TAG = "NodeRuntime"

    data class Launch(
        val nodeHome: File,
        val port: Int,
        val dataDir: File,
        val lanRelay: Boolean
    )

    fun libnodePath(ctx: Context): String =
        File(ctx.applicationInfo.nativeLibraryDir.orEmpty(), "libnode.so").absolutePath

    fun start(ctx: Context, launch: Launch): Result<Unit> {
        val diag = RuntimeDiagnostics.check(ctx)
        if (!diag.canStartNode) {
            return Result.failure(
                IllegalStateException("APK 未内置可运行的 Node.js 运行时，网关无法启动。\n" + diag.advice())
            )
        }

        return try {
            val entry = File(launch.nodeHome, "bootstrap.js")
            require(entry.isFile) { "缺少 bootstrap.js：${entry.absolutePath}" }

            val args = buildList {
                add("node")
                add(entry.absolutePath)
                // 明确告诉 Node「脚本参数从这里开始」。标准 Node 遇到脚本路径后
                // 就停止解析选项，但 nodejs-mobile 的 Android patch 版本未必一致；
                // 万一它继续把 --port 当作 Node 自身选项，会直接报 bad option 并
                // exit(9)。加一个 -- 是零风险的防御：bootstrap.js 的 parseArgs
                // 只匹配 --port 等键，遇到 "--" 会自动跳过。
                add("--")
                add("--port"); add(launch.port.toString())
                add("--data-dir"); add(launch.dataDir.absolutePath)
                add("--host"); add(GatewayConfig.LOOPBACK)
                if (launch.lanRelay) add("--lan-relay")
            }.toTypedArray()

            val libnode = libnodePath(ctx)

            if (NodeBridge.isAvailable()) {
                // node::Start 会一直阻塞到 Node 主循环结束，绝不能占着 Service 主线程。
                Thread({
                    try {
                        val rc = NodeBridge.start(
                            args,
                            libnode,
                            launch.nodeHome.absolutePath,
                            GatewayConfig.nodeOutputLog(ctx).absolutePath
                        )
                        Log.i(TAG, "node::Start 返回 $rc")
                        if (rc < 0) {
                            val msg = when (rc) {
                                -101 -> "dlopen(libnode.so) 失败：APK 内缺少 libnode.so 的依赖库" +
                                    "（最常见是没打包 arm64 的 libc++_shared.so），请查看运行时自检的符号探测。"
                                -102 -> "libnode.so 已加载，但未导出 node::Start 符号（版本或裁剪不匹配）。"
                                -103 -> "构建 Node argv 时内存分配失败。"
                                else -> "Node 启动返回错误码 $rc"
                            }
                            reportFatal(ctx, msg)
                        } else {
                            // node::Start 正常返回说明 Node 主循环结束了（而不是崩溃），
                            // 也写一条标记，让 HealthProbe 立刻收尾。
                            reportFatal(ctx, "node::Start 已返回（退出码 $rc），Node 主循环结束。")
                        }
                    } catch (t: Throwable) {
                        Log.e(TAG, "Node 线程异常", t)
                        reportFatal(ctx, "Node 线程异常：${t.javaClass?.simpleName}: ${t.message}")
                    }
                }, "dsh-nodejs-mobile").apply { isDaemon = true }.start()
            } else {
                // 兼容：用户自行放入 RN 插件 aar 的老形态
                val clazz = Class.forName(NODE_CLASS)
                val startMethod = clazz.declaredMethods.firstOrNull { m ->
                    m.name == "start" && m.parameterTypes.any { p ->
                        p.isArray && p.componentType == String::class.java
                    }
                } ?: throw NoSuchMethodException("未找到 NodeJS.start(String[]...)")
                val callArgs: Array<Any?> = when (startMethod.parameterTypes.size) {
                    1 -> arrayOf<Any?>(args)
                    else -> arrayOf<Any?>(args, ctx)
                }
                startMethod.invoke(null, *callArgs)
            }
            Result.success(Unit)
        } catch (t: Throwable) {
            Result.failure(t)
        }
    }

    /** 写 node-errors.log + 短标记，让 HealthProbe 与界面立刻看到真实原因。 */
    private fun reportFatal(ctx: Context, msg: String) {
        val line = "[${System.currentTimeMillis()}] $msg\n"
        runCatching { GatewayConfig.nodeErrorLog(ctx).appendText(line) }
        runCatching { GatewayConfig.nodeFatalFile(ctx).writeText(msg) }
        Log.e(TAG, msg)
    }
}
