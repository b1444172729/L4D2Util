package com.android.dsh.core

import android.content.Context
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

/**
 * nodejs-mobile 运行时的薄封装。
 *
 * 用反射调用 com.janeasystems.rn_nodejs_mobile.NodeJS，好处是：
 * - 不同 nodejs-mobile 发行版的 start(...) 签名略有差异（有的带 Context，有的不带）；
 * - 未放入 aar 时工程仍可编译，运行时给出明确错误而不是编译期崩溃。
 *
 * 【重要】Node 在一个进程里只能初始化一次，重复调用会触发 V8 assert 直接 abort。
 * 因此 started 用 AtomicBoolean 守住，且停止时必须等宿主进程真正结束才允许再次 start。
 */
object NodeRuntime {

    const val NODE_CLASS = "com.janeasystems.rn_nodejs_mobile.NodeJS"
    private val started = AtomicBoolean(false)

    data class Launch(
        val nodeHome: File,
        val port: Int,
        val dataDir: File,
        val lanRelay: Boolean
    )

    fun isRunning(): Boolean = started.get()

    fun start(ctx: Context, launch: Launch): Result<Unit> {
        if (!started.compareAndSet(false, true)) {
            return Result.failure(IllegalStateException("Node 运行时已在本进程初始化，重复启动被拒绝"))
        }

        // 前置自检：缺原生运行时或桥接层时，直接给出中文结论，
        // 不要让 ClassNotFoundException 的类名（com.janeasystems...）直接显示在界面上。
        val diag = RuntimeDiagnostics.check(ctx)
        if (!diag.canStartNode) {
            started.set(false)
            return Result.failure(
                IllegalStateException("APK 未内置可运行的 Node.js 运行时，网关无法启动。\n" + diag.advice())
            )
        }

        return try {
            val clazz = Class.forName(NODE_CLASS)
            val entry = File(launch.nodeHome, "bootstrap.js")
            require(entry.isFile) { "缺少 bootstrap.js：${entry.absolutePath}" }

            val args = buildList {
                add("node")
                add(entry.absolutePath)
                add("--port"); add(launch.port.toString())
                add("--data-dir"); add(launch.dataDir.absolutePath)
                add("--host"); add(GatewayConfig.LOOPBACK)
                if (launch.lanRelay) add("--lan-relay")
            }.toTypedArray()

            val startMethod = clazz.declaredMethods.firstOrNull { m ->
                m.name == "start" && m.parameterTypes.any { p ->
                    p.isArray && p.componentType == String::class.java
                }
            } ?: throw NoSuchMethodException(
                "未找到 NodeJS.start(String[]...)，请检查 app/libs 下的 nodejs-mobile 版本"
            )

            // Method.invoke(Object, Object...) 的 vararg 必须显式包一层：
            // 直接传 args 会被展开成一串 String，而不是「一个 String[] 参数」。
            // 显式写 <Any?>：Kotlin 的 Array 是不变型，靠期望类型推断 arrayOf
            // 在个别编译器版本上会推成 Array<Array<String>> 而类型不匹配。
            val callArgs: Array<Any?> = when (startMethod.parameterTypes.size) {
                1 -> arrayOf<Any?>(args)
                else -> arrayOf<Any?>(args, ctx)
            }
            startMethod.invoke(null, *callArgs)
            Result.success(Unit)
        } catch (t: Throwable) {
            started.set(false)
            Result.failure(t)
        }
    }

    /**
     * 优雅关停：先让 bootstrap.js 释放端口，再结束进程。
     * 粗暴兜底（杀残留 node 进程、清 service.lock）由 bootstrap.js 与 README 里的运维步骤承担。
     */
    fun requestStop() {
        try {
            val clazz = Class.forName(NODE_CLASS)
            clazz.declaredMethods.firstOrNull { it.name == "stop" && it.parameterTypes.isEmpty() }
                ?.invoke(null)
        } catch (ignored: Throwable) {
            // 运行时未加载时无需处理
        }
        started.set(false)
    }
}
