package com.android.dsh.core

import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.android.dsh.GatewayApp
import com.android.dsh.MainActivity
import com.android.dsh.R
import com.android.dsh.ui.FloatingWindow
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class GatewayService : Service() {

    companion object {
        const val ACTION_START = "com.android.dsh.action.START"
        const val ACTION_STOP = "com.android.dsh.action.STOP"
        const val ACTION_RESTART = "com.android.dsh.action.RESTART"
        private const val NOTIF_ID = 1001

        fun start(ctx: Context) {
            val i = Intent(ctx, GatewayService::class.java).setAction(ACTION_START)
            ctx.startForegroundService(i)
        }

        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, GatewayService::class.java).setAction(ACTION_STOP))
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var wakeLock: PowerManager.WakeLock? = null
    private var floating: FloatingWindow? = null

    override fun onCreate() {
        super.onCreate()
        ServiceCompat.startForeground(
            this, NOTIF_ID, buildNotification(null),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        )
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                shutdown()
                stopSelf()
                // Android Service 的 onStartCommand 只有四个合法返回常量：
                // START_STICKY / START_NOT_STICKY / START_REDELIVER_INTENT /
                // START_STICKY_COMPATIBILITY。此前误写了一个不存在的标识符，
                // 导致 Kotlin 编译报 Unresolved reference。
                // 用户主动停止后不应被系统重启，故用 START_NOT_STICKY。
                return START_NOT_STICKY
            }
            ACTION_RESTART -> {
                shutdown(keepForeground = true)
                boot()
            }
            else -> boot()
        }
        return START_STICKY
    }

    private fun boot() {
        scope.launch {
            val app = GatewayApp.instance
            app.post(GatewayApp.Status(GatewayApp.State.STARTING, message = getString(R.string.state_starting)))
            acquireWakeLock()

            try {
                val nodeHome = AssetInstaller.installIfNeeded(this@GatewayService)
                val port = GatewayConfig.requestedPort(this@GatewayService)
                val dataDir = GatewayConfig.dataDir(this@GatewayService)
                val lan = GatewayConfig.lanRelayEnabled(this@GatewayService)

                // 清掉上一轮快照，避免 HealthProbe 读到旧的端口 / Key
                GatewayConfig.runtimeFile(this@GatewayService).delete()

                NodeRuntime.start(
                    this@GatewayService,
                    NodeRuntime.Launch(nodeHome, port, dataDir, lan)
                ).getOrThrow()

                val info = HealthProbe.awaitRuntime(this@GatewayService, port)
                    ?: error("Node 已启动但 /health 未就绪，详见 ofm-data/node-errors.log")

                GatewayApp.instance.post(
                    GatewayApp.Status(
                        state = GatewayApp.State.READY,
                        port = info.port,
                        apiKey = info.apiKey,
                        manageUrl = info.manageUrl,
                        message = if (info.portShifted) getString(R.string.state_port_changed) else ""
                    )
                )
                ServiceCompat.startForeground(
                    this@GatewayService, NOTIF_ID, buildNotification(info),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
                withContext(Dispatchers.Main) { attachFloatingWindow() }
            } catch (t: Throwable) {
                val raw = t.message ?: t.javaClass.simpleName
                val diag = RuntimeDiagnostics.check(this@GatewayService)
                // ClassNotFoundException 的 message 只有类名，对用户毫无意义
                val friendly = if (t is ClassNotFoundException ||
                    raw == NodeRuntime.NODE_CLASS ||
                    t is UnsatisfiedLinkError
                ) {
                    "APK 的 Node.js 运行时未就绪。\n${diag.advice()}\n${diag.probe}"
                } else {
                    raw
                }
                GatewayApp.instance.post(
                    GatewayApp.Status(
                        state = GatewayApp.State.ERROR,
                        message = friendly
                    )
                )
                GatewayConfig.nodeErrorLog(this@GatewayService).appendText(
                    "[${System.currentTimeMillis()}] $friendly\n" +
                        diag.summary() + "\n" + t.stackTraceToString() + "\n"
                )
            }
        }
    }

    /** 悬浮窗只做「可见 + 可操作」，真正的保活靠前台服务 + 唤醒锁 + 电池白名单 */
    private fun attachFloatingWindow() {
        if (!GatewayConfig.floatingEnabled(this)) return
        if (!android.provider.Settings.canDrawOverlays(this)) return
        if (floating == null) floating = FloatingWindow(this)
        floating?.show()
    }

    private fun shutdown(keepForeground: Boolean = false) {
        NodeRuntime.requestStop()
        floating?.hide()
        floating = null
        wakeLock?.takeIf { it.isHeld }?.release()
        wakeLock = null
        if (!keepForeground) {
            GatewayApp.instance.post(GatewayApp.Status(GatewayApp.State.STOPPED))
        }
    }

    @Suppress("MissingPermission")
    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AggregateGateway::Node").apply { acquire() }
    }

    private fun buildNotification(info: HealthProbe.RuntimeInfo?): android.app.Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val text = if (info != null) {
            "${GatewayConfig.LOOPBACK}:${info.port}${if (info.portShifted) " · ${getString(R.string.state_port_changed)}" else ""}"
        } else {
            getString(R.string.notif_text)
        }
        val stopPi = PendingIntent.getService(
            this, 1, Intent(this, GatewayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, GatewayApp.CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(text)
            .setContentIntent(pi)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(android.R.drawable.ic_media_pause, getString(R.string.action_stop), stopPi)
            .build()
    }

    override fun onDestroy() {
        shutdown()
        scope.cancel()
        super.onDestroy()
    }
}
