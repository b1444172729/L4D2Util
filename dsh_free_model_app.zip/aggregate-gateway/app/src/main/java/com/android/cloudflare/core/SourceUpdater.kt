package com.android.cloudflare.core

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException

/**
 * Cloudflare Workers AI 网关版（cf-ai-gateway-r4）。
 *
 * 旧版这里会从 GitHub 拉 dsh-our-free-model 的 main 分支，裁剪后原子替换
 * filesDir/gateway/node。本改造版不再包含上游源码，若继续更新会把
 * bootstrap.cjs / cf-proxy.cjs 覆盖掉，网关直接起不来 —— 因此「更新上游源码」
 * 明确禁用，点下去给出提示且不动任何文件。
 *
 * 需要改账户 ID / API 令牌 / 本机 Key 时，打开主界面「打开管理页」
 * （http://127.0.0.1:<端口>/），在页面里改并保存，无需重新编译 APK。
 *
 * 保留全部公开成员签名，MainActivity 无需改动。
 */
object SourceUpdater {

    const val DEFAULT_URL = ""

    private const val PREF = "gateway_config"
    private const val KEY_URL = "update_url"
    private const val LOCAL_UPDATE_FLAG = ".ofm-local-update"

    data class UpdateResult(
        val version: String,
        val files: Int,
        val bytes: Long,
        val sourceUrl: String
    ) {
        fun description(): String =
            "已更新到 $version\n来源：$sourceUrl\n源码 $files 个文件"
    }

    fun url(ctx: Context): String =
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getString(KEY_URL, "").orEmpty().ifBlank { DEFAULT_URL }

    fun setUrl(ctx: Context, value: String) =
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit().putString(KEY_URL, value.trim()).apply()

    /** 清掉旧版可能残留的本地更新标记，下次启动用 APK 内置源码重建。 */
    fun restoreBuiltin(ctx: Context): Boolean {
        val flag = File(GatewayConfig.nodeHome(ctx), LOCAL_UPDATE_FLAG)
        return if (flag.isFile) flag.delete() else false
    }

    fun hasLocalUpdate(ctx: Context): Boolean = false

    fun currentVersion(ctx: Context): String {
        val f = File(GatewayConfig.nodeHome(ctx), "bundle-version.txt")
        val v = if (f.isFile) f.readText().trim() else "内置"
        return "Cloudflare Workers AI 网关 · $v"
    }

    suspend fun update(ctx: Context, onProgress: (String) -> Unit = {}): UpdateResult =
        withContext(Dispatchers.IO) {
            onProgress("此版本为 Cloudflare Workers AI 专用网关，不提供上游源码更新")
            throw IOException(
                "已禁用 GitHub 上游源码更新：本 APK 内置 cf-proxy.cjs。" +
                    "改账户 ID / API 令牌 / 本机 Key 请点「打开管理页」；" +
                    "现有源码未被改动，可直接点「启动网关」继续使用。"
            )
        }
}
