package com.android.dsh.core

import android.content.Context
import java.io.File

/**
 * 全机唯一配置源。所有路径都落在 app 私有目录，不写 sdcard。
 * 数据目录 ofm-data 对应 standalone 的 OFM_HOME（桌面端默认 ~/.our-free-model）。
 */
object GatewayConfig {

    private const val PREF = "gateway_config"
    const val DEFAULT_PORT = 18900
    const val LOOPBACK = "127.0.0.1"

    private fun prefs(ctx: Context) =
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun requestedPort(ctx: Context): Int = prefs(ctx).getInt("port", DEFAULT_PORT)
    fun setRequestedPort(ctx: Context, port: Int) =
        prefs(ctx).edit().putInt("port", port).apply()

    fun floatingEnabled(ctx: Context): Boolean = prefs(ctx).getBoolean("floating", true)
    fun setFloatingEnabled(ctx: Context, enabled: Boolean) =
        prefs(ctx).edit().putBoolean("floating", enabled).apply()

    fun bootEnabled(ctx: Context): Boolean = prefs(ctx).getBoolean("boot", false)
    fun setBootEnabled(ctx: Context, enabled: Boolean) =
        prefs(ctx).edit().putBoolean("boot", enabled).apply()

    fun lanRelayEnabled(ctx: Context): Boolean = prefs(ctx).getBoolean("lan_relay", false)
    fun setLanRelayEnabled(ctx: Context, enabled: Boolean) =
        prefs(ctx).edit().putBoolean("lan_relay", enabled).apply()

    /** standalone 的数据目录：settings.json / 用量统计 / 账号凭据都放这里 */
    fun dataDir(ctx: Context): File = File(ctx.filesDir, "ofm-data").apply { mkdirs() }

    /** 从 assets 释放出来的 Node 代码根目录 */
    fun nodeHome(ctx: Context): File = File(ctx.filesDir, "gateway/node")

    /** bootstrap.js 回写给安卓壳的运行信息 */
    fun runtimeFile(ctx: Context): File = File(dataDir(ctx), "gateway-runtime.json")

    fun nodeErrorLog(ctx: Context): File = File(dataDir(ctx), "node-errors.log")
}
