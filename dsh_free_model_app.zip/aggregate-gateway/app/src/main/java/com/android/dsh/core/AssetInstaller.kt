package com.android.dsh.core

import android.content.Context
import java.io.File
import java.io.IOException

/**
 * 把 assets/node 里的上游源码释放到 filesDir/gateway/node。
 *
 * r6 改动：源码改为【散放 assets】，不再打 bundle.zip。
 * 旧版先解压一个 85 MB 的 zip（里面还装着运行时用不到的 node_modules），
 * 现在直接逐个复制裁剪后的散文件，APK 更小、首次释放更快，且目录树
 * 天然没有符号链接（上游 managed storage 闸门会拒绝带链接的安装）。
 *
 * 两条约定：
 * 1. Node 进程级单例：一个进程里只能初始化一次，释放只在服务冷启动做；
 * 2. 升级时用 bundle-version.txt 做标记，重拷代码目录但绝不碰 ofm-data/。
 *
 * ★ 应用内更新优先：SourceUpdater 从 GitHub 拉源码覆盖 nodeHome 后写
 *   `.ofm-local-update`（内容 = 当时 APK 内的 bundle-version.txt）。
 *   只要 APK 没换，就保留本地更新，不被 assets 里的旧版源码覆盖；
 *   一旦 APK 换了（incoming 变化），标记失效并重建，保证新 bootstrap.cjs
 *   一定能生效。用户也可点「恢复内置源码」主动清除标记。
 */
object AssetInstaller {

    private const val LOCAL_UPDATE_FLAG = ".ofm-local-update"

    fun installIfNeeded(ctx: Context): File {
        val target = GatewayConfig.nodeHome(ctx)

        // icudtl.dat 由 fetch-libnode.sh 单独放在 assets/node/，不在源码树里。
        // 必须在「版本相同就提前返回」之前补拷：否则首次安装没这份文件，
        // 后来补进 APK 也不会被释放，NODE_ICU_DATA 就永远指不到它。
        ensureIcuData(ctx, target)

        val incoming = readAsset(ctx, "node/bundle-version.txt")?.trim().orEmpty().ifEmpty { "dev" }
        val current = File(target, "bundle-version.txt").takeIf { it.isFile }?.readText()?.trim().orEmpty()

        val complete = File(target, "bootstrap.cjs").isFile &&
            File(target, "package.json").isFile &&
            File(target, "packages/standalone/cli.mjs").isFile

        // 本地更新优先：标记里记录的 assets 版本与当前 APK 一致 → 不覆盖
        val flag = File(target, LOCAL_UPDATE_FLAG)
        val flagBase = flag.takeIf { it.isFile }?.readText()?.trim().orEmpty()
        if (flagBase.isNotBlank() && flagBase == incoming && complete) return target

        if (current == incoming && complete) return target

        // 只重建代码目录；数据目录 GatewayConfig.dataDir 在别处，不会被删
        if (target.exists()) target.deleteRecursively()
        target.mkdirs()

        copyAssetDir(ctx, "node", target)

        if (!File(target, "bootstrap.cjs").isFile ||
            !File(target, "package.json").isFile ||
            !File(target, "packages/standalone/cli.mjs").isFile
        ) {
            throw IOException("assets/node 源码不完整，请先执行 scripts/prepare-node-bundle.sh")
        }
        return target
    }

    /**
     * 递归复制 assets 目录。裁剪后约 150–300 个散文件，逐个 open 在安卓上
     * 远快于解压一个 85 MB 的 zip（对方移植版也是同样的散放形态）。
     */
    private fun copyAssetDir(ctx: Context, assetPath: String, outDir: File) {
        val am = ctx.assets
        val names = am.list(assetPath).orEmpty()
        for (name in names) {
            if (name.startsWith(".") || name == "__MACOSX") continue
            val childAsset = "$assetPath/$name"
            val out = File(outDir, name)
            val children = am.list(childAsset).orEmpty()
            if (children.isNotEmpty()) {
                out.mkdirs()
                copyAssetDir(ctx, childAsset, out)
            } else {
                out.parentFile?.mkdirs()
                // 空目录与单文件在 AssetManager 里都可能返回空列表，用 open 探测兜底
                try {
                    am.open(childAsset).use { input -> out.outputStream().use { input.copyTo(it) } }
                } catch (ignored: IOException) {
                    out.mkdirs()
                }
            }
        }
    }

    /** 把 assets/node/icudtl.dat 补拷到 nodeHome；文件不存在时静默跳过。 */
    private fun ensureIcuData(ctx: Context, target: File) {
        runCatching {
            if (!target.exists()) target.mkdirs()
            ctx.assets.open("node/icudtl.dat").use { input ->
                val dest = File(target, "icudtl.dat")
                val tmp = File(target, "icudtl.dat.tmp")
                tmp.outputStream().use { input.copyTo(it) }
                if (dest.isFile && dest.length() == tmp.length()) {
                    tmp.delete()
                } else {
                    tmp.renameTo(dest)
                }
            }
        }
    }

    /** 当前 APK 内置的源码版本，SourceUpdater 用它写本地更新标记。 */
    fun assetVersion(ctx: Context): String =
        readAsset(ctx, "node/bundle-version.txt")?.trim().orEmpty().ifEmpty { "dev" }

    fun localUpdateFlag(ctx: Context): File = File(GatewayConfig.nodeHome(ctx), LOCAL_UPDATE_FLAG)

    private fun readAsset(ctx: Context, path: String): String? = try {
        ctx.assets.open(path).bufferedReader().use { it.readText() }
    } catch (e: IOException) {
        null
    }
}
