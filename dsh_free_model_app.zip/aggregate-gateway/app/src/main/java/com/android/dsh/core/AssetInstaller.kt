package com.android.dsh.core

import android.content.Context
import java.io.File
import java.io.IOException

/**
 * 把 assets/node 里的完整仓库释放到 filesDir。
 *
 * 两条约定（来自 nodejs-mobile 在安卓上的常见坑）：
 * 1. Node 进程级单例：一个进程里只能初始化一次，所以释放动作只在服务冷启动时做；
 * 2. 升级时用 bundle-version.txt 做标记，重拷 node/ 但绝不碰 ofm-data/（Key、统计、账号）。
 */
object AssetInstaller {

    fun installIfNeeded(ctx: Context): File {
        val target = GatewayConfig.nodeHome(ctx)

        // icudtl.dat 由 fetch-libnode.sh 单独放在 assets/node/，不在 bundle.zip 里。
        // 必须在下面的「版本相同就提前返回」之前补拷：否则首次安装时没有这份文件，
        // 后来补进 APK 也不会被释放，NODE_ICU_DATA 就永远指不到它。
        ensureIcuData(ctx, target)

        val incoming = readAsset(ctx, "node/bundle-version.txt")?.trim().orEmpty().ifEmpty { "dev" }
        val current = File(target, "bundle-version.txt").takeIf { it.isFile }?.readText()?.trim().orEmpty()

        val complete = File(target, "bootstrap.cjs").isFile &&
            File(target, "package.json").isFile &&
            File(target, "packages/standalone").exists()

        if (current == incoming && complete) return target

        // 只重建代码目录；数据目录 GatewayConfig.dataDir 在别处，不会被删
        if (target.exists()) target.deleteRecursively()
        target.mkdirs()

        // 生产形态：脚本把完整仓库打成单个 bundle.zip，一次解压即可
        // （逐个 AssetManager.open 复制几千个 node_modules 小文件在安卓上极慢）
        val hasZip = runCatching { ctx.assets.open("node/bundle.zip").close(); true }.getOrDefault(false)
        if (hasZip) {
            unzipBundle(ctx, target)
        } else {
            copyAssetDir(ctx, "node", target)
        }

        if (!File(target, "bootstrap.cjs").isFile || !File(target, "package.json").isFile) {
            throw IOException("assets/node 内容不完整，请先执行 scripts/prepare-node-bundle.sh")
        }
        return target
    }

    private fun unzipBundle(ctx: Context, outDir: File) {
        java.util.zip.ZipInputStream(ctx.assets.open("node/bundle.zip").buffered()).use { zis ->
            while (true) {
                val entry = zis.nextEntry ?: break
                val name = entry.name.replace('\\', '/')
                // Zip Slip 防护
                val dest = File(outDir, name).canonicalFile
                if (!dest.path.startsWith(outDir.canonicalPath + File.separator)) {
                    zis.closeEntry()
                    continue
                }
                if (entry.isDirectory) {
                    dest.mkdirs()
                } else {
                    dest.parentFile?.mkdirs()
                    dest.outputStream().use { zis.copyTo(it) }
                }
                zis.closeEntry()
            }
        }
    }

    private fun copyAssetDir(ctx: Context, assetPath: String, outDir: File) {
        val am = ctx.assets
        val names = am.list(assetPath).orEmpty()
        for (name in names) {
            val childAsset = "$assetPath/$name"
            val out = File(outDir, name)
            val children = am.list(childAsset).orEmpty()
            if (children.isNotEmpty()) {
                out.mkdirs()
                copyAssetDir(ctx, childAsset, out)
            } else {
                out.parentFile?.mkdirs()
                // 空目录与单文件在 AssetManager 里都可能返回空列表，用 open 探测兜底
                try {
                    am.open(childAsset).use { input -> out.outputStream().use { input.copyTo(it) } }
                } catch (ignored: IOException) {
                    out.mkdirs()
                }
            }
        }
    }

    /** 把 assets/node/icudtl.dat 补拷到 nodeHome；文件不存在时静默跳过。 */
    private fun ensureIcuData(ctx: Context, target: File) {
        runCatching {
            if (!target.exists()) target.mkdirs()
            ctx.assets.open("node/icudtl.dat").use { input ->
                val dest = File(target, "icudtl.dat")
                val tmp = File(target, "icudtl.dat.tmp")
                tmp.outputStream().use { input.copyTo(it) }
                if (dest.isFile && dest.length() == tmp.length()) {
                    tmp.delete()
                } else {
                    tmp.renameTo(dest)
                }
            }
        }
    }

    private fun readAsset(ctx: Context, path: String): String? = try {
        ctx.assets.open(path).bufferedReader().use { it.readText() }
    } catch (e: IOException) {
        null
    }
}
