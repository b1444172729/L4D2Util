package com.android.dsh.core

import android.content.Context
import java.io.File
import java.io.IOException

/**
 * 把 assets/node 里的上游源码释放到 filesDir/gateway/node（r11：散放形态）。
 *
 * 与 r5 的区别：CI 不再生成 bundle.zip，源码以几百个散文件直接放进
 * assets/node，这里改用递归复制；源码体积从 85 MB 降到约 10 MB。
 * r5 踩过的「managed storage 符号链接闸门」由 prepare-node-bundle.sh
 * 在打包侧一次性消除（tar -h + 删 .bin + 零链接校验）。
 *
 * Node 路线特有：assets/node/icudtl.dat 若存在（small-icu 构建，
 * KEEP_EXTERNAL_ICU=1 时由 fetch-libnode.sh 放入），要补拷进 nodeHome，
 * 让 C 胶水的 NODE_ICU_DATA 指得到。v22.23.2 默认内嵌 full-icu，
 * 该文件通常不存在，静默跳过即可。
 *
 * 应用内更新优先：SourceUpdater 从 GitHub 拉源码覆盖 nodeHome 后写
 * `.ofm-local-update`（内容 = 当时 APK 内的 bundle-version.txt）。
 * 只要 APK 没换，就保留本地更新；一旦 APK 换了（incoming 变化），
 * 标记失效并重建，保证新 bootstrap.cjs 一定生效。
 */
object AssetInstaller {

    private const val LOCAL_UPDATE_FLAG = ".ofm-local-update"
    /**
     * r19：壳自身版本。上游 bundle-version.txt 只标识上游 commit 与构建时间，
     * 只改壳侧文件（bootstrap.cjs / AssetInstaller / 图标）时它未必变化；
     * 单靠它判断会沿用旧的 nodeHome，旧 bootstrap.cjs 里根本没有补丁代码。
     * 加一层独立标记，保证壳一变就重建源码目录。
     */
    private const val SHELL_VERSION = "r19"
    private const val SHELL_MARKER = ".shell-version"
    private const val EXTRA_SEEDED = ".extra-models-seeded"

    fun installIfNeeded(ctx: Context): File {
        val target = GatewayConfig.nodeHome(ctx)

        // r19：配置释放与「目录是否重建」解耦。每次启动都确保一次，但用标记
        // 保证用户把 ids 改成 [] 或删掉文件来关闭补丁后，不会被悄悄恢复。
        ensureExtraModelsConfig(ctx)

        val incoming = readAsset(ctx, "node/bundle-version.txt")?.trim().orEmpty().ifEmpty { "dev" }
        val current = File(target, "bundle-version.txt").takeIf { it.isFile }?.readText()?.trim().orEmpty()
        // 标记放 dataDir 而不是 nodeHome：SourceUpdater 原子替换 nodeHome 时不会
        // 把它冲掉，否则「应用内更新」后下次启动会被误判成换壳、覆盖用户下载的源码。
        val shellCurrent = File(GatewayConfig.dataDir(ctx), SHELL_MARKER)
            .takeIf { it.isFile }?.readText()?.trim().orEmpty()

        val complete = File(target, "bootstrap.cjs").isFile &&
            File(target, "package.json").isFile &&
            File(target, "packages/standalone/cli.mjs").isFile

        // 本地应用内更新：APK 未变就保留用户下载的源码，不重复复制几百个文件
        val flag = File(target, LOCAL_UPDATE_FLAG)
        val flagBase = flag.takeIf { it.isFile }?.readText()?.trim().orEmpty()
        if (flagBase.isNotBlank() && flagBase == incoming && complete && shellCurrent == SHELL_VERSION) return target
        if (current == incoming && complete && shellCurrent == SHELL_VERSION) return target

        // 只重建代码目录；数据目录 GatewayConfig.dataDir 在别处，不会被删
        if (target.exists()) target.deleteRecursively()
        target.mkdirs()

        // r11：源码散放，不再解压 bundle.zip
        copyAssetDir(ctx, "node", target)

        // 必须在重建之后再补拷：r5 把这一步放在提前返回之前，若恰逢
        // 目录重建，target.deleteRecursively() 会把刚拷进去的 icudtl.dat 删掉。
        ensureIcuData(ctx, target)

        // r19：壳版本标记写在 dataDir，且必须在重建之后，避免「重建失败却已标记」。
        runCatching { File(GatewayConfig.dataDir(ctx), SHELL_MARKER).writeText(SHELL_VERSION) }

        if (!File(target, "bootstrap.cjs").isFile ||
            !File(target, "package.json").isFile ||
            !File(target, "packages/standalone/cli.mjs").isFile
        ) {
            throw IOException("assets/node 源码不完整，请先执行 scripts/prepare-node-bundle.sh")
        }
        return target
    }

    /** 递归复制 assets 目录（约 150–500 个散文件）。 */
    private fun copyAssetDir(ctx: Context, assetPath: String, outDir: File) {
        val am = ctx.assets
        val names = am.list(assetPath).orEmpty()
        for (name in names) {
            if (name.startsWith(".") || name == "__MACOSX") continue
            val childAsset = "$assetPath/$name"
            val out = File(outDir, name)
            val children = am.list(childAsset).orEmpty()
            if (children.isNotEmpty()) {
                out.mkdirs()
                copyAssetDir(ctx, childAsset, out)
            } else {
                out.parentFile?.mkdirs()
                // 空目录与单文件在 AssetManager 里都可能返回空列表，用 open 探测兜底
                try {
                    am.open(childAsset).use { input -> out.outputStream().use { input.copyTo(it) } }
                } catch (ignored: IOException) {
                    out.mkdirs()
                }
            }
        }
    }

    /**
     * r19：把 assets/extra-models.json 释放到 ofm-data/（standalone 的数据目录）。
     *
     * 放 ofm-data 而不是 nodeHome，是为了让「应用内更新上游源码」的原子替换
     * 冲不掉它。释放动作由独立标记记录：只在每个壳版本第一次启动时确保一次，
     * 之后用户直接编辑 ids 或删除文件都不会被恢复。
     *
     * 注意：r19 的补丁 ID 已内联进 bootstrap.cjs，本文件【不存在也不影响补丁
     * 生效】（会自动用内置默认），这里释放只是为了让用户能查看 / 覆盖 / 关闭。
     */
    private fun ensureExtraModelsConfig(ctx: Context) {
        runCatching {
            val dir = GatewayConfig.dataDir(ctx)
            val dest = File(dir, "extra-models.json")
            val seeded = File(dir, "$EXTRA_SEEDED-$SHELL_VERSION")
            if (!seeded.isFile) {
                if (!dest.isFile) writeExtraModelsConfig(ctx, dest)
                seeded.writeText(SHELL_VERSION)
            }
        }
    }

    /** 供「恢复 APK 内置源码」调用：强制把补丁配置覆盖回初始内容。 */
    fun restoreExtraModelsConfig(ctx: Context) {
        runCatching {
            writeExtraModelsConfig(ctx, File(GatewayConfig.dataDir(ctx), "extra-models.json"))
        }
    }

    private fun writeExtraModelsConfig(ctx: Context, dest: File) {
        ctx.assets.open("extra-models.json").use { input ->
            val tmp = File(dest.parentFile, "extra-models.json.tmp")
            tmp.outputStream().use { input.copyTo(it) }
            if (!tmp.renameTo(dest)) tmp.copyTo(dest, overwrite = true)
        }
    }

    /** 把 assets/node/icudtl.dat 补拷到 nodeHome；文件不存在时静默跳过。 */
    private fun ensureIcuData(ctx: Context, target: File) {
        runCatching {
            if (!target.exists()) target.mkdirs()
            ctx.assets.open("node/icudtl.dat").use { input ->
                val dest = File(target, "icudtl.dat")
                val tmp = File(target, "icudtl.dat.tmp")
                tmp.outputStream().use { input.copyTo(it) }
                if (dest.isFile && dest.length() == tmp.length()) {
                    tmp.delete()
                } else {
                    tmp.renameTo(dest)
                }
            }
        }
    }

    fun assetVersion(ctx: Context): String =
        readAsset(ctx, "node/bundle-version.txt")?.trim().orEmpty().ifEmpty { "dev" }

    fun localUpdateFlag(ctx: Context): File = File(GatewayConfig.nodeHome(ctx), LOCAL_UPDATE_FLAG)

    private fun readAsset(ctx: Context, path: String): String? = try {
        ctx.assets.open(path).bufferedReader().use { it.readText() }
    } catch (e: IOException) {
        null
    }
}
