package com.android.dsh.core

import android.content.Context
import java.io.File
import java.io.IOException

/**
 * 把 assets/node 里的上游源码释放到 filesDir/gateway/node（r11：散放形态）。
 *
 * 与 r5 的区别：CI 不再生成 bundle.zip，源码以几百个散文件直接放进
 * assets/node，这里改用递归复制；源码体积从 85 MB 降到约 10 MB。
 * r5 踩过的「managed storage 符号链接闸门」由 prepare-node-bundle.sh
 * 在打包侧一次性消除（tar -h + 删 .bin + 零链接校验）。
 *
 * Node 路线特有：assets/node/icudtl.dat 若存在（small-icu 构建，
 * KEEP_EXTERNAL_ICU=1 时由 fetch-libnode.sh 放入），要补拷进 nodeHome，
 * 让 C 胶水的 NODE_ICU_DATA 指得到。v22.23.2 默认内嵌 full-icu，
 * 该文件通常不存在，静默跳过即可。
 *
 * 应用内更新优先：SourceUpdater 从 GitHub 拉源码覆盖 nodeHome 后写
 * `.ofm-local-update`（内容 = 当时 APK 内的 bundle-version.txt）。
 * 只要 APK 没换，就保留本地更新；一旦 APK 换了（incoming 变化），
 * 标记失效并重建，保证新 bootstrap.cjs 一定生效。
 */
object AssetInstaller {

    private const val LOCAL_UPDATE_FLAG = ".ofm-local-update"

    fun installIfNeeded(ctx: Context): File {
        val target = GatewayConfig.nodeHome(ctx)

        val incoming = readAsset(ctx, "node/bundle-version.txt")?.trim().orEmpty().ifEmpty { "dev" }
        val current = File(target, "bundle-version.txt").takeIf { it.isFile }?.readText()?.trim().orEmpty()

        val complete = File(target, "bootstrap.cjs").isFile &&
            File(target, "package.json").isFile &&
            File(target, "packages/standalone/cli.mjs").isFile

        // 本地应用内更新：APK 未变就保留用户下载的源码，不重复复制几百个文件
        val flag = File(target, LOCAL_UPDATE_FLAG)
        val flagBase = flag.takeIf { it.isFile }?.readText()?.trim().orEmpty()
        if (flagBase.isNotBlank() && flagBase == incoming && complete) return target
        if (current == incoming && complete) return target

        // 只重建代码目录；数据目录 GatewayConfig.dataDir 在别处，不会被删
        if (target.exists()) target.deleteRecursively()
        target.mkdirs()

        // r11：源码散放，不再解压 bundle.zip
        copyAssetDir(ctx, "node", target)

        // 必须在重建之后再补拷：r5 把这一步放在提前返回之前，若恰逢
        // 目录重建，target.deleteRecursively() 会把刚拷进去的 icudtl.dat 删掉。
        ensureIcuData(ctx, target)

        if (!File(target, "bootstrap.cjs").isFile ||
            !File(target, "package.json").isFile ||
            !File(target, "packages/standalone/cli.mjs").isFile
        ) {
            throw IOException("assets/node 源码不完整，请先执行 scripts/prepare-node-bundle.sh")
        }
        return target
    }

    /** 递归复制 assets 目录（约 150–500 个散文件）。 */
    private fun copyAssetDir(ctx: Context, assetPath: String, outDir: File) {
        val am = ctx.assets
        val names = am.list(assetPath).orEmpty()
        for (name in names) {
            if (name.startsWith(".") || name == "__MACOSX") continue
            val childAsset = "$assetPath/$name"
            val out = File(outDir, name)
            val children = am.list(childAsset).orEmpty()
            if (children.isNotEmpty()) {
                out.mkdirs()
                copyAssetDir(ctx, childAsset, out)
            } else {
                out.parentFile?.mkdirs()
                // 空目录与单文件在 AssetManager 里都可能返回空列表，用 open 探测兜底
                try {
                    am.open(childAsset).use { input -> out.outputStream().use { input.copyTo(it) } }
                } catch (ignored: IOException) {
                    out.mkdirs()
                }
            }
        }
    }

    /** 把 assets/node/icudtl.dat 补拷到 nodeHome；文件不存在时静默跳过。 */
    private fun ensureIcuData(ctx: Context, target: File) {
        runCatching {
            if (!target.exists()) target.mkdirs()
            ctx.assets.open("node/icudtl.dat").use { input ->
                val dest = File(target, "icudtl.dat")
                val tmp = File(target, "icudtl.dat.tmp")
                tmp.outputStream().use { input.copyTo(it) }
                if (dest.isFile && dest.length() == tmp.length()) {
                    tmp.delete()
                } else {
                    tmp.renameTo(dest)
                }
            }
        }
    }

    fun assetVersion(ctx: Context): String =
        readAsset(ctx, "node/bundle-version.txt")?.trim().orEmpty().ifEmpty { "dev" }

    fun localUpdateFlag(ctx: Context): File = File(GatewayConfig.nodeHome(ctx), LOCAL_UPDATE_FLAG)

    private fun readAsset(ctx: Context, path: String): String? = try {
        ctx.assets.open(path).bufferedReader().use { it.readText() }
    } catch (e: IOException) {
        null
    }
}
