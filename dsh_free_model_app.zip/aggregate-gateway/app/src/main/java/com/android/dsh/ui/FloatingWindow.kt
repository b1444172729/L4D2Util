package com.android.dsh.ui

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.content.res.AppCompatResources
import androidx.core.content.ContextCompat
import com.android.dsh.GatewayApp
import com.android.dsh.R
import com.android.dsh.core.GatewayService
import com.android.dsh.util.RikkaHubHandoff

/**
 * 悬浮球：提升存活能力的「可见层」。
 *
 * 原理不是悬浮窗本身能保活，而是：
 *  1) 一个用户看得见、可拖动的浮层，会降低部分厂商 ROM 对后台进程的激进回收；
 *  2) 配合前台服务通知 + PARTIAL_WAKE_LOCK + 电池优化白名单，形成三重约束；
 *  3) 浮层常驻让用户能一眼看出网关是否还活着，并快速复制配置。
 *
 * 图标与 APP 桌面图标引用同一个 drawable：R.drawable.ic_gateway_vector。
 */
class FloatingWindow(private val ctx: Context) {

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var ball: View? = null
    private var panel: View? = null
    private var ballLp: WindowManager.LayoutParams? = null

    private fun dp(v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()

    fun canShow(): Boolean = Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(ctx)

    @SuppressLint("ClickableViewAccessibility", "InflateParams")
    fun show() {
        if (ball != null || !canShow()) return

        // ★ 与 APP 自适应图标的 <foreground> 完全同一个资源
        val icon = ImageView(ctx).apply {
            setImageResource(R.drawable.ic_gateway_vector)
            background = AppCompatResources.getDrawable(ctx, R.drawable.ic_gateway_badge)
            contentDescription = ctx.getString(R.string.floating_desc)
            // vector 内部已用 <group scale=0.8> 留白，这里只留极小边距，
            // 让渐变圆角底完整露出，与桌面图标观感一致
            val p = dp(2)
            setPadding(p, p, p, p)
            alpha = 1.0f
        }

        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        val lp = WindowManager.LayoutParams(
            dp(BALL_SIZE), dp(BALL_SIZE), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(16)
            y = dp(160)
        }
        ballLp = lp

        var initX = 0
        var initY = 0
        var initTouchX = 0f
        var initTouchY = 0f
        var moved = false

        icon.setOnTouchListener { v, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    initX = lp.x; initY = lp.y
                    initTouchX = ev.rawX; initTouchY = ev.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (ev.rawX - initTouchX).toInt()
                    val dy = (ev.rawY - initTouchY).toInt()
                    if (kotlin.math.abs(dx) > dp(6) || kotlin.math.abs(dy) > dp(6)) moved = true
                    lp.x = initX + dx
                    lp.y = initY + dy
                    runCatching { wm.updateViewLayout(v, lp) }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) togglePanel()
                    true
                }
                else -> false
            }
        }

        runCatching { wm.addView(icon, lp) }
        ball = icon
    }

    @SuppressLint("InflateParams", "SetTextI18n")
    private fun togglePanel() {
        if (panel != null) {
            hidePanel()
            return
        }
        val s = GatewayApp.instance.status.value
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = ContextCompat.getDrawable(ctx, R.drawable.bg_panel)
        }

        root.addView(TextView(ctx).apply {
            text = "聚合网关 · ${if (s.state == GatewayApp.State.READY) "运行中" else s.state.name}"
            setTextColor(ContextCompat.getColor(ctx, R.color.gateway_text))
            textSize = 16f
        })
        root.addView(TextView(ctx).apply {
            text = if (s.port > 0) RikkaHubHandoff.baseUrl(s.port) else "服务未就绪"
            setTextColor(ContextCompat.getColor(ctx, R.color.gateway_text_secondary))
            textSize = 12f
            setPadding(0, dp(6), 0, dp(10))
        })

        fun action(label: String, block: () -> Unit) {
            root.addView(Button(ctx).apply {
                text = label
                isAllCaps = false
                setOnClickListener {
                    block()
                    hidePanel()
                }
            })
        }

        action(ctx.getString(R.string.action_copy_baseurl)) {
            if (s.port > 0) RikkaHubHandoff.copy(ctx, "Base URL", RikkaHubHandoff.baseUrl(s.port))
        }
        action(ctx.getString(R.string.action_copy_key)) {
            if (s.apiKey.isNotBlank()) RikkaHubHandoff.copy(ctx, "API Key", s.apiKey)
        }
        action(ctx.getString(R.string.action_manage)) {
            ctx.startActivity(
                Intent(ctx, ManageActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
        action(ctx.getString(R.string.action_restart_node)) {
            GatewayService.stop(ctx)
            ctx.startForegroundService(
                Intent(ctx, GatewayService::class.java).setAction(GatewayService.ACTION_START)
            )
        }
        action("隐藏悬浮球") {
            hide()
            Toast.makeText(ctx, "前台服务仍在运行，可在通知栏恢复", Toast.LENGTH_SHORT).show()
        }

        val lp = WindowManager.LayoutParams(
            dp(260), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (ballLp?.x ?: dp(16))
            y = (ballLp?.y ?: dp(160)) + dp(BALL_SIZE + 8)
        }
        runCatching { wm.addView(root, lp) }
        panel = root
    }

    private fun hidePanel() {
        panel?.let { runCatching { wm.removeViewImmediate(it) } }
        panel = null
    }

    fun hide() {
        hidePanel()
        ball?.let { runCatching { wm.removeViewImmediate(it) } }
        ball = null
        ballLp = null
    }

    private companion object {
        const val BALL_SIZE = 48
    }
}
