package com.android.dsh.core;

/**
 * 自建 Java ↔ Node 桥接层。
 *
 * 原先工程用反射去调 com.janeasystems.rn_nodejs_mobile.NodeJS，
 * 但那个类属于 React Native 插件，官方没有发布可独立使用的 aar，
 * 所以 APK 里永远找不到它 —— 界面上那串类名就是这么来的。
 *
 * 现在改成自己的类 + 自己编的 libdsh-node.so（见 app/src/main/cpp）。
 * 用懒加载而不是静态块，缺 .so 时返回可诊断的字符串，不会抛
 * ExceptionInInitializerError 让整个界面崩掉。
 */
public final class NodeBridge {

    private static volatile boolean loaded = false;
    private static volatile boolean nodeLoaded = false;
    private static String loadError = null;

    private NodeBridge() {}

    private static synchronized boolean load() {
        if (loaded) return true;
        try {
            System.loadLibrary("dsh-node");
            loaded = true;
        } catch (Throwable t) {
            loadError = t.toString();
        }
        return loaded;
    }

    /**
     * 确保 libnode.so 已由 Android linker 在 app 的 classloader namespace 加载。
     *
     * 首选形态其实是 CMake 的 DT_NEEDED：libdsh-node.so 链接了 libnode.so，
     * 加载本库时 linker 会自动把它带进来。这里再显式 load 一次是兜底 ——
     * Android linker 按 (dev, ino) 去重，同一个文件不会加载两遍，因此
     * 不会制造出「第二份 libnode.so」。
     *
     * 之前只在 C 层 dlopen(绝对路径)：dlsym 能解析到 node::Start（界面符号
     * 探测一直是 OK），但库落在 dlopen 的 namespace，V8 初始化阶段会静默
     * 退出且不留下任何输出。改为 linker 加载后，C++ 静态初始化与内部符号
     * 解析都在同一 namespace 里完成。
     *
     * 失败不抛异常：旧设备若因 16KB 页对齐等原因加载不了，仍回退到 C 层
     * 的 dlopen 路径，界面会如实标注「回退 dlopen 绝对路径」。
     */
    public static synchronized String loadNodeRuntime() {
        if (nodeLoaded) return "已加载";
        try {
            System.loadLibrary("node");
            nodeLoaded = true;
            return "libnode.so 已由 Android linker 加载（System.loadLibrary / DT_NEEDED）";
        } catch (Throwable t) {
            return "System.loadLibrary(node) 失败（将回退 dlopen）：" + t;
        }
    }

    public static boolean isAvailable() {
        return load();
    }

    public static String loadError() {
        load();
        return loadError;
    }

    /** 在界面自检区显示：能否 dlopen libnode.so、能否找到 node::Start 符号。 */
    public static String probe(String libnodePath) {
        if (!load()) return "libdsh-node.so 未加载：" + loadError;
        try {
            return nativeProbe(libnodePath == null ? "" : libnodePath);
        } catch (Throwable t) {
            return "probe 失败：" + t;
        }
    }

    /**
     * 阻塞调用，直到 Node 主循环退出。必须在独立线程上执行。
     * 一个进程只能调用一次，重复调用会触发 V8 assert。
     *
     * args 只保留 ["node", bootstrap.js]：所有端口/目录/主机配置改由 C 层
     * setenv 传给 JS，彻底避开 nodejs-mobile 对 "--port" 这类自定义选项的
     * 解析差异（bad option → exit(9) 是常见的静默退出原因）。
     */
    public static int start(String[] args, String libnodePath, String workDir,
                            String dataDir, String cacheDir, int port,
                            String host, boolean lanRelay, String logPath) {
        if (!load()) throw new UnsatisfiedLinkError("libdsh-node.so 未加载：" + loadError);
        return nativeStart(
            args,
            libnodePath == null ? "" : libnodePath,
            workDir == null ? "" : workDir,
            dataDir == null ? "" : dataDir,
            cacheDir == null ? "" : cacheDir,
            port,
            host == null ? "" : host,
            lanRelay,
            logPath == null ? "" : logPath
        );
    }

    private static native int nativeStart(String[] args, String libnodePath, String workDir,
                                          String dataDir, String cacheDir, int port,
                                          String host, boolean lanRelay, String logPath);

    private static native String nativeProbe(String libnodePath);
}
