package com.android.dsh.core;

/**
 * 自建 Java ↔ Node 桥接层。
 *
 * 原先工程用反射去调 com.janeasystems.rn_nodejs_mobile.NodeJS，
 * 但那个类属于 React Native 插件，官方没有发布可独立使用的 aar，
 * 所以 APK 里永远找不到它 —— 界面上那串类名就是这么来的。
 *
 * 现在改成自己的类 + 自己编的 libdsh-node.so（见 app/src/main/cpp）。
 * 用懒加载而不是静态块，缺 .so 时返回可诊断的字符串，不会抛
 * ExceptionInInitializerError 让整个界面崩掉。
 */
public final class NodeBridge {

    private static volatile boolean loaded = false;
    private static String loadError = null;

    private NodeBridge() {}

    private static synchronized boolean load() {
        if (loaded) return true;
        try {
            System.loadLibrary("dsh-node");
            loaded = true;
        } catch (Throwable t) {
            loadError = t.toString();
        }
        return loaded;
    }

    public static boolean isAvailable() {
        return load();
    }

    public static String loadError() {
        load();
        return loadError;
    }

    /** 在界面自检区显示：能否 dlopen libnode.so、能否找到 node::Start 符号。 */
    public static String probe(String libnodePath) {
        if (!load()) return "libdsh-node.so 未加载：" + loadError;
        try {
            return nativeProbe(libnodePath == null ? "" : libnodePath);
        } catch (Throwable t) {
            return "probe 失败：" + t;
        }
    }

    /**
     * 阻塞调用，直到 Node 主循环退出。必须在独立线程上执行。
     * 一个进程只能调用一次，重复调用会触发 V8 assert。
     */
    public static int start(String[] args, String libnodePath, String workDir) {
        if (!load()) throw new UnsatisfiedLinkError("libdsh-node.so 未加载：" + loadError);
        return nativeStart(args, libnodePath == null ? "" : libnodePath, workDir == null ? "" : workDir);
    }

    private static native int nativeStart(String[] args, String libnodePath, String workDir);

    private static native String nativeProbe(String libnodePath);
}
