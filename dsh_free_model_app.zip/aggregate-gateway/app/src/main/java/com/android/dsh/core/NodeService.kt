package com.android.dsh.core

import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.util.Log

/**
 * Node 引擎的独立宿主进程（Manifest 里 android:process=":node"）。
 *
 * 【为什么必须独立进程】
 * libnode.so 是 C++ 库，V8 / Node 遇到致命错误会直接 abort()，
 * 用户主动退出时也会调用 exit()。此前把它放在 UI 主进程里，
 * 于是「正在启动…」几秒后整个 App 被一起带走 —— 就是用户看到的闪退。
 * 独立进程后，Node 崩了只死 :node，主界面的前台服务、悬浮窗、状态卡
 * 全都活着，还能把 node-output.log 里的遗言显示出来。
 *
 * HTTP 服务仍在 127.0.0.1 上：两个进程同一 UID、同一网络命名空间，
 * 主进程的 HealthProbe 与 RikkaHub 都能照常访问回环端口。
 *
 * 注意：node::Start 的实际执行线程由 C 胶水用 pthread_attr_setstacksize
 * 显式开成 8MB 栈（Android 默认线程栈约 1MB，V8 初始化会 SIGSEGV）。
 * 这里的两层 Kotlin Thread 只负责「不要在 UI / Service 主线程上阻塞」。
 *
 * 跨进程不走 Binder/AIDL，只共享 filesDir 下的几个文件：
 *   node-pid.txt           本进程 pid（主进程据此探活 / 停止）
 *   gateway-runtime.json   端口 / Key / 管理链接
 *   node-output.log        stdout + stderr 原始输出
 *   node-fatal.txt         启动失败的短标记
 */
class NodeService : Service() {

    companion object {
        private const val TAG = "NodeService"
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // 先落 pid：主进程的 HealthProbe 每轮读它检查 /proc/<pid> 是否还在
        runCatching {
            GatewayConfig.nodePidFile(this).writeText(android.os.Process.myPid().toString())
        }

        // node::Start 是阻塞调用，绝不能占 Service 的主线程
        Thread({
            val ctx = this@NodeService
            val nodeHome = GatewayConfig.nodeHome(ctx)
            val port = GatewayConfig.requestedPort(ctx)
            val dataDir = GatewayConfig.dataDir(ctx)
            val lan = GatewayConfig.lanRelayEnabled(ctx)

            val result = NodeRuntime.start(
                ctx,
                NodeRuntime.Launch(nodeHome, port, dataDir, lan)
            )
            if (result.isFailure) {
                val t = result.exceptionOrNull()
                val msg = "[dsh-node] NodeRuntime.start 失败：" +
                    "${t?.javaClass?.simpleName}: ${t?.message}\n"
                Log.e(TAG, msg)
                runCatching { GatewayConfig.nodeOutputLog(ctx).appendText(msg) }
                runCatching { GatewayConfig.nodeFatalFile(ctx).writeText(msg.trim()) }
            }
        }, "dsh-node-launcher").apply { isDaemon = false }.start()

        // 重启由主进程的 GatewayService 统一控制，这里不让系统自动拉起
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        runCatching { GatewayConfig.nodePidFile(this).delete() }
        super.onDestroy()
    }
}
