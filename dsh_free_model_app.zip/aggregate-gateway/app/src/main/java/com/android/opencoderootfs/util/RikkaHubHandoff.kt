package com.android.opencoderootfs.util

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import com.android.opencoderootfs.core.GatewayConfig
import com.android.opencoderootfs.core.HealthProbe
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * 与 RikkaHub 的对接层：它只认「一个 OpenAI 兼容的 HTTP 端点」。
 * 所以这里不实现任何聊天能力，只负责把 Base URL / Key / 模型 ID 交到用户手上。
 */
object RikkaHubHandoff {

    fun baseUrl(port: Int): String = "http://${GatewayConfig.LOOPBACK}:$port/v1"

    fun copy(ctx: Context, label: String, text: String) {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText(label, text))
        Toast.makeText(ctx, "已复制 $label", Toast.LENGTH_SHORT).show()
    }

    /** 配置文本二维码：内容是纯文本，不是 RikkaHub 私有导入协议，见 README */
    fun configText(port: Int, key: String): String = buildString {
        appendLine("OC网关 / RikkaHub 配置")
        appendLine("Provider Type: OpenAI")
        appendLine("Base URL: ${baseUrl(port)}")
        appendLine("API Key: $key")
        appendLine("注意：在提供商详情里手动「添加模型」，Base URL 必须带 /v1 且不要重复写路径")
    }

    suspend fun modelIds(port: Int, key: String): List<String> = withContext(Dispatchers.IO) {
        HealthProbe.fetchModelIds(port, key)
    }
}
