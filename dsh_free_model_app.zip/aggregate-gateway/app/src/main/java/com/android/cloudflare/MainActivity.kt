package com.android.cloudflare

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.android.cloudflare.core.GatewayConfig
import com.android.cloudflare.core.GatewayService
import com.android.cloudflare.core.RuntimeDiagnostics
import com.android.cloudflare.core.SourceUpdater
import com.android.cloudflare.ui.FloatingWindow
import com.android.cloudflare.ui.ManageActivity
import com.android.cloudflare.ui.UiTheme as U
import com.android.cloudflare.util.QrCodeUtil
import com.android.cloudflare.util.RikkaHubHandoff
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 主页（r17 现代化改版）。
 *
 * 布局原则：
 *   · 首屏只留「状态 + 主操作 + 快速连接 + 管理页入口」，一眼能用；
 *   · 「设置」收进右上角按钮，展开后是权限/维护/源码/帮助等低频操作；
 *   · 「运行时自检」与「运行日志」各自收进折叠按钮下方，不再把大段
 *     诊断文本平铺在状态卡里（用户明确要求）；
 *   · 所有按钮的业务回调与 r16 逐字保持一致，只调整它们的位置与外观。
 *
 * 视觉全部由 UiTheme 用代码绘制，不引入 layout XML，也不改悬浮窗/管理页/通知资源。
 */
class MainActivity : AppCompatActivity() {

    private lateinit var stateText: TextView
    private lateinit var stateDot: ImageView
    private lateinit var statePill: TextView
    private lateinit var detailText: TextView
    private lateinit var keyText: TextView
    private lateinit var keyToggle: TextView
    private lateinit var diagText: TextView
    private lateinit var logText: TextView
    private lateinit var updateText: TextView
    private lateinit var qrImage: ImageView

    // 必须是 ViewGroup 子类型：下面会对 diagPanel / logPanel 调用 addView()，
    // 声明成 View 会报 Unresolved reference 'addView'。
    private lateinit var settingsPanel: LinearLayout
    private lateinit var diagPanel: LinearLayout
    private lateinit var logPanel: LinearLayout
    private lateinit var settingsButton: TextView
    private lateinit var diagChevron: ImageView
    private lateinit var logChevron: ImageView
    private lateinit var diagBadge: TextView
    private lateinit var logBadge: TextView

    private var keyVisible = false
    private var updating = false
    private var lastStatus = GatewayApp.Status()

    private var settingsExpanded = false
    private var diagExpanded = false
    private var logExpanded = false

    // 自检里的 probe() 会 dlopen 一个上百 MB 的 libnode.so，
    // 必须放后台做，绝不能每次 render() 都在主线程加载。
    @Volatile
    private var cachedDiag: RuntimeDiagnostics.Report? = null
    @Volatile
    private var cachedLogTail: String = ""
    private var diagRefreshing = false
    private var lastRenderedState: GatewayApp.State? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
        requestNotificationPermissionIfNeeded()
        requestStoragePermissionIfNeeded()
        render(lastStatus)
        refreshDiag()
        updateText.text = if (SourceUpdater.hasLocalUpdate(this)) {
            "当前源码：${SourceUpdater.currentVersion(this)}（GitHub 应用内更新）"
        } else {
            "当前源码：APK 内置 · ${SourceUpdater.currentVersion(this)}"
        }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                GatewayApp.instance.status.collect { render(it) }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // 用户从后台回来时刷新：启动网关会释放代码目录，
        // 不刷新就会一直显示旧的「❌ 已释放代码目录 缺失」误报。
        refreshDiag()
    }

    private fun refreshDiag() {
        if (diagRefreshing) return
        diagRefreshing = true
        lifecycleScope.launch(Dispatchers.IO) {
            val d = runCatching { RuntimeDiagnostics.check(this@MainActivity) }.getOrNull()
            val log = runCatching { readLogTail() }.getOrDefault("")
            cachedDiag = d
            cachedLogTail = log
            withContext(Dispatchers.Main) {
                diagRefreshing = false
                render(lastStatus)
            }
        }
    }

    /** 只读日志尾部，避免累积后拖慢界面；让用户不用 adb 就能反馈真实错误。 */
    private fun readLogTail(): String = buildString {
        // ★ bootstrap.log 独立、不被 C 层 watchdog 心跳刷屏，是排查
        // standalone「加载了却没 listen」的第一手证据，必须排最前面。
        val boot = tailOf(GatewayConfig.bootstrapLogFile(this@MainActivity), 24)
        if (boot.isNotBlank()) {
            appendLine("── bootstrap.log（JS 层诊断）──")
            appendLine(boot)
        }
        // node-output.log 是 stdout+stderr 原始输出，V8 abort / bad option /
        // 模块加载失败都在这里
        val out = tailOf(GatewayConfig.nodeOutputLog(this@MainActivity), 16)
        if (out.isNotBlank()) {
            appendLine("── node-output.log（Node 原始输出）──")
            appendLine(out)
        }
        val err = tailOf(GatewayConfig.nodeErrorLog(this@MainActivity), 6)
        if (err.isNotBlank()) {
            appendLine("── node-errors.log ──")
            append(err)
        }
    }.trim()

    private fun tailOf(f: java.io.File, maxLines: Int): String {
        if (!f.isFile || f.length() == 0L) return ""
        val tail = ArrayDeque<String>(maxLines + 1)
        f.useLines { seq ->
            seq.forEach { line ->
                if (tail.size >= maxLines) tail.removeFirst()
                tail.addLast(line)
            }
        }
        return tail.joinToString("\n")
    }

    // ──────────────────────────────────────────────────────────────
    // 界面构建
    // ──────────────────────────────────────────────────────────────

    private fun buildUi(): View {
        fun d(v: Int) = U.dp(this@MainActivity, v)

        /** 统一按钮工厂；业务回调原样传入，只换外观。 */
        fun b(
            label: String,
            onClick: () -> Unit,
            primary: Boolean = false,
            height: Int = 46
        ): TextView = U.button(
            this@MainActivity,
            label,
            if (primary) U.primary(this@MainActivity) else U.ghost(this@MainActivity),
            U.TEXT,
            if (primary) 15f else 13f,
            height
        ).apply {
            setOnClickListener { onClick() }
            if (primary) elevation = U.dpF(this@MainActivity, 6f)
        }

        /** 等宽横排按钮行。 */
        fun addRow(
            parent: LinearLayout,
            vararg views: View,
            top: Int = 0,
            h: Int = 46,
            gap: Int = 10
        ) {
            val row = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
            }
            views.forEachIndexed { i, v ->
                row.addView(v, LinearLayout.LayoutParams(0, d(h), 1f).apply {
                    if (i > 0) marginStart = d(gap)
                })
            }
            parent.addView(row, LinearLayout.LayoutParams(-1, -2).apply {
                topMargin = d(top)
            })
        }

        fun addSection(parent: LinearLayout, label: String) {
            parent.addView(U.section(this@MainActivity, label),
                LinearLayout.LayoutParams(-1, -2).apply { topMargin = d(22) })
        }

        fun addNote(parent: LinearLayout, text: String) {
            parent.addView(U.note(this@MainActivity, text),
                LinearLayout.LayoutParams(-1, -2).apply { topMargin = d(6) })
        }

        /** 折叠标题行：标题 + 状态胶囊 + 箭头，整行可点。 */
        fun foldRow(label: String, badge: TextView, chevron: View, onClick: () -> Unit) =
            LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(d(16), d(15), d(16), d(15))
                addView(TextView(this@MainActivity).apply {
                    text = label
                    textSize = 14.5f
                    setTextColor(U.TEXT)
                    typeface = Typeface.DEFAULT_BOLD
                }, LinearLayout.LayoutParams(0, -2, 1f))
                addView(badge, LinearLayout.LayoutParams(-2, -2).apply {
                    marginEnd = d(10)
                })
                addView(chevron, LinearLayout.LayoutParams(d(12), d(7)))
                setOnClickListener { onClick() }
            }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(d(20), d(22), d(20), d(30))
        }

        // ── 顶栏：图标 + 标题 + 设置按钮 ──────────────────────────
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        topBar.addView(ImageView(this).apply {
            setImageDrawable(ContextCompat.getDrawable(this@MainActivity, R.drawable.ic_gateway_vector))
        }, LinearLayout.LayoutParams(d(44), d(44)))

        topBar.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(this@MainActivity).apply {
                text = getString(R.string.app_name)
                textSize = 19f
                setTextColor(U.TEXT)
                typeface = Typeface.DEFAULT_BOLD
            })
            addView(TextView(this@MainActivity).apply {
                text = getString(R.string.ui_subtitle)
                textSize = 11.5f
                setTextColor(U.TEXT_SUB)
                setPadding(0, d(2), 0, 0)
            })
        }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = d(12) })

        settingsButton = U.chip(
            this, getString(R.string.ui_settings),
            Color.parseColor("#243257"), U.ACCENT
        ).apply {
            setOnClickListener {
                settingsExpanded = !settingsExpanded
                applyToggles()
            }
        }
        topBar.addView(settingsButton)
        root.addView(topBar, LinearLayout.LayoutParams(-1, -2))

        // ── 设置面板（点右上角展开）──────────────────────────────
        settingsPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = U.card(this@MainActivity, 20f)
            setPadding(d(16), d(16), d(16), d(16))
            visibility = View.GONE
        }.also { panel ->
            panel.addView(TextView(this).apply {
                text = getString(R.string.ui_section_permissions)
                textSize = 11f
                setTextColor(U.TEXT_DIM)
                typeface = Typeface.DEFAULT_BOLD
                letterSpacing = 0.1f
            })
            addRow(panel,
                b(getString(R.string.ui_floating_short), {
                    startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")
                        )
                    )
                }, height = 44),
                b(getString(R.string.ui_battery_short), {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        runCatching {
                            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                                data = Uri.parse("package:$packageName")
                            })
                        }
                    }
                }, height = 44), top = 10)

            panel.addView(TextView(this).apply {
                text = getString(R.string.ui_section_maintenance)
                textSize = 11f
                setTextColor(U.TEXT_DIM)
                typeface = Typeface.DEFAULT_BOLD
                letterSpacing = 0.1f
            }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = d(18) })
            panel.addView(b(getString(R.string.ui_smoke), {
                // 冒烟测试只验证 V8 能否执行 JS，不加载 standalone / 不占端口。
                GatewayService.stop(this)
                GatewayService.smoke(this)
            }, height = 44), LinearLayout.LayoutParams(-1, d(44)).apply {
                topMargin = d(10)
            })

            panel.addView(TextView(this).apply {
                text = getString(R.string.ui_section_source)
                textSize = 11f
                setTextColor(U.TEXT_DIM)
                typeface = Typeface.DEFAULT_BOLD
                letterSpacing = 0.1f
            }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = d(18) })
            updateText = TextView(this).apply {
                textSize = 11.5f
                setTextColor(U.TEXT_SUB)
                setPadding(0, d(8), 0, d(4))
            }
            panel.addView(updateText)

            addRow(panel,
                b(getString(R.string.ui_update), {
                    if (updating) {
                        Toast.makeText(this, "正在更新中，请稍候", Toast.LENGTH_SHORT).show()
                    } else {
                        updating = true
                        // 先把网关停掉，避免替换源码目录时 Node 仍占用文件
                        GatewayService.stop(this)
                        updateText.text = "正在准备更新…"
                        lifecycleScope.launch {
                            delay(1200)
                            val result = withContext(Dispatchers.IO) {
                                runCatching {
                                    SourceUpdater.update(this@MainActivity) { msg ->
                                        runOnUiThread { updateText.text = msg }
                                    }
                                }
                            }
                            updating = false
                            result.fold(
                                onSuccess = { res ->
                                    updateText.text = res.description()
                                    Toast.makeText(
                                        this@MainActivity,
                                        "更新成功，点「启动网关」后生效",
                                        Toast.LENGTH_LONG
                                    ).show()
                                    refreshDiag()
                                },
                                onFailure = { e ->
                                    updateText.text = "更新失败：${e.message}\n现有源码未被改动，可继续使用。"
                                    Toast.makeText(
                                        this@MainActivity,
                                        "更新失败：${e.message}",
                                        Toast.LENGTH_LONG
                                    ).show()
                                }
                            )
                        }
                    }
                }, height = 44),
                b(getString(R.string.ui_restore), {
                    val had = SourceUpdater.restoreBuiltin(this)
                    updateText.text = if (had) {
                        "已清除本地更新标记，下次启动网关会恢复 APK 内置源码。"
                    } else {
                        "当前没有本地更新，无需恢复。"
                    }
                    Toast.makeText(this, updateText.text, Toast.LENGTH_SHORT).show()
                }, height = 44), top = 8)
            addNote(panel, getString(R.string.hint_update_source))

            panel.addView(TextView(this).apply {
                text = getString(R.string.ui_section_help)
                textSize = 11f
                setTextColor(U.TEXT_DIM)
                typeface = Typeface.DEFAULT_BOLD
                letterSpacing = 0.1f
            }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = d(18) })
            addNote(panel, getString(R.string.hint_qr))
            addNote(panel, getString(R.string.hint_key))
            addNote(panel, getString(R.string.hint_cleartext))
            addNote(panel, "包名 com.android.cloudflare；数据目录 ofm-data 不参与备份。")
        }
        root.addView(settingsPanel, LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = d(14)
        })

        // ── 主状态卡 ─────────────────────────────────────────────
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = U.hero(this@MainActivity)
            setPadding(d(18), d(18), d(18), d(18))
            elevation = U.dpF(this@MainActivity, 3f)
        }

        val statusRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        stateDot = ImageView(this).apply {
            setImageDrawable(U.dot(U.IDLE, d(10)))
        }
        statusRow.addView(stateDot, LinearLayout.LayoutParams(d(10), d(10)))
        stateText = TextView(this).apply {
            textSize = 20f
            setTextColor(U.TEXT)
            typeface = Typeface.DEFAULT_BOLD
        }
        statusRow.addView(stateText, LinearLayout.LayoutParams(0, -2, 1f).apply {
            marginStart = d(10)
        })
        statePill = U.chip(this, getString(R.string.state_stopped),
            Color.parseColor("#2A8A97B8"), U.IDLE)
        statusRow.addView(statePill)
        hero.addView(statusRow)

        detailText = TextView(this).apply {
            textSize = 12.5f
            setTextColor(U.TEXT_SUB)
            setLineSpacing(U.dpF(this@MainActivity, 3f), 1f)
            setPadding(0, d(12), 0, 0)
        }
        hero.addView(detailText)

        hero.addView(U.divider(this), LinearLayout.LayoutParams(-1, d(1)).apply {
            topMargin = d(16)
            bottomMargin = d(14)
        })

        val keyRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        keyRow.addView(TextView(this).apply {
            text = getString(R.string.ui_key_label)
            textSize = 10f
            setTextColor(U.TEXT_DIM)
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.12f
        })
        keyText = TextView(this).apply {
            textSize = 13f
            setTextColor(U.TEXT)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        keyRow.addView(keyText, LinearLayout.LayoutParams(0, -2, 1f).apply {
            marginStart = d(10)
            marginEnd = d(8)
        })
        keyToggle = U.chip(this, getString(R.string.ui_show),
            Color.parseColor("#243257"), U.ACCENT).apply {
            setOnClickListener {
                keyVisible = !keyVisible
                render(lastStatus)
            }
        }
        keyRow.addView(keyToggle)
        keyRow.addView(U.chip(this, getString(R.string.ui_copy),
            Color.parseColor("#1C3A52"), U.ACCENT).apply {
            setOnClickListener {
                if (lastStatus.apiKey.isNotBlank())
                    RikkaHubHandoff.copy(this@MainActivity, "API Key", lastStatus.apiKey)
            }
        }, LinearLayout.LayoutParams(-2, -2).apply { marginStart = d(8) })
        hero.addView(keyRow)

        // 主操作：启动占大头，停止 / 重启各占一小格
        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        actions.addView(
            b(getString(R.string.action_start), {
                ensureOverlayAndBattery()
                GatewayService.start(this)
            }, primary = true, height = 52),
            LinearLayout.LayoutParams(0, d(52), 2.2f)
        )
        actions.addView(
            b(getString(R.string.ui_stop_short), { GatewayService.stop(this) }, height = 52),
            LinearLayout.LayoutParams(0, d(52), 1f).apply { marginStart = d(10) }
        )
        actions.addView(
            b(getString(R.string.ui_restart_short), {
                GatewayService.stop(this)
                GatewayService.start(this)
            }, height = 52),
            LinearLayout.LayoutParams(0, d(52), 1f).apply { marginStart = d(10) }
        )
        hero.addView(actions, LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = d(18)
        })

        root.addView(hero, LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = d(18)
        })

        // ── 快速连接 ─────────────────────────────────────────────
        addSection(root, getString(R.string.ui_section_connect))
        val connect = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = U.card(this@MainActivity, 20f)
            setPadding(d(16), d(16), d(16), d(16))
        }
        addRow(connect,
            b(getString(R.string.ui_copy_base), {
                if (lastStatus.port > 0)
                    RikkaHubHandoff.copy(this, "Base URL", RikkaHubHandoff.baseUrl(lastStatus.port))
                else Toast.makeText(this, "网关未就绪", Toast.LENGTH_SHORT).show()
            }, height = 44),
            b(getString(R.string.ui_copy_key), {
                if (lastStatus.apiKey.isNotBlank())
                    RikkaHubHandoff.copy(this, "API Key", lastStatus.apiKey)
            }, height = 44))
        addRow(connect,
            b(getString(R.string.ui_copy_models), {
                if (lastStatus.port <= 0 || lastStatus.apiKey.isBlank()) {
                    Toast.makeText(this, "网关未就绪", Toast.LENGTH_SHORT).show()
                } else {
                    lifecycleScope.launch {
                        val ids = RikkaHubHandoff.modelIds(lastStatus.port, lastStatus.apiKey)
                        if (ids.isEmpty()) Toast.makeText(this@MainActivity, "未取到模型清单，请稍后重试", Toast.LENGTH_LONG).show()
                        else RikkaHubHandoff.copy(this@MainActivity, "模型 ID", ids.joinToString("\n"))
                    }
                }
            }, height = 44),
            b(getString(R.string.ui_qr), {
                if (lastStatus.port > 0 && lastStatus.apiKey.isNotBlank()) {
                    qrImage.setImageBitmap(
                        QrCodeUtil.encode(RikkaHubHandoff.configText(lastStatus.port, lastStatus.apiKey))
                    )
                    qrImage.visibility = View.VISIBLE
                }
            }, height = 44), top = 10)

        qrImage = ImageView(this).apply {
            visibility = View.GONE
            background = U.card(this@MainActivity, 14f, Color.WHITE, Color.WHITE)
            setPadding(d(14), d(14), d(14), d(14))
        }
        connect.addView(qrImage, LinearLayout.LayoutParams(d(200), d(200)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            topMargin = d(16)
        })
        addNote(connect, getString(R.string.hint_rikkahub))
        root.addView(connect, LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = d(10)
        })

        // ── 工具 ─────────────────────────────────────────────────
        addSection(root, getString(R.string.ui_section_tools))
        val manage = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = U.card(this@MainActivity, 18f)
            setPadding(d(16), d(15), d(16), d(15))
            isClickable = true
            setOnClickListener { startActivity(Intent(this@MainActivity, ManageActivity::class.java)) }
        }
        manage.addView(View(this).apply {
            background = U.dot(U.ACCENT_2, d(9))
        }, LinearLayout.LayoutParams(d(9), d(9)))
        manage.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(this@MainActivity).apply {
                text = getString(R.string.ui_manage_short)
                textSize = 15f
                setTextColor(U.TEXT)
                typeface = Typeface.DEFAULT_BOLD
            })
            addView(TextView(this@MainActivity).apply {
                text = getString(R.string.ui_manage_sub)
                textSize = 11f
                setTextColor(U.TEXT_DIM)
                setPadding(0, d(2), 0, 0)
            })
        }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = d(12) })
        manage.addView(TextView(this).apply {
            text = "→"
            textSize = 20f
            setTextColor(U.ACCENT)
        })
        root.addView(manage, LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = d(10)
        })

        // ── 诊断：自检 / 日志各自折叠 ─────────────────────────────
        addSection(root, getString(R.string.ui_section_diag))
        val diagCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = U.card(this@MainActivity, 20f)
        }

        diagBadge = U.chip(this, getString(R.string.ui_diag_pending),
            Color.parseColor("#243257"), U.TEXT_SUB)
        diagChevron = ImageView(this).apply {
            setImageDrawable(U.chevron(false))
        }
        diagCard.addView(foldRow(getString(R.string.ui_runtime_check), diagBadge, diagChevron) {
            diagExpanded = !diagExpanded
            applyToggles()
        })

        diagPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = U.card(this@MainActivity, 14f, U.CARD_INNER, U.STROKE)
            setPadding(d(14), d(12), d(14), d(12))
            visibility = View.GONE
        }
        diagText = TextView(this).apply {
            textSize = 11f
            setTextColor(U.TEXT_SUB)
            typeface = Typeface.MONOSPACE
            setLineSpacing(U.dpF(this@MainActivity, 2f), 1f)
            setTextIsSelectable(true)
        }
        diagPanel.addView(diagText)
        diagCard.addView(diagPanel, LinearLayout.LayoutParams(-1, -2).apply {
            leftMargin = d(12); rightMargin = d(12); bottomMargin = d(12)
        })

        diagCard.addView(U.divider(this), LinearLayout.LayoutParams(-1, d(1)))

        logBadge = U.chip(this, getString(R.string.ui_log_empty),
            Color.parseColor("#243257"), U.TEXT_SUB)
        logChevron = ImageView(this).apply {
            setImageDrawable(U.chevron(false))
        }
        diagCard.addView(foldRow(getString(R.string.ui_logs), logBadge, logChevron) {
            logExpanded = !logExpanded
            applyToggles()
        })

        logPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = U.card(this@MainActivity, 14f, U.CARD_INNER, U.STROKE)
            setPadding(d(14), d(12), d(14), d(12))
            visibility = View.GONE
        }
        logText = TextView(this).apply {
            textSize = 10f
            setTextColor(U.TEXT_SUB)
            typeface = Typeface.MONOSPACE
            setLineSpacing(U.dpF(this@MainActivity, 2f), 1f)
            setTextIsSelectable(true)
        }
        logPanel.addView(logText)
        diagCard.addView(logPanel, LinearLayout.LayoutParams(-1, -2).apply {
            leftMargin = d(12); rightMargin = d(12); topMargin = d(4); bottomMargin = d(12)
        })
        root.addView(diagCard, LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = d(10)
        })

        root.addView(TextView(this).apply {
            text = getString(R.string.ui_footer)
            textSize = 10.5f
            setTextColor(U.TEXT_DIM)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = d(20) })

        applyToggles()
        return ScrollView(this).apply {
            background = U.pageBackground()
            setFillViewport(true)
            addView(root)
        }
    }

    /** 统一同步三个折叠区与箭头、设置按钮文字。 */
    private fun applyToggles() {
        settingsPanel.visibility = if (settingsExpanded) View.VISIBLE else View.GONE
        diagPanel.visibility = if (diagExpanded) View.VISIBLE else View.GONE
        logPanel.visibility = if (logExpanded) View.VISIBLE else View.GONE
        diagChevron.setImageDrawable(U.chevron(diagExpanded))
        logChevron.setImageDrawable(U.chevron(logExpanded))
        settingsButton.text = getString(
            if (settingsExpanded) R.string.ui_collapse_settings else R.string.ui_settings
        )
    }

    // ──────────────────────────────────────────────────────────────
    // 状态渲染
    // ──────────────────────────────────────────────────────────────

    private fun render(s: GatewayApp.Status) {
        lastStatus = s
        val dotColor: Int
        val pillFill: Int
        val pillTextColor: Int
        val pillLabel: Int
        when (s.state) {
            GatewayApp.State.READY -> {
                dotColor = U.OK; pillFill = Color.parseColor("#2A4BE3A2")
                pillTextColor = U.OK; pillLabel = R.string.state_ready
            }
            GatewayApp.State.STARTING -> {
                dotColor = U.WARN; pillFill = Color.parseColor("#2AFFC46B")
                pillTextColor = U.WARN; pillLabel = R.string.state_starting
            }
            GatewayApp.State.ERROR -> {
                dotColor = U.ERROR; pillFill = Color.parseColor("#2AFF7A8A")
                pillTextColor = U.ERROR; pillLabel = R.string.state_error
            }
            else -> {
                dotColor = U.IDLE; pillFill = Color.parseColor("#2A8A97B8")
                pillTextColor = U.IDLE; pillLabel = R.string.state_stopped
            }
        }
        stateDot.setImageDrawable(U.dot(dotColor, U.dp(this, 10)))
        stateText.text = getString(pillLabel)
        stateText.setTextColor(pillTextColor)
        statePill.text = getString(pillLabel)
        statePill.background = U.pill(this, pillFill)
        statePill.setTextColor(pillTextColor)

        detailText.text = if (s.port > 0) {
            buildString {
                appendLine("实际端口：${s.port}${if (s.message.isNotBlank()) "（${s.message}）" else ""}")
                append("Base URL：${RikkaHubHandoff.baseUrl(s.port)}")
            }
        } else {
            s.message.ifBlank { "端口 18900 起的本地服务；被占用时会自动顺延并在界面标注实际端口。" }
        }

        keyText.text = if (s.apiKey.isBlank()) {
            getString(R.string.ui_key_pending)
        } else {
            if (keyVisible) s.apiKey else "••••••••" + s.apiKey.takeLast(4)
        }
        keyToggle.text = getString(if (keyVisible) R.string.ui_hide else R.string.ui_show)

        val diag = cachedDiag
        diagText.text = if (diag == null) {
            getString(R.string.ui_diag_pending)
        } else {
            diag.summary() + "\n" + diag.advice()
        }
        // 折叠状态下也能看到自检结论，不用展开就知道有没有问题。
        diagBadge.text = when {
            diag == null -> getString(R.string.ui_diag_pending)
            diag.canStartNode -> getString(R.string.ui_diag_ready)
            else -> getString(R.string.ui_diag_bad)
        }
        diagBadge.background = U.pill(this, when {
            diag == null -> Color.parseColor("#243257")
            diag.canStartNode -> Color.parseColor("#2A4BE3A2")
            else -> Color.parseColor("#2AFF7A8A")
        })
        diagBadge.setTextColor(when {
            diag == null -> U.TEXT_SUB
            diag.canStartNode -> U.OK
            else -> U.ERROR
        })

        logText.text = cachedLogTail
        logBadge.text = if (cachedLogTail.isBlank()) {
            getString(R.string.ui_log_empty)
        } else {
            getString(R.string.ui_log_lines, cachedLogTail.lines().size)
        }

        applyToggles()

        // 启动/失败各刷新一次自检：代码目录在启动过程中才被释放，
        // 只按状态变化触发，避免与 refreshDiag 内部的 render 形成循环。
        if (s.state != lastRenderedState &&
            (s.state == GatewayApp.State.ERROR || s.state == GatewayApp.State.READY)
        ) {
            refreshDiag()
        }
        lastRenderedState = s.state
    }

    private fun ensureOverlayAndBattery() {
        if (GatewayConfig.floatingEnabled(this) && !FloatingWindow(this).canShow()) {
            Toast.makeText(this, "未授予悬浮窗权限，前台服务仍会运行", Toast.LENGTH_SHORT).show()
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2001
            )
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2001
            )
        }
    }

    /** r5d：从公共 Download 目录导入 rootfs-arm64.tar.gz / .zip 需要读权限。 */
    private fun requestStoragePermissionIfNeeded() {
        val needed = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
        if (needed.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, needed.toTypedArray(), 2002)
        }
    }
}
