package com.android.dsh.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.android.dsh.core.GatewayConfig
import com.android.dsh.core.GatewayService

/** 开机自启默认关闭（Manifest 中 enabled=false），由用户在设置中显式开启。 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action !in setOf(Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_LOCKED_BOOT_COMPLETED)) return
        if (!GatewayConfig.bootEnabled(ctx)) return
        GatewayService.start(ctx)
    }
}
