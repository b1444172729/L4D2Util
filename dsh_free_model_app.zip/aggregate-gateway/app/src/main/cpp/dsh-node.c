/*
 * 聚合网关 · 自建 JNI 胶水（不再依赖 React Native 插件）
 *
 * 官方 nodejs-mobile Android 集成方式：把 Java 的 String[] 转成 libuv 友好的
 * argc/argv，再调用 libnode.so 导出的 node::Start(int, char**)。
 * 官方教程要求 include "node.h" 并在 CMake 里 IMPORTED 链接 libnode.so，
 * 但那样构建期就必须拿到 libnode.so 与全套 headers。
 *
 * 这里改成 dlopen + dlsym：
 *   · 编译期只依赖 NDK 自带的 <jni.h> / <dlfcn.h> / <android/log.h>，
 *     因此即便 CI 这一步没下载到 libnode.so，工程照样能编译出 APK；
 *   · 运行期按绝对路径 dlopen(libnode.so)，再从若干候选符号里解析
 *     node::Start，解析结果由 probe() 暴露到界面自检区；
 *   · 覆盖 node::Start 的两参数与四参数两种 ABI 变体。
 *
 * 参考：nodejs-mobile 官方 getting-started / native-gradle sample。
 */
#include <jni.h>
#include <dlfcn.h>
#include <unistd.h>
#include <fcntl.h>
#include <android/log.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#define LOG_TAG "dsh-node"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

#ifndef RTLD_DEFAULT
#define RTLD_DEFAULT ((void *) 0)
#endif

typedef int (*NodeStart2)(int, char **);
typedef int (*NodeStart4)(int, char **, char **, char **);

/* Itanium C++ ABI 修饰名。首个为官方 sample 使用的 node::Start(int, char**)。 */
static const char *kStartSymbols[] = {
    "_ZN4node5StartEiPPc",           /* node::Start(int, char**) */
    "_ZN4node5StartEiPPcS1_S1_",     /* node::Start(int, char**, char**, char**) */
    "_ZN4node5StartEiPPcS0_S0_",
    "node_Start",                    /* 少数发行版导出的 C 包装 */
    "node_start"
};

static void *find_start(void *handle, const char **found) {
    size_t i;
    for (i = 0; i < sizeof(kStartSymbols) / sizeof(kStartSymbols[0]); ++i) {
        void *s = dlsym(handle ? handle : RTLD_DEFAULT, kStartSymbols[i]);
        if (s) {
            *found = kStartSymbols[i];
            return s;
        }
    }
    return NULL;
}

/* libuv 要求 argv 的字符串位于连续内存块，官方 sample 也是这么做的。 */
static char **build_argv(JNIEnv *env, jobjectArray arguments, jsize *count) {
    jsize n = (*env)->GetArrayLength(env, arguments);
    size_t total = 1;
    char *buffer;
    char **argv;
    char *cursor;
    jsize i;

    for (i = 0; i < n; ++i) {
        jstring js = (jstring) (*env)->GetObjectArrayElement(env, arguments, i);
        if (js) {
            const char *c = (*env)->GetStringUTFChars(env, js, NULL);
            if (c) {
                total += strlen(c) + 1;
                (*env)->ReleaseStringUTFChars(env, js, c);
            }
            (*env)->DeleteLocalRef(env, js);
        }
    }

    buffer = (char *) calloc(total, sizeof(char));
    argv = (char **) calloc((size_t) n + 1, sizeof(char *));
    if (!buffer || !argv) {
        free(buffer);
        free(argv);
        return NULL;
    }

    cursor = buffer;
    for (i = 0; i < n; ++i) {
        jstring js = (jstring) (*env)->GetObjectArrayElement(env, arguments, i);
        const char *c = js ? (*env)->GetStringUTFChars(env, js, NULL) : NULL;
        size_t len = c ? strlen(c) : 0;
        if (len) memcpy(cursor, c, len);
        cursor[len] = '\0';
        argv[i] = cursor;
        cursor += len + 1;
        if (js) {
            if (c) (*env)->ReleaseStringUTFChars(env, js, c);
            (*env)->DeleteLocalRef(env, js);
        }
    }
    *count = n;
    /* buffer 故意不释放：node::Start 会长期持有 argv（uv_setup_args） */
    return argv;
}

JNIEXPORT jstring JNICALL
Java_com_android_dsh_core_NodeBridge_nativeProbe(JNIEnv *env, jclass cls, jstring jpath) {
    const char *p;
    void *handle;
    const char *found = NULL;
    void *sym;
    char buf[768];

    (void) cls;
    p = (*env)->GetStringUTFChars(env, jpath, NULL);
    handle = p ? dlopen(p, RTLD_NOW | RTLD_GLOBAL) : NULL;
    sym = handle ? find_start(handle, &found) : NULL;

    if (!p) {
        snprintf(buf, sizeof(buf), "libnode.so 路径为空");
    } else if (!handle) {
        const char *err = dlerror();
        const char *hint = (err && strstr(err, "libc++_shared"))
            ? "｜请把 NDK 的 arm64 libc++_shared.so 放进 APK 的 lib/arm64-v8a/"
            : "";
        snprintf(buf, sizeof(buf), "dlopen(libnode.so) 失败：%s%s",
                 err ? err : "未知原因", hint);
    } else if (!sym) {
        snprintf(buf, sizeof(buf),
                 "libnode.so 已加载，但未导出 node::Start 符号（版本或裁剪不匹配）");
    } else {
        snprintf(buf, sizeof(buf), "OK：已解析 %s，可以启动 Node", found);
    }
    if (p) (*env)->ReleaseStringUTFChars(env, jpath, p);
    return (*env)->NewStringUTF(env, buf);
}

/*
 * 把 stdout/stderr 重定向到 app 私有目录的日志文件。
 *
 * 这一步是「可观测性」的关键：libnode.so 是 C++ 库，V8/Node 遇到致命错误时
 * 会往 stderr 打印 "FATAL ERROR" / "Check failed" 然后 abort()。
 * 默认这些输出在安卓上会丢进 /dev/null，界面只能看到一句「启动失败」，
 * 无法定位。重定向后再配合独立 :node 进程，Node 即使崩了也留得下遗言。
 *
 * 只在独立 :node 进程里调用（主进程 UI 不受影响），用 _IONBF 保证
 * abort() 之前的最后一行业已落盘。
 */
static void redirect_output_to_file(JNIEnv *env, jstring jlog) {
    if (!jlog) return;
    const char *lp = (*env)->GetStringUTFChars(env, jlog, NULL);
    if (lp && *lp) {
        int fd = open(lp, O_WRONLY | O_CREAT | O_APPEND, 0600);
        if (fd >= 0) {
            dup2(fd, STDOUT_FILENO);
            dup2(fd, STDERR_FILENO);
            if (fd > STDERR_FILENO) close(fd);
        }
    }
    if (lp) (*env)->ReleaseStringUTFChars(env, jlog, lp);
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
}

JNIEXPORT jint JNICALL
Java_com_android_dsh_core_NodeBridge_nativeStart(
        JNIEnv *env, jclass cls, jobjectArray arguments,
        jstring jlib, jstring jworkdir, jstring jlog) {
    const char *libpath;
    void *handle;
    const char *found = NULL;
    void *sym;
    char **argv;
    jsize argc = 0;
    int rc;

    (void) cls;
    redirect_output_to_file(env, jlog);
    libpath = (*env)->GetStringUTFChars(env, jlib, NULL);
    handle = libpath ? dlopen(libpath, RTLD_NOW | RTLD_GLOBAL) : NULL;
    if (!handle) {
        const char *err = dlerror();
        LOGE("dlopen(libnode.so) 失败：%s", err ? err : "未知原因");
        if (libpath) (*env)->ReleaseStringUTFChars(env, jlib, libpath);
        return -101;
    }

    sym = find_start(handle, &found);
    if (!sym) {
        LOGE("libnode.so 未导出 node::Start 符号");
        (*env)->ReleaseStringUTFChars(env, jlib, libpath);
        return -102;
    }
    LOGI("使用符号 %s 启动 Node", found);

    if (jworkdir) {
        const char *wd = (*env)->GetStringUTFChars(env, jworkdir, NULL);
        if (wd) {
            chdir(wd);
            (*env)->ReleaseStringUTFChars(env, jworkdir, wd);
        }
    }

    argv = build_argv(env, arguments, &argc);
    if (!argv) {
        (*env)->ReleaseStringUTFChars(env, jlib, libpath);
        return -103;
    }

    /* 证明重定向已生效：即使下一行 node::Start 直接 abort，日志里也留得下这些行 */
    fprintf(stderr, "[dsh-node] 即将调用 node::Start(argc=%d, symbol=%s)\n",
            (int) argc, found);
    {
        int i;
        for (i = 0; i < (int) argc; ++i) {
            fprintf(stderr, "[dsh-node] argv[%d]=%s\n", i, argv[i]);
        }
    }
    fflush(stderr);

    if (strstr(found, "S1_") || strstr(found, "S0_")) {
        char **empty = (char **) calloc(1, sizeof(char *));
        rc = ((NodeStart4) sym)((int) argc, argv, empty, empty);
        free(empty);
    } else {
        rc = ((NodeStart2) sym)((int) argc, argv);
    }
    LOGI("node::Start 返回 %d", rc);

    free(argv);
    (*env)->ReleaseStringUTFChars(env, jlib, libpath);
    return (jint) rc;
}
