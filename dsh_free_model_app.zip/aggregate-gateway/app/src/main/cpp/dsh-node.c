/*
 * 聚合网关 · 自建 JNI 胶水（不依赖 React Native 插件）
 *
 * 官方 nodejs-mobile Android 集成（getting-started）的两条硬性前置：
 *   1) Java 层先 System.loadLibrary("node")，由 Android linker 在默认
 *      namespace 加载 libnode.so 并执行其 .init_array；
 *   2) 再调用 node::Start(argc, argv)，argc 只包含 "node" 与脚本路径。
 *
 * 早期版本只在 C 层 dlopen(绝对路径)：dlopen/dlsym 都能成功（界面符号
 * 探测一直是 OK），但 V8 初始化阶段的依赖解析/信号初始化在
 * classloader-namespace 里会直接 abort，且 stdout 无任何输出，表现为
 * 「调用 node::Start 后 :node 进程静默消失」。
 *
 * 本版据此调整：
 *   · find_start 优先 RTLD_DEFAULT（已加载的 libnode.so），再回退 dlopen；
 *   · 启动前 setenv TMPDIR/HOME/NODE_PATH/NODE_OPTIONS 与 OFM_* 配置；
 *   · argv 极简为 ["node", bootstrap.js]，所有配置走环境变量，
 *     避开 nodejs-mobile 对自定义 --port 的解析差异（bad option → exit(9)）；
 *   · 关键阶段用 open()+write() 直接落盘，绕过可能被 Node 接管的 stdio。
 */
#ifndef _GNU_SOURCE
#define _GNU_SOURCE 1   /* setenv / TMPDIR 等 POSIX 接口在严格 C11 下需要 */
#endif
#include <jni.h>
#include <dlfcn.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <android/log.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#define LOG_TAG "dsh-node"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

#ifndef RTLD_DEFAULT
#define RTLD_DEFAULT ((void *) 0)
#endif

typedef int (*NodeStart2)(int, char **);
typedef int (*NodeStart4)(int, char **, char **, char **);

/* Itanium C++ ABI 修饰名。首个为官方 sample 使用的 node::Start(int, char**)。 */
static const char *kStartSymbols[] = {
    "_ZN4node5StartEiPPc",           /* node::Start(int, char**) */
    "_ZN4node5StartEiPPcS1_S1_",     /* node::Start(int, char**, char**, char**) */
    "_ZN4node5StartEiPPcS0_S0_",
    "node_Start",                    /* 少数发行版导出的 C 包装 */
    "node_start"
};

/** 直接写文件：Node 可能重新接管 stdout/stderr，文件写入不受影响。 */
static void log_line(const char *path, const char *msg) {
    if (!path || !*path || !msg) return;
    int fd = open(path, O_WRONLY | O_CREAT | O_APPEND, 0600);
    if (fd >= 0) {
        (void) write(fd, msg, strlen(msg));
        (void) write(fd, "\n", 1);
        close(fd);
    }
}

static void *find_start(void *handle, const char **found) {
    size_t i;
    for (i = 0; i < sizeof(kStartSymbols) / sizeof(kStartSymbols[0]); ++i) {
        /* 优先全局符号表：libnode.so 已由 System.loadLibrary("node") 加载 */
        void *s = dlsym(RTLD_DEFAULT, kStartSymbols[i]);
        if (s) {
            *found = kStartSymbols[i];
            return s;
        }
        if (handle) {
            s = dlsym(handle, kStartSymbols[i]);
            if (s) {
                *found = kStartSymbols[i];
                return s;
            }
        }
    }
    return NULL;
}

/* libuv 要求 argv 的字符串位于连续内存块，官方 sample 也是这么做的。 */
static char **build_argv(JNIEnv *env, jobjectArray arguments, jsize *count) {
    jsize n = (*env)->GetArrayLength(env, arguments);
    size_t total = 1;
    char *buffer;
    char **argv;
    char *cursor;
    jsize i;

    for (i = 0; i < n; ++i) {
        jstring js = (jstring) (*env)->GetObjectArrayElement(env, arguments, i);
        if (js) {
            const char *c = (*env)->GetStringUTFChars(env, js, NULL);
            if (c) {
                total += strlen(c) + 1;
                (*env)->ReleaseStringUTFChars(env, js, c);
            }
            (*env)->DeleteLocalRef(env, js);
        }
    }

    buffer = (char *) calloc(total, sizeof(char));
    argv = (char **) calloc((size_t) n + 1, sizeof(char *));
    if (!buffer || !argv) {
        free(buffer);
        free(argv);
        return NULL;
    }

    cursor = buffer;
    for (i = 0; i < n; ++i) {
        jstring js = (jstring) (*env)->GetObjectArrayElement(env, arguments, i);
        const char *c = js ? (*env)->GetStringUTFChars(env, js, NULL) : NULL;
        size_t len = c ? strlen(c) : 0;
        if (len) memcpy(cursor, c, len);
        cursor[len] = '\0';
        argv[i] = cursor;
        cursor += len + 1;
        if (js) {
            if (c) (*env)->ReleaseStringUTFChars(env, js, c);
            (*env)->DeleteLocalRef(env, js);
        }
    }
    *count = n;
    /* buffer 故意不释放：node::Start 会长期持有 argv（uv_setup_args） */
    return argv;
}

JNIEXPORT jstring JNICALL
Java_com_android_dsh_core_NodeBridge_nativeProbe(JNIEnv *env, jclass cls, jstring jpath) {
    const char *p;
    void *handle;
    const char *found = NULL;
    void *sym;
    char buf[768];

    (void) cls;
    p = (*env)->GetStringUTFChars(env, jpath, NULL);
    handle = p ? dlopen(p, RTLD_NOW | RTLD_GLOBAL) : NULL;
    sym = find_start(handle, &found);

    if (!p) {
        snprintf(buf, sizeof(buf), "libnode.so 路径为空");
    } else if (!handle) {
        const char *err = dlerror();
        const char *hint = (err && strstr(err, "libc++_shared"))
            ? "｜请把 NDK 的 arm64 libc++_shared.so 放进 APK 的 lib/arm64-v8a/"
            : "";
        snprintf(buf, sizeof(buf), "dlopen(libnode.so) 失败：%s%s",
                 err ? err : "未知原因", hint);
    } else if (!sym) {
        snprintf(buf, sizeof(buf),
                 "libnode.so 已加载，但未导出 node::Start 符号（版本或裁剪不匹配）");
    } else {
        snprintf(buf, sizeof(buf), "OK：已解析 %s，可以启动 Node", found);
    }
    if (p) (*env)->ReleaseStringUTFChars(env, jpath, p);
    return (*env)->NewStringUTF(env, buf);
}

/* 把 stdout/stderr 重定向到 app 私有目录，用 _IONBF 保证 abort 前落盘。 */
static void redirect_output_to_file(JNIEnv *env, jstring jlog) {
    if (!jlog) return;
    const char *lp = (*env)->GetStringUTFChars(env, jlog, NULL);
    if (lp && *lp) {
        int fd = open(lp, O_WRONLY | O_CREAT | O_APPEND, 0600);
        if (fd >= 0) {
            dup2(fd, STDOUT_FILENO);
            dup2(fd, STDERR_FILENO);
            if (fd > STDERR_FILENO) close(fd);
        }
    }
    if (lp) (*env)->ReleaseStringUTFChars(env, jlog, lp);
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
}

/*
 * V8 / Node 在 Android 上初始化时的必需环境：
 *   TMPDIR   —— 系统没有 /tmp，缺失会让 V8 的临时文件/快照路径初始化失败；
 *   HOME     —— bootstrap.js 与 standalone 的默认数据目录依据；
 *   NODE_PATH—— 释放出来的 node_modules 位置；
 *   NODE_OPTIONS 清空 —— 避免外部注入选项触发 bad option。
 * 端口/目录等配置一律走 OFM_*，argv 因此能保持官方 sample 的最简形态。
 */
static void setup_environment(JNIEnv *env, jstring jhome, jstring jdata,
                              jstring jcache, jint jport, jstring jhost,
                              jboolean jlan, const char *logpath) {
    const char *home = jhome ? (*env)->GetStringUTFChars(env, jhome, NULL) : NULL;
    const char *data = jdata ? (*env)->GetStringUTFChars(env, jdata, NULL) : NULL;
    const char *cache = jcache ? (*env)->GetStringUTFChars(env, jcache, NULL) : NULL;
    const char *host = jhost ? (*env)->GetStringUTFChars(env, jhost, NULL) : NULL;
    char buf[1400];

    if (cache && *cache) {
        mkdir(cache, 0700);
        setenv("TMPDIR", cache, 1);
    }
    if (data && *data) {
        setenv("HOME", data, 1);
        setenv("OFM_HOME", data, 1);
        setenv("OFM_DATA_DIR", data, 1);
    }
    setenv("NODE_OPTIONS", "", 1);
    setenv("UV_THREADPOOL_SIZE", "4", 1);

    if (home && *home) {
        snprintf(buf, sizeof(buf), "%s/node_modules", home);
        setenv("NODE_PATH", buf, 1);
        chdir(home);
    }
    snprintf(buf, sizeof(buf), "%d", (int) jport);
    setenv("OFM_PORT", buf, 1);
    setenv("OFM_HOST", (host && *host) ? host : "127.0.0.1", 1);
    setenv("OFM_LAN_RELAY", jlan == JNI_TRUE ? "1" : "0", 1);

    snprintf(buf, sizeof(buf),
             "[dsh-node] env: TMPDIR=%s | HOME=%s | NODE_PATH=%s/node_modules | "
             "OFM_PORT=%d | OFM_HOST=%s | OFM_LAN_RELAY=%s",
             (cache && *cache) ? cache : "(未设置)",
             (data && *data) ? data : "(未设置)",
             (home && *home) ? home : "(未设置)",
             (int) jport,
             (host && *host) ? host : "127.0.0.1",
             jlan == JNI_TRUE ? "1" : "0");
    log_line(logpath, buf);
    fprintf(stderr, "%s\n", buf);
    fflush(stderr);

    if (home) (*env)->ReleaseStringUTFChars(env, jhome, home);
    if (data) (*env)->ReleaseStringUTFChars(env, jdata, data);
    if (cache) (*env)->ReleaseStringUTFChars(env, jcache, cache);
    if (host) (*env)->ReleaseStringUTFChars(env, jhost, host);
}

JNIEXPORT jint JNICALL
Java_com_android_dsh_core_NodeBridge_nativeStart(
        JNIEnv *env, jclass cls, jobjectArray arguments,
        jstring jlib, jstring jworkdir, jstring jdata, jstring jcache,
        jint jport, jstring jhost, jboolean jlan, jstring jlog) {
    const char *libpath;
    void *handle;
    const char *found = NULL;
    void *sym;
    char **argv;
    jsize argc = 0;
    char logpath[1024] = {0};
    char tmp[256];
    int rc;

    (void) cls;
    redirect_output_to_file(env, jlog);
    if (jlog) {
        const char *lp = (*env)->GetStringUTFChars(env, jlog, NULL);
        if (lp) {
            snprintf(logpath, sizeof(logpath), "%s", lp);
            (*env)->ReleaseStringUTFChars(env, jlog, lp);
        }
    }

    log_line(logpath, "[dsh-node] nativeStart 进入，准备初始化环境");
    setup_environment(env, jworkdir, jdata, jcache, jport, jhost, jlan, logpath);

    libpath = (*env)->GetStringUTFChars(env, jlib, NULL);
    handle = libpath ? dlopen(libpath, RTLD_NOW | RTLD_GLOBAL) : NULL;
    if (!handle) {
        const char *err = dlerror();
        LOGE("dlopen(libnode.so) 失败：%s", err ? err : "未知原因");
        log_line(logpath, "[dsh-node] dlopen(libnode.so) 失败");
        if (libpath) (*env)->ReleaseStringUTFChars(env, jlib, libpath);
        return -101;
    }

    sym = find_start(handle, &found);
    if (!sym) {
        LOGE("libnode.so 未导出 node::Start 符号");
        log_line(logpath, "[dsh-node] 未找到 node::Start 符号");
        (*env)->ReleaseStringUTFChars(env, jlib, libpath);
        return -102;
    }
    snprintf(tmp, sizeof(tmp), "[dsh-node] 使用符号 %s", found);
    log_line(logpath, tmp);

    argv = build_argv(env, arguments, &argc);
    if (!argv) {
        (*env)->ReleaseStringUTFChars(env, jlib, libpath);
        return -103;
    }

    snprintf(tmp, sizeof(tmp), "[dsh-node] 即将调用 node::Start(argc=%d)", (int) argc);
    log_line(logpath, tmp);
    fprintf(stderr, "%s\n", tmp);
    {
        int i;
        for (i = 0; i < (int) argc; ++i) {
            fprintf(stderr, "[dsh-node] argv[%d]=%s\n", i, argv[i]);
        }
    }
    fflush(stderr);

    if (strstr(found, "S1_") || strstr(found, "S0_")) {
        char **empty = (char **) calloc(1, sizeof(char *));
        rc = ((NodeStart4) sym)((int) argc, argv, empty, empty);
        free(empty);
    } else {
        rc = ((NodeStart2) sym)((int) argc, argv);
    }

    snprintf(tmp, sizeof(tmp), "[dsh-node] node::Start 返回 rc=%d（Node 主循环已结束）", rc);
    log_line(logpath, tmp);
    LOGI("%s", tmp);
    fprintf(stderr, "%s\n", tmp);
    fflush(stderr);

    free(argv);
    (*env)->ReleaseStringUTFChars(env, jlib, libpath);
    return (jint) rc;
}
