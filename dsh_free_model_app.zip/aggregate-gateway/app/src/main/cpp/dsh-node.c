/*
 * 聚合网关 · 自建 JNI 胶水（不依赖 React Native 插件）
 *
 * 官方 nodejs-mobile Android 集成（getting-started）的两条硬性前置：
 *   1) Java 层先 System.loadLibrary("node")，由 Android linker 在默认
 *      namespace 加载 libnode.so 并执行其 .init_array；
 *   2) 再调用 node::Start(argc, argv)，argc 只包含 "node" 与脚本路径。
 *
 * 早期版本只在 C 层 dlopen(绝对路径)：dlopen/dlsym 都能成功（界面符号
 * 探测一直是 OK），但 V8 初始化阶段的依赖解析/信号初始化在
 * classloader-namespace 里会直接 abort，且 stdout 无任何输出，表现为
 * 「调用 node::Start 后 :node 进程静默消失」。
 *
 * 本版据此调整：
 *   · find_start 优先 RTLD_DEFAULT（已加载的 libnode.so），再回退 dlopen；
 *   · 启动前 setenv TMPDIR/HOME/NODE_PATH/NODE_OPTIONS 与 OFM_* 配置；
 *   · argv 极简为 ["node", bootstrap.js]，所有配置走环境变量，
 *     避开 nodejs-mobile 对自定义 --port 的解析差异（bad option → exit(9)）；
 *   · 关键阶段用 open()+write() 直接落盘，绕过可能被 Node 接管的 stdio。
 */
#ifndef _GNU_SOURCE
#define _GNU_SOURCE 1   /* setenv / TMPDIR 等 POSIX 接口在严格 C11 下需要 */
#endif
#include <jni.h>
#include <dlfcn.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <pthread.h>
#include <stdint.h>
#include <errno.h>
#include <sys/stat.h>
#include <android/log.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

/* V8 需要大栈：Android 默认线程栈约 1MB，V8 初始化/解析阶段容易 SIGSEGV。 */
#define NODE_STACK_BYTES (8 * 1024 * 1024)

#define LOG_TAG "dsh-node"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

#ifndef RTLD_DEFAULT
#define RTLD_DEFAULT ((void *) 0)
#endif

typedef int (*NodeStart2)(int, char **);
typedef int (*NodeStart4)(int, char **, char **, char **);

#ifdef DSH_LINK_LIBNODE
/*
 * 官方形态：CMake 把 libnode.so 作为 IMPORTED SHARED 链接进 libdsh-node.so，
 * 生成 DT_NEEDED: libnode.so。Android linker 在加载本库时自动把 libnode.so
 * 加载进同一个 classloader namespace 并在加载期绑定符号 —— 进程里只有一份，
 * V8 的 .init_array 与内部符号解析都在正确的 namespace 里完成。
 *
 * 用 weak 声明：万一这份 libnode.so 不导出该符号，本库仍能加载，
 * 运行时回退到 dlopen+dlsym，界面自检会如实显示，不会出现「加载胶水就崩」。
 */
extern int _ZN4node5StartEiPPc(int, char **) __attribute__((weak));
#endif

/* Itanium C++ ABI 修饰名。首个为官方 sample 使用的 node::Start(int, char**)。 */
static const char *kStartSymbols[] = {
    "_ZN4node5StartEiPPc",           /* node::Start(int, char**) */
    "_ZN4node5StartEiPPcS1_S1_",     /* node::Start(int, char**, char**, char**) */
    "_ZN4node5StartEiPPcS0_S0_",
    "node_Start",                    /* 少数发行版导出的 C 包装 */
    "node_start"
};

/** 直接写文件：Node 可能重新接管 stdout/stderr，文件写入不受影响。
 *  单次 write（把 \n 拼进同一缓冲区），避免 watchdog 线程与主线程交错成
 *  「_ZN4node5StartEiPPc[dsh-node] watchdog tick=1」这种粘行。 */
static void log_line(const char *path, const char *msg) {
    if (!path || !*path || !msg) return;
    char line[2048];
    size_t n = strlen(msg);
    if (n > sizeof(line) - 2) n = sizeof(line) - 2;
    memcpy(line, msg, n);
    line[n] = '\n';
    int fd = open(path, O_WRONLY | O_CREAT | O_APPEND, 0600);
    if (fd >= 0) {
        (void) write(fd, line, n + 1);
        close(fd);
    }
}

/*
 * nodejs-mobile 的 Android 构建明确把 JS 的 process.stdout/stderr 送到
 * /dev/null；直接 dup2 到普通文件时，Node 初始化阶段写出的
 *   "node: could not initialize ICU (check NODE_ICU_DATA ...)"
 *   "node: bad option: ..."
 * 这类 C 层 fprintf(stderr) 常常一条都看不到 —— 这正是前几轮
 * 「atexit 触发但 node-output.log 里没有任何 Node 文本」的原因。
 *
 * 官方 redirect-to-logcat guide 的做法：在 node::Start 之前建 pipe，
 * dup2 写端到 fd 1/2，再用两个 pthread 从读端把内容泵到日志。
 * 即使 Node 随后把 stdio 换成 /dev/null，初始化早期写进 pipe 的数据
 * 仍会被泵出来。这里泵到 ofm-data/node-output.log 而不是 logcat，
 * 这样界面状态卡不用 adb 就能看到。
 */
static char g_pump_log[1024] = {0};

static void *stdio_pump(void *arg) {
    int rfd = (int) (intptr_t) arg;
    int wfd = open(g_pump_log, O_WRONLY | O_CREAT | O_APPEND, 0600);
    char buf[4096];
    for (;;) {
        ssize_t n = read(rfd, buf, sizeof(buf));
        if (n > 0) {
            if (wfd >= 0) (void) write(wfd, buf, (size_t) n);
        } else if (n == 0) {
            break;                     /* 写端全部关闭 */
        } else if (errno == EINTR) {
            continue;
        } else {
            break;
        }
    }
    close(rfd);
    if (wfd >= 0) close(wfd);
    return NULL;
}

/* -------------------------------------------------------------------------
 * 原生崩溃捕获。
 *
 * V8 / libnode 在初始化阶段若直接 SIGSEGV（栈溢出）或 abort()（CHECK 失败），
 * 进程会静默消失，stdio 里什么都不会留下 —— 这正是前几轮「日志停在
 * '即将调用 node::Start' 之后一片空白」的原因。
 * 这里用 sigaction 把信号编号写进日志文件，只调用 async-signal-safe 的
 * open/write/close，不做任何格式化或内存分配。
 * ------------------------------------------------------------------------- */
static char g_crash_log[1024] = {0};
static volatile int g_watchdog_run = 1;

/*
 * atexit 探测：node::Start 内部若直接调用 exit()（Node 参数/初始化失败时
 * 常见），进程会连 pthread_join 之后的代码都不执行就消失 —— 既不触发我们
 * 捕获的信号，也不会打印 "node::Start 返回"。atexit 回调是唯一能留下的遗言。
 */
static void atexit_probe(void) {
    log_line(g_crash_log,
             "[dsh-node] atexit 触发：进程走 exit() 退出，node::Start 未正常返回"
             "（不是被信号杀死，多为 Node 内部初始化直接退出）");
}

/*
 * 看门狗：独立 pthread 定时写心跳。三种结局可区分：
 *   · 有 atexit 行            → node::Start 内部调用了 exit()
 *   · 有崩溃信号行            → 被可捕获信号终止
 *   · 心跳突然停、两者都没有  → SIGKILL / LMK / OOM，或 V8 覆盖了 signal handler
 * 心跳还能给出存活时长（tick 数 × 0.5 秒），判断是秒级退出还是跑了一阵被回收。
 */
static void *watchdog_main(void *p) {
    (void) p;
    int n = 0;
    char b[160];
    while (g_watchdog_run && n < 30) {
        snprintf(b, sizeof(b), "[dsh-node] watchdog tick=%d：:node 进程仍存活", ++n);
        log_line(g_crash_log, b);
        usleep(500000);
    }
    return NULL;
}

static const char *signal_name(int sig) {
    switch (sig) {
        case SIGSEGV: return "SIGSEGV(11) 段错误 / 线程栈溢出";
        case SIGABRT: return "SIGABRT(6) abort() / V8 CHECK 失败";
        case SIGBUS:  return "SIGBUS(7) 总线错误";
        case SIGILL:  return "SIGILL(4) 非法指令 / ABI 不匹配";
        case SIGFPE:  return "SIGFPE(8) 算术异常";
        default:      return "未知信号";
    }
}

static void crash_signal_handler(int sig, siginfo_t *info, void *ucontext) {
    (void) info;
    (void) ucontext;
    int fd = open(g_crash_log, O_WRONLY | O_CREAT | O_APPEND, 0600);
    if (fd >= 0) {
        static const char p1[] = "\n[dsh-node] !!! 原生崩溃 signal=";
        static const char p2[] = " | 即将按默认动作终止（logcat 会生成 tombstone）\n";
        const char *name = signal_name(sig);
        /* signal handler 内只调用 async-signal-safe 的 open/write/close，
           长度也自己数，不调用 strlen 等 libc 字符串函数。 */
        size_t n = 0;
        while (name[n] != '\0') ++n;
        (void) write(fd, p1, sizeof(p1) - 1);
        (void) write(fd, name, n);
        (void) write(fd, p2, sizeof(p2) - 1);
        close(fd);
    }
    /* sa_flags 带 SA_RESETHAND，进入本处理器时该信号的动作已自动恢复为默认；
       直接重新投递即可按默认动作终止并留下 tombstone。raise() 是异步信号安全的。 */
    raise(sig);
}

static void install_crash_handlers(const char *logpath) {
    if (logpath && *logpath) {
        snprintf(g_crash_log, sizeof(g_crash_log), "%s", logpath);
    }
    atexit(atexit_probe);
    {
        pthread_t wd;
        if (pthread_create(&wd, NULL, watchdog_main, NULL) == 0) {
            pthread_detach(wd);
        }
    }
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_sigaction = crash_signal_handler;
    sa.sa_flags = SA_SIGINFO | SA_RESETHAND;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGSEGV, &sa, NULL);
    sigaction(SIGABRT, &sa, NULL);
    sigaction(SIGBUS,  &sa, NULL);
    sigaction(SIGILL,  &sa, NULL);
    sigaction(SIGFPE,  &sa, NULL);
}

/* -------------------------------------------------------------------------
 * node::Start 必须在显式大栈的原生 pthread 上执行。
 *
 * Android 的 JVM/JNI 线程默认栈约 1MB；V8 初始化与 JS 解析会递归使用栈，
 * 容易直接 SIGSEGV。官方 sample 用「后台线程」只是相对 UI 线程而言，
 * 真正可靠的做法是 pthread_attr_setstacksize(8MB)。
 *
 * pthread 内不碰 JNIEnv：argv 与符号指针在进入线程前就已准备好（纯 C 内存）。
 * ------------------------------------------------------------------------- */
typedef struct {
    void *sym;
    int argc;
    char **argv;
    int use4;
    int rc;
} node_thread_args;

static void *node_thread_main(void *p) {
    node_thread_args *a = (node_thread_args *) p;
    log_line(g_crash_log, "[dsh-node] pthread 内部：已获得 8MB 栈，即将进入 node::Start");
    if (a->use4) {
        char **empty = (char **) calloc(1, sizeof(char *));
        a->rc = ((NodeStart4) a->sym)((int) a->argc, a->argv, empty, empty);
        free(empty);
    } else {
        a->rc = ((NodeStart2) a->sym)((int) a->argc, a->argv);
    }
    return NULL;
}

static void *find_start(void *handle, const char **found) {
    size_t i;
    for (i = 0; i < sizeof(kStartSymbols) / sizeof(kStartSymbols[0]); ++i) {
        /* 优先全局符号表：libnode.so 已由 System.loadLibrary("node") 加载 */
        void *s = dlsym(RTLD_DEFAULT, kStartSymbols[i]);
        if (s) {
            *found = kStartSymbols[i];
            return s;
        }
        if (handle) {
            s = dlsym(handle, kStartSymbols[i]);
            if (s) {
                *found = kStartSymbols[i];
                return s;
            }
        }
    }
    return NULL;
}

/* libuv 要求 argv 的字符串位于连续内存块，官方 sample 也是这么做的。 */
static char **build_argv(JNIEnv *env, jobjectArray arguments, jsize *count) {
    jsize n = (*env)->GetArrayLength(env, arguments);
    size_t total = 1;
    char *buffer;
    char **argv;
    char *cursor;
    jsize i;

    for (i = 0; i < n; ++i) {
        jstring js = (jstring) (*env)->GetObjectArrayElement(env, arguments, i);
        if (js) {
            const char *c = (*env)->GetStringUTFChars(env, js, NULL);
            if (c) {
                total += strlen(c) + 1;
                (*env)->ReleaseStringUTFChars(env, js, c);
            }
            (*env)->DeleteLocalRef(env, js);
        }
    }

    buffer = (char *) calloc(total, sizeof(char));
    argv = (char **) calloc((size_t) n + 1, sizeof(char *));
    if (!buffer || !argv) {
        free(buffer);
        free(argv);
        return NULL;
    }

    cursor = buffer;
    for (i = 0; i < n; ++i) {
        jstring js = (jstring) (*env)->GetObjectArrayElement(env, arguments, i);
        const char *c = js ? (*env)->GetStringUTFChars(env, js, NULL) : NULL;
        size_t len = c ? strlen(c) : 0;
        if (len) memcpy(cursor, c, len);
        cursor[len] = '\0';
        argv[i] = cursor;
        cursor += len + 1;
        if (js) {
            if (c) (*env)->ReleaseStringUTFChars(env, js, c);
            (*env)->DeleteLocalRef(env, js);
        }
    }
    *count = n;
    /* buffer 故意不释放：node::Start 会长期持有 argv（uv_setup_args） */
    return argv;
}

JNIEXPORT jstring JNICALL
Java_com_android_dsh_core_NodeBridge_nativeProbe(JNIEnv *env, jclass cls, jstring jpath) {
    const char *p;
    void *handle;
    const char *found = NULL;
    void *sym;
    char buf[768];

    (void) cls;
    p = (*env)->GetStringUTFChars(env, jpath, NULL);
    handle = p ? dlopen(p, RTLD_NOW | RTLD_GLOBAL) : NULL;
    sym = find_start(handle, &found);

    if (!p) {
        snprintf(buf, sizeof(buf), "libnode.so 路径为空");
    } else if (!handle) {
        const char *err = dlerror();
        const char *hint = (err && strstr(err, "libc++_shared"))
            ? "｜请把 NDK 的 arm64 libc++_shared.so 放进 APK 的 lib/arm64-v8a/"
            : "";
        snprintf(buf, sizeof(buf), "dlopen(libnode.so) 失败：%s%s",
                 err ? err : "未知原因", hint);
    } else if (!sym) {
        snprintf(buf, sizeof(buf),
                 "libnode.so 已加载，但未导出 node::Start 符号（版本或裁剪不匹配）");
    } else {
        snprintf(buf, sizeof(buf), "OK：已解析 %s，可以启动 Node", found);
    }
    if (p) (*env)->ReleaseStringUTFChars(env, jpath, p);
    return (*env)->NewStringUTF(env, buf);
}

/* 用官方 pipe+pump 形态把 stdout/stderr 泵进日志，_IONBF 保证 abort 前落盘。 */
static void redirect_output_to_file(JNIEnv *env, jstring jlog) {
    if (!jlog) return;
    const char *lp = (*env)->GetStringUTFChars(env, jlog, NULL);
    if (lp && *lp) {
        snprintf(g_pump_log, sizeof(g_pump_log), "%s", lp);

        int po[2], pe[2];
        if (pipe(po) == 0 && pipe(pe) == 0) {
            dup2(po[1], STDOUT_FILENO);
            dup2(pe[1], STDERR_FILENO);
            close(po[1]);
            close(pe[1]);
            pthread_t t1, t2;
            if (pthread_create(&t1, NULL, stdio_pump, (void *) (intptr_t) po[0]) == 0)
                pthread_detach(t1);
            if (pthread_create(&t2, NULL, stdio_pump, (void *) (intptr_t) pe[0]) == 0)
                pthread_detach(t2);
            log_line(g_pump_log, "[dsh-node] stdio pump 已启动（pipe → node-output.log）");
        } else {
            /* 兜底：pipe 创建失败时退回直接 dup2 到文件，仍比丢进 /dev/null 强 */
            int fd = open(lp, O_WRONLY | O_CREAT | O_APPEND, 0600);
            if (fd >= 0) {
                dup2(fd, STDOUT_FILENO);
                dup2(fd, STDERR_FILENO);
                if (fd > STDERR_FILENO) close(fd);
            }
            log_line(g_pump_log, "[dsh-node] 警告：pipe 创建失败，回退直接 dup2");
        }
    }
    if (lp) (*env)->ReleaseStringUTFChars(env, jlog, lp);
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
}

/*
 * V8 / Node 在 Android 上初始化时的必需环境：
 *   TMPDIR   —— 系统没有 /tmp，缺失会让 V8 的临时文件/快照路径初始化失败；
 *   HOME     —— bootstrap.js 与 standalone 的默认数据目录依据；
 *   NODE_PATH—— 释放出来的 node_modules 位置；
 *   NODE_OPTIONS 清空 —— 避免外部注入选项触发 bad option。
 * 端口/目录等配置一律走 OFM_*，argv 因此能保持官方 sample 的最简形态。
 */
static void setup_environment(JNIEnv *env, jstring jhome, jstring jdata,
                              jstring jcache, jint jport, jstring jhost,
                              jboolean jlan, const char *logpath) {
    const char *home = jhome ? (*env)->GetStringUTFChars(env, jhome, NULL) : NULL;
    const char *data = jdata ? (*env)->GetStringUTFChars(env, jdata, NULL) : NULL;
    const char *cache = jcache ? (*env)->GetStringUTFChars(env, jcache, NULL) : NULL;
    const char *host = jhost ? (*env)->GetStringUTFChars(env, jhost, NULL) : NULL;
    char buf[1400];

    if (cache && *cache) {
        mkdir(cache, 0700);
        setenv("TMPDIR", cache, 1);
    }
    if (data && *data) {
        setenv("HOME", data, 1);
        setenv("OFM_HOME", data, 1);
        setenv("OFM_DATA_DIR", data, 1);
    }
    setenv("NODE_OPTIONS", "", 1);
    setenv("UV_THREADPOOL_SIZE", "4", 1);

    /*
     * ICU 兜底。Node 启动源码（src/node.cc）里：
     *   if (!i18n::InitializeICUDirectory(icu_data_dir)) {
     *     fprintf(stderr, "%s: could not initialize ICU ...", argv[0]);
     *     exit(9);
     *   }
     * 这是「无崩溃信号、atexit 触发、0.5 秒内静默消失」最经典的来源。
     * 官方 nodejs-mobile v18 是 --with-intl=none（不走这段），但社区 v22
     * 的 full-icu 构建需要 icudtl.dat。CI 会把 release 包里可能存在的
     * icudtl.dat 放进 assets 并释放到 nodeHome，这里只要指过去即可。
     */
    if (home && *home) {
        snprintf(buf, sizeof(buf), "%s/icudtl.dat", home);
        if (access(buf, F_OK) == 0) {
            setenv("NODE_ICU_DATA", home, 1);
        } else {
            snprintf(buf, sizeof(buf), "%s/icu/icudtl.dat", home);
            if (access(buf, F_OK) == 0) {
                snprintf(buf, sizeof(buf), "%s/icu", home);
                setenv("NODE_ICU_DATA", buf, 1);
            } else {
                /* 不要留一个指向不存在目录的值：那反而会让 small-icu 构建启动失败 */
                unsetenv("NODE_ICU_DATA");
            }
        }
        snprintf(buf, sizeof(buf), "%s/node_modules", home);
        setenv("NODE_PATH", buf, 1);
        chdir(home);
    }
    snprintf(buf, sizeof(buf), "%d", (int) jport);
    setenv("OFM_PORT", buf, 1);
    setenv("OFM_HOST", (host && *host) ? host : "127.0.0.1", 1);
    setenv("OFM_LAN_RELAY", jlan == JNI_TRUE ? "1" : "0", 1);

    {
        const char *icu = getenv("NODE_ICU_DATA");
        snprintf(buf, sizeof(buf),
                 "[dsh-node] env: TMPDIR=%s | HOME=%s | NODE_PATH=%s/node_modules | "
                 "NODE_ICU_DATA=%s | OFM_PORT=%d | OFM_HOST=%s | OFM_LAN_RELAY=%s",
                 (cache && *cache) ? cache : "(未设置)",
                 (data && *data) ? data : "(未设置)",
                 (home && *home) ? home : "(未设置)",
                 (icu && *icu) ? icu : "(未设置，构建为无 intl 时正常)",
                 (int) jport,
                 (host && *host) ? host : "127.0.0.1",
                 jlan == JNI_TRUE ? "1" : "0");
    }
    /* 只写一次：log_line 与 fprintf(stderr) 目标是同一个文件，双写会让日志出现两遍 env */
    log_line(logpath, buf);

    if (home) (*env)->ReleaseStringUTFChars(env, jhome, home);
    if (data) (*env)->ReleaseStringUTFChars(env, jdata, data);
    if (cache) (*env)->ReleaseStringUTFChars(env, jcache, cache);
    if (host) (*env)->ReleaseStringUTFChars(env, jhost, host);
}

JNIEXPORT jint JNICALL
Java_com_android_dsh_core_NodeBridge_nativeStart(
        JNIEnv *env, jclass cls, jobjectArray arguments,
        jstring jlib, jstring jworkdir, jstring jdata, jstring jcache,
        jint jport, jstring jhost, jboolean jlan, jstring jlog) {
    const char *libpath;
    void *handle;
    const char *found = NULL;
    void *sym;
    char **argv;
    jsize argc = 0;
    char logpath[1024] = {0};
    char tmp[256];
    int rc;

    (void) cls;
    redirect_output_to_file(env, jlog);
    if (jlog) {
        const char *lp = (*env)->GetStringUTFChars(env, jlog, NULL);
        if (lp) {
            snprintf(logpath, sizeof(logpath), "%s", lp);
            (*env)->ReleaseStringUTFChars(env, jlog, lp);
        }
    }

    log_line(logpath, "[dsh-node] nativeStart 进入，准备初始化环境");
    setup_environment(env, jworkdir, jdata, jcache, jport, jhost, jlan, logpath);

    /* 装崩溃捕获：必须在 node::Start 之前，且要先于 V8 自己的 signal 处理 */
    install_crash_handlers(logpath);

    libpath = (*env)->GetStringUTFChars(env, jlib, NULL);

    /*
     * ★ 首选：DT_NEEDED 直接绑定的符号（官方 getting-started 形态）。
     * CMake 已把 libnode.so 链接进 libdsh-node.so，Android linker 在加载
     * 本库时就完成了加载与符号绑定，进程里只有一份、同处 classloader
     * namespace。之前靠 dlopen(绝对路径) 拿符号，dlsym 虽成功但 V8
     * 初始化阶段在 dlopen 的 namespace 里会静默退出 —— 这是前几轮
     * 「符号探测 OK、node::Start 之后一行输出都没有」的主要嫌疑。
     */
    sym = NULL;
#ifdef DSH_LINK_LIBNODE
    if (&_ZN4node5StartEiPPc != NULL) {
        sym = (void *) &_ZN4node5StartEiPPc;
        found = "_ZN4node5StartEiPPc";
        log_line(logpath, "[dsh-node] 官方 DT_NEEDED 形态：libnode.so 已由 linker 加载并绑定符号");
    }
#endif
    if (!sym) {
        /* 兜底：先用 RTLD_NOLOAD 取已加载的那份（不产生第二份），再退 dlopen */
        handle = libpath ? dlopen(libpath, RTLD_NOW | RTLD_NOLOAD) : NULL;
        sym = find_start(handle, &found);
        if (sym) {
            log_line(logpath, "[dsh-node] 未走 DT_NEEDED，复用已加载的 libnode.so");
        } else {
            handle = libpath ? dlopen(libpath, RTLD_NOW | RTLD_GLOBAL) : NULL;
            if (!handle) {
                const char *err = dlerror();
                LOGE("dlopen(libnode.so) 失败：%s", err ? err : "未知原因");
                log_line(logpath, "[dsh-node] libnode.so 既未链接，dlopen 也失败");
                if (libpath) (*env)->ReleaseStringUTFChars(env, jlib, libpath);
                return -101;
            }
            sym = find_start(handle, &found);
            log_line(logpath, "[dsh-node] 警告：回退 dlopen 绝对路径（非官方形态，V8 可能初始化失败）");
        }
    }
    if (!sym) {
        LOGE("libnode.so 未导出 node::Start 符号");
        log_line(logpath, "[dsh-node] 未找到 node::Start 符号");
        if (libpath) (*env)->ReleaseStringUTFChars(env, jlib, libpath);
        return -102;
    }
    snprintf(tmp, sizeof(tmp), "[dsh-node] 使用符号 %s", found);
    log_line(logpath, tmp);

    argv = build_argv(env, arguments, &argc);
    if (!argv) {
        if (libpath) (*env)->ReleaseStringUTFChars(env, jlib, libpath);
        return -103;
    }

    snprintf(tmp, sizeof(tmp), "[dsh-node] 即将在 8MB 栈 pthread 上调用 node::Start(argc=%d)", (int) argc);
    log_line(logpath, tmp);
    {
        int i;
        for (i = 0; i < (int) argc; ++i) {
            snprintf(tmp, sizeof(tmp), "[dsh-node] argv[%d]=%s", i, argv[i]);
            log_line(logpath, tmp);
        }
    }
    log_line(logpath, "[dsh-node] 环境/参数就绪，进入 node::Start —— 若此后无任何输出，"
             "说明进程在 V8 原生初始化阶段崩溃（见崩溃信号行或 logcat tombstone）");

    /*
     * ★ 核心修复：显式 8MB 栈的原生 pthread。
     * 之前直接在 JNI 线程（Kotlin Thread，默认约 1MB 栈）上调用，
     * V8 初始化/JS 解析递归用栈稍深即 SIGSEGV，且原生 SIGSEGV 不走 stdio，
     * 表现为「日志停在 '即将调用' 之后、进程静默消失」。
     */
    {
        pthread_attr_t attr;
        pthread_t tid;
        node_thread_args args;
        args.sym = sym;
        args.argc = (int) argc;
        args.argv = argv;
        args.use4 = (strstr(found, "S1_") || strstr(found, "S0_")) ? 1 : 0;
        args.rc = 0;

        pthread_attr_init(&attr);
        if (pthread_attr_setstacksize(&attr, NODE_STACK_BYTES) != 0) {
            log_line(logpath, "[dsh-node] 警告：设置 8MB 栈失败，退回默认栈");
        }
        int perr = pthread_create(&tid, &attr, node_thread_main, &args);
        pthread_attr_destroy(&attr);
        if (perr == 0) {
            snprintf(tmp, sizeof(tmp), "[dsh-node] pthread 已创建（栈=%d MB），等待 Node 主循环",
                     NODE_STACK_BYTES / (1024 * 1024));
            log_line(logpath, tmp);
            pthread_join(tid, NULL);
            g_watchdog_run = 0;
            rc = args.rc;
        } else {
            log_line(logpath, "[dsh-node] pthread_create 失败，退回当前线程调用（栈可能不足）");
            if (args.use4) {
                char **empty = (char **) calloc(1, sizeof(char *));
                rc = ((NodeStart4) sym)((int) argc, argv, empty, empty);
                free(empty);
            } else {
                rc = ((NodeStart2) sym)((int) argc, argv);
            }
        }
    }

    snprintf(tmp, sizeof(tmp), "[dsh-node] node::Start 返回 rc=%d（Node 主循环已结束）", rc);
    log_line(logpath, tmp);
    LOGI("%s", tmp);

    /* argv buffer 由 node::Start 长期持有，仅在返回后才释放 */
    free(argv);
    if (libpath) (*env)->ReleaseStringUTFChars(env, jlib, libpath);
    return (jint) rc;
}
