# 聚合网关 → Cloudflare Workers AI 本地网关（cf-ai-gateway-r1）

## 一句话结论

**能做，而且几乎不用重写。** 这个壳本来就是「Android 里跑 Node 服务 → 只在 127.0.0.1 暴露 OpenAI 兼容端点 → RikkaHub 对接」，和我们要的本地代理是同一套契约。改造只把「加载上游 standalone」换成「加载 cf-proxy.cjs」，前台服务、唤醒锁、悬浮窗、开机自启、健康探活、RikkaHub 交接、二维码、日志自检**全部原样复用**。

不用 Termux、不用电脑常开、不碰 `*.workers.dev`；上游只访问 `api.cloudflare.com`（HTTPS），国内网络下已验证可达。

---

## 架构对照

| 层 | 原版 | 改造版 |
|---|---|---|
| 前台服务 / 保活 / 悬浮窗 / 开机自启 | GatewayService 等 | **一行未改** |
| Node 引擎 | libnode.so v22 + JNI | **一行未改**（仍需 CI 下载） |
| 启动入口 | bootstrap.cjs（找 standalone 入口） | bootstrap.cjs（直接 `require('./cf-proxy.cjs')`） |
| HTTP 服务 | 上游 packages/standalone（几百个文件、约 10 MB） | **cf-proxy.cjs 单文件、零依赖** |
| `/health` | 上游提供 | cf-proxy 提供（HealthProbe 依赖） |
| `/v1/models` | 上游提供 | cf-proxy 调 `ai/models/search` 后转成 OpenAI 形状 |
| `/v1/chat/completions` | 上游聚合 76 家渠道 | cf-proxy 原样转发到 Workers AI，SSE 透传 |
| `/` 管理页 | upstream WebView 完整管理页 | 极简页：状态 + 改配置 + 刷新模型缓存 |
| 应用内更新上游源码 | SourceUpdater 从 GitHub 拉源码 | **禁用**（会覆盖网关代码），点「恢复内置源码」仍可用 |

`gateway-runtime.json` 的字段（port / apiKey / manageUrl）完全兼容，`HealthProbe.awaitRuntime()` 的「apiKey 非空 + /health 200」判据也不用改。

---

## 改动文件清单

| 文件 | 处理 |
|---|---|
| `app/src/main/assets/node/bootstrap.cjs` | **重写**：去掉入口定位 / 引擎核对 / 符号链接实体化，改为加载 cf-proxy，回写实际端口与 Key |
| `app/src/main/assets/node/cf-proxy.cjs` | **新增**：本地 HTTP 网关核心（约 390 行，零 npm 依赖） |
| `app/src/main/assets/node/bundle-version.txt` | **新增** `cf-ai-gateway-r1`：与旧值不同，覆盖安装会强制重建 nodeHome |
| `app/src/main/assets/node/package.json` | **新增占位**：只为满足 AssetInstaller 的完整性判据 |
| `app/src/main/assets/node/packages/standalone/cli.mjs` | **新增占位**：同上；不会被加载 |
| `scripts/prepare-node-bundle.sh` | **重写**：不再 clone GitHub / npm install / 裁剪，只做离线校验，CI 流程不变 |
| `app/src/main/java/com/android/dsh/core/SourceUpdater.kt` | **精简**：`update()` 明确抛错，保留全部公开签名，MainActivity 无需改 |
| `.github/workflows/build.yml` | 第 6 步名称 + 构建前自检文案与判据改为 CF 版（不影响编译逻辑） |
| `CLOUDFLARE_README.md` | 本文件 |

**未改动**：全部其他 Kotlin / Java / C 胶水 / CMake / Manifest / 资源 / 图标 / Gradle 配置。

---

## 编译（沿用你原来的 GitHub Actions）

1. 把本工程包按原习惯命名为 `dsh_free_model_app.zip` 放到仓库根目录（zip 里套一层 `aggregate-gateway/`）；同时把改造后的 `.github/workflows/build.yml` **作为明文文件单独提交**到仓库根目录 —— GitHub 不会执行压缩包里的 workflow，zip 内那份只是备份。
2. 提交触发 Actions，或手动 Run workflow。若按钮文案仍是「更新上游源码」，那是 `strings.xml` 的旧文案，不影响功能；点下去会明确提示已禁用。
3. CI 会：解压 → 装 JDK/SDK/NDK → 跑改造后的 `prepare-node-bundle.sh`（离线校验）→ 下载 `libnode.so` → `assembleDebug` → 产出 `AggregateGateway-*.apk`。
4. 安装 APK（同意通知 / 悬浮窗 / 电池白名单权限），点**启动网关**。

> `libnode.so` 仍由 CI 从 nodejs-mobile Release 下载，这一步不变。改造只把 `assets/node` 从约 10 MB 上游源码降到 4 个文本文件，APK 体积主要仍是 libnode.so。

---

## RikkaHub 配置（和原版几乎一样）

| 项 | 值 |
|---|---|
| 供应商类型 | OpenAI |
| API Base Url | `http://127.0.0.1:18900/v1`（以主界面显示的端口为准，被占用会顺延） |
| API 路径 | `/chat/completions` |
| API Key | `Rikka-2026-CF-Proxy-Key-8f3b`（主界面可复制 / 扫二维码） |
| Response API | 关 |
| 回传历史思考过程 | 先关，跑稳再试 |
| 自定义 Header | 不需要 |

保存后进「模型」页，点「添加新模型」左侧带数字角标的图标即可**自动拉出全量模型列表**，不用再手查官网。

### 模型清单规则

- 只列 `task.name === Text Generation`，排掉 Embeddings / 分类 / 语音 / 决策模型
- 自动隐藏 `planned_deprecation_date` 在 30 天内的（例如 `@cf/google/gemma-2b-it-lora` 是 2026-11-20）
- 付费档模型（GLM 5.x、Kimi K2.6/2.7 等）不默认隐藏，但在 `metadata.paid_hint` 里标注；可在管理页配置里打开 `hideKnownPaid`
- 缓存 1 小时，`GET /v1/models?refresh=1` 或管理页「刷新模型清单」可强制刷新

---

## 令牌轮换（重要）

`cf-proxy.cjs` 里内置了账户 ID、API 令牌和本机 Key，方便开箱即用。但 **assets 不加密，拿到 APK 的人可以解出内置令牌**，所以：

1. 编译前建议先去 Cloudflare 控制台**轮换**令牌，把新值替换 `cf-proxy.cjs` 的 `DEFAULTS.apiToken`；
2. 或者装好后点主界面「打开管理页」→ 在页面里填新令牌 / 账户 ID / 本机 Key → 保存。覆盖值写入 APP 私有目录 `ofm-data/cf-config.json`（0600），优先级高于内置值，**不用重新编译**；
3. 改了「本机 API Key」后，回主界面点「停止网关 → 启动网关」，让状态栏与二维码更新；RikkaHub 里也要同步改 Key；
4. 改完点「刷新模型清单」清缓存。

配置优先级：环境变量 `CF_ACCOUNT_ID / CF_API_TOKEN / CF_PROXY_KEY` > `cf-config.json` > 内置默认值。

---

## 已知差异与风险

- **「更新上游源码」按钮点下去会提示失败**（源码不动），这是刻意的；改配置请用管理页。
- **「局域网中继」开关无效**：管理页 `/config` 不鉴权，改造版固定只监听 `127.0.0.1`，避免把配置接口暴露到局域网。
- 上游是 `api.cloudflare.com` 的 HTTPS，Node 用内置根证书，不依赖 Android 系统 CA；若网络层拦截该域名，网关会返回 502，日志在 `bootstrap.log`。
- `/v1/chat/completions` 只做透传，**不改写请求体**：RikkaHub 若发送 Workers AI 不支持的字段（如某些 Responses 参数），错误由上游原样返回。
- 免费档是否可用，官方目录没有标志；清单里的 `paid_hint` 是本地维护的小名单，随 Cloudflare 调整需要更新 `KNOWN_PAID`。
- Node 进程仍由 `:node` 独立进程承载，崩溃不会带崩 UI，日志体系（运行时自检 / 冒烟测试）全部保留。

---

## 验证清单（装好后）

| 检查 | 预期 |
|---|---|
| 主界面状态 | READY，显示端口 / Base URL / API Key |
| 「运行时自检」 | /health 200 |
| 「复制模型 ID」 | 能列出二十多个 `@cf/` 模型 |
| 管理页 `/` | 显示账户 ID / 令牌掩码、模型数量 |
| RikkaHub 测试连接 | 非流式 / 流式 / 工具调用按模型能力通过 |
| 手机浏览器或 Termux（可选） | `curl http://127.0.0.1:18900/health` 返回 `{"ok":true,...}` |

排查顺序：`bootstrap.log`（`[cf-proxy]` 行）→ `node-output.log` → `node-fatal.txt`。常见失败只有两类：`libnode.so` 没打进 APK（引擎层），或 Cloudflare 令牌失效 / 账户 ID 不是 32 位（上游 401 / 7003）。
