# CF网关 → Cloudflare Workers AI 本地网关（cf-ai-gateway-r3）

## 一句话结论

**能做，而且几乎不用重写。** 这个壳本来就是「Android 里跑 Node 服务 → 只在 127.0.0.1 暴露 OpenAI 兼容端点 → RikkaHub 对接」，和我们要的本地代理是同一套契约。改造只把「加载上游 standalone」换成「加载 cf-proxy.cjs」，前台服务、唤醒锁、悬浮窗、开机自启、健康探活、RikkaHub 交接、二维码、日志自检**全部原样复用**。

不用 Termux、不用电脑常开、不碰 `*.workers.dev`；上游只访问 `api.cloudflare.com`（HTTPS），国内网络下已验证可达。

---

## 架构对照

| 层 | 原版 | 改造版 |
|---|---|---|
| 前台服务 / 保活 / 悬浮窗 / 开机自启 | GatewayService 等 | **一行未改** |
| Node 引擎 | libnode.so v22 + JNI | **一行未改**（仍需 CI 下载） |
| 启动入口 | bootstrap.cjs（找 standalone 入口） | bootstrap.cjs（直接 `require('./cf-proxy.cjs')`） |
| HTTP 服务 | 上游 packages/standalone（几百个文件、约 10 MB） | **cf-proxy.cjs 单文件、零依赖** |
| `/health` | 上游提供 | cf-proxy 提供（HealthProbe 依赖） |
| `/v1/models` | 上游提供 | cf-proxy 调 `ai/models/search` 后转成 OpenAI 形状 |
| `/v1/chat/completions` | 上游聚合 76 家渠道 | cf-proxy 原样转发到 Workers AI，SSE 透传 |
| `/` 管理页 | upstream WebView 完整管理页 | 极简页：状态 + 改配置 + 刷新模型缓存 |
| 应用内更新上游源码 | SourceUpdater 从 GitHub 拉源码 | **禁用**（会覆盖网关代码），点「恢复内置源码」仍可用 |

`gateway-runtime.json` 的字段（port / apiKey / manageUrl）完全兼容，`HealthProbe.awaitRuntime()` 的「apiKey 非空 + /health 200」判据也不用改。

---

## 改动文件清单

| 文件 | 处理 |
|---|---|
| `app/src/main/assets/node/bootstrap.cjs` | **重写**：去掉入口定位 / 引擎核对 / 符号链接实体化，改为加载 cf-proxy，回写实际端口与 Key |
| `app/src/main/assets/node/cf-proxy.cjs` | **新增**：本地 HTTP 网关核心（约 390 行，零 npm 依赖） |
| `app/src/main/assets/node/bundle-version.txt` | **新增** `cf-ai-gateway-r3`：与旧值不同，覆盖安装会强制重建 nodeHome |
| `app/src/main/assets/node/package.json` | **新增占位**：只为满足 AssetInstaller 的完整性判据 |
| `app/src/main/assets/node/packages/standalone/cli.mjs` | **新增占位**：同上；不会被加载 |
| `scripts/prepare-node-bundle.sh` | **重写**：不再 clone GitHub / npm install / 裁剪，只做离线校验，CI 流程不变 |
| `app/src/main/java/com/android/cloudflare/core/SourceUpdater.kt` | **精简**：`update()` 明确抛错，保留全部公开签名，MainActivity 无需改 |
| `.github/workflows/build.yml` | 第 6 步名称 + 构建前自检文案与判据改为 CF 版（不影响编译逻辑） |
| `CLOUDFLARE_README.md` | 本文件 |

**未改动**：全部其他 Kotlin / Java / C 胶水 / CMake / Manifest / 资源 / 图标 / Gradle 配置。

---

## 编译（沿用你原来的 GitHub Actions）

1. 把本工程包按原习惯命名为 `dsh_free_model_app.zip` 放到仓库根目录（zip 里套一层 `aggregate-gateway/`）；同时把改造后的 `.github/workflows/build.yml` **作为明文文件单独提交**到仓库根目录 —— GitHub 不会执行压缩包里的 workflow，zip 内那份只是备份。
2. 提交触发 Actions，或手动 Run workflow。若按钮文案仍是「更新上游源码」，那是 `strings.xml` 的旧文案，不影响功能；点下去会明确提示已禁用。
3. CI 会：解压 → 装 JDK/SDK/NDK → 跑改造后的 `prepare-node-bundle.sh`（离线校验）→ 下载 `libnode.so` → `assembleDebug` → 产出 `AggregateGateway-*.apk`。
4. 安装 APK（同意通知 / 悬浮窗 / 电池白名单权限），点**启动网关**。

> `libnode.so` 仍由 CI 从 nodejs-mobile Release 下载，这一步不变。改造只把 `assets/node` 从约 10 MB 上游源码降到 4 个文本文件，APK 体积主要仍是 libnode.so。

---

## RikkaHub 配置（和原版几乎一样）

| 项 | 值 |
|---|---|
| 供应商类型 | OpenAI |
| API Base Url | `http://127.0.0.1:18900/v1`（以主界面显示的端口为准，被占用会顺延） |
| API 路径 | `/chat/completions` |
| API Key | `Rikka-2026-CF-Proxy-Key-8f3b`（主界面可复制 / 扫二维码） |
| Response API | 关 |
| 回传历史思考过程 | 先关，跑稳再试 |
| 自定义 Header | 不需要 |

保存后进「模型」页，点「添加新模型」左侧带数字角标的图标即可**自动拉出全量模型列表**，不用再手查官网。

### 模型清单规则

- 只列 `task.name === Text Generation`，排掉 Embeddings / 分类 / 语音 / 决策模型
- 自动隐藏 `planned_deprecation_date` 在 30 天内的（例如 `@cf/google/gemma-2b-it-lora` 是 2026-11-20）
- 付费档模型（GLM 5.x、Kimi K2.6/2.7 等）不默认隐藏，但在 `metadata.paid_hint` 里标注；可在管理页配置里打开 `hideKnownPaid`
- 缓存 1 小时，`GET /v1/models?refresh=1` 或管理页「刷新模型清单」可强制刷新

---

## 令牌轮换（重要）

`cf-proxy.cjs` 里内置了账户 ID、API 令牌和本机 Key，方便开箱即用。但 **assets 不加密，拿到 APK 的人可以解出内置令牌**，所以：

1. 编译前建议先去 Cloudflare 控制台**轮换**令牌，把新值替换 `cf-proxy.cjs` 的 `DEFAULTS.apiToken`；
2. 或者装好后点主界面「打开管理页」→ 在页面里填新令牌 / 账户 ID / 本机 Key → 保存。覆盖值写入 APP 私有目录 `ofm-data/cf-config.json`（0600），优先级高于内置值，**不用重新编译**；
3. 改了「本机 API Key」后，回主界面点「停止网关 → 启动网关」，让状态栏与二维码更新；RikkaHub 里也要同步改 Key；
4. 改完点「刷新模型清单」清缓存。

配置优先级：环境变量 `CF_ACCOUNT_ID / CF_API_TOKEN / CF_PROXY_KEY` > `cf-config.json` > 内置默认值。

---

## 已知差异与风险

- **「更新上游源码」按钮点下去会提示失败**（源码不动），这是刻意的；改配置请用管理页。
- **「局域网中继」开关无效**：管理页 `/config` 不鉴权，改造版固定只监听 `127.0.0.1`，避免把配置接口暴露到局域网。
- 上游是 `api.cloudflare.com` 的 HTTPS，Node 用内置根证书，不依赖 Android 系统 CA；若网络层拦截该域名，网关会返回 502，日志在 `bootstrap.log`。
- `/v1/chat/completions` 只做透传，**不改写请求体**：RikkaHub 若发送 Workers AI 不支持的字段（如某些 Responses 参数），错误由上游原样返回。
- 免费档是否可用，官方目录没有标志；清单里的 `paid_hint` 是本地维护的小名单，随 Cloudflare 调整需要更新 `KNOWN_PAID`。
- Node 进程仍由 `:node` 独立进程承载，崩溃不会带崩 UI，日志体系（运行时自检 / 冒烟测试）全部保留。

---

## 验证清单（装好后）

| 检查 | 预期 |
|---|---|
| 主界面状态 | READY，显示端口 / Base URL / API Key |
| 「运行时自检」 | /health 200 |
| 「复制模型 ID」 | 能列出二十多个 `@cf/` 模型 |
| 管理页 `/` | 显示账户 ID / 令牌掩码、模型数量 |
| RikkaHub 测试连接 | 非流式 / 流式 / 工具调用按模型能力通过 |
| 手机浏览器或 Termux（可选） | `curl http://127.0.0.1:18900/health` 返回 `{"ok":true,...}` |

排查顺序：`bootstrap.log`（`[cf-proxy]` 行）→ `node-output.log` → `node-fatal.txt`。常见失败只有两类：`libnode.so` 没打进 APK（引擎层），或 Cloudflare 令牌失效 / 账户 ID 不是 32 位（上游 401 / 7003）。

---

## r2 品牌改造（应用名曾用「限量网关」/ 用户图标 / 新包名）

| 项 | 旧值 | 新值 |
|---|---|---|
| 应用名 / 主页标题大字 / 通知 / 悬浮窗 / 页脚 | `聚合网关` | `限量网关`（r3 已改为 **`CF网关`**） |
| 包名 `namespace` / `applicationId` | `com.android.dsh` | **`com.android.cloudflare`** |
| 图标母版 | `docs/icon-source.png`（旧眼睛/轨道图） | **用户提供的漏斗 + 三色管道图** |
| 图标生成链 | `scripts/render_icon_preview.py` | **`scripts/render_icons.py`**（旧脚本已移除） |

### 三处图标全部同源

母版抠成透明底彩色主图 `drawable-nodpi/ic_gateway_art.png`（512²），再由它派生：

| 位置 | 引用 | 产物 |
|---|---|---|
| 桌面 / 启动器 | `@mipmap/ic_launcher` → adaptive 或 legacy | `ic_gateway_art` 为前景 + 浅色 `ic_gateway_bg`；API<26 用 `mipmap-*` 下 5 密度 PNG |
| 悬浮窗 | `R.drawable.ic_gateway_vector` + `ic_gateway_badge` | 同一张 `ic_gateway_art`，浅色圆角底 |
| 通知栏 | `.setLargeIcon(ic_gateway_art)` + `.setSmallIcon(ic_gateway_status)` | 大图标彩色；状态栏是白色硬边剪影，中间圆孔镂空 |

`ic_gateway_status.png` 单独生成是因为 Android 的 smallIcon **强制按 alpha 染色、忽略 RGB**，彩色位图会变成一坨白饼。`mipmap-anydpi-v26` 的 `<monochrome>` 也改指向这个剪影，Android 12+ 主题图标才正常。

主图缩到画布 64% 居中，是为了避开 adaptive icon 约 66% 的可见遮罩，三根管道末端不会被裁掉。`ic_gateway_bg.xml` / `ic_gateway_badge.xml` 一并改成浅灰白渐变，配透明底前景和深色文字；沿用原来的深蓝紫底会出现色块。

重新生成图标（改了母版后）：`python3 scripts/render_icons.py`，产物已提交进 `res/`，CI 不会重新生成。

### 改包名时同步处理的关键点

- **C 胶水的 JNI 函数名**必须从 `Java_com_android_dsh_core_NodeBridge_*` 改成 `Java_com_android_cloudflare_core_NodeBridge_*`（下划线形式，点分包名替换漏得到这一处）。符号对不上，`nativeStart` / `nativeProbe` 会抛 `UnsatisfiedLinkError`，Node 引擎完全起不来。
- 所有 Kotlin / Java 的 `package` 声明、`import`、`GatewayService` 的 `com.android.*.action.*` 常量、`proguard-rules.pro`、Gradle 的 `namespace` / `applicationId`、源码物理目录 `java/com/android/dsh/` 全部一起换掉。
- `AndroidManifest.xml` 的 FileProvider 用 `${applicationId}.fileprovider`，自动跟随，无需手改；主题名 `Theme.AggregateGateway` 是英文标识符，保持不变。
- CMake target / `System.loadLibrary("dsh-node")` / logcat tag `dsh-node` 是**库名不是包名**，不要替换。

### ⚠️ 换成新包名后必须做三件事

1. **卸载旧的 `com.android.dsh` APK**：包名变了，系统视为两个不同应用，不会覆盖安装，两个会并存且都抢 18900 端口。
2. **重新填 API 令牌**：新包名的私有目录是空的，旧包 `ofm-data/cf-config.json` 里保存的令牌不会迁移，APK 内置的仍是 `cfut_olMi…847f`（已失效）。装好后点「打开管理页」只填第二个框（Cloudflare API 令牌），另外两个留空 → 保存 → 回主界面复制模型 ID。
3. **RikkaHub 里重新确认配置**：Base Url / 本机 Key 没变，但建议重新复制一次并新开聊天。

新包名不影响 `127.0.0.1:18900` 这个回环地址，RikkaHub 侧不需要改端口。


---

## r3 应用名改为「CF网关」

| 项 | r2 | r3 |
|---|---|---|
| 应用显示名 / 桌面图标下文字 | `限量网关` | **`CF网关`** |
| 主页标题大字 | `限量网关` | **`CF网关`** |
| 通知标题 / 渠道名 / 悬浮窗描述 / 页脚 / 二维码配置文本 | `限量网关…` | **`CF网关…`** |
| `rootProject.name` / CI 标题 / 代码注释 | `限量网关` | **`CF网关`** |
| `bundle-version.txt` | `cf-ai-gateway-r3` | **`cf-ai-gateway-r3`** |

主页那行大字在 `MainActivity.kt` 里绑定的是 `getString(R.string.app_name)`，
所以本次只改了 `res/values/strings.xml` 的 `app_name` 一处，主页大字自动同步，
没有第二处硬编码需要改。

包名 `com.android.cloudflare`、图标、端口 `18900`、RikkaHub 配置**全部不变**。
`bundle-version.txt` 升到 r3 是为了覆盖安装时强制重建 `nodeHome`，避免新旧
assets 混用；私有目录 `ofm-data/cf-config.json` 里保存的令牌配置**不受影响**，
不需要重新填。
