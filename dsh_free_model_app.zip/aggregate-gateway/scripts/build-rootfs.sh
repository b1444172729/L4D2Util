#!/usr/bin/env bash
# =============================================================================
# 生成可在 Android(arm64) 上运行的 rootfs-arm64.tar.gz  ——  r2 修复版
#
# 修复 2026-11-11 run #246 的失败：
#   旧版只用「第一个能下到 Packages 索引」的镜像（清华 TUNA）去拼 deb URL，
#   且 curl 错误被 2>/dev/null 吞掉。一旦该镜像的 pool/ 路径不可用就整体失败：
#     [build-rootfs]   尝试 https://mirrors.tuna.tsinghua.edu.cn/.../proot_5.1.107.102_aarch64.deb
#     ❌ 下载 proot 失败
#
# 本版改动：
#   · Termux 官方源排第一（GitHub Actions 境外 runner 直连最稳），国内镜像作回退
#   · 【每个镜像独立走完整流程】下索引 → 解析 4 个包 → 下全部 deb → 全成功才采用，
#     任一失败立刻换下一个镜像，不再被单一镜像锁死
#   · 索引支持 Packages / Packages.gz / Packages.xz 三种格式
#   · deb URL 多路径拼接（仓库根 / dists 下 / 多一层 apt/termux-main）
#   · fetch_first 打印 HTTP 码与 curl 错误，不再盲失败
#   · libandroid-shmem 改为「建议但不致命」（部分 Termux 源已并入 proot 包）
#   · 支持手动兜底：若 /tmp/{proot,libtalloc,libandroid-shmem}.deb 已存在就直接用
#   · 其余（Ubuntu base / OpenCode v2 CLI / --skip-apt / 四件套自检 / SHA256）不变
#
# 用法：
#   bash build-rootfs.sh --skip-apt            # 无需 root / chroot
#   OC_VER=2.2.7 bash build-rootfs.sh --skip-apt
#   sudo -E bash build-rootfs.sh              # 完整版（含 git，需 root + arm64）
# =============================================================================
set -euo pipefail

ARCH="arm64"
OUT="rootfs-${ARCH}.tar.gz"
ROOT="rootfs-${ARCH}"
OC_VER="${OC_VER:-}"
SKIP_APT="${SKIP_APT:-0}"
for a in "$@"; do [ "$a" = "--skip-apt" ] && SKIP_APT=1; done

UBUNTU_MIRRORS=(
  "https://cdimage.ubuntu.com/ubuntu-base/releases/24.04/release/ubuntu-base-24.04.3-base-arm64.tar.gz"
  "https://mirrors.tuna.tsinghua.edu.cn/ubuntu-cdimage/ubuntu-base/releases/24.04/release/ubuntu-base-24.04.3-base-arm64.tar.gz"
  "https://mirrors.aliyun.com/ubuntu-cdimage/ubuntu-base/releases/24.04/release/ubuntu-base-24.04.3-base-arm64.tar.gz"
  "https://mirrors.ustc.edu.cn/ubuntu-cdimage/ubuntu-base/releases/24.04/release/ubuntu-base-24.04.3-base-arm64.tar.gz"
)
# ⚠ 官方源优先：run #246 里清华镜像的 Packages 能下、pool 里的 deb 却取不到。
TERMUX_MIRRORS=(
  "https://packages.termux.dev/apt/termux-main"
  "https://mirrors.tuna.tsinghua.edu.cn/termux/apt/termux-main"
  "https://mirrors.ustc.edu.cn/termux/apt/termux-main"
  "https://mirrors.aliyun.com/termux/apt/termux-main"
)
NPM_REGISTRIES=(
  "https://registry.npmjs.org"
  "https://registry.npmmirror.com"
)
GH_MIRRORS=(
  ""
  "https://gh-proxy.com/"
  "https://ghfast.top/"
  "https://ghproxy.net/"
)

log() { echo "[build-rootfs] $*"; }
die() { echo "❌ $*" >&2; exit 1; }

# 逐个尝试；打印 HTTP 码与 curl 错误，不再 2>/dev/null 全吞
fetch_first() {
  local dest="$1"; shift
  local u code
  for u in "$@"; do
    [ -z "$u" ] && continue
    log "  尝试 $u"
    : > /tmp/fetch.err
    code=$(curl -sSL --connect-timeout 12 --max-time 900 -A 'Mozilla/5.0' \
           -w '%{http_code}' "$u" -o "$dest" 2>/tmp/fetch.err || true)
    if { [ "$code" = "200" ] || [ "$code" = "206" ]; } && [ -s "$dest" ]; then
      log "  ✓ HTTP $code，拿到 $(du -h "$dest" | cut -f1)"
      return 0
    fi
    local err; err=$(tr '\n' ' ' < /tmp/fetch.err | cut -c1-140)
    log "  ✗ HTTP ${code:-无响应} $err"
    rm -f "$dest"
  done
  return 1
}

# ---------------------------------------------------------------- 0) 环境
log "架构：$(uname -m)（产物固定 arm64；若宿主非 aarch64，只有 --skip-apt 能跑）"
if [ "$SKIP_APT" = "0" ] && [ "$(id -u)" != "0" ]; then
  die "完整版需要 root（chroot + mount + apt）。改用 sudo -E bash $0，或加 --skip-apt。"
fi

rm -rf "$ROOT"
mkdir -p "$ROOT"

# ---------------------------------------------------------------- 1) Ubuntu base
log "1/7 下载 Ubuntu Base 24.04 arm64（glibc rootfs，约 28 MB）"
fetch_first /tmp/ubuntu-base.tar.gz "${UBUNTU_MIRRORS[@]}" \
  || die "Ubuntu base 所有镜像都不可达。可手动下载后放到 /tmp/ubuntu-base.tar.gz 再重跑。"
tar -xzf /tmp/ubuntu-base.tar.gz -C "$ROOT" || die "Ubuntu base 解包失败"
rm -f /tmp/ubuntu-base.tar.gz

# ---------------------------------------------------------------- 2) 基础目录
log "2/7 基础目录 / DNS / CA 证书"
mkdir -p "$ROOT/dev" "$ROOT/proc" "$ROOT/sys" "$ROOT/dev/pts" "$ROOT/tmp" "$ROOT/workspace"
chmod 1777 "$ROOT/tmp"
printf 'nameserver 223.5.5.5\nnameserver 8.8.8.8\n' > "$ROOT/etc/resolv.conf"
if [ -f /etc/ssl/certs/ca-certificates.crt ]; then
  mkdir -p "$ROOT/etc/ssl/certs"
  cp -f /etc/ssl/certs/ca-certificates.crt "$ROOT/etc/ssl/certs/ca-certificates.crt"
fi

# ---------------------------------------------------------------- 3) git（可选）
if [ "$SKIP_APT" = "0" ]; then
  log "3/7 chroot 安装 git（/api/vcs/init 需要真实 git）"
  cat > "$ROOT/etc/apt/sources.list" <<'SRC'
deb http://ports.ubuntu.com/ubuntu-ports noble main universe
deb http://ports.ubuntu.com/ubuntu-ports noble-updates main universe
SRC
  mount -t proc /proc "$ROOT/proc" 2>/dev/null || true
  mount --bind /dev "$ROOT/dev" 2>/dev/null || true
  if chroot "$ROOT" /bin/bash -c "export DEBIAN_FRONTEND=noninteractive; apt-get update -qq && apt-get install -y --no-install-recommends git ca-certificates" >/tmp/git-install.log 2>&1; then
    log "  ✓ git 已安装"
  else
    log "  ⚠ apt 安装 git 失败（不影响 bridge）："; sed -n '1,12p' /tmp/git-install.log || true
  fi
  umount "$ROOT/proc" 2>/dev/null || true
  umount "$ROOT/dev" 2>/dev/null || true
  rm -rf "$ROOT/var/lib/apt/lists"/* "$ROOT/var/cache/apt/archives"/*.deb 2>/dev/null || true
else
  log "3/7 跳过 git（--skip-apt）"
fi

# ---------------------------------------------------------------- 4) OpenCode CLI (v2)
log "4/7 获取 OpenCode v2 CLI（arm64）"
if [ -z "$OC_VER" ]; then
  for reg in "${NPM_REGISTRIES[@]}"; do
    OC_VER=$(curl -fsSL --connect-timeout 10 --max-time 20 "$reg/@opencode%2fcli-linux-arm64/latest" 2>/dev/null \
             | python3 -c 'import sys,json;print(json.load(sys.stdin).get("version",""))' 2>/dev/null || true)
    [ -n "$OC_VER" ] && break
  done
  OC_VER="${OC_VER:-2.2.7}"
fi
log "  目标版本：$OC_VER"

mkdir -p "$ROOT/opencode/bin" /tmp/ocpkg
OC_OK=0
for reg in "${NPM_REGISTRIES[@]}"; do
  if fetch_first /tmp/oc.tgz "$reg/@opencode/cli-linux-arm64/-/cli-linux-arm64-${OC_VER}.tgz"; then OC_OK=1; break; fi
done
if [ "$OC_OK" = "0" ]; then
  for pre in "${GH_MIRRORS[@]}"; do
    if fetch_first /tmp/oc.tgz "${pre}https://github.com/anomalyco/opencode/releases/download/v${OC_VER}/opencode-linux-arm64.tar.gz"; then OC_OK=1; break; fi
  done
fi
[ "$OC_OK" = "1" ] || die "拿不到 OpenCode CLI：npm 与 GitHub release 都不可达。可手动放到 /tmp/oc.tgz 再重跑。"

rm -rf /tmp/ocpkg && mkdir -p /tmp/ocpkg
tar -xzf /tmp/oc.tgz -C /tmp/ocpkg || die "CLI 包解包失败"
OC_BIN=$(find /tmp/ocpkg -type f -name 'opencode' | sed -n '1p')
[ -n "$OC_BIN" ] || die "CLI 包里找不到 opencode 可执行文件"
cp -f "$OC_BIN" "$ROOT/opencode/bin/opencode"
chmod 755 "$ROOT/opencode/bin/opencode"
log "  ✓ CLI $(du -h "$ROOT/opencode/bin/opencode" | cut -f1)"
rm -rf /tmp/oc.tgz /tmp/ocpkg

# ---------------------------------------------------------------- 5) Termux proot【本次修复重点】
log "5/7 获取 Termux 版 proot + loader + libtalloc + libandroid-shmem"
mkdir -p "$ROOT/proot/bin" "$ROOT/proot/lib" "$ROOT/proot/libexec"

extract_deb() { # debfile destdir
  python3 - "$1" "$2" <<'PY'
import sys, os, subprocess, tempfile
deb, dest = sys.argv[1], sys.argv[2]
d = open(deb, 'rb').read()
i = 8
while i < len(d):
    hdr = d[i:i+60]
    if len(hdr) < 60: break
    name = hdr[0:16].decode(errors='replace').strip().rstrip('/')
    try: size = int(hdr[48:58].decode().strip())
    except ValueError: break
    data = d[i+60:i+60+size]
    if name.startswith('data.tar'):
        ext = name.split('.', 1)[1] if '.' in name else 'tar'
        tmp = tempfile.mktemp(suffix='.' + ext)
        open(tmp, 'wb').write(data)
        os.makedirs(dest, exist_ok=True)
        subprocess.run(['tar', '-xf', tmp, '-C', dest], check=False)
        os.remove(tmp)
    i += 60 + size
    if i % 2: i += 1
PY
}

fn() { # pkg -> Filename（从 /tmp/tpkgs 解析）
  awk -v pkg="$1" '
    $1=="Package:" && $2==pkg {found=1; next}
    found && $1=="Filename:" {print $2; exit}
    found && $1=="Package:" {found=0}
  ' /tmp/tpkgs
}

PKGS=(proot libtalloc libandroid-shmem)
TERMUX_OK=0

for tm in "${TERMUX_MIRRORS[@]}"; do
  log "  ── 镜像：$tm"

  # ① 该镜像自己的索引（支持未压缩 / gz / xz）
  IDX=""
  for idx in Packages Packages.gz Packages.xz; do
    u="$tm/dists/stable/main/binary-aarch64/$idx"
    code=$(curl -sSL --connect-timeout 10 --max-time 120 -A 'Mozilla/5.0' \
           -w '%{http_code}' "$u" -o /tmp/tpkgs.raw 2>/dev/null || true)
    if [ "$code" = "200" ] && [ -s /tmp/tpkgs.raw ]; then
      case "$idx" in
        *.gz) gzip -dc /tmp/tpkgs.raw > /tmp/tpkgs 2>/dev/null || { continue; } ;;
        *.xz) xz -dc   /tmp/tpkgs.raw > /tmp/tpkgs 2>/dev/null || { continue; } ;;
        *)    cp /tmp/tpkgs.raw /tmp/tpkgs ;;
      esac
      IDX="$idx"; break
    fi
    log "     索引 $idx -> HTTP ${code:-无响应}"
  done
  if [ -z "$IDX" ]; then log "  ⚠ 该镜像索引不可达，换下一个"; continue; fi
  log "     索引格式：$IDX（$(wc -l < /tmp/tpkgs) 行）"

  # ② 解析每个包的 Filename
  declare -A PATHS=()
  BAD=0
  for p in "${PKGS[@]}"; do
    path=$(fn "$p")
    if [ -z "$path" ]; then
      log "  ⚠ 索引里找不到包 $p，换下一个镜像"
      BAD=1; break
    fi
    PATHS[$p]="$path"
    log "     $p -> $path"
  done
  [ "$BAD" = "0" ] || continue

  # ③ 下全部 deb：同一路径在多个前缀下尝试；任一失败就换镜像
  for p in "${PKGS[@]}"; do
    path="${PATHS[$p]}"
    # 手动兜底：用户预先放好的 deb 优先
    if [ -s "/tmp/$p.deb" ] && [ ! -f "/tmp/$p.deb.tried" ]; then
      log "     使用已存在的 /tmp/$p.deb（手动兜底）"
      : > "/tmp/$p.deb.tried"
    else
      # 标准 apt 布局：Filename 相对仓库根；部分镜像把 pool 放在 dists 下或多层目录
      urls=(
        "$tm/$path"
        "$tm/dists/stable/main/binary-aarch64/$path"
        "$tm/apt/termux-main/$path"
      )
      fetch_first "/tmp/$p.deb" "${urls[@]}" || { BAD=1; break; }
    fi
    rm -rf "/tmp/tx_$p"
    extract_deb "/tmp/$p.deb" "/tmp/tx_$p"
  done
  [ "$BAD" = "0" ] || { log "  ⚠ 该镜像有包下载失败，换下一个"; continue; }

  TERMUX_OK=1
  log "  ✅ 四件套来自镜像：$tm"
  break
done
[ "$TERMUX_OK" = "1" ] || die "所有 Termux 镜像都拿不到 proot 四件套。可手动把 proot.deb / libtalloc.deb / libandroid-shmem.deb 放到 /tmp/ 后重跑。"

P="/tmp/tx_proot/data/data/com.termux/files/usr"
[ -f "$P/bin/proot" ]            || die "proot.deb 里缺 bin/proot（包结构变了，请把日志贴出来）"
[ -f "$P/libexec/proot/loader" ] || die "proot.deb 里缺 libexec/proot/loader"
cp -f "$P/bin/proot"                  "$ROOT/proot/bin/proot"
cp -f "$P/libexec/proot/loader"       "$ROOT/proot/libexec/loader"
if [ -f "$P/libexec/proot/loader32" ]; then
  cp -f "$P/libexec/proot/loader32"   "$ROOT/proot/libexec/loader32"
fi
TL=$(find /tmp/tx_libtalloc -name 'libtalloc.so.*' -type f | sed -n '1p')
[ -n "$TL" ] || die "缺 libtalloc.so"
cp -f "$TL" "$ROOT/proot/lib/libtalloc.so.2"
SH=$(find /tmp/tx_libandroid-shmem -name 'libandroid-shmem.so*' -type f | sed -n '1p')
if [ -n "$SH" ]; then
  cp -f "$SH" "$ROOT/proot/lib/libandroid-shmem.so"
else
  log "  ⚠ 缺 libandroid-shmem.so（部分源已并入 proot 包）：APP 会告警，多数 ROM 仍可启动"
fi
chmod 755 "$ROOT/proot/bin/proot" "$ROOT/proot/libexec/"*
chmod 644 "$ROOT/proot/lib/"*.so*

# ---------------------------------------------------------------- 6) 清理
log "6/7 清理残留 .git 与缓存"
find "$ROOT" -name '.git' -type d -exec rm -rf {} + 2>/dev/null || true
rm -rf "$ROOT/var/tmp"/* 2>/dev/null || true
du -sh "$ROOT"

# ---------------------------------------------------------------- 7) 打包 + 校验
log "7/7 打包 $OUT（--hard-dereference 展开硬链接）"
tar -czf "$OUT" -C "$ROOT" --hard-dereference .
sha256sum "$OUT" > "$OUT.sha256"

log "校验四件套："
MISS=0
for f in opencode/bin/opencode proot/bin/proot proot/libexec/loader proot/lib/libtalloc.so.2; do
  if [ -f "$ROOT/$f" ]; then echo "  ✅ $f"; else echo "  ❌ $f"; MISS=1; fi
done
[ "$MISS" = "0" ] || die "四件套不齐，产物不可用"
for f in proot/lib/libandroid-shmem.so proot/libexec/loader32; do
  [ -f "$ROOT/$f" ] && echo "  ✅ $f（推荐）" || echo "  ⚠ $f（建议补上）"
done

HL=$(tar -tvf "$OUT" 2>/dev/null | awk '$1 ~ /^h/' | wc -l)
log "归档内硬链接条目：$HL（必须为 0）"
log "完成：$OUT ($(du -h "$OUT" | cut -f1))"
cat "$OUT.sha256"
