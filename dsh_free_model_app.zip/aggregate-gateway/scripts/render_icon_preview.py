#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
「聚合网关」图标生成器（r15：用户提供的「眼睛 / 轨道」图形）。

唯一数据源： docs/icon-source.png —— 2048×2048 高清母版（深蓝紫渐变底 + 图形）。
本脚本从它派生全部运行期图标资源：

  - res/drawable-nodpi/ic_gateway_art.png   图标位图（满幅构图 + 78% 安全区留边）
  - res/mipmap-*/ic_launcher.png            传统方形图标（API < 26）
  - res/mipmap-*/ic_launcher_round.png      传统圆形图标
  - res/drawable/ic_notification.xml        通知栏 smallIcon（彩色别名）
  - docs/icon-preview.png                   三格并排预览

设计要点
  1. r15 起三处图标「字节级同源」：
       mipmap-anydpi-v26/ic_launcher*.xml 的 <foreground>
       FloatingWindow.kt 的 setImageResource(R.drawable.ic_gateway_vector)
       GatewayService.kt 的 setSmallIcon(R.drawable.ic_notification)
     两个 drawable XML 都是 <bitmap android:src="@drawable/ic_gateway_art"/>，
     即都指向同一张 PNG。改图标只需换母版再跑一次本脚本。
  2. 不做单色剪影、不做抠像。r13/r14 曾把通知栏与 <monochrome> 改成白色
     alpha 剪影，理由写的是「系统禁止彩色 smallIcon」——这条是错的：
     Android 只是按 src_in 用 alpha 染色、忽略 RGB，彩色资源合法且旧版一直
     这么用（旧版 <monochrome> 就直接指向彩色 vector）。用户要求改回彩色、
     三处一模一样，故撤销剪影化。代价见 README：严格染色的 ROM 上，
     满幅不透明位图会被染成白色圆角方块；用户已确认接受。
  3. 前景位图直接使用母版本身（含深蓝紫渐变底）。差分/阈值抠像会把粗弧
     与实心圆的内部判成背景，只剩一圈空心描边，图形反而失真。
  4. adaptive icon 的 108dp 画布只有中心约 66dp 是安全区，前景缩到 78%
     并四周留透明边、四角做圆角；传统 PNG 为满幅构图。
  5. 半透明一律在独立 RGBA 图层上合成，避免「低 alpha 被当成不透明色」。

依赖：Pillow、numpy（仅构建图标时用，不参与 Android 编译）
用法： python3 scripts/render_icon_preview.py
"""
import os

try:
    import numpy as np
    from PIL import Image, ImageDraw, ImageFilter, ImageFont
except ImportError as e:
    raise SystemExit("需要 Pillow 与 numpy：pip install pillow numpy") from e

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
RES = os.path.join(ROOT, "app", "src", "main", "res")
DOCS = os.path.join(ROOT, "docs")
MASTER = os.path.join(DOCS, "icon-source.png")

for d in (RES, DOCS, os.path.join(RES, "drawable-nodpi")):
    os.makedirs(d, exist_ok=True)

DEEP = (12, 18, 46, 255)          # 页面/卡片底色，取母版暗部
FONT = None
for p in ("/usr/share/fonts/truetype/wqy/wqy-microhei.ttc",
          "/usr/share/fonts/wenquanyi/wqy-microhei.ttc",
          "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"):
    if os.path.exists(p):
        FONT = ImageFont.truetype(p, 22)
        break

# 两个 drawable XML 共用的 <bitmap> 别名内容
BITMAP_ALIAS = '''<bitmap xmlns:android="http://schemas.android.com/apk/res/android"
    android:src="@drawable/ic_gateway_art" />
'''


def rounded(im, radius):
    """给 RGBA 图加圆角 alpha 蒙版。"""
    mask = Image.new("L", im.size, 0)
    ImageDraw.Draw(mask).rounded_rectangle(
        [0, 0, im.width - 1, im.height - 1], radius=radius, fill=255)
    out = im.copy()
    out.putalpha(Image.composite(im.getchannel("A"), Image.new("L", im.size, 0), mask))
    return out


def make_foreground(master, size=1024, scale=0.78):
    """完整母版（含底色）缩到 scale，四角圆角，四周留透明边。"""
    inner = int(size * scale)
    art = master.convert("RGBA").resize((inner, inner), Image.Resampling.LANCZOS)
    art = rounded(art, int(inner * 0.20))
    canvas = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    canvas.alpha_composite(art, ((size - inner) // 2, (size - inner) // 2))
    return canvas


def make_status_icon(master, size=192):
    """状态栏 smallIcon 专用：透明底 + 白色轨道图形。

    系统会把 smallIcon 按 alpha 用 src_in 染色、忽略 RGB，所以不能用带
    不透明深蓝紫底的主图（会染成一整块白饼）。这里按颜色族把青/紫轨道
    与实心圆从母版里取出来，做成白色 alpha 图形——形状与主图同源，
    状态栏里显示为白色轨道，而不是旧的信号塔，也不是白块。
    """
    a = np.asarray(master.convert("RGB")).astype(np.int16)
    r, g, b = a[:, :, 0], a[:, :, 1], a[:, :, 2]
    cyan = (g > 105) & (b > 125) & (r < 175)
    purple = (r > 52) & (b > 100) & (b > g * 1.30) & (r > g * 1.05)
    deep_blue = (b > 90) & (g > 33) & (b > r * 2)
    mask = (cyan | purple | deep_blue)
    m = Image.fromarray((mask * 255).astype(np.uint8), "L")
    m = m.filter(ImageFilter.MaxFilter(5)).filter(ImageFilter.MinFilter(5))
    m = m.filter(ImageFilter.MinFilter(3)).filter(ImageFilter.MaxFilter(3))
    m = m.filter(ImageFilter.MedianFilter(3)).filter(ImageFilter.GaussianBlur(0.6))
    white = Image.new("RGBA", master.size, (255, 255, 255, 255))
    white.putalpha(m)
    # 裁到图形包围盒再留 8% 边距，小尺寸下才够醒目
    bb = m.getbbox()
    white = white.crop(bb)
    inner = int(size * 0.84)
    white = white.resize((inner, inner), Image.Resampling.LANCZOS)
    canvas = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    canvas.alpha_composite(white, ((size - inner) // 2, (size - inner) // 2))
    return canvas


def write_icon_aliases():
    """生成/刷新两个彩色 <bitmap> 别名，保证三处引用同一张 PNG。

    ic_gateway_vector.xml 同时被 adaptive <foreground>、<monochrome> 与悬浮球引用；
    ic_notification.xml 被 GatewayService.setSmallIcon() 引用。两者内容相同，
    只是文件注释不同，便于在各自上下文里读懂。
    """
    vector = '''<?xml version="1.0" encoding="utf-8"?>
<!--
  聚合网关 / APP 图标与悬浮窗图标共用的唯一图形资源（r15）。

  用户提供的「眼睛 / 轨道」图形已重制为 2048×2048 高清母版
  docs/icon-source.png，由 scripts/render_icon_preview.py 派生出
  drawable-nodpi/ic_gateway_art.png（缩到 78%、四角圆角、四周留透明边）。

  这里用 <bitmap> 指向它，而不是用 vector 重描：位图能 1:1 保留原图的
  青色轨道渐变、紫色弧渐变与深蓝紫背景，避免矢量只能取纯色造成的色差。
  adaptive <foreground>、<monochrome>、悬浮球 ImageView 都引用本文件。

  r15：通知栏 smallIcon 的 ic_notification.xml 也是同一个 <bitmap> 别名，
  因此 APP 图标 / 悬浮窗 / 通知栏三处字节级同源、完全一样。
-->
''' + BITMAP_ALIAS

    notification = '''<?xml version="1.0" encoding="utf-8"?>
<!--
  兼容别名：指向状态栏 smallIcon 专用资源 ic_gateway_status。

  r16 起 GatewayService.buildNotification() 不再引用本文件，改为：
    .setSmallIcon(R.drawable.ic_gateway_status)   ← 透明底白色轨道，染色后形状正确
    .setLargeIcon(ic_gateway_art 的彩色 Bitmap)   ← 通知头部显示彩色主图
  保留本文件仅为兼容旧引用；保留彩色 <bitmap> 语义，不再当作 smallIcon 使用。
-->
''' + BITMAP_ALIAS

    for name, content in (("ic_gateway_vector.xml", vector),
                          ("ic_notification.xml", notification)):
        out = os.path.join(RES, "drawable", name)
        with open(out, "w", encoding="utf-8", newline="\n") as f:
            f.write(content)
        print(f"彩色别名 → {out}")


def make_preview(master, fg, status):
    """四格并排预览：APP / 悬浮窗 / 通知头部彩色大图 / 状态栏单色小图。"""
    W, H = 1640, 420
    page = Image.new("RGBA", (W, H), DEEP)
    d = ImageDraw.Draw(page)

    side = 256
    art = fg.resize((side, side), Image.Resampling.LANCZOS)

    # 桌面图标（启动器圆角遮罩）
    tile = Image.new("RGBA", (side, side), (14, 20, 52, 255))
    tile.alpha_composite(art)
    tile = rounded(tile, int(side * 0.22))
    page.alpha_composite(tile, (40, 78))

    # 悬浮球（圆角更小）
    ball = Image.new("RGBA", (side, side), (14, 20, 52, 255))
    ball.alpha_composite(art)
    ball = rounded(ball, int(side * 0.16))
    page.alpha_composite(ball, (40 + side + 120, 78))

    # 通知栏：深色横条 + 同一张彩色图标（模拟未强制染色时的观感）
    nx = 40 + 2 * (side + 120)
    bar = Image.new("RGBA", (256, 96), (26, 32, 72, 255))
    bar = rounded(bar, 18)
    page.alpha_composite(bar, (nx, 78 + 20))
    small = fg.resize((80, 80), Image.Resampling.LANCZOS)
    page.alpha_composite(small, (nx + 10, 78 + 20 + 8))
    if FONT:
        d.text((nx + 100, 78 + 20 + 34), "聚合网关", font=FONT,
               fill=(220, 228, 248, 255))

    # 第四格：状态栏（单色小图标，系统按 alpha 染色后的实际观感）
    sx = 40 + 3 * (side + 120)
    sbar = Image.new("RGBA", (256, 96), (26, 32, 72, 255))
    sbar = rounded(sbar, 18)
    page.alpha_composite(sbar, (sx, 78 + 20))
    st = status.resize((48, 48), Image.Resampling.LANCZOS)
    page.alpha_composite(st, (sx + 18, 78 + 20 + 24))
    if FONT:
        d.text((sx + 80, 78 + 20 + 34), "17:24  95%", font=FONT,
               fill=(220, 228, 248, 255))

    if FONT:
        for x, cap in ((40, "APP 图标"), (40 + side + 120, "悬浮窗图标"),
                       (nx, "通知头部（彩色大图）"),
                       (sx, "状态栏（单色小图）")):
            d.text((x, 352), cap, font=FONT, fill=(228, 235, 255, 255))
    return page.convert("RGB")


def main():
    if not os.path.isfile(MASTER):
        raise SystemExit(f"缺少高清母版：{MASTER}")
    master = Image.open(MASTER).convert("RGBA")
    if master.width != master.height:
        raise SystemExit("母版必须是正方形")
    print(f"母版：{MASTER}  {master.width}×{master.height}")

    fg = make_foreground(master)
    art_path = os.path.join(RES, "drawable-nodpi", "ic_gateway_art.png")
    fg.save(art_path, optimize=True)
    print(f"图标位图 → {art_path}  {fg.width}×{fg.height}")

    status = make_status_icon(master)
    status_path = os.path.join(RES, "drawable-nodpi", "ic_gateway_status.png")
    status.save(status_path, optimize=True)
    print(f"状态栏图标 → {status_path}  {status.width}×{status.height}（透明底）")

    write_icon_aliases()

    # r15：不再生成单色剪影资源
    stale = os.path.join(RES, "drawable-nodpi", "ic_gateway_mono.png")
    if os.path.isfile(stale):
        os.remove(stale)
        print(f"已移除 r13/r14 的单色剪影 → {stale}")

    densities = {
        "mdpi": 48, "hdpi": 72, "xhdpi": 96,
        "xxhdpi": 144, "xxxhdpi": 192,
    }
    for name, side in densities.items():
        folder = os.path.join(RES, f"mipmap-{name}")
        os.makedirs(folder, exist_ok=True)
        sq = master.resize((side, side), Image.Resampling.LANCZOS).convert("RGBA")
        sq.save(os.path.join(folder, "ic_launcher.png"), optimize=True)

        # 圆形传统图标：外部透明，圆内为完整构图
        mask = Image.new("L", (side * 4, side * 4), 0)
        ImageDraw.Draw(mask).ellipse([0, 0, side * 4 - 1, side * 4 - 1], fill=255)
        mask = mask.resize((side, side), Image.Resampling.LANCZOS)
        circ = sq.copy()
        circ.putalpha(mask)
        circ.save(os.path.join(folder, "ic_launcher_round.png"), optimize=True)
        print(f"  mipmap-{name:8s} {side}×{side}  方形 + 圆形")

    preview = make_preview(master, fg, status)
    out = os.path.join(DOCS, "icon-preview.png")
    preview.save(out, optimize=True)
    print(f"预览 → {out}")


if __name__ == "__main__":
    main()
