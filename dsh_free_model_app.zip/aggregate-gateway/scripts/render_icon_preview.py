#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
按用户提供的参考图重绘「聚合网关」图标，并生成：
  - docs/icon-preview.png                    并排预览（APP 图标 / 悬浮球）
  - res/mipmap-*/ic_launcher.png             传统图标（API < 26 兼容，满幅构图）
  - res/mipmap-*/ic_launcher_round.png       圆形传统图标

几何与 res/drawable/ic_gateway_vector.xml 完全同源（108×108 坐标系）。
矢量版在 adaptive icon 里用 <group scale=0.8> 收进安全区；PNG 为方形传统图标，满幅。

半透明元素必须画在独立 RGBA 图层上再 alpha_composite —— 直接在 RGBA 底图上
用 ImageDraw(mode="RGBA") 写 (r,g,b,a<255) 会「替换」而非「混合」，导出 RGB 后
低 alpha 会被当成纯色，正是背景亮带变粗白带的原因。

依赖：Pillow、numpy（仅构建图标时用，不参与 Android 编译）
"""
import os

try:
    import numpy as np
    from PIL import Image, ImageDraw, ImageFont
except ImportError as e:
    raise SystemExit("需要 Pillow 与 numpy：pip install pillow numpy") from e

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
RES = os.path.join(ROOT, "app", "src", "main", "res")
DOCS = os.path.join(ROOT, "docs")
os.makedirs(DOCS, exist_ok=True)

# ------------------------------------------------------------------ 配色
C_START = (44, 201, 168)   # 左上 青绿
C_MID = (18, 166, 206)    # 中间 青蓝
C_END = (11, 111, 204)    # 右下 蓝

def opaque(rgb):
    return (rgb[0], rgb[1], rgb[2], 255)

WHITE = opaque((255, 255, 255))
TOWER = opaque((234, 247, 255))
TOWER_SHADE = opaque((214, 238, 250))
ROPE = opaque((240, 252, 255))
ORANGE = opaque((255, 168, 43))
ORANGE_EDGE = opaque((232, 135, 12))

# 半透明（只在独立 RGBA 图层上绘制）
GLARE = (255, 255, 255, 20)
GLARE2 = (255, 255, 255, 13)
CYAN_75 = (205, 246, 240, 205)
CYAN_55 = (180, 242, 233, 175)
CYAN_35 = (185, 242, 234, 85)
SHADOW = (10, 105, 130, 95)

FONT = None
for p in ("/usr/share/fonts/truetype/wqy/wqy-microhei.ttc",
          "/usr/share/fonts/wenquanyi/wqy-microhei.ttc",
          "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"):
    if os.path.exists(p):
        FONT = ImageFont.truetype(p, 20)
        break


# ------------------------------------------------------------------ 渐变底
def gradient(size):
    yy, xx = np.mgrid[0:size, 0:size].astype(np.float32)
    t = np.clip((xx + yy) / (2.0 * max(1, size - 1)), 0.0, 1.0)[..., None]
    a = np.array(C_START, np.float32)
    b = np.array(C_MID, np.float32)
    c = np.array(C_END, np.float32)
    first = a + (b - a) * np.clip(t / 0.5, 0, 1)
    second = b + (c - b) * np.clip((t - 0.5) / 0.5, 0, 1)
    rgb = np.where(t < 0.5, first, second).astype(np.uint8)
    return Image.fromarray(rgb, "RGB").convert("RGBA")


def round_mask(size, radius_ratio):
    m = Image.new("L", (size, size), 0)
    ImageDraw.Draw(m).rounded_rectangle(
        [0, 0, size - 1, size - 1], radius=int(size * radius_ratio), fill=255)
    return m


def lerp_pts(p0, p1, p2, n=28):
    out = []
    for i in range(n + 1):
        t = i / n
        u = 1 - t
        out.append((u * u * p0[0] + 2 * u * t * p1[0] + t * t * p2[0],
                    u * u * p0[1] + 2 * u * t * p1[1] + t * t * p2[1]))
    return out


class Canvas:
    """把 108×108 设计坐标映射到输出像素"""
    def __init__(self, img, scale, ox=0.0, oy=0.0):
        self.d = ImageDraw.Draw(img, "RGBA")
        self.s = scale
        self.ox, self.oy = ox, oy

    def p(self, x, y):
        return (x * self.s + self.ox, y * self.s + self.oy)

    def stroke(self, pts, color, w, cap=True):
        q = [self.p(*v) for v in pts]
        ww = max(1, int(round(w * self.s)))
        self.d.line(q, fill=color, width=ww, joint="curve")
        if cap and q:
            r = ww / 2.0
            for (x, y) in (q[0], q[-1]):
                self.d.ellipse([x - r, y - r, x + r, y + r], fill=color)

    def q(self, p0, p1, p2, color, w):
        self.stroke(lerp_pts(p0, p1, p2), color, w)

    def line(self, p0, p1, color, w):
        self.stroke([p0, p1], color, w)

    def circle(self, cx, cy, r, fill, outline=None, ow=0):
        x, y = self.p(cx, cy)
        rr = r * self.s
        self.d.ellipse([x - rr, y - rr, x + rr, y + rr], fill=fill,
                       outline=outline, width=max(1, int(ow * self.s)) if outline else 1)

    def poly(self, pts, fill):
        self.d.polygon([self.p(*v) for v in pts], fill=fill)


# ------------------------------------------------------------------ 三层绘制
def paint_back(c):
    """最底层：极淡的斜向亮带 + 塔基阴影"""
    c.q((-10, 72), (40, 30), (118, 8), GLARE, 14)
    c.q((-10, 94), (45, 50), (118, 30), GLARE2, 10)
    c.q((10, 108), (60, 74), (118, 62), GLARE2, 8)
    c.poly([(29, 101), (54, 97), (79, 101), (54, 105)], SHADOW)


def paint_solid(c):
    """不透明主体：波纹、塔、桥、吊索、橙点"""
    # 1) 塔顶六道信号波纹（左右各三条，由内到外变长）
    c.q((31, 5), (18, 27), (33, 50), WHITE, 4.0)
    c.q((77, 5), (90, 27), (75, 50), WHITE, 4.0)
    c.q((39, 11), (27, 27), (40, 43), WHITE, 3.8)
    c.q((69, 11), (81, 27), (68, 43), WHITE, 3.8)
    c.q((44, 17), (36, 27), (44, 37), WHITE, 3.4)
    c.q((64, 17), (72, 27), (64, 37), WHITE, 3.4)

    # 2) 塔顶圆球
    c.circle(54, 27.2, 6.6, WHITE)
    c.q((47.6, 29.5), (54, 34.2), (60.4, 29.5), TOWER_SHADE, 1.6)

    # 3) 塔身桁架
    c.line((50.8, 34), (36.5, 98), TOWER, 4.2)
    c.line((57.2, 34), (71.5, 98), TOWER, 4.2)
    for y, x0, x1 in [(42, 48.8, 59.2), (56, 45.5, 62.5),
                      (70, 42, 66), (86, 38.5, 69.5)]:
        c.line((x0, y), (x1, y), TOWER, 3.0)
    cells = [
        ((50.8, 34), (59.2, 42), (57.2, 34), (48.8, 42)),
        ((48.8, 42), (62.5, 56), (59.2, 42), (45.5, 56)),
        ((45.5, 56), (66, 70), (62.5, 56), (42, 70)),
        ((42, 70), (69.5, 86), (66, 70), (38.5, 86)),
        ((38.5, 86), (71.5, 98), (69.5, 86), (36.5, 98)),
    ]
    for a, b, d, e in cells:
        c.line(a, b, TOWER, 2.9)
        c.line(d, e, TOWER, 2.9)
    c.stroke([(54, 36.5), (58.5, 41), (54, 45.5), (49.5, 41), (54, 36.5)],
             WHITE, 1.8)

    # 4) 吊索（细白竖线，落在桥面之前）
    for x, top in [(19, 60), (25, 58.5), (31, 58.5), (37, 60.5), (43, 63.5),
                   (65, 63.5), (71, 60.5), (77, 58.5), (83, 58.5), (89, 60)]:
        c.line((x, top), (x, 78), ROPE, 1.3)

    # 5) 桥面（白色圆头横带）+ 两端加厚端帽
    c.line((10, 80), (98, 80), WHITE, 4.2)
    c.line((9, 80), (20, 80), WHITE, 5.4)
    c.line((88, 80), (99, 80), WHITE, 5.4)

    # 6) 立柱与底座横杠
    c.line((13, 62), (13, 88), WHITE, 3.4)
    c.line((95, 62), (95, 88), WHITE, 3.4)
    c.line((9, 88), (17, 88), WHITE, 3.6)
    c.line((91, 88), (99, 88), WHITE, 3.6)



def paint_front(c):
    """最上层：浅青半透明的悬索缆带与两侧小信号弧"""
    c.q((13, 62), (32, 56), (54, 67), CYAN_75, 4.4)
    c.q((54, 67), (76, 56), (95, 62), CYAN_75, 4.4)
    c.q((13, 64), (32, 59), (54, 69), CYAN_35, 2.4)
    c.q((54, 69), (76, 59), (95, 64), CYAN_35, 2.4)
    c.q((5, 59), (13, 51), (21, 59), CYAN_55, 2.4)
    c.q((2, 56), (13, 45), (24, 56), CYAN_55, 2.4)
    c.q((87, 59), (95, 51), (103, 59), CYAN_55, 2.4)
    c.q((84, 56), (95, 45), (106, 56), CYAN_55, 2.4)
    # 橙色立柱顶帽放在最上层，保证圆点完整可见
    c.circle(13, 62.7, 3.3, ORANGE, ORANGE_EDGE, 0.6)
    c.circle(95, 62.7, 3.3, ORANGE, ORANGE_EDGE, 0.6)


def make_icon(size, zoom=1.0, rounded=0.0):
    base_scale = size / 108.0
    s = base_scale * zoom
    ox = oy = (1 - zoom) * 54 * base_scale

    bg = gradient(size)
    back = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    front = Image.new("RGBA", (size, size), (0, 0, 0, 0))

    paint_back(Canvas(back, s, ox, oy))
    out = Image.alpha_composite(bg, back)
    paint_solid(Canvas(out, s, ox, oy))
    paint_front(Canvas(front, s, ox, oy))
    out = Image.alpha_composite(out, front)

    if rounded:
        out.putalpha(round_mask(size, rounded))
    return out.convert("RGBA")


def preview():
    W, H = 820, 440
    img = Image.new("RGB", (W, H), (246, 248, 252))
    d = ImageDraw.Draw(img)
    for icon, pos in [(make_icon(320, zoom=0.8, rounded=0.22), (44, 68)),
                      (make_icon(256, zoom=0.8, rounded=0.24), (470, 100))]:
        img.paste(icon.convert("RGB"), pos, icon.getchannel("A"))

    def label(x, y, t):
        d.text((x, y), t, font=FONT, fill=(27, 36, 54)) if FONT else d.text((x, y), t, fill=(27, 36, 54))

    label(44, 26, "聚合网关 · APP 图标（自适应前景 + 渐变底）")
    label(470, 26, "悬浮窗 · 同一个 drawable")
    label(44, 404, "信号塔 + 悬索桥 + 六道信号波纹 · 两处共用 R.drawable.ic_gateway_vector")
    out = os.path.join(DOCS, "icon-preview.png")
    img.save(out)
    print("预览:", out)


def legacy_pngs():
    for name, px in [("mdpi", 48), ("hdpi", 72), ("xhdpi", 96),
                     ("xxhdpi", 144), ("xxxhdpi", 192)]:
        folder = os.path.join(RES, "mipmap-" + name)
        os.makedirs(folder, exist_ok=True)
        make_icon(px, zoom=1.0, rounded=0.0).save(os.path.join(folder, "ic_launcher.png"))
        make_icon(px, zoom=0.92, rounded=0.5).save(os.path.join(folder, "ic_launcher_round.png"))
        print("  mipmap-%s: %dpx" % (name, px))


if __name__ == "__main__":
    preview()
    legacy_pngs()
    print("完成")
