#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
「聚合网关」图标生成器（r13：用户提供的「眼睛 / 轨道」图形）。

唯一数据源： docs/icon-source.png —— 2048×2048 高清母版（深蓝紫渐变底 + 图形）。
本脚本从它派生全部运行期图标资源，保证 APP 图标、圆形图标、悬浮球、
自适应图标前景四者构图、配色完全一致：

  - res/drawable-nodpi/ic_gateway_art.png   透明底前景（adaptive foreground / 悬浮球 src）
  - res/mipmap-*/ic_launcher.png            传统方形图标（API < 26）
  - res/mipmap-*/ic_launcher_round.png      传统圆形图标
  - docs/icon-preview.png                   并排预览

设计要点
  1. APP 图标与悬浮窗图标引用同一个资源 R.drawable.ic_gateway_vector，
     该文件已改为 <bitmap> 指向 ic_gateway_art.png，因此两处天然同步。
  2. 前景位图直接使用母版本身（含深蓝紫渐变底），不做抠像：
     差分/阈值抠像会把粗弧与实心圆的「内部」判成背景，只剩一圈空心描边，
     图形反而失真。母版自带底色，与 ic_gateway_bg / ic_gateway_badge 的
     深蓝紫渐变同色系，叠加后边角过渡自然，且图形与参考图逐像素一致。
  3. adaptive icon 的 108dp 画布只有中心约 66dp 是安全区，前景缩到 78%
     并四周留透明边、四角做圆角；传统 PNG 为满幅构图。
  4. 半透明一律在独立 RGBA 图层上合成，避免「低 alpha 被当成不透明色」。

依赖：Pillow、numpy（仅构建图标时用，不参与 Android 编译）
用法： python3 scripts/render_icon_preview.py
"""
import os

try:
    import numpy as np
    from PIL import Image, ImageDraw, ImageFilter, ImageFont
except ImportError as e:
    raise SystemExit("需要 Pillow 与 numpy：pip install pillow numpy") from e

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
RES = os.path.join(ROOT, "app", "src", "main", "res")
DOCS = os.path.join(ROOT, "docs")
MASTER = os.path.join(DOCS, "icon-source.png")

for d in (RES, DOCS, os.path.join(RES, "drawable-nodpi")):
    os.makedirs(d, exist_ok=True)

DEEP = (12, 18, 46, 255)          # 页面/卡片底色，取母版暗部
FONT = None
for p in ("/usr/share/fonts/truetype/wqy/wqy-microhei.ttc",
          "/usr/share/fonts/wenquanyi/wqy-microhei.ttc",
          "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"):
    if os.path.exists(p):
        FONT = ImageFont.truetype(p, 22)
        break


def rounded(im, radius):
    """给 RGBA 图加圆角 alpha 蒙版。"""
    mask = Image.new("L", im.size, 0)
    ImageDraw.Draw(mask).rounded_rectangle(
        [0, 0, im.width - 1, im.height - 1], radius=radius, fill=255)
    out = im.copy()
    out.putalpha(Image.composite(im.getchannel("A"), Image.new("L", im.size, 0), mask))
    return out


def make_foreground(master, size=1024, scale=0.78):
    """完整母版（含底色）缩到 scale，四角圆角，四周留透明边。"""
    inner = int(size * scale)
    art = master.convert("RGBA").resize((inner, inner), Image.Resampling.LANCZOS)
    art = rounded(art, int(inner * 0.20))
    canvas = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    canvas.alpha_composite(art, ((size - inner) // 2, (size - inner) // 2))
    return canvas


def make_monochrome(master, size=512, scale=0.78):
    """生成纯白 alpha 剪影，供 Android 13+ 主题图标（monochrome）使用。

    按颜色族分类而非「与背景做差分」：后者会把粗弧/实心圆的内部判成背景，
    只剩一圈空心描边。青、紫、深蓝三组阈值能连内部一起取到。
    """
    a = np.asarray(master.convert("RGB")).astype(np.int16)
    r, g, b = a[:, :, 0], a[:, :, 1], a[:, :, 2]
    cyan = (g > 105) & (b > 125) & (r < 175)
    # 紫色弧是亮紫 → 深紫渐变，阈值要放宽到能把最外侧那条弧的内部取到
    purple = (r > 52) & (b > 100) & (b > g * 1.30) & (r > g * 1.05)
    deep_blue = (b > 90) & (g > 33) & (b > r * 2)
    mask = (cyan | purple | deep_blue)
    m = Image.fromarray((mask * 255).astype(np.uint8), "L")
    # 闭运算：补掉渐变弧内部的细小空洞，同时抹掉背景里的孤立噪点
    m = m.filter(ImageFilter.MaxFilter(5)).filter(ImageFilter.MinFilter(5))
    # 开运算：去掉背景里残留的孤立小亮点，粗弧不受影响
    m = m.filter(ImageFilter.MinFilter(3)).filter(ImageFilter.MaxFilter(3))
    m = m.filter(ImageFilter.MedianFilter(3)).filter(ImageFilter.GaussianBlur(0.6))
    white = Image.new("RGBA", master.size, (255, 255, 255, 255))
    white.putalpha(m)

    inner = int(size * scale)
    white = white.resize((inner, inner), Image.Resampling.LANCZOS)
    canvas = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    canvas.alpha_composite(white, ((size - inner) // 2, (size - inner) // 2))
    return canvas


def make_notification_vector(mono):
    """把白色 alpha 剪影转成通知栏用的 24×24 vector pathData。

    通知栏 smallIcon 必须是单色 alpha 图形（系统按 src_in 染色），
    且要够简洁才在状态栏的小尺寸下可辨。做法：对剪影做轮廓提取
    （RETR_TREE 保留孔洞层级）→ 按面积滤掉噪点 → approxPolyDP 简化
    → 裁到图形包围盒等比映射进 24 viewport 的 [1.2, 22.8] 安全区。
    所有轮廓串进一个 path 并声明 fillType="evenOdd"，孔洞自动镂空。
    """
    try:
        import cv2
    except ImportError:
        raise SystemExit("生成通知栏图标需要 opencv-python：pip install opencv-python-headless")

    arr = np.asarray(mono.convert("RGBA"))
    mask = (arr[:, :, 3] > 128).astype(np.uint8) * 255
    ys, xs = np.where(mask > 0)
    x0, x1, y0, y1 = xs.min(), xs.max(), ys.min(), ys.max()
    sub = mask[y0:y1 + 1, x0:x1 + 1]
    h, w = sub.shape
    side = max(h, w)
    canvas = np.zeros((side, side), np.uint8)
    canvas[(side - h) // 2:(side - h) // 2 + h,
           (side - w) // 2:(side - w) // 2 + w] = sub

    cnts, _ = cv2.findContours(canvas, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    min_area = side * side * 0.0008
    kept = [c for c in cnts if cv2.contourArea(c) >= min_area]

    margin, span, eps = 1.2, 24.0 - 2.4, 1.4
    scale = span / side
    paths = []
    for c in kept:
        ap = cv2.approxPolyDP(c, eps, True).reshape(-1, 2)
        if len(ap) < 3:
            continue
        pts = [(margin + float(x) * scale, margin + float(y) * scale) for x, y in ap]
        paths.append("M%.2f,%.2f " % pts[0] +
                     " ".join("L%.2f,%.2f" % p for p in pts[1:]) + "Z")
    return " ".join(paths), len(kept)


def write_notification_drawable(mono):
    path_data, n = make_notification_vector(mono)
    xml = f'''<?xml version="1.0" encoding="utf-8"?>
<!--
  通知栏小图标：系统要求单色 alpha 图形（按 src_in 染成白/深色），
  不能用彩色的 ic_gateway_vector，否则会显示成一块白饼。

  本文件由 scripts/render_icon_preview.py 自动生成，请勿手工编辑：
  取 ic_gateway_mono.png 的白色剪影做轮廓提取（RETR_TREE 保留孔洞）、
  按面积滤噪、approxPolyDP 简化，再映射进 24×24 viewport 的安全区。
  当前共 {n} 段轮廓；fillType="evenOdd" 保证椭圆轨道内部正确镂空。
-->
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">

    <path
        android:fillColor="#FFFFFFFF"
        android:fillType="evenOdd"
        android:pathData="{path_data}" />
</vector>
'''
    out = os.path.join(RES, "drawable", "ic_notification.xml")
    with open(out, "w", encoding="utf-8", newline="\n") as f:
        f.write(xml)
    print(f"通知栏图标 → {out}  {n} 段轮廓 / {len(path_data)} 字符")
    return path_data


def make_preview(master, fg, mono):
    """并排预览：APP 图标 / 悬浮球 / 通知栏小图标。"""
    W, H = 1240, 420
    page = Image.new("RGBA", (W, H), DEEP)
    d = ImageDraw.Draw(page)

    side = 256
    art = fg.resize((side, side), Image.Resampling.LANCZOS)
    positions = [(40, 78), (40 + side + 120, 78)]
    captions = ["APP 图标", "悬浮窗图标"]

    # 桌面图标（启动器圆角遮罩）
    tile = Image.new("RGBA", (side, side), (14, 20, 52, 255))
    tile.alpha_composite(art)
    tile = rounded(tile, int(side * 0.22))
    page.alpha_composite(tile, positions[0])

    # 悬浮球（圆角更小）
    ball = Image.new("RGBA", (side, side), (14, 20, 52, 255))
    ball.alpha_composite(art)
    ball = rounded(ball, int(side * 0.16))
    page.alpha_composite(ball, positions[1])

    # 通知栏：深色横条 + 白色剪影小图标（模拟状态栏）
    nx = 40 + 2 * (side + 120)
    bar = Image.new("RGBA", (256, 96), (26, 32, 72, 255))
    bar = rounded(bar, 18)
    page.alpha_composite(bar, (nx, 78 + 20))
    small = mono.resize((80, 80), Image.Resampling.LANCZOS)
    page.alpha_composite(small, (nx + 10, 78 + 20 + 8))
    if FONT:
        d.text((nx + 96, 78 + 20 + 34), "聚合网关", font=FONT, fill=(220, 228, 248, 255))
    captions.append("通知栏小图标")

    if FONT:
        for (x, _), cap in zip(positions, captions[:2]):
            d.text((x, 352), cap, font=FONT, fill=(228, 235, 255, 255))
        d.text((nx, 352), captions[2], font=FONT, fill=(228, 235, 255, 255))
    return page.convert("RGB")


def main():
    if not os.path.isfile(MASTER):
        raise SystemExit(f"缺少高清母版：{MASTER}")
    master = Image.open(MASTER).convert("RGBA")
    if master.width != master.height:
        raise SystemExit("母版必须是正方形")
    print(f"母版：{MASTER}  {master.width}×{master.height}")

    fg = make_foreground(master)
    art_path = os.path.join(RES, "drawable-nodpi", "ic_gateway_art.png")
    fg.save(art_path, optimize=True)
    print(f"图标前景 → {art_path}  {fg.width}×{fg.height}")

    mono = make_monochrome(master)
    mono_path = os.path.join(RES, "drawable-nodpi", "ic_gateway_mono.png")
    mono.save(mono_path, optimize=True)
    print(f"单色剪影 → {mono_path}  {mono.width}×{mono.height}")

    write_notification_drawable(mono)

    densities = {
        "mdpi": 48, "hdpi": 72, "xhdpi": 96,
        "xxhdpi": 144, "xxxhdpi": 192,
    }
    for name, side in densities.items():
        folder = os.path.join(RES, f"mipmap-{name}")
        os.makedirs(folder, exist_ok=True)
        sq = master.resize((side, side), Image.Resampling.LANCZOS).convert("RGBA")
        sq.save(os.path.join(folder, "ic_launcher.png"), optimize=True)

        # 圆形传统图标：外部透明，圆内为完整构图
        mask = Image.new("L", (side * 4, side * 4), 0)
        ImageDraw.Draw(mask).ellipse([0, 0, side * 4 - 1, side * 4 - 1], fill=255)
        mask = mask.resize((side, side), Image.Resampling.LANCZOS)
        circ = sq.copy()
        circ.putalpha(mask)
        circ.save(os.path.join(folder, "ic_launcher_round.png"), optimize=True)
        print(f"  mipmap-{name:8s} {side}×{side}  方形 + 圆形")

    preview = make_preview(master, fg, mono)
    out = os.path.join(DOCS, "icon-preview.png")
    preview.save(out, optimize=True)
    print(f"预览 → {out}")


if __name__ == "__main__":
    main()
