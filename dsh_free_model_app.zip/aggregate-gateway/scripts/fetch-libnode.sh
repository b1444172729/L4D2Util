#!/usr/bin/env bash
# 放置 nodejs-mobile 的 arm64 运行时。
#
# 只需要 libnode.so：Java 桥接层是本工程自建的 NodeBridge.java +
# app/src/main/cpp/dsh-node.c（CMake 编译成 libdsh-node.so），
# 不依赖 nodejs-mobile React Native 插件的任何 aar。
#
# 用法： ./scripts/fetch-libnode.sh <release-zip-下载URL> [sha256]
#
# ★ 上游 packages/standalone 根 package.json 声明
#     engines.node = "^22.19.0 || >=24.0.0"
#   cli.mjs 在 Node 18 下会抛
#     Cannot read properties of undefined (reading 'bind')
#   后安静返回、不 listen，表现为「入口已加载但 18900 ECONNREFUSED」。
#   官方 nodejs-mobile/nodejs-mobile 的 Android 产物停在 v18.20.4
#   （--with-intl=none），**不能用**。
#
#   推荐：OpenFlun/nodejs-mobile Releases 的 android-libnode.zip
#     https://github.com/OpenFlun/nodejs-mobile/releases
#     https://gitee.com/OpenFlun/nodejs-mobile/releases   （国内镜像）
#   当前版本 v22.23.2，arm64-v8a/libnode.so 约 113 MB，带 full-icu。
#   ⚠️ 该仓库还有一个 **v18.20.4 基线 release**，资产名同样是
#   android-libnode.zip（59.6 MB 的 v18 .so）。必须选 tag v22.23.2，
#   不要取「第一个 android-libnode 资产」。workflow 已按 major>=22 过滤。
#
# 脚本会校验 ELF 为 64 位 AArch64、读出二进制内嵌的 Node 版本、
# 检查 node::Start 导出符号，然后（r8）用 llvm-strip --strip-unneeded
# 去掉符号表以缩小 APK：只删 .symtab / 调试信息，保留 .dynsym 里的
# node::Start 导出符号，CMake 的 DT_NEEDED 链接不受影响，且带自动回滚。
#
# r8：v22.23.2 的 ICU 数据已内嵌在 libnode.so 里，release 若另带
# icudtl.dat 属于重复（约 31 MB 未压缩 / 12 MB 压缩后），默认跳过；
# 只有 KEEP_EXTERNAL_ICU=1（确为 small-icu 构建）才复制进 assets/node/。
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
URL="${1:-${NODE_MOBILE_URL:-}}"
EXPECTED_SHA="${2:-${NODE_MOBILE_SHA256:-}}"

if [[ -z "$URL" ]]; then
  echo "用法: $0 <nodejs-mobile release zip URL> [sha256]" >&2
  echo "请从 nodejs-mobile Releases 页面取得 arm64-v8a 产物 URL 后传入。" >&2
  exit 1
fi

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
echo "==> 下载 $URL"
curl -fL --retry 3 -o "$TMP/release.zip" "$URL"

if [[ -n "$EXPECTED_SHA" ]]; then
  ACTUAL="$(sha256sum "$TMP/release.zip" | cut -d' ' -f1)"
  [[ "$ACTUAL" == "$EXPECTED_SHA" ]] || { echo "SHA256 校验失败：$ACTUAL" >&2; exit 1; }
  echo "==> SHA256 校验通过"
fi

mkdir -p "$TMP/unzip"
python3 - <<PY
import zipfile, os
with zipfile.ZipFile(r"$TMP/release.zip") as z:
    z.extractall(r"$TMP/unzip")
PY

JNI="$ROOT/app/src/main/jniLibs/arm64-v8a"
LIBS="$ROOT/app/libs"
mkdir -p "$JNI" "$LIBS"

python3 - <<PY
import os, shutil, hashlib
KEEP_ICU = os.environ.get("KEEP_EXTERNAL_ICU") == "1"
src = r"$TMP/unzip"
jni = r"$JNI"
libs = r"$LIBS"
assets = r"$ROOT/app/src/main/assets/node"
os.makedirs(assets, exist_ok=True)
found = {"libnode.so": False, "libc++_shared.so": False, "aar": False,
         "headers": False, "icudtl.dat": False}
for base, _, files in os.walk(src):
    for f in files:
        p = os.path.join(base, f)
        if f == "libnode.so" and "arm64" in p and not found["libnode.so"]:
            shutil.copy2(p, os.path.join(jni, "libnode.so")); found["libnode.so"] = True
        # 若 release 自带 STL，优先用它（与 libnode.so 同批次编译，版本最匹配）
        elif f == "libc++_shared.so" and not found["libc++_shared.so"]:
            shutil.copy2(p, os.path.join(jni, "libc++_shared.so")); found["libc++_shared.so"] = True
        # full-icu 构建需要 icudtl.dat；Node 启动源码里 ICU 初始化失败会
        # fprintf(stderr, ...) 后直接 exit(9)。打进 assets 后 C 胶水会
        # setenv("NODE_ICU_DATA", nodeHome)，避免静默 exit。
        elif f == "icudtl.dat" and KEEP_ICU and not found["icudtl.dat"]:
            shutil.copy2(p, os.path.join(assets, "icudtl.dat")); found["icudtl.dat"] = True
        elif f.endswith(".aar") and not found["aar"]:
            shutil.copy2(p, os.path.join(libs, f)); found["aar"] = True
        elif f.endswith(".h") and "include/node" in p and not found["headers"]:
            os.makedirs(os.path.join(libs, "include/node"), exist_ok=True)
            found["headers"] = True
print("==> 命中：", found)
if not found["libnode.so"]:
    raise SystemExit("未在 release 包中找到 arm64 的 libnode.so，请确认下载的是 Android arm64 产物")

# ---- 二进制核对：必须是 64 位 AArch64 的 ELF ----
p = os.path.join(jni, "libnode.so")
h = open(p, "rb").read(20)
size_mb = os.path.getsize(p) / 1024.0 / 1024.0
sha = hashlib.sha256(open(p, "rb").read()).hexdigest()
is_elf = h[:4] == b"\x7fELF"
is64 = len(h) > 4 and h[4] == 2
machine = h[18] | (h[19] << 8) if len(h) >= 20 else 0
arch = {0xB7: "AArch64", 0x3E: "x86_64", 0x28: "ARMv7"}.get(machine, hex(machine))
print(f"==> libnode.so: {size_mb:.1f} MB | ELF={is_elf} | 64位={is64} | arch={arch} | sha256={sha[:16]}…")
if not (is_elf and is64 and machine == 0xB7):
    raise SystemExit(f"libnode.so 不是 arm64 的 64 位 ELF（arch={arch}），拒绝打包")
if found["icudtl.dat"]:
    print("==> r8：KEEP_EXTERNAL_ICU=1，icudtl.dat 已放入 assets/node/")
elif not KEEP_ICU:
    print("==> r8：跳过外部 icudtl.dat（v22 已内嵌 full-icu，属重复数据）")
else:
    print("==> r8：release 未含 icudtl.dat（v22 已内嵌 full-icu，正常）")

# ---- 运行时版本识别：直接从二进制里读出内嵌的 process.version ----
# 这是构建期唯一能确认「这次到底打进去的是 v18 还是 v22」的信号。
# 前面十几轮反复失败，正是因为界面一直显示 v18.20.4 却没人核对来源。
blob = open(p, "rb").read()
import re as _re
vers = sorted({m.group(0).decode() for m in _re.finditer(rb"v(\d{2})\.(\d+)\.(\d+)", blob)},
              key=lambda s: tuple(int(x) for x in s[1:].split(".")), reverse=True)
runtime_ver = vers[0] if vers else "(未识别)"
major = int(runtime_ver[1:].split(".")[0]) if runtime_ver.startswith("v") else 0
if major >= 22:
    print(f"==> 运行时 Node 版本（二进制内嵌）：{runtime_ver} ✅ 满足上游 engines.node")
elif major > 0:
    print(f"::warning::运行时 Node 版本（二进制内嵌）为 {runtime_ver}，低于上游要求的 ^22.19.0 || >=24.0.0。")
    print("::warning::standalone 会抛 (reading 'bind') 后不监听端口。")
    print("::warning::请换 OpenFlun/nodejs-mobile 的 **v22.23.2** tag 下的 android-libnode.zip；")
    print("::warning::注意该仓库还有个 v18.20.4 基线 release，资产同名，别选错。")
else:
    print("::notice::未能从二进制识别版本字符串，请对照上面的体积判断：v22 arm64 约 113 MB，v18 约 47 MB。")

# ---- node::Start 导出符号检查（v22 若改了签名，编译前就能发现）----
syms = ["_ZN4node5StartEiPPc", "_ZN4node5StartEiPPcS1_S1_", "node_Start", "node_start"]
hit = [s for s in syms if s.encode() in blob]
if hit:
    print("==> node::Start 导出符号命中：" + ", ".join(hit))
else:
    print("::warning::未在二进制中找到 node::Start 候选符号，装上后可能报符号未导出；")
    print("::warning::请把实际符号名发回，C 胶水的候选表需要补一行。")
PY

# ---------------------------------------------------------------------------
# ★ r8：llvm-strip --strip-unneeded 缩小 libnode.so。
#   Node 官方 .so 带完整 .symtab / 调试符号，通常占未压缩体积三到五成。
#   --strip-unneeded 只删本地符号表，保留 .dynsym（node::Start 是动态导出），
#   .text / .rodata / V8 snapshot 全部不动；CMake 的 IMPORTED SHARED 链接
#   与运行时 dlopen 回退都仍可用。丢符号或工具失败一律回滚原始文件。
# ---------------------------------------------------------------------------
SO="$JNI/libnode.so"
BEFORE="$(stat -c%s "$SO")"
STRIP_BIN="$(command -v llvm-strip || true)"
if [[ -z "$STRIP_BIN" ]]; then
  SDK_ROOT="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-${ANDROID_SDK:-}}}"
  NDK_VER="${NDK_VERSION:-27.0.12077973}"
  for c in \
    "$SDK_ROOT/ndk/$NDK_VER/toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-strip" \
    "$SDK_ROOT/ndk/$NDK_VER/toolchains/llvm/prebuilt/darwin-x86_64/bin/llvm-strip"; do
    [[ -x "$c" ]] && { STRIP_BIN="$c"; break; }
  done
fi
if [[ -n "$STRIP_BIN" && -x "$STRIP_BIN" ]]; then
  cp "$SO" "$TMP/libnode.orig.so"
  if "$STRIP_BIN" --strip-unneeded "$SO" 2>"$TMP/strip.err"; then
    if grep -aq '_ZN4node5StartEiPPc' "$SO"; then
      AFTER="$(stat -c%s "$SO")"
      echo "==> r8 strip 完成：$STRIP_BIN"
      echo "    $(( BEFORE/1048576 )) MB → $(( AFTER/1048576 )) MB（减少 $(( (BEFORE-AFTER)/1048576 )) MB）"
      echo "    node::Start 动态导出符号仍在 ✅"
    else
      cp "$TMP/libnode.orig.so" "$SO"
      echo "::warning::r8：strip 后 node::Start 符号消失，已回滚原始 libnode.so"
    fi
  else
    cp "$TMP/libnode.orig.so" "$SO"
    echo "::warning::r8：llvm-strip 失败，已回滚；原因：$(head -c 200 "$TMP/strip.err")"
  fi
else
  echo "==> r8：未找到 llvm-strip，跳过（不影响编译，APK 会大一些）"
fi

# ---------------------------------------------------------------------------
# ★ libnode.so 是 C++ 库，DT_NEEDED 里有 libc++_shared.so。
# 本工程胶水是纯 C，AGP 不会自动打包这份 STL；缺失时 dlopen 会报
#   library "libc++_shared.so" not found ... in namespace classloader-namespace
# release 里通常不带它，因此从 NDK 复制同架构的一份随 APK 打包。
# ---------------------------------------------------------------------------
if [[ ! -f "$JNI/libc++_shared.so" ]]; then
  SDK_ROOT="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-${ANDROID_SDK:-}}}"
  NDK_VER="${NDK_VERSION:-27.0.12077973}"
  SRC=""
  for c in \
    "$SDK_ROOT/ndk/$NDK_VER/toolchains/llvm/prebuilt/linux-x86_64/sysroot/usr/lib/aarch64-linux-android/libc++_shared.so" \
    "$SDK_ROOT/ndk/$NDK_VER/sources/cxx-stl/llvm-libc++/libs/arm64-v8a/libc++_shared.so"; do
    [[ -f "$c" ]] && { SRC="$c"; break; }
  done
  if [[ -z "$SRC" && -n "$SDK_ROOT" && -d "$SDK_ROOT/ndk" ]]; then
    SRC="$(find "$SDK_ROOT/ndk" -type f -name 'libc++_shared.so' \
      \( -path '*aarch64-linux-android*' -o -path '*arm64-v8a*' \) 2>/dev/null \
      | head -n1 || true)"
  fi
  if [[ -n "$SRC" && -f "$SRC" ]]; then
    cp "$SRC" "$JNI/libc++_shared.so"
    echo "==> 从 NDK 补齐 STL：$SRC"
  else
    echo "==> 警告：未能从 NDK 找到 libc++_shared.so（SDK_ROOT=${SDK_ROOT:-未设置}）。" >&2
    echo "    请把该文件放进 app/src/main/jniLibs/arm64-v8a/，否则装上后 dlopen 会失败。" >&2
    echo "    CI 构建由 workflow 的同名步骤兜底，不会走到这里。" >&2
  fi
fi

echo "==> 完成："
echo "    $JNI/libnode.so（$(du -h "$JNI/libnode.so" | cut -f1)，已按 r8 strip）"
echo "    $JNI/libc++_shared.so（$([ -f "$JNI/libc++_shared.so" ] && echo 已就位 || echo '缺失，需手动补')）"
echo "    Java 桥接层由本工程 CMake 编译，无需在 $LIBS/ 放任何 aar"
