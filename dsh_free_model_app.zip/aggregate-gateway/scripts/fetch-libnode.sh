#!/usr/bin/env bash
# 放置 nodejs-mobile 的 arm64 运行时。
#
# 只需要 libnode.so：Java 桥接层是本工程自建的 NodeBridge.java +
# app/src/main/cpp/dsh-node.c（CMake 编译成 libdsh-node.so），
# 不依赖 nodejs-mobile React Native 插件的任何 aar。
#
# 用法： ./scripts/fetch-libnode.sh <release-zip-下载URL> [sha256]
#   release 页面： https://github.com/nodejs-mobile/nodejs-mobile/releases
#   请选择带 Android arm64-v8a 产物的版本，并把该产物 zip 的 URL 传进来。
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
URL="${1:-${NODE_MOBILE_URL:-}}"
EXPECTED_SHA="${2:-${NODE_MOBILE_SHA256:-}}"

if [[ -z "$URL" ]]; then
  echo "用法: $0 <nodejs-mobile release zip URL> [sha256]" >&2
  echo "请从 nodejs-mobile Releases 页面取得 arm64-v8a 产物 URL 后传入。" >&2
  exit 1
fi

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
echo "==> 下载 $URL"
curl -fL --retry 3 -o "$TMP/release.zip" "$URL"

if [[ -n "$EXPECTED_SHA" ]]; then
  ACTUAL="$(sha256sum "$TMP/release.zip" | cut -d' ' -f1)"
  [[ "$ACTUAL" == "$EXPECTED_SHA" ]] || { echo "SHA256 校验失败：$ACTUAL" >&2; exit 1; }
  echo "==> SHA256 校验通过"
fi

mkdir -p "$TMP/unzip"
python3 - <<PY
import zipfile, os
with zipfile.ZipFile(r"$TMP/release.zip") as z:
    z.extractall(r"$TMP/unzip")
PY

JNI="$ROOT/app/src/main/jniLibs/arm64-v8a"
LIBS="$ROOT/app/libs"
mkdir -p "$JNI" "$LIBS"

python3 - <<PY
import os, shutil
src = r"$TMP/unzip"
jni = r"$JNI"
libs = r"$LIBS"
found = {"libnode.so": False, "aar": False, "headers": False}
for base, _, files in os.walk(src):
    for f in files:
        p = os.path.join(base, f)
        if f == "libnode.so" and "arm64" in p and not found["libnode.so"]:
            shutil.copy2(p, os.path.join(jni, "libnode.so")); found["libnode.so"] = True
        elif f.endswith(".aar") and not found["aar"]:
            shutil.copy2(p, os.path.join(libs, f)); found["aar"] = True
        elif f.endswith(".h") and "include/node" in p and not found["headers"]:
            os.makedirs(os.path.join(libs, "include/node"), exist_ok=True)
            found["headers"] = True
print("==> 命中：", found)
if not found["libnode.so"]:
    raise SystemExit("未在 release 包中找到 arm64 的 libnode.so，请确认下载的是 Android arm64 产物")
PY

echo "==> 完成：$JNI/libnode.so"
echo "    Java 桥接层由本工程 CMake 编译，无需在 $LIBS/ 放任何 aar"
