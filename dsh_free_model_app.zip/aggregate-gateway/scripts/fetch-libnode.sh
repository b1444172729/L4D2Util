#!/usr/bin/env bash
# 放置 nodejs-mobile 的 arm64 运行时。
#
# 只需要 libnode.so：Java 桥接层是本工程自建的 NodeBridge.java +
# app/src/main/cpp/dsh-node.c（CMake 编译成 libdsh-node.so），
# 不依赖 nodejs-mobile React Native 插件的任何 aar。
#
# 用法： ./scripts/fetch-libnode.sh <release-zip-下载URL> [sha256]
#   release 页面： https://github.com/nodejs-mobile/nodejs-mobile/releases
#   推荐固定官方核心库 v18.20.4 的 nodejs-mobile-v18.20.4-android.zip
#   （GitHub workflow 已按此精确锁定；不要用「最新任意 android 资产」，
#    社区 fork 的 full-icu 构建启动行为与官方 sample 不同）。
#   脚本会校验 ELF 为 64 位 AArch64，并把 release 里可能存在的 icudtl.dat
#   放进 assets/node/，供 full-icu 构建在启动时通过 NODE_ICU_DATA 找到。
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
URL="${1:-${NODE_MOBILE_URL:-}}"
EXPECTED_SHA="${2:-${NODE_MOBILE_SHA256:-}}"

if [[ -z "$URL" ]]; then
  echo "用法: $0 <nodejs-mobile release zip URL> [sha256]" >&2
  echo "请从 nodejs-mobile Releases 页面取得 arm64-v8a 产物 URL 后传入。" >&2
  exit 1
fi

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
echo "==> 下载 $URL"
curl -fL --retry 3 -o "$TMP/release.zip" "$URL"

if [[ -n "$EXPECTED_SHA" ]]; then
  ACTUAL="$(sha256sum "$TMP/release.zip" | cut -d' ' -f1)"
  [[ "$ACTUAL" == "$EXPECTED_SHA" ]] || { echo "SHA256 校验失败：$ACTUAL" >&2; exit 1; }
  echo "==> SHA256 校验通过"
fi

mkdir -p "$TMP/unzip"
python3 - <<PY
import zipfile, os
with zipfile.ZipFile(r"$TMP/release.zip") as z:
    z.extractall(r"$TMP/unzip")
PY

JNI="$ROOT/app/src/main/jniLibs/arm64-v8a"
LIBS="$ROOT/app/libs"
mkdir -p "$JNI" "$LIBS"

python3 - <<PY
import os, shutil, hashlib
src = r"$TMP/unzip"
jni = r"$JNI"
libs = r"$LIBS"
assets = r"$ROOT/app/src/main/assets/node"
os.makedirs(assets, exist_ok=True)
found = {"libnode.so": False, "libc++_shared.so": False, "aar": False,
         "headers": False, "icudtl.dat": False}
for base, _, files in os.walk(src):
    for f in files:
        p = os.path.join(base, f)
        if f == "libnode.so" and "arm64" in p and not found["libnode.so"]:
            shutil.copy2(p, os.path.join(jni, "libnode.so")); found["libnode.so"] = True
        # 若 release 自带 STL，优先用它（与 libnode.so 同批次编译，版本最匹配）
        elif f == "libc++_shared.so" and not found["libc++_shared.so"]:
            shutil.copy2(p, os.path.join(jni, "libc++_shared.so")); found["libc++_shared.so"] = True
        # full-icu 构建需要 icudtl.dat；Node 启动源码里 ICU 初始化失败会
        # fprintf(stderr, ...) 后直接 exit(9)。打进 assets 后 C 胶水会
        # setenv("NODE_ICU_DATA", nodeHome)，避免静默 exit。
        elif f == "icudtl.dat" and not found["icudtl.dat"]:
            shutil.copy2(p, os.path.join(assets, "icudtl.dat")); found["icudtl.dat"] = True
        elif f.endswith(".aar") and not found["aar"]:
            shutil.copy2(p, os.path.join(libs, f)); found["aar"] = True
        elif f.endswith(".h") and "include/node" in p and not found["headers"]:
            os.makedirs(os.path.join(libs, "include/node"), exist_ok=True)
            found["headers"] = True
print("==> 命中：", found)
if not found["libnode.so"]:
    raise SystemExit("未在 release 包中找到 arm64 的 libnode.so，请确认下载的是 Android arm64 产物")

# ---- 二进制核对：必须是 64 位 AArch64 的 ELF ----
p = os.path.join(jni, "libnode.so")
h = open(p, "rb").read(20)
size_mb = os.path.getsize(p) / 1024.0 / 1024.0
sha = hashlib.sha256(open(p, "rb").read()).hexdigest()
is_elf = h[:4] == b"\x7fELF"
is64 = len(h) > 4 and h[4] == 2
machine = h[18] | (h[19] << 8) if len(h) >= 20 else 0
arch = {0xB7: "AArch64", 0x3E: "x86_64", 0x28: "ARMv7"}.get(machine, hex(machine))
print(f"==> libnode.so: {size_mb:.1f} MB | ELF={is_elf} | 64位={is64} | arch={arch} | sha256={sha[:16]}…")
if not (is_elf and is64 and machine == 0xB7):
    raise SystemExit(f"libnode.so 不是 arm64 的 64 位 ELF（arch={arch}），拒绝打包")
if found["icudtl.dat"]:
    print("==> icudtl.dat 已放入 assets/node/，运行时 NODE_ICU_DATA 会自动生效")
else:
    print("==> release 未含 icudtl.dat（官方 v18 --with-intl=none，属正常）")
PY

# ---------------------------------------------------------------------------
# ★ libnode.so 是 C++ 库，DT_NEEDED 里有 libc++_shared.so。
# 本工程胶水是纯 C，AGP 不会自动打包这份 STL；缺失时 dlopen 会报
#   library "libc++_shared.so" not found ... in namespace classloader-namespace
# release 里通常不带它，因此从 NDK 复制同架构的一份随 APK 打包。
# ---------------------------------------------------------------------------
if [[ ! -f "$JNI/libc++_shared.so" ]]; then
  SDK_ROOT="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-${ANDROID_SDK:-}}}"
  NDK_VER="${NDK_VERSION:-27.0.12077973}"
  SRC=""
  for c in \
    "$SDK_ROOT/ndk/$NDK_VER/toolchains/llvm/prebuilt/linux-x86_64/sysroot/usr/lib/aarch64-linux-android/libc++_shared.so" \
    "$SDK_ROOT/ndk/$NDK_VER/sources/cxx-stl/llvm-libc++/libs/arm64-v8a/libc++_shared.so"; do
    [[ -f "$c" ]] && { SRC="$c"; break; }
  done
  if [[ -z "$SRC" && -n "$SDK_ROOT" && -d "$SDK_ROOT/ndk" ]]; then
    SRC="$(find "$SDK_ROOT/ndk" -type f -name 'libc++_shared.so' \
      \( -path '*aarch64-linux-android*' -o -path '*arm64-v8a*' \) 2>/dev/null \
      | head -n1 || true)"
  fi
  if [[ -n "$SRC" && -f "$SRC" ]]; then
    cp "$SRC" "$JNI/libc++_shared.so"
    echo "==> 从 NDK 补齐 STL：$SRC"
  else
    echo "==> 警告：未能从 NDK 找到 libc++_shared.so（SDK_ROOT=${SDK_ROOT:-未设置}）。" >&2
    echo "    请把该文件放进 app/src/main/jniLibs/arm64-v8a/，否则装上后 dlopen 会失败。" >&2
    echo "    CI 构建由 workflow 的同名步骤兜底，不会走到这里。" >&2
  fi
fi

echo "==> 完成："
echo "    $JNI/libnode.so"
echo "    $JNI/libc++_shared.so（$([ -f "$JNI/libc++_shared.so" ] && echo 已就位 || echo '缺失，需手动补')）"
echo "    Java 桥接层由本工程 CMake 编译，无需在 $LIBS/ 放任何 aar"
