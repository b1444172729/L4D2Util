#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
OC网关 · 图标生成链（唯一生成入口）

母版：docs/icon-source.png —— 用户提供的青绿→蓝渐变「管道/电路」方形插画
（1256×1115，完全不透明，白色管线 + 橙色节点）。

产物：
  res/drawable-nodpi/ic_gateway_art.png      正方形彩色主图（APP/悬浮窗/通知大图标共用）
  res/drawable-nodpi/ic_gateway_status.png   透明底白色剪影（状态栏 smallIcon / themed icon）
  res/mipmap-*/ic_launcher.png               5 密度传统图标（轻微圆角）
  res/mipmap-*/ic_launcher_round.png         5 密度圆形传统图标
  docs/icon-preview.png                      预览

与旧版的区别：旧母版是浅灰白底、需要「抠背景」得到透明底图形；
新母版自带不透明渐变背景，因此：
  · 主图 = 居中裁成正方形后整体缩放，保留原画所有颜色，不再抠图；
  · 自适应图标的 background 用同色系渐变补遮罩外的一圈，避免突兀边框；
  · 状态栏 smallIcon 不能按 alpha 取轮廓（整张 alpha=255，会变成实心白方块），
    改为按「亮度显著高于背景 / 橙色节点」提取白色管线剪影。
  · monochrome（Android 12+ 主题图标）沿用这枚剪影。
"""
from PIL import Image, ImageDraw, ImageFilter
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, 'docs', 'icon-source.png')
RES = os.path.join(ROOT, 'app', 'src', 'main', 'res')

# 采样自母版四角（左上→右下），用于 adaptive background 与悬浮球底
BG_TOP = (57, 215, 181)
BG_BOTTOM = (16, 135, 227)


def make_art(size=512):
    """母版是 1256×1115 的横向方形插画：居中裁成正方形再缩放。
    左右各裁 70px（5.6%），橙色节点在 x≈170、右侧管线端点在 x≈1160，均在安全区内。"""
    src = Image.open(SRC).convert('RGBA')
    w, h = src.size
    side = min(w, h)
    x0 = (w - side) // 2
    y0 = (h - side) // 2
    crop = src.crop((x0, y0, x0 + side, y0 + side))
    return crop.resize((size, size), Image.LANCZOS)


def make_status(art, size=192):
    """smallIcon / themed icon：白色剪影。

    系统按 alpha 染色、忽略 RGB，所以必须是「图案=白、其余=透明」。
    母版背景是青蓝渐变（RGB 和约 450~500），白色管线 RGB 和 720+，
    浅青管线 620+，橙色节点 (≈245,160,40) 单独用红-绿-蓝落差判定。
    """
    src = art if art.size == (size, size) else art.resize((size, size), Image.LANCZOS)
    px = src.convert('RGB').load()
    mask = Image.new('L', (size, size), 0)
    mp = mask.load()
    for y in range(size):
        for x in range(size):
            r, g, b = px[x, y]
            bright = r + g + b > 565                      # 白 / 浅青管线
            orange = r > 190 and (r - g) > 55 and (g - b) > 45   # 橙色节点
            if bright or orange:
                mp[x, y] = 255
    # 轻微膨胀：线条在 24dp 状态栏里不至于细到看不见
    mask = mask.filter(ImageFilter.MaxFilter(3))
    white = Image.new('RGBA', (size, size), (255, 255, 255, 0))
    white.putalpha(mask)
    return white


def gradient_bg(size):
    bg = Image.new('RGBA', (size, size))
    d = ImageDraw.Draw(bg)
    for y in range(size):
        t = y / max(1, size - 1)
        c = tuple(int(BG_TOP[i] + (BG_BOTTOM[i] - BG_TOP[i]) * t) for i in range(3)) + (255,)
        d.line([(0, y), (size, y)], fill=c)
    return bg


def legacy(art, size, round_icon=False):
    """传统图标：主图自带背景，直接缩放 + 圆角/圆形遮罩；不再叠浅灰底。"""
    base = art.resize((size, size), Image.LANCZOS)
    m = Image.new('L', (size * 4, size * 4), 0)
    d = ImageDraw.Draw(m)
    if round_icon:
        d.ellipse((0, 0, size * 4 - 1, size * 4 - 1), fill=255)
    else:
        d.rounded_rectangle((0, 0, size * 4 - 1, size * 4 - 1),
                            radius=int(size * 4 * 0.18), fill=255)
    m = m.resize((size, size), Image.LANCZOS)
    out = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    out.paste(base, (0, 0), m)
    return out


def main():
    art = make_art(512)
    nodpi = os.path.join(RES, 'drawable-nodpi')
    os.makedirs(nodpi, exist_ok=True)
    art.save(os.path.join(nodpi, 'ic_gateway_art.png'))
    status = make_status(art, 192)
    status.save(os.path.join(nodpi, 'ic_gateway_status.png'))
    a = status.getchannel('A').histogram()
    cover = sum(a[128:]) / (192 * 192)
    print('  ✅ drawable-nodpi/ic_gateway_art.png / ic_gateway_status.png'
          '（剪影覆盖率 %.1f%%）' % (cover * 100))

    densities = {'mdpi': 48, 'hdpi': 72, 'xhdpi': 96, 'xxhdpi': 144, 'xxxhdpi': 192}
    for name, sz in densities.items():
        d = os.path.join(RES, 'mipmap-' + name)
        os.makedirs(d, exist_ok=True)
        legacy(art, sz, False).save(os.path.join(d, 'ic_launcher.png'))
        legacy(art, sz, True).save(os.path.join(d, 'ic_launcher_round.png'))
        print(f'  ✅ mipmap-{name}: {sz}px (方 / 圆)')

    # 预览：彩色主图 / 状态栏剪影（放在青底上看）/ 桌面效果
    prev = Image.new('RGBA', (940, 330), (245, 247, 250, 255))
    prev.alpha_composite(art.resize((300, 300), Image.LANCZOS), (10, 15))
    chip = gradient_bg(280)
    chip.alpha_composite(status.resize((280, 280), Image.LANCZOS))
    prev.alpha_composite(chip, (320, 15))
    prev.alpha_composite(legacy(art, 300, False), (620, 15))
    prev.convert('RGB').save(os.path.join(ROOT, 'docs', 'icon-preview.png'))
    print('  ✅ docs/icon-preview.png')


if __name__ == '__main__':
    main()
