#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
OC网关 · 图标生成链（唯一生成入口）

母版：docs/icon-source.png —— 用户提供的深蓝圆角方形插画
（2032×2048，四角透明，深蓝渐变底 + 青/白十字管线 + 中心同心圆环）。

产物：
  res/drawable-nodpi/ic_gateway_art.png          正方形彩色主图（APP/悬浮窗/通知大图标/传统图标共用）
  res/drawable-nodpi/ic_gateway_foreground.png  108dp 等效画布，图案内缩 76% 居中（adaptive foreground）
  res/drawable-nodpi/ic_gateway_status.png      透明底白色剪影（状态栏 smallIcon / themed icon）
  res/mipmap-*/ic_launcher.png                  5 密度传统图标（轻微圆角）
  res/mipmap-*/ic_launcher_round.png            5 密度圆形传统图标
  docs/icon-preview.png                         预览

要点：
  · 母版四角本来就是透明的（圆角方形 + 抗锯齿柔边），不需要再抠图；
    直接居中裁成正方形保留 alpha 即可。
  · adaptive-icon 的可见遮罩约为画布中心 66~72%，而十字管线的四个端点
    在母版 x/y ≈ 9%~91%。若把主图铺满 108dp，端点会被启动器的圆形遮罩切掉；
    因此 foreground 单独生成一张「图案缩到 76% 居中、四周透明」的版本，
    背景由 ic_gateway_bg.xml 的同色系深蓝渐变补上。
  · 状态栏 smallIcon 被系统按 alpha 染色、忽略 RGB，彩色位图会变成实心白方块；
    这里按「亮度显著高于深蓝底」提取十字管线与中心环，得到白色剪影。
    android:monochrome 沿用同一张剪影。
"""
from PIL import Image, ImageDraw, ImageFilter
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, 'docs', 'icon-source.png')
RES = os.path.join(ROOT, 'app', 'src', 'main', 'res')

# 采样自母版内部：左上 (16,67,114) / 中部 (10,55,97) / 右下 (3,40,82)
BG_TOP = (16, 67, 114)
BG_MID = (10, 55, 97)
BG_BOTTOM = (3, 40, 82)


def make_art(size=512):
    """母版 2032×2048：居中裁成 2032 见方（上下各裁 8px），保留原 alpha 与渐变。"""
    src = Image.open(SRC).convert('RGBA')
    w, h = src.size
    side = min(w, h)
    x0 = (w - side) // 2
    y0 = (h - side) // 2
    crop = src.crop((x0, y0, x0 + side, y0 + side))
    return crop.resize((size, size), Image.LANCZOS)


def make_foreground(art, size=512, occupy=0.76):
    """adaptive foreground：缩到画布 occupy 居中，并抠掉深蓝底只留青/白管线。

    若把整张圆角方形图当前景，叠在渐变 background 上会出现「方块里套方块」
    的明显边界。这里按亮度做软 alpha：深蓝底（RGB 和 ≈180）归零，
    青管线 ≈460 / 白管线 765 / 中心亮蓝环 ≈400 保留原色，边缘平滑过渡。
    系统把 108dp 画布按 fill 绘制时，四个端点落在约 20~88dp，
    稳稳在圆形可见遮罩（约 18~90dp）内，不会被裁。
    """
    inner = int(size * occupy)
    scaled = art.resize((inner, inner), Image.LANCZOS)
    px = scaled.load()
    for y in range(inner):
        for x in range(inner):
            r, g, b, a = px[x, y]
            t = max(0.0, min(1.0, (r + g + b - 240) / 120.0))
            px[x, y] = (r, g, b, int(a * t))
    canvas = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    canvas.alpha_composite(scaled, ((size - inner) // 2, (size - inner) // 2))
    return canvas


def make_status(art, size=192):
    """smallIcon / themed icon：白色剪影。

    深蓝底 RGB 和约 150~200；白色管线 765、青色管线 ≈460、中心亮蓝环 ≈400。
    先用 alpha>=200 排除圆角抗锯齿柔边（那些淡蓝像素亮度虚高但半透明），
    再用 r+g+b>300 取出管线与圆环；中心深蓝内环自然镂空，白圆保留。
    """
    src = art if art.size == (size, size) else art.resize((size, size), Image.LANCZOS)
    px = src.load()
    mask = Image.new('L', (size, size), 0)
    mp = mask.load()
    for y in range(size):
        for x in range(size):
            r, g, b, a = px[x, y]
            if a >= 200 and (r + g + b) > 300:
                mp[x, y] = 255
    # 轻微膨胀：24dp 状态栏里细线条不至于消失（不会填实中心环）
    mask = mask.filter(ImageFilter.MaxFilter(3))
    white = Image.new('RGBA', (size, size), (255, 255, 255, 0))
    white.putalpha(mask)
    return white


def gradient_bg(size):
    bg = Image.new('RGBA', (size, size))
    d = ImageDraw.Draw(bg)
    for y in range(size):
        t = y / max(1, size - 1)
        top, bottom, k = (BG_TOP, BG_MID, t * 2) if t < 0.5 else (BG_MID, BG_BOTTOM, (t - 0.5) * 2)
        c = tuple(int(top[i] + (bottom[i] - top[i]) * k) for i in range(3)) + (255,)
        d.line([(0, y), (size, y)], fill=c)
    return bg


def legacy(art, size, round_icon=False):
    """传统图标：主图自带圆角与深蓝底，缩放后叠圆角/圆形遮罩。"""
    base = art.resize((size, size), Image.LANCZOS)
    m = Image.new('L', (size * 4, size * 4), 0)
    d = ImageDraw.Draw(m)
    if round_icon:
        d.ellipse((0, 0, size * 4 - 1, size * 4 - 1), fill=255)
    else:
        d.rounded_rectangle((0, 0, size * 4 - 1, size * 4 - 1),
                            radius=int(size * 4 * 0.18), fill=255)
    m = m.resize((size, size), Image.LANCZOS)
    out = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    out.paste(base, (0, 0), m)
    return out


def main():
    art = make_art(512)
    nodpi = os.path.join(RES, 'drawable-nodpi')
    os.makedirs(nodpi, exist_ok=True)
    art.save(os.path.join(nodpi, 'ic_gateway_art.png'))
    make_foreground(art).save(os.path.join(nodpi, 'ic_gateway_foreground.png'))
    status = make_status(art, 192)
    status.save(os.path.join(nodpi, 'ic_gateway_status.png'))
    cover = sum(status.getchannel('A').histogram()[128:]) / (192 * 192)
    print('  ✅ drawable-nodpi/ic_gateway_art.png / ic_gateway_foreground.png'
          ' / ic_gateway_status.png（剪影覆盖率 %.1f%%）' % (cover * 100))

    densities = {'mdpi': 48, 'hdpi': 72, 'xhdpi': 96, 'xxhdpi': 144, 'xxxhdpi': 192}
    for name, sz in densities.items():
        d = os.path.join(RES, 'mipmap-' + name)
        os.makedirs(d, exist_ok=True)
        legacy(art, sz, False).save(os.path.join(d, 'ic_launcher.png'))
        legacy(art, sz, True).save(os.path.join(d, 'ic_launcher_round.png'))
        print(f'  ✅ mipmap-{name}: {sz}px (方 / 圆)')

    # 预览：彩色主图 / 状态栏剪影（深蓝底上看）/ adaptive 效果（渐变底 + 内缩前景）
    prev = Image.new('RGBA', (940, 330), (245, 247, 250, 255))
    prev.alpha_composite(art.resize((300, 300), Image.LANCZOS), (10, 15))
    chip = gradient_bg(280)
    chip.alpha_composite(status.resize((280, 280), Image.LANCZOS))
    prev.alpha_composite(chip, (320, 15))
    ad = gradient_bg(300)
    ad.alpha_composite(make_foreground(art, 300), (0, 0))
    prev.alpha_composite(ad, (620, 15))
    prev.convert('RGB').save(os.path.join(ROOT, 'docs', 'icon-preview.png'))
    print('  ✅ docs/icon-preview.png')


if __name__ == '__main__':
    main()
