#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
限量网关 · 图标生成链（唯一生成入口）

母版：docs/icon-source.png（用户提供的漏斗 / 三色管道图，浅灰白底）

产物：
  res/drawable-nodpi/ic_gateway_art.png      透明底彩色主图（APP/悬浮窗/通知大图标共用）
  res/drawable-nodpi/ic_gateway_status.png   透明底白色剪影（状态栏 smallIcon / themed icon）
  res/mipmap-*/ic_launcher.png               5 密度传统图标（浅色底 + 主图）
  res/mipmap-*/ic_launcher_round.png         5 密度圆形传统图标
  docs/icon-preview.png                      预览

Android 约定：
  · adaptive icon 的 foreground 画布 108dp，可见遮罩约 66%，故主图缩到画布 64%
    居中，避免管道末端被裁；
  · 状态栏 smallIcon 强制按 alpha 染色、忽略 RGB，因此必须是白色剪影；
    主图中间那个白色圆孔 alpha=0，剪影里自然镂空，不会变成实心白块；
  · API<26 没有 adaptive，legacy PNG 自带浅色底。
"""
from PIL import Image, ImageDraw, ImageFilter
import math
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, 'docs', 'icon-source.png')
RES = os.path.join(ROOT, 'app', 'src', 'main', 'res')

BG_TOP = (243, 244, 249)
BG_BOTTOM = (231, 235, 245)
BG_EST = (240, 241, 246)


def make_foreground(size=512, occupy=0.64):
    """把母版里彩色图形抠成透明底 PNG，居中放到 size×size 画布的 occupy 比例内。"""
    src = Image.open(SRC).convert('RGBA')
    w, h = src.size
    px = src.load()

    mask = Image.new('L', (w, h), 0)
    mp = mask.load()
    for y in range(h):
        for x in range(w):
            r, g, b, a = px[x, y]
            if a < 8:
                continue
            d = math.sqrt((r - BG_EST[0]) ** 2 + (g - BG_EST[1]) ** 2 + (b - BG_EST[2]) ** 2)
            # 与浅灰背景的距离决定 alpha：彩色部分全不透明，阴影/柔边渐隐，白孔归零
            v = int(max(0.0, min(1.0, (d - 10) / 32)) * 255)
            if v > mp[x, y]:
                mp[x, y] = v

    cut = Image.new('RGBA', (w, h), (0, 0, 0, 0))
    cut.paste(src, (0, 0))
    cut.putalpha(mask)

    bbox = mask.getbbox()
    if not bbox:
        raise RuntimeError('母版里没抠出任何图形')
    art = cut.crop(bbox)
    aw, ah = art.size
    target = int(size * occupy)
    scale = min(target / aw, target / ah)
    art = art.resize((max(1, int(aw * scale)), max(1, int(ah * scale))), Image.LANCZOS)

    canvas = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    canvas.alpha_composite(art, ((size - art.width) // 2, (size - art.height) // 2))
    return canvas


def make_status(foreground, size=192):
    """smallIcon：白色硬边剪影。系统会按 alpha 染色、忽略 RGB，
    阈值化可去掉主图的光晕柔边，避免剪影比实际图形膨胀一圈。"""
    art = foreground.resize((size, size), Image.LANCZOS)
    hard = art.getchannel('A').point(lambda v: 255 if v >= 110 else 0)
    white = Image.new('RGBA', (size, size), (255, 255, 255, 0))
    white.putalpha(hard)
    return white


def gradient_bg(size):
    bg = Image.new('RGBA', (size, size))
    d = ImageDraw.Draw(bg)
    for y in range(size):
        t = y / max(1, size - 1)
        c = tuple(int(BG_TOP[i] + (BG_BOTTOM[i] - BG_TOP[i]) * t) for i in range(3)) + (255,)
        d.line([(0, y), (size, y)], fill=c)
    return bg


def legacy(foreground, size, round_icon=False, occupy=0.62):
    bg = gradient_bg(size)
    art = foreground.resize((int(size * occupy), int(size * occupy)), Image.LANCZOS)
    bg.alpha_composite(art, ((size - art.width) // 2, (size - art.height) // 2))
    if round_icon:
        mask = Image.new('L', (size * 4, size * 4), 0)
        ImageDraw.Draw(mask).ellipse((0, 0, size * 4 - 1, size * 4 - 1), fill=255)
        mask = mask.resize((size, size), Image.LANCZOS)
        out = Image.new('RGBA', (size, size), (0, 0, 0, 0))
        out.paste(bg, (0, 0), mask)
        return out
    # 传统图标轻微圆角，避免在所有启动器里都是硬方块
    r = int(size * 0.18)
    mask = Image.new('L', (size * 4, size * 4), 0)
    ImageDraw.Draw(mask).rounded_rectangle((0, 0, size * 4 - 1, size * 4 - 1), radius=r * 4, fill=255)
    mask = mask.resize((size, size), Image.LANCZOS)
    out = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    out.paste(bg, (0, 0), mask)
    return out


def main():
    fg = make_foreground(512, 0.64)
    nodpi = os.path.join(RES, 'drawable-nodpi')
    os.makedirs(nodpi, exist_ok=True)
    fg.save(os.path.join(nodpi, 'ic_gateway_art.png'))
    make_status(fg, 192).save(os.path.join(nodpi, 'ic_gateway_status.png'))
    print('  ✅ drawable-nodpi/ic_gateway_art.png / ic_gateway_status.png')

    densities = {'mdpi': 48, 'hdpi': 72, 'xhdpi': 96, 'xxhdpi': 144, 'xxxhdpi': 192}
    for name, sz in densities.items():
        d = os.path.join(RES, 'mipmap-' + name)
        os.makedirs(d, exist_ok=True)
        legacy(fg, sz, False).save(os.path.join(d, 'ic_launcher.png'))
        legacy(fg, sz, True).save(os.path.join(d, 'ic_launcher_round.png'))
        print(f'  ✅ mipmap-{name}: {sz}px (方 / 圆)')

    # 预览：三格（主图 / 状态栏剪影 / 桌面效果）
    prev = Image.new('RGBA', (900, 320), (248, 249, 253, 255))
    a = fg.resize((280, 280), Image.LANCZOS)
    prev.alpha_composite(a, (10, 20))
    s = make_status(fg, 280)
    prev.alpha_composite(s, (310, 20))
    t = legacy(fg, 280, False)
    prev.alpha_composite(t, (610, 20))
    prev.convert('RGB').save(os.path.join(ROOT, 'docs', 'icon-preview.png'))
    print('  ✅ docs/icon-preview.png')


if __name__ == '__main__':
    main()
