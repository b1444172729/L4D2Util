#!/usr/bin/env bash
# 生成 app/src/main/assets/node/ 下的【散放上游源码】（r11 / Node 22 + JNI 路线）。
#
# 与旧版 bundle.zip 的区别：
#   旧版：npm install（把 devDependencies + peer 全装进来，约 85 MB）
#         → 整仓打成一个 bundle.zip → APK 里再套一层压缩 → 126 MB 的由来。
#   r11： ① 上游 standalone 运行时零裸包依赖（已逐文件验证，见下），
#           默认跳过 npm install；仅在探测到真实裸包依赖时才条件安装；
#         ② 裁掉 packages/desktop、scripts、TS 源码、图标等纯构建期文件；
#         ③ 源码散放进 assets/node/，不再打 bundle.zip —— 单文件 deflate
#           压缩率更高，也彻底避开上游 managed storage 的符号链接闸门；
#         ④ 运行时仍是 libnode.so（Node 22.23.2）+ 自建 JNI 胶水，
#            由 scripts/fetch-libnode.sh 与 workflow 负责，本脚本只管源码。
#
# 保留完整仓库结构（adapter/ src/ locale/ catalog/ feed/ worker/ vendor/），
# 因为 README 明确要求：只拷入口脚本会导致渠道加载失败。
#
# 用法： ./scripts/prepare-node-bundle.sh [源码缓存目录]
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
ASSETS="$ROOT/app/src/main/assets/node"
WORK="${1:-$ROOT/.ofm-src}"
REPO="${OFM_REPO:-https://github.com/Ebony-Vinyl/dsh-our-free-model.git}"
# r11：保持 r5 已验证能聊天的 main 分支；也可用 OFM_REF 覆盖为固定 tag。
# 不因为固定版本而让整条 CI 失败：ref 不可用时自动回退 main。
REF="${OFM_REF:-main}"

checkout_ref() {
  local ref="$1"
  if [[ -d "$WORK/.git" ]]; then
    git -C "$WORK" fetch --depth 1 origin "$ref" \
      && git -C "$WORK" reset --hard FETCH_HEAD
  else
    rm -rf "$WORK"
    git clone --depth 1 --branch "$ref" "$REPO" "$WORK"
  fi
}

echo "==> 仓库：$REPO ($REF)"
if ! checkout_ref "$REF"; then
  echo "::warning::ref $REF 不可用，回退 main 分支"
  REF="main"
  rm -rf "$WORK"
  checkout_ref "$REF" || { echo "::error::无法拉取上游源码"; exit 1; }
fi
UPSTREAM_VER="$(cd "$WORK" && node -e '
  try { const p=require("./package.json"); console.log(p.version||"?"); } catch(_) { console.log("?"); }' 2>/dev/null || echo '?')"
echo "==> 上游版本：$UPSTREAM_VER @ $REF"

# ---------------------------------------------------------------------------
# ★ r6 选项 1：不再无脑 npm install。
# 上游根 package.json 的 dependencies 为空，devDependencies 是
# typescript / esbuild / vite / react / tailwindcss / undici 等构建期工具，
# peerDependencies 是 DSH 宿主注入的 @deepseek-ai/*。
# packages/standalone 的整条 import 链全是 node: 内置模块 + 相对路径，
# 实测零裸包依赖（沙盒用对方 2.8.0 源码在零 node_modules 下跑通
# `node cli.mjs --help`，退出码 0）。
#
# 为兼容上游将来新增真实运行时依赖，这里做一次自适应探测：
# 只有扫描到非 node:/相对/bun:/@deepseek-ai 的裸包才执行安装。
# ---------------------------------------------------------------------------
echo "==> 零依赖校验：不装任何包，直接跑 cli.mjs --help"
# 用「真实执行结果」做判据，比静态扫描准：client.js 里的 react、vite.config.mjs
# 里的 @tailwindcss/vite 属于 DSH / 前端构建期代码，standalone 的 import 链根本
# 不加载，静态扫会把它们误判成运行时依赖。--help 会走完整条静态 import 链，
# 只有真的缺包才会 ERR_MODULE_NOT_FOUND / Cannot find package。
rm -rf "$WORK/node_modules"
PROBE_OUT="$(cd "$WORK" && timeout 25 node packages/standalone/cli.mjs --help 2>&1 || true)"
if echo "$PROBE_OUT" | grep -q '独立本地服务\|用法：\|Usage'; then
  echo "    ✅ 零 node_modules 下整条 import 链加载成功 → 跳过 npm install"
elif echo "$PROBE_OUT" | grep -q 'ERR_MODULE_NOT_FOUND\|Cannot find package\|Cannot find module'; then
  echo "    ⚠️ 检测到运行时依赖缺失 → 条件安装（omit dev/peer/optional）"
  echo "$PROBE_OUT" | grep -E 'ERR_MODULE_NOT_FOUND|Cannot find package|Cannot find module' | head -5 || true
  (cd "$WORK" && npm install --omit=dev --omit=peer --omit=optional \
     --ignore-scripts --no-audit --no-fund)
else
  echo "    ⚠️ --help 未能确认（上游 CLI 变更或 Node 版本差异），按零依赖继续："
  echo "$PROBE_OUT" | head -6 || true
fi
if [[ -d "$WORK/node_modules" ]]; then
  echo "    node_modules 体积：$(du -sh "$WORK/node_modules" | cut -f1)"
else
  echo "    node_modules：不存在（预期）"
fi

echo "==> 校验必要目录"
for d in packages/standalone src adapter locale vendor/magpie vendor/channel-pack catalog feed worker; do
  if [[ ! -e "$WORK/$d" ]]; then
    echo "    警告：缺少 $d —— 若上游结构已调整，请核对后决定是否继续" >&2
  fi
done

# 把上游真实启动方式打印进 CI 日志：bootstrap.cjs 按根 package.json 的
# start:standalone 推断入口；若上游改用 tsx / --experimental-* 包装器，
# 这里一眼能看出来。同时打印 engines.node，便于核对运行时版本。
echo "==> 上游独立服务启动方式"
(cd "$WORK" && node -e '
  const fs=require("fs"),p=JSON.parse(fs.readFileSync("package.json","utf8"));
  console.log("  type              =",p.type||"(未声明)");
  console.log("  engines.node      =",(p.engines&&p.engines.node)||"(未声明)");
  console.log("  start:standalone  =",(p.scripts&&p.scripts["start:standalone"])||"(未声明)");
  const dir="packages/standalone";
  if(fs.existsSync(dir)) console.log("  standalone 文件   =",fs.readdirSync(dir).slice(0,20).join(", "));
' || echo "  (读取 package.json 失败，请查看 CI 日志)")
echo "  提示：Android 运行时为 Node 22.23.2（libnode.so + 自建 JNI 胶水 / DT_NEEDED）。"

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
STAGE="$TMP/repo"
mkdir -p "$STAGE"

# ---------------------------------------------------------------------------
# ★ r6 选项 3：裁剪纯构建期文件（实测裁剪后 `cli.mjs --help` 仍 exit 0，
#   证明 service.mjs → src/* → channels/* → vendor/channel-pack/pack.js
#   整条静态 import 链不受影响）。
#   tar -h 跟随符号链接写入真实文件内容，保证释放后目录树零链接。
# ---------------------------------------------------------------------------
echo "==> r11：裁剪非运行时文件（desktop / scripts / TS 源码 / 图标）"
(cd "$WORK" && tar -h \
  --exclude='./.git' \
  --exclude='./scripts' \
  --exclude='./packages/desktop' \
  --exclude='./vendor/channel-pack/src' \
  --exclude='./vendor/channel-pack/scripts' \
  --exclude='./.github' \
  --exclude='./docs' \
  --exclude='./.ofm-src' \
  --exclude='./node_modules' \
  --exclude='*/node_modules' \
  --exclude='*/node_modules/.cache' \
  -cf - .) | (cd "$STAGE" && tar -xf -)

# r7：条件安装分支（上游将来真有裸包依赖时）会生成 node_modules，
# 旧版 tar 只排了 .cache，会把几十 MB 依赖原样带进 assets → APK 虚胖。
# 这里再兜一次底：无论前面走没走 npm install，散放目录里都不允许出现它。
find "$STAGE" -type d -name 'node_modules' -prune -exec rm -rf {} + 2>/dev/null || true

find "$STAGE" -type f \( \
    -name '*.ts' ! -name '*.d.ts' -o \
    -name 'tsconfig.json' -o \
    -name 'package-lock.json' -o \
    -name '*.map' -o \
    -name '*.icns' -o \
    -name '*.bmp' -o \
    -name 'README.md' -o -name 'README_EN.md' -o -name 'PACKAGING.md' \
  \) -delete
find "$STAGE" -type d -empty -delete 2>/dev/null || true

echo "==> r11：校验裁剪结果"
for f in package.json packages/standalone/cli.mjs packages/standalone/service.mjs; do
  if [[ ! -f "$STAGE/$f" ]]; then
    echo "::error::裁剪后缺少关键文件 $f，请检查上游目录结构" >&2
    exit 1
  fi
done
[[ -d "$STAGE/src" ]] || { echo "::error::裁剪后缺少 src/"; exit 1; }
echo "    裁剪后文件数：$(find "$STAGE" -type f | wc -l | tr -d ' ')"
echo "    裁剪后体积  ：$(du -sh "$STAGE" | cut -f1)"
LINKS="$(find "$STAGE" -type l 2>/dev/null | wc -l | tr -d ' ')"
echo "    符号链接    ：$LINKS 个"
if [[ "$LINKS" != "0" ]]; then
  echo "::error::裁剪目录里仍有 $LINKS 个符号链接，上游 managed storage 闸门会拒绝启动" >&2
  find "$STAGE" -type l -print | head -20 >&2
  exit 1
fi

# 用裁剪后的源码复跑一次：证明 scripts/ desktop/ TS 源码确实不被 import 链引用。
# 只警告不 exit 1，避免上游 CLI 改了 --help 行为就阻断整条流水线。
echo "==> r11：裁剪后零依赖复验"
STAGE_OUT="$(cd "$STAGE" && timeout 25 node packages/standalone/cli.mjs --help 2>&1 || true)"
if echo "$STAGE_OUT" | grep -q '独立本地服务\|用法：\|Usage'; then
  echo "    ✅ 裁剪后 import 链仍完整（零 node_modules）"
else
  echo "::warning::裁剪后 cli.mjs --help 未能确认，请查看输出：" >&2
  echo "$STAGE_OUT" | head -12 >&2 || true
fi

# 注入本工程的启动入口与版本标记
cp "$ASSETS/bootstrap.cjs" "$TMP/bootstrap.cjs"
cp "$TMP/bootstrap.cjs" "$STAGE/bootstrap.cjs"
BOOTSTRAP_HASH="$(sha256sum "$TMP/bootstrap.cjs" | cut -c1-12)"
# -r11 后缀是硬性保险：手机端旧版 filesDir 里是 bundle.zip 释放出来的目录，
# 版本号一定不同，AssetInstaller 必然重建，不会沿用旧的 85 MB 目录树。
VERSION="$(git -C "$WORK" rev-parse --short HEAD)-$(date +%Y%m%d%H%M)-$BOOTSTRAP_HASH-r11"
echo "$VERSION" > "$STAGE/bundle-version.txt"

# ---------------------------------------------------------------------------
# ★ r6 选项 2：散放。清空 assets/node（保留模板与 ICU 数据），把裁剪后的
#   源码树直接写进去，不生成 bundle.zip。工程包里只带 bootstrap.cjs，
#   几百个散文件由本脚本在 CI 里现场生成，不会混进交付 zip。
# ---------------------------------------------------------------------------
echo "==> r11：散放源码到 $ASSETS"
mkdir -p "$ASSETS"
find "$ASSETS" -mindepth 1 -maxdepth 1 \
  ! -name 'bootstrap.cjs' ! -name 'icudtl.dat' -exec rm -rf {} +
(cd "$STAGE" && tar -cf - .) | (cd "$ASSETS" && tar -xf -)
cp "$TMP/bootstrap.cjs" "$ASSETS/bootstrap.cjs"

echo "==> r11：最终自检"
FINAL_FILES="$(find "$ASSETS" -type f | wc -l | tr -d ' ')"
FINAL_MB="$(du -sm "$ASSETS" | cut -f1)"
FINAL_LINKS="$(find "$ASSETS" -type l 2>/dev/null | wc -l | tr -d ' ')"
echo "    assets/node 文件数：$FINAL_FILES"
echo "    assets/node 体积  ：${FINAL_MB} MB"
echo "    node_modules      ：$([ -d "$ASSETS/node_modules" ] && echo '存在 ❌' || echo '不存在 ✅')"
echo "    bundle.zip        ：$([ -f "$ASSETS/bundle.zip" ] && echo '仍存在 ❌' || echo '已取消 ✅')"
echo "    符号链接          ：$FINAL_LINKS 个"

# r7：硬闸门。正常裁剪后约 9.9 MB；超过 20 MB 一定是混进了
# node_modules / 旧 bundle.zip / 重复的 icudtl.dat，直接让步骤失败，
# 不再静默产出一个「能装但虚胖几十 MB」的 APK。
if [[ "$FINAL_MB" -gt 20 ]]; then
  echo "::error::assets/node 体积 ${FINAL_MB} MB，远超正常的 ~10 MB，疑似混入冗余：" >&2
  find "$ASSETS" -type f -printf '%s %p\n' | sort -rn | head -15 >&2
  exit 1
fi
if [[ -d "$ASSETS/node_modules" || -f "$ASSETS/bundle.zip" ]]; then
  echo "::error::assets/node 里仍有 node_modules 或 bundle.zip" >&2
  exit 1
fi
if [[ "$FINAL_LINKS" != "0" ]]; then
  echo "::error::assets/node 含符号链接，上游 managed storage 闸门会拒绝启动" >&2
  exit 1
fi
[[ -f "$ASSETS/bootstrap.cjs" && -f "$ASSETS/package.json" && -f "$ASSETS/packages/standalone/cli.mjs" ]] || {
  echo "::error::assets/node 内容不完整（缺 bootstrap.cjs / package.json / cli.mjs）" >&2
  exit 1
}

echo "==> 完成"
echo "    bundle-version: $VERSION"
echo "    下一步：./scripts/fetch-libnode.sh <release-zip-url>（会顺带 strip libnode.so），然后在 Android Studio 里 Sync & Build"
