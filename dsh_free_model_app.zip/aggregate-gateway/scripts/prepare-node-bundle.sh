#!/usr/bin/env bash
# 生成 assets/node/bundle.zip：把原仓库完整源码 + standalone 依赖打成一个包。
#
# 为什么必须「完整仓库」而不是只拷 packages/standalone：
# 原项目 README 明确要求保留 adapter/、src/、locale/、vendor/magpie/ 的元数据与许可证，
# 以及 vendor/channel-pack/ 下的 pack.js、WASM、LICENSE、NOTICE——只拷入口脚本会导致渠道加载失败。
# 同时「独立服务的安装制品与 Release 尚未发布，本阶段从完整仓库运行」。
#
# 用法： ./scripts/prepare-node-bundle.sh [源码缓存目录]
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
ASSETS="$ROOT/app/src/main/assets/node"
WORK="${1:-$ROOT/.ofm-src}"
REPO="${OFM_REPO:-https://github.com/Ebony-Vinyl/dsh-our-free-model.git}"
REF="${OFM_REF:-main}"

echo "==> 仓库：$REPO ($REF)"
if [[ -d "$WORK/.git" ]]; then
  git -C "$WORK" fetch --depth 1 origin "$REF"
  git -C "$WORK" reset --hard "origin/$REF"
else
  git clone --depth 1 --branch "$REF" "$REPO" "$WORK"
fi

echo "==> 安装依赖（standalone 需要完整 node_modules）"
(cd "$WORK" && npm install --no-audit --no-fund)

echo "==> 校验必要目录"
for d in packages/standalone src adapter locale vendor/magpie vendor/channel-pack catalog scripts; do
  if [[ ! -e "$WORK/$d" ]]; then
    echo "    警告：缺少 $d —— 若上游结构已调整，请核对后决定是否继续" >&2
  fi
done

# ★ 把上游真实启动方式打印进 CI 日志：bootstrap.cjs 是直接 require/import
# 入口的，若上游 script 用 tsx / --experimental-* / --import / --env-file 等
# 包装器，或入口只导出 start() 不自启动，服务会「加载了却没 listen」。
# 同时打印 engines.node —— nodejs-mobile 官方 Android 构建只有 v18.20.4，
# 上游若要求 Node 22+，这就是 standalone 静默失败的根因。
echo "==> 上游独立服务启动方式（排查「没监听端口」时看这里）"
(cd "$WORK" && node -e '
  const fs=require("fs"),p=JSON.parse(fs.readFileSync("package.json","utf8"));
  console.log("  type              =",p.type||"(未声明)");
  console.log("  engines.node      =",(p.engines&&p.engines.node)||"(未声明)");
  console.log("  start:standalone  =",(p.scripts&&p.scripts["start:standalone"])||"(未声明)");
  const dir="packages/standalone";
  if(fs.existsSync(dir)) console.log("  standalone 文件   =",fs.readdirSync(dir).slice(0,20).join(", "));
' || echo "  (读取 package.json 失败，请查看 CI 日志)")
echo "  提示：当前 Android libnode 为 Node 22.23.2（满足上游 engines.node）；CI 已按 tag major>=22 锁定运行时。"

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/repo"

# ---------------------------------------------------------------------------
# ★ r5：上游 standalone 在「托管/整合包安装」形态下会执行符号链接闸门，
#   报 `启动失败: Symlinks are not allowed in managed storage` 后安静返回、
#   不监听 18900。npm install 会在 node_modules/.bin 生成大量符号链接，
#   tar 默认又保留链接，因此在打包前把所有链接实体化、并删掉 standalone
#   运行时根本用不到的 .bin，保证释放出来的目录树里没有任何符号链接。
# ---------------------------------------------------------------------------
echo "==> r5：消除符号链接（上游 managed storage 闸门）"
BEFORE_LINKS="$(find "$WORK" -type l 2>/dev/null | wc -l | tr -d ' ')"
echo "    源码目录符号链接：$BEFORE_LINKS 个"
# 删除 CLI 快捷方式（standalone 以 `node cli.mjs` 启动，不执行 .bin）
find "$WORK/node_modules" -type d -name '.bin' -prune -exec rm -rf {} + 2>/dev/null || true
# 其余符号链接先实体化再复制：tar -h 会跟随链接写入真实文件内容
# 完整复制（排除 .git 与缓存），用 tar 管道避免依赖 rsync
(cd "$WORK" && tar -h --exclude='./.git' --exclude='*/node_modules/.cache' -cf - .) \
  | (cd "$TMP/repo" && tar -xf -)
AFTER_LINKS="$(find "$TMP/repo" -type l 2>/dev/null | wc -l | tr -d ' ')"
echo "    打包目录残留符号链接：$AFTER_LINKS 个"
if [[ "$AFTER_LINKS" != "0" ]]; then
  echo "::error::bundle 里仍有 $AFTER_LINKS 个符号链接，上游 managed storage 闸门会拒绝启动" >&2
  find "$TMP/repo" -type l -print | head -20 >&2
  exit 1
fi

# 注入本工程的启动入口
cp "$ASSETS/bootstrap.cjs" "$TMP/repo/bootstrap.cjs"

# 版本标记必须随 bootstrap.cjs 变化：AssetInstaller 靠它决定要不要重新解压。
# 若只按构建时间，同一分钟内重跑 CI 会让手机端沿用旧的 bootstrap.cjs，
# 新加的 JS 心跳与环境变量读取就不会生效，排查会走进死胡同。
BOOTSTRAP_HASH="$(sha256sum "$ASSETS/bootstrap.cjs" | cut -c1-12)"
# -cjs 后缀是硬性保险：手机端旧版 filesDir 里是 bootstrap.js，即使某次
# hash 或构建分钟恰好相同，版本号也一定不同，AssetInstaller 必然重新解压。
VERSION="$(git -C "$WORK" rev-parse --short HEAD)-$(date +%Y%m%d%H%M)-$BOOTSTRAP_HASH-cjs"
echo "$VERSION" > "$TMP/repo/bundle-version.txt"

mkdir -p "$ASSETS"
rm -f "$ASSETS/bundle.zip" "$ASSETS/bundle-version.txt"
if command -v zip >/dev/null 2>&1; then
  (cd "$TMP/repo" && zip -qr -9 "$ASSETS/bundle.zip" .)
else
  TMP_REPO="$TMP/repo" ASSETS_ZIP="$ASSETS/bundle.zip" python3 - <<'PY'
import os, zipfile
src = os.environ["TMP_REPO"]
dst = os.environ["ASSETS_ZIP"]
with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for base, _, files in os.walk(src):
        for f in files:
            p = os.path.join(base, f)
            z.write(p, os.path.relpath(p, src))
PY
fi
cp "$TMP/repo/bundle-version.txt" "$ASSETS/bundle-version.txt"

# zip 条目也可能带 S_IFLNK 属性（即使 tar -h 已实体化，Python 分支若按
# lstat 写入仍会留下链接条目）。这里读 external_attr 高 16 位复核一次。
ASSETS_ZIP="$ASSETS/bundle.zip" python3 - <<'PY'
import os, stat, zipfile
p = os.environ["ASSETS_ZIP"]
links = []
with zipfile.ZipFile(p) as z:
    for i in z.infolist():
        mode = (i.external_attr >> 16) & 0xFFFF
        if stat.S_ISLNK(mode):
            links.append(i.filename)
print("==> r5 bundle.zip 内符号链接条目：%d" % len(links))
if links:
    print("    前 10 个：" + ", ".join(links[:10]))
    raise SystemExit("::error::bundle.zip 含符号链接条目，上游 managed storage 闸门会拒绝启动")
PY

echo "==> 完成"
echo "    $ASSETS/bundle.zip"
echo "    bundle-version: $VERSION"
echo "    下一步：./scripts/fetch-libnode.sh <release-zip-url>，然后在 Android Studio 里 Sync & Build"
