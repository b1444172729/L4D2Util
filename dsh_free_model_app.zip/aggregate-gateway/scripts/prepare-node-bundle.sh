#!/usr/bin/env bash
# 校验并标记 app/src/main/assets/node/ 下的【本机网关源码】（B 方案）。
#
# 与旧版（r11）的根本区别：
#   旧版：git clone Ebony-Vinyl/dsh-our-free-model → 裁剪 → 散放几百个文件
#         → 由 bootstrap.cjs 动态 import packages/standalone/cli.mjs。
#   本版：网关代码就在本工程里（bootstrap.cjs + opencode-gateway.cjs +
#         models.builtin.json + web/index.html + package.json），构建期不再联网、
#         不再 clone、不再 npm install、不再打 bundle.zip。
#
# 这样做的三个理由：
#   1. 手机上没有 DSH，dsh-opencode-free-models 插件的面板 / 18766 授权桥 /
#      cordis 注入全都无从加载，只能把「清单 + provider 转发」等价重写成本机服务；
#   2. 控制面（原作者后端 free-api.gd7.cn/opencode 的 4 个接口）也搬到 127.0.0.1，
#      因此运行时不依赖任何第三方后端；
#   3. assets/node 从 ~10 MB 缩到几十 KB，CI 与真机释放都更快。
#
# 用法： ./scripts/prepare-node-bundle.sh [忽略的参数]
#   CI 里仍会传 "$PROJECT_DIR/.ofm-src" 作为第二个参数，本版忽略即可，
#   保持 workflow 的调用形式不用改。
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
ASSETS="$ROOT/app/src/main/assets/node"

echo "==> 本机网关源码目录：$ASSETS"

required=(
  "package.json"
  "bootstrap.cjs"
  "opencode-gateway.cjs"
  "models.builtin.json"
  "web/index.html"
)
for f in "${required[@]}"; do
  if [[ ! -f "$ASSETS/$f" ]]; then
    echo "::error::缺少 $ASSETS/$f" >&2
    exit 1
  fi
  echo "    ✅ $f ($(wc -c < "$ASSETS/$f" | tr -d ' ') bytes)"
done

# 硬闸门：不该再出现上游整仓的产物
if [[ -e "$ASSETS/packages/standalone" || -d "$ASSETS/node_modules" || -f "$ASSETS/bundle.zip" ]]; then
  echo "::error::assets/node 里残留旧上游源码 / node_modules / bundle.zip，请先清理" >&2
  exit 1
fi
links="$(find "$ASSETS" -type l 2>/dev/null | wc -l | tr -d ' ')"
echo "    符号链接：$links 个（必须为 0）"
if [[ "$links" != "0" ]]; then
  echo "::error::assets/node 含符号链接，Android AssetManager 释放后会出问题" >&2
  exit 1
fi

# JS 语法自检（CI 已通过 setup-node 装好 Node 22；本地没装则跳过）
if command -v node >/dev/null 2>&1; then
  echo "==> JS 语法自检（node --check）"
  node --check "$ASSETS/bootstrap.cjs"
  node --check "$ASSETS/opencode-gateway.cjs"
  echo "    ✅ 两个入口语法通过 · 运行时 $(node --version)"
  # 模型清单必须是合法 JSON
  node -e 'const j=require(process.argv[1]);if(!Array.isArray(j.items)||!j.items.length)process.exit(1);console.log("    ✅ 内置免费模型 "+j.items.length+" 个 · 快照 "+j.snapshot)' "$ASSETS/models.builtin.json"
else
  echo "::warning::本机没有 node，跳过语法自检（CI 会执行）"
fi

# 版本标记 = 代码内容哈希。APK 里的网关代码一变，AssetInstaller 就会
# 删掉 filesDir/gateway/node 重新释放，避免手机上跑到旧 bootstrap。
HASH="$(cd "$ASSETS" && find . -type f ! -name bundle-version.txt -print0 \
  | sort -z | xargs -0 cat 2>/dev/null | sha256sum | cut -d' ' -f1 | cut -c1-16)"
VERSION="opencode-local-${HASH}"
printf '%s\n' "$VERSION" > "$ASSETS/bundle-version.txt"
echo "==> bundle-version.txt = $VERSION"

echo "==> 端点与契约"
echo "    数据面  : /v1/models · /v1/chat/completions · /v1/responses · /v1/messages"
echo "    控制面  : /api/models · /api/version · /api/articles · /api/license · /api/refresh · /api/usage"
echo "    探活    : /health（HealthProbe.awaitRuntime 依赖）"
echo "    运行信息: ofm-data/gateway-runtime.json（port / apiKey / manageUrl）"
echo "    上游    : \${ZEN_BASE_URL:-https://opencode.ai/zen/v1}，认证 Bearer \${OPENCODE_ZEN_API_KEY:-public}"
echo "    文件数 / 体积: $(find "$ASSETS" -type f | wc -l | tr -d ' ') 个 / $(du -sh "$ASSETS" | cut -f1)"
