#!/usr/bin/env bash
# 生成 assets/node/bundle.zip：把原仓库完整源码 + standalone 依赖打成一个包。
#
# 为什么必须「完整仓库」而不是只拷 packages/standalone：
# 原项目 README 明确要求保留 adapter/、src/、locale/、vendor/magpie/ 的元数据与许可证，
# 以及 vendor/channel-pack/ 下的 pack.js、WASM、LICENSE、NOTICE——只拷入口脚本会导致渠道加载失败。
# 同时「独立服务的安装制品与 Release 尚未发布，本阶段从完整仓库运行」。
#
# 用法： ./scripts/prepare-node-bundle.sh [源码缓存目录]
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
ASSETS="$ROOT/app/src/main/assets/node"
WORK="${1:-$ROOT/.ofm-src}"
REPO="${OFM_REPO:-https://github.com/Ebony-Vinyl/dsh-our-free-model.git}"
REF="${OFM_REF:-main}"

echo "==> 仓库：$REPO ($REF)"
if [[ -d "$WORK/.git" ]]; then
  git -C "$WORK" fetch --depth 1 origin "$REF"
  git -C "$WORK" reset --hard "origin/$REF"
else
  git clone --depth 1 --branch "$REF" "$REPO" "$WORK"
fi

echo "==> 安装依赖（standalone 需要完整 node_modules）"
(cd "$WORK" && npm install --no-audit --no-fund)

echo "==> 校验必要目录"
for d in packages/standalone src adapter locale vendor/magpie vendor/channel-pack catalog scripts; do
  if [[ ! -e "$WORK/$d" ]]; then
    echo "    警告：缺少 $d —— 若上游结构已调整，请核对后决定是否继续" >&2
  fi
done

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/repo"

# 完整复制（排除 .git 与缓存），用 tar 管道避免依赖 rsync
(cd "$WORK" && tar --exclude='./.git' --exclude='*/node_modules/.cache' -cf - .) \
  | (cd "$TMP/repo" && tar -xf -)

# 注入本工程的启动入口
cp "$ASSETS/bootstrap.js" "$TMP/repo/bootstrap.js"

VERSION="$(git -C "$WORK" rev-parse --short HEAD)-$(date +%Y%m%d%H%M)"
echo "$VERSION" > "$TMP/repo/bundle-version.txt"

mkdir -p "$ASSETS"
rm -f "$ASSETS/bundle.zip" "$ASSETS/bundle-version.txt"
if command -v zip >/dev/null 2>&1; then
  (cd "$TMP/repo" && zip -qr -9 "$ASSETS/bundle.zip" .)
else
  TMP_REPO="$TMP/repo" ASSETS_ZIP="$ASSETS/bundle.zip" python3 - <<'PY'
import os, zipfile
src = os.environ["TMP_REPO"]
dst = os.environ["ASSETS_ZIP"]
with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for base, _, files in os.walk(src):
        for f in files:
            p = os.path.join(base, f)
            z.write(p, os.path.relpath(p, src))
PY
fi
cp "$TMP/repo/bundle-version.txt" "$ASSETS/bundle-version.txt"

echo "==> 完成"
echo "    $ASSETS/bundle.zip"
echo "    bundle-version: $VERSION"
echo "    下一步：./scripts/fetch-libnode.sh <release-zip-url>，然后在 Android Studio 里 Sync & Build"
