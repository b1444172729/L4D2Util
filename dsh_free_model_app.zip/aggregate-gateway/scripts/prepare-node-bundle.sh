#!/usr/bin/env bash
# OpenCode 免费模型网关版（oc-free-gateway-r1）
#
# 与旧版的区别：不再 clone GitHub 上游、不再 npm install、不再裁剪几百个文件。
# assets/node 里只需要 4 个文本：
#   bootstrap.cjs · oc-proxy.cjs · bundle-version.txt · package.json
#   （packages/standalone/cli.mjs 为兼容旧壳完整性判据的占位文件）
#
# 本脚本仍由 .github/workflows/build.yml 第 6 步调用，保持 CI 流程不变；
# 它会校验文件齐备并刷新版本标记，绝不会覆盖改造后的网关代码。
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
ASSETS="$ROOT/app/src/main/assets/node"
VERSION="oc-free-gateway-r1"

echo "==> OpenCode 免费模型网关源码校验（离线，不联网）"
echo "    目录：$ASSETS"

missing=0
for f in bootstrap.cjs oc-proxy.cjs package.json packages/standalone/cli.mjs; do
  if [ -f "$ASSETS/$f" ]; then
    echo "    ✅ $f ($(wc -c < "$ASSETS/$f") B)"
  else
    echo "    ❌ 缺失 $f"
    missing=$((missing + 1))
  fi
done

# 语法自检：CI 的 Node 22 与手机里的 libnode.so 都是 CommonJS 可解析的 .cjs
if command -v node >/dev/null 2>&1; then
  node --check "$ASSETS/bootstrap.cjs" || { echo "::error::bootstrap.cjs 语法错误"; exit 1; }
  node --check "$ASSETS/oc-proxy.cjs"  || { echo "::error::oc-proxy.cjs 语法错误"; exit 1; }
  echo "    ✅ node --check 两个 .cjs 均通过"
else
  echo "    ⚠️ 未找到 node，跳过语法自检（CI 一般会装）"
fi

if [ "$missing" -gt 0 ]; then
  echo "::error::assets/node 缺少 $missing 个必要文件，请把完整工程包上传"
  exit 1
fi

printf '%s\n' "$VERSION" > "$ASSETS/bundle-version.txt"
echo "    ✅ 写入 bundle-version.txt = $VERSION（覆盖安装会强制重建 nodeHome）"

# r2「限量网关」品牌资源：4 个核心图标 + 5 密度传统图标缺一不可
RES="$ROOT/app/src/main/res"
icon_missing=0
for f in \
  drawable-nodpi/ic_gateway_art.png \
  drawable-nodpi/ic_gateway_status.png \
  drawable/ic_gateway_vector.xml \
  drawable/ic_gateway_bg.xml \
  drawable/ic_gateway_badge.xml \
  mipmap-anydpi-v26/ic_launcher.xml \
  mipmap-anydpi-v26/ic_launcher_round.xml; do
  [ -f "$RES/$f" ] || { echo "    ❌ 缺图标资源 $f"; icon_missing=$((icon_missing + 1)); }
done
for d in mdpi hdpi xhdpi xxhdpi xxxhdpi; do
  for n in ic_launcher.png ic_launcher_round.png; do
    [ -f "$RES/mipmap-$d/$n" ] || { echo "    ❌ 缺图标资源 mipmap-$d/$n"; icon_missing=$((icon_missing + 1)); }
  done
done
if [ "$icon_missing" -gt 0 ]; then
  echo "::error::缺 $icon_missing 个图标资源，请运行 scripts/render_icons.py 生成后再打包"
  exit 1
fi
echo "    ✅ 图标资源齐备（桌面 / 悬浮窗 / 通知栏三处同源）"

TOTAL="$(du -sm "$ASSETS" 2>/dev/null | cut -f1)"
echo "    文件数 / 体积：$(find "$ASSETS" -type f | wc -l | tr -d ' ') 个 / ${TOTAL} MB"
if [ "${TOTAL:-0}" -gt 20 ]; then
  echo "::error::assets/node 超过 20 MB，疑似混入旧版上游源码或 bundle.zip"
  exit 1
fi
echo "==> 完成。运行时 libnode.so 仍由 fetch-libnode.sh / CI 下载，本脚本不碰二进制。"
