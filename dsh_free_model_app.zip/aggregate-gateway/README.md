# 聚合网关（Aggregate Gateway）

把 `Ebony-Vinyl/dsh-our-free-model` 的独立本地服务 **`packages/standalone`** 原样嵌进一台安卓手机，
对外只暴露 `127.0.0.1` 上的 OpenAI 兼容端点，供 **RikkaHub** 当作自定义提供商使用；
同时用 **前台服务 + 唤醒锁 + 悬浮窗 + 电池白名单** 把网关常驻在后台，并用 **WebView 容器**承载 standalone 自带的完整网页管理页。

- 应用名：**聚合网关**
- 包名：`com.android.dsh`
- 交付形态：**仅源码，未编译 APK**（按要求）
- APP 图标与悬浮窗图标：共用唯一资源 `res/drawable/ic_gateway_vector.xml`

---

## 0. 先把一句话说清楚

> 「把原插件的所有功能全都要」在安卓上**不能 1:1 复刻**，但**模型能力与网关能力可以全量保留**。

原因是：`dsh-our-free-model` 的「功能」其实分两半——

- 一半是**插件自己的代码**：免费车道、协议转换、压缩、恢复、用量、聚合渠道、本地网关……这些都在 `packages/standalone` 里，不依赖 DSH，嵌进 APK 原样跑即可；
- 另一半是 **DSH 宿主给的 UI 与生命周期**：输入框模型选择器、Effort 菜单、应用内升级 / 公告 / 热重载、Cordis 注入、profile 闸门、Electron 桌面端……安卓上没有 DSH，这些要么换宿主承载，要么根本不适用。

所以本工程的策略是：**不重写插件，只搬完整仓库 + 补一层宿主**。壳越薄，功能越不会丢。

---

## 1. 架构

```
┌──────────────────────── 一台安卓手机 ────────────────────────┐
│                                                                │
│  聚合网关 APK (com.android.dsh)                                 │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ GatewayService（前台服务 · specialUse · PARTIAL_WAKE_LOCK） │  │
│  │   └─ nodejs-mobile (libnode.so, arm64-v8a)                 │  │
│  │        └─ bootstrap.js                                     │  │
│  │             └─ require(原仓库 packages/standalone)          │  │
│  │                  ├─ 免费车道 / EAC / 十个账号渠道            │  │
│  │                  ├─ 76 家聚合渠道 / 三种线协议               │  │
│  │                  ├─ 压缩 / 恢复 / 用量 / combo              │  │
│  │                  └─ HTTP :18900  127.0.0.1                 │  │
│  │                       ├─ /v1/models                        │  │
│  │                       ├─ /v1/chat/completions              │  │
│  │                       ├─ /v1/responses · /v1/messages      │  │
│  │                       └─ / · 网页管理页                     │  │
│  ├──────────────────────────────────────────────────────────┤  │
│  │ FloatingWindow（悬浮球，同图标） / ManageActivity（WebView） │  │
│  │ MainActivity（状态、Base URL、Key、模型清单、二维码）        │  │
│  └──────────────────────────────────────────────────────────┘  │
│                          ▲ HTTP 回环                            │
│  RikkaHub（另一个 App）──┘  OpenAI 兼容 Provider                │
│    Base URL  http://127.0.0.1:18900/v1                          │
│    API Key   独立 Key（不读 DSH 数据）                            │
└────────────────────────────────────────────────────────────────┘
```

**网关跑在手机里，RikkaHub 只是聊天前台。** 两者不共享进程、不共享数据目录，只靠回环 HTTP 对接。

---

## 2. 能力对照表（逐项核对原 README）

### A. 原样继承 —— 由 `packages/standalone` 完整源码承载

| 能力 | 说明 |
|---|---|
| 免费车道（匿名 / Kilo）、EAC、十个账号渠道 | 全部由原仓库代码提供，壳不改动 |
| 模型清单随上游刷新、按本机出口实测可用性、地区分组、拒因与探测时间 | 手机换蜂窝 / Wi-Fi 后可在管理页「重新探测可用性」 |
| 思考强度下发真实预算（档位 `reasoning_effort` 或硬性 token 上限） | 非提示词伪装 |
| `/v1/chat/completions`、`/v1/responses`、`/v1/messages`、`/v1/messages/count_tokens` | 含流式与非流式 |
| 本地转发 + 局域网中继、独立 LAN Key、Key 不回显（只给 `hasKey` 与指纹） | 中继默认关闭 |
| 端口顺延（18899 被占 → 18900…）与实际端口写回 | `gateway-runtime.json` 回传给壳，界面显示真实端口 |
| SSE 心跳注释帧、思考帧识别（`reasoning` / `reasoning_content` / `reasoning_text` / `reasoning_details`） | 维持连接 |
| 纯思考 EOF / 纯思考空停的检查点恢复（每回合最多追加一次物理请求） | 含次数、时间、上下文边界 |
| RTK 工具输出压缩、caveman / ponytail 提示词瘦身、幂等注入 | 默认档位 off / RTK 默认开 |
| 五个本地应答（额度探测、命令前缀、标题生成、建议模式、路径提取） | 进程内直接应答 |
| combo 虚拟模型链（fallback / round-robin、容量取交集、思考不算正文） | 作为 `combo:` 出现在模型清单 |
| 用量看板、Token 热力图、吞吐统计、物理请求 vs 逻辑回合分离统计 | 管理页「统计」分区 |
| 76 家聚合渠道注册表、三种线协议、Key 存 0600 `settings.json` | 免账号提供商不需要 Key |
| 模型窗口 / 输出上限、能力标注以可探测者为限 | 沿用 9router / models.dev 口径 |
| 网页管理页：模型、统计、渠道、EAC、设置、API Key 等分区 | ManageActivity 只做 WebView 容器 |

> **为什么是「完整仓库」而不是只拷 `packages/standalone`**：原 README 明确写了「本阶段从完整仓库运行，暂不能仅复制本目录或将它单独作为 npm 包安装」，且手工复制必须包含 `adapter/`、`src/`、`locale/`、`vendor/magpie/` 的元数据与许可证，以及 `vendor/channel-pack/` 下的 `pack.js`、WASM、`LICENSE`、`NOTICE`。`prepare-node-bundle.sh` 因此打的是整仓（去 `.git`）。

### B. 换宿主承载 —— 功能在，但入口变了

| 原插件形态 | 本 APP 形态 |
|---|---|
| DSH 输入框模型选择器 → `Our Free Model` 分组 | **RikkaHub 顶部模型下拉**；模型 ID 需在 RikkaHub 提供商详情里手动添加 |
| 同一菜单的 Effort 三档 / 声明档位 | **RikkaHub 是通用 OpenAI 客户端，不会下发插件私有的 effort 参数**，因此「按会话随手切档」在手机侧做不到。改为在管理页设全局默认档位，或选不同模型 / combo 变体。这是方案 C 唯一实打实的能力损失 |
| 设置 → Our Free Model 七个分区 | standalone 网页管理页（WebView 内嵌） |
| 应用内升级（Ed25519 签名 + SHA-256 清单 → 热重载） | 换成 **替换 `bundle.zip` → `bundle-version.txt` 变更 → 重启 Node 服务**。插件那套升级器绑在 DSH 插件目录上，不能直接复用；签名信任改由「只从可信仓库取源码 + 人工核对 commit / 校验值」承担 |
| 公告中心 / urgent 全屏弹窗 / 系统通知 | 改由安卓前台通知承载；standalone 是否保留 feed 以实际仓库为准 |
| 「设置 → 本地转发」里生成 Key | Key 由 standalone 写入 `ofm-data/settings.json`，壳读取后提供复制 / 二维码 |

### C. 不适用 —— 属于 DSH / 桌面端宿主，安卓上没有对应物

`Cordis` / `ctx.inject` / `providerRetryPolicy()` 扁平退避 / 内核 0.1.5–0.1.7 鸭子类型兼容、`cordis.patch.yml` duplicate loader、DSHEAC AIO 与 Electron 的 profile 符号链接闸门、命令行 `dsh plugin add` 对 desktop profile 的拒绝、pnpm `ERR_PNPM_VIRTUAL_STORE_DIR_MAX_LENGTH_DIFF`、git `insteadOf` 重写、`WebView2` 通知权限、Windows `netsh interface portproxy` / 手动系统代理 / PAC / `ProxyOverride`、macOS 社区构建 Gatekeeper 与公证、桌面壳 DMG / AppImage。

另有两处**在 arm64 安卓上尚未验证**，属于已知风险而非已实现：`vendor/channel-pack/` 的 WASM 与签名校验在安卓 Node 运行时上的行为；Gemini / Cline 的 OAuth 回调（需 `accounts.google.com`、`oauth2.googleapis.com` 等可达，且回调地址与端口在手机上要能收得到）。

---

## 3. 图标

已按用户提供的参考图**以矢量路径重画**：青绿→青蓝→蓝的对角渐变底、中央信号塔（桁架 + 顶部圆球）、六道对称信号波纹、横贯的悬索桥与两枚橙色立柱顶帽、两侧浅青小信号弧、塔基阴影、极淡的斜向亮带。预览见 `docs/icon-preview.png`。

资源分工：

| 文件 | 作用 |
|---|---|
| `drawable/ic_gateway_vector.xml` | **唯一图形层**（透明底，108×108 viewport，`<group scale=0.8>` 收进自适应安全区） |
| `drawable/ic_gateway_bg.xml` | 自适应图标 `<background>`：同款对角渐变 |
| `drawable/ic_gateway_badge.xml` | 悬浮球底：同款渐变 + 12dp 圆角 |
| `drawable/ic_notification.xml` | 通知栏单色剪影（系统要求 alpha 图形，不能用彩色主图标） |
| `mipmap-anydpi-v26/ic_launcher*.xml` | adaptive icon，foreground / monochrome 指向主图形 |
| `mipmap-*/ic_launcher*.png` | API < 26 的传统图标，由同一套几何渲染（满幅构图） |

**APP 图标与悬浮窗图标确实一模一样**：`ic_launcher.xml` 的 `<foreground>` 与 `FloatingWindow.kt` 的 `setImageResource()` 引用的是**同一个 drawable**，底色也都用同一组渐变色。两者唯一的差别是启动器/悬浮球各自的遮罩形状（圆角方形），图形内容完全一致。

`scripts/render_icon_preview.py` 是图标的**唯一几何源**：它与矢量 XML 共用 108×108 坐标系，一次运行同时产出预览图和五个密度的兼容 PNG。改图标时改这两处（或只改脚本再据此同步 XML），不要只改其中一边。脚本里半透明元素必须画在独立 RGBA 图层再 `alpha_composite`——直接在 RGBA 底图上写 `alpha<255` 会被「替换」而非「混合」，导出后低 alpha 会变成纯色。

主题色 `colors.xml` 已一并调到同色系（主蓝 `#0E7FC4` / 深蓝 `#0A5A9E` / 青绿点缀 `#2CC9A8`）。

---

## 4. 目录结构

```
aggregate-gateway/
├── settings.gradle.kts / build.gradle.kts / gradle.properties
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/android/dsh/
│       │   ├── GatewayApp.kt              状态总线 + 通知渠道
│       │   ├── MainActivity.kt            状态屏 / 配置交接 / 二维码
│       │   ├── core/
│       │   │   ├── GatewayConfig.kt       端口、开关、私有目录
│       │   │   ├── AssetInstaller.kt      bundle.zip 释放（版本标记 + Zip Slip 防护）
│       │   │   ├── NodeRuntime.kt         反射启动 nodejs-mobile，进程级单例
│       │   │   ├── HealthProbe.kt         /health 握手、/v1/models、实际端口
│       │   │   └── GatewayService.kt      前台服务 + 唤醒锁 + 悬浮窗 + 状态回传
│       │   ├── ui/
│       │   │   ├── FloatingWindow.kt      悬浮球（同图标、可拖动、快捷面板）
│       │   │   └── ManageActivity.kt      管理页 WebView 容器
│       │   ├── util/
│       │   │   ├── RikkaHubHandoff.kt     Base URL / Key / 模型 ID 交接
│       │   │   └── QrCodeUtil.kt          ZXing 二维码
│       │   └── receiver/BootReceiver.kt  开机自启（默认关）
│       ├── assets/node/
│       │   ├── bootstrap.js               ★ Node 侧启动胶水（本次手写）
│       │   └── （bundle.zip 由脚本生成）
│       └── res/
│           ├── drawable/                  ic_gateway_vector（主图形）/ bg / badge / notification
│           ├── mipmap-anydpi-v26/        adaptive icon（渐变底 + 主图形前景）
│           ├── mipmap-*/                 API<26 传统 PNG 图标（5 个密度）
│           └── values/ xml/              颜色、字符串、明文策略、备份排除
├── scripts/
│   ├── prepare-node-bundle.sh            整仓 → bundle.zip
│   ├── fetch-libnode.sh                  放置 arm64 libnode.so 与 aar
│   └── render_icon_preview.py           ★ 图标几何源：预览 + 5 密度 PNG
├── docs/icon-preview.png
└── README.md
```

---

## 5. 从源码到可编译（本次不执行编译）

```bash
# 1) 生成完整仓库 bundle（需要 git / npm / node）
./scripts/prepare-node-bundle.sh
#   产物：app/src/main/assets/node/bundle.zip + bundle-version.txt

# 2) 放置 nodejs-mobile arm64 运行时
#    从 https://github.com/nodejs-mobile/nodejs-mobile/releases 取 arm64 Android 产物 URL
./scripts/fetch-libnode.sh "<release-zip-url>" "<可选 sha256>"
#   产物：app/src/main/jniLibs/arm64-v8a/libnode.so、app/libs/*.aar

# 3) Android Studio Sync → Build（本交付按要求止步于源码）
```

`bootstrap.js` 的入口定位是容错的：优先从根 `package.json` 的 `scripts["start:standalone"]` 里正则提取 `node xxx.js`，否则依次试 `packages/standalone/src/index.js`、`index.js`、`dist/index.js`、`server.js` 等。若上游改了文件名，只需改 `resolveEntry()` 的 `candidates`。

`bootstrap.js` 还负责三件壳做不到的事：把 `OFM_HOME` 指向 `filesDir/ofm-data`、劫持 stdout 抓**一次性管理链接**与**实际端口**、轮询 `settings.json` 取 Key，最后原子写 `gateway-runtime.json`（0600）。异常一律写 `node-errors.log` 且**不调用 `process.exit()`**——在安卓里 exit 会把宿主 App 一起结束。

---

## 6. RikkaHub 怎么配

1. 打开「聚合网关」→ 启动网关 → 等状态变「运行中」，记下**实际端口**（被占用会顺延）。
2. RikkaHub → 设置 → 提供商 → 添加 → **OpenAI**
   - **Base URL**：`http://127.0.0.1:18900/v1`（必须以 `/v1` 结尾，RikkaHub 会自动拼 `/chat/completions`，别重复写路径）
   - **API Key**：主界面「复制 API Key」；`Authorization: Bearer` 由 RikkaHub 自动加，不要手动配 header
   - **模型**：进提供商详情「添加模型」，ID 从主界面「复制模型 ID 清单」粘贴（会请求 `/v1/models`）
3. 回到聊天界面，顶部选刚添加的模型即可。

三个坑：

- **明文 HTTP**：Android 9+ 默认禁止明文。本工程用 `network_security_config.xml` 只对 `127.0.0.1` / `localhost` 放行；**RikkaHub 是另一个 App，它自己也需要允许回环明文**（它的文档有 `http://localhost:11434/v1` 这类示例，通常已放行）。若连接失败先查这一层，不是网关的问题。
- **长思考易超时**：SSE 注释帧只维持连接、不重置客户端的空闲看门狗。选 `reasoning: false` 的模型或调大单次输出上限更稳。
- **二维码不是原生导入格式**：主界面生成的是「Base URL + Key」的**配置文本二维码**，供手动粘贴；RikkaHub 的扫码导入串包含它自己的编码结构，本工程不伪造。要原生扫码请用 RikkaHub 自带的 Provider Share 生成。二维码**含 Key**，只发给可信对象。

---

## 7. 悬浮窗与存活能力

悬浮窗的作用要说准：**它本身不保活**，真正保活是三重约束——

| 层 | 实现 | 作用 |
|---|---|---|
| 前台服务 | `GatewayService`，`foregroundServiceType="specialUse"` + 常驻通知 | 提高进程优先级，系统不易回收 |
| 唤醒锁 | `PARTIAL_WAKE_LOCK` | 息屏后 CPU 继续服务请求 |
| 悬浮窗 | `TYPE_APPLICATION_OVERLAY`，48dp 可拖动的可见浮层 | 降低部分厂商 ROM 对后台的激进回收；用户一眼能看出网关是否还活着；点开可复制配置 / 打开管理页 / 重启 |
| 电池白名单 | 主界面按钮跳 `ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS` | 避免锁屏清理与 Doze 冻结 |
| 开机自启 | `BootReceiver`（Manifest 里默认 `enabled=false`） | 可选，需用户显式开启 |

已知系统限制：

- **Android 15（API 35）对 `dataSync` 类前台服务有每天约 6 小时上限**。本工程用 `specialUse` 并声明 `PROPERTY_SPECIAL_USE_FGS_SUBTYPE`；上架 Play 时需说明用途，或改用其它合规类型。
- 厂商 ROM（部分国产系统）可能无视前台服务杀后台，需要在系统「应用信息 → 电池 / 自启动 / 后台锁定」里手动加白名单。
- Node 在一个进程里**只能初始化一次**：`NodeRuntime` 用 `AtomicBoolean` 守住重复启动；「划掉 App」时 libuv 线程可能仍占端口，所以 `HealthProbe` 冷启动前会删掉上一轮 `gateway-runtime.json`，并以 `/health` 握手为准，不以「进程还活着」为准。
- 原插件的 `service.lock` 残留由 `bootstrap.js` 校验 PID 后清理（与桌面文档一致）。

---

## 8. 管理页

standalone 自带**独立网页管理**，启动时终端会打印一条**一次性登录链接**。`bootstrap.js` 从 stdout 抓到它写进 `gateway-runtime.json`，`ManageActivity` 用 WebView 打开；抓不到时回退到 `http://127.0.0.1:<port>/`，也可点「外部浏览器」用系统浏览器打开。

管理页管的是**网关配置与观测**（模型清单与探测、请求数 / 回合数 / Token / 热力图、渠道 Key 写入与测试、EAC 与账号登录、Key 生成轮换、中继开关、设置），**不是聊天界面**。聊天、消息分支、Markdown、MCP、记忆、助手人格全在 RikkaHub 那边。两者通过 HTTP 对接，不需要同屏。

WebView 已关闭 `allowFileAccess` / `allowContentAccess`，只允许跟进回环地址，其余链接交给系统浏览器；`mixedContentMode = NEVER_ALLOW`。

---

## 9. 权限与数据边界

| 权限 | 用途 |
|---|---|
| `INTERNET` / `ACCESS_NETWORK_STATE` | 上游模型请求、探测可用性、开本地 socket |
| `FOREGROUND_SERVICE` / `FOREGROUND_SERVICE_SPECIAL_USE` | 常驻服务 |
| `POST_NOTIFICATIONS` | Android 13+ 前台服务通知 |
| `SYSTEM_ALERT_WINDOW` | 悬浮球（用户手动授权，未授权不影响服务） |
| `WAKE_LOCK` / `REQUEST_IGNORE_BATTERY_OPTIMIZATIONS` | 保活 |
| `RECEIVE_BOOT_COMPLETED` | 可选开机自启 |

数据全部落在 app 私有目录：`filesDir/ofm-data`（Key、统计、账号凭据）与 `filesDir/gateway/node`（代码）。`backup_rules.xml` / `data_extraction_rules.xml` 已把 `ofm-data` 与配置 SharedPreferences **排除出云备份和设备迁移**，避免 Key 随备份外流。

---

## 10. 必须知道的风险与边界

- **包名 `com.android.dsh` 已照用**，但 `com.android.*` 是 AOSP 常见命名空间：个别 ROM 预置了同包名的系统组件时，可能出现安装冲突或签名校验提示。若遇到，改成 `com.aggregate.gateway` 之类即可（`applicationId` + `namespace` 两处，代码目录可保持）。
- **「免费不限量」的真实含义**：没有计费体系、不按 token 收费，但免费车道**按 session 限速**，短时间打满返回 429，插件会标记「已达限额」并在下一轮探测后恢复。部分模型上游延迟很高。
- **隐私**：提示词、工具结果、图片会原样发给上游；部分免费档条款允许用提交内容改进服务。密码、密钥、个人身份信息、商业机密不要往里送。
- **账号渠道**：依赖逆向第三方 AI 工具免费额度的渠道，稳定性与合规风险都高于干净的免费车道，已有渠道被下架的先例。建议只用免费车道与 Kilo。
- **不要通过 npm 安装**：npm 上的同名 `dsh-our-free-model` 是无关第三方打包，`index.js` / `client.js` 被改动且多了本仓库没有的文件。本工程只认 `git clone` 到的完整源码。
- **信任链变化**：插件侧的应用内升级以 pin 的 Ed25519 公钥 + SHA-256 清单为信任根；本 APK 改成「替换 bundle.zip 并重启」，请自行核对仓库 commit 与校验值。
- **未验证项**：`vendor/channel-pack/` 的 WASM、签名校验、公告与热重载在 arm64 安卓 Node 上，以及 Gemini / Cline 的 OAuth 回调。
- 源码为明文 JavaScript，作为本地服务必须如此；能访问该目录的人即可读懂网关逻辑，这是分发形态的固有属性。

---

## 11. 本次交付边界

按要求**只给源码、不编译 APK**。因此以下事项留给你在真机上验证：nodejs-mobile 具体发行版的 `start(...)` 签名（`NodeRuntime` 用反射兼容了常见两种）、`packages/standalone` 的真实入口文件名、WASM 在 arm64 上的行为、以及 RikkaHub 对明文回环的放行情况。

最小验证顺序建议：装 APK → 启动网关 → 主界面出现实际端口与 Key → 打开管理页能看到模型清单 → RikkaHub 手填一个 `beam-free` 发出第一条消息。前三步验「回环通不通、后台活不活」，第四步才验业务。
