# 聚合网关（Aggregate Gateway）

把 `Ebony-Vinyl/dsh-our-free-model` 的独立本地服务 **`packages/standalone`** 原样嵌进一台安卓手机，
对外只暴露 `127.0.0.1` 上的 OpenAI 兼容端点，供 **RikkaHub** 当作自定义提供商使用；
同时用 **前台服务 + 唤醒锁 + 悬浮窗 + 电池白名单** 把网关常驻在后台，并用 **WebView 容器**承载 standalone 自带的完整网页管理页。

- 应用名：**聚合网关**
- 包名：`com.android.dsh`
- 交付形态：**仅源码，未编译 APK**（按要求）
- APP 图标 / 悬浮窗 / 通知头部：共用唯一彩色位图 `res/drawable-nodpi/ic_gateway_art.png`；状态栏 smallIcon 为同源透明底剪影 `ic_gateway_status.png`

---

## r18 变更（保持拉 main + 补回旧模型声明）

**问题**：上游 `main` 的模型池会轮换（旧一批下架、换上新一批），而服务端仍认旧 ID —— 用户实测另一台固定版本的网关能用那 5 个 ID 正常会话。于是固定版 22 个、拉 main 版 20 个，差的不是「少了两个」，是「换掉一批」（8 出 6 进）。

**做法**：不改 CI 的 `git clone main`，也不 fork、不固定版本，只在**运行时**往免费车道的清单里补回 5 个已核对的 ID。

| 项 | 说明 |
|---|---|
| 补丁配置 | `assets/extra-models.json`（纯文本、5 个 ID，人工逐行核对；**不含任何二进制，不读取任何第三方 APK，不依赖上游 tag / commit**） |
| 释放位置 | `ofm-data/extra-models.json`（standalone 的数据目录，不是 `nodeHome`）——「应用内更新」原子替换源码目录冲不掉它 |
| 注入点 | `src/catalog.js` 的 `buildCatalog(ids)` 函数体开头。`FALLBACK_CATALOG`、网络 listing 刷新、缓存 `materialize` 三条路径最终都汇入这里，一处覆盖三条 |
| 合并规则 | `ids = [...new Set([...ids, ...补丁])]` —— **main 在前、只填空缺、不覆盖**；`ALWAYS_FREE` 是同模块级 `Set`，原地 `add` 让 `big-pickle` 这类不带 `-free` 后缀的 ID 通过 `isFreeLane()` |
| 失败开放 | 配置缺失 / `ids` 为空 / 找不到 `src/catalog.js` / 上游把 `buildCatalog` 改名或改签名 / 注入代码抛异常 —— 一律整层跳过，网关照常按 main 跑。这是 r12 那次 99 MB Windows 二进制教训的延续 |
| 幂等 | 注入带 `/* OFM_EXTRA_MODELS_PATCH v1 */` 标记；重复启动不重复注入。换 APK 或点「更新上游源码」换了源码树后，下次启动自动重新注入 |

### 补的 5 个 ID

```
big-pickle
deepseek-v4.1-flash-free
flint-40b-free
glm-5.3-flash-free
pulse-alpha-free
```

另外 3 个「对方独有」其实是同一模型的两种 ID 写法，**默认不补**（我方已能通过长名调用，补了只是多几行选择器）：

| 对方短名 | 我方已有 |
|---|---|
| `beam-free` | `reflection/beam-free` |
| `crouton-alpha-free` | `stealth/crouton-alpha` |
| `nemotron-3.5-super-vl-free` | `nvidia/nemotron-3.5-super-vl:free` |

想补就把这三行加进 `extra-models.json` 的 `ids` 即可。补完后我方是 **25 个**（不补别名），不是 22 —— 因为我方还多着 6 个对方没有的 `muse-spark` / `ling-3.0` / `mimo-v2.5` 那批，「对齐到 22」从一开始就不是精确目标。

### 打开 / 关闭 / 恢复

- **默认开启**：首次安装（或换 APK 导致源码目录重建）时由 `AssetInstaller` 释放配置
- **关闭**：把 `ofm-data/extra-models.json` 的 `ids` 改成 `[]`，或直接删除该文件。之后每次启动都不会被悄悄恢复
- **恢复**：设置 → 上游源码 → 「恢复 APK 内置源码」会顺带把配置覆盖回内置版本
- **状态可见**：运行时自检多一行 `模型声明补丁(r18)：配置 ✅ 内置 · 5 个 ID · 注入 ✅ 已生效`；`bootstrap.log` 里另有 `r18 模型声明补丁：...` 的逐段记录

### 边界，如实说

- **能力字段不硬编**：补丁只补 ID，上下文 / 输出上限 / 思考档位全部交给 main 自己的 `capabilitiesFor()`（族规则或默认值）算，绝不覆盖 main 已声明的能力。因此个别模型的思考档位菜单可能与固定版不同，但调用本身不受影响。
- **探测闸门不伪造**：清单行仍要过本机出口实测；429 只标「已达限额」且不隐藏，地区受限模型会在分组间迁移。补丁做的是「让 ID 重新有机会被声明和探测」，不是「强制它可用」。
- **RikkaHub 侧要重新同步**：RikkaHub 保存的是静态模型表，网关 `/v1/models` 变了以后，要在提供商里重新同步一次，卡片上的数字才会跟着变。
- **上游服务端若真下线这几个 ID**：补丁里那几行会变成过时字符串，但只影响这 5 行、不拖垮网关；删配置即可一键摘除。主干 `main` 从来不绑在补丁上。
- **沙盒无 Android SDK**：注入逻辑用真实的上游 `src/catalog.js` 在 Node 里实跑验证过，但 `assembleDebug` 与真机 `/v1/models` 未实跑。

**改动文件**：新增 `assets/extra-models.json`；`bootstrap.cjs`（注入函数 + 调用）、`AssetInstaller.kt`（配置释放 / 恢复）、`MainActivity.kt`（恢复按钮顺带恢复配置 + 一行 import）、`RuntimeDiagnostics.kt`（自检新增一行）、本 README。
**`build.yml` 零改动**（补丁在运行时注入，CI 阶段不需要改任何步骤），仓库根明文 workflow 不用重新提交；`prepare-node-bundle.sh` / C 胶水 / CMake / 图标资源 / Gradle / Manifest 全部未动。

---

## r17 变更（主页现代化改版）

设计预览见 `docs/ui-preview.png`（左：默认首页；右：设置 / 自检 / 日志展开后）。

**布局原则**：首屏只留「状态 + 主操作 + 快速连接 + 管理页入口」，低频操作全部收进折叠区。

| 区域 | 位置 | 内容 |
|---|---|---|
| 顶栏 | 右上角「设置」按钮 | 展开「权限与保活 / 维护 / 上游源码 / 使用提示」：悬浮窗权限、电池白名单、冒烟测试、更新与恢复内置源码、全部说明文字 |
| 主状态卡 | 首屏 | 状态圆点 + 状态胶囊、端口 / Base URL、API KEY（显示 / 复制），下方「启动网关」主按钮 + 停止 / 重启 |
| 快速连接 | 2×2 网格 | 复制 Base URL / 复制 API Key / 复制模型 ID / 生成二维码（二维码在卡片内展开） |
| 工具 | 单行卡片 | 打开管理页 |
| 诊断 | 两个折叠行 | **「运行时自检」按钮下**才是自检详情；**「运行日志」按钮下**才是日志尾部。默认收起，按钮右侧仍显示「齐备 / 异常」与日志行数，不展开也能判断有没有问题 |

视觉由 `app/src/main/java/com/android/dsh/ui/UiTheme.kt` 用代码绘制（深蓝紫渐变底、玻璃卡片、青→紫主按钮、状态色胶囊），不引入 layout XML 或新的 UI 依赖；折叠箭头用 `PathShape` 画三角形，不依赖字体符号。`MainActivity` 的**所有业务回调与 r16 逐字一致**，只调整了位置与外观。

改动文件：`MainActivity.kt`、新增 `UiTheme.kt`、`strings.xml`（新增短标签）、`colors.xml`（新增 `ui_bg`）、`themes.xml`（窗口背景 / 状态栏改暗色）、`docs/ui-preview.png`、本 README。
**未改动**：`build.yml`、全部其它 Kotlin / Java / C 胶水 / CMake / `bootstrap.cjs` / 图标资源 / Manifest / Gradle 配置。

> 沙盒无 Android SDK，未实跑 `assembleDebug`；r16 备份（`聚合网关_稳定版备份_r16.zip`）保持冻结不动，出问题可直接回退。

---

## r11 变更（本次移植 r6~r8 回到已验证的 Node 22 + JNI 路线）

本版以 **r5**（真机上实测「模型可以正常聊天」的 Node 22.23.2 + 自建 JNI 胶水）为基底，
把 r6~r8 那几项**只作用于打包与体积**的改进移植回来，**运行时形态一行未改**：

| 项 | 来源 | 改动 |
|---|---|---|
| 零 `node_modules` | r6 选项 1 | `prepare-node-bundle.sh` 默认跳过 `npm install`，改用 `cli.mjs --help` 真实执行判据；仅探测到缺失裸包才条件安装 |
| 源码散放 | r6 选项 2 | 取消 `bundle.zip`，`AssetInstaller` 从「解压 zip」改成递归复制 `assets/node`；`bundle-version` 带 `-r11` 强制重建 |
| 裁剪非运行时文件 | r6 选项 3 | 删 `scripts/`、`packages/desktop/`、`vendor/channel-pack/src/`、TS 源码、lock、图标；保留 `pack.js` / WASM / LICENSE / `adapter/` / `catalog/` / `feed/` |
| 应用内更新 | r6 选项 5 | 新增 `SourceUpdater.kt`：从 GitHub 拉 main 分支源码 → 同规则裁剪 → 原子替换 `nodeHome`；写 `.ofm-local-update` 标记，换 APK 自动失效 |
| 体积硬闸门 + 清单 | r7 | `assets/node` >20 MB 直接失败；CI 编译完自动把 APK 体积构成表写进日志与 Job Summary |
| `llvm-strip` | r8 | `fetch-libnode.sh` 用 `--strip-unneeded` 去掉 `libnode.so` 符号表，保留 `.dynsym`（`node::Start`）；丢符号自动回滚 |
| 跳过重复 ICU 数据 | r8 | v22.23.2 已内嵌 full-icu，默认不再打包外部 `icudtl.dat`；确为 small-icu 时设 `KEEP_EXTERNAL_ICU=1` |

**预期体积**：126 MB → 约 60–80 MB（取决于 strip 收益与 `libnode.so` 压缩率）；
Job Summary 的体积表会给出实际构成，不再靠猜。

**保持不变**：`libnode.so` 来源（OpenFlun/nodejs-mobile 的 v22.23.2 Release，CI 打印 SHA-256 与 ELF 架构并按 major>=22 闸门拦截）、
`app/src/main/cpp/` 自建 JNI 胶水 + CMake 的 DT_NEEDED 链接、8MB 栈 pthread、独立 `:node` 进程、
`System.loadLibrary("node")`、`bootstrap.cjs` 的 r5 路径规范化与符号链接实体化、运行时自检 / `bootstrap.log` / 冒烟测试、
管理页 WebView、悬浮窗、二维码、RikkaHub 交接。

**没有引入任何第三方 APK 里的二进制**：本工程包仍然只有文本与几张小 PNG；
`libnode.so` 由 CI 从 GitHub Release 下载，上游源码由 CI 从 GitHub 仓库 clone。

---

## 0. 先把一句话说清楚

> 「把原插件的所有功能全都要」在安卓上**不能 1:1 复刻**，但**模型能力与网关能力可以全量保留**。

原因是：`dsh-our-free-model` 的「功能」其实分两半——

- 一半是**插件自己的代码**：免费车道、协议转换、压缩、恢复、用量、聚合渠道、本地网关……这些都在 `packages/standalone` 里，不依赖 DSH，嵌进 APK 原样跑即可；
- 另一半是 **DSH 宿主给的 UI 与生命周期**：输入框模型选择器、Effort 菜单、应用内升级 / 公告 / 热重载、Cordis 注入、profile 闸门、Electron 桌面端……安卓上没有 DSH，这些要么换宿主承载，要么根本不适用。

所以本工程的策略是：**不重写插件，只搬完整仓库 + 补一层宿主**。壳越薄，功能越不会丢。

> r11 补充：上游 `packages/standalone` 的整条 import 链零裸包依赖，`prepare-node-bundle.sh` 因此不再 `npm install`，并裁掉纯构建期文件；`adapter/`、`src/`、`locale/`、`vendor/*` 的元数据、WASM 与许可证全部保留（原 README 的「完整包」要求不变）。

---

## 1. 架构

```
┌──────────────────────── 一台安卓手机 ────────────────────────┐
│                                                                │
│  聚合网关 APK (com.android.dsh)                                 │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ GatewayService（前台服务 · specialUse · PARTIAL_WAKE_LOCK） │  │
│  │   └─ nodejs-mobile (libnode.so, arm64-v8a)                 │  │
│  │        └─ bootstrap.cjs                                     │  │
│  │             └─ require(原仓库 packages/standalone)          │  │
│  │                  ├─ 免费车道 / EAC / 十个账号渠道            │  │
│  │                  ├─ 76 家聚合渠道 / 三种线协议               │  │
│  │                  ├─ 压缩 / 恢复 / 用量 / combo              │  │
│  │                  └─ HTTP :18900  127.0.0.1                 │  │
│  │                       ├─ /v1/models                        │  │
│  │                       ├─ /v1/chat/completions              │  │
│  │                       ├─ /v1/responses · /v1/messages      │  │
│  │                       └─ / · 网页管理页                     │  │
│  ├──────────────────────────────────────────────────────────┤  │
│  │ FloatingWindow（悬浮球，同图标） / ManageActivity（WebView） │  │
│  │ MainActivity（状态、Base URL、Key、模型清单、二维码）        │  │
│  └──────────────────────────────────────────────────────────┘  │
│                          ▲ HTTP 回环                            │
│  RikkaHub（另一个 App）──┘  OpenAI 兼容 Provider                │
│    Base URL  http://127.0.0.1:18900/v1                          │
│    API Key   独立 Key（不读 DSH 数据）                            │
└────────────────────────────────────────────────────────────────┘
```

**网关跑在手机里，RikkaHub 只是聊天前台。** 两者不共享进程、不共享数据目录，只靠回环 HTTP 对接。

---

## 2. 能力对照表（逐项核对原 README）

### A. 原样继承 —— 由 `packages/standalone` 完整源码承载

| 能力 | 说明 |
|---|---|
| 免费车道（匿名 / Kilo）、EAC、十个账号渠道 | 全部由原仓库代码提供，壳不改动 |
| 模型清单随上游刷新、按本机出口实测可用性、地区分组、拒因与探测时间 | 手机换蜂窝 / Wi-Fi 后可在管理页「重新探测可用性」 |
| 思考强度下发真实预算（档位 `reasoning_effort` 或硬性 token 上限） | 非提示词伪装 |
| `/v1/chat/completions`、`/v1/responses`、`/v1/messages`、`/v1/messages/count_tokens` | 含流式与非流式 |
| 本地转发 + 局域网中继、独立 LAN Key、Key 不回显（只给 `hasKey` 与指纹） | 中继默认关闭 |
| 端口顺延（18899 被占 → 18900…）与实际端口写回 | `gateway-runtime.json` 回传给壳，界面显示真实端口 |
| SSE 心跳注释帧、思考帧识别（`reasoning` / `reasoning_content` / `reasoning_text` / `reasoning_details`） | 维持连接 |
| 纯思考 EOF / 纯思考空停的检查点恢复（每回合最多追加一次物理请求） | 含次数、时间、上下文边界 |
| RTK 工具输出压缩、caveman / ponytail 提示词瘦身、幂等注入 | 默认档位 off / RTK 默认开 |
| 五个本地应答（额度探测、命令前缀、标题生成、建议模式、路径提取） | 进程内直接应答 |
| combo 虚拟模型链（fallback / round-robin、容量取交集、思考不算正文） | 作为 `combo:` 出现在模型清单 |
| 用量看板、Token 热力图、吞吐统计、物理请求 vs 逻辑回合分离统计 | 管理页「统计」分区 |
| 76 家聚合渠道注册表、三种线协议、Key 存 0600 `settings.json` | 免账号提供商不需要 Key |
| 模型窗口 / 输出上限、能力标注以可探测者为限 | 沿用 9router / models.dev 口径 |
| 网页管理页：模型、统计、渠道、EAC、设置、API Key 等分区 | ManageActivity 只做 WebView 容器 |

> **为什么是「完整仓库」而不是只拷 `packages/standalone`**：原 README 明确写了「本阶段从完整仓库运行，暂不能仅复制本目录或将它单独作为 npm 包安装」，且手工复制必须包含 `adapter/`、`src/`、`locale/`、`vendor/magpie/` 的元数据与许可证，以及 `vendor/channel-pack/` 下的 `pack.js`、WASM、`LICENSE`、`NOTICE`。`prepare-node-bundle.sh` 因此打的是整仓（去 `.git`）。

### B. 换宿主承载 —— 功能在，但入口变了

| 原插件形态 | 本 APP 形态 |
|---|---|
| DSH 输入框模型选择器 → `Our Free Model` 分组 | **RikkaHub 顶部模型下拉**；模型 ID 需在 RikkaHub 提供商详情里手动添加 |
| 同一菜单的 Effort 三档 / 声明档位 | **RikkaHub 是通用 OpenAI 客户端，不会下发插件私有的 effort 参数**，因此「按会话随手切档」在手机侧做不到。改为在管理页设全局默认档位，或选不同模型 / combo 变体。这是方案 C 唯一实打实的能力损失 |
| 设置 → Our Free Model 七个分区 | standalone 网页管理页（WebView 内嵌） |
| 应用内升级（Ed25519 签名 + SHA-256 清单 → 热重载） | 换成 **主界面「更新上游源码（GitHub）」**：拉 main 分支 zip → 裁剪 → 原子替换散放源码目录 → 重启网关生效，另有「恢复 APK 内置源码」。插件那套升级器绑在 DSH 插件目录上，不能直接复用；**下载内容只做结构校验、不做签名校验**，信任等同「信任该仓库当前 main 分支」 |
| 公告中心 / urgent 全屏弹窗 / 系统通知 | 改由安卓前台通知承载；standalone 是否保留 feed 以实际仓库为准 |
| 「设置 → 本地转发」里生成 Key | Key 由 standalone 写入 `ofm-data/settings.json`，壳读取后提供复制 / 二维码 |

### C. 不适用 —— 属于 DSH / 桌面端宿主，安卓上没有对应物

`Cordis` / `ctx.inject` / `providerRetryPolicy()` 扁平退避 / 内核 0.1.5–0.1.7 鸭子类型兼容、`cordis.patch.yml` duplicate loader、DSHEAC AIO 与 Electron 的 profile 符号链接闸门、命令行 `dsh plugin add` 对 desktop profile 的拒绝、pnpm `ERR_PNPM_VIRTUAL_STORE_DIR_MAX_LENGTH_DIFF`、git `insteadOf` 重写、`WebView2` 通知权限、Windows `netsh interface portproxy` / 手动系统代理 / PAC / `ProxyOverride`、macOS 社区构建 Gatekeeper 与公证、桌面壳 DMG / AppImage。

另有两处**在 arm64 安卓上尚未验证**，属于已知风险而非已实现：`vendor/channel-pack/` 的 WASM 与签名校验在安卓 Node 运行时上的行为；Gemini / Cline 的 OAuth 回调（需 `accounts.google.com`、`oauth2.googleapis.com` 等可达，且回调地址与端口在手机上要能收得到）。

---

## 3. 图标

已按用户提供的「眼睛 / 轨道」参考图重制为 **2048×2048 高清母版** `docs/icon-source.png`：深蓝紫渐变底、青色椭圆轨道与两端圆点、中心圆、内侧深蓝弧、左上两条与右下三条紫色弧。图形与参考图逐像素一致，不做矢量重描（矢量只能取纯色，会丢掉青/紫渐变）。预览见 `docs/icon-preview.png`。

资源分工：

| 文件 | 作用 |
|---|---|
| `docs/icon-source.png` | **唯一母版**（2048²，含底色） |
| `drawable-nodpi/ic_gateway_art.png` | **唯一图标位图**：母版缩到 78%、四角圆角、四周留透明边（自适应安全区） |
| `drawable/ic_gateway_vector.xml` | `<bitmap>` 指向 `ic_gateway_art`；adaptive `<foreground>` / `<monochrome>` 与悬浮球 ImageView 共用 |
| `drawable-nodpi/ic_gateway_status.png` | **状态栏 smallIcon 专用**：192² 透明底白色轨道剪影（系统按 alpha 染色后形状正确，不会变白饼） |
| `drawable/ic_notification.xml` | 兼容别名，r16 起不再被 `setSmallIcon()` 引用（保留仅为兼容旧引用） |
| `drawable/ic_gateway_bg.xml` | 自适应图标 `<background>`：同款深蓝紫斜向渐变 |
| `drawable/ic_gateway_badge.xml` | 悬浮球底：同款渐变 + 12dp 圆角 |
| `mipmap-anydpi-v26/ic_launcher*.xml` | adaptive icon，foreground 与 monochrome 都指向彩色主图形 |
| `mipmap-*/ic_launcher*.png` | API < 26 的传统图标，由母版满幅渲染（方形 + 圆形各一套） |

**APP 图标 / 悬浮窗 / 通知头部是同一张彩色图**：`ic_gateway_vector.xml` 是 `android:src="@drawable/ic_gateway_art"` 的 `<bitmap>` 别名；`GatewayService.buildNotification()` 显式 `.setLargeIcon()` 把同一张 `ic_gateway_art` 解码成 192² Bitmap 交给通知，所以通知抽屉里显示的是**彩色主图本身**，与桌面、悬浮窗完全一样。

**状态栏位置是同源的白色剪影**：Android 对 `setSmallIcon()` 强制按 alpha 用 `src_in` 染色、忽略 RGB，这个位置**物理上无法彩色**（所有 Android 应用都一样）。因此指向 `ic_gateway_status.png`（透明底白色轨道），染色后形状与彩色主图同源，不是信号塔、也不是一整块白饼。

> **r16 修复记录**：r15 只把 `ic_notification.xml` 换成彩色位图，却没动 `buildNotification()` —— 该方法**从来没调用过 `setLargeIcon()`**。国产 ROM 在通知头部 largeIcon 位置会拿「应用图标」顶上，而 SystemUI 对它有进程级缓存，覆盖安装 / 重新编译都不刷新，所以用户看到的通知两处一直是旧的信号塔。r16 三管齐下：显式 `setLargeIcon(Bitmap)`、`setSmallIcon()` 改用**全新资源名** `ic_gateway_status`、`CHANNEL_ID` 与 `NOTIF_ID` 同时换新以打破缓存。界面「运行时自检」新增一行 `通知图标(r16)：...`，会实际探测这两个资源是否打进 APK，截图即可确认装的是不是新包。

`scripts/render_icon_preview.py` 是**唯一生成链**：以 `docs/icon-source.png` 为源，一次运行产出图标位图、**状态栏透明底剪影**、两个彩色 `<bitmap>` 别名、五个密度的兼容 PNG 和四格预览图。改图标时只换母版再跑一次本脚本即可，不要单独改某个 PNG 或 XML。半透明元素必须画在独立 RGBA 图层再 `alpha_composite`——直接在 RGBA 底图上写 `alpha<255` 会被「替换」而非「混合」，导出后低 alpha 会变成纯色。

---

## 4. 目录结构

```
aggregate-gateway/
├── settings.gradle.kts / build.gradle.kts / gradle.properties
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/android/dsh/
│       │   ├── GatewayApp.kt              状态总线 + 通知渠道
│       │   ├── MainActivity.kt            状态屏 / 配置交接 / 二维码
│       │   ├── core/
│       │   │   ├── GatewayConfig.kt       端口、开关、私有目录
│       │   │   ├── AssetInstaller.kt      散放源码复制（版本标记 + 应用内更新标记）
│       │   │   ├── SourceUpdater.kt       GitHub 应用内更新上游源码
│       │   │   ├── NodeRuntime.kt         反射启动 nodejs-mobile，进程级单例
│       │   │   ├── HealthProbe.kt         /health 握手、/v1/models、实际端口
│       │   │   └── GatewayService.kt      前台服务 + 唤醒锁 + 悬浮窗 + 状态回传
│       │   ├── ui/
│       │   │   ├── FloatingWindow.kt      悬浮球（同图标、可拖动、快捷面板）
│       │   │   └── ManageActivity.kt      管理页 WebView 容器
│       │   ├── util/
│       │   │   ├── RikkaHubHandoff.kt     Base URL / Key / 模型 ID 交接
│       │   │   └── QrCodeUtil.kt          ZXing 二维码
│       │   └── receiver/BootReceiver.kt  开机自启（默认关）
│       ├── assets/node/
│       │   ├── bootstrap.cjs               ★ Node 侧启动胶水（本次手写）
│       │   └── （裁剪后的上游源码由脚本散放生成，无 bundle.zip / 无 node_modules）
│       └── res/
│           ├── drawable/                  ic_gateway_vector（主图形）/ bg / badge / notification
│           ├── mipmap-anydpi-v26/        adaptive icon（渐变底 + 主图形前景）
│           ├── mipmap-*/                 API<26 传统 PNG 图标（5 个密度）
│           └── values/ xml/              颜色、字符串、明文策略、备份排除
├── scripts/
│   ├── prepare-node-bundle.sh            整仓 → 零依赖裁剪 → 散放 assets/node
│   ├── fetch-libnode.sh                  放置 arm64 libnode.so + llvm-strip（r8）
│   └── render_icon_preview.py           ★ 图标生成链：位图/状态栏剪影/彩色别名 + 预览 + 5 密度 PNG
├── docs/icon-source.png                 ★ 2048² 高清母版（唯一源）
├── docs/icon-preview.png
└── README.md
```

---

## 5. 从源码到可编译（本次不执行编译）

```bash
# 1) 生成裁剪后的散放上游源码（需要 git / node；默认不 npm install）
./scripts/prepare-node-bundle.sh
#   产物：app/src/main/assets/node/ 下约 150 个散文件 + bundle-version.txt

# 2) 放置 nodejs-mobile arm64 运行时
#    从 https://github.com/OpenFlun/nodejs-mobile/releases 取 v22.23.2 的 android-libnode.zip（官方核心库只有 v18，不能用）
./scripts/fetch-libnode.sh "<release-zip-url>" "<可选 sha256>"
#   产物：app/src/main/jniLibs/arm64-v8a/libnode.so（已 strip）+ libc++_shared.so

# 3) Android Studio Sync → Build（需要 NDK 27.0.12077973 + CMake 3.22.1）
```

**Java 桥接层不需要任何 aar。** 官方只发布 `libnode.so` + headers，
`com.janeasystems.rn_nodejs_mobile.NodeJS` 属于 React Native 插件，没有可独立使用的 aar。
因此本工程自己写了这层：`app/src/main/java/com/android/dsh/core/NodeBridge.java`
配合 `app/src/main/cpp/dsh-node.c`，由 CMake 编成 `libdsh-node.so`。它用 `dlopen` +
`dlsym` 解析 `node::Start(int, char**)`，编译期不链接 libnode.so，所以**即使本次没下载到
libnode.so，工程仍能编译出可安装的 APK**（只是启动不了网关）。界面「运行时自检」会显示
四项状态与符号探测结果，缺什么一目了然。

### 别漏掉 `libc++_shared.so`

`libnode.so` 是 C++ 库，它的 `DT_NEEDED` 里有 `libc++_shared.so`。而本工程的 JNI 胶水是
**纯 C**，AGP 不会自动把这份 STL 打进 APK。缺了它，真机 `dlopen` 会明确报：

```
library "libc++_shared.so" not found: needed by .../lib/arm64/libnode.so
        in namespace classloader-namespace
```

所以 `app/src/main/jniLibs/arm64-v8a/` 下必须同时有：

| 文件 | 来源 |
|---|---|
| `libnode.so` | nodejs-mobile Release 的 arm64 Android 包 |
| `libc++_shared.so` | 同包若自带则优先；否则从 NDK 取 `aarch64-linux-android/libc++_shared.so` |

`scripts/fetch-libnode.sh` 和 GitHub workflow 都会自动补齐第二个文件，无需手工下载。
本地用 Android Studio 构建时，确保 `ANDROID_HOME` 指向含 NDK 27 的 SDK，`fetch-libnode.sh`
会自己去找。界面自检的「符号探测」一行会直接显示 `dlopen` 的完整结果。

### Node 跑在独立 `:node` 进程

`node::Start` 是阻塞调用，且 V8 / Node 遇到致命错误会直接 `abort()`、正常结束会
`exit()` —— 这两者都会**结束调用它的整个进程**。放在 UI 主进程里，表现就是点「启动网关」
后几秒整个 App 闪退，界面来不及显示任何错误。

因此 `NodeService` 声明了 `android:process=":node"`：

| 进程 | 负责 |
|---|---|
| 主进程 | `GatewayService` 前台服务、唤醒锁、悬浮窗、状态卡、管理页 WebView、HealthProbe |
| `:node` | `NodeRuntime` / `libnode.so` / `node::Start` / HTTP 监听 |

两个进程同一 UID、同一网络命名空间，HTTP 服务照样绑在 `127.0.0.1:18900`，主进程和
RikkaHub 都能连。跨进程不走 Binder，只共享 `filesDir/ofm-data/` 下几个文件：
`node-pid.txt`（探活 / 停止）、`gateway-runtime.json`（端口 / Key / 管理链接）、
`node-output.log`（stdout+stderr）、`node-fatal.txt`（启动失败标记）。

`dsh-node.c` 在调用 `node::Start` 前把 stdout/stderr 用 `dup2` 重定向到
`node-output.log` 并关掉缓冲，所以 V8 的 `FATAL ERROR`、Node 的 `bad option`、
模块加载失败都会留下原文。界面状态卡底部直接显示这份日志的末尾，不用 adb。
停止网关时主进程读 `node-pid.txt` 并 `killProcess`，因为 `node::Start` 阻塞期间
`:node` 进程收不到任何 Intent。

### 启动前的两个硬性前置（官方 getting-started）

1. **`System.loadLibrary("node")` 必须早于任何 `dlopen`**。官方集成是先由
   Android linker 在默认 namespace 加载 `libnode.so` 并执行其 `.init_array`
   （V8 / C++ 静态初始化），再调用 `node::Start`。只在 C 层 `dlopen(绝对路径)`
   时，库落在 classloader-namespace：`dlopen`/`dlsym` 都成功（界面符号探测正常），
   但 V8 初始化阶段可能直接 `abort()` 且 stdout 一片空白，表现就是
   「调用 node::Start 后进程静默消失」。`NodeRuntime.start()` 因此在自检的
   `dlopen` 之前先调 `NodeBridge.loadNodeRuntime()`。

2. **环境变量必须补齐**：Android 没有 `/tmp`，`TMPDIR` 缺失会让 V8 的临时路径
   初始化失败；`HOME`、`NODE_PATH`（指向释放出的 `node_modules`）同样是
   standalone 的定位依据。`NODE_OPTIONS` 显式清空以免外部注入触发 bad option。
   端口 / 数据目录 / 主机 / 中继一律由 C 层 `setenv` 成 `OFM_*`，
   **argv 只保留 `["node", bootstrap.cjs]`** —— 与官方 sample 完全一致，
   也不给 nodejs-mobile 的参数解析器留下把 `--port` 当成 Node 自身选项的机会。

### 分层诊断

`node-output.log` 用 `open()+write()` 直写关键阶段，不依赖可能被 Node 接管的
stdio；`bootstrap.cjs` 第一行也用 `fs.appendFileSync` 写一条
`[bootstrap] JS 层已启动`。据此能一眼分出三层：

| 日志最后一行 | 故障层 | 下一步 |
|---|---|---|
| 有 `!!! 原生崩溃 signal=SIGSEGV` | V8 初始化阶段段错误 | 多为线程栈不足；确认 C 胶水的 8MB pthread 生效 |
| 有 `!!! 原生崩溃 signal=SIGABRT` | C++ `abort()` / V8 CHECK | 查看 logcat tombstone，核对 libc++ 与 libnode 版本 |
| 只有 `[dsh-node] env:` | 原生环境已就绪，V8 初始化失败 | 检查 libnode 加载方式与 STL |
| 有 `8MB 栈 pthread 已创建` 但无 JS 心跳 | `node::Start` 内部崩溃 | 查看崩溃信号行 / logcat |
| 有 `[bootstrap] JS 层已启动` 但 `/health` 不通 | standalone 或其依赖 | 看 `[js:err]` 行的具体报错 |
| 有 `could not initialize ICU` | ★ Node 源码的 `exit(9)` 分支 | full-icu 构建缺 `icudtl.dat`；确认 CI 已把它打进 assets |
| 有 `bad option:` | ★ Node 参数解析失败 `exit(9)` | 看具体选项名，argv 应保持 `["node", 脚本]` |

### `atexit 触发` 的源码级解释

日志出现 `atexit 触发：进程走 exit() 退出` 且**没有任何 Node 文本**时，最经典的
来源是 Node 启动源码 `src/node.cc`：

```c
if (!i18n::InitializeICUDirectory(icu_data_dir)) {
  fprintf(stderr, "%s: could not initialize ICU "
                  "(check NODE_ICU_DATA or --icu-data-dir parameters)\n", argv[0]);
  exit(9);
}
```

官方 nodejs-mobile v18 是 `--with-intl=none`，不走这段；但社区 full-icu
构建需要 `icudtl.dat`。而 nodejs-mobile 的 Android 构建又明确「JS 的
`process.stdout/stderr` 输出被送到 `/dev/null`」，所以直接 `dup2` 到普通文件
时，初始化阶段的 `fprintf(stderr, ...)` 常常一条都看不到 —— 这正是
「有 atexit、无 Node 输出」的组合特征。

本版两处针对性改动：

1. **stdio 改用官方 pipe+pump 形态**：`dsh-node.c` 在 `node::Start` 前建两个
   `pipe()`，把写端 `dup2` 到 fd 1/2，再用两个 pthread 从读端泵进
   `node-output.log`（官方 `redirect-to-logcat` guide 的做法，只是目标换成文件）。
   即使 Node 随后把 stdio 换成 `/dev/null`，初始化早期写进 pipe 的文本仍会被泵出来。
2. **ICU 数据兜底**：`fetch-libnode.sh` 把 release 里可能存在的 `icudtl.dat`
   放进 `assets/node/`，`AssetInstaller.ensureIcuData()` 释放到 `nodeHome`，
   C 胶水 `setup_environment()` 检测到它才 `setenv("NODE_ICU_DATA", ...)`；
   不存在则 `unsetenv`，避免给 small-icu 构建指一个空目录反而报错。
   界面自检会显示「ICU 数据 icudtl.dat：✅/未提供」。

### Node 引擎冒烟测试

主界面的「Node 引擎冒烟测试」按钮会写 `ofm-data/smoke.flag` 后启动 `:node`。
`bootstrap.cjs` 看到标记就只做一件事：写 `smoke-result.txt`（含 `process.version`
与 intl 状态）并 `process.exit(0)` —— **不加载 bundle.zip、不碰 standalone、
不占端口、不联网**。

| 结果 | 结论 |
|---|---|
| 通过 | V8 能初始化并执行 JS，故障必在 standalone / 依赖层 |
| 失败 | `libnode.so` 引擎本身在初始化阶段就退出，与网关代码无关 |

这是把「引擎二进制问题」与「网关 JS 层问题」一锤定音分开的判据，
不用再靠猜。冒烟后点「停止网关」即可清掉标记，再正常启动。

### 运行时必须 Node 22+，且构建期必须核对（2026-11-05 22:15 截图实证）

`bootstrap.log` 的三行把最后一层定死：

```
[bootstrap] ⚠️ 运行时版本不足：上游 engines.node=^22.19.0 || >=24.0.0，当前 libnode 仅 v18.20.4
[bootstrap] 上游 start:standalone = node packages/standalone/cli.mjs
启动失败: Cannot read properties of undefined (reading 'bind')
```

`cli.mjs` 是纯 `node` 直跑、没有 tsx / `--experimental-*` 包装器；它用了
Node 22.19+ 才存在的对象，在 v18 上某个值为 `undefined`，`.bind()` 抛
TypeError 后被自身错误处理吞掉、只打印一行就安静返回 —— 于是
`import()` 已返回、但从不 `listen()`，`/health` 必然 ECONNREFUSED。
**别人 1 秒启动成功，用的是 Node 22+ 运行时，不是官方 v18.20.4。**

官方 `nodejs-mobile/nodejs-mobile` 的 Android 产物停在 **v18.20.4**
（54.6 MB zip，`--with-intl=none`）；社区 `OpenFlun/nodejs-mobile` 发布
**v22.23.2** 的 `android-libnode.zip`（arm64 `libnode.so` 约 113 MB，full-icu）。
`fetch-libnode.sh` 的解包逻辑递归找路径含 `arm64` 的 `libnode.so`，
新 zip 结构天然兼容；C 胶水的符号候选表也已覆盖 v22 可能的变体。

新增两道构建期校验，避免再出现「包里其实是 v18、界面却看不出来」：

- `fetch-libnode.sh` 从二进制内嵌字符串读出 `process.version`，CI 打印
  `运行时 Node 版本（二进制内嵌）：v22.23.2 ✅ 满足上游 engines.node`；
  若仍是 v18 就 `::warning::`，并顺带检查 `node::Start` 导出符号
- `build.yml` 留空 `libnode_url` 时默认探测 `OpenFlun/.../android-libnode.zip`；
  查询失败才回退官方 v18，**且必须同时打警告**，不许静默产出跑不起来的包

### r5：上游 managed storage 符号链接闸门（2026-11-05 23:02 截图实证）

Node 22.23.2（112.4 MB）终于进包、运行时自检八项全 ✅、JS 层已启动、
`require(entry)` 也返回了，但 `/health` 仍 ECONNREFUSED。这次上游自己把
原因打印在 `node-output.log` 里，没有走我们的 console hook：

```
[bootstrap] 已读取本机 API Key（内容不回显）
启动失败: Symlinks are not allowed in managed storage
```

**根因不是 Node 版本，是符号链接。** 上游独立服务在「托管/整合包安装」
形态下会执行一道闸门：检测到路径链或安装目录树里有符号链接就拒绝监听。
安卓这边有两处必然命中：

1. **系统路径混用**：截图里 `cwd=/data/data/com.android.dsh/files/gateway/node/`
   而 `OFM_HOME=/data/user/0/com.android.dsh/files/ofm-data`。`/data/data` 是
   `/data/user/0` 的符号链接 / bind mount，同一物理目录两种字符串表示，
   上游逐级 `lstat` 父链就会判定「路径经过符号链接」。
2. **bundle 内的 npm 链接**：CI 里 `npm install` 会在 `node_modules/.bin`
   生成大量符号链接，而 `tar -cf - .` 默认保留链接；旧脚本原样带进 bundle.zip。

r5 四层同时消除，任何一层单独生效都能过闸门：

| 层 | 改动 |
|---|---|
| C（`dsh-node.c`） | `realpath()` 规范化 home/data/cache；`chdir` 后用 `getcwd()` 读回内核真实视角，把 `NODE_PATH`/`HOME`/`OFM_*` 全部同步到同一前缀；日志打印 `r5 cwd 真实视角` |
| Kotlin（`GatewayConfig.kt` / `NodeRuntime.kt`） | `filesDir.canonicalFile`、传给 JNI 用 `canonicalPath` |
| JS（`bootstrap.cjs`） | `ROOT`/`OFM_HOME`/`NODE_PATH`/`TMPDIR` 用 `fs.realpathSync.native` 再归一化；打印 ROOT 与 DATA 的**父链符号链接**清单；启动时实体化残留链接；`.mjs` 强制走动态 `import()`（Node 22 的 `require(esm)` 会让 `import.meta.main` 失真） |
| 打包（`prepare-node-bundle.sh`） | 删 `node_modules/.bin`、`tar -h` 跟随链接实体化、打包后校验 zip 内 `S_IFLNK` 条目为 0，否则 `exit 1`；CI 日志打印链接数量 |

诊断侧同步修掉一个**掩盖真实原因**的问题：上游那句报错是直接 `write(2)`
出来的，绕过 `console.error` hook，只落在 `node-output.log`；界面却优先显示
`bootstrap.log`，于是被我们猜测的「tsx 包装器 / Node 版本低」三条旧文案盖住。
现在 `process.stdout.write` / `stderr.write` 也镜像到 `bootstrap.log`
（`[raw:stderr]` 前缀），8 秒自检失败时把上游报错原文放在 fatal 第一行，
`GatewayService` 的阶段判定新增「managed storage 符号链接闸门」分支。

### r4：默认探测误取 v18 基线 release（2026-11-05 CI 日志实证）

r3 的闸门**确实生效了**，而且这次明文 `build.yml` 也确实提交了（`workflow 版本：
2026-11-05-r3` 出现在日志里）。job 变红不是编译错误，是闸门按设计拦下了
一个 v18 包。CI 日志把根因写得很直白：

```
默认探测命中：https://github.com/OpenFlun/nodejs-mobile/releases/download/v18.20.4/android-libnode.zip
==> libnode.so: 59.6 MB · v18.20.4
闸门核对 : 59.6 MB | 内嵌版本候选 = v18.20.4, v10.12.0
##[error]打进 APK 的 libnode.so 只有 59.6 MB
```

旧探测是 `.[] | .assets[] | test("android-libnode") | head -n1`，遍历所有
release 取第一个同名资产。**OpenFlun 仓库最早的 release 是 `v18.20.4` 基线**
（同样带 `android-libnode.zip`，里面是 59.6 MB 的 v18 `.so`），于是被选中。
注意这个 v18 基线是 59.6 MB，而官方 `nodejs-mobile/nodejs-mobile` 的
arm64 是 47.2 MB —— **体积不是跨来源的可靠判据**。

r4 三处修改：

1. 探测 jq 改为**按 tag 的 major ≥ 22 过滤**
   `select(.tag_name | test("^v?(2[2-9]|[3-9][0-9])\\."))`，取第一个
   `android-libnode` 资产；**删除回退官方 v18 的分支**，找不到就直接
   `::error:: + exit 1`，并给出 GitHub / Gitee 两个 release 页。
2. 加 URL 语义校验：命中 `.../v18.` 或 `.../18.20.4/` 直接失败，不必等闸门。
3. 闸门判据改为**内嵌版本字符串优先**（最大的 `vNN.x.y` 即 Node 自身版本，
   major < 22 判失败），体积只在读不到版本时兜底；`libnode.so` 不存在时
   也改为 `exit 1`，因为步骤 7 带 `continue-on-error`，下载失败会被吞成
   黄色，若不拦就会产出「能装但没有引擎」的废 APK。

CI 日志里认 `workflow 版本：2026-11-05-r4` 与
`默认探测命中（Node 22+）：.../v22.23.2/android-libnode.zip`。

### r3：编译期硬闸门（2026-11-05 22:30 截图后补）

22:30 的截图仍是 `47.2 MB / node=v18.20.4`——**两个硬指标都没变，说明这次 APK
用的还是旧运行时**，`pid` 从 7328 变 9733 只是重启 App，不代表换了包。
改动文件本身是对的，断在「文件 → CI → APK」这条链上。而原设计有个漏洞：
版本识别写在 `fetch-libnode.sh` 内部，但下载步骤带 `continue-on-error: true`，
一旦下载失败 / 被变量覆盖 / 工程包自带旧 `.so`，脚本根本没跑，v18 就静默
混进一个**能安装、能打开、但一定启动失败**的 APK。

`build.yml` 新增独立步骤「运行时版本闸门」（不受 `continue-on-error` 影响）：
无条件读取 `app/src/main/jniLibs/arm64-v8a/libnode.so`，**体积 < 60 MB 即判定
v18 并 `exit 1` 让 job 直接变红**，同时打印四条定位提示。体积判据与界面自检的
「二进制核对：47.2 MB」一一对应，不易被内嵌版本字符串干扰。

CI 日志里搜 `workflow 版本：2026-11-05-r3`：
- **搜不到** → 仓库根的明文 `build.yml` 没覆盖提交（GitHub 只认明文，zip 里的不算）
- 搜到且 job **红、报「只有 47.2 MB」** → 闸门正常拦截，按报错里的四条改来源
- 搜到且打印 `✅ 闸门通过：113.x MB` → 这次才是真的 Node 22+ 包

> ⚠️ 交付流程教训：曾经出现过「回复里描述了改动、但文件没有真正落盘、
> 交出去的仍是旧 zip」的情况，结果用户重新构建后拿到的依旧是 47.2 MB 的
> v18（界面 `node=v18.20.4` + `二进制核对：47.2 MB` 即为铁证）。
> 判断这次到底换没换运行时，**只看两个硬指标**：
> `libnode.so` 体积约 **113 MB**（v18 是 47.2 MB）、`bootstrap.log` 首行
> `node=v22.x`。二者任一没变，就说明新包没进到这次构建里。

### 假「运行中」：/health 未握手却被当成 READY（2026-11-05 21:31 截图实证）

`.cjs` 修好后界面显示「运行中 / 端口 18900 / API Key 已生成」，但管理页
`ERR_CONNECTION_REFUSED`、RikkaHub 取不到模型、启动要等约 50 秒。日志底部
其实已经写明真相：

```
[dsh-node] watchdog tick=30
[dsh-node] node::Start 返回 rc=1（Node 主循环已结束）
```

**Node 进程已经退出，18900 从头到尾没有任何服务监听。三个症状同源。**

代码级原因有两处，现已全部修复：

1. `HealthProbe.awaitRuntime` 旧版超时后**把已解析到的 `parsed` 返回出去**
   （注释说「由界面显示未就绪」，但调用方没配合）；
2. `GatewayService.boot()` 拿到非 null 就 `post(READY)`，**从不检查 `info.healthOk`**。

于是 45 秒超时一到，界面就把「`gateway-runtime.json` 存在 + 旧 `settings.json`
里有个 Key」误当成「服务已就绪」。那 50 秒不是启动耗时，是超时等待；
别人移植版 1 秒成功，是因为人家 `/health` 真的立刻通了。

修复：超时一律返回 `null`、默认超时缩短到 30 秒、`boot()` 显式检查
`healthOk`，并在失败文案里写明「/health 从未握手成功，端口上没有服务监听」。

**为何 standalone 没监听**：`node::Start` 正常返回 rc=1 说明事件循环跑空了，
而 `main()` 的 catch 没触发（`node-errors.log` 里没有「启动 standalone 失败」）——
也就是**入口被加载了、没抛异常、但没启动 HTTP 服务**。三个高概率方向：

- 上游 `start:standalone` 用了 `tsx` / `node --experimental-*` / `--import` /
  `--env-file` 等包装器，直接 `require` 入口缺少前置条件
- 入口只导出 `start()` 而不自启动，或依赖 `import.meta.main` 这类新版特性
- **Node 版本不足**：上游文档要求「符合仓库 engines 的 Node.js」，社区实测
  **Node 22+**；而 nodejs-mobile 官方 Android 构建只有 **v18.20.4**

为此新增 `bootstrap.log`（独立、不被 C 层 watchdog 心跳刷屏，界面优先显示），
里面记录 `上游 start:standalone` 原文、`package.json type`、`engines.node`、
实际命中的入口、`require`/`import` 返回情况；`prepare-node-bundle.sh` 也会在
CI 日志里打印同样三项。加载后 8 秒主动探测 `/health`，没监听就写
`node-fatal.txt`，`HealthProbe` 下一轮（≤400ms）立刻收尾，不再干等 30 秒。

> 排障优先级：`bootstrap.log` → CI 构建日志的「上游独立服务启动方式」段落 →
> logcat 的 `nodejs` tag。若 `engines.node >= 20` 而当前 libnode 是 18，
> 需要换 Node 22+ 的 Android `libnode.so`（社区 full-icu 构建，记得带
> `icudtl.dat`），或转方案 B 由 Termux 提供完整 Node。

### 定案：真正的根因是 `.js` 被当成 ES module（2026-11-05 logcat 实证）

此前十几轮都误判为「Node 引擎初始化期崩溃」。用 `adb logcat -d -b main,system,crash`
抓到 `:node` 进程（pid 23855）从 `Start proc` 到 `has died` 的完整 1 秒窗口后，
logcat 里出现了决定性原文：

```
E nodejs  : ReferenceError: require is not defined in ES module scope, you can use import instead
E nodejs  : This file is being treated as an ES module because it has a '.js' file extension and
            '/data/data/com.android.dsh/files/gateway/node/package.json' contains "type": "module".
            To treat it as a CommonJS script, rename it to use the '.cjs' file extension.
E nodejs  : Node.js v18.20.4
D RefBase : #01 pc ... libc.so (exit+24)
D RefBase : #02 pc ... libnode.so (node::DefaultProcessExitHandler(node::Environment*, int)+80)
I Zygote  : Process 23855 exited cleanly (1)
```

**引擎一直是好的**：V8 初始化成功、ESM loader 正常工作、还打印了 `Node.js v18.20.4`。
真相是启动入口 `bootstrap.js` 与上游仓库根 `package.json`（`"type": "module"`）同目录，
Node 按 ESM 解析它，第一行 `const fs = require('fs')` 抛 `ReferenceError` →
未捕获异常 → `node::DefaultProcessExitHandler` → `exit(1)` → 我们的 `atexit_probe` 触发。
`Zygote: exited cleanly (1)` 与「有 atexit、无崩溃信号、无 JS 心跳」全部对上。

**为什么之前所有日志都看不到这句**：nodejs-mobile 的 Android 构建把 ESM loader /
启动期错误以 logcat tag **`nodejs`** 直接输出，不写 fd 1/2。C 层的 stdio pipe pump
和 `dup2` 只能接到写进 stdout/stderr 的内容，接不到 `__android_log_print`。
所以 `node-output.log` 里干净得像没跑过，而 logcat 里其实一直有答案。

修复：**入口改名为 `bootstrap.cjs`**（Node 在错误信息里给的建议）。`.cjs` 强制
CommonJS，`require` 可用；上游 `type: module` 保持不变，standalone 的 ESM 模块由
`require(entry)` → `ERR_REQUIRE_ESM` → 动态 `import()` 回退加载。
`resolveEntry()` 的正则与候选同时放宽到 `.mjs` / `.cjs`。

配套改动：`prepare-node-bundle.sh` 注入 `.cjs` 并在 `bundle-version.txt` 加 `-cjs`
硬标记；`AssetInstaller` / `RuntimeDiagnostics` / `NodeRuntime` 的入口检查全部改指
`.cjs`，确保手机上旧版 `bootstrap.js` 一定被重新解压替换。

> 排障经验：安卓上排查 nodejs-mobile，**logcat 是第一手证据**，app 私有日志只能作补充。
> 纯手机可用「Termux + 无线 ADB 自连」或 MT 管理器的终端执行 `adb logcat -d` 抓取。

### 二进制溯源

CI 不再用「最新 release 里任意名字带 android 的资产」—— 那可能拿到社区
fork 的 full-icu 构建。现在精确锁定官方核心库 **v18.20.4 的
`nodejs-mobile-v18.20.4-android.zip`**，并在构建前自检打印：文件大小、
SHA-256 前 16 位、ELF 的 `e_machine`（必须是 183 = AArch64）、`icudtl.dat`
是否随包提供。`fetch-libnode.sh` 里若 ELF 不是 64 位 arm64 会直接拒绝打包。
界面「运行时自检」也显示同样的体积与架构核对结果，手机端可直接比对。

### 为什么 `node::Start` 要单独开 8MB 栈的 pthread

Android 的 JVM / JNI 线程默认栈约 1MB，而 V8 在初始化与解析 JS 时会递归
使用较深的栈，容易直接 `SIGSEGV` —— 原生段错误不走 stdout/stderr，表现就是
「日志停在『即将调用 node::Start』之后一片空白、进程静默消失」。官方
getting-started 说的「后台线程」只是相对 UI 线程，真正可靠的做法是 C 层用
`pthread_attr_setstacksize(&attr, 8 * 1024 * 1024)` 开一个原生线程专门跑
`node::Start`，JNI 线程只负责 `pthread_join` 等待。

同时 C 胶水在调用前用 `sigaction` 装了 `SIGSEGV/SIGABRT/SIGBUS/SIGILL/SIGFPE`
捕获，只用 `open/write/close` 把信号编号写进 `node-output.log`。即便 V8 崩溃，
界面也能看到「原生崩溃 signal=…」，不必再靠猜。

符号解析最终改为**官方的 `DT_NEEDED` 链接形态**：`cpp/CMakeLists.txt` 在
`app/src/main/jniLibs/${ANDROID_ABI}/libnode.so` 存在时，把它声明为
`IMPORTED SHARED` 并 `target_link_libraries(dsh-node node ...)`，于是
`libdsh-node.so` 带 `DT_NEEDED: libnode.so`。Android linker 在加载胶水时会
自动把 libnode.so 带进**同一个 classloader namespace** 并在加载期绑定
`node::Start` —— 进程里只有一份，V8 的 C++ 静态初始化与内部符号解析都在
正确环境里完成。

这正是前几轮最隐蔽的偏差：`dlopen(绝对路径) + dlsym` 能成功解析符号
（界面「符号探测」一直是 OK），但库落在 dlopen 的 namespace，`node::Start`
一进入 V8 初始化就静默退出，stdout 一行都不写。C 胶水用 weak 声明
`_ZN4node5StartEiPPc`，链接不到时自动回退 `RTLD_NOLOAD` → `dlopen`，界面会
如实标注「回退 dlopen 绝对路径」；CI 的「构建前自检」也会打印本次走的是哪种形态。

### 进程消失的三条路径，现在都能区分

`dsh-node.c` 在 `node::Start` 前装了三层观测：

| 观测 | 能识别 |
|---|---|
| `sigaction` 捕获 SIGSEGV/ABRT/BUS/ILL/FPE | 被可捕获信号杀死；`!!! 原生崩溃 signal=` 行 |
| `atexit` 回调 | `node::Start` 内部直接 `exit()`（既不是崩溃也不是被杀） |
| 独立 pthread 每 0.5s 写 `watchdog tick=N` | 前两者都没有 → SIGKILL / 系统内存回收 / V8 覆盖了 signal handler；tick 数还能估算存活秒数 |

注意 V8 在初始化时会安装自己的 SIGSEGV handler 用于 stack guard，可能覆盖
我们装在 `node::Start` 之前的那个 —— 这也是「明明崩了却没有崩溃信号行」的一种
解释，此时 watchdog 的最后一个 tick 就是唯一线索。

`console.log` / `console.error` 在 bootstrap.cjs 里被覆写，除走 stdout 外还会用
`[js]` / `[js:err]` 前缀直写同一份日志，因此 standalone 的输出不会因 stdio
被重新接管而丢失。`prepare-node-bundle.sh` 把 `bootstrap.cjs` 的哈希写进
`bundle-version.txt`，改动入口后手机端一定会重新解压，不会沿用旧脚本。

`bootstrap.cjs` 的入口定位是容错的：优先从根 `package.json` 的 `scripts["start:standalone"]` 里正则提取 `node xxx.js`，否则依次试 `packages/standalone/src/index.js`、`index.js`、`dist/index.js`、`server.js` 等。若上游改了文件名，只需改 `resolveEntry()` 的 `candidates`。

`bootstrap.cjs` 还负责三件壳做不到的事：把 `OFM_HOME` 指向 `filesDir/ofm-data`、劫持 stdout 抓**一次性管理链接**与**实际端口**、轮询 `settings.json` 取 Key，最后原子写 `gateway-runtime.json`（0600）。异常一律写 `node-errors.log` 且**不调用 `process.exit()`**——在安卓里 exit 会把宿主 App 一起结束。

---

## 6. RikkaHub 怎么配

1. 打开「聚合网关」→ 启动网关 → 等状态变「运行中」，记下**实际端口**（被占用会顺延）。
2. RikkaHub → 设置 → 提供商 → 添加 → **OpenAI**
   - **Base URL**：`http://127.0.0.1:18900/v1`（必须以 `/v1` 结尾，RikkaHub 会自动拼 `/chat/completions`，别重复写路径）
   - **API Key**：主界面「复制 API Key」；`Authorization: Bearer` 由 RikkaHub 自动加，不要手动配 header
   - **模型**：进提供商详情「添加模型」，ID 从主界面「复制模型 ID 清单」粘贴（会请求 `/v1/models`）
3. 回到聊天界面，顶部选刚添加的模型即可。

三个坑：

- **明文 HTTP**：Android 9+ 默认禁止明文。本工程用 `network_security_config.xml` 只对 `127.0.0.1` / `localhost` 放行；**RikkaHub 是另一个 App，它自己也需要允许回环明文**（它的文档有 `http://localhost:11434/v1` 这类示例，通常已放行）。若连接失败先查这一层，不是网关的问题。
- **长思考易超时**：SSE 注释帧只维持连接、不重置客户端的空闲看门狗。选 `reasoning: false` 的模型或调大单次输出上限更稳。
- **二维码不是原生导入格式**：主界面生成的是「Base URL + Key」的**配置文本二维码**，供手动粘贴；RikkaHub 的扫码导入串包含它自己的编码结构，本工程不伪造。要原生扫码请用 RikkaHub 自带的 Provider Share 生成。二维码**含 Key**，只发给可信对象。

---

## 7. 悬浮窗与存活能力

悬浮窗的作用要说准：**它本身不保活**，真正保活是三重约束——

| 层 | 实现 | 作用 |
|---|---|---|
| 前台服务 | `GatewayService`，`foregroundServiceType="specialUse"` + 常驻通知 | 提高进程优先级，系统不易回收 |
| 唤醒锁 | `PARTIAL_WAKE_LOCK` | 息屏后 CPU 继续服务请求 |
| 悬浮窗 | `TYPE_APPLICATION_OVERLAY`，48dp 可拖动的可见浮层 | 降低部分厂商 ROM 对后台的激进回收；用户一眼能看出网关是否还活着；点开可复制配置 / 打开管理页 / 重启 |
| 电池白名单 | 主界面按钮跳 `ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS` | 避免锁屏清理与 Doze 冻结 |
| 开机自启 | `BootReceiver`（Manifest 里默认 `enabled=false`） | 可选，需用户显式开启 |

已知系统限制：

- **Android 15（API 35）对 `dataSync` 类前台服务有每天约 6 小时上限**。本工程用 `specialUse` 并声明 `PROPERTY_SPECIAL_USE_FGS_SUBTYPE`；上架 Play 时需说明用途，或改用其它合规类型。
- 厂商 ROM（部分国产系统）可能无视前台服务杀后台，需要在系统「应用信息 → 电池 / 自启动 / 后台锁定」里手动加白名单。
- Node 在一个进程里**只能初始化一次**：`NodeRuntime` 用 `AtomicBoolean` 守住重复启动；「划掉 App」时 libuv 线程可能仍占端口，所以 `HealthProbe` 冷启动前会删掉上一轮 `gateway-runtime.json`，并以 `/health` 握手为准，不以「进程还活着」为准。
- 原插件的 `service.lock` 残留由 `bootstrap.cjs` 校验 PID 后清理（与桌面文档一致）。

---

## 8. 管理页

standalone 自带**独立网页管理**，启动时终端会打印一条**一次性登录链接**。`bootstrap.cjs` 从 stdout 抓到它写进 `gateway-runtime.json`，`ManageActivity` 用 WebView 打开；抓不到时回退到 `http://127.0.0.1:<port>/`，也可点「外部浏览器」用系统浏览器打开。

管理页管的是**网关配置与观测**（模型清单与探测、请求数 / 回合数 / Token / 热力图、渠道 Key 写入与测试、EAC 与账号登录、Key 生成轮换、中继开关、设置），**不是聊天界面**。聊天、消息分支、Markdown、MCP、记忆、助手人格全在 RikkaHub 那边。两者通过 HTTP 对接，不需要同屏。

WebView 已关闭 `allowFileAccess` / `allowContentAccess`，只允许跟进回环地址，其余链接交给系统浏览器；`mixedContentMode = NEVER_ALLOW`。

---

## 9. 权限与数据边界

| 权限 | 用途 |
|---|---|
| `INTERNET` / `ACCESS_NETWORK_STATE` | 上游模型请求、探测可用性、开本地 socket |
| `FOREGROUND_SERVICE` / `FOREGROUND_SERVICE_SPECIAL_USE` | 常驻服务 |
| `POST_NOTIFICATIONS` | Android 13+ 前台服务通知 |
| `SYSTEM_ALERT_WINDOW` | 悬浮球（用户手动授权，未授权不影响服务） |
| `WAKE_LOCK` / `REQUEST_IGNORE_BATTERY_OPTIMIZATIONS` | 保活 |
| `RECEIVE_BOOT_COMPLETED` | 可选开机自启 |

数据全部落在 app 私有目录：`filesDir/ofm-data`（Key、统计、账号凭据）与 `filesDir/gateway/node`（代码）。`backup_rules.xml` / `data_extraction_rules.xml` 已把 `ofm-data` 与配置 SharedPreferences **排除出云备份和设备迁移**，避免 Key 随备份外流。

---

## 10. 必须知道的风险与边界

- **包名 `com.android.dsh` 已照用**，但 `com.android.*` 是 AOSP 常见命名空间：个别 ROM 预置了同包名的系统组件时，可能出现安装冲突或签名校验提示。若遇到，改成 `com.aggregate.gateway` 之类即可（`applicationId` + `namespace` 两处，代码目录可保持）。
- **「免费不限量」的真实含义**：没有计费体系、不按 token 收费，但免费车道**按 session 限速**，短时间打满返回 429，插件会标记「已达限额」并在下一轮探测后恢复。部分模型上游延迟很高。
- **隐私**：提示词、工具结果、图片会原样发给上游；部分免费档条款允许用提交内容改进服务。密码、密钥、个人身份信息、商业机密不要往里送。
- **账号渠道**：依赖逆向第三方 AI 工具免费额度的渠道，稳定性与合规风险都高于干净的免费车道，已有渠道被下架的先例。建议只用免费车道与 Kilo。
- **不要通过 npm 安装**：npm 上的同名 `dsh-our-free-model` 是无关第三方打包，`index.js` / `client.js` 被改动且多了本仓库没有的文件。本工程只认 `git clone` 到的完整源码。
- **信任链变化**：插件侧的应用内升级以 pin 的 Ed25519 公钥 + SHA-256 清单为信任根；本 APK 的「更新上游源码」只做结构校验、不做签名校验。运行时 `libnode.so` 来自 OpenFlun/nodejs-mobile 的 GitHub Release（第三方构建，非 Node 官方 Android 版），CI 打印 SHA-256 与 ELF 架构、闸门按 major>=22 拦截；请自行核对来源。
- **未验证项**：`vendor/channel-pack/` 的 WASM、签名校验、公告与热重载在 arm64 安卓 Node 上，以及 Gemini / Cline 的 OAuth 回调。
- 源码为明文 JavaScript，作为本地服务必须如此；能访问该目录的人即可读懂网关逻辑，这是分发形态的固有属性。

---

## 11. 本次交付边界

按要求**只给源码、不编译 APK**。因此以下事项留给你在真机上验证：nodejs-mobile 具体发行版的 `start(...)` 签名（`NodeRuntime` 用反射兼容了常见两种）、`packages/standalone` 的真实入口文件名、WASM 在 arm64 上的行为、以及 RikkaHub 对明文回环的放行情况。

最小验证顺序建议：装 APK → 启动网关 → 主界面出现实际端口与 Key → 打开管理页能看到模型清单 → RikkaHub 手填一个 `beam-free` 发出第一条消息。前三步验「回环通不通、后台活不活」，第四步才验业务。
