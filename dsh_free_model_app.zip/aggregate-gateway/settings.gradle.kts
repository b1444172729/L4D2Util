pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

// 用 ASCII 项目名：Gradle 会拿它生成 IDE 工程名与部分构建产物路径，
// 在 CI 的不同 locale/编码环境下中文偶有边缘问题。应用显示名仍是「聚合网关」
// （见 res/values/strings.xml 的 app_name）。
rootProject.name = "AggregateGateway"
include(":app")
