# 本机 OpenCode Zen 免费模型网关（B 方案改造说明）

本文件是**改造后工程**的权威说明。旧 `README.md` 里 r17/r11/r5 的长篇排障日志，
只有「Android 运行时 / JNI / 前台服务」部分仍然适用，网关逻辑以本文为准。

> **429 策略（默认纯透传）**：管理页可填自有 Zen API Key 走独立额度。用自有 Key +
> 单人手动聊天时，429 的 body 与上游 `Retry-After` 原样透传，**不冷却、不下架、
> 不回本地 200 提示**；短时限流按 `Retry-After` 等几秒手动重试即可。
> 「单模型冷却 + 临时下架 + 本地提示」保留为 `cooldownEnabled` 可选开关（默认 false），
> 供自动化 / 多客户端 / LAN 中继等重试风暴场景使用。详见第 4、7、9 节。
> Android 壳与编译流程完全不用改。

---

## 1. 到底改了什么

用户目标：把 `yu-wenchao/dsh-opencode-free-models` 做成**手机上本地可调用**的网关，
且在这个「聚合网关」Android 工程里改。

先说清楚一个事实：**那个插件不是网关，没有 HTTP 服务端**。它在 DSH 里只干两件事：

| 插件在 DSH 里做的事 | 依赖谁 |
|---|---|
| 从作者后端 `GET /api/models` 拉免费模型清单，放进 🎁 抽屉面板，点「一键置入」写进 `llm-pi-ai.providers.opencode--*` | DSH 宿主 + 作者后端 `free-api.gd7.cn/opencode` |
| 生成 provider 条目：`apiKeyEnv: OPENCODE_ZEN_API_KEY`（宿主注入字面量 `public`）、`baseURL: https://opencode.ai/zen/v1` | DSH 宿主 `llm-pi-ai` 负责真正发请求 |

手机上没有 DSH，所以面板、`127.0.0.1:18766` 授权桥、`cordis.patch.yml`、模型选择器全都无从加载。
因此本改造是**等价重写，不是移植插件代码**：

- **清单**：本机 `GET /api/models` 提供，注册进 `GET /v1/models`；
- **调用**：本机 `/v1/chat/completions` 等统一转发到 `https://opencode.ai/zen/v1`，
  用 `Bearer public`，客户端只认 `127.0.0.1` 与一把**本地 Key**。

这就是 B 方案（数据面 + 控制面都在本机），和你上传的 APP 形态一致：
RikkaHub 只是聊天前台，网关跑在手机里。

---

## 2. 文件清单

**新增 / 重写（都在 `app/src/main/assets/node/`）：**

| 文件 | 作用 |
|---|---|
| `bootstrap.cjs` | Node 启动胶水。保留冒烟测试、日志镜像、路径 realpath 规范化；改为 `require('./opencode-gateway.cjs')` |
| `opencode-gateway.cjs` | ★ 网关本体：清单、本地 Key、`/health`、OpenAI 兼容转发、本地控制面、管理页；含自有 Zen Key 热更新与 429 策略开关（默认纯透传） |
| `package.json` | 包元数据，`type: commonjs`，`engines.node >= 22.19.0`（`AssetInstaller` / `RuntimeDiagnostics` 仍检查它） |
| `models.builtin.json` | 免费模型离线兜底快照（2026-11-10 公开目录，限时提供） |
| `web/index.html` | 本机管理页（自有 Zen Key、429 策略开关、冷却状态、模型上下架、刷新目录、用量、总开关），替代插件的 DSH 抽屉面板 |
| `bundle-version.txt` | 代码内容哈希，`AssetInstaller` 据此决定是否重建 `filesDir/gateway/node` |

**改过的工程文件：**

- `scripts/prepare-node-bundle.sh` → 不再 clone 上游整仓 / 不 `npm install` / 不联网，只做离线校验、`node --check`、零符号链接检查、生成版本标记
- `core/AssetInstaller.kt` / `core/RuntimeDiagnostics.kt` → 完整性判据从 `packages/standalone/cli.mjs` 换成 `opencode-gateway.cjs` 等四件套
- `core/SourceUpdater.kt` → 「更新上游源码」改成「刷新免费模型目录」：只拉官方 `/models` 的 JSON 写进 `ofm-data/models.json`，**不下载也不执行任何外部代码**
- `core/GatewayService.kt` / `MainActivity.kt` / `values/strings.xml` → 文案改为本机网关语义
- `.github/workflows/build.yml` / `scripts/fetch-libnode.sh` → 自检项、闸门与日志文案同步；**libnode.so 的下载与 Node 22 硬闸门完全保留**

**完全没动：** `AndroidManifest.xml`、`GatewayConfig.kt`、`HealthProbe.kt`、`NodeRuntime.kt`、
`NodeService.kt`、`NodeBridge.java`、`cpp/dsh-node.c`、`CMakeLists.txt`、`ManageActivity.kt`、
`FloatingWindow.kt`、`UiTheme.kt`、`RikkaHubHandoff.kt`、`network_security_config.xml`、Gradle 配置、图标资源。

> 之所以 Java/Kotlin 主逻辑几乎不用改，是因为新网关**严格复刻了旧 standalone 与壳之间的契约**（见第 5 节）。

---

## 3. 端点

| 路径 | 鉴权 | 说明 |
|---|---|---|
| `GET /health` | 无 | `HealthProbe.awaitRuntime()` 握手用，返回 2xx 才置 READY |
| `GET /v1/models` | `Bearer <本地Key>` | OpenAI 格式，`HealthProbe.fetchModelIds()` 从这里取模型 ID |
| `POST /v1/chat/completions` | `Bearer <本地Key>` | 流式 / 非流式转发到上游 `/chat/completions`，SSE 逐块透传 |
| `POST /v1/responses` | 同上 | 转发到 `/responses` |
| `POST /v1/messages`、`/v1/messages/count_tokens` | 同上 | 转发到同名上游路径 |
| `GET /api/models` | 回环免鉴权 | **原作者后端 `/api/models` 的本地等价物**，返回 `{ok,total,total_pages,page,page_size,opencode_enabled,items[]}` |
| `GET /api/version`、`/api/articles`、`/api/license?act=status` | 回环免鉴权 | 本地版，替代插件的远程控制面 |
| `POST /api/models` | 回环免鉴权 | `toggle-global` 总开关 / `toggle-model` 上下架 / `clear-cooldown` 提前结束冷却（仅冷却模式有效） |
| `POST /api/settings` | 回环免鉴权 | `{zenKey, cooldownEnabled, cooldownMinutes}`，**热更新立即生效、无需重启网关** |
| `POST /api/refresh`、`/api/license?act=toggle` | 回环免鉴权 | 刷新目录 / 授权开关 |
| `GET /api/usage`、`/api/settings` | 回环免鉴权 | 用量与设置（**只回显本地 Key 指纹与 Zen Key 尾 4 位，绝不回显完整 Key**） |
| `GET /` | 无 | 管理页，`ManageActivity` 的 WebView 打开 `manageUrl` |

所有响应带 CORS 头并处理 `OPTIONS` 预检（WebView / 外部浏览器调试都能用）。

**开关的本地等价物**：`settings.opencodeEnabled`（总开关）→ `settings.authorized`（授权）
→ 单模型 `status / usable / available_from / available_until / hidden` →
**429 冷却（默认关闭，纯透传模式下完全不参与过滤）**，取交集后才进 `/v1/models`。
原插件的 fail-closed 是「等远端授权信号」；本机没有远端，改成把授权开关留在用户自己手里，默认已授权。

---

## 4. 环境变量（由 `cpp/dsh-node.c` 的 `setenv` 注入，argv 仍是 `["node", bootstrap.cjs]`）

| 变量 | 默认 | 说明 |
|---|---|---|
| `OFM_PORT` | `18900` | 被占用时自动顺延最多 20 个端口，实际端口写回 `gateway-runtime.json` |
| `OFM_HOST` | `127.0.0.1` | 回环主机 |
| `OFM_HOME` / `OFM_DATA_DIR` | `filesDir/ofm-data` | Key、清单、用量、日志 |
| `OFM_LAN_RELAY` | `0` | `1` 时绑 `0.0.0.0` 并启用独立 LAN Key |
| `ZEN_BASE_URL` | `https://opencode.ai/zen/v1` | 上游网关；改它可接自建代理 / 本地 mock |
| `OPENCODE_ZEN_API_KEY` | `public` | 仅作环境变量兜底；Android 上 C 层不注入它，实际请用管理页配置（见下） |
| `ZEN_EXTRA_HEADERS` | 空 | JSON 字符串，额外透传给上游的请求头（见第 7 节） |

**★ 自有 Zen Key 在手机上的配置方式**：打开主界面「管理页」→ 在 ① 里粘贴 `oc_sk_…` →
「保存并立即生效」。Key 写入 `ofm-data/settings.json` 的 `zenKey`，网关**热更新**内存变量，
不用重启 App、不用改 Kotlin、不用重新编译。优先级：

```
settings.zenKey  >  OPENCODE_ZEN_API_KEY  >  'public'
```

填了自有 Key 后额度与匿名共享池分开，网关会自动清掉匿名档遗留的 429 冷却。
「清空 / 恢复 public」即退回匿名档。

**★ 429 策略在管理页 ② 区切换**，写入 `settings.json` 的 `cooldownEnabled`，热更新无需重启：

| 模式 | 默认 | 行为 |
|---|---|---|
| **纯透传** | ✅ 是 | 429 body + 上游 `Retry-After` 原样送达；不冷却、不下架、不回本地 200 提示 |
| 冷却兜底 | 否 | 恢复单模型冷却 + 临时下架 + 本地提示（详见第 9 节） |

老版本升级时 `settings.json` 里没有 `cooldownEnabled` 字段，一律按 `false` 处理，
**不会**让上一版的冷却行为在新版悄悄继续生效；启动与关闭开关时都会清空历史冷却记录。
冷却时长（1–60 分钟，默认 15）仅在冷却模式下生效，管理页会灰掉该输入。

数据文件：`ofm-data/settings.json`（`forwardKey` / `lanKey` / `zenKey` / `cooldownMinutes` / 开关，0600）、
`gateway-runtime.json`（`port` / `requestedPort` / `apiKey` / `manageUrl` / `host`，0600）、
`models.json`（刷新后的清单）、`cooldowns.json`（429 冷却到期时间，重启后仍保留）、
`usage.json`、`bootstrap.log`、`node-output.log`、`node-fatal.txt`。

---

## 5. 为什么 Android 壳不用改

| 壳的期待 | 新网关怎么满足 |
|---|---|
| `NodeRuntime` 找 `nodeHome/bootstrap.cjs`，argv 极简 | 文件名不变，配置全读环境变量 |
| `HealthProbe.awaitRuntime()` 读 `gateway-runtime.json` 的 `port/apiKey/manageUrl/requestedPort` | 网关启动时原子写，Key 非空；listen 成功后再写实际端口 |
| `HealthProbe.pingHealth()` 无 Key 请求 `/health` | `/health` 无条件 2xx |
| `HealthProbe.fetchModelIds()` 带 `Authorization: Bearer` 请求 `/v1/models` | 校验本地 Key 后返回 `data[].id` |
| `GatewayService` 读 `bootstrap.log` / `node-output.log` / `node-fatal.txt` | 全部沿用，冒烟分支仍写 `smoke-result.txt` |
| `ManageActivity` 打开 `manageUrl` | 网关写 `http://127.0.0.1:<port>/`，提供管理页 |
| `network_security_config.xml` 只对回环放行明文 | 客户端到网关是回环 HTTP；网关到上游是 HTTPS |

---

## 6. 编译与使用

**编译**（沿用原 CI，仍只出 arm64-v8a / minSdk 26）：

```bash
# 1) 离线校验网关源码 + 生成 bundle-version.txt（不再联网 clone）
./scripts/prepare-node-bundle.sh

# 2) 放置 Node 22 的 arm64 libnode.so（仍是 OpenFlun/nodejs-mobile v22.23.2）
./scripts/fetch-libnode.sh "<release-zip-url>" "<可选 sha256>"

# 3) Android Studio / Gradle 8.9 编译：需 SDK 35 / NDK 27.0.12077973 / CMake 3.22.1 / JDK 17
```

GitHub Actions 的 `.github/workflows/build.yml` 仍会自动完成 1→2→3 并产出 debug APK。

**手机上使用**：

1. 装 APK → 点「启动网关」→ 等状态变「运行中」（`/health` 真握手才算 READY，不是看进程在不在）。
2. RikkaHub → 设置 → 提供商 → 添加 → **OpenAI**
   - Base URL：`http://127.0.0.1:18900/v1`（端口被占用会顺延，用主界面显示的**实际端口**）
   - API Key：主界面「复制 API Key」（这是**本机网关自己的 Key**，不是 `public`）
   - 模型：主界面「复制模型 ID 清单」→ 在提供商详情里手动添加
3. 管理页：主界面「打开管理页」，可填自有 Zen Key、切换 429 策略、刷新免费模型目录、上下架单模型、看用量、关总开关。
4. **出现 429 时（默认纯透传）**：RikkaHub 会显示上游真实错误与 `Retry-After`，
   按它提示等几秒再手动重试，或换个模型；网关不改写、不伪装成模型回复。
   最有效的根治办法仍是管理页 ① 填自有 Zen Key。详见第 9 节。

「刷新免费模型目录」按钮 = 联网拉 `https://opencode.ai/zen/v1/models` 并筛出免费模型，
写入 `ofm-data/models.json`；失败保留现有清单。「恢复内置快照」删掉该文件，回退 APK 内置清单。
网关启动时也会后台刷一次，刷新失败一律用缓存，**绝不阻塞 `/health`**。

---

## 7. 必须知道的风险（会直接决定能不能用）

1. **匿名免费档会按请求内容判定，不只是请求头。** 公开资料明确提到免费车道会看工具声明、
   请求体结构、客户端身份乃至 TLS 特征；官方文档也提示免费档聊天模型限时提供且主要面向
   OpenCode 自身客户端。本网关**不做 CLI 身份 / TLS 指纹伪装**（那套没有公开契约，写死只会随时间失效），
   只发 `Authorization: Bearer public` + `x-opencode-session`（OpenCode 文档公开要求的会话头）。
   因此从 Android 直接打，**可能返回 403 / 需付费 / 429**。网关默认把上游状态码、body 与
   `Retry-After` **完全原样透传**，不伪造成功、不改写错误（仅手动开启冷却模式时才有本地提示响应，
   见第 9 节）。若确定上游要求额外请求头，可通过 `ZEN_EXTRA_HEADERS`（JSON）补充；
   **根治 429 请走管理页填自有 Zen Key**——只改认证与额度，不改模型清单。

2. **内置清单是快照，不是实时列表。** `models.builtin.json` 取自 2026-11-10 前后公开目录，
   免费模型「限时提供、名单随时变化」。首次联网刷新后以 `models.json` 为准；某个 ID 报
   「model unavailable」时，先点刷新目录，再到管理页隐藏它。

3. **免费不等于不限量。** 上游有每日请求上限且未公开具体数字，短时打满返回 429，
   且匿名档按出口 IP 共享额度。默认的纯透传模式不掩盖这个事实；可选的 429 冷却（第 9 节）
   只负责**别让重试继续烧额度**，不会凭空变出新额度；根治仍要靠自有 Zen Key。
   旧 README 里「切换网络 IP 重置额度 = 无限免费」属于绕开第三方限流，
   **本版不实现也不建议**，可能违反上游条款且随时失效。

4. **隐私**：提示词、工具结果、图片会原样发往上游；部分免费档条款允许用提交内容改进模型。
   密码、密钥、个人信息、商业机密不要往里送。OpenCode 官方也说明「只有使用免费模型时才会存储你的数据」。

5. **本地 Key 与 LAN 中继**：`settings.json` 里的 `forwardKey` 是本机网关自己生成的，
   二维码与分享串包含它，只发给可信对象。默认只绑 `127.0.0.1`；开 `lanRelay` 会绑 `0.0.0.0`
   并启用独立 LAN Key，且控制面要求 LAN Key 才能修改开关——只在可信局域网开，别暴露公网。

6. **运行时仍是第三方构建**：`libnode.so` 来自 OpenFlun/nodejs-mobile 的 GitHub Release
   （非 Node 官方 Android 版），CI 打印 SHA-256 / ELF 架构并按 major ≥ 22 硬闸门拦截。
   应用内「刷新目录」只下载 JSON，不下载也不执行任何外部代码，信任边界比旧版更窄。

7. **未验证项**：真机上匿名免费车道是否放行来自 Android Node 22 `https` 模块的请求；
   `vendor/channel-pack` 之类的 WASM / OAuth 回调在本方案里不存在（不再内嵌上游整仓）。

---

## 8. 与 A 方案的区别（为什么选 B）

A 只把「模型清单 / 上下架 / 授权」四个接口搬到本地，聊天请求仍由 DSH 直连上游。
手机上没有 DSH 宿主，A 连面板与 `18766` 桥都装不上，且拿不到本地 Key、流式转发、用量统计、
多客户端共享。B 把数据面也放到 `127.0.0.1`，才是你上传的「聚合网关」同形态。

两者都只是把「控制 / 转发」放本地，**模型推理仍然要联网到上游，不是离线推理**。

---

## 9. 429 策略：纯透传（默认）与可选冷却

### 为什么默认改成纯透传

两种 429 不是一回事，处理方式相反：

| | 匿名共享池 `public` | 自有 Zen Key |
|---|---|---|
| 429 主因 | 按出口 IP 的**日额度被打满**，全网共用一个池子 | 短时间 **RPM / 并发 / TPM 速率超限**，或模型临时过载 |
| 多久恢复 | 几十分钟到次日，重试几次也没用 | 通常几秒到几十秒，下一次重试很可能就成 |
| 重试代价 | 每次都真扣共享额度，把窗口越打越满 | 限流请求一般不计费，主要是空转 |

用户已选「自有 Zen Key + 单人手动聊天」。这时上一版的冷却会从「帮忙」变成「添乱」：
上游给 `Retry-After: 3`，客户端等 3 秒重试本来就能成功，冷却却把它按成 15 分钟下架；
本地 200 提示还会被 RikkaHub 当成一条正常回复存进聊天记录，并盖住真实错误。
因此**默认 `cooldownEnabled = false`**。

### 默认模式：纯透传

```
命中 429 → 上游 statusCode / body / Retry-After 原样送达 → 客户端显示真实错误
         → 不登记冷却、不下架模型、不回本地 200 提示、不改写任何响应头
```

- `Retry-After` **无条件保留**：这是零成本纯收益，守规矩的客户端会按上游要求等待，
  而不是立刻狂重试；网关不吞、不改、不造。
- 客户端看到「速率限制 (429)」后，按 `Retry-After` 等几秒手动重试，或换个模型即可。
- 自有 Key 下若仍频繁 429，值得直接看到原始错误去调并发 / 查脚本，而不是被提示盖住。

### 可选模式：冷却兜底（`cooldownEnabled = true`）

只在**自动化脚本 / 批量任务 / 多 App 共用 / 开了 LAN 中继**等真会出现重试风暴时开启。
RikkaHub 看到 429 会自动重试 6 次，每次都是真实上游请求；匿名档按 IP 共享额度，
越重试越把窗口打满，冷却才有意义。

| 时刻 | 网关做什么 | 客户端看到什么 |
|---|---|---|
| 第 1 次命中 429 | 原样透传 429 与 body；登记冷却（默认 15 分钟，上游带 `Retry-After` 时取它，封顶 30 分钟），并用同一时长覆盖 `Retry-After` | 真实「速率限制 (429)」 |
| 冷却期内 | 不再转发上游；模型从 `GET /v1/models` 临时下架；`chat/completions` 回一条 200 本地提示（流式按 SSE 给 `delta` + `[DONE]`） | 一条正常结束的提示消息，不再触发重试 |
| 冷却结束 / 手动解除 | 自动恢复上架，恢复正常转发 | 可以正常聊天 |

三条边界：本地提示**不是伪造模型输出**（正文明确标注「不是模型回复、本次未产生上游请求」，
非流式还带 `gateway_local: true`）；只对 `/v1/chat/completions` 做完整本地应答，其它端点回
429 + `Retry-After`；冷却状态持久化在 `ofm-data/cooldowns.json`。

### 升级与开关语义

- 老版本 `settings.json` 没有 `cooldownEnabled` → 一律按 `false`，**不会**让旧冷却行为悄悄继续生效。
- 启动时、以及把开关切回 `false` 时，都会清空 `cooldowns.json`，保证「关掉」真的干净。
- 开关与冷却时长都是 `/api/settings` 热更新，**无需重启网关、无需重新编译**。

### 配置

管理页 ① 填自有 Zen Key；② 切换 429 策略（含冷却时长，仅冷却模式可改）；③ 查看 / 提前解除冷却。

```bash
# 填自有 Key（立即生效，429 的根治办法）
curl -X POST http://127.0.0.1:18900/api/settings \
  -H 'Content-Type: application/json' -d '{"zenKey":"oc_sk_你的key"}'

# 保持默认纯透传（也是老版本升级后的默认状态）
curl -X POST http://127.0.0.1:18900/api/settings \
  -H 'Content-Type: application/json' -d '{"cooldownEnabled":false}'

# 只在跑自动化 / 多客户端时开启冷却兜底，并设 5 分钟
curl -X POST http://127.0.0.1:18900/api/settings \
  -H 'Content-Type: application/json' -d '{"cooldownEnabled":true,"cooldownMinutes":5}'

# 解除全部冷却
curl -X POST http://127.0.0.1:18900/api/models \
  -H 'Content-Type: application/json' -d '{"action":"clear-cooldown"}'
```

`GET /api/settings`、`GET /health` 会回显 `mode_429`（`passthrough` / `cooldown`）与
`cooldown_enabled`，方便一眼确认当前行为；只回显 `zen_key_hint`（是否 public + 尾 4 位），
**不回显完整 Zen Key**；`settings.json` 为 0600。
