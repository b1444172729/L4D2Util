# SSH 助手（SSH + SFTP）

一个集 **SSH 终端** 与 **SFTP 文件管理** 于一体的 Android 远程工具。纯原生实现，不依赖 Android System WebView。

## 特性

### 终端
- 自绘 VT100 / ANSI / xterm 终端（支持 256 色、粗体/斜体/下划线/反显、UTF-8、中文与 emoji 宽字符）
- **双指缩放**字号，音量键也可缩放
- **清屏**（发送 `clear` 并清空回滚）、清回滚缓冲
- 回滚缓冲区可配置（默认 3000 行），手指上下滑动查看历史
- 长按拖动选择文本 / 双击选词 → 复制到剪贴板；粘贴自动使用 bracketed paste 模式
- 底部按键栏：Esc / Ctrl / Alt / Tab / 方向键 / Home / End / PgUp / PgDn / Del / 复制 / 粘贴 / 清屏
- 支持软键盘（中文输入走 commitText，不会丢字）与实体键盘（Ctrl/Alt 组合、F1–F12）
- 终端类型（TERM）、字号、保活间隔、快捷命令均可配置
- 自动同步 PTY 窗口尺寸（旋转屏幕 / 缩放 / 键盘弹出时）
- 窗口标题跟随 OSC 转义序列

### SFTP 文件管理
- **本地 / 远程双窗格**，一键切换
- 浏览、进入目录、上一级、回到根目录、下拉刷新
- 多选（长按进入选择模式）、全选 / 取消选择
- 上传 / 下载（文件与整个目录），多选批量传输
- 后台传输服务 + 前台通知、进度百分比与实时速度
- **断点续传**（按已有大小续传）、覆盖 / 跳过 / 续传 冲突策略，可"应用到全部冲突"
- 暂停 / 继续 / 重试 / 取消单个任务，清除已完成
- 新建文件夹、新建文件、重命名、删除（目录递归删除）
- **修改权限**（属主/属组/其他 × 读/写/执行，八进制实时显示，可批量应用）
- 复制 / 剪切 / 粘贴（同端复制移动、跨端自动转为传输）
- **远程文本文件直接编辑**并保存回服务器（< 1MB）
- 本地文件用其他应用打开（FileProvider）
- 属性查看（名称/路径/类型/大小/修改时间/权限/属主）
- 排序（名称/大小/时间/类型，目录优先）、显示隐藏文件
- 显示属主 UID:GID、符号链接等属性

### 其它
- 主机管理：新增 / 编辑 / 复制 / 删除，导入导出 JSON（不含密码）
- 认证：密码、私钥（PEM / PKCS#8 / OpenSSH）+ 私钥口令；密码留空则连接时询问
- 凭据用 **EncryptedSharedPreferences** 加密存储
- 主机密钥指纹（SHA-256）校验：未知主机 / 密钥变更弹窗确认，可"仅本次信任"或"信任并记住"
- **本地端口转发**：把手机端口经 SSH 隧道映射到远程网络地址
- 全中文界面，深色主题

## 体积

- 无任何 native `.so`，不含 WebView / 浏览器内核
- release 构建开启 R8 代码压缩 + 资源压缩
- 依赖：AndroidX 基础组件 + Material + sshj（纯 Java）+ slf4j-api
- 实测 release APK 约 **10–16 MB**（取决于 AGP/R8 版本），稳定低于 30 MB

## 编译

```bash
./gradlew assembleRelease
# 或
./gradlew assembleDebug
```

产物：`app/build/outputs/apk/release/app-release.apk`

要求 JDK 17、Android Gradle Plugin 8.5、compileSdk 34。仓库已附带 Gradle Wrapper。

### 依赖下载慢？

`settings.gradle.kts` 默认使用 `google()` 与 `mavenCentral()`。国内网络可在 `dependencyResolutionManagement` 中追加镜像：

```kotlin
repositories {
    maven("https://maven.aliyun.com/repository/google")
    maven("https://maven.aliyun.com/repository/public")
    google()
    mavenCentral()
}
```

GitHub Actions 工作流见 `.github/workflows/android.yml`，推送到 `main` 或手动触发即可产出 APK 产物。

## 权限说明

| 权限 | 用途 |
|---|---|
| INTERNET / ACCESS_NETWORK_STATE | SSH 连接 |
| POST_NOTIFICATIONS | 后台传输进度通知（Android 13+） |
| FOREGROUND_SERVICE(_DATA_SYNC) | 后台传输 |
| MANAGE_EXTERNAL_STORAGE | 浏览手机本地文件（可选）。未授予时自动回退到应用私有目录，功能不受影响 |

## CI 自动构建

两个平台各准备了一份工作流，都是「上传 `source.zip`（外层套几层文件夹都行）→ 自动解压定位工程 → 编译 → 收集 APK」：

| 平台 | 文件位置 | 产物 |
|---|---|---|
| GitHub Actions | `.github/workflows/build-from-source-zip.yml` | Actions 页面的 `apks` artifact |
| Gitee Go | `.workflow/build-apk.yml` | Gitee Go → 制品库（`output`） |

Gitee Go 注意事项：

1. 配置文件放在仓库根目录的 `.workflow/` 下（部分企业版用 `.gitee/workflows/`）。
2. 流水线保存后 Gitee 会把配置回写到仓库，之后再 `git push` 请先 `git pull --rebase`。
3. 若构建环境的 JDK 下拉框没有 17，把 yml 里的 `jdkVersion: '17'` 改成界面可选的版本。
4. 免费额度有限，只编 release 的话可以把脚本里 `assembleDebug` 那行删掉。

## 目录结构

```
app/src/main/java/com/sshsftp/app/
├── App.kt                     应用入口
├── data/                      配置、加密存储、主机持久化
├── ssh/                       连接、SFTP、传输、端口转发
│   ├── SshConnector.kt        连接 + 认证 + 主机密钥校验
│   ├── SessionRegistry.kt     会话生命周期（SSH / Shell / SFTP）
│   ├── RemoteFs.kt            SFTP 文件操作
│   ├── LocalFs.kt             本地文件操作
│   ├── TransferService.kt     后台传输（前台服务）
│   ├── TransferPlanner.kt     任务展开与冲突处理
│   └── PortForward.kt         本地端口转发
├── term/
│   ├── TerminalEmulator.kt    终端模拟器（VT/ANSI/xterm）
│   └── TerminalView.kt        自绘终端视图（缩放/选择/键盘）
└── ui/                        主机列表、会话、文件双窗格、传输、编辑器、设置
```

## 第三方库

- [sshj](https://github.com/hierynomus/sshj)（Apache-2.0）—— SSH / SFTP 协议实现
- [SLF4J](https://www.slf4j.org/)（MIT）—— sshj 的日志门面
- AndroidX、Material Components（Apache-2.0）
