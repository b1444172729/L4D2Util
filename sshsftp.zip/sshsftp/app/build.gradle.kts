plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.sshsftp.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.sshsftp.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"
        // 本项目全部依赖均为纯 Java/Kotlin，不含任何 .so，因此无需 abi 分包
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        isCoreLibraryDesugaringEnabled = true
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        resources {
            // 依赖里重复的元数据会让打包报 "2 files found with same path"，直接排除
            excludes += setOf(
                "/META-INF/DEPENDENCIES",
                "/META-INF/LICENSE",
                "/META-INF/LICENSE.txt",
                "/META-INF/NOTICE",
                "/META-INF/NOTICE.txt"
            )
        }
    }

    buildFeatures {
        // 显式声明，消除 AGP 的 buildconfig 默认值弃用警告
        buildConfig = true
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    // ---------- AndroidX 基础 ----------
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.1")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.viewpager2:viewpager2:1.1.0")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")

    // ---------- Material 组件 ----------
    implementation("com.google.android.material:material:1.12.0")
    // 布局里直接用了 androidx.coordinatorlayout.widget.CoordinatorLayout，
    // 显式声明，不依赖 Material 的传递依赖
    implementation("androidx.coordinatorlayout:coordinatorlayout:1.2.0")

    // ---------- 生命周期 / 协程 ----------
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.6")

    // ---------- 设置页 & 加密存储 ----------
    implementation("androidx.preference:preference-ktx:1.2.1")
    implementation("androidx.security:security-crypto:1.1.0-alpha06")

    // ---------- SSH / SFTP 核心（纯 Java，无 native） ----------
    implementation("com.hierynomus:sshj:0.38.0")
    implementation("org.slf4j:slf4j-api:2.0.13")

    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.4")
}
