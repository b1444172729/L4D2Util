package com.sshsftp.app.ui

import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.AdapterView
import android.widget.Spinner
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import com.sshsftp.app.R
import com.sshsftp.app.data.HostConfig
import com.sshsftp.app.data.HostStore
import com.sshsftp.app.ssh.SshConnector
import com.sshsftp.app.util.installTrustPrompt
import com.sshsftp.app.util.toast
import java.io.File
import kotlin.concurrent.thread

class HostEditActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_HOST_ID = "host_id"
    }

    private lateinit var host: HostConfig
    private var existing: HostConfig? = null

    private lateinit var etName: TextInputEditText
    private lateinit var etHost: TextInputEditText
    private lateinit var etPort: TextInputEditText
    private lateinit var etUser: TextInputEditText
    private lateinit var etPassword: TextInputEditText
    private lateinit var etKey: TextInputEditText
    private lateinit var etKeyPass: TextInputEditText
    private lateinit var etDir: TextInputEditText
    private lateinit var etCmd: TextInputEditText
    private lateinit var etRemark: TextInputEditText
    private lateinit var spAuth: Spinner
    private lateinit var tilPassword: TextInputLayout
    private lateinit var tilKey: TextInputLayout
    private lateinit var tilKeyPass: TextInputLayout

    private val pickKeyLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@registerForActivityResult
        try {
            val dir = File(filesDir, "keys").apply { mkdirs() }
            val name = uri.lastPathSegment?.substringAfterLast('/')?.takeIf { it.isNotBlank() } ?: "id_rsa"
            val target = File(dir, name.filter { it.isLetterOrDigit() || it == '.' || it == '_' })
            contentResolver.openInputStream(uri)?.use { input ->
                target.outputStream().use { output -> input.copyTo(output) }
            }
            etKey.setText(target.absolutePath)
        } catch (e: Exception) {
            toast(e.message ?: getString(R.string.unknown_error))
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_host_edit)

        val id = intent.getStringExtra(EXTRA_HOST_ID)
        existing = id?.let { HostStore.get(it) }
        host = existing?.copy() ?: HostConfig()

        etName = findViewById(R.id.etName)
        etHost = findViewById(R.id.etHost)
        etPort = findViewById(R.id.etPort)
        etUser = findViewById(R.id.etUser)
        etPassword = findViewById(R.id.etPassword)
        etKey = findViewById(R.id.etKey)
        etKeyPass = findViewById(R.id.etKeyPass)
        etDir = findViewById(R.id.etDir)
        etCmd = findViewById(R.id.etCmd)
        etRemark = findViewById(R.id.etRemark)
        spAuth = findViewById(R.id.spAuth)
        tilPassword = findViewById(R.id.tilPassword)
        tilKey = findViewById(R.id.tilKey)
        tilKeyPass = findViewById(R.id.tilKeyPass)

        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        toolbar.title = if (existing == null) getString(R.string.add_host) else getString(R.string.edit_host)
        toolbar.setNavigationOnClickListener { finish() }
        toolbar.setOnMenuItemClickListener {
            if (it.itemId == R.id.action_save) {
                save()
                true
            } else false
        }

        etName.setText(host.name)
        etHost.setText(host.host)
        etPort.setText(host.port.toString())
        etUser.setText(host.user)
        etKey.setText(host.keyPath)
        etDir.setText(host.startDir)
        etCmd.setText(host.startupCmd)
        etRemark.setText(host.remark)
        etHost.inputType = InputType.TYPE_TEXT_VARIATION_URI or InputType.TYPE_CLASS_TEXT
        spAuth.setSelection(if (host.authType == "key") 1 else 0)
        updateAuthFields()

        spAuth.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                updateAuthFields()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }

        findViewById<MaterialButton>(R.id.btnPickKey).setOnClickListener {
            runCatching { pickKeyLauncher.launch(arrayOf("*/*")) }
        }

        findViewById<MaterialButton>(R.id.btnTest).setOnClickListener { testConnection() }
    }

    private fun updateAuthFields() {
        val useKey = spAuth.selectedItemPosition == 1
        tilPassword.visibility = if (useKey) View.GONE else View.VISIBLE
        tilKey.visibility = if (useKey) View.VISIBLE else View.GONE
        tilKeyPass.visibility = if (useKey) View.VISIBLE else View.GONE
    }

    private fun collect(): HostConfig? {
        val name = etName.text?.toString()?.trim().orEmpty()
        val addr = etHost.text?.toString()?.trim().orEmpty()
        val user = etUser.text?.toString()?.trim().orEmpty()
        val port = etPort.text?.toString()?.trim()?.toIntOrNull() ?: 22
        when {
            addr.isEmpty() -> toast(getString(R.string.field_required, getString(R.string.host_address)))
            user.isEmpty() -> toast(getString(R.string.field_required, getString(R.string.username)))
            else -> Unit
        }
        if (addr.isEmpty() || user.isEmpty()) return null

        return host.copy(
            name = name,
            host = addr,
            port = port.coerceIn(1, 65535),
            user = user,
            authType = if (spAuth.selectedItemPosition == 1) "key" else "password",
            keyPath = etKey.text?.toString()?.trim().orEmpty(),
            remark = etRemark.text?.toString()?.trim().orEmpty(),
            startDir = etDir.text?.toString()?.trim().orEmpty(),
            startupCmd = etCmd.text?.toString()?.trim().orEmpty()
        )
    }

    private fun save() {
        val h = collect() ?: return
        val pw = etPassword.text?.toString().orEmpty()
        val kp = etKeyPass.text?.toString().orEmpty()
        HostStore.save(h)
        if (pw.isNotEmpty()) HostStore.setPassword(h.id, pw)
        if (kp.isNotEmpty()) HostStore.setKeyPassphrase(h.id, kp)
        toast(getString(R.string.done))
        finish()
    }

    private fun testConnection() {
        val h = collect() ?: return
        val pw = etPassword.text?.toString().orEmpty().ifEmpty { HostStore.password(existing?.id ?: "") }
        val kp = etKeyPass.text?.toString().orEmpty().ifEmpty { HostStore.keyPassphrase(existing?.id ?: "") }
        installTrustPrompt()
        val dialog = com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle(R.string.test_connection)
            .setMessage(getString(R.string.connecting, "${h.user}@${h.host}:${h.port}"))
            .setCancelable(false)
            .show()
        thread {
            var error: String? = null
            try {
                SshConnector.connect(h, pw, kp).close()
            } catch (e: Throwable) {
                error = e.message ?: getString(R.string.unknown_error)
            }
            runOnUiThread {
                dialog.dismiss()
                if (error == null) toast(getString(R.string.test_ok))
                else toast(getString(R.string.test_failed, error))
            }
        }
    }
}
