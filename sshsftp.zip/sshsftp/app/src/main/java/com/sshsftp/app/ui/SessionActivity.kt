package com.sshsftp.app.ui

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import com.sshsftp.app.R
import com.sshsftp.app.data.HostConfig
import com.sshsftp.app.data.HostStore
import com.sshsftp.app.ssh.ConnState
import com.sshsftp.app.ssh.LiveSession
import com.sshsftp.app.ssh.SessionRegistry
import com.sshsftp.app.ssh.TransferService
import com.sshsftp.app.util.installTrustPrompt
import com.sshsftp.app.util.passwordDialog
import com.sshsftp.app.util.toast

class SessionActivity : AppCompatActivity(), SessionHost {

    companion object {
        const val EXTRA_HOST_ID = "host_id"
    }

    private lateinit var host: HostConfig
    private lateinit var toolbar: MaterialToolbar
    private var connecting = false
    private val pending = ArrayList<(LiveSession) -> Unit>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_session)

        val id = intent.getStringExtra(EXTRA_HOST_ID)
        host = id?.let { HostStore.get(it) } ?: run {
            finish()
            return
        }

        toolbar = findViewById(R.id.toolbar)
        toolbar.title = host.displayName
        toolbar.subtitle = "${host.user}@${host.host}:${host.port}"
        toolbar.setNavigationOnClickListener { finish() }
        toolbar.setOnMenuItemClickListener { onMenu(it) }

        val tabs = findViewById<TabLayout>(R.id.tabs)
        val pager = findViewById<ViewPager2>(R.id.pager)
        pager.adapter = object : FragmentStateAdapter(this) {
            override fun getItemCount(): Int = 3
            override fun createFragment(position: Int): Fragment = when (position) {
                0 -> TerminalFragment.new(host.id)
                1 -> SftpFragment.new(host.id)
                else -> PortForwardFragment.new(host.id)
            }
        }
        pager.offscreenPageLimit = 2
        TabLayoutMediator(tabs, pager) { tab, position ->
            tab.text = when (position) {
                0 -> getString(R.string.tab_terminal)
                1 -> getString(R.string.tab_files)
                else -> getString(R.string.tab_forward)
            }
        }.attach()

        installTrustPrompt()

        // 已有连接则直接复用，否则按需连接
        val existing = SessionRegistry.get(host.id)
        if (existing == null || existing.state != ConnState.CONNECTED) {
            ensureConnected { }
        }
    }

    private fun onMenu(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_transfers -> {
                TransferService.start(this)
                startActivity(Intent(this, TransfersActivity::class.java))
            }
            R.id.action_shortcuts -> showShortcuts()
            R.id.action_reconnect -> {
                SessionRegistry.close(host.id)
                ensureConnected { toast(getString(R.string.done)) }
            }
            R.id.action_disconnect -> {
                SessionRegistry.close(host.id)
                finish()
            }
            R.id.action_settings -> startActivity(Intent(this, SettingsActivity::class.java))
            else -> return false
        }
        return true
    }

    private fun showShortcuts() {
        val cmds = com.sshsftp.app.data.AppPrefs.shortcuts
        if (cmds.isEmpty()) {
            toast(getString(R.string.no_shortcuts))
            return
        }
        val names = cmds.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.shortcuts)
            .setItems(names) { _, which ->
                val live = SessionRegistry.get(host.id)
                if (live == null || !live.isAlive) {
                    toast(getString(R.string.session_closed))
                    return@setItems
                }
                live.sendText(names[which] + "\n")
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    override fun liveSession(): LiveSession? = SessionRegistry.get(host.id)

    override fun ensureConnected(onDone: (LiveSession) -> Unit) {
        val live = SessionRegistry.getOrCreate(host)
        if (live.state == ConnState.CONNECTED && live.isAlive) {
            onDone(live)
            return
        }
        pending.add(onDone)
        if (connecting) return
        connecting = true

        val askPassword: () -> Unit = {
            passwordDialog(this, getString(R.string.password)) { pw, remember ->
                if (remember && pw.isNotEmpty()) HostStore.setPassword(host.id, pw)
                doConnect(pw)
            }
        }

        val savedPw = HostStore.password(host.id)
        val savedKp = HostStore.keyPassphrase(host.id)
        if (host.authType == "password" && savedPw.isNullOrEmpty()) {
            toolbar.subtitle = getString(R.string.connecting, "${host.user}@${host.host}")
            askPassword()
        } else {
            toolbar.subtitle = getString(R.string.connecting, "${host.user}@${host.host}")
            doConnect(savedPw, savedKp)
        }
    }

    private fun doConnect(password: String?, keyPass: String? = HostStore.keyPassphrase(host.id)) {
        SessionRegistry.connect(host, password, keyPass) { live ->
            connecting = false
            if (live.state == ConnState.CONNECTED) {
                toolbar.subtitle = "${host.user}@${host.host}:${host.port}"
            } else {
                toolbar.subtitle = live.error ?: getString(R.string.connect_failed)
                Toast.makeText(this, live.error ?: getString(R.string.connect_failed), Toast.LENGTH_LONG).show()
            }
            val list = pending.toList()
            pending.clear()
            list.forEach { runCatching { it.invoke(live) } }
        }
    }

    override fun onDestroy() {
        if (isFinishing) {
            // 不清空连接：返回主机列表后重进可复用，用户点"断开"才真正关闭
        }
        super.onDestroy()
    }
}
