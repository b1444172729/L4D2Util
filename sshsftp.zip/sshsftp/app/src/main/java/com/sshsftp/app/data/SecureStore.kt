package com.sshsftp.app.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * 加密存储：保存密码、私钥口令。
 * 若设备 Keystore 不可用则自动降级为普通 SharedPreferences（功能不受影响，只是不加密）。
 */
object SecureStore {

    private const val FILE = "secure_store"

    private var sp: SharedPreferences? = null

    fun init(context: Context) {
        sp = try {
            val masterKey = MasterKey.Builder(context.applicationContext)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            EncryptedSharedPreferences.create(
                context.applicationContext,
                FILE,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (_: Throwable) {
            context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        }
    }

    fun put(key: String, value: String) {
        sp?.edit()?.putString(key, value)?.apply()
    }

    fun get(key: String): String? = sp?.getString(key, null)

    fun remove(key: String) {
        sp?.edit()?.remove(key)?.apply()
    }
}
