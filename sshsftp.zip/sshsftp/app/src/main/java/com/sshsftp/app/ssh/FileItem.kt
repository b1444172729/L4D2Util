package com.sshsftp.app.ssh

import android.text.format.Formatter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 本地与远程统一的文件条目模型。
 */
data class FileItem(
    val name: String,
    val path: String,
    val isDir: Boolean,
    val size: Long = 0,
    val mtime: Long = 0,
    /** 权限位，例如 0644 */
    val perms: Int = 0,
    val owner: String = "",
    val isLink: Boolean = false,
    val linkTarget: String? = null
) {
    val displaySize: String
        get() = if (isDir) "" else formatSize(size)
}

fun formatSize(bytes: Long): String {
    if (bytes < 0) return "-"
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    var v = bytes.toDouble()
    var i = 0
    while (v >= 1024 && i < units.size - 1) {
        v /= 1024
        i++
    }
    return if (i == 0) "$bytes B" else String.format(Locale.getDefault(), "%.1f %s", v, units[i])
}

fun formatTime(ms: Long): String {
    if (ms <= 0) return "-"
    return SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(ms))
}

fun permsToString(perms: Int): String {
    val sb = StringBuilder(10)
    val r = perms and 4 != 0
    val w = perms and 2 != 0
    val x = perms and 1 != 0
    sb.append(if (perms and 0x100 != 0) 'd' else '-')
    val u = (perms shr 6) and 7
    val g = (perms shr 3) and 7
    val o = perms and 7
    fun three(v: Int) {
        sb.append(if (v and 4 != 0) 'r' else '-')
        sb.append(if (v and 2 != 0) 'w' else '-')
        sb.append(if (v and 1 != 0) 'x' else '-')
    }
    three(u)
    three(g)
    three(o)
    return sb.toString()
}

fun octalString(perms: Int): String = String.format(Locale.US, "%03o", perms and 0x1FF)

/** 排序：目录永远在前 */
fun sortItems(items: MutableList<FileItem>, mode: String) {
    items.sortWith { a, b ->
        if (a.isDir != b.isDir) return@sortWith if (a.isDir) -1 else 1
        when (mode) {
            "size" -> (b.size - a.size).let { if (it == 0L) a.name.compareTo(b.name, true) else if (it > 0) 1 else -1 }
            "time" -> (b.mtime - a.mtime).let { if (it == 0L) a.name.compareTo(b.name, true) else if (it > 0) 1 else -1 }
            "type" -> {
                val ea = a.name.substringAfterLast('.', "")
                val eb = b.name.substringAfterLast('.', "")
                if (ea == eb) a.name.compareTo(b.name, true) else ea.compareTo(eb, true)
            }
            else -> a.name.compareTo(b.name, true)
        }
    }
}

/** 拼接路径，避免重复斜杠 */
fun joinPath(base: String, name: String): String {
    val b = base.trimEnd('/')
    return if (b.isEmpty()) "/$name" else "$b/$name"
}

fun parentPath(path: String): String {
    val p = path.trimEnd('/')
    val idx = p.lastIndexOf('/')
    return if (idx <= 0) "/" else p.substring(0, idx)
}
