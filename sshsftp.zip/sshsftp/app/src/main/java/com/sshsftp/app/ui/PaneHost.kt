package com.sshsftp.app.ui

import com.sshsftp.app.ssh.FileItem
import com.sshsftp.app.ssh.LiveSession
import com.sshsftp.app.ssh.TransferTask

/** 文件面板与其宿主（SftpFragment）之间的桥 */
interface PaneHost {
    fun liveSession(): LiveSession?
    fun ensureConnected(cb: (LiveSession) -> Unit)
    /** 取另一侧面板的当前目录 */
    fun counterpartDir(isRemote: Boolean): String
    fun enqueue(tasks: List<TransferTask>)
    fun openRemoteEditor(path: String)
    fun refreshCounterpart()
    fun currentSort(): String
    fun setSort(mode: String)
    fun showHidden(): Boolean
    fun setShowHidden(v: Boolean)
}
