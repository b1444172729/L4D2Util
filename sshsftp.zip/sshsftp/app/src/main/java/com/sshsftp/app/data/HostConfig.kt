package com.sshsftp.app.data

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * 一台远程主机的连接配置。
 * 密码与私钥口令不保存在这里，统一放在 [SecureStore]（加密 SharedPreferences）。
 */
data class HostConfig(
    var id: String = UUID.randomUUID().toString(),
    var name: String = "",
    var host: String = "",
    var port: Int = 22,
    var user: String = "",
    /** password 或 key */
    var authType: String = "password",
    var keyPath: String = "",
    var remark: String = "",
    var startDir: String = "",
    var startupCmd: String = ""
) {

    val displayName: String
        get() = name.ifBlank { if (host.isBlank()) "未命名" else host }

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("host", host)
        put("port", port)
        put("user", user)
        put("authType", authType)
        put("keyPath", keyPath)
        put("remark", remark)
        put("startDir", startDir)
        put("startupCmd", startupCmd)
    }

    fun copyConfig(): HostConfig = copy(id = UUID.randomUUID().toString())

    companion object {
        fun fromJson(o: JSONObject): HostConfig = HostConfig(
            id = o.optString("id", UUID.randomUUID().toString()),
            name = o.optString("name"),
            host = o.optString("host"),
            port = o.optInt("port", 22),
            user = o.optString("user"),
            authType = o.optString("authType", "password"),
            keyPath = o.optString("keyPath"),
            remark = o.optString("remark"),
            startDir = o.optString("startDir"),
            startupCmd = o.optString("startupCmd")
        )
    }
}

/** 主机列表的导入 / 导出（不含任何凭据） */
object HostJson {
    fun exportAll(list: List<HostConfig>): String {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        return JSONObject().put("version", 1).put("hosts", arr).toString(2)
    }

    fun importAll(json: String): List<HostConfig> {
        val obj = JSONObject(json)
        val arr = obj.optJSONArray("hosts") ?: throw IllegalArgumentException("缺少 hosts 字段")
        val out = ArrayList<HostConfig>()
        for (i in 0 until arr.length()) out.add(HostConfig.fromJson(arr.getJSONObject(i)))
        return out
    }
}
