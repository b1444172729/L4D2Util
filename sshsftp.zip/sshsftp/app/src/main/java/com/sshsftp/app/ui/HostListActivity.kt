package com.sshsftp.app.ui

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.appbar.MaterialToolbar
import com.sshsftp.app.R
import com.sshsftp.app.data.HostConfig
import com.sshsftp.app.data.HostJson
import com.sshsftp.app.data.HostStore
import com.sshsftp.app.ssh.SessionRegistry
import com.sshsftp.app.util.confirmDialog
import com.sshsftp.app.util.toast
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HostListActivity : AppCompatActivity() {

    private lateinit var adapter: HostAdapter
    private lateinit var empty: TextView

    private val editLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        adapter.submit(HostStore.all())
        updateEmpty()
    }

    private val importLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri == null) return@registerForActivityResult
        try {
            val json = contentResolver.openInputStream(uri)?.use { it.readBytes() }?.toString(Charsets.UTF_8)
                ?: return@registerForActivityResult
            val list = HostJson.importAll(json)
            list.forEach { HostStore.save(it) }
            adapter.submit(HostStore.all())
            updateEmpty()
            toast(getString(R.string.import_done, list.size))
        } catch (e: Exception) {
            toast(getString(R.string.import_failed, e.message ?: ""))
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_host_list)

        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        toolbar.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.action_import -> {
                    runCatching { importLauncher.launch(arrayOf("application/json", "text/*", "*/*")) }
                    true
                }
                R.id.action_export -> {
                    exportHosts()
                    true
                }
                R.id.action_settings -> {
                    startActivity(Intent(this, SettingsActivity::class.java))
                    true
                }
                else -> false
            }
        }

        adapter = HostAdapter(
            onClick = { host -> openSession(host) },
            onMore = { host, anchor -> showHostMenu(host, anchor) }
        )

        val recycler = findViewById<RecyclerView>(R.id.recycler)
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter
        adapter.submit(HostStore.all())

        empty = findViewById(R.id.empty)
        updateEmpty()

        findViewById<FloatingActionButton>(R.id.fab).setOnClickListener {
            editLauncher.launch(
                Intent(this, HostEditActivity::class.java)
            )
        }

        requestNotificationPermission()
    }

    private fun updateEmpty() {
        empty.visibility = if (adapter.itemCount == 0) View.VISIBLE else View.GONE
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
            }
        }
    }

    private fun openSession(host: HostConfig) {
        startActivity(Intent(this, SessionActivity::class.java).putExtra(SessionActivity.EXTRA_HOST_ID, host.id))
    }

    private fun showHostMenu(host: HostConfig, anchor: View) {
        val popup = android.widget.PopupMenu(this, anchor)
        popup.menuInflater.inflate(R.menu.menu_host_actions, popup.menu)
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.action_edit -> editLauncher.launch(
                    Intent(this, HostEditActivity::class.java).putExtra(HostEditActivity.EXTRA_HOST_ID, host.id)
                )
                R.id.action_duplicate -> {
                    val copy = host.copyConfig().apply { name = "${host.displayName} 副本" }
                    HostStore.save(copy)
                    adapter.submit(HostStore.all())
                }
                R.id.action_delete -> confirmDialog(this, getString(R.string.delete),
                    getString(R.string.delete_host_confirm, host.displayName)) {
                    SessionRegistry.close(host.id)
                    HostStore.delete(host.id)
                    adapter.submit(HostStore.all())
                    updateEmpty()
                }
            }
            true
        }
        popup.show()
    }

    private fun exportHosts() {
        try {
            val json = HostJson.exportAll(HostStore.all())
            val dir = File(getExternalFilesDir(null), "backup").apply { mkdirs() }
            val name = "hosts-${SimpleDateFormat("yyyyMMdd-HHmmss", Locale.getDefault()).format(Date())}.json"
            val file = File(dir, name)
            file.writeText(json, Charsets.UTF_8)
            toast(getString(R.string.export_done, file.absolutePath))
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            val share = Intent(Intent.ACTION_SEND).apply {
                type = "application/json"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            runCatching { startActivity(Intent.createChooser(share, getString(R.string.export_hosts))) }
        } catch (e: Exception) {
            toast(e.message ?: getString(R.string.unknown_error))
        }
    }

    // ---------------- 列表适配器 ----------------

    private class HostAdapter(
        private val onClick: (HostConfig) -> Unit,
        private val onMore: (HostConfig, View) -> Unit
    ) : RecyclerView.Adapter<HostAdapter.VH>() {

        private val items = ArrayList<HostConfig>()

        fun submit(list: List<HostConfig>) {
            items.clear()
            items.addAll(list)
            notifyDataSetChanged()
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_host, parent, false))

        override fun getItemCount(): Int = items.size

        override fun onBindViewHolder(holder: VH, position: Int) {
            val h = items[position]
            holder.bind(h, onClick, onMore)
        }

        class VH(view: View) : RecyclerView.ViewHolder(view) {
            private val name: TextView = view.findViewById(R.id.hostName)
            private val addr: TextView = view.findViewById(R.id.hostAddr)
            private val remark: TextView = view.findViewById(R.id.hostRemark)
            private val more: ImageButton = view.findViewById(R.id.btnMore)

            fun bind(h: HostConfig, onClick: (HostConfig) -> Unit, onMore: (HostConfig, View) -> Unit) {
                name.text = h.displayName
                addr.text = if (h.user.isBlank()) {
                    "${h.host}:${h.port}"
                } else {
                    "${h.user}@${h.host}:${h.port}"
                }
                if (h.remark.isBlank()) {
                    remark.visibility = View.GONE
                } else {
                    remark.visibility = View.VISIBLE
                    remark.text = h.remark
                }
                itemView.setOnClickListener { onClick(h) }
                more.setOnClickListener { onMore(h, it) }
            }
        }
    }
}
