package com.sshsftp.app.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.preference.EditTextPreference
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat
import com.google.android.material.appbar.MaterialToolbar
import com.sshsftp.app.R
import com.sshsftp.app.data.AppPrefs
import com.sshsftp.app.data.HostStore
import com.sshsftp.app.util.toast

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        toolbar.setNavigationOnClickListener { finish() }
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.settingsContainer, SettingsFragment())
                .commit()
        }
    }

    class SettingsFragment : PreferenceFragmentCompat() {

        override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
            setPreferencesFromResource(R.xml.preferences, rootKey)

            findPreference<Preference>("version")?.summary =
                getString(R.string.set_about_summary) + "\n" + getString(R.string.set_version, "1.0.0")

            findPreference<EditTextPreference>("scrollback")?.setOnBindEditTextListener { edit ->
                edit.inputType = android.text.InputType.TYPE_CLASS_NUMBER
            }
            findPreference<EditTextPreference>("keepalive")?.setOnBindEditTextListener { edit ->
                edit.inputType = android.text.InputType.TYPE_CLASS_NUMBER
            }
            findPreference<EditTextPreference>("shortcuts")?.setOnBindEditTextListener { edit ->
                edit.setSingleLine(false)
                edit.minLines = 6
            }

            findPreference<Preference>("known_hosts")?.setOnPreferenceClickListener {
                val n = HostStore.clearKnownHosts()
                toast(requireContext().getString(R.string.known_hosts_cleared, n))
                true
            }

            findPreference<Preference>("font_size")?.setOnPreferenceChangeListener { _, _ ->
                true
            }
        }
    }
}
