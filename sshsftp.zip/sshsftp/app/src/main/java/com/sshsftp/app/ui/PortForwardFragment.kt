package com.sshsftp.app.ui

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.sshsftp.app.R
import com.sshsftp.app.ssh.LiveSession
import com.sshsftp.app.ssh.PortForwardRule
import com.sshsftp.app.util.toast
import kotlin.concurrent.thread

/**
 * 本地端口转发：把手机上的端口经由 SSH 隧道转发到远程网络内的地址。
 */
class PortForwardFragment : Fragment(R.layout.fragment_port_forward) {

    companion object {
        private const val ARG_HOST_ID = "host_id"

        fun new(hostId: String) = PortForwardFragment().apply {
            arguments = Bundle().apply { putString(ARG_HOST_ID, hostId) }
        }
    }

    private val hostId: String by lazy { requireArguments().getString(ARG_HOST_ID)!! }
    private val main = Handler(Looper.getMainLooper())
    private val rules = ArrayList<PortForwardRule>()
    private lateinit var adapter: RuleAdapter
    private lateinit var empty: TextView

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        empty = view.findViewById(R.id.empty)
        adapter = RuleAdapter(
            onToggle = { rule -> toggle(rule) },
            onDelete = { rule -> delete(rule) }
        )
        val recycler = view.findViewById<RecyclerView>(R.id.recycler)
        recycler.layoutManager = LinearLayoutManager(requireContext())
        recycler.adapter = adapter
        adapter.submit(rules)
        updateEmpty()

        view.findViewById<FloatingActionButton>(R.id.fab).setOnClickListener { addRule() }

        // 恢复该主机已有的转发
        rules.addAll(PortForwardStore.all(hostId))
        adapter.submit(rules)
        updateEmpty()
    }

    private fun updateEmpty() {
        empty.isVisible = rules.isEmpty()
    }

    private fun live(): LiveSession? = (activity as? SessionHost)?.liveSession()

    private fun addRule() {
        val view = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_port_forward, null)
        val etLocal = view.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.etLocalPort)
        val etRemoteHost = view.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.etRemoteHost)
        val etRemotePort = view.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.etRemotePort)
        etRemoteHost.setText("127.0.0.1")
        com.google.android.material.dialog.MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.forward_add)
            .setView(view)
            .setNegativeButton(R.string.cancel, null)
            .setPositiveButton(R.string.ok) { _, _ ->
                val lp = etLocal.text?.toString()?.trim()?.toIntOrNull()
                val rp = etRemotePort.text?.toString()?.trim()?.toIntOrNull()
                val rh = etRemoteHost.text?.toString()?.trim().orEmpty()
                if (lp == null || rp == null || lp !in 1..65535 || rp !in 1..65535 || rh.isEmpty()) {
                    toast(getString(R.string.forward_invalid))
                    return@setPositiveButton
                }
                val rule = PortForwardRule(hostId, lp, rh, rp)
                rules.add(rule)
                PortForwardStore.save(rules)
                adapter.submit(rules)
                updateEmpty()
                start(rule)
            }
            .show()
    }

    private fun start(rule: PortForwardRule) {
        val live = live()
        if (live == null || !live.isAlive) {
            toast(getString(R.string.session_closed))
            return
        }
        thread {
            val err = try {
                live.startForward(rule)
                null
            } catch (e: Throwable) {
                e.message ?: getString(R.string.unknown_error)
            }
            main.post {
                if (err != null) toast(err)
                adapter.submit(rules)
            }
        }
    }

    private fun toggle(rule: PortForwardRule) {
        if (rule.running) {
            live()?.stopForward(rule)
            rule.running = false
            adapter.submit(rules)
        } else {
            start(rule)
        }
    }

    private fun delete(rule: PortForwardRule) {
        live()?.stopForward(rule)
        rules.remove(rule)
        PortForwardStore.save(rules)
        adapter.submit(rules)
        updateEmpty()
    }

    override fun onDestroyView() {
        super.onDestroyView()
    }

    private class RuleAdapter(
        private val onToggle: (PortForwardRule) -> Unit,
        private val onDelete: (PortForwardRule) -> Unit
    ) : RecyclerView.Adapter<RuleAdapter.VH>() {

        private val items = ArrayList<PortForwardRule>()

        fun submit(list: List<PortForwardRule>) {
            items.clear()
            items.addAll(list)
            notifyDataSetChanged()
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_port_forward, parent, false))

        override fun getItemCount(): Int = items.size

        override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(items[position], onToggle, onDelete)

        class VH(view: View) : RecyclerView.ViewHolder(view) {
            private val text: TextView = view.findViewById(R.id.text)
            private val status: TextView = view.findViewById(R.id.status)
            private val btnToggle: ImageButton = view.findViewById(R.id.btnToggle)
            private val btnDelete: ImageButton = view.findViewById(R.id.btnDelete)

            fun bind(
                r: PortForwardRule,
                onToggle: (PortForwardRule) -> Unit,
                onDelete: (PortForwardRule) -> Unit
            ) {
                text.text = "localhost:${r.localPort}  →  ${r.remoteHost}:${r.remotePort}"
                status.text = itemView.context.getString(
                    if (r.running) R.string.forward_running else R.string.forward_stopped
                )
                btnToggle.setImageResource(if (r.running) R.drawable.ic_stop else R.drawable.ic_play)
                btnToggle.setOnClickListener { onToggle(r) }
                btnDelete.setOnClickListener { onDelete(r) }
                status.setTextColor(
                    itemView.context.getColor(if (r.running) R.color.accent else R.color.text_secondary)
                )
            }
        }
    }
}
