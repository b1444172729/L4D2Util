package com.sshsftp.app.ui

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.sshsftp.app.R
import com.sshsftp.app.ssh.TransferManager
import com.sshsftp.app.ssh.TransferService
import com.sshsftp.app.ssh.TransferState
import com.sshsftp.app.ssh.TransferTask
import com.sshsftp.app.ssh.formatSize
import java.io.File

class TransfersActivity : AppCompatActivity() {

    private lateinit var adapter: TransferAdapter
    private lateinit var empty: TextView

    private val listener: () -> Unit = { refresh() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_transfers)

        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        toolbar.setNavigationOnClickListener { finish() }
        toolbar.setOnMenuItemClickListener { item: MenuItem ->
            when (item.itemId) {
                R.id.action_clear_finished -> TransferManager.clearFinished()
                else -> return@setOnMenuItemClickListener false
            }
            true
        }

        adapter = TransferAdapter(
            onToggle = { task ->
                when (task.state) {
                    TransferState.RUNNING, TransferState.WAIT -> TransferManager.pause(task.id)
                    TransferState.PAUSED, TransferState.FAILED, TransferState.CANCELLED -> {
                        TransferManager.resume(task.id)
                        TransferService.start(this)
                    }
                }
            },
            onCancel = { TransferManager.cancel(it.id) },
            onRetry = {
                TransferManager.retry(it.id)
                TransferService.start(this)
            }
        )

        val recycler = findViewById<RecyclerView>(R.id.recycler)
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter
        empty = findViewById(R.id.empty)

        refresh()
    }

    override fun onResume() {
        super.onResume()
        TransferManager.addListener(listener)
        refresh()
    }

    override fun onPause() {
        TransferManager.removeListener(listener)
        super.onPause()
    }

    private fun refresh() {
        val list = TransferManager.all()
        adapter.submit(list)
        empty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
    }

    private class TransferAdapter(
        private val onToggle: (TransferTask) -> Unit,
        private val onCancel: (TransferTask) -> Unit,
        private val onRetry: (TransferTask) -> Unit
    ) : RecyclerView.Adapter<TransferAdapter.VH>() {

        private val items = ArrayList<TransferTask>()

        fun submit(list: List<TransferTask>) {
            items.clear()
            items.addAll(list)
            notifyDataSetChanged()
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_transfer, parent, false))

        override fun getItemCount(): Int = items.size

        override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(items[position], onToggle, onCancel, onRetry)

        class VH(view: View) : RecyclerView.ViewHolder(view) {
            private val icon: ImageView = view.findViewById(R.id.icon)
            private val name: TextView = view.findViewById(R.id.name)
            private val status: TextView = view.findViewById(R.id.status)
            private val progress: ProgressBar = view.findViewById(R.id.progress)
            private val btnToggle: MaterialButton = view.findViewById(R.id.btnToggle)
            private val btnCancel: MaterialButton = view.findViewById(R.id.btnCancel)
            private val btnRetry: MaterialButton = view.findViewById(R.id.btnRetry)

            fun bind(
                t: TransferTask,
                onToggle: (TransferTask) -> Unit,
                onCancel: (TransferTask) -> Unit,
                onRetry: (TransferTask) -> Unit
            ) {
                val ctx: Context = itemView.context
                name.text = t.displayName.ifBlank { File(t.localPath).name }
                icon.setImageResource(if (t.upload) R.drawable.ic_upload else R.drawable.ic_download)
                val stateText = when (t.state) {
                    TransferState.WAIT -> ctx.getString(R.string.transfer_waiting)
                    TransferState.RUNNING -> ctx.getString(R.string.transfer_running)
                    TransferState.PAUSED -> ctx.getString(R.string.transfer_paused)
                    TransferState.DONE -> ctx.getString(R.string.transfer_success)
                    TransferState.FAILED -> ctx.getString(R.string.transfer_failed)
                    else -> ctx.getString(R.string.transfer_cancelled)
                }
                val detail = if (t.error != null) {
                    ctx.getString(R.string.transfer_error, stateText, t.error)
                } else if (t.state == TransferState.RUNNING && t.speedBps > 0) {
                    "$stateText · ${formatSize(t.size)} · ${formatSize(t.speedBps)}/s"
                } else {
                    "$stateText · ${formatSize(t.transferred)} / ${formatSize(t.size)}"
                }
                status.text = detail
                progress.progress = t.progressPercent
                progress.isIndeterminate = t.state == TransferState.RUNNING && t.size <= 0

                val finished = t.state == TransferState.DONE || t.state == TransferState.CANCELLED
                btnToggle.visibility = if (finished) View.GONE else View.VISIBLE
                btnCancel.visibility = if (finished) View.GONE else View.VISIBLE
                btnRetry.visibility = if (t.state == TransferState.FAILED) View.VISIBLE else View.GONE
                btnToggle.text = ctx.getString(
                    if (t.state == TransferState.RUNNING || t.state == TransferState.WAIT) R.string.pause else R.string.resume
                )
                btnToggle.setOnClickListener { onToggle(t) }
                btnCancel.setOnClickListener { onCancel(t) }
                btnRetry.setOnClickListener { onRetry(t) }
            }
        }
    }
}
