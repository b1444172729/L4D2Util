package com.sshsftp.app.ssh

import android.os.Handler
import android.os.Looper
import android.util.Log
import com.sshsftp.app.data.AppPrefs
import com.sshsftp.app.data.HostConfig
import com.sshsftp.app.term.TerminalEmulator
import net.schmizz.sshj.SSHClient
import net.schmizz.sshj.connection.channel.direct.PTYMode
import net.schmizz.sshj.connection.channel.direct.Session
import net.schmizz.sshj.sftp.SFTPClient
import java.io.IOException
import kotlin.concurrent.thread

enum class ConnState { IDLE, CONNECTING, CONNECTED, FAILED, CLOSED }

/** 统一日志 TAG，logcat 过滤它即可看到全部运行信息 */
private const val TAG = "SSH助手"

/**
 * 一条到远程主机的活动连接：SSH 客户端、Shell 会话、SFTP 客户端与终端缓冲区。
 */
class LiveSession(val host: HostConfig) {

    @Volatile
    var state: ConnState = ConnState.IDLE

    @Volatile
    var ssh: SSHClient? = null

    @Volatile
    var session: Session? = null

    @Volatile
    var shell: Session.Shell? = null

    @Volatile
    var sftp: SFTPClient? = null

    var emulator: TerminalEmulator? = null

    @Volatile
    var error: String? = null

    /** 最近一次操作失败的原因（发送/启动 shell） */
    @Volatile
    var lastError: String? = null

    private val sftpLock = Any()
    private var readerThread: Thread? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    val isAlive: Boolean
        get() = state == ConnState.CONNECTED && ssh?.isConnected == true

    /** 顺序使用 SFTP 客户端（sshj 的 SFTPClient 不是线程安全的） */
    fun <T> withSftp(block: (SFTPClient) -> T): T {
        synchronized(sftpLock) {
            val client = sftp ?: ssh!!.newSFTPClient().also { sftp = it }
            return try {
                block(client)
            } catch (e: IOException) {
                // 连接已断或会话失效：丢弃客户端，下次重新打开
                if (ssh?.isConnected != true) sftp = null
                throw e
            }
        }
    }

    /**
     * 启动 shell。返回 null 表示成功，否则返回可读的错误原因。
     *
     * 注意：以前这里是抛异常由调用方 catch，失败原因被吞掉，
     * 只能笼统提示"会话已关闭"，无法定位。现在把原因带回 UI。
     */
    fun startShell(cols: Int, rows: Int): String? {
        val client = ssh ?: return "尚未建立连接"
        runCatching { session?.close() }
        return try {
            val s = client.startSession()
            session = s

            // PTY 尺寸必须合法，0 或负数会让部分服务器直接拒绝并关闭通道。
            val c = cols.coerceIn(20, 500)
            val r = rows.coerceIn(5, 200)
            val term = AppPrefs.termType.ifBlank { "xterm" }
            Log.i(TAG, "申请 PTY: term=$term ${c}x${r}")

            try {
                // 只使用与原实现相同的 allocatePTY 签名（Int 参数），避免 API 差异。
                // 带上像素尺寸，部分服务器对全 0 的 pty-req 敏感。
                s.allocatePTY(term, c, r, c * 8, r * 16, emptyMap<PTYMode, Int>())
            } catch (e: Throwable) {
                // 老式/嵌入式 sshd 可能不接受这种 pty-req，
                // 回退到最保守的参数再试一次（同样只调用已验证存在的 API）。
                Log.w(TAG, "allocatePTY 失败，回退保守参数: ${e.message}")
                s.allocatePTY("vt100", 80, 24, 0, 0, emptyMap<PTYMode, Int>())
            }

            val sh = s.startShell()
            shell = sh

            val cmd = host.startupCmd.trim()
            if (cmd.isNotEmpty()) {
                runCatching {
                    sh.outputStream.write((cmd + "\n").toByteArray(Charsets.UTF_8))
                    sh.outputStream.flush()
                }
            }
            startReader()
            Log.i(TAG, "shell 已启动 ${c}x${r}")
            null
        } catch (e: Throwable) {
            Log.e(TAG, "启动 shell 失败", e)
            "启动 shell 失败：${e.message ?: e::class.java.simpleName}"
        }
    }

    /**
     * 发送数据。返回是否成功。
     * 以前任何写入异常都会直接 markClosed()，把偶发失败表现为"连接断开"；
     * 现在只有连接确实已断时才改状态，否则仅记录原因供 UI 提示。
     */
    fun send(data: ByteArray): Boolean {
        val sh = shell
        if (sh == null) {
            lastError = "Shell 未启动"
            Log.w(TAG, "发送失败：shell 为空")
            return false
        }
        return try {
            val out = sh.outputStream
            out.write(data)
            out.flush()
            true
        } catch (e: Throwable) {
            val reason = e.message ?: e::class.java.simpleName
            lastError = reason
            Log.w(TAG, "发送失败：$reason")
            // 只有底层连接真的断了才标记关闭
            if (ssh?.isConnected != true) markClosed()
            false
        }
    }

    fun sendText(text: String): Boolean = send(text.toByteArray(Charsets.UTF_8))

    fun resizeShell(cols: Int, rows: Int) {
        try {
            shell?.changeWindowDimensions(cols, rows, 0, 0)
        } catch (_: Throwable) {
        }
    }

    fun startForward(rule: PortForwardRule) = PortForwards.start(this, rule)

    fun stopForward(rule: PortForwardRule) = PortForwards.stop(this, rule)

    private fun startReader() {
        val sh = shell ?: return
        val emu = emulator
        readerThread = thread(start = true, name = "ssh-reader") {
            val buf = ByteArray(16 * 1024)
            var eof = false
            try {
                sh.inputStream.use { input ->
                    while (!Thread.currentThread().isInterrupted) {
                        val n = input.read(buf)
                        if (n < 0) {
                            eof = true
                            break
                        }
                        emu?.write(buf, n)
                    }
                }
            } catch (e: Throwable) {
                // 主动中断（close()）属正常退出，不算错误
                if (Thread.currentThread().isInterrupted) {
                    Log.i(TAG, "reader 线程被中断，正常退出")
                    return@thread
                }
                Log.w(TAG, "reader 异常退出：${e.message ?: e::class.java.simpleName}")
            }
            // EOF = 服务器主动关闭了 shell；异常 = 连接层面出问题。
            // 两者都要让 UI 感知，但日志要区分开，便于定位。
            Log.i(TAG, if (eof) "服务器关闭了 shell（EOF）" else "reader 结束")
            markClosed()
        }
    }

    private fun markClosed() {
        if (state != ConnState.CLOSED) {
            state = ConnState.CLOSED
            mainHandler.post { SessionRegistry.notifyChanged() }
        }
    }

    fun close() {
        state = ConnState.CLOSED
        readerThread?.interrupt()
        readerThread = null
        runCatching { sftp?.close() }
        runCatching { shell?.close() }
        runCatching { session?.close() }
        runCatching { ssh?.disconnect() }
        sftp = null
        shell = null
        session = null
        ssh = null
    }
}

object SessionRegistry {

    private val sessions = HashMap<String, LiveSession>()
    private val listeners = ArrayList<() -> Unit>()

    fun get(hostId: String): LiveSession? = synchronized(sessions) { sessions[hostId] }

    fun getOrCreate(host: HostConfig): LiveSession = synchronized(sessions) {
        sessions[host.id] ?: LiveSession(host).also { sessions[host.id] = it }
    }

    fun close(hostId: String) {
        val s = synchronized(sessions) { sessions.remove(hostId) }
        s?.close()
        notifyChanged()
    }

    fun closeAll() {
        val all = synchronized(sessions) { sessions.values.toList().also { sessions.clear() } }
        all.forEach { it.close() }
    }

    /**
     * 后台连接；结果通过 onDone 回到主线程。
     */
    fun connect(
        host: HostConfig,
        password: String?,
        keyPassphrase: String?,
        onDone: (LiveSession) -> Unit
    ) {
        val live = getOrCreate(host)
        live.state = ConnState.CONNECTING
        live.error = null
        thread(start = true, name = "ssh-connect") {
            try {
                val ssh = SshConnector.connect(host, password, keyPassphrase)
                ssh.connection.keepAlive.setKeepAliveInterval(AppPrefs.keepAliveSec)
                live.ssh = ssh
                live.state = ConnState.CONNECTED
            } catch (e: Throwable) {
                live.state = ConnState.FAILED
                live.error = e.message ?: "连接失败"
                runCatching { live.ssh?.close() }
            }
            Handler(Looper.getMainLooper()).post {
                notifyChanged()
                onDone(live)
            }
        }
    }

    /** 主机配置的远程起始目录；未配置时用 canonicalize(".") 得到家目录 */
    fun hostStartDir(hostId: String): String {
        val live = get(hostId) ?: return "/"
        if (live.host.startDir.isNotBlank()) return live.host.startDir.trimEnd('/').ifEmpty { "/" }
        if (live.isAlive) {
            return try {
                RemoteFs.canonical(live, ".")
            } catch (_: Throwable) {
                "/"
            }
        }
        return "/"
    }

    fun addListener(l: () -> Unit) {
        synchronized(listeners) { listeners.add(l) }
    }

    fun removeListener(l: () -> Unit) {
        synchronized(listeners) { listeners.remove(l) }
    }

    fun notifyChanged() {
        Handler(Looper.getMainLooper()).post {
            val snapshot = synchronized(listeners) { listeners.toList() }
            snapshot.forEach { runCatching { it.invoke() } }
        }
    }
}
