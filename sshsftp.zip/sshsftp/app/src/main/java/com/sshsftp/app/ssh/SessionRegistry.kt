package com.sshsftp.app.ssh

import android.os.Handler
import android.os.Looper
import com.sshsftp.app.data.AppPrefs
import com.sshsftp.app.data.HostConfig
import com.sshsftp.app.term.TerminalEmulator
import net.schmizz.sshj.SSHClient
import net.schmizz.sshj.connection.channel.direct.PTYMode
import net.schmizz.sshj.connection.channel.direct.Session
import net.schmizz.sshj.sftp.SFTPClient
import java.io.IOException
import kotlin.concurrent.thread

enum class ConnState { IDLE, CONNECTING, CONNECTED, FAILED, CLOSED }

/**
 * 一条到远程主机的活动连接：SSH 客户端、Shell 会话、SFTP 客户端与终端缓冲区。
 */
class LiveSession(val host: HostConfig) {

    @Volatile
    var state: ConnState = ConnState.IDLE

    @Volatile
    var ssh: SSHClient? = null

    @Volatile
    var session: Session? = null

    @Volatile
    var shell: Session.Shell? = null

    @Volatile
    var sftp: SFTPClient? = null

    var emulator: TerminalEmulator? = null

    @Volatile
    var error: String? = null

    private val sftpLock = Any()
    private var readerThread: Thread? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    val isAlive: Boolean
        get() = state == ConnState.CONNECTED && ssh?.isConnected == true

    /** 顺序使用 SFTP 客户端（sshj 的 SFTPClient 不是线程安全的） */
    fun <T> withSftp(block: (SFTPClient) -> T): T {
        synchronized(sftpLock) {
            val client = sftp ?: ssh!!.newSFTPClient().also { sftp = it }
            return try {
                block(client)
            } catch (e: IOException) {
                // 连接已断或会话失效：丢弃客户端，下次重新打开
                if (ssh?.isConnected != true) sftp = null
                throw e
            }
        }
    }

    fun startShell(cols: Int, rows: Int) {
        val client = ssh ?: return
        runCatching { session?.close() }
        val s = client.startSession()
        s.allocatePTY(AppPrefs.termType, cols, rows, 0, 0, emptyMap<PTYMode, Int>())
        session = s
        val sh = s.startShell()
        shell = sh
        val cmd = host.startupCmd.trim()
        if (cmd.isNotEmpty()) {
            try {
                sh.outputStream.write((cmd + "\n").toByteArray(Charsets.UTF_8))
                sh.outputStream.flush()
            } catch (_: Throwable) {
            }
        }
        startReader()
    }

    fun send(data: ByteArray) {
        try {
            val out = shell?.outputStream ?: return
            out.write(data)
            out.flush()
        } catch (_: Throwable) {
            markClosed()
        }
    }

    fun sendText(text: String) = send(text.toByteArray(Charsets.UTF_8))

    fun resizeShell(cols: Int, rows: Int) {
        try {
            shell?.changeWindowDimensions(cols, rows, 0, 0)
        } catch (_: Throwable) {
        }
    }

    fun startForward(rule: PortForwardRule) = PortForwards.start(this, rule)

    fun stopForward(rule: PortForwardRule) = PortForwards.stop(this, rule)

    private fun startReader() {
        val sh = shell ?: return
        val emu = emulator
        readerThread = thread(start = true, name = "ssh-reader") {
            val buf = ByteArray(16 * 1024)
            try {
                sh.inputStream.use { input ->
                    while (!Thread.currentThread().isInterrupted) {
                        val n = input.read(buf)
                        if (n < 0) break
                        emu?.write(buf, n)
                    }
                }
            } catch (_: Throwable) {
            } finally {
                markClosed()
            }
        }
    }

    private fun markClosed() {
        if (state != ConnState.CLOSED) {
            state = ConnState.CLOSED
            mainHandler.post { SessionRegistry.notifyChanged() }
        }
    }

    fun close() {
        state = ConnState.CLOSED
        readerThread?.interrupt()
        readerThread = null
        runCatching { sftp?.close() }
        runCatching { shell?.close() }
        runCatching { session?.close() }
        runCatching { ssh?.disconnect() }
        sftp = null
        shell = null
        session = null
        ssh = null
    }
}

object SessionRegistry {

    private val sessions = HashMap<String, LiveSession>()
    private val listeners = ArrayList<() -> Unit>()

    fun get(hostId: String): LiveSession? = synchronized(sessions) { sessions[hostId] }

    fun getOrCreate(host: HostConfig): LiveSession = synchronized(sessions) {
        sessions[host.id] ?: LiveSession(host).also { sessions[host.id] = it }
    }

    fun close(hostId: String) {
        val s = synchronized(sessions) { sessions.remove(hostId) }
        s?.close()
        notifyChanged()
    }

    fun closeAll() {
        val all = synchronized(sessions) { sessions.values.toList().also { sessions.clear() } }
        all.forEach { it.close() }
    }

    /**
     * 后台连接；结果通过 onDone 回到主线程。
     */
    fun connect(
        host: HostConfig,
        password: String?,
        keyPassphrase: String?,
        onDone: (LiveSession) -> Unit
    ) {
        val live = getOrCreate(host)
        live.state = ConnState.CONNECTING
        live.error = null
        thread(start = true, name = "ssh-connect") {
            try {
                val ssh = SshConnector.connect(host, password, keyPassphrase)
                ssh.connection.keepAlive.setKeepAliveInterval(AppPrefs.keepAliveSec)
                live.ssh = ssh
                live.state = ConnState.CONNECTED
            } catch (e: Throwable) {
                live.state = ConnState.FAILED
                live.error = e.message ?: "连接失败"
                runCatching { live.ssh?.close() }
            }
            Handler(Looper.getMainLooper()).post {
                notifyChanged()
                onDone(live)
            }
        }
    }

    /** 主机配置的远程起始目录；未配置时用 canonicalize(".") 得到家目录 */
    fun hostStartDir(hostId: String): String {
        val live = get(hostId) ?: return "/"
        if (live.host.startDir.isNotBlank()) return live.host.startDir.trimEnd('/').ifEmpty { "/" }
        if (live.isAlive) {
            return try {
                RemoteFs.canonical(live, ".")
            } catch (_: Throwable) {
                "/"
            }
        }
        return "/"
    }

    fun addListener(l: () -> Unit) {
        synchronized(listeners) { listeners.add(l) }
    }

    fun removeListener(l: () -> Unit) {
        synchronized(listeners) { listeners.remove(l) }
    }

    fun notifyChanged() {
        Handler(Looper.getMainLooper()).post {
            val snapshot = synchronized(listeners) { listeners.toList() }
            snapshot.forEach { runCatching { it.invoke() } }
        }
    }
}
