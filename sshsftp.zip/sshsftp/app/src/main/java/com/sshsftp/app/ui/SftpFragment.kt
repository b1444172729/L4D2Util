package com.sshsftp.app.ui

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import com.google.android.material.tabs.TabLayout
import com.sshsftp.app.R
import com.sshsftp.app.data.AppPrefs
import com.sshsftp.app.ssh.LiveSession
import com.sshsftp.app.ssh.TransferManager
import com.sshsftp.app.ssh.TransferTask
import com.sshsftp.app.ssh.TransferService
import com.sshsftp.app.util.toast

/**
 * SFTP 页：本地 / 远程双窗格，负责协调两侧目录与入队传输任务。
 */
class SftpFragment : Fragment(R.layout.fragment_sftp), PaneHost {

    companion object {
        private const val ARG_HOST_ID = "host_id"

        fun new(hostId: String) = SftpFragment().apply {
            arguments = Bundle().apply { putString(ARG_HOST_ID, hostId) }
        }
    }

    private val hostId: String by lazy { requireArguments().getString(ARG_HOST_ID)!! }

    private lateinit var localPane: FilePaneFragment
    private lateinit var remotePane: FilePaneFragment
    private var sortMode = "name"
    private var hidden = AppPrefs.showHidden

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val tabs = view.findViewById<TabLayout>(R.id.paneTabs)

        localPane = FilePaneFragment.new(hostId, false)
        remotePane = FilePaneFragment.new(hostId, true)

        childFragmentManager.beginTransaction()
            .add(R.id.paneContainer, localPane, "local")
            .add(R.id.paneContainer, remotePane, "remote")
            .hide(remotePane)
            .commit()

        tabs.addTab(tabs.newTab().setText(R.string.pane_local), true)
        tabs.addTab(tabs.newTab().setText(R.string.pane_remote))
        tabs.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) = showPane(tab.position == 1)
            override fun onTabUnselected(tab: TabLayout.Tab) = Unit
            override fun onTabReselected(tab: TabLayout.Tab) = Unit
        })
    }

    private fun showPane(remote: Boolean) {
        childFragmentManager.beginTransaction()
            .apply {
                if (remote) hide(localPane).show(remotePane) else hide(remotePane).show(localPane)
            }
            .commit()
    }

    // ---------------- PaneHost ----------------

    override fun liveSession(): LiveSession? = (activity as? SessionHost)?.liveSession()

    override fun ensureConnected(cb: (LiveSession) -> Unit) {
        (activity as? SessionHost)?.ensureConnected(cb)
    }

    override fun counterpartDir(isRemote: Boolean): String =
        if (isRemote) localPane.currentDir() else remotePane.currentDir()

    override fun enqueue(tasks: List<TransferTask>) {
        // 下载时确保本地父目录存在
        tasks.forEach { t ->
            if (!t.upload) {
                java.io.File(t.localPath).parentFile?.mkdirs()
            }
        }
        TransferManager.add(tasks)
        TransferService.start(requireContext())
        toast(getString(R.string.transfer_notify_title, tasks.size))
    }

    override fun openRemoteEditor(path: String) {
        startActivity(
            android.content.Intent(requireContext(), EditorActivity::class.java)
                .putExtra(EditorActivity.EXTRA_PATH, path)
                .putExtra(EditorActivity.EXTRA_REMOTE, true)
                .putExtra(EditorActivity.EXTRA_HOST_ID, hostId)
        )
    }

    override fun refreshCounterpart() {
        remotePane.load(remotePane.currentDir())
        localPane.load(localPane.currentDir())
    }

    override fun currentSort(): String = sortMode
    override fun setSort(mode: String) { sortMode = mode }
    override fun showHidden(): Boolean = hidden
    override fun setShowHidden(v: Boolean) { hidden = v }
}
