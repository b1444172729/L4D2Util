package com.sshsftp.app.ssh

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import com.sshsftp.app.R
import com.sshsftp.app.data.AppPrefs
import com.sshsftp.app.ui.TransfersActivity
import net.schmizz.sshj.sftp.OpenMode
import net.schmizz.sshj.sftp.SFTPClient
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.util.EnumSet
import kotlin.concurrent.thread

/**
 * 后台传输服务：串行执行上传 / 下载队列，支持取消、暂停、续传与进度通知。
 */
class TransferService : Service() {

    companion object {
        private const val CHANNEL_ID = "transfer"
        private const val NOTIF_ID = 1001

        fun start(context: Context) {
            val i = Intent(context, TransferService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(i)
            } else {
                context.startService(i)
            }
        }
    }

    private var running = false
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, buildNotification(null))
        if (!running) {
            running = true
            thread(name = "transfer", start = true) { loop() }
        }
        return START_STICKY
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "文件传输", NotificationManager.IMPORTANCE_LOW)
            channel.setSound(null, null)
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    private fun openIntent(): PendingIntent {
        val i = Intent(this, TransfersActivity::class.java)
        val flag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }
        return PendingIntent.getActivity(this, 0, i, flag)
    }

    private fun buildNotification(current: TransferTask?): android.app.Notification {
        val total = TransferManager.countActive()
        val title = if (current != null) {
            getString(
                R.string.transfer_progress,
                current.progressPercent,
                100,
                current.displayName.ifBlank { File(current.localPath).name }
            )
        } else {
            getString(R.string.transfer_notify_title, total)
        }
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_transfer)
            .setContentTitle(title)
            .setContentText(if (total > 1) "剩余 $total 个任务" else "")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openIntent())
        if (current != null) {
            builder.setProgress(100, current.progressPercent, current.size <= 0)
        }
        return builder.build()
    }

    private fun updateNotification(current: TransferTask?) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        runCatching { nm.notify(NOTIF_ID, buildNotification(current)) }
    }

    private fun loop() {
        try {
            while (true) {
                val task = TransferManager.nextPending()
                if (task == null) break
                task.state = TransferState.RUNNING
                TransferManager.notifyChangedAsync()
                updateNotification(task)
                runTask(task)
                TransferManager.notifyChangedAsync()
                updateNotification(null)
            }
        } finally {
            running = false
            mainHandler.post {
                if (TransferManager.nextPending() == null) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) stopForeground(STOP_FOREGROUND_REMOVE)
                    else @Suppress("DEPRECATION") stopForeground(true)
                    stopSelf()
                }
            }
        }
    }

    private fun runTask(task: TransferTask) {
        val live = SessionRegistry.get(task.hostId)
        if (live == null || !live.isAlive) {
            fail(task, "连接已断开")
            return
        }
        try {
            if (task.upload) upload(live, task) else download(live, task)
            if (task.state == TransferState.RUNNING) {
                task.state = TransferState.DONE
                task.transferred = task.size
            }
        } catch (e: Throwable) {
            if (task.state == TransferState.RUNNING) {
                task.state = TransferState.FAILED
                task.error = e.message ?: e.javaClass.simpleName
            }
        }
    }

    private fun fail(task: TransferTask, msg: String) {
        task.state = TransferState.FAILED
        task.error = msg
    }

    private fun download(live: LiveSession, task: TransferTask) {
        live.withSftp { sftp ->
            val target = File(task.localPath)
            target.parentFile?.mkdirs()
            val offset = task.resumeOffset
            val rf = sftp.open(task.remotePath)
            try {
                val input: InputStream = rf.ReadAheadRemoteFileInputStream(16, offset)
                FileOutputStream(target, offset > 0).use { out ->
                    copy(input, out, task, offset)
                }
                runCatching { input.close() }
                // 尽量保留远端修改时间
                runCatching {
                    val mtime = sftp.mtime(task.remotePath) * 1000L
                    if (mtime > 0) target.setLastModified(mtime)
                }
            } finally {
                runCatching { rf.close() }
            }
        }
    }

    private fun upload(live: LiveSession, task: TransferTask) {
        live.withSftp { sftp ->
            val src = File(task.localPath)
            mkdirsRemote(sftp, parentPath(task.remotePath))
            val offset = task.resumeOffset
            val modes = if (offset > 0) {
                EnumSet.of(OpenMode.WRITE, OpenMode.APPEND)
            } else {
                EnumSet.of(OpenMode.WRITE, OpenMode.CREAT, OpenMode.TRUNC)
            }
            val rf = sftp.open(task.remotePath, modes)
            try {
                val os: OutputStream = rf.RemoteFileOutputStream(offset, 16)
                FileInputStream(src).use { input ->
                    if (offset > 0) {
                        var skipped = 0L
                        while (skipped < offset) {
                            val s = input.skip(offset - skipped)
                            if (s <= 0) break
                            skipped += s
                        }
                    }
                    copy(input, os, task, offset)
                }
                os.flush()
                os.close()
            } finally {
                runCatching { rf.close() }
            }
        }
    }

    private fun mkdirsRemote(sftp: SFTPClient, dir: String) {
        if (dir.isBlank() || dir == "/") return
        try {
            sftp.mkdirs(dir)
        } catch (_: Throwable) {
            // 某些服务端不支持 mkdirs，逐级创建
            val parts = dir.trim('/').split('/')
            var cur = ""
            for (p in parts) {
                cur += "/$p"
                runCatching { sftp.mkdir(cur) }
            }
        }
    }

    private fun copy(input: InputStream, out: OutputStream, task: TransferTask, startOffset: Long) {
        val buf = ByteArray(32 * 1024)
        var total = startOffset
        var lastNotify = System.currentTimeMillis()
        var lastBytes = startOffset
        task.transferred = total
        while (true) {
            when (task.state) {
                TransferState.CANCELLED -> return
                TransferState.PAUSED -> {
                    Thread.sleep(200)
                    continue
                }
            }
            val n = input.read(buf)
            if (n <= 0) break
            out.write(buf, 0, n)
            total += n
            task.transferred = total
            val now = System.currentTimeMillis()
            val elapsed = now - lastNotify
            if (elapsed >= 400) {
                task.speedBps = ((total - lastBytes) * 1000) / elapsed
                lastBytes = total
                lastNotify = now
                TransferManager.notifyChangedAsync()
                updateNotification(task)
            }
        }
        out.flush()
        task.transferred = total
    }
}
