package com.sshsftp.app

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate
import com.sshsftp.app.data.AppPrefs
import com.sshsftp.app.data.HostStore

class App : Application() {

    override fun onCreate() {
        super.onCreate()
        AppPrefs.init(this)
        HostStore.init(this)
        AppCompatDelegate.setDefaultNightMode(AppPrefs.nightMode)
    }
}
