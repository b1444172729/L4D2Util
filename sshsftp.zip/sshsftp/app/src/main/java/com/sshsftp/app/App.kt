package com.sshsftp.app

import android.app.Application
import android.os.Looper
import android.util.Log
import androidx.appcompat.app.AppCompatDelegate
import com.sshsftp.app.data.AppPrefs
import com.sshsftp.app.data.HostStore
import java.security.Security

class App : Application() {

    override fun onCreate() {
        super.onCreate()
        installCryptoProvider()
        installCrashGuard()
        AppPrefs.init(this)
        HostStore.init(this)
        AppCompatDelegate.setDefaultNightMode(AppPrefs.nightMode)
    }

    /**
     * 关键修复：Android 自带一个被裁剪的 BouncyCastle，注册名同样是 "BC"，
     * 但它不含 X25519 / Ed25519 / chacha20-poly1305 等现代算法。
     *
     * sshj 内部是按名字取 provider 的（KeyAgreement.getInstance("X25519", "BC")），
     * 于是拿到的是系统那个残版，连接时抛：
     *     net.schmizz.sshj.common.SSHRuntimeException:
     *     no such algorithm: X25519 for provider BC
     *
     * 由于 Android 上同名 provider 无法直接覆盖，必须先 remove 再 add，
     * 让 "BC" 这个名字指向 sshj 自带的完整 BouncyCastle。
     *
     * 这里用 addProvider（追加到末尾）而不是 insertProviderAt(..., 1)，
     * 是为了不抢占 Conscrypt(AndroidOpenSSL) 的优先级，避免影响系统 TLS。
     */
    private fun installCryptoProvider() {
        try {
            val bc = org.bouncycastle.jce.provider.BouncyCastleProvider()
            Security.removeProvider("BC")
            val pos = Security.addProvider(bc)
            Log.i(TAG, "BouncyCastle 已注册: name=${bc.name} ver=${bc.version} pos=$pos")
            if (pos < 0) {
                Log.w(TAG, "BouncyCastle 注册未生效（仍存在同名 provider）")
            }
        } catch (t: Throwable) {
            // 注册失败不阻止启动，连接时会给出可读的错误
            Log.e(TAG, "BouncyCastle 注册失败", t)
        }
    }

    /**
     * sshj 的 reader / 心跳等后台线程里抛出的异常没有 try-catch，
     * 在 Android 上任何线程的未捕获异常都会终止整个进程 —— 也就是"闪退"。
     *
     * 这里只让后台线程的异常被记录，不再连累整个 app；
     * 主线程仍交给系统默认处理，避免出现"卡死但什么都不显示"的情况。
     */
    private fun installCrashGuard() {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            Log.e(TAG, "未捕获异常 @ 线程 ${thread.name}", throwable)
            if (Looper.getMainLooper().thread === thread) {
                // 主线程异常交给系统处理（通常是上一个 handler = 系统的崩溃处理器）。
                // 万一拿不到，主动结束进程，避免出现"卡住但毫无反应"的状态。
                if (previous != null) {
                    previous.uncaughtException(thread, throwable)
                } else {
                    android.os.Process.killProcess(android.os.Process.myPid())
                }
            }
        }
    }

    private companion object {
        const val TAG = "SSH助手"
    }
}
