package com.sshsftp.app.ssh

import net.schmizz.sshj.connection.channel.direct.LocalPortForwarder
import net.schmizz.sshj.connection.channel.direct.Parameters
import java.net.ServerSocket
import java.util.concurrent.ConcurrentHashMap

data class PortForwardRule(
    val hostId: String,
    val localPort: Int,
    val remoteHost: String,
    val remotePort: Int,
    @Volatile var running: Boolean = false
)

object PortForwardStore {

    private val byHost = ConcurrentHashMap<String, MutableList<PortForwardRule>>()

    fun all(hostId: String): List<PortForwardRule> = byHost[hostId] ?: emptyList()

    fun save(list: List<PortForwardRule>) {
        if (list.isEmpty()) return
        byHost[list.first().hostId] = list.toMutableList()
    }
}

/** 在 LiveSession 上启动 / 停止一条本地端口转发 */
object PortForwards {

    private val forwarders = ConcurrentHashMap<String, LocalPortForwarder>()

    private fun id(rule: PortForwardRule) = "${rule.hostId}:${rule.localPort}:${rule.remoteHost}:${rule.remotePort}"

    @Throws(Exception::class)
    fun start(live: LiveSession, rule: PortForwardRule) {
        stop(live, rule)
        val client = live.ssh ?: throw IllegalStateException("未连接")
        val serverSocket = ServerSocket(rule.localPort)
        val params = Parameters("localhost", rule.localPort, rule.remoteHost, rule.remotePort)
        val forwarder = client.newLocalPortForwarder(params, serverSocket)
        val t = Thread({
            try {
                forwarder.listen()
            } catch (_: Throwable) {
            }
        }, "pfwd-${rule.localPort}")
        t.isDaemon = true
        t.start()
        forwarders[id(rule)] = forwarder
        rule.running = true
    }

    fun stop(live: LiveSession, rule: PortForwardRule) {
        val fid = id(rule)
        forwarders.remove(fid)?.let {
            runCatching { it.close() }
        }
        rule.running = false
    }
}
