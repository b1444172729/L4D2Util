package con.android.ssh.ui

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import con.android.ssh.R
import con.android.ssh.data.HostStore
import con.android.ssh.ssh.LocalFs
import con.android.ssh.ssh.RemoteFs
import con.android.ssh.ssh.SessionRegistry
import con.android.ssh.util.toast
import java.io.File
import kotlin.concurrent.thread

/**
 * 远程（或本地）文本文件编辑器：读取 → 编辑 → 直接保存回服务器。
 */
class EditorActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PATH = "path"
        const val EXTRA_REMOTE = "remote"
        const val EXTRA_HOST_ID = "host_id"
    }

    private lateinit var editor: EditText
    private lateinit var path: String
    private var remote = false
    private var hostId = ""
    private var original = ""
    private var saving = false
    private val main = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_editor)

        path = intent.getStringExtra(EXTRA_PATH) ?: run { finish(); return }
        remote = intent.getBooleanExtra(EXTRA_REMOTE, false)
        hostId = intent.getStringExtra(EXTRA_HOST_ID).orEmpty()

        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        toolbar.title = getString(R.string.editor_title, File(path).name)
        toolbar.setNavigationOnClickListener { onBack() }
        toolbar.setOnMenuItemClickListener {
            if (it.itemId == R.id.action_save) {
                save()
                true
            } else false
        }

        editor = findViewById(R.id.editor)
        load()
    }

    private fun load() {
        thread {
            var text: String? = null
            var err: String? = null
            try {
                text = if (remote) {
                    val live = SessionRegistry.get(hostId)
                    if (live == null || !live.isAlive) throw IllegalStateException(getString(R.string.session_closed))
                    RemoteFs.readText(live, path)
                } else {
                    LocalFs.readText(File(path))
                }
            } catch (e: Throwable) {
                err = e.message ?: runCatching { getString(R.string.unknown_error) }.getOrDefault("")
            }
            main.post {
                // Activity 已销毁（用户在加载时退出）就不再触碰视图与 Context
                if (isFinishing || isDestroyed) return@post
                if (text == null) {
                    toast(getString(R.string.save_failed, err ?: getString(R.string.unknown_error)))
                    finish()
                    return@post
                }
                original = text!!
                editor.setText(text)
                editor.setSelection(0)
            }
        }
    }

    private fun save() {
        if (saving) return
        saving = true
        val content = editor.text.toString()
        val dialog = MaterialAlertDialogBuilder(this)
            .setMessage(R.string.editor_saving)
            .setCancelable(false)
            .show()
        thread {
            var err: String? = null
            try {
                if (remote) {
                    val live = SessionRegistry.get(hostId)
                    if (live == null || !live.isAlive) throw IllegalStateException(getString(R.string.session_closed))
                    RemoteFs.writeText(live, path, content)
                } else {
                    LocalFs.writeText(File(path), content)
                }
            } catch (e: Throwable) {
                err = e.message
            }
            main.post {
                // 同上：保存过程中 Activity 被销毁时直接放弃回调
                if (isFinishing || isDestroyed) return@post
                dialog.dismiss()
                saving = false
                if (err == null) {
                    original = content
                    toast(getString(R.string.file_saved))
                } else {
                    toast(getString(R.string.save_failed, err!!))
                }
            }
        }
    }

    private fun dirty(): Boolean = editor.text.toString() != original

    private fun onBack() {
        if (dirty()) {
            MaterialAlertDialogBuilder(this)
                .setMessage(R.string.editor_unsaved)
                .setNegativeButton(R.string.cancel, null)
                .setPositiveButton(R.string.discard) { _, _ -> finish() }
                .show()
        } else {
            finish()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        onBack()
    }

    override fun onResume() {
        super.onResume()
        if (con.android.ssh.util.ThemeGuard.check(this)) return
    }

}
