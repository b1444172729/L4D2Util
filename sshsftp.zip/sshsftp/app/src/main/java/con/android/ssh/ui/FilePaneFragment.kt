package con.android.ssh.ui

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.TextView
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.button.MaterialButton
import com.google.android.material.tabs.TabLayout
import con.android.ssh.R
import con.android.ssh.data.AppPrefs
import con.android.ssh.ssh.ClipboardEntry
import con.android.ssh.ssh.FileItem
import con.android.ssh.ssh.LiveSession
import con.android.ssh.ssh.LocalFs
import con.android.ssh.ssh.PaneClipboard
import con.android.ssh.ssh.RemoteFs
import con.android.ssh.ssh.SessionRegistry
import con.android.ssh.ssh.TransferPlanner
import con.android.ssh.ssh.TransferTask
import con.android.ssh.ssh.formatSize
import con.android.ssh.ssh.formatTime
import con.android.ssh.ssh.joinPath
import con.android.ssh.ssh.octalString
import con.android.ssh.ssh.parentPath
import con.android.ssh.ssh.permsToString
import con.android.ssh.ssh.sortItems
import con.android.ssh.util.confirmDialog
import con.android.ssh.util.inputDialog
import con.android.ssh.util.openFileWith
import con.android.ssh.util.permissionsDialog
import con.android.ssh.util.propertiesDialog
import con.android.ssh.util.toast
import kotlin.concurrent.thread

class FilePaneFragment : Fragment(R.layout.fragment_file_pane) {

    companion object {
        private const val ARG_HOST_ID = "host_id"
        private const val ARG_REMOTE = "remote"

        fun new(hostId: String, remote: Boolean) = FilePaneFragment().apply {
            arguments = Bundle().apply {
                putString(ARG_HOST_ID, hostId)
                putBoolean(ARG_REMOTE, remote)
            }
        }
    }

    private val hostId: String by lazy { requireArguments().getString(ARG_HOST_ID)!! }
    private val remote: Boolean by lazy { requireArguments().getBoolean(ARG_REMOTE) }

    private val main = Handler(Looper.getMainLooper())
    private var currentPath: String = "/"
    private var items = mutableListOf<FileItem>()
    private val selection = LinkedHashSet<String>()
    private var selectionMode = false
    private var loading = false

    private lateinit var adapter: FileAdapter
    private lateinit var tvPath: TextView
    private lateinit var tvSelected: TextView
    private lateinit var empty: TextView
    private lateinit var progress: ProgressBar
    private lateinit var swipe: SwipeRefreshLayout
    private lateinit var btnMain: MaterialButton
    private lateinit var btnPaste: MaterialButton
    private lateinit var tvNotice: TextView

    private fun host(): PaneHost? = parentFragment as? PaneHost

    /**
     * 后台线程安全地取字符串。
     *
     * 后台任务（thread{}）里若直接 getString()，会在 Fragment 已销毁时
     * 抛 IllegalStateException("Fragment not attached to a context")，
     * 直接把进程带崩。这里拿不到 Context 时退化为占位串，不再抛异常。
     */
    private fun s(resId: Int, vararg args: Any): String =
        runCatching { context?.getString(resId, *args) }.getOrNull() ?: ""

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        tvPath = view.findViewById(R.id.tvPath)
        tvSelected = view.findViewById(R.id.tvSelected)
        empty = view.findViewById(R.id.empty)
        progress = view.findViewById(R.id.progress)
        swipe = view.findViewById(R.id.swipe)
        btnMain = view.findViewById(R.id.btnMain)
        btnPaste = view.findViewById(R.id.btnPaste)
        tvNotice = view.findViewById(R.id.tvNotice)

        adapter = FileAdapter(
            onClick = { item, _ -> onItemClick(item) },
            onLongClick = { item, _ -> onItemLongClick(item); true },
            onCheck = { item, checked ->
                if (checked) selection.add(item.path) else selection.remove(item.path)
                updateSelectionUi()
            }
        )

        val recycler = view.findViewById<RecyclerView>(R.id.recycler)
        recycler.layoutManager = LinearLayoutManager(requireContext())
        recycler.adapter = adapter

        swipe.setOnRefreshListener { load(currentPath) }
        swipe.setColorSchemeResources(R.color.primary)

        view.findViewById<ImageButton>(R.id.btnUp).setOnClickListener { goUp() }
        view.findViewById<ImageButton>(R.id.btnHome).setOnClickListener { goRoot() }
        view.findViewById<ImageButton>(R.id.btnRefresh).setOnClickListener { load(currentPath) }
        // 顶部右侧的"三个点"已移除。底部"更多"按钮：
        // 有选中项 → 对这些文件的操作菜单；无选中项 → 面板菜单（含多选等）
        view.findViewById<MaterialButton>(R.id.btnAction).setOnClickListener {
            if (selection.isNotEmpty()) showActionsMenu(it, null)
            else showPaneMenu(it)
        }

        btnMain.text = if (remote) getString(R.string.download) else getString(R.string.upload)
        btnMain.setIconResource(if (remote) R.drawable.ic_download else R.drawable.ic_upload)
        btnMain.setOnClickListener { transferSelection() }

        view.findViewById<MaterialButton>(R.id.btnNew).setOnClickListener { newFolder() }

        btnPaste.setOnClickListener { pasteHere() }

        if (!remote) {
            tvNotice.setOnClickListener {
                try {
                    val i = android.content.Intent(android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                    i.data = android.net.Uri.parse("package:${requireContext().packageName}")
                    startActivity(i)
                } catch (_: Throwable) {
                    toast(requireContext().getString(R.string.need_storage_permission))
                }
            }
            refreshPermissionNotice()
        }

        val start = if (remote) {
            SessionRegistry.hostStartDir(hostId)
        } else {
            LocalFs.root(requireContext()).absolutePath
        }
        currentPath = start
        host()?.ensureConnected { load(currentPath) }
        if (!remote) load(currentPath)
    }

    fun currentDir(): String = currentPath

    // ---------------- 导航 ----------------

    private fun goUp() {
        val parent = if (remote) parentPath(currentPath) else parentPath(currentPath)
        if (parent == currentPath) return
        load(parent)
    }

    private fun goRoot() {
        val root = if (remote) {
            val live = host()?.liveSession()
            if (live != null && live.isAlive) {
                try {
                    RemoteFs.canonical(live, ".")
                } catch (_: Throwable) {
                    "/"
                }
            } else "/"
        } else {
            LocalFs.root(requireContext()).absolutePath
        }
        load(root)
    }

    fun load(path: String) {
        if (loading) return
        selection.clear()
        selectionMode = false
        updateSelectionUi()
        if (remote) {
            loadRemote(path)
        } else {
            // 本地加载是同步完成的，必须在这里收尾。
            // 之前只有 loadRemote 的异步回调里调了 setBusy(false)，
            // 本地这条路径从不复位 —— 于是进度圈一直转，即使列表早已显示完。
            loadLocal(path)
            setBusy(false)
        }
    }

    /** 重新载入当前目录（设置变化后刷新用） */
    fun reload() {
        if (!::adapter.isInitialized) return
        load(currentPath)
    }

    /**
     * 刷新"需要所有文件访问权限"提示条的可见性。
     *
     * 之前只在 onViewCreated 里判断一次，而授权页是跳到系统设置完成的，
     * 回到应用时 Fragment 不会重建，提示条就一直挂着 —— 必须重启应用才消失。
     * 现在在每次回到前台（onResume）时重新判断，授权后立即隐藏。
     */
    private fun refreshPermissionNotice() {
        if (remote || !::tvNotice.isInitialized) return
        val ok = LocalFs.hasFullAccess()
        tvNotice.isVisible = !ok
        // 授权状态变化时，本地起始目录也会变（不再退回应用私有目录），需要重载
        if (ok) {
            val root = LocalFs.root(requireContext()).absolutePath
            if (currentPath != root && !currentPath.startsWith(root)) {
                load(root)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshPermissionNotice()
    }

    private fun setBusy(busy: Boolean) {
        loading = busy
        progress.isVisible = busy
        swipe.isRefreshing = false
    }

    private fun loadLocal(path: String) {
        val dir = java.io.File(path)
        if (!dir.isDirectory) {
            toast(getString(R.string.empty_dir))
            return
        }
        currentPath = dir.absolutePath
        tvPath.text = currentPath
        val list = LocalFs.list(dir, host()?.showHidden() ?: AppPrefs.showHidden).toMutableList()
        sortItems(list, host()?.currentSort() ?: "name")
        items = list
        adapter.submit(list, selectionMode, selection)
        empty.isVisible = list.isEmpty()
    }

    private fun loadRemote(path: String) {
        val live = host()?.liveSession()
        if (live == null || !live.isAlive) {
            empty.isVisible = true
            empty.text = getString(R.string.session_closed)
            return
        }
        setBusy(true)
        thread(name = "sftp-ls") {
            var list: List<FileItem>? = null
            var err: String? = null
            var real = path
            try {
                real = RemoteFs.canonical(live, path)
                list = RemoteFs.list(live, real, host()?.showHidden() ?: AppPrefs.showHidden)
            } catch (e: Throwable) {
                err = e.message ?: s(R.string.unknown_error)
            }
            main.post {
                // Fragment 已销毁（用户退出页面）时不再触碰视图与 Context，否则 getString()/requireContext() 会抛 IllegalStateException
                if (!isAdded || isRemoving || isDetached) return@post
                setBusy(false)
                if (list == null) {
                    toast(err ?: getString(R.string.unknown_error))
                    return@post
                }
                currentPath = real
                tvPath.text = real
                val sorted = list.toMutableList()
                sortItems(sorted, host()?.currentSort() ?: "name")
                items = sorted
                adapter.submit(sorted, selectionMode, selection)
                empty.isVisible = sorted.isEmpty()
                empty.text = getString(R.string.empty_dir)
            }
        }
    }

    private fun onItemClick(item: FileItem) {
        if (selectionMode) {
            if (selection.contains(item.path)) selection.remove(item.path) else selection.add(item.path)
            updateSelectionUi()
            adapter.submit(items, selectionMode, selection)
            return
        }
        if (item.isDir) {
            load(item.path)
        } else {
            showActionsMenu(null, item)
        }
    }

    /**
     * 长按：直接弹出该文件的操作菜单（居中显示）。
     *
     * 之前长按是"进入多选模式"，现在多选改由面板菜单里的【多选】按钮进入，
     * 长按专职用来对单个文件呼出操作菜单。
     */
    private fun onItemLongClick(item: FileItem) {
        showActionsMenu(null, item, centered = true)
    }

    private fun updateSelectionUi() {
        val n = selection.size
        tvSelected.isVisible = n > 0
        tvSelected.text = getString(R.string.selected_count, n)
        btnPaste.isVisible = !PaneClipboard.isEmpty()
        if (n == 0) selectionMode = false
    }

    // ---------------- 菜单 ----------------

    private fun showPaneMenu(anchor: View, centered: Boolean = false) {
        val popup = PopupMenu(requireContext(), anchor)
        popup.menuInflater.inflate(R.menu.menu_file_pane, popup.menu)
        if (centered) popup.gravity = android.view.Gravity.CENTER
        popup.menu.findItem(R.id.action_hidden).isChecked = host()?.showHidden() ?: AppPrefs.showHidden
        val sort = host()?.currentSort() ?: "name"
        popup.menu.findItem(
            when (sort) {
                "size" -> R.id.sort_size
                "time" -> R.id.sort_time
                "type" -> R.id.sort_type
                else -> R.id.sort_name
            }
        ).isChecked = true
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.sort_name, R.id.sort_size, R.id.sort_time, R.id.sort_type -> {
                    val mode = when (item.itemId) {
                        R.id.sort_size -> "size"
                        R.id.sort_time -> "time"
                        R.id.sort_type -> "type"
                        else -> "name"
                    }
                    host()?.setSort(mode)
                    load(currentPath)
                }
                R.id.action_hidden -> {
                    val v = !(host()?.showHidden() ?: AppPrefs.showHidden)
                    host()?.setShowHidden(v)
                    load(currentPath)
                }
                R.id.action_select_all -> {
                    selectionMode = true
                    selection.clear()
                    items.forEach { selection.add(it.path) }
                    updateSelectionUi()
                    adapter.submit(items, selectionMode, selection)
                }
                R.id.action_multi_select -> {
                    // 进入多选模式：选中项清空，由用户自己勾选。
                    //
                    // 顺序很关键：updateSelectionUi() 内部有 "if (n == 0)
                    // selectionMode = false"（清空后立即退出多选）。
                    // 所以必须先让它跑完、再置 true，否则刚进入就被打回，
                    // 表现为"点了多选却没有任何反应"。
                    selection.clear()
                    updateSelectionUi()
                    selectionMode = true
                    adapter.submit(items, selectionMode, selection)
                }
                R.id.action_deselect_all -> {
                    selection.clear()
                    selectionMode = false
                    updateSelectionUi()
                    adapter.submit(items, selectionMode, selection)
                }
                R.id.action_new_file -> newFile()
                R.id.action_new_folder -> newFolder()
            }
            true
        }
        popup.show()
    }

    private fun showActionsMenu(anchor: View?, item: FileItem?, centered: Boolean = false) {
        val targets = selectedItems()
        val single = item ?: targets.singleOrNull()
        if (single == null && targets.isEmpty()) {
            // 没有选中项：退化为面板菜单
            val a = anchor ?: requireView().findViewById<MaterialButton>(R.id.btnAction)
            showPaneMenu(a, centered)
            return
        }
        val list = if (single != null) listOf(single) else targets
        val view = anchor ?: requireView().findViewById<MaterialButton>(R.id.btnAction)
        val popup = PopupMenu(requireContext(), view)
        popup.menuInflater.inflate(R.menu.menu_file_actions, popup.menu)
        // "新建文件"已移到面板菜单（取消选择之后），这里不再重复添加
        if (centered) popup.gravity = android.view.Gravity.CENTER

        val isRemote = remote
        popup.menu.findItem(R.id.action_transfer).title =
            if (isRemote) getString(R.string.download) else getString(R.string.upload)
        popup.menu.findItem(R.id.action_edit_file).isVisible = !list.any { it.isDir }
        popup.menu.findItem(R.id.action_open_with).isVisible = !isRemote && !list.any { it.isDir }
        popup.menu.findItem(R.id.action_permissions).isVisible = isRemote || !isRemote
        popup.menu.findItem(R.id.action_rename).isVisible = list.size == 1

        popup.setOnMenuItemClickListener { mi -> handleAction(mi, list) }
        popup.show()
    }

    private fun handleAction(mi: MenuItem, list: List<FileItem>): Boolean {
        when (mi.itemId) {
            R.id.action_transfer -> transferList(list)
            R.id.action_edit_file -> openEditor(list.first())
            R.id.action_open_with -> openFileWith(requireContext(), java.io.File(list.first().path))
            R.id.action_rename -> renameItem(list.first())
            R.id.action_copy -> copyToClipboard(list, false)
            R.id.action_cut -> copyToClipboard(list, true)
            R.id.action_permissions -> changePermissions(list)
            R.id.action_properties -> showProperties(list.first())
            R.id.action_delete -> deleteItems(list)
        }
        return true
    }

    private fun selectedItems(): List<FileItem> =
        items.filter { selection.contains(it.path) }

    // ---------------- 操作 ----------------

    private fun transferSelection() {
        val list = selectedItems()
        if (list.isEmpty()) {
            toast(getString(R.string.selected_count, 0))
            return
        }
        transferList(list)
    }

    /**
     * 传输方向规则（本面板永远是"源"，另一侧是"目标"）：
     *   本面板是本地(remote=false) ⇒ 上传 upload=true  ⇒ 目标 = 远程当前目录
     *   本面板是远程(remote=true)  ⇒ 下载 upload=false ⇒ 目标 = 本地当前目录
     */
    private fun transferList(list: List<FileItem>) {
        if (list.isEmpty()) return
        val h = host() ?: return

        val upload = !remote
        val destDir = if (upload) h.remoteDir() else h.localDir()
        if (destDir.isBlank()) {
            toast(getString(R.string.operation_cancelled))
            return
        }

        // 上传同样需要连接：以前只在下载时检查，断开时上传会静默失败
        val live = h.liveSession()
        if (live == null || !live.isAlive) {
            toast(getString(R.string.session_closed))
            return
        }

        // 目录【下载】时才需要预建本地目录；上传时建的是远端目录，由 SFTP 端负责
        if (!upload) {
            list.filter { it.isDir }.forEach {
                java.io.File(destDir, it.name).mkdirs()
            }
        }

        android.util.Log.d(
            "终端模拟器",
            "${if (upload) "上传" else "下载"} ${list.size} 项: " +
                list.joinToString { it.path } + "  →  " + destDir
        )

        TransferPlanner.plan(requireActivity(), hostId, upload, list, destDir) { tasks ->
            if (tasks.isEmpty()) {
                toast(getString(R.string.operation_cancelled))
                return@plan
            }
            h.enqueue(tasks)
        }
    }

    private fun copyToClipboard(list: List<FileItem>, cut: Boolean) {
        PaneClipboard.set(list.map {
            ClipboardEntry(it.path, it.name, it.isDir, cut, remote)
        }, cut)
        updateSelectionUi()
        toast(if (cut) getString(R.string.cut) else getString(R.string.copy))
    }

    private fun pasteHere() {
        val entries = PaneClipboard.all()
        if (entries.isEmpty()) {
            toast(getString(R.string.clipboard_empty))
            return
        }
        val dest = currentPath
        if (entries.any { it.remote != remote }) {
            // 跨端粘贴 = 传输。
            // 方向由【来源】决定：剪贴板内容来自本地 ⇒ 上传；来自远程 ⇒ 下载。
            // 之前写成 !remote（按目标面板判断），跨端场景下恰好取反 ——
            // 于是往本地面板粘贴远程文件会当成"上传"，把远程路径当本地文件读。
            val live = host()?.liveSession()
            if (live == null || !live.isAlive) {
                toast(getString(R.string.session_closed))
                return
            }
            val upload = !entries.first().remote
            val items = entries.map { FileItem(it.name, it.path, it.isDir, 0, 0) }
            android.util.Log.d(
                "终端模拟器",
                "跨端粘贴 ${if (upload) "上传" else "下载"}: " +
                    items.joinToString { it.path } + "  →  " + dest
            )
            TransferPlanner.plan(requireActivity(), hostId, upload, items, dest) { tasks ->
                if (tasks.isEmpty()) return@plan
                host()?.enqueue(tasks)
            }
            PaneClipboard.clear()
            updateSelectionUi()
            return
        }
        // 同端粘贴 = 复制 / 移动
        setBusy(true)
        thread {
            var moved = 0
            for (e in entries) {
                try {
                    val target = joinPath(dest, e.name)
                    if (remote) {
                        val live = host()?.liveSession() ?: continue
                        RemoteFs.copyOrMove(live, e.path, target, e.cut)
                    } else {
                        LocalFs.copyOrMove(java.io.File(e.path), java.io.File(target), e.cut)
                    }
                    moved++
                } catch (_: Throwable) {
                }
            }
            main.post {
                // Fragment 已销毁（用户退出页面）时不再触碰视图与 Context，否则 getString()/requireContext() 会抛 IllegalStateException
                if (!isAdded || isRemoving || isDetached) return@post
                setBusy(false)
                toast(getString(R.string.done))
                PaneClipboard.clear()
                load(currentPath)
                host()?.refreshCounterpart()
            }
        }
    }

    private fun newFolder() {
        inputDialog(requireContext(), getString(R.string.mkdir_title), getString(R.string.file_name)) { name ->
            if (name.isEmpty()) return@inputDialog
            setBusy(true)
            thread {
                var err: String? = null
                try {
                    if (remote) {
                        val live = host()?.liveSession() ?: throw IllegalStateException(s(R.string.session_closed))
                        RemoteFs.mkdir(live, joinPath(currentPath, name))
                    } else {
                        LocalFs.mkdir(java.io.File(currentPath), name)
                    }
                } catch (e: Throwable) {
                    err = e.message
                }
                main.post {
                    // Fragment 已销毁（用户退出页面）时不再触碰视图与 Context，否则 getString()/requireContext() 会抛 IllegalStateException
                    if (!isAdded || isRemoving || isDetached) return@post
                    setBusy(false)
                    if (err != null) toast(err!!) else load(currentPath)
                }
            }
        }
    }

    private fun newFile() {
        inputDialog(requireContext(), getString(R.string.new_file), getString(R.string.file_name)) { name ->
            if (name.isEmpty()) return@inputDialog
            setBusy(true)
            thread {
                var err: String? = null
                try {
                    if (remote) {
                        val live = host()?.liveSession() ?: throw IllegalStateException(s(R.string.session_closed))
                        RemoteFs.createFile(live, joinPath(currentPath, name))
                    } else {
                        LocalFs.createFile(java.io.File(currentPath), name)
                    }
                } catch (e: Throwable) {
                    err = e.message
                }
                main.post {
                    // Fragment 已销毁（用户退出页面）时不再触碰视图与 Context，否则 getString()/requireContext() 会抛 IllegalStateException
                    if (!isAdded || isRemoving || isDetached) return@post
                    setBusy(false)
                    if (err != null) toast(err!!) else load(currentPath)
                }
            }
        }
    }

    private fun renameItem(item: FileItem) {
        inputDialog(requireContext(), getString(R.string.rename), getString(R.string.file_name), item.name) { name ->
            if (name.isEmpty() || name == item.name) return@inputDialog
            setBusy(true)
            thread {
                var err: String? = null
                try {
                    if (remote) {
                        val live = host()?.liveSession() ?: throw IllegalStateException(s(R.string.session_closed))
                        RemoteFs.rename(live, item.path, joinPath(currentPath, name))
                    } else {
                        LocalFs.rename(java.io.File(item.path), name)
                    }
                } catch (e: Throwable) {
                    err = e.message
                }
                main.post {
                    // Fragment 已销毁（用户退出页面）时不再触碰视图与 Context，否则 getString()/requireContext() 会抛 IllegalStateException
                    if (!isAdded || isRemoving || isDetached) return@post
                    setBusy(false)
                    if (err != null) toast(err!!) else load(currentPath)
                }
            }
        }
    }

    private fun deleteItems(list: List<FileItem>) {
        val title = getString(R.string.delete)
        val msg = if (list.size == 1) {
            getString(R.string.delete_confirm_one, list.first().name)
        } else {
            getString(R.string.delete_confirm, list.size)
        }
        confirmDialog(requireContext(), title, msg) {
            setBusy(true)
            thread {
                var count = 0
                var err: String? = null
                try {
                    if (remote) {
                        val live = host()?.liveSession() ?: throw IllegalStateException(s(R.string.session_closed))
                        list.forEach { RemoteFs.delete(live, it); count++ }
                    } else {
                        list.forEach { if (LocalFs.delete(java.io.File(it.path))) count++ }
                    }
                } catch (e: Throwable) {
                    err = e.message
                }
                main.post {
                    // Fragment 已销毁（用户退出页面）时不再触碰视图与 Context，否则 getString()/requireContext() 会抛 IllegalStateException
                    if (!isAdded || isRemoving || isDetached) return@post
                    setBusy(false)
                    if (err != null) toast(err!!) else toast(getString(R.string.deleted, count))
                    selection.clear()
                    selectionMode = false
                    load(currentPath)
                }
            }
        }
    }

    private fun changePermissions(list: List<FileItem>) {
        val first = list.firstOrNull() ?: return
        val current = if (remote) first.perms and 0x1FF else (first.perms and 0x1FF)
        permissionsDialog(requireContext(), current, list.size > 1) { perms, applyAll ->
            val targets = if (applyAll) list else listOf(first)
            setBusy(true)
            thread {
                var err: String? = null
                try {
                    if (remote) {
                        val live = host()?.liveSession() ?: throw IllegalStateException(s(R.string.session_closed))
                        targets.forEach { RemoteFs.chmod(live, it.path, perms) }
                    } else {
                        targets.forEach { LocalFs.chmod(java.io.File(it.path), perms) }
                    }
                } catch (e: Throwable) {
                    err = e.message
                }
                main.post {
                    // Fragment 已销毁（用户退出页面）时不再触碰视图与 Context，否则 getString()/requireContext() 会抛 IllegalStateException
                    if (!isAdded || isRemoving || isDetached) return@post
                    setBusy(false)
                    if (err != null) toast(err!!) else load(currentPath)
                }
            }
        }
    }

    private fun showProperties(item: FileItem) {
        val text = buildString {
            append(getString(R.string.name)).append("：").append(item.name).append('\n')
            append(getString(R.string.path)).append("：").append(item.path).append('\n')
            append(getString(R.string.type)).append("：")
                .append(if (item.isDir) "目录" else "文件").append('\n')
            if (!item.isDir) append(getString(R.string.size)).append("：").append(formatSize(item.size)).append('\n')
            append(getString(R.string.modified)).append("：").append(formatTime(item.mtime)).append('\n')
            append(getString(R.string.permissions)).append("：")
                .append(permsToString(item.perms)).append(" (").append(octalString(item.perms)).append(")\n")
            if (remote && item.owner.isNotEmpty()) {
                append(getString(R.string.owner)).append("：").append(item.owner).append('\n')
            }
        }
        propertiesDialog(requireContext(), item.name, text)
    }

    private fun openEditor(item: FileItem) {
        if (remote) {
            host()?.openRemoteEditor(item.path)
        } else {
            val f = java.io.File(item.path)
            if (f.length() > 1024 * 1024) {
                toast(getString(R.string.file_too_large))
                return
            }
            startActivity(
                android.content.Intent(requireContext(), EditorActivity::class.java)
                    .putExtra(EditorActivity.EXTRA_PATH, item.path)
                    .putExtra(EditorActivity.EXTRA_REMOTE, false)
            )
        }
    }

    // ---------------- 适配器 ----------------

    private class FileAdapter(
        private val onClick: (FileItem, Int) -> Unit,
        private val onLongClick: (FileItem, Int) -> Boolean,
        private val onCheck: (FileItem, Boolean) -> Unit
    ) : RecyclerView.Adapter<FileAdapter.VH>() {

        private val items = ArrayList<FileItem>()
        private var selectionMode = false
        private val selected = HashSet<String>()

        fun submit(list: List<FileItem>, mode: Boolean, sel: Set<String>) {
            items.clear()
            items.addAll(list)
            selectionMode = mode
            selected.clear()
            selected.addAll(sel)
            notifyDataSetChanged()
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_file, parent, false))

        override fun getItemCount(): Int = items.size

        override fun onBindViewHolder(holder: VH, position: Int) {
            holder.bind(items[position], selectionMode, selected.contains(items[position].path), onClick, onLongClick, onCheck)
        }

        class VH(view: View) : RecyclerView.ViewHolder(view) {
            private val check: CheckBox = view.findViewById(R.id.check)
            private val icon: ImageView = view.findViewById(R.id.icon)
            private val name: TextView = view.findViewById(R.id.name)
            private val meta: TextView = view.findViewById(R.id.meta)

            fun bind(
                item: FileItem,
                mode: Boolean,
                checked: Boolean,
                onClick: (FileItem, Int) -> Unit,
                onLongClick: (FileItem, Int) -> Boolean,
                onCheck: (FileItem, Boolean) -> Unit
            ) {
                name.text = item.name
                icon.setImageResource(if (item.isDir) R.drawable.ic_folder else R.drawable.ic_file)
                check.visibility = if (mode) View.VISIBLE else View.GONE
                // 顺序至关重要：必须先摘掉监听器，再改 isChecked，最后才重新挂上。
                //
                // 之前是"先 isChecked = checked，再 setOnCheckedChangeListener(null)"，
                // 而 CheckBox 在程序化改变选中状态时会触发当前已注册的监听器 ——
                // 此时挂着的还是【上一次绑定】时那个（属于另一个条目的）监听器。
                // 于是复用 ViewHolder 时，勾选 A 会顺带把 B 也选上（或反选），
                // 表现为"选这项却多选了另一项"。
                check.setOnCheckedChangeListener(null)
                check.isChecked = checked
                check.setOnCheckedChangeListener { _, isChecked -> onCheck(item, isChecked) }
                meta.text = if (item.isDir) {
                    formatTime(item.mtime)
                } else {
                    "${formatSize(item.size)} · ${formatTime(item.mtime)}"
                }
                itemView.setOnClickListener { onClick(item, bindingAdapterPosition) }
                itemView.setOnLongClickListener { onLongClick(item, bindingAdapterPosition) }
            }
        }
    }
}
