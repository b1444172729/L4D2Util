package con.android.ssh.ssh

import android.os.Handler
import android.os.Looper
import android.util.Log
import con.android.ssh.data.AppPrefs
import con.android.ssh.data.HostConfig
import con.android.ssh.term.TerminalEmulator
import net.schmizz.sshj.SSHClient
import net.schmizz.sshj.connection.channel.direct.PTYMode
import net.schmizz.sshj.connection.channel.direct.Session
import net.schmizz.sshj.sftp.SFTPClient
import java.io.IOException
import kotlin.concurrent.thread

enum class ConnState { IDLE, CONNECTING, CONNECTED, FAILED, CLOSED }

/** 统一日志 TAG，logcat 过滤它即可看到全部运行信息 */
private const val TAG = "终端模拟器"

/**
 * 一条到远程主机的活动连接：SSH 客户端、Shell 会话、SFTP 客户端与终端缓冲区。
 */
class LiveSession(val host: HostConfig) {

    @Volatile
    var state: ConnState = ConnState.IDLE

    @Volatile
    var ssh: SSHClient? = null

    @Volatile
    var session: Session? = null

    @Volatile
    var shell: Session.Shell? = null

    @Volatile
    var sftp: SFTPClient? = null

    var emulator: TerminalEmulator? = null

    @Volatile
    var error: String? = null

    /** 最近一次操作失败的原因（发送/启动 shell） */
    @Volatile
    var lastError: String? = null

    private val sftpLock = Any()
    private val shellLock = Any()
    private var readerThread: Thread? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    /** 通道是否已损坏（sshj buffer 负 wpos），损坏后只能重连 */
    @Volatile
    var broken = false

    /** 专用写线程：串行化发送，避免与 reader 并发操作 transport */
    private val writeExecutor = java.util.concurrent.Executors.newSingleThreadExecutor { r ->
        Thread(r, "ssh-send").apply { isDaemon = true }
    }

    /** 发送失败回调（主线程） */
    var onSendError: ((String) -> Unit)? = null

    val isAlive: Boolean
        get() = state == ConnState.CONNECTED && ssh?.isConnected == true

    /** 顺序使用 SFTP 客户端（sshj 的 SFTPClient 不是线程安全的） */
    fun <T> withSftp(block: (SFTPClient) -> T): T {
        // 中心防线：任何网络操作都不许在主线程发起。
        // 主线程做网络写会抛 NetworkOnMainThreadException，且报文编到一半，
        // 会把 sshj 的 buffer 弄坏（wpos 变负），之后整个连接都发不出数据。
        if (Looper.getMainLooper().thread === Thread.currentThread()) {
            val e = IOException("禁止在主线程执行 SSH 网络操作")
            Log.e(TAG, "withSftp 在主线程被调用，已阻止")
            throw e
        }
        if (broken) throw IOException("连接已损坏，请重连")
        synchronized(sftpLock) {
            val client = sftp ?: ssh!!.newSFTPClient().also { sftp = it }
            return try {
                block(client)
            } catch (e: IOException) {
                // 连接已断或会话失效：丢弃客户端，下次重新打开
                if (ssh?.isConnected != true) sftp = null
                throw e
            }
        }
    }

    /**
     * 启动 shell。返回 null 表示成功，否则返回可读的错误原因。
     *
     * 注意：以前这里是抛异常由调用方 catch，失败原因被吞掉，
     * 只能笼统提示"会话已关闭"，无法定位。现在把原因带回 UI。
     */
    fun startShell(cols: Int, rows: Int): String? {
        // 幂等：已经有一个活着的 shell 就直接复用。
        // 之前每次 onConnected 都会再 startSession，产生多个 shell / 多条 reader 线程
        // 抢同一个 transport，通道状态被搅乱 —— 这正是后续写入抛
        // arraycopy 越界（sshj 已知问题，wpos 变负）的根源。
        synchronized(shellLock) {
            if (shell != null && session != null && ssh?.isConnected == true) {
                Log.i(TAG, "shell 已存在，直接复用")
                return null
            }
            return reallyStartShell(cols, rows)
        }
    }

    private fun reallyStartShell(cols: Int, rows: Int): String? {
        val client = ssh ?: return "尚未建立连接"

        // 彻底回收旧资源：先停掉旧 reader，再关 shell / session，
        // 否则旧线程继续读已废弃的通道，会把 transport 状态搅乱。
        readerThread?.interrupt()
        readerThread = null
        runCatching { shell?.close() }
        runCatching { session?.close() }
        shell = null
        session = null

        return try {
            val s = client.startSession()
            session = s

            // PTY 尺寸必须合法，0 或负数会让部分服务器直接拒绝并关闭通道。
            val c = cols.coerceIn(20, 500)
            val r = rows.coerceIn(5, 200)
            val term = AppPrefs.termType.ifBlank { "xterm" }
            Log.i(TAG, "申请 PTY: term=$term ${c}x${r}")

            try {
                // 只使用与原实现相同的 allocatePTY 签名（Int 参数），避免 API 差异。
                // 带上像素尺寸，部分服务器对全 0 的 pty-req 敏感。
                s.allocatePTY(term, c, r, c * 8, r * 16, emptyMap<PTYMode, Int>())
            } catch (e: Throwable) {
                // 老式/嵌入式 sshd 可能不接受这种 pty-req，
                // 回退到最保守的参数再试一次（同样只调用已验证存在的 API）。
                Log.w(TAG, "allocatePTY 失败，回退保守参数: ${e.message}")
                s.allocatePTY("vt100", 80, 24, 0, 0, emptyMap<PTYMode, Int>())
            }

            val sh = s.startShell()
            shell = sh

            val cmd = host.startupCmd.trim()
            if (cmd.isNotEmpty()) {
                runCatching {
                    sh.outputStream.write((cmd + "\n").toByteArray(Charsets.UTF_8))
                    sh.outputStream.flush()
                }
            }
            startReader()
            Log.i(TAG, "shell 已启动 ${c}x${r}")
            null
        } catch (e: Throwable) {
            Log.e(TAG, "启动 shell 失败", e)
            "启动 shell 失败：${e.message ?: e::class.java.simpleName}"
        }
    }

    /**
     * 异步发送：投递到专用单线程。
     *
     * 两个原因：
     * 1. 不能在主线程做网络写（sshj 写时会等待远端窗口，可能阻塞）；
     * 2. 串行化后保证按键顺序，且不会与 reader 线程并发操作 transport。
     */
    fun send(data: ByteArray) {
        if (broken) {
            notifySendError("连接已损坏，请点右上角「重连」")
            return
        }
        if (writeExecutor.isShutdown) {
            notifySendError("连接已关闭")
            return
        }
        writeExecutor.execute {
            if (!doSend(data)) {
                notifySendError(lastError ?: "未知原因")
            }
        }
    }

    /** 同步写入，只在写线程中调用 */
    private fun doSend(data: ByteArray): Boolean {
        val sh = shell
        if (sh == null) {
            lastError = "Shell 未启动"
            Log.w(TAG, "发送失败：shell 为空")
            return false
        }
        return try {
            val out = sh.outputStream
            // 统一行结束符：PTY 的输入行结束符是 CR(0x0D)。
            // 软键盘回车、快捷命令、粘贴文本带的都是 LF(0x0A)，
            // 直接发 LF 时 shell 常常不认为一行结束 —— 表现就是"回车没反应"。
            // 终端输入场景下把 LF 一律换成 CR 是安全的（ESC 序列里不含 0x0A）。
            val payload = if (data.indexOf(0x0A.toByte()) >= 0) {
                val fixed = data.copyOf()
                for (i in fixed.indices) if (fixed[i] == 0x0A.toByte()) fixed[i] = 0x0D.toByte()
                fixed
            } else data

            Log.d(TAG, "发送 ${payload.size} 字节: ${hex(payload)}")
            out.write(payload)
            out.flush()
            true
        } catch (e: Throwable) {
            // arraycopy 越界 = sshj buffer 的 wpos 已变负，此连接不可恢复，必须重连
            val isFatal = e is ArrayIndexOutOfBoundsException ||
                e is IndexOutOfBoundsException ||
                (e.message?.contains("index=-", true) == true) ||
                (e.message?.contains("dstPos=-", true) == true)
            Log.e(TAG, "发送失败（完整堆栈见下）", e)
            var root: Throwable = e
            var depth = 0
            while (root.cause != null && depth++ < 5) root = root.cause!!
            lastError = "${root.javaClass.simpleName}: ${root.message}"
            if (isFatal) {
                markBroken(root)
            } else if (ssh?.isConnected != true) {
                markClosed()
            }
            false
        }
    }

    private fun notifySendError(msg: String) {
        val cb = onSendError
        if (cb != null) mainHandler.post { runCatching { cb.invoke(msg) } }
    }

    /** 把字节数组转成十六进制，供日志诊断 */
    private fun hex(data: ByteArray): String {
        val n = data.size.coerceAtMost(16)
        val sb = StringBuilder()
        for (i in 0 until n) {
            sb.append((data[i].toInt() and 0xFF).toString(16).padStart(2, '0')).append(' ')
        }
        if (data.size > n) sb.append("…")
        return sb.toString().trim()
    }

    /** 兼容旧调用：结果不再同步返回，发送失败会通过 onSendError 回调 */
    fun sendText(text: String) {
        send(text.toByteArray(Charsets.UTF_8))
    }

    /**
     * 同步 PTY 窗口尺寸。
     *
     * 必须走写线程：这本身是一次网络写（发 SSH 报文）。
     * 以前它在主线程直接调用（View 的 onSizeChanged 触发），
     * 连接刚建立、终端视图测量时就会命中 —— 抛
     * NetworkOnMainThreadException 且报文已编到一半，
     * 导致 sshj 内部 buffer 的 wpos 变负，之后每一次发送都
     * 抛 ArrayIndexOutOfBoundsException（index=-5 / dstPos=-4）。
     * 这就是"一次 resize 之后所有输入全部失败"的根因。
     */
    fun resizeShell(cols: Int, rows: Int) {
        if (broken) return
        postWrite {
            val c = cols.coerceIn(20, 500)
            val r = rows.coerceIn(5, 200)
            try {
                shell?.changeWindowDimensions(c, r, 0, 0)
                Log.i(TAG, "PTY 尺寸已同步 ${c}x${r}")
            } catch (e: Throwable) {
                Log.w(TAG, "同步 PTY 尺寸失败：${e.message}")
                markBroken(e)
            }
        }
    }

    /** 所有会发出网络报文的操作都必须经此串行执行，且不在主线程 */
    private fun postWrite(block: () -> Unit) {
        if (broken || writeExecutor.isShutdown) return
        try {
            writeExecutor.execute {
                try {
                    block()
                } catch (t: Throwable) {
                    Log.e(TAG, "写线程异常", t)
                    markBroken(t)
                }
            }
        } catch (_: Throwable) {
            // 线程池已关闭等，忽略
        }
    }

    /**
     * sshj 的 buffer 一旦出现负 wpos，这个连接就再也发不出数据了，
     * 只能重连。这里主动标记并提示，避免用户一直敲却永远失败。
     */
    private fun markBroken(e: Throwable) {
        broken = true
        lastError = "${e.javaClass.simpleName}: ${e.message}"
        Log.e(TAG, "SSH 通道已损坏，需要重连：$lastError")
        state = ConnState.CLOSED
        mainHandler.post {
            SessionRegistry.notifyChanged()
            onSendError?.let { runCatching { it.invoke("连接已损坏，请点右上角「重连」") } }
        }
    }

    fun startForward(rule: PortForwardRule) = PortForwards.start(this, rule)

    fun stopForward(rule: PortForwardRule) = PortForwards.stop(this, rule)

    private fun startReader() {
        val sh = shell ?: return
        readerThread = thread(start = true, name = "ssh-reader") {
            val buf = ByteArray(16 * 1024)
            var eof = false
            var got = 0L
            try {
                sh.inputStream.use { input ->
                    while (!Thread.currentThread().isInterrupted) {
                        val n = input.read(buf)
                        if (n < 0) {
                            eof = true
                            break
                        }
                        // 每次都重新取 emulator：Fragment 重建后它会被换成新实例，
                        // 若在线程开头就捕获，之后的输出全写进旧对象，屏幕不再更新。
                        val emu = emulator
                        if (emu == null) {
                            Log.w(TAG, "reader: emulator 为空，丢弃 ${n} 字节输出")
                        } else {
                            emu.write(buf, n)
                        }
                        got += n
                    }
                }
            } catch (e: Throwable) {
                // 主动中断（close()）属正常退出，不算错误
                if (Thread.currentThread().isInterrupted) {
                    Log.i(TAG, "reader 线程被中断，正常退出")
                    return@thread
                }
                Log.w(TAG, "reader 异常退出：${e.message ?: e::class.java.simpleName}")
            }
            // EOF = 服务器主动关闭了 shell；异常 = 连接层面出问题。
            // 两者都要让 UI 感知，但日志要区分开，便于定位。
            Log.i(TAG, "${if (eof) "服务器关闭了 shell（EOF）" else "reader 结束"}，累计收到 $got 字节")
            markClosed()
        }
    }

    private fun markClosed() {
        if (state != ConnState.CLOSED) {
            state = ConnState.CLOSED
            mainHandler.post { SessionRegistry.notifyChanged() }
        }
    }

    fun close() {
        state = ConnState.CLOSED
        readerThread?.interrupt()
        readerThread = null
        runCatching { writeExecutor.shutdownNow() }
        onSendError = null
        runCatching { sftp?.close() }
        runCatching { shell?.close() }
        runCatching { session?.close() }
        runCatching { ssh?.disconnect() }
        sftp = null
        shell = null
        session = null
        ssh = null
    }
}

object SessionRegistry {

    private val sessions = HashMap<String, LiveSession>()
    private val listeners = ArrayList<() -> Unit>()

    fun get(hostId: String): LiveSession? = synchronized(sessions) { sessions[hostId] }

    fun getOrCreate(host: HostConfig): LiveSession = synchronized(sessions) {
        sessions[host.id] ?: LiveSession(host).also { sessions[host.id] = it }
    }

    fun close(hostId: String) {
        val s = synchronized(sessions) { sessions.remove(hostId) }
        s?.close()
        notifyChanged()
    }

    fun closeAll() {
        val all = synchronized(sessions) { sessions.values.toList().also { sessions.clear() } }
        all.forEach { it.close() }
    }

    /**
     * 后台连接；结果通过 onDone 回到主线程。
     */
    fun connect(
        host: HostConfig,
        password: String?,
        keyPassphrase: String?,
        onDone: (LiveSession) -> Unit
    ) {
        val live = getOrCreate(host)
        live.state = ConnState.CONNECTING
        live.error = null
        thread(start = true, name = "ssh-connect") {
            try {
                val ssh = SshConnector.connect(host, password, keyPassphrase)
                ssh.connection.keepAlive.setKeepAliveInterval(AppPrefs.keepAliveSec)
                live.ssh = ssh
                live.state = ConnState.CONNECTED
            } catch (e: Throwable) {
                live.state = ConnState.FAILED
                live.error = e.message ?: "连接失败"
                runCatching { live.ssh?.close() }
            }
            Handler(Looper.getMainLooper()).post {
                notifyChanged()
                onDone(live)
            }
        }
    }

    /** 主机配置的远程起始目录；未配置时用 canonicalize(".") 得到家目录 */
    fun hostStartDir(hostId: String): String {
        val live = get(hostId) ?: return "/"
        if (live.host.startDir.isNotBlank()) return live.host.startDir.trimEnd('/').ifEmpty { "/" }
        if (live.isAlive) {
            return try {
                RemoteFs.canonical(live, ".")
            } catch (_: Throwable) {
                "/"
            }
        }
        return "/"
    }

    fun addListener(l: () -> Unit) {
        synchronized(listeners) { listeners.add(l) }
    }

    fun removeListener(l: () -> Unit) {
        synchronized(listeners) { listeners.remove(l) }
    }

    fun notifyChanged() {
        Handler(Looper.getMainLooper()).post {
            val snapshot = synchronized(listeners) { listeners.toList() }
            snapshot.forEach { runCatching { it.invoke() } }
        }
    }
}
