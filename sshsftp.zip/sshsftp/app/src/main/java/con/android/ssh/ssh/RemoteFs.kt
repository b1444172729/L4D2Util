package con.android.ssh.ssh

import con.android.ssh.data.AppPrefs
import net.schmizz.sshj.sftp.FileMode
import net.schmizz.sshj.sftp.OpenMode
import net.schmizz.sshj.sftp.RemoteResourceInfo
import java.io.IOException
import java.util.EnumSet

/**
 * 远程（SFTP）文件系统操作。
 */
object RemoteFs {

    private fun toItem(rri: RemoteResourceInfo): FileItem {
        val a = rri.attributes
        return FileItem(
            name = rri.name,
            path = rri.path,
            isDir = rri.isDirectory,
            size = a.size,
            mtime = a.mtime * 1000L,
            perms = a.mode.permissionsMask,
            owner = "${a.uid}:${a.gid}",
            isLink = a.type == FileMode.Type.SYMLINK
        )
    }

    fun list(live: LiveSession, path: String, showHidden: Boolean = AppPrefs.showHidden): List<FileItem> {
        val items = live.withSftp { sftp ->
            sftp.ls(path).mapNotNull { rri ->
                val name = rri.name
                if (name == "." || name == "..") return@mapNotNull null
                if (!showHidden && name.startsWith(".")) return@mapNotNull null
                toItem(rri)
            }
        }.toMutableList()
        sortItems(items, "name")
        return items
    }

    /** 解析出真实绝对路径（用于进入目录后显示） */
    fun canonical(live: LiveSession, path: String): String = try {
        live.withSftp { it.canonicalize(path) }
    } catch (_: Throwable) {
        path
    }

    fun mkdir(live: LiveSession, path: String) {
        live.withSftp { it.mkdir(path) }
    }

    fun createFile(live: LiveSession, path: String) {
        live.withSftp { sftp ->
            sftp.open(path, EnumSet.of(OpenMode.WRITE, OpenMode.CREAT)).close()
        }
    }

    fun rename(live: LiveSession, from: String, to: String) {
        live.withSftp { it.rename(from, to) }
    }

    fun chmod(live: LiveSession, path: String, perms: Int) {
        live.withSftp { it.chmod(path, perms) }
    }

    /** 删除文件、空目录或递归删除整个目录 */
    fun delete(live: LiveSession, item: FileItem) {
        live.withSftp { sftp ->
            if (item.isDir) deleteDirRecursive(sftp, item.path) else sftp.rm(item.path)
        }
    }

    private fun deleteDirRecursive(sftp: net.schmizz.sshj.sftp.SFTPClient, path: String) {
        val children = try {
            sftp.ls(path)
        } catch (_: Throwable) {
            emptyList()
        }
        for (c in children) {
            val n = c.name
            if (n == "." || n == "..") continue
            if (c.isDirectory) deleteDirRecursive(sftp, c.path) else sftp.rm(c.path)
        }
        sftp.rmdir(path)
    }

    /** 读取文本文件内容（用于内置编辑器） */
    fun readText(live: LiveSession, path: String, maxBytes: Int = 1024 * 1024): String {
        return live.withSftp { sftp ->
            val rf = sftp.open(path)
            try {
                val size = rf.length()
                if (size > maxBytes) throw IOException("文件过大：${formatSize(size)}")
                val input = rf.ReadAheadRemoteFileInputStream(16, 0)
                input.readBytes().toString(Charsets.UTF_8)
            } finally {
                runCatching { rf.close() }
            }
        }
    }

    fun writeText(live: LiveSession, path: String, text: String) {
        live.withSftp { sftp ->
            val rf = sftp.open(path, EnumSet.of(OpenMode.WRITE, OpenMode.CREAT, OpenMode.TRUNC))
            try {
                val os = rf.RemoteFileOutputStream(0, 16)
                os.write(text.toByteArray(Charsets.UTF_8))
                os.flush()
            } finally {
                runCatching { rf.close() }
            }
        }
    }

    /**
     * 递归列出目录下的所有文件（供下载整个目录使用）。
     * 返回相对根目录的路径列表。
     */
    fun listFilesRecursive(live: LiveSession, dir: String, includeHidden: Boolean): List<Pair<String, Long>> {
        val out = ArrayList<Pair<String, Long>>()
        fun walk(path: String, rel: String) {
            val children = live.withSftp { sftp -> sftp.ls(path) }
            for (c in children) {
                val n = c.name
                if (n == "." || n == "..") continue
                if (!includeHidden && n.startsWith(".")) continue
                val childRel = if (rel.isEmpty()) n else "$rel/$n"
                if (c.isDirectory) walk(c.path, childRel)
                else out.add(childRel to c.attributes.size)
            }
        }
        walk(dir, "")
        return out
    }

    /** 同一台主机内的复制 / 移动 */
    fun copyOrMove(live: LiveSession, from: String, to: String, move: Boolean) {
        live.withSftp { sftp ->
            if (move) {
                sftp.rename(from, to)
            } else {
                copyRemote(live, sftp, from, to)
            }
        }
    }

    private fun copyRemote(live: LiveSession, sftp: net.schmizz.sshj.sftp.SFTPClient, from: String, to: String) {
        val attrs = sftp.stat(from)
        if (attrs.type == FileMode.Type.DIRECTORY) {
            runCatching { sftp.mkdir(to) }
            val children = sftp.ls(from)
            for (c in children) {
                val n = c.name
                if (n == "." || n == "..") continue
                copyRemote(live, sftp, joinPath(from, n), joinPath(to, n))
            }
        } else {
            val src = sftp.open(from)
            try {
                val dst = sftp.open(to, EnumSet.of(OpenMode.WRITE, OpenMode.CREAT, OpenMode.TRUNC))
                try {
                    val input = src.ReadAheadRemoteFileInputStream(16, 0)
                    val output = dst.RemoteFileOutputStream(0, 16)
                    val buf = ByteArray(32 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n <= 0) break
                        output.write(buf, 0, n)
                    }
                    output.flush()
                    output.close()
                } finally {
                    runCatching { dst.close() }
                }
            } finally {
                runCatching { src.close() }
            }
        }
    }

    fun exists(live: LiveSession, path: String): Boolean = try {
        live.withSftp { it.stat(path) }
        true
    } catch (_: Throwable) {
        false
    }

    fun sizeOf(live: LiveSession, path: String): Long = try {
        live.withSftp { it.size(path) }
    } catch (_: Throwable) {
        0
    }
}
