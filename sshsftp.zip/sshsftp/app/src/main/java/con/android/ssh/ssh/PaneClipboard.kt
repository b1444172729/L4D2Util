package con.android.ssh.ssh

/**
 * 文件面板之间的"复制 / 剪切"剪贴板（会话内共享）。
 */
object PaneClipboard {

    private val entries = ArrayList<ClipboardEntry>()

    @Volatile
    var cut: Boolean = false

    fun set(list: List<ClipboardEntry>, isCut: Boolean) {
        synchronized(entries) {
            entries.clear()
            entries.addAll(list)
            cut = isCut
        }
    }

    fun all(): List<ClipboardEntry> = synchronized(entries) { entries.toList() }

    fun isEmpty(): Boolean = synchronized(entries) { entries.isEmpty() }

    fun clear() {
        synchronized(entries) { entries.clear() }
        cut = false
    }
}
