package con.android.ssh.data

import androidx.annotation.StringRes
import con.android.ssh.R

/**
 * 底部按键栏的定义与顺序。
 *
 * 按键顺序可由用户在「设置 → 按键栏顺序」里拖动调整，
 * 存为逗号分隔的 id 列表。这里负责：
 *  - 维护全部按键的定义（id / 文案 / 要发送的序列）
 *  - 读取顺序并对"新增/失效"的按键做补齐与剔除，保证永远合法
 */
object KeyBar {

    data class KeyDef(
        /** 唯一 id，也是 SharedPreferences 里存的标识 */
        val id: String,
        /** 要发给远端的序列；为 null 表示不是"发送类"按键（Ctrl/Alt、复制、粘贴、清屏） */
        val seq: String? = null,
        @StringRes val labelRes: Int = 0,
        /** 当没有对应字符串资源时使用的字面文案（如 "." "/"） */
        val literal: String = ""
    ) {
        fun label(ctx: android.content.Context): String =
            if (labelRes != 0) ctx.getString(labelRes) else literal
    }

    /** 全部按键。新增按键只需加到这里，老用户的顺序会自动补上。 */
    val ALL: List<KeyDef> = listOf(
        KeyDef("esc", "\u001B", R.string.key_esc),
        KeyDef("ctrl", null, R.string.key_ctrl),
        KeyDef("alt", null, R.string.key_alt),
        KeyDef("tab", "\t", R.string.key_tab),
        KeyDef("up", "\u001B[A", R.string.key_up),
        KeyDef("down", "\u001B[B", R.string.key_down),
        KeyDef("left", "\u001B[D", R.string.key_left),
        KeyDef("right", "\u001B[C", R.string.key_right),
        KeyDef("home", "\u001B[H", R.string.key_home),
        KeyDef("end", "\u001B[F", R.string.key_end),
        KeyDef("pgup", "\u001B[5~", R.string.key_pgup),
        KeyDef("pgdn", "\u001B[6~", R.string.key_pgdn),
        KeyDef("del", "\u001B[3~", R.string.key_del),
        // 命令行最常用的两个字符，直接给独立按键
        KeyDef("dot", ".", literal = "."),
        KeyDef("slash", "/", literal = "/"),
        KeyDef("copy", null, R.string.copy),
        KeyDef("paste", null, R.string.paste),
        KeyDef("enter", "\r", R.string.key_enter),
        KeyDef("clear", null, R.string.clear_screen)
    )

    private val BY_ID = ALL.associateBy { it.id }

    fun defaultOrder(): List<String> = ALL.map { it.id }

    fun def(id: String): KeyDef? = BY_ID[id]

    /**
     * 当前生效的顺序。
     * 已保存的列表里若缺新按键（比如这次新增的 . 和 /）则追加到末尾，
     * 已失效的 id 直接剔除，保证返回的列表始终与 ALL 一一对应。
     */
    fun order(): List<String> {
        val saved = AppPrefs.keyBarOrder
            .split(',')
            .map { it.trim() }
            .filter { it.isNotEmpty() && BY_ID.containsKey(it) }
            .distinct()
        val missing = ALL.map { it.id }.filter { it !in saved }
        return saved + missing
    }

    fun saveOrder(ids: List<String>) {
        AppPrefs.keyBarOrder = ids.filter { BY_ID.containsKey(it) }.distinct().joinToString(",")
    }

    fun resetOrder() {
        AppPrefs.keyBarOrder = ""
    }
}
