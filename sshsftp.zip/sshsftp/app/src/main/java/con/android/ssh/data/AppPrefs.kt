package con.android.ssh.data

import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatDelegate
import androidx.preference.PreferenceManager

/**
 * 全局设置。所有设置项与 res/xml/preferences.xml 中的 key 一一对应。
 */
object AppPrefs {

    private lateinit var sp: SharedPreferences

    /** 配置变化监听：参数是被改动的 key */
    private val listeners = mutableListOf<(String) -> Unit>()

    /**
     * 必须持有强引用 —— SharedPreferences 对监听器是弱引用，
     * 只传匿名对象会在 GC 后被静默注销。
     */
    private val spListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == null) return@OnSharedPreferenceChangeListener
        listeners.toList().forEach { runCatching { it(key) } }
    }

    fun init(context: Context) {
        sp = PreferenceManager.getDefaultSharedPreferences(context.applicationContext)
        sp.registerOnSharedPreferenceChangeListener(spListener)
    }

    /**
     * 订阅配置变化，返回用于取消订阅的函数。
     * 这样设置页一改动，正在显示的界面就能立刻跟着变，不必重启应用。
     */
    @Synchronized
    fun listen(block: (String) -> Unit): () -> Unit {
        listeners.add(block)
        return { listeners.remove(block) }
    }

    // ------------------------------------------------------------------
    // 类型兼容
    //
    // 关键：AndroidX Preference 在"首次显示设置页"时会把每个 Preference 的
    // 默认值写进 SharedPreferences（dispatchSetInitialValue → persistXxx）。
    // 也就是说，只要打开过一次设置，这些 key 就有了值。
    //
    // 而 preferences.xml 里：
    //   scrollback / keepalive 是 EditTextPreference → 以【字符串】持久化
    //   font_size 是 SeekBarPreference            → 以【整型】持久化
    //
    // 之前 getter 一律用 sp.getInt()，一旦设置页把 "3000" 写成字符串，
    // 之后每次 sp.getInt("scrollback") 都抛 ClassCastException ——
    // 表现为"只要进过设置，连接就闪退，且重启无效（数据在，除非卸载清数据）"。
    // ------------------------------------------------------------------

    /** preferences.xml 中声明为 EditTextPreference 的数值项，必须以字符串写回 */
    private val stringNumericKeys = setOf("scrollback", "keepalive")

    /** 读数值：整型 / 字符串 两种存储都能正确读出 */
    private fun readInt(key: String, def: Int, min: Int, max: Int): Int {
        val v = try {
            sp.getInt(key, def)
        } catch (_: ClassCastException) {
            val s = try {
                sp.getString(key, null)
            } catch (_: ClassCastException) {
                null
            }
            s?.trim()?.toIntOrNull() ?: def
        }
        return v.coerceIn(min, max)
    }

    /**
     * 写数值：按 preferences.xml 的控件类型选择存储类型，
     * 否则 EditTextPreference 再次读取时会因类型不符而崩溃。
     */
    private fun writeInt(key: String, value: Int) {
        val e = sp.edit()
        if (key in stringNumericKeys) e.putString(key, value.toString())
        else e.putInt(key, value)
        e.apply()
    }

    /** 读字符串：即便历史上被写成别的类型也不会抛异常 */
    private fun readString(key: String, def: String): String =
        try {
            sp.getString(key, def) ?: def
        } catch (_: ClassCastException) {
            def
        }

    /** 读布尔：同上 */
    private fun readBool(key: String, def: Boolean): Boolean =
        try {
            sp.getBoolean(key, def)
        } catch (_: ClassCastException) {
            def
        }

    /** 终端字号（sp），双指缩放也写回这里 */
    var fontSizeSp: Int
        get() = readInt("font_size", 13, 8, 28)
        set(value) = writeInt("font_size", value.coerceIn(8, 28))

    /** 回滚缓冲区行数 */
    var scrollback: Int
        get() = readInt("scrollback", 3000, 200, 20000)
        set(value) = writeInt("scrollback", value.coerceIn(200, 20000))

    /** TERM 环境变量 */
    var termType: String
        get() = readString("term_type", "xterm-256color")
        set(value) = sp.edit().putString("term_type", value).apply()

    /** SSH 保活间隔（秒） */
    var keepAliveSec: Int
        get() = readInt("keepalive", 30, 5, 600)
        set(value) = writeInt("keepalive", value.coerceIn(5, 600))

    /** 快捷命令，一行一条 */
    var shortcuts: List<String>
        get() {
            val raw = readString("shortcuts", "")
            return raw.lineSequence().map { it.trim() }.filter { it.isNotEmpty() }.toList()
        }
        set(value) = sp.edit().putString("shortcuts", value.joinToString("\n")).apply()

    var showKeyBar: Boolean
        get() = readBool("keybar", true)
        set(value) = sp.edit().putBoolean("keybar", value).apply()

    var bellVibrate: Boolean
        get() = readBool("bell", false)
        set(value) = sp.edit().putBoolean("bell", value).apply()

    var showHidden: Boolean
        get() = readBool("show_hidden", false)
        set(value) = sp.edit().putBoolean("show_hidden", value).apply()

    var localRoot: String
        get() = readString("local_root", "/sdcard")
        set(value) = sp.edit().putString("local_root", value).apply()

    /** 传输冲突策略：ask / overwrite / skip / resume */
    var conflictPolicy: String
        get() = readString("conflict", "ask")
        set(value) = sp.edit().putString("conflict", value).apply()

    var compression: Boolean
        get() = readBool("compression", false)
        set(value) = sp.edit().putBoolean("compression", value).apply()

    /**
     * 底部按键栏顺序，逗号分隔的 id 列表。
     * 空串表示未自定义，使用 KeyBar 的默认顺序。
     */
    var keyBarOrder: String
        get() = readString("keybar_order", "")
        set(value) = sp.edit().putString("keybar_order", value).apply()

    /** 主题原始值：dark / light / system */
    val themeRaw: String
        get() = readString("theme", "dark")

    val nightMode: Int
        get() = nightModeOf(themeRaw)

    /**
     * 由主题原始值得到 AppCompat 模式。
     * 单独抽出是因为：Preference 的 OnPreferenceChangeListener
     * 在"值还没写入 SharedPreferences 之前"就回调了，
     * 此时直接读 themeRaw 拿到的还是旧值，必须用回调传入的 newValue。
     */
    fun nightModeOf(raw: String): Int = when (raw) {
        "light" -> AppCompatDelegate.MODE_NIGHT_NO
        "system" -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
        else -> AppCompatDelegate.MODE_NIGHT_YES
    }
}
