package con.android.ssh.data

import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatDelegate
import androidx.preference.PreferenceManager

/**
 * 全局设置。所有设置项与 res/xml/preferences.xml 中的 key 一一对应。
 */
object AppPrefs {

    private lateinit var sp: SharedPreferences

    fun init(context: Context) {
        sp = PreferenceManager.getDefaultSharedPreferences(context.applicationContext)
    }

    /** 终端字号（sp），双指缩放也写回这里 */
    var fontSizeSp: Int
        get() = sp.getInt("font_size", 13).coerceIn(8, 28)
        set(value) = sp.edit().putInt("font_size", value.coerceIn(8, 28)).apply()

    /** 回滚缓冲区行数 */
    var scrollback: Int
        get() = sp.getInt("scrollback", 3000).coerceIn(200, 20000)
        set(value) = sp.edit().putInt("scrollback", value.coerceIn(200, 20000)).apply()

    /** TERM 环境变量 */
    var termType: String
        get() = sp.getString("term_type", "xterm-256color") ?: "xterm-256color"
        set(value) = sp.edit().putString("term_type", value).apply()

    /** SSH 保活间隔（秒） */
    var keepAliveSec: Int
        get() = sp.getInt("keepalive", 30).coerceIn(5, 600)
        set(value) = sp.edit().putInt("keepalive", value.coerceIn(5, 600)).apply()

    /** 快捷命令，一行一条 */
    var shortcuts: List<String>
        get() {
            val raw = sp.getString("shortcuts", "") ?: ""
            return raw.lineSequence().map { it.trim() }.filter { it.isNotEmpty() }.toList()
        }
        set(value) = sp.edit().putString("shortcuts", value.joinToString("\n")).apply()

    var showKeyBar: Boolean
        get() = sp.getBoolean("keybar", true)
        set(value) = sp.edit().putBoolean("keybar", value).apply()

    var bellVibrate: Boolean
        get() = sp.getBoolean("bell", false)
        set(value) = sp.edit().putBoolean("bell", value).apply()

    var showHidden: Boolean
        get() = sp.getBoolean("show_hidden", false)
        set(value) = sp.edit().putBoolean("show_hidden", value).apply()

    var localRoot: String
        get() = sp.getString("local_root", "/sdcard") ?: "/sdcard"
        set(value) = sp.edit().putString("local_root", value).apply()

    /** 传输冲突策略：ask / overwrite / skip / resume */
    var conflictPolicy: String
        get() = sp.getString("conflict", "ask") ?: "ask"
        set(value) = sp.edit().putString("conflict", value).apply()

    var compression: Boolean
        get() = sp.getBoolean("compression", false)
        set(value) = sp.edit().putBoolean("compression", value).apply()

    val nightMode: Int
        get() = when (sp.getString("theme", "dark")) {
            "light" -> AppCompatDelegate.MODE_NIGHT_NO
            "system" -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
            else -> AppCompatDelegate.MODE_NIGHT_YES
        }
}
