package con.android.ssh.data

import android.content.Context
import org.json.JSONArray

/**
 * 主机列表 + 主机密钥指纹的持久化。
 */
object HostStore {

    private const val FILE = "hosts"
    private const val KEY_HOSTS = "hosts_json"

    private lateinit var sp: android.content.SharedPreferences
    private val hosts = ArrayList<HostConfig>()

    fun init(context: Context) {
        SecureStore.init(context)
        sp = context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        load()
    }

    private fun load() {
        hosts.clear()
        val raw = sp.getString(KEY_HOSTS, null) ?: return
        runCatching {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) hosts.add(HostConfig.fromJson(arr.getJSONObject(i)))
        }
    }

    private fun persist() {
        val arr = JSONArray()
        hosts.forEach { arr.put(it.toJson()) }
        sp.edit().putString(KEY_HOSTS, arr.toString()).apply()
    }

    fun all(): List<HostConfig> = hosts.toList()

    fun get(id: String): HostConfig? = hosts.find { it.id == id }

    fun save(h: HostConfig) {
        val idx = hosts.indexOfFirst { it.id == h.id }
        if (idx >= 0) hosts[idx] = h else hosts.add(h)
        persist()
    }

    fun delete(id: String) {
        hosts.removeAll { it.id == id }
        persist()
        SecureStore.remove(pwKey(id))
        SecureStore.remove(keyPassKey(id))
    }

    // ---------- 凭据 ----------

    private fun pwKey(id: String) = "pw_$id"
    private fun keyPassKey(id: String) = "kp_$id"

    fun password(id: String): String? = SecureStore.get(pwKey(id))

    fun setPassword(id: String, value: String?) {
        if (value.isNullOrEmpty()) SecureStore.remove(pwKey(id)) else SecureStore.put(pwKey(id), value)
    }

    fun keyPassphrase(id: String): String? = SecureStore.get(keyPassKey(id))

    fun setKeyPassphrase(id: String, value: String?) {
        if (value.isNullOrEmpty()) SecureStore.remove(keyPassKey(id)) else SecureStore.put(keyPassKey(id), value)
    }

    // ---------- 主机密钥 ----------

    private fun hostKeyKey(host: String, port: Int) = "kh_${host}_$port"

    fun knownFingerprint(host: String, port: Int): String? = sp.getString(hostKeyKey(host, port), null)

    fun trustFingerprint(host: String, port: Int, fingerprint: String) {
        sp.edit().putString(hostKeyKey(host, port), fingerprint).apply()
    }

    fun clearKnownHosts(): Int {
        var count = 0
        val edit = sp.edit()
        sp.all.keys.filter { it.startsWith("kh_") }.forEach { edit.remove(it); count++ }
        edit.apply()
        return count
    }
}
