package con.android.ssh.ssh

import android.os.Handler
import android.os.Looper
import java.io.File
import java.util.UUID

object TransferState {
    const val WAIT = 0
    const val RUNNING = 1
    const val PAUSED = 2
    const val DONE = 3
    const val FAILED = 4
    const val CANCELLED = 5
}

/** 冲突解决方式 */
enum class ConflictAction { OVERWRITE, SKIP, RESUME }

data class TransferTask(
    val id: String = UUID.randomUUID().toString(),
    val hostId: String = "",
    val upload: Boolean = false,
    /** 远端文件完整路径 */
    val remotePath: String = "",
    /** 本地文件完整路径 */
    val localPath: String = "",
    /** 展示名（相对名） */
    val displayName: String = "",
    val size: Long = 0,
    var resumeOffset: Long = 0,
    @Volatile var transferred: Long = 0,
    @Volatile var state: Int = TransferState.WAIT,
    @Volatile var error: String? = null,
    @Volatile var speedBps: Long = 0
) {
    val progressPercent: Int
        get() = if (size <= 0) 0 else ((transferred * 100) / size).toInt().coerceIn(0, 100)
}

object TransferManager {

    private val tasks = ArrayList<TransferTask>()
    private val listeners = ArrayList<() -> Unit>()
    private val mainHandler = Handler(Looper.getMainLooper())

    fun all(): List<TransferTask> = synchronized(tasks) { tasks.toList() }

    fun get(id: String): TransferTask? = synchronized(tasks) { tasks.find { it.id == id } }

    fun add(newTasks: List<TransferTask>) {
        synchronized(tasks) { tasks.addAll(newTasks) }
        notifyChanged()
    }

    fun nextPending(): TransferTask? =
        synchronized(tasks) { tasks.firstOrNull { it.state == TransferState.WAIT } }

    fun countActive(): Int =
        synchronized(tasks) { tasks.count { it.state == TransferState.WAIT || it.state == TransferState.RUNNING } }

    fun cancel(id: String) {
        synchronized(tasks) { tasks.find { it.id == id } }?.let {
            if (it.state == TransferState.RUNNING || it.state == TransferState.WAIT || it.state == TransferState.PAUSED) {
                it.state = TransferState.CANCELLED
            }
        }
        notifyChanged()
    }

    fun pause(id: String) {
        synchronized(tasks) { tasks.find { it.id == id } }?.let {
            if (it.state == TransferState.RUNNING || it.state == TransferState.WAIT) it.state = TransferState.PAUSED
        }
        notifyChanged()
    }

    fun resume(id: String) {
        synchronized(tasks) { tasks.find { it.id == id } }?.let {
            if (it.state == TransferState.PAUSED || it.state == TransferState.FAILED || it.state == TransferState.CANCELLED) {
                it.state = TransferState.WAIT
                it.error = null
            }
        }
        notifyChanged()
    }

    fun retry(id: String) {
        synchronized(tasks) { tasks.find { it.id == id } }?.let {
            it.state = TransferState.WAIT
            it.error = null
            it.transferred = 0
        }
        notifyChanged()
    }

    fun clearFinished() {
        synchronized(tasks) {
            tasks.removeAll { it.state == TransferState.DONE || it.state == TransferState.CANCELLED }
        }
        notifyChanged()
    }

    fun addListener(l: () -> Unit) {
        synchronized(listeners) { listeners.add(l) }
    }

    fun removeListener(l: () -> Unit) {
        synchronized(listeners) { listeners.remove(l) }
    }

    fun notifyChanged() {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            dispatch()
        } else {
            mainHandler.post { dispatch() }
        }
    }

    fun notifyChangedAsync() {
        mainHandler.post { dispatch() }
    }

    private fun dispatch() {
        val snapshot = synchronized(listeners) { listeners.toList() }
        snapshot.forEach { runCatching { it.invoke() } }
    }
}

/** 待粘贴/待传输的剪贴板条目 */
data class ClipboardEntry(
    val path: String,
    val name: String,
    val isDir: Boolean,
    val cut: Boolean,
    /** 本地还是远程 */
    val remote: Boolean
)

/** 计算目标文件的最终路径（避免目录内重名） */
fun uniqueTarget(dir: File, name: String): File {
    var f = File(dir, name)
    if (!f.exists()) return f
    val dot = name.lastIndexOf('.')
    val base = if (dot > 0) name.substring(0, dot) else name
    val ext = if (dot > 0) name.substring(dot) else ""
    var i = 1
    while (i < 999) {
        f = File(dir, "$base($i)$ext")
        if (!f.exists()) return f
        i++
    }
    return File(dir, "${System.currentTimeMillis()}$ext")
}
