package con.android.ssh.ui

import con.android.ssh.ssh.LiveSession

/**
 * 会话页向各子页面暴露的能力。
 */
interface SessionHost {
    fun liveSession(): LiveSession?
    /** 确保已连接；未连接时先发起连接，完成后回调（主线程） */
    fun ensureConnected(onDone: (LiveSession) -> Unit)
}
