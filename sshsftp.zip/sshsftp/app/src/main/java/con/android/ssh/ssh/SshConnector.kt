package con.android.ssh.ssh

import android.util.Base64
import con.android.ssh.data.HostConfig
import con.android.ssh.data.HostStore
import net.schmizz.sshj.SSHClient
import net.schmizz.sshj.common.Buffer
import net.schmizz.sshj.transport.verification.HostKeyVerifier
import net.schmizz.sshj.userauth.method.AuthKeyboardInteractive
import net.schmizz.sshj.userauth.method.AuthMethod
import net.schmizz.sshj.userauth.method.AuthPassword
import net.schmizz.sshj.userauth.method.AuthPublickey
import net.schmizz.sshj.userauth.method.PasswordResponseProvider
import net.schmizz.sshj.userauth.password.PasswordFinder
import net.schmizz.sshj.userauth.password.Resource
import java.io.IOException
import java.security.MessageDigest
import java.security.PublicKey

/** 主机密钥需要用户确认 */
data class TrustRequest(
    val host: String,
    val port: Int,
    val algorithm: String,
    val fingerprint: String,
    val changed: Boolean,
    val oldFingerprint: String?
)

class KeyLoadException(msg: String) : IOException(msg)

object SshConnector {

    /**
     * 主机密钥确认回调。在连接线程（非主线程）中同步调用，
     * UI 层应弹出对话框并用 CountDownLatch 阻塞等待用户选择。
     */
    @Volatile
    var trustPrompt: ((TrustRequest) -> Boolean)? = null

    /** 把底层异常翻成人能看懂的中文提示 */
    private fun readable(e: Throwable): String {
        val msg = e.message ?: ""
        return when {
            // 完整 BouncyCastle 未生效（Android 残版 BC 缺现代算法）
            msg.contains("no such algorithm", true) ->
                "算法不受支持（$msg）。这通常是内置加密库未生效导致，请重启应用后重试。"
            msg.contains("Unable to reach a settlement", true) ->
                "算法协商失败，服务器与客户端没有共同支持的算法。"
            msg.contains("timed out", true) || msg.contains("timeout", true) ->
                "连接超时，请检查网络与端口是否可达。"
            msg.contains("Connection refused", true) ->
                "连接被拒绝，请确认端口与 SSH 服务是否正常。"
            msg.contains("UnknownHost", true) || msg.contains("unknown host", true) ->
                "无法解析主机名，请检查地址拼写与网络。"
            msg.isBlank() -> "网络不可达"
            else -> msg
        }
    }

    /** 计算 SSH 标准格式的 SHA-256 指纹 */
    fun fingerprint(key: PublicKey): String {
        val blob = try {
            Buffer.PlainBuffer().putPublicKey(key).getCompactData()
        } catch (_: Throwable) {
            key.encoded ?: ByteArray(0)
        }
        val digest = MessageDigest.getInstance("SHA-256").digest(blob)
        return "SHA256:" + Base64.encodeToString(digest, Base64.NO_PADDING or Base64.NO_WRAP)
    }

    private class TrustVerifier(private val host: String, private val port: Int) : HostKeyVerifier {

        override fun verify(hostname: String, port: Int, key: PublicKey): Boolean {
            val fp = fingerprint(key)
            val known = HostStore.knownFingerprint(host, this.port)
            if (known == null) {
                val req = TrustRequest(hostname, port, key.algorithm ?: "unknown", fp, false, null)
                return trustPrompt?.invoke(req) ?: false
            }
            if (known != fp) {
                val req = TrustRequest(hostname, port, key.algorithm ?: "unknown", fp, true, known)
                return trustPrompt?.invoke(req) ?: false
            }
            return true
        }

        override fun findExistingAlgorithms(hostname: String, port: Int): MutableList<String> = mutableListOf()
    }

    /**
     * 建立连接并完成认证。
     * @param password 密码（密码认证 / 键盘交互认证使用）
     * @param keyPassphrase 私钥口令
     */
    @Throws(IOException::class)
    fun connect(host: HostConfig, password: String?, keyPassphrase: String?): SSHClient {
        if (host.user.isBlank()) throw IOException("用户名为空")

        val ssh = SSHClient()
        ssh.addHostKeyVerifier(TrustVerifier(host.host, host.port))
        ssh.setConnectTimeout(15_000)
        ssh.setTimeout(30_000)
        if (con.android.ssh.data.AppPrefs.compression) ssh.useCompression()

        // sshj 在协商失败时抛的是 SSHRuntimeException（RuntimeException），
        // 不是 IOException，只 catch IOException 会让它穿透出去。
        try {
            ssh.connect(host.host, host.port)
        } catch (e: Throwable) {
            runCatching { ssh.close() }
            throw IOException("无法连接到 ${host.host}:${host.port}：${readable(e)}", e)
        }

        val methods = ArrayList<AuthMethod>()
        if (host.authType == "key") {
            val path = host.keyPath.trim()
            if (path.isEmpty()) throw IOException("未选择私钥文件")
            val provider = try {
                if (keyPassphrase.isNullOrEmpty()) ssh.loadKeys(path) else ssh.loadKeys(path, keyPassphrase)
            } catch (e: Exception) {
                val hint = if (e.message?.contains("BouncyCastle", true) == true ||
                    e.cause?.toString()?.contains("bouncycastle", true) == true
                ) "该文件可能是受密码保护的 OpenSSH 新格式私钥，请改用 PEM/PKCS#8 格式"
                else e.message ?: "私钥解析失败"
                throw KeyLoadException(hint)
            }
            methods.add(AuthPublickey(provider))
        }
        if (!password.isNullOrEmpty()) {
            val finder = object : PasswordFinder {
                override fun reqPassword(resource: Resource<*>?): CharArray = password.toCharArray()
                override fun shouldRetry(resource: Resource<*>?): Boolean = false
            }
            methods.add(AuthPassword(finder))
            methods.add(AuthKeyboardInteractive(PasswordResponseProvider(finder)))
        }
        if (methods.isEmpty()) throw IOException("没有可用的认证方式")

        try {
            ssh.auth(host.user, methods)
        } catch (e: Exception) {
            ssh.close()
            throw IOException("认证失败：${e.message ?: "用户名或凭据不正确"}", e)
        }
        if (!ssh.isAuthenticated) {
            ssh.close()
            throw IOException("认证失败：服务器拒绝了所有认证方式")
        }
        return ssh
    }
}
