package con.android.ssh.ui

import android.content.Context
import android.os.Bundle
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.HorizontalScrollView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import com.google.android.material.button.MaterialButton
import con.android.ssh.R
import con.android.ssh.data.AppPrefs
import con.android.ssh.ssh.LiveSession
import con.android.ssh.term.TerminalEmulator
import con.android.ssh.term.TerminalView
import con.android.ssh.util.toast

class TerminalFragment : Fragment(R.layout.fragment_terminal) {

    companion object {
        private const val ARG_HOST_ID = "host_id"

        fun new(hostId: String) = TerminalFragment().apply {
            arguments = Bundle().apply { putString(ARG_HOST_ID, hostId) }
        }
    }

    private val hostId: String by lazy { requireArguments().getString(ARG_HOST_ID)!! }

    private lateinit var terminal: TerminalView
    private lateinit var progress: ProgressBar
    private lateinit var hint: TextView
    private lateinit var keyBar: HorizontalScrollView

    private var emulator: TerminalEmulator? = null
    private var shellStarted = false

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        terminal = view.findViewById(R.id.terminal)
        progress = view.findViewById(R.id.progress)
        hint = view.findViewById(R.id.hint)
        keyBar = view.findViewById(R.id.keyBar)

        keyBar.isVisible = AppPrefs.showKeyBar

        val emu = TerminalEmulator(80, 24, AppPrefs.scrollback)
        emulator = emu
        terminal.emulator = emu

        // 发送是异步的，结果通过 onSendError 回来（写线程里执行，不阻塞主线程）
        terminal.onInput = { data ->
            val live = session()
            when {
                live == null -> warnSend("尚未连接")
                live.shell == null -> warnSend("Shell 未启动，请点右上角重连")
                else -> {
                    live.onSendError = { msg -> warnSend("发送失败：$msg") }
                    live.send(data)
                }
            }
        }
        terminal.onSizeChanged = { cols, rows ->
            val live = session()
            if (live != null && shellStarted) {
                live.resizeShell(cols, rows)
            }
        }

        bindKeys(view)

        terminal.post {
            if (isResumed) {
                terminal.requestFocus()
                if (!TerminalView.hasHardwareKeyboard(requireContext())) {
                    terminal.showKeyboard(true)
                }
            }
        }

        (activity as? SessionHost)?.ensureConnected { live ->
            onConnected(live)
        }
        refreshState()
    }

    private fun session(): LiveSession? = (activity as? SessionHost)?.liveSession()

    /** 输入失败时提示。做节流，避免每个按键都弹 toast 刷屏。 */
    private var lastWarnAt = 0L
    private fun warnSend(msg: String) {
        val now = android.os.SystemClock.elapsedRealtime()
        if (now - lastWarnAt < 3000) return
        lastWarnAt = now
        android.util.Log.w("终端模拟器", "输入未能送达: $msg")
        if (isAdded) toast(msg)
    }

    private fun onConnected(live: LiveSession) {
        if (!isAdded) return
        refreshState(live)
        if (live.state != con.android.ssh.ssh.ConnState.CONNECTED) return
        if (shellStarted) return
        val (cols, rows) = terminal.termSize()
        val emu = emulator ?: return
        // 必须无条件重新绑定：Fragment 重建后（切 tab、从设置页返回）会生成新的
        // TerminalEmulator，而 live.emulator 还指向上一个已失效的实例。
        // 之前写成「仅在为 null 时赋值」，重建后就再也不会指向新的，
        // 于是远端回显全写进了旧对象 —— 屏幕上看不到任何新内容。
        live.emulator = emu
        android.util.Log.d("终端模拟器", "终端缓冲已绑定: ${emu.cols}x${emu.rows}")
        progress.isVisible = true
        kotlin.concurrent.thread(name = "start-shell") {
            // startShell 现在返回错误原因（null = 成功），直接显示给用户，
            // 不再笼统提示"会话已关闭"，否则根本无法定位问题。
            val err = live.startShell(cols, rows)
            activity?.runOnUiThread {
                shellStarted = (err == null)
                progress.isVisible = false
                if (err != null) {
                    hint.isVisible = true
                    hint.text = err
                    android.util.Log.e("终端模拟器", "shell 启动失败: $err")
                } else {
                    hint.isVisible = false
                    terminal.requestFocus()
                }
            }
        }
    }

    fun refreshState(live: LiveSession? = session()) {
        if (!isAdded) return
        if (live == null || live.state != con.android.ssh.ssh.ConnState.CONNECTED) {
            progress.isVisible = true
        } else {
            progress.isVisible = !shellStarted
        }
    }

    private fun bindKeys(view: View) {
        view.findViewById<MaterialButton>(R.id.keyEsc).setOnClickListener { terminal.sendSpecial("\u001B") }
        view.findViewById<MaterialButton>(R.id.keyTab).setOnClickListener { terminal.sendSpecial("\t") }
        view.findViewById<MaterialButton>(R.id.keyUp).setOnClickListener { terminal.sendSpecial("\u001B[A") }
        view.findViewById<MaterialButton>(R.id.keyDown).setOnClickListener { terminal.sendSpecial("\u001B[B") }
        view.findViewById<MaterialButton>(R.id.keyLeft).setOnClickListener { terminal.sendSpecial("\u001B[D") }
        view.findViewById<MaterialButton>(R.id.keyRight).setOnClickListener { terminal.sendSpecial("\u001B[C") }
        view.findViewById<MaterialButton>(R.id.keyHome).setOnClickListener { terminal.sendSpecial("\u001B[H") }
        view.findViewById<MaterialButton>(R.id.keyEnd).setOnClickListener { terminal.sendSpecial("\u001B[F") }
        view.findViewById<MaterialButton>(R.id.keyPgUp).setOnClickListener { terminal.sendSpecial("\u001B[5~") }
        view.findViewById<MaterialButton>(R.id.keyPgDn).setOnClickListener { terminal.sendSpecial("\u001B[6~") }
        view.findViewById<MaterialButton>(R.id.keyDel).setOnClickListener { terminal.sendSpecial("\u001B[3~") }

        val btnCtrl = view.findViewById<MaterialButton>(R.id.keyCtrl)
        val btnAlt = view.findViewById<MaterialButton>(R.id.keyAlt)
        btnCtrl.setOnClickListener {
            val on = terminal.toggleCtrl()
            btnCtrl.isSelected = on
            btnAlt.isSelected = false
        }
        btnAlt.setOnClickListener {
            val on = terminal.toggleAlt()
            btnAlt.isSelected = on
            btnCtrl.isSelected = false
        }

        view.findViewById<MaterialButton>(R.id.keyCopy).setOnClickListener { copySelection() }
        view.findViewById<MaterialButton>(R.id.keyPaste).setOnClickListener { paste() }
        // 显式回车按钮：部分中文输入法（搜狗/百度/Gboard 中文）在设置了
        // IME_FLAG_NO_ENTER_ACTION 后不会把回车键转发为 KeyEvent，
        // 导致 onKeyDown 收不到 KEYCODE_ENTER。这个按钮是可靠兜底。
        view.findViewById<MaterialButton>(R.id.keyEnter).setOnClickListener {
            terminal.sendSpecial("\r")
        }
        view.findViewById<MaterialButton>(R.id.keyClear).setOnClickListener { clearScreen() }
    }

    fun clearScreen() {
        // 发送 clear 命令，让远端真正重绘（比本地清屏更贴合 shell 状态）
        val live = session()
        if (live != null && live.isAlive) {
            live.sendText("clear\n")
        }
        emulator?.clearScreen()
        emulator?.clearScrollback()
        terminal.scrollToBottom()
    }

    fun copySelection() {
        val text = terminal.getSelectedText()
        if (text.isNullOrEmpty()) {
            toast(requireContext().getString(R.string.nothing_selected))
            return
        }
        val cm = requireContext().getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(android.content.ClipData.newPlainText("terminal", text))
        terminal.clearSelection()
        toast(requireContext().getString(R.string.copied_to_clipboard))
    }

    fun paste() {
        val cm = requireContext().getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        val text = cm.primaryClip?.getItemAt(0)?.text?.toString() ?: return
        val live = session() ?: return
        if (emulator?.bracketedPaste == true) {
            live.sendText("\u001B[200~")
            live.sendText(text)
            live.sendText("\u001B[201~")
        } else {
            live.sendText(text)
        }
        terminal.scrollToBottom()
    }

    fun zoomIn() = terminal.zoomIn()
    fun zoomOut() = terminal.zoomOut()
    fun resetZoom() = terminal.resetZoom()

    fun scrollPage(dir: Int) = terminal.scrollPage(dir)

    override fun onResume() {
        super.onResume()
        view?.post {
            terminal.requestFocus()
        }
    }

    override fun onPause() {
        (requireContext().getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager)
            ?.hideSoftInputFromWindow(terminal.windowToken, 0)
        super.onPause()
    }

    override fun onDestroyView() {
        terminal.emulator = null
        super.onDestroyView()
    }
}
