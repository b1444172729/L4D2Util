package con.android.ssh.ui

import android.content.Context
import android.os.Bundle
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import com.google.android.material.button.MaterialButton
import con.android.ssh.R
import con.android.ssh.data.AppPrefs
import con.android.ssh.data.KeyBar
import con.android.ssh.ssh.LiveSession
import con.android.ssh.term.TerminalEmulator
import con.android.ssh.term.TerminalView
import con.android.ssh.util.toast

class TerminalFragment : Fragment(R.layout.fragment_terminal) {

    companion object {
        private const val ARG_HOST_ID = "host_id"

        fun new(hostId: String) = TerminalFragment().apply {
            arguments = Bundle().apply { putString(ARG_HOST_ID, hostId) }
        }
    }

    private val hostId: String by lazy { requireArguments().getString(ARG_HOST_ID)!! }

    private lateinit var terminal: TerminalView
    private lateinit var progress: ProgressBar
    private lateinit var hint: TextView
    private lateinit var keyBar: HorizontalScrollView

    private var emulator: TerminalEmulator? = null
    private var shellStarted = false
    private var stopPrefs: (() -> Unit)? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        terminal = view.findViewById(R.id.terminal)
        progress = view.findViewById(R.id.progress)
        hint = view.findViewById(R.id.hint)
        keyBar = view.findViewById(R.id.keyBar)

        keyBar.isVisible = AppPrefs.showKeyBar

        val emu = TerminalEmulator(80, 24, AppPrefs.scrollback)
        emulator = emu
        terminal.emulator = emu
        // 订阅设置变化：设置页一改动，这里立即跟着变，不必重启应用
        stopPrefs = AppPrefs.listen { key -> onPrefChanged(key) }

        // 发送是异步的，结果通过 onSendError 回来（写线程里执行，不阻塞主线程）
        terminal.onInput = { data ->
            val live = session()
            when {
                live == null -> warnSend("尚未连接")
                live.shell == null -> warnSend("Shell 未启动，请点右上角重连")
                else -> {
                    live.onSendError = { msg -> warnSend("发送失败：$msg") }
                    live.send(data)
                }
            }
        }
        terminal.onSizeChanged = { cols, rows ->
            val live = session()
            if (live != null && shellStarted) {
                live.resizeShell(cols, rows)
            }
        }

        buildKeyBar()

        terminal.post {
            if (isResumed) {
                terminal.requestFocus()
                if (!TerminalView.hasHardwareKeyboard(requireContext())) {
                    terminal.showKeyboard(true)
                }
            }
        }

        (activity as? SessionHost)?.ensureConnected { live ->
            onConnected(live)
        }
        refreshState()
    }

    private fun session(): LiveSession? = (activity as? SessionHost)?.liveSession()

    /**
     * 设置项即时生效。
     *
     * 以前这些值只在 Fragment 创建时读一次，改完设置必须重启应用才看到变化。
     * 现在改设置会触发回调；同时 onResume 也会整体重刷一次，
     * 覆盖「从设置页返回」这种 Fragment 处于停止态、收不到回调的情况。
     */
    private fun onPrefChanged(key: String) {
        when (key) {
            "font_size" -> if (::terminal.isInitialized) terminal.applyPrefs()
            "scrollback" -> emulator?.applyMaxScrollback(AppPrefs.scrollback)
            "keybar" -> if (::keyBar.isInitialized) keyBar.isVisible = AppPrefs.showKeyBar
            "keybar_order" -> buildKeyBar()
            "term_type" -> toast("终端类型将在下次连接时生效")
            "keepalive" -> toast("保活间隔将在下次连接时生效")
            "compression" -> toast("压缩开关将在下次连接时生效")
        }
    }

    private fun applyAllPrefs() {
        if (!::terminal.isInitialized) return
        terminal.applyPrefs()
        emulator?.applyMaxScrollback(AppPrefs.scrollback)
        keyBar.isVisible = AppPrefs.showKeyBar
        buildKeyBar()
    }

    /** 输入失败时提示。做节流，避免每个按键都弹 toast 刷屏。 */
    private var lastWarnAt = 0L
    private fun warnSend(msg: String) {
        val now = android.os.SystemClock.elapsedRealtime()
        if (now - lastWarnAt < 3000) return
        lastWarnAt = now
        android.util.Log.w("终端模拟器", "输入未能送达: $msg")
        if (isAdded) toast(msg)
    }

    private fun onConnected(live: LiveSession) {
        if (!isAdded) return
        refreshState(live)
        if (live.state != con.android.ssh.ssh.ConnState.CONNECTED) return
        if (shellStarted) return
        val (cols, rows) = terminal.termSize()
        val emu = emulator ?: return
        // 必须无条件重新绑定：Fragment 重建后（切 tab、从设置页返回）会生成新的
        // TerminalEmulator，而 live.emulator 还指向上一个已失效的实例。
        // 之前写成「仅在为 null 时赋值」，重建后就再也不会指向新的，
        // 于是远端回显全写进了旧对象 —— 屏幕上看不到任何新内容。
        live.emulator = emu
        android.util.Log.d("终端模拟器", "终端缓冲已绑定: ${emu.cols}x${emu.rows}")
        progress.isVisible = true
        kotlin.concurrent.thread(name = "start-shell") {
            // startShell 现在返回错误原因（null = 成功），直接显示给用户，
            // 不再笼统提示"会话已关闭"，否则根本无法定位问题。
            val err = live.startShell(cols, rows)
            activity?.runOnUiThread {
                shellStarted = (err == null)
                progress.isVisible = false
                if (err != null) {
                    hint.isVisible = true
                    hint.text = err
                    android.util.Log.e("终端模拟器", "shell 启动失败: $err")
                } else {
                    hint.isVisible = false
                    terminal.requestFocus()
                }
            }
        }
    }

    fun refreshState(live: LiveSession? = session()) {
        if (!isAdded) return
        if (live == null || live.state != con.android.ssh.ssh.ConnState.CONNECTED) {
            progress.isVisible = true
        } else {
            progress.isVisible = !shellStarted
        }
    }

    /**
     * 按设置里的顺序动态生成底部按键栏。
     *
     * 原来是写死在 XML 里的静态按钮，无法调整顺序、新增按键也要改布局。
     * 现在由 KeyBar.order() 决定顺序，用户在设置里拖动后即时生效。
     */
    private fun buildKeyBar() {
        val content = view?.findViewById<LinearLayout>(R.id.keyBarContent) ?: return
        content.removeAllViews()

        val ctx = requireContext()
        val dm = ctx.resources.displayMetrics
        val h = (36 * dm.density).toInt()
        val marginStart = (4 * dm.density).toInt()

        var btnCtrl: MaterialButton? = null
        var btnAlt: MaterialButton? = null

        for (id in KeyBar.order()) {
            val def = KeyBar.def(id) ?: continue
            val btn = MaterialButton(ctx, null, com.google.android.material.R.attr.materialButtonOutlinedStyle)
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, h
            ).apply { this.marginStart = marginStart }
            btn.layoutParams = lp
            btn.minWidth = (48 * dm.density).toInt()
            btn.minimumWidth = (48 * dm.density).toInt()
            btn.insetTop = 0
            btn.insetBottom = 0
            btn.setPadding((8 * dm.density).toInt(), 0, (8 * dm.density).toInt(), 0)
            btn.text = def.label(ctx)
            btn.isAllCaps = false
            btn.textSize = 12f

            // 按钮不要抢走终端的焦点，否则软键盘会收起
            btn.isFocusable = false
            btn.isFocusableInTouchMode = false

            when (id) {
                "ctrl" -> {
                    btnCtrl = btn
                    btn.setOnClickListener {
                        val on = terminal.toggleCtrl()
                        btn.isSelected = on
                        btnAlt?.isSelected = false
                    }
                }
                "alt" -> {
                    btnAlt = btn
                    btn.setOnClickListener {
                        val on = terminal.toggleAlt()
                        btn.isSelected = on
                        btnCtrl?.isSelected = false
                    }
                }
                "copy" -> btn.setOnClickListener { copySelection() }
                "paste" -> btn.setOnClickListener { paste() }
                "clear" -> btn.setOnClickListener { clearScreen() }
                else -> {
                    val seq = def.seq
                    if (seq != null) {
                        btn.setOnClickListener { terminal.sendSpecial(seq) }
                    }
                }
            }
            content.addView(btn)
        }
    }

    fun clearScreen() {
        // 发送 clear 命令，让远端真正重绘（比本地清屏更贴合 shell 状态）
        val live = session()
        if (live != null && live.isAlive) {
            live.sendText("clear\n")
        }
        emulator?.clearScreen()
        emulator?.clearScrollback()
        terminal.scrollToBottom()
    }

    fun copySelection() {
        val text = terminal.getSelectedText()
        if (text.isNullOrEmpty()) {
            toast(requireContext().getString(R.string.nothing_selected))
            return
        }
        val cm = requireContext().getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(android.content.ClipData.newPlainText("terminal", text))
        terminal.clearSelection()
        toast(requireContext().getString(R.string.copied_to_clipboard))
    }

    fun paste() {
        val cm = requireContext().getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        val text = cm.primaryClip?.getItemAt(0)?.text?.toString() ?: return
        val live = session() ?: return
        if (emulator?.bracketedPaste == true) {
            live.sendText("\u001B[200~")
            live.sendText(text)
            live.sendText("\u001B[201~")
        } else {
            live.sendText(text)
        }
        terminal.scrollToBottom()
    }

    fun zoomIn() = terminal.zoomIn()
    fun zoomOut() = terminal.zoomOut()
    fun resetZoom() = terminal.resetZoom()

    fun scrollPage(dir: Int) = terminal.scrollPage(dir)

    override fun onResume() {
        super.onResume()
        // 从设置页返回时，Fragment 此前处于停止态收不到回调，这里整体重刷
        applyAllPrefs()
        view?.post {
            terminal.requestFocus()
        }
    }

    override fun onPause() {
        (requireContext().getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager)
            ?.hideSoftInputFromWindow(terminal.windowToken, 0)
        super.onPause()
    }

    override fun onDestroyView() {
        stopPrefs?.invoke()
        stopPrefs = null
        terminal.emulator = null
        super.onDestroyView()
    }
}
