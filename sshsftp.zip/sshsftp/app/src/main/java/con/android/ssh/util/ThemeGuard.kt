package con.android.ssh.util

import android.app.Activity
import android.content.res.Configuration
import android.content.res.Resources
import androidx.appcompat.app.AppCompatDelegate
import con.android.ssh.data.AppPrefs

/**
 * 主题守卫：保证设置里改了主题后，所有已存在的界面都能跟着变，
 * 不需要用户退出应用重进。
 *
 * 判定方式是【看实际状态】而不是记账：
 * 把"期望的夜间模式"与本 Activity 当前 resources.configuration.uiMode 对比，
 * 不同才重建。这样天然满足两点：
 *   - 已经是目标主题 ⇒ 一次都不重建，不会有闪烁；
 *   - 确实没跟上（比如 AppCompat 没自动重建它）⇒ 补一次重建。
 *
 * 之前用"记住上次生效值"的字符串比较，遇到 AppCompat 未重建某个界面时
 * 会误判为"已生效"而漏掉重建。
 */
object ThemeGuard {

    /** 上次触发重建的时间戳，用于防止极端情况下的重建循环 */
    @Volatile
    private var lastRecreateAt = 0L

    /** 保留给外部在已知主题生效时调用；check() 不再依赖它 */
    @Volatile
    private var applied: String = ""

    fun markApplied(value: String = AppPrefs.themeRaw) {
        applied = value
    }

    /**
     * 在 Activity.onResume() 中调用。
     * 返回 true 表示已触发重建，调用方应直接 return，不要再执行后续逻辑。
     */
    fun check(activity: Activity): Boolean {
        val desired = desiredMask(activity)
        val current = activity.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
        // 期望值无法确定，或当前已经是目标主题 ⇒ 不重建
        if (desired == 0 || current == desired) return false

        // 防循环：短时间内不重复重建
        val now = android.os.SystemClock.elapsedRealtime()
        if (now - lastRecreateAt < 1500) return false
        lastRecreateAt = now

        AppCompatDelegate.setDefaultNightMode(AppPrefs.nightMode)
        runCatching { activity.recreate() }
        return true
    }

    /**
     * 当前是否处于浅色模式。
     *
     * 终端配色需要跟随它：之前终端在深浅两套主题里都写成黑底，
     * 浅色主题下终端仍是黑底白字，与界面整体割裂。
     */
    fun isLightNow(): Boolean {
        val mode = (android.content.res.Resources.getSystem().configuration.uiMode
            and Configuration.UI_MODE_NIGHT_MASK)
        return mode == Configuration.UI_MODE_NIGHT_NO
    }

    /** 期望的 UI_MODE_NIGHT_* ；返回 0 表示无法确定 */
    private fun desiredMask(activity: Activity): Int {
        return when (AppPrefs.nightMode) {
            AppCompatDelegate.MODE_NIGHT_NO -> Configuration.UI_MODE_NIGHT_NO
            AppCompatDelegate.MODE_NIGHT_YES -> Configuration.UI_MODE_NIGHT_YES
            else -> {
                // 跟随系统：取系统当前的夜间状态
                val sys = Resources.getSystem().configuration.uiMode and
                    Configuration.UI_MODE_NIGHT_MASK
                if (sys == Configuration.UI_MODE_NIGHT_UNDEFINED) {
                    activity.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
                } else {
                    sys
                }
            }
        }
    }
}
