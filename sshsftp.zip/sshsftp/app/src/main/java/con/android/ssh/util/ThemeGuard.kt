package con.android.ssh.util

import android.app.Activity
import androidx.appcompat.app.AppCompatDelegate
import con.android.ssh.data.AppPrefs

/**
 * 主题守卫：保证设置里改了主题后，所有已存在的界面都能跟着变，
 * 不需要用户退出应用重进。
 *
 * AppCompatDelegate.setDefaultNightMode() 只影响"之后新建"的界面；
 * 已经在后台栈里的 Activity 不会重新 inflate 布局，
 * 所以在它们重新可见时（onResume）检查一次：主题变了就 recreate()。
 * recreate() 只是重建这一个界面的视图，瞬间完成，用户感知不到。
 */
object ThemeGuard {

    /** 最近一次已知已生效的主题值 */
    @Volatile
    private var applied: String = ""

    fun markApplied(value: String = AppPrefs.themeRaw) {
        applied = value
    }

    /**
     * 在 Activity.onResume() 中调用。
     * 返回 true 表示已触发重建，调用方应直接 return，不要再执行后续逻辑。
     */
    fun check(activity: Activity): Boolean {
        val current = AppPrefs.themeRaw
        if (applied.isEmpty()) {
            // 首次进入，记录基线
            applied = current
            return false
        }
        if (applied == current) return false
        applied = current
        AppCompatDelegate.setDefaultNightMode(AppPrefs.nightMode)
        activity.recreate()
        return true
    }
}
