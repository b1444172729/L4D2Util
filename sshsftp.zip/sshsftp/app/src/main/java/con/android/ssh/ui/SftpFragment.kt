package con.android.ssh.ui

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import com.google.android.material.tabs.TabLayout
import con.android.ssh.R
import con.android.ssh.data.AppPrefs
import con.android.ssh.ssh.LiveSession
import con.android.ssh.ssh.LocalFs
import con.android.ssh.ssh.SessionRegistry
import con.android.ssh.ssh.TransferManager
import con.android.ssh.ssh.TransferTask
import con.android.ssh.ssh.TransferService
import con.android.ssh.util.toast

/**
 * SFTP 页：本地 / 远程双窗格，负责协调两侧目录与入队传输任务。
 */
class SftpFragment : Fragment(R.layout.fragment_sftp), PaneHost {

    companion object {
        private const val ARG_HOST_ID = "host_id"

        fun new(hostId: String) = SftpFragment().apply {
            arguments = Bundle().apply { putString(ARG_HOST_ID, hostId) }
        }
    }

    private val hostId: String by lazy { requireArguments().getString(ARG_HOST_ID)!! }

    private lateinit var localPane: FilePaneFragment
    private lateinit var remotePane: FilePaneFragment
    private var sortMode = "name"
    private var hidden = AppPrefs.showHidden

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val tabs = view.findViewById<TabLayout>(R.id.paneTabs)

        // 复用已存在的子 Fragment：重建（旋转、进程恢复）时若再 add 一次，
        // 会出现两套面板，localPane/remotePane 指向新的、屏幕上却是旧的，
        // 于是"另一侧目录"取到的就是错的。
        val fm = childFragmentManager
        val oldLocal = fm.findFragmentByTag("local") as? FilePaneFragment
        val oldRemote = fm.findFragmentByTag("remote") as? FilePaneFragment
        localPane = oldLocal ?: FilePaneFragment.new(hostId, false)
        remotePane = oldRemote ?: FilePaneFragment.new(hostId, true)

        if (oldLocal == null || oldRemote == null) {
            fm.beginTransaction().apply {
                if (oldLocal == null) add(R.id.paneContainer, localPane, "local")
                if (oldRemote == null) add(R.id.paneContainer, remotePane, "remote")
                hide(remotePane)
            }.commit()
        }

        tabs.addTab(tabs.newTab().setText(R.string.pane_local), true)
        tabs.addTab(tabs.newTab().setText(R.string.pane_remote))
        tabs.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) = showPane(tab.position == 1)
            override fun onTabUnselected(tab: TabLayout.Tab) = Unit
            override fun onTabReselected(tab: TabLayout.Tab) = Unit
        })
    }

    /**
     * 传输结束后自动刷新两侧目录，让结果立刻可见。
     *
     * 用"当前活跃任务数"判断，而不是一个 pendingRefresh 布尔标记：
     * 布尔标记会在第一批任务完成的瞬间被置回 false，
     * 若用户随后又入队了新一批，或通知在任务入队前先到，就会漏刷新。
     */
    private val transferListener: () -> Unit = {
        if (::localPane.isInitialized && ::remotePane.isInitialized &&
            TransferManager.countActive() == 0
        ) {
            runCatching { localPane.reload() }
            runCatching { remotePane.reload() }
        }
    }

    override fun onStart() {
        super.onStart()
        TransferManager.addListener(transferListener)
    }

    override fun onStop() {
        TransferManager.removeListener(transferListener)
        super.onStop()
    }

    private fun showPane(remote: Boolean) {
        childFragmentManager.beginTransaction()
            .apply {
                if (remote) hide(localPane).show(remotePane) else hide(remotePane).show(localPane)
            }
            .commit()
    }

    // ---------------- PaneHost ----------------

    override fun liveSession(): LiveSession? = (activity as? SessionHost)?.liveSession()

    override fun ensureConnected(cb: (LiveSession) -> Unit) {
        (activity as? SessionHost)?.ensureConnected(cb)
    }

    /**
     * 本地侧当前目录。面板尚未就绪时回退到默认根目录，
     * 避免拿到空串或初始值 "/" 导致传输落到错误位置。
     */
    override fun localDir(): String {
        val cur = if (::localPane.isInitialized) localPane.currentDir() else ""
        return if (cur.isBlank()) LocalFs.root(requireContext()).absolutePath else cur
    }

    /** 远程侧当前目录，同上做回退 */
    override fun remoteDir(): String {
        val cur = if (::remotePane.isInitialized) remotePane.currentDir() else ""
        return if (cur.isBlank()) SessionRegistry.hostStartDir(hostId) else cur
    }

    override fun enqueue(tasks: List<TransferTask>) {
        // 下载时确保本地父目录存在
        tasks.forEach { t ->
            if (!t.upload) {
                java.io.File(t.localPath).parentFile?.mkdirs()
            }
        }
        TransferManager.add(tasks)
        TransferService.start(requireContext())
        toast(getString(R.string.transfer_notify_title, tasks.size))
    }

    override fun openRemoteEditor(path: String) {
        startActivity(
            android.content.Intent(requireContext(), EditorActivity::class.java)
                .putExtra(EditorActivity.EXTRA_PATH, path)
                .putExtra(EditorActivity.EXTRA_REMOTE, true)
                .putExtra(EditorActivity.EXTRA_HOST_ID, hostId)
        )
    }

    override fun refreshCounterpart() {
        remotePane.load(remotePane.currentDir())
        localPane.load(localPane.currentDir())
    }

    override fun currentSort(): String = sortMode
    override fun setSort(mode: String) { sortMode = mode }
    override fun showHidden(): Boolean = hidden
    override fun setShowHidden(v: Boolean) { hidden = v }

    /** 上次载入时用的几项设置，用于判断回到本页时是否需要刷新 */
    private var lastLocalRoot: String = ""

    override fun onResume() {
        super.onResume()
        // 设置页改动后回到本页立即生效，不必重启应用
        val pref = AppPrefs.showHidden
        val rootChanged = lastLocalRoot.isNotEmpty() && lastLocalRoot != AppPrefs.localRoot
        lastLocalRoot = AppPrefs.localRoot
        if (pref != hidden || rootChanged) {
            hidden = pref
            runCatching { localPane.reload() }
            runCatching { remotePane.reload() }
        }
    }
}
