package con.android.ssh.util

import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import con.android.ssh.R
import con.android.ssh.data.HostStore
import con.android.ssh.ssh.SshConnector
import con.android.ssh.ssh.TrustRequest
import java.util.concurrent.CountDownLatch

/**
 * 安装主机密钥确认处理器。
 * 该回调在连接线程中被同步调用，这里把对话框抛到主线程并阻塞等待用户选择。
 */
fun AppCompatActivity.installTrustPrompt() {
    SshConnector.trustPrompt = { req: TrustRequest ->
        val latch = CountDownLatch(1)
        var accepted = false
        runOnUiThread {
            if (isFinishing || isDestroyed) {
                latch.countDown()
            } else {
                val (title, msg) = if (req.changed) {
                    getString(R.string.host_key_changed_title) to getString(
                        R.string.host_key_changed_msg,
                        "${req.host}:${req.port}",
                        req.oldFingerprint ?: "-",
                        req.fingerprint
                    )
                } else {
                    getString(R.string.unknown_host_title) to getString(
                        R.string.unknown_host_msg,
                        "${req.host}:${req.port}",
                        req.algorithm,
                        req.fingerprint
                    )
                }
                MaterialAlertDialogBuilder(this)
                    .setTitle(title)
                    .setMessage(msg)
                    .setCancelable(false)
                    .setNegativeButton(R.string.cancel) { _, _ -> latch.countDown() }
                    .setNeutralButton(R.string.trust_once) { _, _ ->
                        accepted = true
                        latch.countDown()
                    }
                    .setPositiveButton(R.string.trust_always) { _, _ ->
                        accepted = true
                        HostStore.trustFingerprint(req.host, req.port, req.fingerprint)
                        latch.countDown()
                    }
                    .setOnDismissListener { latch.countDown() }
                    .show()
            }
        }
        runCatching { latch.await() }
        accepted
    }
}
