package con.android.ssh.util

import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import con.android.ssh.R
import con.android.ssh.data.HostStore
import con.android.ssh.ssh.SshConnector
import con.android.ssh.ssh.TrustRequest
import java.util.concurrent.CountDownLatch

/**
 * 安装主机密钥确认处理器。
 * 该回调在连接线程中被同步调用，这里把对话框抛到主线程并阻塞等待用户选择。
 */
fun AppCompatActivity.installTrustPrompt() {
    SshConnector.trustPrompt = { req: TrustRequest ->
        val latch = CountDownLatch(1)
        // 必须用 AtomicBoolean：accepted 在主线程写、在连接线程读，
        // 普通 Boolean 不保证跨线程可见，可能用户已点"信任"这边仍读到 false，
        // 表现为"明明确认了却还是连不上"。
        val accepted = java.util.concurrent.atomic.AtomicBoolean(false)
        runOnUiThread {
            if (isFinishing || isDestroyed) {
                latch.countDown()
            } else {
                val (title, msg) = if (req.changed) {
                    getString(R.string.host_key_changed_title) to getString(
                        R.string.host_key_changed_msg,
                        "${req.host}:${req.port}",
                        req.oldFingerprint ?: "-",
                        req.fingerprint
                    )
                } else {
                    getString(R.string.unknown_host_title) to getString(
                        R.string.unknown_host_msg,
                        "${req.host}:${req.port}",
                        req.algorithm,
                        req.fingerprint
                    )
                }
                MaterialAlertDialogBuilder(this)
                    .setTitle(title)
                    .setMessage(msg)
                    .setCancelable(false)
                    .setNegativeButton(R.string.cancel) { _, _ -> latch.countDown() }
                    .setNeutralButton(R.string.trust_once) { _, _ ->
                        accepted.set(true)
                        latch.countDown()
                    }
                    .setPositiveButton(R.string.trust_always) { _, _ ->
                        accepted.set(true)
                        HostStore.trustFingerprint(req.host, req.port, req.fingerprint)
                        latch.countDown()
                    }
                    .setOnDismissListener { latch.countDown() }
                    .show()
            }
        }
        runCatching { latch.await() }
        accepted.get()
    }
}

/**
 * 断开主机密钥确认处理器与 Activity 的绑定。
 *
 * trustPrompt 是 SshConnector 上的静态回调，会隐式捕获 Activity。
 * 若不在 onDestroy 里清空，Activity 销毁后连接线程仍可能通过它弹窗，
 * 既造成 Activity 泄漏，也会在已销毁的实例上操作视图而崩溃。
 */
fun clearTrustPrompt() {
    SshConnector.trustPrompt = null
}
