package con.android.ssh.ui

import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.DialogFragment
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import con.android.ssh.R
import con.android.ssh.data.KeyBar
import java.util.Collections

/**
 * 底部按键栏顺序调整。
 *
 * 两种操作方式都可用：
 *  1. 点条目右侧的 ▲ / ▼ 直接上下移动（推荐，必定生效）；
 *  2. 长按条目拖动（ItemTouchHelper）。
 *
 * 关键改动：每移动一步就【立即写入】SharedPreferences，
 * 而不是等点"完成"才保存。之前只在 positive 按钮里保存，
 * 一旦用户拖动没成功触发 onMove（长按手势在对话框里很容易失败），
 * 数据就完全没变 —— 表现正是"明明调了，回头看还是原样"。
 */
class KeyBarOrderDialog : DialogFragment() {

    /** 打开时的初始顺序，供"取消"回滚 */
    private lateinit var original: List<String>
    private lateinit var ids: MutableList<String>
    private lateinit var adapter: OrderAdapter

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val ctx = requireContext()
        original = KeyBar.order()
        ids = original.toMutableList()

        val dp = ctx.resources.displayMetrics.density
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((20 * dp).toInt(), (4 * dp).toInt(), (20 * dp).toInt(), 0)
        }

        val tip = TextView(ctx).apply {
            text = getString(R.string.set_keybar_order_hint)
            setTextAppearance(android.R.style.TextAppearance_Material_Caption)
            setPadding((4 * dp).toInt(), 0, 0, (4 * dp).toInt())
        }

        val recycler = RecyclerView(ctx).apply {
            layoutManager = LinearLayoutManager(ctx)
            // 条目数量固定且很少，固定高度可避免对话框尺寸在移动后跳动
            isNestedScrollingEnabled = false
        }

        adapter = OrderAdapter(ids) { from, to ->
            if (from < 0 || to < 0 || from >= ids.size || to >= ids.size) false
            else {
                Collections.swap(ids, from, to)
                KeyBar.saveOrder(ids)   // 立即持久化
                true
            }
        }
        recycler.adapter = adapter

        // 长按拖动（可选方式）。只需把手指位置换算成"向上/向下移动一格"。
        val touch = ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(
            ItemTouchHelper.UP or ItemTouchHelper.DOWN, 0
        ) {
            override fun onMove(
                rv: RecyclerView,
                vh: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                val from = vh.bindingAdapterPosition
                val to = target.bindingAdapterPosition
                return adapter.move(from, to)
            }

            override fun onSwiped(vh: RecyclerView.ViewHolder, dir: Int) = Unit
        })
        touch.attachToRecyclerView(recycler)

        root.addView(tip)
        root.addView(recycler)

        return MaterialAlertDialogBuilder(ctx)
            .setTitle(R.string.set_keybar_order)
            .setView(root)
            .setNeutralButton(R.string.reset_default) { _, _ ->
                KeyBar.resetOrder()
            }
            .setNegativeButton(R.string.cancel) { _, _ ->
                // 回滚到打开时的顺序
                KeyBar.saveOrder(original)
            }
            .setPositiveButton(R.string.done, null)
            .create()
    }

    private class OrderAdapter(
        private val ids: MutableList<String>,
        private val onMove: (Int, Int) -> Boolean
    ) : RecyclerView.Adapter<OrderAdapter.VH>() {

        /** 返回 true 表示确实发生了移动 */
        fun move(from: Int, to: Int): Boolean {
            if (!onMove(from, to)) return false
            notifyItemMoved(from, to)
            // 两端条目的可用状态会变化，整体刷新一次更稳妥
            notifyItemRangeChanged(minOf(from, to), kotlin.math.abs(from - to) + 1)
            return true
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
            VH(LayoutInflater.from(parent.context)
                .inflate(R.layout.item_key_order, parent, false))

        override fun getItemCount(): Int = ids.size

        override fun onBindViewHolder(holder: VH, position: Int) {
            val ctx = holder.itemView.context
            holder.name.text = KeyBar.def(ids[position])?.label(ctx) ?: ids[position]
            holder.btnUp.isEnabled = position > 0
            holder.btnDown.isEnabled = position < ids.size - 1
            holder.btnUp.alpha = if (holder.btnUp.isEnabled) 1f else 0.3f
            holder.btnDown.alpha = if (holder.btnDown.isEnabled) 1f else 0.3f
            holder.btnUp.setOnClickListener { move(position, position - 1) }
            holder.btnDown.setOnClickListener { move(position, position + 1) }
        }

        class VH(v: View) : RecyclerView.ViewHolder(v) {
            val name: TextView = v.findViewById(R.id.name)
            val btnUp: com.google.android.material.button.MaterialButton = v.findViewById(R.id.btnUp)
            val btnDown: com.google.android.material.button.MaterialButton = v.findViewById(R.id.btnDown)
        }
    }
}
