package con.android.ssh.ui

import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.DialogFragment
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import con.android.ssh.R
import con.android.ssh.data.KeyBar
import java.util.Collections

/**
 * 底部按键栏顺序调整：长按右侧条目上下拖动即可排序。
 */
class KeyBarOrderDialog : DialogFragment() {

    private val ids = KeyBar.order().toMutableList()

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val ctx = requireContext()

        val recycler = RecyclerView(ctx).apply {
            layoutManager = LinearLayoutManager(ctx)
            setPadding(0, 8, 0, 8)
        }
        val adapter = OrderAdapter(ids) { from, to ->
            Collections.swap(ids, from, to)
        }
        recycler.adapter = adapter

        val touch = ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(
            ItemTouchHelper.UP or ItemTouchHelper.DOWN, 0
        ) {
            override fun onMove(
                rv: RecyclerView,
                vh: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                val from = vh.bindingAdapterPosition
                val to = target.bindingAdapterPosition
                if (from < 0 || to < 0) return false
                adapter.move(from, to)
                return true
            }

            override fun onSwiped(vh: RecyclerView.ViewHolder, dir: Int) = Unit
        })
        touch.attachToRecyclerView(recycler)

        return MaterialAlertDialogBuilder(ctx)
            .setTitle(R.string.set_keybar_order)
            .setMessage(R.string.set_keybar_order_hint)
            .setView(recycler)
            .setNeutralButton(R.string.reset_default) { _, _ ->
                KeyBar.resetOrder()
                dismiss()
            }
            .setNegativeButton(R.string.cancel, null)
            .setPositiveButton(R.string.done) { _, _ ->
                KeyBar.saveOrder(ids)
            }
            .create()
    }

    private class OrderAdapter(
        private val ids: MutableList<String>,
        private val onMove: (Int, Int) -> Unit
    ) : RecyclerView.Adapter<OrderAdapter.VH>() {

        fun move(from: Int, to: Int) {
            onMove(from, to)
            notifyItemMoved(from, to)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
            VH(LayoutInflater.from(parent.context)
                .inflate(R.layout.item_key_order, parent, false))

        override fun getItemCount(): Int = ids.size

        override fun onBindViewHolder(holder: VH, position: Int) {
            holder.name.text = KeyBar.def(ids[position])?.label(holder.name.context) ?: ids[position]
        }

        class VH(v: View) : RecyclerView.ViewHolder(v) {
            val name: TextView = v.findViewById(R.id.name)
        }
    }
}
