package con.android.ssh.ui

import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.DialogFragment
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import con.android.ssh.R
import con.android.ssh.data.KeyBar
import java.util.Collections

/**
 * 底部按键栏顺序调整：长按条目拖动，松手立即生效。
 *
 * 交互简化：
 *  - 去掉了每行的 ▲▼ 按钮（拖动本身就够用）；
 *  - 去掉了"取消 / 完成"，不留需要二次确认的出口，
 *    每移动一格就写入 SharedPreferences，关闭即已保存；
 *  - 只保留"恢复默认"。
 */
class KeyBarOrderDialog : DialogFragment() {

    private lateinit var ids: MutableList<String>
    private lateinit var adapter: OrderAdapter

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val ctx = requireContext()
        ids = KeyBar.order().toMutableList()

        val dp = ctx.resources.displayMetrics.density
        // 24dp 与 MaterialAlertDialog 标题的水平内边距一致，
        // 这样底部的"恢复默认"才能与标题「按键栏顺序」左对齐。
        val inset = (24 * dp).toInt()
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(inset, (4 * dp).toInt(), inset, 0)
        }

        val tip = TextView(ctx).apply {
            text = getString(R.string.set_keybar_order_hint)
            setTextAppearance(android.R.style.TextAppearance_Material_Caption)
            setPadding(0, 0, 0, (4 * dp).toInt())
        }

        val recycler = RecyclerView(ctx).apply {
            layoutManager = LinearLayoutManager(ctx)
            // 条目数量固定且很少，禁掉嵌套滚动避免对话框高度在拖动时跳动
            isNestedScrollingEnabled = false
        }

        adapter = OrderAdapter(ids) { from, to ->
            if (from < 0 || to < 0 || from >= ids.size || to >= ids.size) false
            else {
                Collections.swap(ids, from, to)
                // 立即持久化：没有"完成"按钮可点，必须每步都存
                KeyBar.saveOrder(ids)
                true
            }
        }
        recycler.adapter = adapter

        // 长按拖动。除了 ItemTouchHelper 自带长按外，额外在把手与整行上
        // 显式调用 startDrag：对话框里长按手势容易被滚动抢走，
        // 显式触发能保证一定拖得动。
        val touch = ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(
            ItemTouchHelper.UP or ItemTouchHelper.DOWN, 0
        ) {
            override fun onMove(
                rv: RecyclerView,
                vh: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                val from = vh.bindingAdapterPosition
                val to = target.bindingAdapterPosition
                return adapter.move(from, to)
            }

            override fun onSwiped(vh: RecyclerView.ViewHolder, dir: Int) = Unit
        })
        touch.attachToRecyclerView(recycler)
        adapter.onStartDrag = { vh -> touch.startDrag(vh) }

        root.addView(tip)
        root.addView(recycler)

        // "恢复默认"放在内容区左下角，而不是用 setNeutralButton()。
        // MaterialAlertDialogBuilder 会把所有按钮右对齐排成一组，
        // 无法与标题左对齐；用 TextView 则能精确控制到与标题同一条起始线。
        val resetView = TextView(ctx).apply {
            text = getString(R.string.reset_default)
            setTextAppearance(android.R.style.TextAppearance_Material_Button)
            // 用主题强调色，看起来像个可点的文字按钮
            setTextColor(materialColor(ctx))
            gravity = android.view.Gravity.START or android.view.Gravity.CENTER_VERTICAL
            // 48dp 保证触摸目标足够大；上下留白让它在视觉上不贴边
            minHeight = (48 * dp).toInt()
            setPadding(0, (6 * dp).toInt(), 0, (6 * dp).toInt())
            isClickable = true
            isFocusable = true
            val ripple = android.util.TypedValue()
            if (context.theme.resolveAttribute(
                    android.R.attr.selectableItemBackground, ripple, true
                )
            ) setBackgroundResource(ripple.resourceId)
            setOnClickListener {
                KeyBar.resetOrder()
                // 同步刷新列表，让用户立刻看到恢复后的顺序
                ids = KeyBar.order().toMutableList()
                adapter.resetTo(ids)
            }
        }
        root.addView(
            resetView,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        )

        return MaterialAlertDialogBuilder(ctx)
            .setTitle(R.string.set_keybar_order)
            .setView(root)
            .create()
    }

    /** 取主题的 colorAccent；取不到时退回内置青色 */
    private fun materialColor(ctx: android.content.Context): Int {
        val tv = android.util.TypedValue()
        return if (ctx.theme.resolveAttribute(android.R.attr.colorAccent, tv, true)) {
            tv.data
        } else {
            androidx.core.content.ContextCompat.getColor(ctx, con.android.ssh.R.color.accent)
        }
    }

    private class OrderAdapter(
        private var ids: MutableList<String>,
        private val onMove: (Int, Int) -> Boolean
    ) : RecyclerView.Adapter<OrderAdapter.VH>() {

        /** 由外层注入：请求开始拖动某个条目 */
        var onStartDrag: ((RecyclerView.ViewHolder) -> Unit)? = null

        fun resetTo(list: MutableList<String>) {
            ids = list
            notifyDataSetChanged()
        }

        /** 返回 true 表示确实发生了移动 */
        fun move(from: Int, to: Int): Boolean {
            if (!onMove(from, to)) return false
            notifyItemMoved(from, to)
            notifyItemRangeChanged(minOf(from, to), kotlin.math.abs(from - to) + 1)
            return true
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
            VH(LayoutInflater.from(parent.context)
                .inflate(R.layout.item_key_order, parent, false))

        override fun getItemCount(): Int = ids.size

        override fun onBindViewHolder(holder: VH, position: Int) {
            val ctx = holder.itemView.context
            holder.name.text = KeyBar.def(ids[position])?.label(ctx) ?: ids[position]
            // 把手与整行都支持长按起拖
            val starter = View.OnLongClickListener {
                onStartDrag?.invoke(holder)
                true
            }
            holder.handle.setOnLongClickListener(starter)
            holder.itemView.setOnLongClickListener(starter)
        }

        class VH(v: View) : RecyclerView.ViewHolder(v) {
            val name: TextView = v.findViewById(R.id.name)
            val handle: TextView = v.findViewById(R.id.handle)
        }
    }
}
