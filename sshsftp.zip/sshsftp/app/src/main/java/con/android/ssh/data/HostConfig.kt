package con.android.ssh.data

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * 一台远程主机的连接配置。
 * 密码与私钥口令不保存在这里，统一放在 [SecureStore]（加密 SharedPreferences）。
 */
data class HostConfig(
    var id: String = UUID.randomUUID().toString(),
    var name: String = "",
    var host: String = "",
    var port: Int = 22,
    var user: String = "",
    /** password 或 key */
    var authType: String = "password",
    var keyPath: String = "",
    var remark: String = "",
    var startDir: String = "",
    var startupCmd: String = ""
) {

    val displayName: String
        get() = name.ifBlank { if (host.isBlank()) "未命名" else host }

    /**
     * @param includeCredentials 是否把凭据写进 JSON。
     *                           仅导出时可设 true；[HostStore.persist] 必须保持 false，
     *                           因为凭据平时单独存在 SecureStore（加密）里，不能落进明文 SP。
     */
    fun toJson(
        includeCredentials: Boolean = false,
        creds: HostCredentials = HostCredentials()
    ): JSONObject = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("host", host)
        put("port", port)
        put("user", user)
        put("authType", authType)
        put("keyPath", keyPath)
        put("remark", remark)
        put("startDir", startDir)
        put("startupCmd", startupCmd)
        if (includeCredentials) {
            if (!creds.password.isNullOrEmpty()) put("password", creds.password)
            if (!creds.keyPassphrase.isNullOrEmpty()) put("keyPassphrase", creds.keyPassphrase)
        }
    }

    fun copyConfig(): HostConfig = copy(id = UUID.randomUUID().toString())

    companion object {
        fun fromJson(o: JSONObject): HostConfig = HostConfig(
            id = o.optString("id", UUID.randomUUID().toString()),
            name = o.optString("name"),
            host = o.optString("host"),
            port = o.optInt("port", 22),
            user = o.optString("user"),
            authType = o.optString("authType", "password"),
            keyPath = o.optString("keyPath"),
            remark = o.optString("remark"),
            startDir = o.optString("startDir"),
            startupCmd = o.optString("startupCmd")
        )
    }
}

/** 一台主机的凭据（登录密码 + 私钥口令）。仅在导入/导出时流动。 */
data class HostCredentials(
    val password: String? = null,
    val keyPassphrase: String? = null
) {
    val isEmpty: Boolean
        get() = password.isNullOrEmpty() && keyPassphrase.isNullOrEmpty()
}

/** 导出/导入的一条记录：配置 + 对应凭据 */
data class ExportedHost(
    val config: HostConfig,
    val credentials: HostCredentials = HostCredentials()
)

/**
 * 主机列表的导入 / 导出。
 *
 * 导出【包含凭据】（密码与私钥口令以明文写入 JSON）—— 这是刻意的，
 * 目的是备份后能在另一台设备上直接连上，不用重新输密码。
 * 代价是导出的文件里含明文口令，因此导出前会弹窗提示用户妥善保管。
 *
 * 兼容性：老版本导出的文件里没有 password / keyPassphrase 字段，
 * 用 optString 读取会返回空，导入后凭据为空（保持原行为），不会报错。
 */
object HostJson {
    fun exportAll(entries: List<ExportedHost>, includeCredentials: Boolean = true): String {
        val arr = JSONArray()
        entries.forEach {
            arr.put(it.config.toJson(includeCredentials, it.credentials))
        }
        return JSONObject()
            .put("version", 1)
            .put("containsCredentials", includeCredentials)
            .put("hosts", arr)
            .toString(2)
    }

    fun importAll(json: String): List<ExportedHost> {
        val obj = JSONObject(json)
        val arr = obj.optJSONArray("hosts") ?: throw IllegalArgumentException("缺少 hosts 字段")
        val out = ArrayList<ExportedHost>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            // 只在该字段确实存在时才取值：optString 对缺失字段返回 ""，
            // 与"确实存了空密码"无法区分，但对导入结果无影响（空串不落库）。
            val creds = HostCredentials(
                password = if (o.has("password")) o.optString("password") else null,
                keyPassphrase = if (o.has("keyPassphrase")) o.optString("keyPassphrase") else null
            )
            out.add(ExportedHost(HostConfig.fromJson(o), creds))
        }
        return out
    }
}
