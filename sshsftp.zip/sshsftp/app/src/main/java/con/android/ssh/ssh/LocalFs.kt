package con.android.ssh.ssh

import android.content.Context
import android.os.Environment
import con.android.ssh.data.AppPrefs
import java.io.File

/**
 * 本地文件系统操作。
 * Android 11+ 需要"所有文件访问权限"才能自由浏览 /sdcard；
 * 未授权时回退到应用私有目录（功能完整，只是范围受限）。
 */
object LocalFs {

    fun hasFullAccess(): Boolean =
        android.os.Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager()

    fun root(context: Context): File {
        val f = if (hasFullAccess()) {
            val custom = File(AppPrefs.localRoot)
            if (custom.exists() && custom.isDirectory) custom else Environment.getExternalStorageDirectory()
        } else {
            context.getExternalFilesDir(null) ?: context.filesDir
        }
        return if (f.exists() && f.isDirectory) f else context.filesDir
    }

    private fun toItem(f: File): FileItem {
        return FileItem(
            name = f.name,
            path = f.absolutePath,
            isDir = f.isDirectory,
            size = if (f.isDirectory) 0 else f.length(),
            mtime = f.lastModified(),
            perms = permsOf(f),
            owner = "",
            isLink = try {
                @Suppress("DEPRECATION")
                android.os.Build.VERSION.SDK_INT >= 26 && java.nio.file.Files.isSymbolicLink(f.toPath())
            } catch (_: Throwable) {
                false
            }
        )
    }

    private fun permsOf(f: File): Int {
        var p = 0
        if (f.canRead()) p = p or 0b100100100
        if (f.canWrite()) p = p or 0b010010010
        if (f.canExecute()) p = p or 0b001001001
        if (f.isDirectory) p = p or 0x100
        return p
    }

    fun list(dir: File, showHidden: Boolean = AppPrefs.showHidden): List<FileItem> {
        val files = dir.listFiles()?.toMutableList() ?: mutableListOf()
        val items = files.mapNotNull { f ->
            if (!showHidden && f.name.startsWith(".")) return@mapNotNull null
            toItem(f)
        }.toMutableList()
        sortItems(items, "name")
        return items
    }

    fun mkdir(dir: File, name: String): Boolean {
        val target = File(dir, name)
        return if (target.exists()) false else target.mkdirs()
    }

    fun createFile(dir: File, name: String): Boolean {
        val target = File(dir, name)
        return if (target.exists()) false else target.createNewFile()
    }

    fun rename(f: File, newName: String): Boolean {
        val target = File(f.parentFile, newName)
        return if (target.exists()) false else f.renameTo(target)
    }

    fun delete(f: File): Boolean = if (f.isDirectory) f.deleteRecursively() else f.delete()

    // POSIX 权限位（八进制 0644 这类）。Kotlin 没有八进制字面量，故用十进制常量。
    private const val OWNER_R = 0b100000000 // 0o400 = 256
    private const val OWNER_W = 0b010000000 // 0o200 = 128
    private const val OWNER_X = 0b001000000 // 0o100 = 64
    private const val OTHER_R = 0b000000100 // 0o004 = 4
    private const val OTHER_W = 0b000000010 // 0o002 = 2
    private const val OTHER_X = 0b000000001 // 0o001 = 1

    /**
     * 设置文件权限。
     *
     * 之前这里的两组掩码都写错了：owner 那组用了 0b100_000(=32，其实是 group-read)，
     * group 位则完全没有设置 —— 结果 chmod 0644 会把 owner 权限设成 group 的值。
     *
     * 说明：java.io.File 只能控制 owner 位与 others 位（setReadable 的第二个参数
     * ownerOnly=true 改 owner、false 改 others），**group 位无法设置**，这是
     * Android/Java 文件 API 的固有限制，不是本函数的疏漏。
     */
    fun chmod(f: File, perms: Int) {
        f.setReadable(perms and OWNER_R != 0, true)
        f.setWritable(perms and OWNER_W != 0, true)
        f.setExecutable(perms and OWNER_X != 0, true)
        f.setReadable(perms and OTHER_R != 0, false)
        f.setWritable(perms and OTHER_W != 0, false)
        f.setExecutable(perms and OTHER_X != 0, false)
    }

    fun copyOrMove(src: File, dst: File, move: Boolean): Boolean {
        // 目标是源自身或其子目录 ⇒ 会把内容递归复制进自己，必须拦下
        if (isSameOrChild(src, dst)) return false

        if (move) {
            // renameTo 跨分区/被占用时会失败并返回 false，不能当成功处理
            dst.parentFile?.mkdirs()
            if (src.renameTo(dst)) return true
            // 重命名失败：退化为"复制后删除"，保证结果一致
            if (!copyOrMove(src, dst, false)) return false
            return if (src.isDirectory) src.deleteRecursively() else src.delete()
        }
        if (src.isDirectory) {
            if (!dst.mkdirs() && !dst.isDirectory) return false
            src.listFiles()?.forEach {
                copyOrMove(it, File(dst, it.name), false)
            }
            return true
        }
        dst.parentFile?.mkdirs()
        src.inputStream().use { input ->
            dst.outputStream().use { output -> input.copyTo(output) }
        }
        return true
    }

    /** dst 是否就是 src，或位于 src 内部 */
    private fun isSameOrChild(src: File, dst: File): Boolean {
        return try {
            val s = src.canonicalPath
            val d = dst.canonicalPath
            s == d || d.startsWith(s.trimEnd('/') + "/")
        } catch (_: Throwable) {
            src.absolutePath == dst.absolutePath
        }
    }

    fun readText(f: File, maxBytes: Int = 1024 * 1024): String {
        if (f.length() > maxBytes) throw IllegalStateException("文件过大")
        return f.readText(Charsets.UTF_8)
    }

    fun writeText(f: File, text: String) {
        f.writeText(text, Charsets.UTF_8)
    }

    /** 递归列出目录下所有文件（相对路径 + 大小） */
    fun listFilesRecursive(dir: File, includeHidden: Boolean): List<Pair<String, Long>> {
        val out = ArrayList<Pair<String, Long>>()
        fun walk(base: String, rel: String) {
            val d = File(base, rel)
            val children = d.listFiles() ?: return
            for (c in children) {
                if (!includeHidden && c.name.startsWith(".")) continue
                val childRel = if (rel.isEmpty()) c.name else "$rel/${c.name}"
                if (c.isDirectory) walk(base, childRel) else out.add(childRel to c.length())
            }
        }
        walk(dir.absolutePath, "")
        return out
    }
}
