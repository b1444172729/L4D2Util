package con.android.ssh.ssh

import android.content.Context
import android.os.Environment
import con.android.ssh.data.AppPrefs
import java.io.File

/**
 * 本地文件系统操作。
 * Android 11+ 需要"所有文件访问权限"才能自由浏览 /sdcard；
 * 未授权时回退到应用私有目录（功能完整，只是范围受限）。
 */
object LocalFs {

    fun hasFullAccess(): Boolean =
        android.os.Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager()

    fun root(context: Context): File {
        val f = if (hasFullAccess()) {
            val custom = File(AppPrefs.localRoot)
            if (custom.exists() && custom.isDirectory) custom else Environment.getExternalStorageDirectory()
        } else {
            context.getExternalFilesDir(null) ?: context.filesDir
        }
        return if (f.exists() && f.isDirectory) f else context.filesDir
    }

    private fun toItem(f: File): FileItem {
        val canRead = f.canRead()
        return FileItem(
            name = f.name,
            path = f.absolutePath,
            isDir = f.isDirectory,
            size = if (f.isDirectory) 0 else f.length(),
            mtime = f.lastModified(),
            perms = permsOf(f),
            owner = "",
            isLink = try {
                @Suppress("DEPRECATION")
                android.os.Build.VERSION.SDK_INT >= 26 && java.nio.file.Files.isSymbolicLink(f.toPath())
            } catch (_: Throwable) {
                false
            }
        ).also { if (!canRead) Unit }
    }

    private fun permsOf(f: File): Int {
        var p = 0
        if (f.canRead()) p = p or 0b100100100
        if (f.canWrite()) p = p or 0b010010010
        if (f.canExecute()) p = p or 0b001001001
        if (f.isDirectory) p = p or 0x100
        return p
    }

    fun list(dir: File, showHidden: Boolean = AppPrefs.showHidden): List<FileItem> {
        val files = dir.listFiles()?.toMutableList() ?: mutableListOf()
        val items = files.mapNotNull { f ->
            if (!showHidden && f.name.startsWith(".")) return@mapNotNull null
            toItem(f)
        }.toMutableList()
        sortItems(items, "name")
        return items
    }

    fun mkdir(dir: File, name: String): Boolean {
        val target = File(dir, name)
        return if (target.exists()) false else target.mkdirs()
    }

    fun createFile(dir: File, name: String): Boolean {
        val target = File(dir, name)
        return if (target.exists()) false else target.createNewFile()
    }

    fun rename(f: File, newName: String): Boolean {
        val target = File(f.parentFile, newName)
        return if (target.exists()) false else f.renameTo(target)
    }

    fun delete(f: File): Boolean = if (f.isDirectory) f.deleteRecursively() else f.delete()

    fun chmod(f: File, perms: Int) {
        f.setReadable(perms and 0b100 != 0, false)
        f.setWritable(perms and 0b010 != 0, false)
        f.setExecutable(perms and 0b001 != 0, false)
        f.setReadable(perms and 0b100_000 != 0, true)
        f.setWritable(perms and 0b010_000 != 0, true)
        f.setExecutable(perms and 0b001_000 != 0, true)
    }

    fun copyOrMove(src: File, dst: File, move: Boolean) {
        if (move) {
            src.renameTo(dst)
            return
        }
        if (src.isDirectory) {
            dst.mkdirs()
            src.listFiles()?.forEach { copyOrMove(it, File(dst, it.name), false) }
        } else {
            dst.parentFile?.mkdirs()
            src.inputStream().use { input ->
                dst.outputStream().use { output -> input.copyTo(output) }
            }
        }
    }

    fun readText(f: File, maxBytes: Int = 1024 * 1024): String {
        if (f.length() > maxBytes) throw IllegalStateException("文件过大")
        return f.readText(Charsets.UTF_8)
    }

    fun writeText(f: File, text: String) {
        f.writeText(text, Charsets.UTF_8)
    }

    /** 递归列出目录下所有文件（相对路径 + 大小） */
    fun listFilesRecursive(dir: File, includeHidden: Boolean): List<Pair<String, Long>> {
        val out = ArrayList<Pair<String, Long>>()
        fun walk(base: String, rel: String) {
            val d = File(base, rel)
            val children = d.listFiles() ?: return
            for (c in children) {
                if (!includeHidden && c.name.startsWith(".")) continue
                val childRel = if (rel.isEmpty()) c.name else "$rel/${c.name}"
                if (c.isDirectory) walk(base, childRel) else out.add(childRel to c.length())
            }
        }
        walk(dir.absolutePath, "")
        return out
    }
}
