package con.android.ssh.term

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * 一个轻量但够用的 VT100 / ANSI / xterm 终端模拟器：
 * 字符网格 + 颜色属性、滚动区域、回滚缓冲、UTF-8、宽字符（CJK / emoji）支持。
 *
 * 纯 Kotlin 实现，不依赖任何 WebView 或 native 代码。
 */
class TerminalEmulator(
    var cols: Int,
    var rows: Int,
    var maxScrollback: Int = 3000
) {

    // ---------------- 行缓冲 ----------------
    class Line(val cols: Int) {
        val text = CharArray(cols)
        val attr = IntArray(cols)

        fun fill(ch: Char, a: Int) {
            for (i in 0 until cols) {
                text[i] = ch
                attr[i] = a
            }
        }

        /** 列数变化时保留原有内容 */
        fun copyFrom(o: Line) {
            val n = min(cols, o.cols)
            for (i in 0 until cols) {
                if (i < n) {
                    text[i] = o.text[i]
                    attr[i] = o.attr[i]
                } else {
                    text[i] = ' '
                    attr[i] = makeAttr(DEFAULT_FG, DEFAULT_BG, 0)
                }
            }
        }
    }

    private val screen = ArrayList<Line>(rows + 4)
    private val scrollback = ArrayList<Line>()

    // ---------------- 光标与状态 ----------------
    var cx = 0
    var cy = 0
    private var savedCx = 0
    private var savedCy = 0
    private var savedAttr = makeAttr(DEFAULT_FG, DEFAULT_BG, 0)

    private var fg = DEFAULT_FG
    private var bg = DEFAULT_BG
    private var flags = 0
    private var currentAttr = makeAttr(DEFAULT_FG, DEFAULT_BG, 0)
    private var wrapPending = false

    var scrollTop = 0
    var scrollBottom = rows - 1
    private var originMode = false
    var autoWrap = true
    var cursorVisible = true
    var bracketedPaste = false

    var title: String? = null
    var onTitleChanged: ((String) -> Unit)? = null
    var onBell: (() -> Unit)? = null
    var onContentChanged: (() -> Unit)? = null

    init {
        repeat(rows) { screen.add(newBlankLine()) }
    }

    private fun newBlankLine(): Line = Line(cols).also { it.fill(' ', currentAttr) }
    private fun makeAttrNow(): Int = makeAttr(fg, bg, flags)

    // ---------------- 缓冲区访问 ----------------

    val scrollbackSize: Int get() = scrollback.size
    val totalLines: Int get() = scrollback.size + rows

    fun getBufferedLine(index: Int): Line =
        if (index < scrollback.size) scrollback[index] else screen[index - scrollback.size]

    fun screenLine(r: Int): Line = screen[r]

    fun cursorBufferLine(): Int = scrollback.size + cy

    fun reset() {
        scrollback.clear()
        cx = 0
        cy = 0
        fg = DEFAULT_FG
        bg = DEFAULT_BG
        flags = 0
        currentAttr = makeAttrNow()
        wrapPending = false
        scrollTop = 0
        scrollBottom = rows - 1
        originMode = false
        autoWrap = true
        cursorVisible = true
        for (i in 0 until rows) screen[i].fill(' ', currentAttr)
        notifyChanged()
    }

    fun clearScrollback() {
        scrollback.clear()
        notifyChanged()
    }

    /** 只清屏幕内容（保留回滚） */
    fun clearScreen() {
        val blank = makeAttrNow()
        for (i in 0 until rows) screen[i].fill(' ', blank)
        cx = 0
        cy = 0
        wrapPending = false
        notifyChanged()
    }

    // ---------------- 尺寸 ----------------

    fun resize(newCols: Int, newRows: Int) {
        if (newCols <= 0 || newRows <= 0) return
        if (newCols == cols && newRows == rows) return
        cols = newCols
        rows = newRows

        while (screen.size < rows) screen.add(newBlankLine())
        while (screen.size > rows) pushScrollback(screen.removeAt(screen.size - 1))

        for (i in 0 until rows) {
            if (screen[i].cols != cols) {
                val nl = Line(cols)
                nl.copyFrom(screen[i])
                screen[i] = nl
            }
        }
        scrollTop = 0
        scrollBottom = rows - 1
        originMode = false
        cx = cx.coerceIn(0, max(0, cols - 1))
        cy = cy.coerceIn(0, max(0, rows - 1))
        wrapPending = false
        notifyChanged()
    }

    private fun pushScrollback(l: Line) {
        scrollback.add(l)
        while (scrollback.size > maxScrollback) scrollback.removeAt(0)
    }

    /**
     * 运行时修改回滚缓冲上限（设置页改了之后立即生效，不必重开会话）。
     * 调小时只丢弃最旧的行，当前屏幕内容不受影响。
     */
    fun applyMaxScrollback(n: Int) {
        val v = n.coerceIn(200, 20000)
        if (v == maxScrollback) return
        maxScrollback = v
        while (scrollback.size > maxScrollback) scrollback.removeAt(0)
        notifyChanged()
    }

    // ---------------- 输入解析 ----------------

    private var state = ST_GROUND
    private val csiParams = IntArray(32)
    private var csiCount = 0
    private var csiQuestion = false
    private val oscBuf = StringBuilder()

    private val uBuf = ByteArray(4)
    private var uLen = 0
    private var uNeed = 0

    /** 把远端数据写入终端 */
    @Synchronized
    fun write(data: ByteArray, length: Int = data.size) {
        for (i in 0 until length) processByte(data[i].toInt() and 0xFF)
        notifyChanged()
    }

    private fun processByte(b: Int) {
        if (uNeed > 0) {
            uBuf[uLen++] = b.toByte()
            if (uLen >= uNeed) {
                val s = String(uBuf, 0, uNeed, Charsets.UTF_8)
                uNeed = 0
                uLen = 0
                if (s.isNotEmpty()) printString(s)
            }
            return
        }

        when (state) {
            ST_GROUND -> when {
                b >= 0x80 -> {
                    uNeed = when {
                        b >= 0xF0 -> 4
                        b >= 0xE0 -> 3
                        b >= 0xC0 -> 2
                        else -> 0
                    }
                    if (uNeed == 0) return
                    uLen = 1
                    uBuf[0] = b.toByte()
                }
                b == 0x1B -> state = ST_ESC
                b == 0x0D -> { cx = 0; wrapPending = false }
                b == 0x0A -> newline(false)
                b == 0x09 -> tabForward(1)
                b == 0x08 -> { if (cx > 0) cx--; wrapPending = false }
                b == 0x07 -> onBell?.invoke()
                b == 0x0E || b == 0x0F || b == 0x00 -> Unit
                b < 0x20 -> Unit
                else -> printString(b.toChar().toString())
            }

            ST_ESC -> when (b.toChar()) {
                '[' -> {
                    state = ST_CSI
                    csiCount = 0
                    csiQuestion = false
                    csiParams.fill(-1)
                }
                ']' -> {
                    state = ST_OSC
                    oscBuf.setLength(0)
                }
                '7' -> { savedCx = cx; savedCy = cy; savedAttr = currentAttr; state = ST_GROUND }
                '8' -> { cx = savedCx; cy = savedCy; currentAttr = savedAttr; restoreAttrFromCurrent(); state = ST_GROUND }
                'D' -> { newline(false); state = ST_GROUND }
                'E' -> { newline(true); state = ST_GROUND }
                'M' -> { reverseIndex(); state = ST_GROUND }
                'c' -> { reset(); state = ST_GROUND }
                else -> state = ST_GROUND // 字符集 / keypad / DECALN 等，忽略
            }

            ST_CSI -> collectCsi(b)

            ST_OSC -> {
                if (b == 0x07 || b == 0x1B) finishOsc()
                else {
                    oscBuf.append(b.toChar())
                    if (oscBuf.length > 512) finishOsc()
                }
            }
        }
    }

    private fun finishOsc() {
        val s = oscBuf.toString()
        val semi = s.indexOf(';')
        if (semi > 0) {
            when (s.substring(0, semi)) {
                "0", "1", "2" -> {
                    title = s.substring(semi + 1)
                    onTitleChanged?.invoke(title ?: "")
                }
            }
        }
        oscBuf.setLength(0)
        state = ST_GROUND
    }

    private fun collectCsi(b: Int) {
        val c = b.toChar()
        when {
            c in '0'..'9' -> {
                val idx = if (csiCount == 0) 0 else csiCount - 1
                if (idx < csiParams.size) {
                    val cur = if (csiParams[idx] < 0) 0 else csiParams[idx]
                    csiParams[idx] = cur * 10 + (c - '0')
                    if (csiCount == 0) csiCount = 1
                }
            }
            c == ';' -> {
                csiCount++
                if (csiCount <= csiParams.size) csiParams[csiCount - 1] = -1
            }
            c == '?' -> csiQuestion = true
            c == ' ' || c == '!' || c == '"' || c == '$' || c == '\'' -> Unit
            else -> {
                dispatchCsi(c)
                state = ST_GROUND
            }
        }
    }

    private fun p(i: Int, def: Int): Int {
        val v = if (i < csiCount) csiParams[i] else -1
        return if (v < 0) def else v
    }

    private fun dispatchCsi(c: Char) {
        when (c) {
            '@' -> insertChars(p(0, 1))
            'A' -> { cy = max(scrollTop, cy - p(0, 1)); wrapPending = false }
            'B', 'e' -> { cy = min(scrollBottom, cy + p(0, 1)); wrapPending = false }
            'C', 'a' -> { cx = min(cols - 1, cx + p(0, 1)); wrapPending = false }
            'D' -> { cx = max(0, cx - p(0, 1)); wrapPending = false }
            'E' -> { cy = min(scrollBottom, cy + p(0, 1)); cx = 0; wrapPending = false }
            'F' -> { cy = max(scrollTop, cy - p(0, 1)); cx = 0; wrapPending = false }
            'G', '`' -> { cx = (p(0, 1) - 1).coerceIn(0, cols - 1); wrapPending = false }
            'H', 'f' -> {
                val r = p(0, 1) - 1
                cy = if (originMode) (scrollTop + r).coerceIn(scrollTop, scrollBottom) else r.coerceIn(0, rows - 1)
                cx = (p(1, 1) - 1).coerceIn(0, cols - 1)
                wrapPending = false
            }
            'I' -> tabForward(p(0, 1))
            'J' -> eraseInDisplay(p(0, 0))
            'K' -> eraseInLine(p(0, 0))
            'L' -> insertLines(p(0, 1))
            'M' -> deleteLines(p(0, 1))
            'P' -> deleteChars(p(0, 1))
            'S' -> scrollUp(p(0, 1))
            'T' -> scrollDown(p(0, 1))
            'X' -> eraseChars(p(0, 1))
            'Z' -> tabBackward(p(0, 1))
            'd' -> { cy = (p(0, 1) - 1).coerceIn(0, rows - 1); wrapPending = false }
            'h' -> setMode(true)
            'l' -> setMode(false)
            'm' -> sgr()
            'r' -> {
                val top = p(0, 1) - 1
                val bottom = p(1, rows) - 1
                if (top >= 0 && top < bottom && bottom < rows) {
                    scrollTop = top
                    scrollBottom = bottom
                } else {
                    scrollTop = 0
                    scrollBottom = rows - 1
                }
                cx = 0
                cy = 0
            }
            's' -> { savedCx = cx; savedCy = cy; savedAttr = currentAttr }
            'u' -> { cx = savedCx; cy = savedCy; currentAttr = savedAttr; restoreAttrFromCurrent() }
            else -> Unit // DSR / DA 等查询类指令不回应也不影响使用
        }
    }

    private fun restoreAttrFromCurrent() {
        fg = fgOf(currentAttr)
        bg = bgOf(currentAttr)
        flags = currentAttr and 0xFF0000
    }

    private fun setMode(enable: Boolean) {
        if (csiQuestion) {
            for (i in 0 until csiCount) {
                when (csiParams[i]) {
                    6 -> {
                        originMode = enable
                        cx = 0
                        cy = if (enable) scrollTop else 0
                    }
                    7 -> autoWrap = enable
                    25 -> cursorVisible = enable
                    2004 -> bracketedPaste = enable
                    1047, 1049 -> {
                        scrollback.clear()
                        val blank = makeAttrNow()
                        for (r in 0 until rows) screen[r].fill(' ', blank)
                    }
                }
            }
        }
    }

    private fun sgr() {
        if (csiCount == 0) {
            fg = DEFAULT_FG
            bg = DEFAULT_BG
            flags = 0
            currentAttr = makeAttrNow()
            return
        }
        var i = 0
        while (i < csiCount) {
            val v = csiParams[i]
            when (v) {
                0 -> { fg = DEFAULT_FG; bg = DEFAULT_BG; flags = 0 }
                1 -> flags = flags or F_BOLD
                2 -> flags = flags or F_FAINT
                3 -> flags = flags or F_ITALIC
                4 -> flags = flags or F_UNDERLINE
                5 -> flags = flags or F_BLINK
                7 -> flags = flags or F_REVERSE
                8 -> flags = flags or F_INVISIBLE
                21, 22 -> flags = flags and (F_BOLD or F_FAINT).inv()
                23 -> flags = flags and F_ITALIC.inv()
                24 -> flags = flags and F_UNDERLINE.inv()
                25 -> flags = flags and F_BLINK.inv()
                27 -> flags = flags and F_REVERSE.inv()
                28 -> flags = flags and F_INVISIBLE.inv()
                38 -> i += readColor(i)
                48 -> i += readColor(i)
                39 -> fg = DEFAULT_FG
                49 -> bg = DEFAULT_BG
                in 30..37 -> fg = v - 30
                in 40..47 -> bg = v - 40
                in 90..97 -> fg = v - 90 + 8
                in 100..107 -> bg = v - 100 + 8
            }
            i++
        }
        currentAttr = makeAttrNow()
    }

    /** 返回还需要跳过的参数个数 */
    private fun readColor(i: Int): Int {
        if (i + 1 >= csiCount) return 0
        return when (csiParams[i + 1]) {
            5 -> {
                if (i + 2 < csiCount) {
                    val idx = csiParams[i + 2].coerceIn(0, 255)
                    if (csiParams[i] == 38) fg = idx else bg = idx
                }
                2
            }
            2 -> {
                if (i + 4 < csiCount) {
                    val r = csiParams[i + 2].coerceIn(0, 255)
                    val g = csiParams[i + 3].coerceIn(0, 255)
                    val b = csiParams[i + 4].coerceIn(0, 255)
                    val idx = rgbToIndex(r, g, b)
                    if (csiParams[i] == 38) fg = idx else bg = idx
                }
                4
            }
            else -> 1
        }
    }

    private fun rgbToIndex(r: Int, g: Int, b: Int): Int {
        if (r == g && g == b) return when {
            r < 8 -> 16
            r > 248 -> 231
            else -> 232 + (r - 8) * 24 / 247
        }
        return 16 + 36 * cubeIndex(r) + 6 * cubeIndex(g) + cubeIndex(b)
    }

    private fun cubeIndex(v: Int): Int {
        val levels = intArrayOf(0, 0x5F, 0x87, 0xAF, 0xD7, 0xFF)
        var best = 0
        var bestDiff = Int.MAX_VALUE
        for (i in levels.indices) {
            val d = abs(v - levels[i])
            if (d < bestDiff) {
                bestDiff = d
                best = i
            }
        }
        return best
    }

    // ---------------- 编辑操作 ----------------

    private fun printString(s: String) {
        var idx = 0
        while (idx < s.length) {
            val cp = s.codePointAt(idx)
            val charCount = Character.charCount(cp)
            val str = s.substring(idx, idx + charCount)
            putGlyph(str, if (isWide(cp)) 2 else 1)
            idx += charCount
        }
    }

    private fun putGlyph(str: String, w: Int) {
        if (wrapPending) {
            cx = 0
            newline(false)
            wrapPending = false
        }
        if (cx + w > cols) {
            cx = 0
            newline(false)
        }
        val line = screen[cy]
        val a = makeAttrNow()
        line.text[cx] = str[0]
        line.attr[cx] = a or (if (w == 2) F_WIDE else 0)
        if (w == 2) {
            // 宽字符的第二格：emoji 用低代理填充，CJK 用空格占位
            line.text[cx + 1] = if (str.length > 1) str[1] else ' '
            line.attr[cx + 1] = a or F_WIDE_CONT
        }
        cx += w
        if (cx >= cols) {
            cx = cols - 1
            wrapPending = autoWrap
        }
    }

    private fun newline(carriageReturn: Boolean) {
        if (cy == scrollBottom) scrollUp(1) else if (cy < rows - 1) cy++
        if (carriageReturn) cx = 0
        wrapPending = false
    }

    private fun reverseIndex() {
        if (cy == scrollTop) scrollDown(1) else if (cy > 0) cy--
        wrapPending = false
    }

    private fun tabForward(n: Int) {
        repeat(n) {
            val next = ((cx / 8) + 1) * 8
            cx = if (next >= cols) cols - 1 else next
        }
        wrapPending = false
    }

    private fun tabBackward(n: Int) {
        repeat(n) {
            var t = (cx / 8) * 8
            if (t == cx && cx > 0) t -= 8
            cx = t.coerceAtLeast(0)
        }
        wrapPending = false
    }

    fun scrollUp(n: Int) {
        val times = n.coerceAtMost(scrollBottom - scrollTop + 1)
        repeat(times) {
            pushScrollback(screen.removeAt(scrollTop))
            screen.add(scrollBottom, Line(cols).also { it.fill(' ', makeAttrNow()) })
        }
    }

    fun scrollDown(n: Int) {
        val times = n.coerceAtMost(scrollBottom - scrollTop + 1)
        repeat(times) {
            screen.removeAt(scrollBottom)
            screen.add(scrollTop, Line(cols).also { it.fill(' ', makeAttrNow()) })
        }
    }

    private fun eraseInDisplay(mode: Int) {
        val blank = makeAttrNow()
        when (mode) {
            0 -> {
                eraseInLine(0)
                for (r in cy + 1 until rows) screen[r].fill(' ', blank)
            }
            1 -> {
                for (r in 0 until cy) screen[r].fill(' ', blank)
                eraseInLine(1)
            }
            2 -> for (r in 0 until rows) screen[r].fill(' ', blank)
            3 -> {
                for (r in 0 until rows) screen[r].fill(' ', blank)
                scrollback.clear()
            }
        }
        notifyChanged()
    }

    private fun eraseInLine(mode: Int) {
        val line = screen[cy]
        val blank = makeAttrNow()
        when (mode) {
            0 -> for (i in cx until cols) { line.text[i] = ' '; line.attr[i] = blank }
            1 -> for (i in 0..cx.coerceAtMost(cols - 1)) { line.text[i] = ' '; line.attr[i] = blank }
            2 -> line.fill(' ', blank)
        }
    }

    private fun eraseChars(n: Int) {
        val line = screen[cy]
        val blank = makeAttrNow()
        for (i in cx until min(cols, cx + n)) { line.text[i] = ' '; line.attr[i] = blank }
    }

    private fun insertChars(n: Int) {
        val line = screen[cy]
        val blank = makeAttrNow()
        val cnt = n.coerceAtMost(cols - cx)
        for (i in cols - 1 downTo cx + cnt) {
            line.text[i] = line.text[i - cnt]
            line.attr[i] = line.attr[i - cnt]
        }
        for (i in cx until cx + cnt) { line.text[i] = ' '; line.attr[i] = blank }
    }

    private fun deleteChars(n: Int) {
        val line = screen[cy]
        val blank = makeAttrNow()
        val cnt = n.coerceAtMost(cols - cx)
        for (i in cx until cols - cnt) {
            line.text[i] = line.text[i + cnt]
            line.attr[i] = line.attr[i + cnt]
        }
        for (i in cols - cnt until cols) { line.text[i] = ' '; line.attr[i] = blank }
    }

    private fun insertLines(n: Int) {
        if (cy < scrollTop || cy > scrollBottom) return
        repeat(n.coerceAtMost(scrollBottom - cy + 1)) {
            screen.removeAt(scrollBottom)
            screen.add(cy, Line(cols).also { it.fill(' ', makeAttrNow()) })
        }
        cx = 0
    }

    private fun deleteLines(n: Int) {
        if (cy < scrollTop || cy > scrollBottom) return
        repeat(n.coerceAtMost(scrollBottom - cy + 1)) {
            pushScrollback(screen.removeAt(cy))
            screen.add(scrollBottom, Line(cols).also { it.fill(' ', makeAttrNow()) })
        }
        cx = 0
    }

    // ---------------- 文本提取（选择 / 复制） ----------------

    fun getText(startLine: Int, startCol: Int, endLine: Int, endCol: Int): String {
        val sb = StringBuilder()
        for (l in startLine..endLine) {
            if (l < 0 || l >= totalLines) continue
            val line = getBufferedLine(l)
            val from = if (l == startLine) startCol.coerceIn(0, cols - 1) else 0
            val to = if (l == endLine) endCol.coerceIn(0, cols - 1) else cols - 1
            var lastNonSpace = sb.length
            for (c in from..to) {
                if (line.attr[c] and F_WIDE_CONT != 0) continue
                val ch = line.text[c]
                sb.append(if (ch.code == 0) ' ' else ch)
                if (ch != ' ') lastNonSpace = sb.length
            }
            if (l < endLine) sb.append('\n') else sb.setLength(lastNonSpace)
        }
        return sb.toString()
    }

    private fun notifyChanged() {
        onContentChanged?.invoke()
    }

    companion object {
        const val F_BOLD = 1 shl 16
        const val F_FAINT = 1 shl 17
        const val F_ITALIC = 1 shl 18
        const val F_UNDERLINE = 1 shl 19
        const val F_BLINK = 1 shl 20
        const val F_REVERSE = 1 shl 21
        const val F_INVISIBLE = 1 shl 22
        /** 宽字符的第一格 */
        const val F_WIDE = 1 shl 23
        /** 宽字符的续格，绘制与复制时跳过 */
        const val F_WIDE_CONT = 1 shl 24

        const val DEFAULT_FG = 7
        const val DEFAULT_BG = 0

        private const val ST_GROUND = 0
        private const val ST_ESC = 1
        private const val ST_CSI = 2
        private const val ST_OSC = 3

        fun makeAttr(fg: Int, bg: Int, flags: Int): Int =
            (fg and 0xFF) or ((bg and 0xFF) shl 8) or (flags and 0x7F0000)

        fun fgOf(attr: Int) = attr and 0xFF
        fun bgOf(attr: Int) = (attr shr 8) and 0xFF

        /** 256 色调色板 */
        val PALETTE = IntArray(256).also { p ->
            val base = intArrayOf(
                0xFF000000.toInt(), 0xFFCC0000.toInt(), 0xFF4E9A06.toInt(), 0xFFC4A000.toInt(),
                0xFF3465A4.toInt(), 0xFF75507B.toInt(), 0xFF06989A.toInt(), 0xFFD3D7CF.toInt(),
                0xFF555753.toInt(), 0xFFEF2929.toInt(), 0xFF8AE234.toInt(), 0xFFFCE94F.toInt(),
                0xFF729FCF.toInt(), 0xFFAD7FA8.toInt(), 0xFF34E2E2.toInt(), 0xFFEEEEEC.toInt()
            )
            System.arraycopy(base, 0, p, 0, 16)
            val levels = intArrayOf(0, 0x5F, 0x87, 0xAF, 0xD7, 0xFF)
            var i = 16
            for (r in 0..5) for (g in 0..5) for (b in 0..5) {
                p[i++] = 0xFF000000.toInt() or (levels[r] shl 16) or (levels[g] shl 8) or levels[b]
            }
            var v = 8
            while (i < 256) {
                p[i++] = 0xFF000000.toInt() or (v shl 16) or (v shl 8) or v
                v += 10
            }
        }

        /** 粗略的东亚宽字符 / emoji 判断 */
        fun isWide(cp: Int): Boolean = when (cp) {
            in 0x1100..0x115F -> true
            0x2329, 0x232A -> true
            in 0x2E80..0xA4CF -> true
            in 0xAC00..0xD7A3 -> true
            in 0xF900..0xFAFF -> true
            in 0xFE10..0xFE19 -> true
            in 0xFE30..0xFE6F -> true
            in 0xFF00..0xFF60 -> true
            in 0xFFE0..0xFFE6 -> true
            in 0x1F300..0x1F64F -> true
            in 0x1F900..0x1F9FF -> true
            in 0x20000..0x3FFFD -> true
            else -> false
        }
    }
}
