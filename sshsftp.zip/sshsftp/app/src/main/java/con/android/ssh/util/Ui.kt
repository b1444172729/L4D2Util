package con.android.ssh.util

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import con.android.ssh.R
import java.io.File

fun Context.toast(msg: CharSequence) {
    Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}

fun Context.longToast(msg: CharSequence) {
    Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}

/**
 * Fragment 版本。Fragment 本身不是 Context，
 * 直接调 toast() 会因 receiver 类型不匹配而编译失败，这里补一个重载。
 */
fun Fragment.toast(msg: CharSequence) {
    context?.let { Toast.makeText(it, msg, Toast.LENGTH_SHORT).show() }
}

fun Fragment.longToast(msg: CharSequence) {
    context?.let { Toast.makeText(it, msg, Toast.LENGTH_LONG).show() }
}

/** 通用单行输入对话框 */
fun inputDialog(
    context: Context,
    title: String,
    hint: String? = null,
    initial: String? = null,
    onOk: (String) -> Unit
) {
    val view = android.view.LayoutInflater.from(context).inflate(R.layout.dialog_input, null)
    val til = view.findViewById<TextInputLayout>(R.id.til)
    val et = view.findViewById<TextInputEditText>(R.id.input)
    til.hint = hint ?: title
    et.setText(initial ?: "")
    et.setSelection(et.text?.length ?: 0)
    MaterialAlertDialogBuilder(context)
        .setTitle(title)
        .setView(view)
        .setNegativeButton(R.string.cancel, null)
        .setPositiveButton(R.string.ok) { _, _ ->
            onOk(et.text?.toString()?.trim().orEmpty())
        }
        .show()
}

/** 二次确认对话框 */
fun confirmDialog(context: Context, title: String, message: String, onOk: () -> Unit) {
    MaterialAlertDialogBuilder(context)
        .setTitle(title)
        .setMessage(message)
        .setNegativeButton(R.string.cancel, null)
        .setPositiveButton(R.string.ok) { _, _ -> onOk() }
        .show()
}

/** 连接时输入密码 */
fun passwordDialog(
    context: Context,
    title: String,
    onOk: (String, Boolean) -> Unit
) {
    val view = android.view.LayoutInflater.from(context).inflate(R.layout.dialog_auth, null)
    val et = view.findViewById<TextInputEditText>(R.id.etPassword)
    val cb = view.findViewById<android.widget.CheckBox>(R.id.cbRemember)
    MaterialAlertDialogBuilder(context)
        .setTitle(title)
        .setView(view)
        .setNegativeButton(R.string.cancel, null)
        .setPositiveButton(R.string.ok) { _, _ ->
            onOk(et.text?.toString() ?: "", cb.isChecked)
        }
        .show()
}

/** 权限修改对话框（9 个勾选框 + 八进制显示） */
fun permissionsDialog(
    context: Context,
    current: Int,
    multiple: Boolean,
    onOk: (Int, Boolean) -> Unit
) {
    val view = android.view.LayoutInflater.from(context).inflate(R.layout.dialog_permissions, null)
    val boxes = mapOf(
        0b100000000 to view.findViewById<android.widget.CheckBox>(R.id.ur),
        0b010000000 to view.findViewById<android.widget.CheckBox>(R.id.uw),
        0b001000000 to view.findViewById<android.widget.CheckBox>(R.id.ux),
        0b000100000 to view.findViewById<android.widget.CheckBox>(R.id.gr),
        0b000010000 to view.findViewById<android.widget.CheckBox>(R.id.gw),
        0b000001000 to view.findViewById<android.widget.CheckBox>(R.id.gx),
        0b000000100 to view.findViewById<android.widget.CheckBox>(R.id.orx),
        0b000000010 to view.findViewById<android.widget.CheckBox>(R.id.ow),
        0b000000001 to view.findViewById<android.widget.CheckBox>(R.id.ox)
    )
    val tvOctal = view.findViewById<android.widget.TextView>(R.id.tvOctal)
    val applyAll = view.findViewById<android.widget.CheckBox>(R.id.applyAll)

    fun value(): Int {
        var v = 0
        boxes.forEach { (bit, box) -> if (box.isChecked) v = v or bit }
        return v
    }

    fun refresh() {
        tvOctal.text = String.format("%03o", value() and 0x1FF)
    }

    boxes.forEach { (bit, box) ->
        box.isChecked = current and bit != 0
        box.setOnCheckedChangeListener { _, _ -> refresh() }
    }
    refresh()
    if (multiple) applyAll.visibility = android.view.View.VISIBLE

    MaterialAlertDialogBuilder(context)
        .setTitle(R.string.change_permissions)
        .setView(view)
        .setNegativeButton(R.string.cancel, null)
        .setPositiveButton(R.string.ok) { _, _ -> onOk(value(), applyAll.isChecked) }
        .show()
}

/** 属性查看 */
fun propertiesDialog(context: Context, title: String, text: String) {
    MaterialAlertDialogBuilder(context)
        .setTitle(title)
        .setMessage(text)
        .setPositiveButton(R.string.ok, null)
        .show()
}

/** 用其它应用打开文件 */
fun openFileWith(context: Context, file: File, mime: String = "*/*") {
    return try {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mime)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, file.name))
    } catch (_: Throwable) {
        context.toast(context.getString(R.string.no_app_to_open))
    }
}
