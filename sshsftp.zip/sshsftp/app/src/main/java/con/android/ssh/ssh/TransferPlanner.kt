package con.android.ssh.ssh

import android.app.Activity
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.widget.CheckBox
import android.widget.TextView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import con.android.ssh.R
import con.android.ssh.data.AppPrefs
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

/**
 * 把"选中的文件或目录"展开成一组可执行的传输任务。
 * 目录递归展开；目标已存在时按策略（询问 / 覆盖 / 跳过 / 续传）处理。
 */
object TransferPlanner {

    fun plan(
        activity: Activity,
        hostId: String,
        upload: Boolean,
        sources: List<FileItem>,
        destDir: String,
        onDone: (List<TransferTask>) -> Unit
    ) {
        val main = Handler(Looper.getMainLooper())
        Thread {
            val tasks = try {
                build(activity, hostId, upload, sources, destDir)
            } catch (e: Throwable) {
                e.printStackTrace()
                emptyList<TransferTask>()
            }
            main.post { onDone(tasks) }
        }.start()
    }

    private fun build(
        activity: Activity,
        hostId: String,
        upload: Boolean,
        sources: List<FileItem>,
        destDir: String
    ): List<TransferTask> {
        val live = SessionRegistry.get(hostId)
        val out = ArrayList<TransferTask>()
        var applyAll: ConflictAction? = null
        var applyAllFlag = false

        fun handle(t: TransferTask, remotePath: String): Boolean {
            val policy = AppPrefs.conflictPolicy
            val action = when (policy) {
                "overwrite" -> ConflictAction.OVERWRITE
                "skip" -> ConflictAction.SKIP
                "resume" -> ConflictAction.RESUME
                else -> {
                    val pre = applyAll
                    if (pre != null) pre else {
                        val (a, all) = askUser(activity, upload, remotePath, t.localPath, t, live)
                        a.also { if (all) { applyAll = it; applyAllFlag = true } }
                    }
                }
            }
            return when (action) {
                ConflictAction.SKIP -> false
                ConflictAction.OVERWRITE -> { t.resumeOffset = 0; true }
                ConflictAction.RESUME -> { t.resumeOffset = existingSize(upload, t, live); true }
            }
        }

        for (src in sources) {
            if (src.isDir) {
                if (upload) {
                    val files = LocalFs.listFilesRecursive(File(src.path), true)
                    for ((rel, _) in files) {
                        val local = File(src.path, rel)
                        val remote = "$destDir/${src.name}/$rel".replace("//", "/")
                        val t = task(hostId, true, local.absolutePath, remote, "${src.name}/$rel", local.length())
                        if (handle(t, remote)) out.add(t)
                    }
                } else {
                    if (live == null) continue
                    val files = RemoteFs.listFilesRecursive(live, src.path, true)
                    for ((rel, size) in files) {
                        val remote = joinPath(src.path, rel)
                        val local = File(File(destDir, src.name), rel)
                        val t = task(hostId, false, local.absolutePath, remote, "${src.name}/$rel", size)
                        if (handle(t, remote)) out.add(t)
                    }
                }
            } else {
                if (upload) {
                    val remote = joinPath(destDir, src.name)
                    val size = File(src.path).length()
                    val t = task(hostId, true, src.path, remote, src.name, size)
                    if (handle(t, remote)) out.add(t)
                } else {
                    val local = File(destDir, src.name)
                    val t = task(hostId, false, local.absolutePath, src.path, src.name, src.size)
                    if (handle(t, src.path)) out.add(t)
                }
            }
        }
        return out
    }

    private fun task(
        hostId: String, upload: Boolean, localPath: String, remotePath: String, display: String, size: Long
    ) = TransferTask(
        hostId = hostId,
        upload = upload,
        localPath = localPath,
        remotePath = remotePath,
        displayName = display,
        size = size
    )

    private fun existingSize(upload: Boolean, t: TransferTask, live: LiveSession?): Long {
        val remote = live?.let { RemoteFs.sizeOf(it, t.remotePath) } ?: 0L
        val local = File(t.localPath).length()
        val known = if (upload) remote else local
        return if (known > 0 && known < t.size) known else 0L
    }

    private fun askUser(
        activity: Activity,
        upload: Boolean,
        remotePath: String,
        localPath: String,
        task: TransferTask,
        live: LiveSession?
    ): Pair<ConflictAction, Boolean> {
        val action = AtomicReference(ConflictAction.SKIP)
        val applyAll = AtomicBoolean(false)
        val latch = CountDownLatch(1)
        Handler(Looper.getMainLooper()).post {
            if (activity.isFinishing || activity.isDestroyed) {
                latch.countDown()
                return@post
            }
            val name = File(if (upload) remotePath else localPath).name
            val have = if (upload) {
                live?.let { RemoteFs.sizeOf(it, remotePath) } ?: 0L
            } else File(localPath).length()
            val view = LayoutInflater.from(activity).inflate(R.layout.dialog_conflict, null)
            view.findViewById<TextView>(R.id.tvConflict).text =
                activity.getString(R.string.overwrite_existing) + "\n" + name + "\n" +
                    activity.getString(R.string.resume_transfer, formatSize(have))
            val cb = view.findViewById<CheckBox>(R.id.cbApplyAll)
            MaterialAlertDialogBuilder(activity)
                .setTitle(name)
                .setView(view)
                .setCancelable(false)
                .setNeutralButton(R.string.skip) { _, _ ->
                    action.set(ConflictAction.SKIP); applyAll.set(cb.isChecked); latch.countDown()
                }
                .setNegativeButton(R.string.resume_action) { _, _ ->
                    action.set(ConflictAction.RESUME); applyAll.set(cb.isChecked); latch.countDown()
                }
                .setPositiveButton(R.string.overwrite) { _, _ ->
                    action.set(ConflictAction.OVERWRITE); applyAll.set(cb.isChecked); latch.countDown()
                }
                .setOnDismissListener { latch.countDown() }
                .show()
        }
        runCatching { latch.await() }
        return action.get() to applyAll.get()
    }
}
