package con.android.ssh.ssh

import android.app.Activity
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.widget.CheckBox
import android.widget.TextView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import con.android.ssh.R
import con.android.ssh.data.AppPrefs
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

/**
 * 把"选中的文件或目录"展开成一组可执行的传输任务。
 * 目录递归展开；目标已存在时按策略（询问 / 覆盖 / 跳过 / 续传）处理。
 */
object TransferPlanner {

    fun plan(
        activity: Activity,
        hostId: String,
        upload: Boolean,
        sources: List<FileItem>,
        destDir: String,
        onDone: (List<TransferTask>) -> Unit
    ) {
        val main = Handler(Looper.getMainLooper())
        Thread {
            val tasks = try {
                build(activity, hostId, upload, sources, destDir)
            } catch (e: Throwable) {
                e.printStackTrace()
                emptyList<TransferTask>()
            }
            main.post { onDone(tasks) }
        }.start()
    }

    private fun build(
        activity: Activity,
        hostId: String,
        upload: Boolean,
        sources: List<FileItem>,
        destDir: String
    ): List<TransferTask> {
        val live = SessionRegistry.get(hostId)
        val out = ArrayList<TransferTask>()
        var applyAll: ConflictAction? = null
        var applyAllFlag = false

        /**
         * 决定一个任务是否执行、以什么方式执行。
         *
         * 关键：必须先判断【目标是否已存在】。
         * 之前这里无条件直接弹冲突对话框，于是不管远端/本地有没有同名文件，
         * 每次上传下载都会问一遍"是否覆盖" —— 用户看到的是
         * "目标根本没有这个文件，却提示已存在"。
         * 目标不存在时直接放行，不打扰用户。
         */
        fun handle(t: TransferTask, remotePath: String): Boolean {
            // 目标不存在 ⇒ 无需询问，直接传输（从 0 开始）
            if (!existsTarget(upload, t)) {
                t.resumeOffset = 0
                return true
            }
            val policy = AppPrefs.conflictPolicy
            val action = when (policy) {
                "overwrite" -> ConflictAction.OVERWRITE
                "skip" -> ConflictAction.SKIP
                "resume" -> ConflictAction.RESUME
                else -> {
                    val pre = applyAll
                    if (pre != null) pre else {
                        val (a, all) = askUser(activity, upload, remotePath, t.localPath, t, live)
                        a.also { if (all) { applyAll = it; applyAllFlag = true } }
                    }
                }
            }
            return when (action) {
                ConflictAction.SKIP -> false
                ConflictAction.OVERWRITE -> { t.resumeOffset = 0; true }
                ConflictAction.RESUME -> { t.resumeOffset = existingSize(upload, t, live); true }
            }
        }

        for (src in sources) {
            if (src.isDir) {
                if (upload) {
                    val files = LocalFs.listFilesRecursive(File(src.path), true)
                    for ((rel, _) in files) {
                        val local = File(src.path, rel)
                        val remote = "$destDir/${src.name}/$rel".replace("//", "/")
                        val t = task(hostId, true, local.absolutePath, remote, "${src.name}/$rel", local.length())
                        if (handle(t, remote)) out.add(t)
                    }
                } else {
                    if (live == null) continue
                    val files = RemoteFs.listFilesRecursive(live, src.path, true)
                    for ((rel, size) in files) {
                        val remote = joinPath(src.path, rel)
                        val local = File(File(destDir, src.name), rel)
                        val t = task(hostId, false, local.absolutePath, remote, "${src.name}/$rel", size)
                        if (handle(t, remote)) out.add(t)
                    }
                }
            } else {
                if (upload) {
                    val remote = joinPath(destDir, src.name)
                    val size = File(src.path).length()
                    val t = task(hostId, true, src.path, remote, src.name, size)
                    if (handle(t, remote)) out.add(t)
                } else {
                    val local = File(destDir, src.name)
                    val t = task(hostId, false, local.absolutePath, src.path, src.name, src.size)
                    if (handle(t, src.path)) out.add(t)
                }
            }
        }
        return out
    }

    private fun task(
        hostId: String, upload: Boolean, localPath: String, remotePath: String, display: String, size: Long
    ) = TransferTask(
        hostId = hostId,
        upload = upload,
        localPath = localPath,
        remotePath = remotePath,
        displayName = display,
        size = size
    )

    /**
     * 目标是否已存在。
     * 上传看远端路径，下载看本地路径。
     *
     * 注意用 stat 判断存在性，不能用 sizeOf：
     * sizeOf 在文件不存在时返回 0，与"存在但长度为 0"无法区分，
     * 空文件会被误判为不存在（反之把不存在误判为存在则取决于调用方式）。
     */
    private fun existsTarget(upload: Boolean, t: TransferTask): Boolean {
        return if (upload) {
            val live = SessionRegistry.get(t.hostId) ?: return false
            if (!live.isAlive) false else RemoteFs.exists(live, t.remotePath)
        } else {
            File(t.localPath).exists()
        }
    }

    private fun existingSize(upload: Boolean, t: TransferTask, live: LiveSession?): Long {
        val remote = live?.let { RemoteFs.sizeOf(it, t.remotePath) } ?: 0L
        val local = File(t.localPath).length()
        val known = if (upload) remote else local
        return if (known > 0 && known < t.size) known else 0L
    }

    private fun askUser(
        activity: Activity,
        upload: Boolean,
        remotePath: String,
        localPath: String,
        task: TransferTask,
        live: LiveSession?
    ): Pair<ConflictAction, Boolean> {
        val action = AtomicReference(ConflictAction.SKIP)
        val applyAll = AtomicBoolean(false)
        val latch = CountDownLatch(1)
        Handler(Looper.getMainLooper()).post {
            if (activity.isFinishing || activity.isDestroyed) {
                latch.countDown()
                return@post
            }
            val name = File(if (upload) remotePath else localPath).name
            val have = if (upload) {
                live?.let { RemoteFs.sizeOf(it, remotePath) } ?: 0L
            } else File(localPath).length()
            val view = LayoutInflater.from(activity).inflate(R.layout.dialog_conflict, null)
            view.findViewById<TextView>(R.id.tvConflict).text =
                activity.getString(R.string.overwrite_existing) + "\n" + name + "\n" +
                    activity.getString(R.string.resume_transfer, formatSize(have))
            val cb = view.findViewById<CheckBox>(R.id.cbApplyAll)
            MaterialAlertDialogBuilder(activity)
                .setTitle(name)
                .setView(view)
                .setCancelable(false)
                .setNeutralButton(R.string.skip) { _, _ ->
                    action.set(ConflictAction.SKIP); applyAll.set(cb.isChecked); latch.countDown()
                }
                .setNegativeButton(R.string.resume_action) { _, _ ->
                    action.set(ConflictAction.RESUME); applyAll.set(cb.isChecked); latch.countDown()
                }
                .setPositiveButton(R.string.overwrite) { _, _ ->
                    action.set(ConflictAction.OVERWRITE); applyAll.set(cb.isChecked); latch.countDown()
                }
                .setOnDismissListener { latch.countDown() }
                .show()
        }
        runCatching { latch.await() }
        return action.get() to applyAll.get()
    }
}
