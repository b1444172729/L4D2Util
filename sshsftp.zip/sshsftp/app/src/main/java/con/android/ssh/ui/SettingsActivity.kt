package con.android.ssh.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.preference.EditTextPreference
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat
import com.google.android.material.appbar.MaterialToolbar
import con.android.ssh.R
import con.android.ssh.data.AppPrefs
import con.android.ssh.data.HostStore
import con.android.ssh.util.toast

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // 重建后的新实例：清掉待重建标记，避免兜底逻辑再重建一次
        pendingTheme = null
        setContentView(R.layout.activity_settings)
        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        toolbar.setNavigationOnClickListener { finish() }
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.settingsContainer, SettingsFragment())
                .commit()
        }
    }

    /**
     * 主题切换后由 Fragment 调用。
     *
     * 两个要点：
     *
     * 1) 必须用回调传来的 newValue：OnPreferenceChangeListener 在值写入
     *    SharedPreferences 之前就触发，此时 AppPrefs 读到的还是旧值。
     *
     * 2) 只调用 setDefaultNightMode，【不要】再自己 recreate()。
     *    setDefaultNightMode 内部会遍历所有存活的 delegate 并逐个
     *    applyDayNight()，对未声明 configChanges 的 Activity 会自动触发一次
     *    重建。再手动 recreate() 就是第二次重建 —— 这正是"闪两次"的根因
     *    （第一闪是 AppCompat 的重建，第二次是我们自己的）。
     *
     * 已经是当前主题时直接返回，一次都不重建，也就不会有任何闪烁。
     */
    fun applyThemeNow(newValue: Any?) {
        val raw = newValue as? String ?: return
        // 与"当前已生效"的主题相同 ⇒ 什么都不做，连一次重建都没有
        if (raw == AppPrefs.themeRaw) {
            con.android.ssh.util.ThemeGuard.markApplied(raw)
            return
        }
        pendingTheme = raw
        // 先标记，再切换：AppCompat 重建其它界面时它们一进来就能看到新值，
        // 不会各自再触发一次重建
        con.android.ssh.util.ThemeGuard.markApplied(raw)
        AppCompatDelegate.setDefaultNightMode(AppPrefs.nightModeOf(raw))

        // 兜底：正常情况下 setDefaultNightMode 会让 AppCompat 自动重建本 Activity，
        // 重建后新实例的 onCreate 会把 pendingTheme 清空，这里的检查就会跳过。
        // 万一某些机型/版本没有自动重建（pendingTheme 仍等于本次目标值），
        // 再补一次重建 —— 且只会补一次。
        window?.decorView?.postDelayed({
            if (isFinishing || isDestroyed) return@postDelayed
            if (pendingTheme == raw) {
                pendingTheme = null
                runCatching { recreate() }
            }
        }, 250)
    }

    companion object {
        /** 已请求、但尚未完成重建的主题值；重建后的新实例会在 onCreate 清空它 */
        @Volatile
        private var pendingTheme: String? = null
    }

    class SettingsFragment : PreferenceFragmentCompat() {

        override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
            setPreferencesFromResource(R.xml.preferences, rootKey)

            findPreference<Preference>("version")?.summary =
                getString(R.string.set_about_summary) + "\n" + getString(R.string.set_version, "1.0.0")

            findPreference<EditTextPreference>("scrollback")?.setOnBindEditTextListener { edit ->
                edit.inputType = android.text.InputType.TYPE_CLASS_NUMBER
            }
            findPreference<EditTextPreference>("keepalive")?.setOnBindEditTextListener { edit ->
                edit.inputType = android.text.InputType.TYPE_CLASS_NUMBER
            }
            findPreference<EditTextPreference>("shortcuts")?.setOnBindEditTextListener { edit ->
                edit.setSingleLine(false)
                edit.minLines = 6
            }

            findPreference<Preference>("known_hosts")?.setOnPreferenceClickListener {
                val n = HostStore.clearKnownHosts()
                toast(requireContext().getString(R.string.known_hosts_cleared, n))
                true
            }

            // 按键栏顺序：打开拖动排序对话框
            findPreference<Preference>("keybar_order")?.setOnPreferenceClickListener {
                KeyBarOrderDialog().show(parentFragmentManager, "keybar_order")
                true
            }

            // 主题：改完立即切，不必重启应用
            findPreference<Preference>("theme")?.setOnPreferenceChangeListener { _, newValue ->
                (activity as? SettingsActivity)?.applyThemeNow(newValue)
                true
            }

            // 其余设置：写入 SharedPreferences 即可，一律不弹提示。
            // AppPrefs 的监听器会通知当前活着的界面即时重刷；
            // 处于停止态的界面会在 onResume 里整体重刷一次。
            // 只有"清除已保存的主机密钥"保留了 toast —— 那是一个真正的动作，
            // 需要告知清掉了多少条。
        }
    }
}
