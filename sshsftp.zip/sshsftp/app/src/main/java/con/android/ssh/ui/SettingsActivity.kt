package con.android.ssh.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.preference.EditTextPreference
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat
import com.google.android.material.appbar.MaterialToolbar
import con.android.ssh.R
import con.android.ssh.data.AppPrefs
import con.android.ssh.data.HostStore
import con.android.ssh.util.toast

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        toolbar.setNavigationOnClickListener { finish() }
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.settingsContainer, SettingsFragment())
                .commit()
        }
    }

    /**
     * 主题切换后由 Fragment 调用。
     *
     * 必须用回调传来的 newValue：OnPreferenceChangeListener 在值写入
     * SharedPreferences 之前就触发，此时 AppPrefs.nightMode 读到的还是旧值，
     * 直接读会导致第一次切换无效、要切两次才对。
     *
     * AppCompatDelegate.setDefaultNightMode 只改"后续新建"的界面，
     * 已存在的 Activity 必须自己重建才会重新 inflate 布局。
     * recreate() 只重建当前这一屏的视图，瞬间完成，用户感知不到。
     */
    fun applyThemeNow(newValue: Any?) {
        val raw = newValue as? String ?: AppPrefs.themeRaw
        AppCompatDelegate.setDefaultNightMode(AppPrefs.nightModeOf(raw))
        con.android.ssh.util.ThemeGuard.markApplied(raw)
        // 稍作延迟：等 Preference 把值真正写入后再重建，避免状态不一致
        window?.decorView?.post { runCatching { recreate() } } ?: recreate()
    }

    class SettingsFragment : PreferenceFragmentCompat() {

        override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
            setPreferencesFromResource(R.xml.preferences, rootKey)

            findPreference<Preference>("version")?.summary =
                getString(R.string.set_about_summary) + "\n" + getString(R.string.set_version, "1.0.0")

            findPreference<EditTextPreference>("scrollback")?.setOnBindEditTextListener { edit ->
                edit.inputType = android.text.InputType.TYPE_CLASS_NUMBER
            }
            findPreference<EditTextPreference>("keepalive")?.setOnBindEditTextListener { edit ->
                edit.inputType = android.text.InputType.TYPE_CLASS_NUMBER
            }
            findPreference<EditTextPreference>("shortcuts")?.setOnBindEditTextListener { edit ->
                edit.setSingleLine(false)
                edit.minLines = 6
            }

            findPreference<Preference>("known_hosts")?.setOnPreferenceClickListener {
                val n = HostStore.clearKnownHosts()
                toast(requireContext().getString(R.string.known_hosts_cleared, n))
                true
            }

            // 按键栏顺序：打开拖动排序对话框
            findPreference<Preference>("keybar_order")?.setOnPreferenceClickListener {
                KeyBarOrderDialog().show(parentFragmentManager, "keybar_order")
                true
            }

            // 主题：改完立即切，不必重启应用
            findPreference<Preference>("theme")?.setOnPreferenceChangeListener { _, newValue ->
                (activity as? SettingsActivity)?.applyThemeNow(newValue)
                true
            }

            // 其余设置：写入 SharedPreferences 即可。
            // AppPrefs 的监听器会通知当前还活着的界面（终端页等）即时重刷；
            // 处于停止态的界面会在 onResume 里整体重刷一次。
            // 仅"下次连接才生效"的几项给出明确提示，避免用户以为没生效。
            val nextConnect = listOf("term_type", "keepalive", "compression")
            nextConnect.forEach { key ->
                findPreference<Preference>(key)?.setOnPreferenceChangeListener { _, _ ->
                    toast(requireContext().getString(R.string.pref_applied_next_connect))
                    true
                }
            }

            // 字号 / 回滚 / 按键栏等即时生效项：无需额外处理，
            // 但给个反馈让用户知道已经生效
            val instant = listOf("font_size", "scrollback", "keybar", "bell",
                "show_hidden", "local_root", "conflict")
            instant.forEach { key ->
                findPreference<Preference>(key)?.setOnPreferenceChangeListener { _, _ ->
                    toast(requireContext().getString(R.string.pref_applied_now))
                    true
                }
            }
        }
    }
}
