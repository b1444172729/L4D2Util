package con.android.ssh.term

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.inputmethod.BaseInputConnection
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputMethodManager
import con.android.ssh.data.AppPrefs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

/**
 * 自绘终端视图：
 * - 双指缩放字号（并把字号写回设置持久化）
 * - 上下拖动查看回滚、长按拖选复制
 * - 支持软键盘（含中文输入）与硬件键盘（Ctrl / Alt / 功能键）
 */
class TerminalView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyle: Int = 0
) : View(context, attrs, defStyle) {

    /** 用户输入回调（把字节发给远端） */
    var onInput: ((ByteArray) -> Unit)? = null
    /** 终端尺寸变化回调（用于同步 PTY 窗口大小） */
    var onSizeChanged: ((cols: Int, rows: Int) -> Unit)? = null

    var emulator: TerminalEmulator? = null
        set(value) {
            field = value
            value?.onContentChanged = { onContentChanged() }
            value?.onBell = { vibrate() }
            lastTotalLines = value?.totalLines ?: 0
            updateTermSize(true)
            postInvalidate()
        }

    /** 上次记录的总行数，用于算出这次新增了多少行 */
    private var lastTotalLines = 0

    /**
     * 远端有新输出。
     *
     * - 贴底时（scrollOffset == 0）：保持贴底，新内容自动滚进视野；
     * - 正在看历史时（scrollOffset > 0）：把偏移同步加上新增行数，
     *   让用户正在看的那几行停在屏幕原处。否则总行数一涨，
     *   视野就会被往下顶 —— 表现为"文本自己往下跑"。
     */
    private fun onContentChanged() {
        val emu = emulator
        if (emu != null) {
            val total = emu.totalLines
            val grew = total - lastTotalLines
            if (grew > 0 && scrollOffset > 0) {
                scrollOffset = (scrollOffset + grew).coerceIn(0, maxScrollOffset())
            }
            lastTotalLines = total
        }
        postInvalidate()
    }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.MONOSPACE
    }
    private val cursorPaint = Paint()

    private var cellW = 8f
    private var cellH = 16f
    private var baseLine = 12f

    /** 回滚偏移：0 表示贴着最新内容 */
    private var scrollOffset = 0

    private var ctrlOn = false
    private var altOn = false

    private var selecting = false
    private var hasSelection = false
    private var selStartLine = 0
    private var selStartCol = 0
    private var selEndLine = 0
    private var selEndCol = 0

    private val gestureDetector: GestureDetector
    private val scaleDetector: ScaleGestureDetector

    private var fontSizeSp: Int = AppPrefs.fontSizeSp
    private var scaleFactor = 1f

    init {
        val dp = resources.displayMetrics.density
        setPadding((6 * dp).toInt(), (4 * dp).toInt(), (6 * dp).toInt(), (4 * dp).toInt())
        isFocusable = true
        isFocusableInTouchMode = true
        cursorPaint.color = 0xFF55FF55.toInt()
        cursorPaint.alpha = 120

        gestureDetector = GestureDetector(context, GestureListener())
        gestureDetector.setIsLongpressEnabled(true)
        scaleDetector = ScaleGestureDetector(context, ScaleListener())
    }

    // ---------------- 尺寸 ----------------

    private fun applyFont() {
        val sizeSp = (fontSizeSp * scaleFactor).coerceIn(6f, 48f)
        paint.textSize = sizeSp * resources.displayMetrics.scaledDensity
        paint.typeface = Typeface.MONOSPACE
        val fm = paint.fontMetrics
        cellW = paint.measureText("M")
        cellH = ceil((fm.descent - fm.ascent).toDouble()).toFloat() + 1f
        baseLine = -fm.ascent + 0.5f
    }

    private fun updateTermSize(force: Boolean = false) {
        val emu = emulator ?: return
        applyFont()
        val availW = (width - paddingLeft - paddingRight).toFloat()
        val availH = (height - paddingTop - paddingBottom).toFloat()
        val cols = max(2, (availW / cellW).toInt())
        val rows = max(2, (availH / cellH).toInt())
        if (force || cols != emu.cols || rows != emu.rows) {
            emu.resize(cols, rows)
            onSizeChanged?.invoke(cols, rows)
        }
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        updateTermSize()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        fontSizeSp = AppPrefs.fontSizeSp
        updateTermSize(true)
    }

    /**
     * 重新读取设置里的字号并重排。
     * 设置页改字号后调用它即可立即生效（原来只有 View 重新 attach 才会读一次）。
     */
    fun applyPrefs() {
        fontSizeSp = AppPrefs.fontSizeSp
        applyCursorColor()
        updateTermSize(true)
    }

    /**
     * 光标色跟随主题。浅色主题下原来的亮绿 #55FF55 在白底上对比度极低，
     * 几乎看不见，换成深青；深色主题保持亮绿。
     */
    private fun applyCursorColor() {
        cursorPaint.color = if (TerminalEmulator.lightTheme)
            0xFF00897B.toInt() else 0xFF55FF55.toInt()
        cursorPaint.alpha = 120
    }

    // ---------------- 缩放 ----------------

    fun zoom(factorDelta: Float) {
        scaleFactor = (scaleFactor * factorDelta).coerceIn(0.5f, 3.0f)
        updateTermSize(true)
    }

    fun zoomIn() = zoom(1.15f)
    fun zoomOut() = zoom(1f / 1.15f)

    fun resetZoom() {
        scaleFactor = 1f
        updateTermSize(true)
    }

    private inner class ScaleListener : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            scaleFactor = (scaleFactor * detector.scaleFactor).coerceIn(0.5f, 3.0f)
            updateTermSize(true)
            return true
        }
    }

    // ---------------- 滚动 ----------------

    private fun maxScrollOffset(): Int {
        val emu = emulator ?: return 0
        return max(0, emu.totalLines - emu.rows)
    }

    private fun topLine(): Int {
        val emu = emulator ?: return 0
        val off = scrollOffset.coerceIn(0, maxScrollOffset())
        return emu.totalLines - emu.rows - off
    }

    /** 距底部多少行：0 = 贴底（最新一行），越大表示看得越早 */
    fun isAtBottom(): Boolean = scrollOffset <= 0

    fun scrollToBottom() {
        scrollOffset = 0
        scrollRemainder = 0f
        postInvalidate()
    }

    /** dir > 0 向下翻（走向更新的内容），dir < 0 向上翻（走向历史） */
    fun scrollPage(dir: Int) {
        val emu = emulator ?: return
        scrollOffset = (scrollOffset - dir * emu.rows / 2).coerceIn(0, maxScrollOffset())
        scrollRemainder = 0f
        postInvalidate()
    }

    /** 不足一行的位移余量，慢速滑动时累积，避免小位移被整行取整吃掉 */
    private var scrollRemainder = 0f

    /**
     * 按手指位移滚动。
     *
     * @param dy Android 的 distanceY（= 上一位置 − 当前位置），手指【向上】滑时为正。
     *
     * 方向约定（与常规列表一致）：
     *   手指上滑 ⇒ 内容整体向上移 ⇒ 视野走向【更新】的行 ⇒ scrollOffset 减小，
     *             减到 0（最后一行）就停住；
     *   手指向下滑 ⇒ 视野走向【更早】的历史 ⇒ scrollOffset 增大，
     *             增到回滚区顶部就停住。
     * 由于 scrollOffset 越大代表离底部越远（越早），这里对 dy 取负号。
     * （此前用的是正号，方向正好相反：上滑反而在往历史里翻。）
     */
    private fun scrollByPixels(dy: Float) {
        val max = maxScrollOffset()
        val delta = -dy + scrollRemainder
        val lines = (delta / cellH).toInt()
        scrollRemainder = delta - lines * cellH
        if (lines == 0) return
        val next = (scrollOffset + lines).coerceIn(0, max)
        if (next == scrollOffset) {
            // 已经到边界，清掉余量，避免在边界外继续"攒"位移
            scrollRemainder = 0f
            return
        }
        scrollOffset = next
        invalidate()
    }

    // ---------------- 手势 ----------------

    private inner class GestureListener : GestureDetector.SimpleOnGestureListener() {

        override fun onDown(e: MotionEvent): Boolean = true

        override fun onSingleTapUp(e: MotionEvent): Boolean {
            if (hasSelection) {
                hasSelection = false
                selecting = false
                invalidate()
            }
            requestFocus()
            showKeyboard(true)
            return true
        }

        override fun onLongPress(e: MotionEvent) {
            val cell = cellAt(e.x, e.y)
            selStartLine = cell.first
            selStartCol = cell.second
            selEndLine = cell.first
            selEndCol = cell.second
            hasSelection = true
            selecting = true
            invalidate()
        }

        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
            if (selecting) return false
            scrollByPixels(distanceY)
            return true
        }

        override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
            if (selecting) return false
            // velocityY 向下为正、向上为负。
            // 向上甩 ⇒ 走向【更新】的内容 ⇒ scrollOffset 减小 —— 与 onScroll 一致。
            val lines = (velocityY / cellH / 8).toInt()
            if (lines != 0) {
                val next = (scrollOffset + lines).coerceIn(0, maxScrollOffset())
                if (next != scrollOffset) {
                    scrollOffset = next
                    invalidate()
                }
            }
            scrollRemainder = 0f
            return true
        }

        override fun onDoubleTap(e: MotionEvent): Boolean {
            val cell = cellAt(e.x, e.y)
            selectWordAt(cell.first, cell.second)
            return true
        }
    }

    private fun cellAt(x: Float, y: Float): Pair<Int, Int> {
        val emu = emulator ?: return 0 to 0
        val col = ((x - paddingLeft) / cellW).toInt().coerceIn(0, emu.cols - 1)
        val row = ((y - paddingTop) / cellH).toInt().coerceIn(0, emu.rows - 1)
        return (topLine() + row) to col
    }

    private fun selectWordAt(line: Int, col: Int) {
        val emu = emulator ?: return
        if (line < 0 || line >= emu.totalLines) return
        val l = emu.getBufferedLine(line)
        if (l.text[col] == ' ') return
        var s = col
        var e = col
        while (s > 0 && l.text[s - 1] != ' ') s--
        while (e < emu.cols - 1 && l.text[e + 1] != ' ') e++
        selStartLine = line
        selStartCol = s
        selEndLine = line
        selEndCol = e
        hasSelection = true
        selecting = false
        invalidate()
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        if (scaleDetector.isInProgress) return true
        if (selecting) {
            when (event.actionMasked) {
                MotionEvent.ACTION_MOVE -> {
                    val cell = cellAt(event.x, event.y)
                    selEndLine = cell.first
                    selEndCol = cell.second
                    invalidate()
                    return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    selecting = false
                    return true
                }
            }
        }
        return gestureDetector.onTouchEvent(event) || super.onTouchEvent(event)
    }

    // ---------------- 选择 ----------------

    fun getSelectedText(): String? {
        val emu = emulator ?: return null
        if (!hasSelection) return null
        val (sl, sc, el, ec) = normalizedSelection() ?: return null
        return emu.getText(sl, sc, el, ec)
    }

    fun clearSelection() {
        hasSelection = false
        selecting = false
        invalidate()
    }

    private data class Sel(val sl: Int, val sc: Int, val el: Int, val ec: Int)

    private fun normalizedSelection(): Sel? {
        if (selStartLine > selEndLine || (selStartLine == selEndLine && selStartCol > selEndCol)) {
            return Sel(selEndLine, selEndCol, selStartLine, selStartCol)
        }
        return Sel(selStartLine, selStartCol, selEndLine, selEndCol)
    }

    private fun inSelection(line: Int, col: Int): Boolean {
        if (!hasSelection) return false
        val s = normalizedSelection() ?: return false
        return when {
            line < s.sl || line > s.el -> false
            line == s.sl && line == s.el -> col in s.sc..s.ec
            line == s.sl -> col >= s.sc
            line == s.el -> col <= s.ec
            else -> true
        }
    }

    // ---------------- 绘制 ----------------

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val emu = emulator ?: return
        canvas.drawColor(TerminalEmulator.PALETTE[0])
        val top = topLine()
        val cols = emu.cols
        val rows = emu.rows

        for (r in 0 until rows) {
            val lineIndex = top + r
            if (lineIndex < 0 || lineIndex >= emu.totalLines) continue
            val line = emu.getBufferedLine(lineIndex)
            val yTop = paddingTop + r * cellH
            val baseline = yTop + baseLine
            drawLineBackground(canvas, line, cols, yTop, lineIndex)
            drawLineText(canvas, line, cols, baseline, lineIndex)
        }
        drawCursor(canvas, emu, top)
    }

    private fun drawLineBackground(canvas: Canvas, line: TerminalEmulator.Line, cols: Int, yTop: Float, lineIndex: Int) {
        var c = 0
        while (c < cols) {
            val attr = line.attr[c]
            val sel = inSelection(lineIndex, c)
            val bgIdx = if (attr and TerminalEmulator.F_REVERSE != 0) TerminalEmulator.fgOf(attr) else TerminalEmulator.bgOf(attr)
            val bgDefault = bgIdx == 0
            if (!sel) {
                if (bgDefault) { c++; continue }
            }
            // 合并连续的同背景格子
            var e = c + 1
            while (e < cols) {
                val a2 = line.attr[e]
                val b2 = if (a2 and TerminalEmulator.F_REVERSE != 0) TerminalEmulator.fgOf(a2) else TerminalEmulator.bgOf(a2)
                if (b2 != bgIdx || inSelection(lineIndex, e) != sel) break
                e++
            }
            val paintBg = bgPaint
            paintBg.color = if (sel) 0x6658A6FF else TerminalEmulator.PALETTE[bgIdx]
            canvas.drawRect(
                paddingLeft + c * cellW,
                yTop,
                paddingLeft + e * cellW,
                yTop + cellH,
                paintBg
            )
            c = e
        }
    }

    private val bgPaint = Paint()

    private fun drawLineText(canvas: Canvas, line: TerminalEmulator.Line, cols: Int, baseline: Float, lineIndex: Int) {
        var c = 0
        while (c < cols) {
            val attr = line.attr[c]
            if (attr and TerminalEmulator.F_WIDE_CONT != 0) { c++; continue }
            if (attr and TerminalEmulator.F_INVISIBLE != 0) { c++; continue }

            val rev = attr and TerminalEmulator.F_REVERSE != 0
            val fgIdx = if (rev) TerminalEmulator.bgOf(attr) else TerminalEmulator.fgOf(attr)
            val bgIdx = if (rev) TerminalEmulator.fgOf(attr) else TerminalEmulator.bgOf(attr)
            val selected = inSelection(lineIndex, c)

            applyTextStyle(attr, fgIdx, bgIdx, selected)

            val wide = attr and TerminalEmulator.F_WIDE != 0
            if (wide) {
                // 宽字符：CJK 只画首格字符，emoji 用高低代理拼起来画，占 2 列
                val s = if (c + 1 < cols && line.text[c + 1] != ' ') {
                    String(charArrayOf(line.text[c], line.text[c + 1]))
                } else {
                    line.text[c].toString()
                }
                if (s != " ") canvas.drawText(s, paddingLeft + c * cellW, baseline, paint)
                c += 2
                continue
            }

            val ch = line.text[c]
            if (ch.code < 0x80) {
                // ASCII：合并连续同属性字符，一次 drawText 画完
                val sb = StringBuilder()
                var e = c
                while (e < cols && line.attr[e] == attr && line.text[e].code < 0x80) {
                    sb.append(line.text[e])
                    e++
                }
                while (sb.isNotEmpty() && sb[sb.length - 1] == ' ') sb.deleteCharAt(sb.length - 1)
                if (sb.isNotEmpty()) canvas.drawText(sb.toString(), paddingLeft + c * cellW, baseline, paint)
                c = e
            } else {
                // 非 ASCII：逐字符绝对定位，避免字体 advance 不一致导致错位
                if (ch != ' ') canvas.drawText(ch.toString(), paddingLeft + c * cellW, baseline, paint)
                c++
            }
        }
        paint.isUnderlineText = false
        paint.textSkewX = 0f
        paint.isFakeBoldText = false
        paint.alpha = 255
    }

    private fun applyTextStyle(attr: Int, fgIdx: Int, bgIdx: Int, selected: Boolean) {
        val faint = attr and TerminalEmulator.F_FAINT != 0
        val bold = attr and TerminalEmulator.F_BOLD != 0
        paint.color = when {
            selected && fgIdx == TerminalEmulator.DEFAULT_FG -> 0xFFFFFFFF.toInt()
            selected -> TerminalEmulator.PALETTE[fgIdx]
            faint -> TerminalEmulator.PALETTE[fgIdx] and 0x00FFFFFF or 0x70000000.toInt()
            else -> TerminalEmulator.PALETTE[fgIdx]
        }
        if (!faint && !selected && bold && fgIdx < 8) {
            // 亮色加粗：使用 8-15 的高亮色
            paint.color = TerminalEmulator.PALETTE[fgIdx + 8]
        }
        paint.isFakeBoldText = bold
        paint.textSkewX = if (attr and TerminalEmulator.F_ITALIC != 0) -0.2f else 0f
        paint.isUnderlineText = attr and TerminalEmulator.F_UNDERLINE != 0
        paint.alpha = if (faint) 150 else 255
    }

    private fun drawCursor(canvas: Canvas, emu: TerminalEmulator, top: Int) {
        if (!emu.cursorVisible || !isFocused) return
        val lineIndex = emu.cursorBufferLine()
        val r = lineIndex - top
        if (r < 0 || r >= emu.rows) return
        if (scrollOffset > 0) return
        val x = paddingLeft + emu.cx * cellW
        val y = paddingTop + r * cellH
        canvas.drawRect(x, y, x + cellW, y + cellH, cursorPaint)
    }

    // ---------------- 输入 ----------------

    fun send(data: ByteArray) {
        onInput?.invoke(data)
    }

    fun sendString(s: String) {
        send(s.toByteArray(Charsets.UTF_8))
    }

    fun sendEscape(seq: String) = sendString("\u001B$seq")

    /** 发送一个"键"，自动附加当前的 Alt（ESC 前缀）修饰 */
    private fun sendKeyBytes(bytes: ByteArray) {
        val withAlt = if (altOn) byteArrayOf(0x1B.toByte()) + bytes else bytes
        altOn = false
        send(withAlt)
        scrollToBottom()
    }

    private fun sendChar(ch: Char, ctrl: Boolean) {
        val code = if (ctrl) {
            val c = ch.uppercaseChar()
            if (c in 'A'..'Z') (c.code - 'A'.code + 1).toChar() else ch
        } else ch
        sendKeyBytes(code.toString().toByteArray(Charsets.UTF_8))
    }

    fun isCtrlOn() = ctrlOn
    fun toggleCtrl(): Boolean { ctrlOn = !ctrlOn; return ctrlOn }
    fun toggleAlt(): Boolean { altOn = !altOn; return altOn }
    fun clearModifiers() { ctrlOn = false; altOn = false }

    /** 供底部按键栏调用：发送控制键序列 */
    fun sendSpecial(seq: String) = sendKeyBytes(seq.toByteArray(Charsets.UTF_8))

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        val ctrl = ctrlOn || event.isCtrlPressed
        val alt = altOn || event.isAltPressed
        altOn = false

        when (keyCode) {
            KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                sendKeyBytes(byteArrayOf(13))
                ctrlOn = false
                return true
            }
            KeyEvent.KEYCODE_DEL, KeyEvent.KEYCODE_FORWARD_DEL -> {
                sendKeyBytes(byteArrayOf(0x7F.toByte()))
                ctrlOn = false
                return true
            }
            KeyEvent.KEYCODE_TAB -> {
                sendKeyBytes(byteArrayOf(9))
                ctrlOn = false
                return true
            }
            KeyEvent.KEYCODE_DPAD_UP -> { sendKeyBytes(arrowSeq('A')); return true }
            KeyEvent.KEYCODE_DPAD_DOWN -> { sendKeyBytes(arrowSeq('B')); return true }
            KeyEvent.KEYCODE_DPAD_RIGHT -> { sendKeyBytes(arrowSeq('C')); return true }
            KeyEvent.KEYCODE_DPAD_LEFT -> { sendKeyBytes(arrowSeq('D')); return true }
            KeyEvent.KEYCODE_MOVE_HOME -> { sendKeyBytes("\u001B[H".toByteArray()); return true }
            KeyEvent.KEYCODE_MOVE_END -> { sendKeyBytes("\u001B[F".toByteArray()); return true }
            KeyEvent.KEYCODE_PAGE_UP -> { sendKeyBytes("\u001B[5~".toByteArray()); return true }
            KeyEvent.KEYCODE_PAGE_DOWN -> { sendKeyBytes("\u001B[6~".toByteArray()); return true }
            KeyEvent.KEYCODE_ESCAPE -> { sendKeyBytes(byteArrayOf(0x1B)); return true }
            KeyEvent.KEYCODE_INSERT -> { sendKeyBytes("\u001B[2~".toByteArray()); return true }
            KeyEvent.KEYCODE_F1 -> { sendKeyBytes("\u001BOP".toByteArray()); return true }
            KeyEvent.KEYCODE_F2 -> { sendKeyBytes("\u001BOQ".toByteArray()); return true }
            KeyEvent.KEYCODE_F3 -> { sendKeyBytes("\u001BOR".toByteArray()); return true }
            KeyEvent.KEYCODE_F4 -> { sendKeyBytes("\u001BOS".toByteArray()); return true }
            KeyEvent.KEYCODE_F5 -> { sendKeyBytes("\u001B[15~".toByteArray()); return true }
            KeyEvent.KEYCODE_F6 -> { sendKeyBytes("\u001B[17~".toByteArray()); return true }
            KeyEvent.KEYCODE_F7 -> { sendKeyBytes("\u001B[18~".toByteArray()); return true }
            KeyEvent.KEYCODE_F8 -> { sendKeyBytes("\u001B[19~".toByteArray()); return true }
            KeyEvent.KEYCODE_F9 -> { sendKeyBytes("\u001B[20~".toByteArray()); return true }
            KeyEvent.KEYCODE_F10 -> { sendKeyBytes("\u001B[21~".toByteArray()); return true }
            KeyEvent.KEYCODE_F11 -> { sendKeyBytes("\u001B[23~".toByteArray()); return true }
            KeyEvent.KEYCODE_F12 -> { sendKeyBytes("\u001B[24~".toByteArray()); return true }
            KeyEvent.KEYCODE_VOLUME_UP -> { zoomIn(); return true }
            KeyEvent.KEYCODE_VOLUME_DOWN -> { zoomOut(); return true }
        }

        val meta = event.metaState
        val uc = event.getUnicodeChar(meta)
        if (uc != 0) {
            val ch = uc.toChar()
            if (ctrl && ch.code < 0x20) {
                sendKeyBytes(byteArrayOf(ch.code.toByte()))
            } else {
                sendChar(ch, ctrl)
            }
            ctrlOn = false
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun arrowSeq(c: Char) = "\u001B[$c".toByteArray(Charsets.UTF_8)

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) return true
        return super.onKeyUp(keyCode, event)
    }

    // ---------------- 软键盘 ----------------

    override fun onCheckIsTextEditor(): Boolean = true

    override fun onCreateInputConnection(outAttrs: EditorInfo): InputConnection {
        outAttrs.inputType = android.text.InputType.TYPE_CLASS_TEXT or
            android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS or
            android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
        outAttrs.imeOptions = EditorInfo.IME_FLAG_NO_ENTER_ACTION or EditorInfo.IME_ACTION_NONE
        outAttrs.initialSelStart = 0
        outAttrs.initialSelEnd = 0
        return TerminalInputConnection(this)
    }

    /**
     * 供软键盘提交文本使用。
     *
     * 关键：把 LF(0x0A) 统一改成 CR(0x0D)。
     * 软键盘的回车键（尤其中文输入法）往往不走 KeyEvent，
     * 而是通过 commitText("\n") 提交一个换行符。而 PTY 的行结束符是 CR：
     * termios 的 ICRNL 负责把 CR 转成 NL 交给应用，反过来不成立，
     * 直接发 LF 时很多服务器上的 shell 不认为这是一行结束 —— 表现就是
     * "能输入字符，但按回车没反应"。
     */
    private fun sendKeyboardText(s: String) {
        if (s.isEmpty()) return
        val fixed = if (s.indexOf('\n') >= 0) s.replace('\n', '\r') else s
        send(fixed.toByteArray(Charsets.UTF_8))
    }

    fun showKeyboard(show: Boolean) {
        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager ?: return
        if (show) {
            requestFocus()
            imm.showSoftInput(this, InputMethodManager.SHOW_IMPLICIT)
        } else {
            imm.hideSoftInputFromWindow(windowToken, 0)
        }
    }

    private class TerminalInputConnection(private val view: TerminalView) : BaseInputConnection(view, true) {

        /**
         * 组合中的文本（拼音候选阶段）只本地保存，不再发给远端。
         *
         * 以前每次 setComposingText 都把中间态发过去，提交时再补发等量的
         * 退格(0x7F)去删除 —— 一旦输入法在按回车时没有先结束组合，
         * commitText 就会先发退格把刚输入的整条命令删掉，再发回车，
         * 结果提交的是空行：看起来就是"回车没反应"。
         *
         * 现在改成只在真正提交时才发送，彻底去掉这套退格补偿逻辑。
         */
        private var composing = ""

        override fun commitText(text: CharSequence?, newCursorPosition: Int): Boolean {
            val s = text?.toString() ?: ""
            composing = ""
            if (s.isNotEmpty()) view.sendKeyboardText(s)
            view.scrollToBottom()
            return true
        }

        override fun setComposingText(text: CharSequence?, newCursorPosition: Int): Boolean {
            // 组合态不发往远端，交给输入法的候选栏显示
            composing = text?.toString() ?: ""
            return true
        }

        override fun finishComposingText(): Boolean {
            composing = ""
            return true
        }

        override fun deleteSurroundingText(beforeLength: Int, afterLength: Int): Boolean {
            repeat(beforeLength.coerceAtMost(64)) { view.send(byteArrayOf(0x7F)) }
            repeat(afterLength.coerceAtMost(64)) { view.send("\u001B[3~".toByteArray(Charsets.UTF_8)) }
            composing = ""
            return true
        }

        override fun sendKeyEvent(event: KeyEvent?): Boolean {
            if (event != null) {
                if (event.action == KeyEvent.ACTION_DOWN) return view.onKeyDown(event.keyCode, event)
                return view.onKeyUp(event.keyCode, event)
            }
            return false
        }

        override fun getEditable(): android.text.Editable? = null
    }

    // ---------------- 其它 ----------------

    private fun vibrate() {
        if (!AppPrefs.bellVibrate) return
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(30, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(30)
            }
        } catch (_: Throwable) {
            // 无振动权限或设备不支持时忽略
        }
    }

    override fun onWindowFocusChanged(hasWindowFocus: Boolean) {
        super.onWindowFocusChanged(hasWindowFocus)
        if (hasWindowFocus) postInvalidate()
    }

    /** 当前终端尺寸（供 PTY 同步） */
    fun termSize(): Pair<Int, Int> {
        val emu = emulator
        return if (emu == null) 80 to 24 else emu.cols to emu.rows
    }

    companion object {
        /** 是否存在实体键盘（用于决定是否自动弹出软键盘） */
        fun hasHardwareKeyboard(context: Context): Boolean =
            context.resources.configuration.keyboard != android.content.res.Configuration.KEYBOARD_NOKEYS ||
                InputDevice.getDeviceIds().any {
                    InputDevice.getDevice(it)?.keyboardType == InputDevice.KEYBOARD_TYPE_ALPHABETIC
                }
    }
}
