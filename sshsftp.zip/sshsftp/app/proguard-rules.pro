# ---------- SSH / SFTP（sshj 及其传递依赖） ----------
# sshj 用反射查找算法实现，整体保留（代价很小）
-keep class net.schmizz.sshj.** { *; }
-keep class net.schmizz.concurrent.** { *; }
-keep class net.schmizz.keepalive.** { *; }
-keep class com.hierynomus.** { *; }
-keep class net.i2p.crypto.** { *; }

# BouncyCastle：Provider 与 JCA 适配层用反射/SPI 加载，必须保留，
# 否则会出现 NoSuchAlgorithmException（ed25519 / chacha20-poly1305 等）
-keep class org.bouncycastle.jce.provider.BouncyCastleProvider { *; }
-keep class org.bouncycastle.jcajce.provider.** { *; }
-keep class org.bouncycastle.crypto.generators.** { *; }
-keep class org.bouncycastle.crypto.params.** { *; }
-dontwarn org.bouncycastle.**
-dontwarn org.slf4j.**
-dontwarn java.lang.management.**
-dontwarn javax.naming.**
-dontwarn com.sun.jna.**

# ---------- 通用 ----------
-keepattributes Signature, InnerClasses, EnclosingMethod, *Annotation*
-keepclassmembers class * implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator *;
}
-keepclassmembers class **.R$* { public static <fields>; }

# 配置数据类
-keep class com.sshsftp.app.data.** { *; }
