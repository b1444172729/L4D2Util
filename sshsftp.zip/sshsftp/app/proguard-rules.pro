# ---------- SSH / SFTP（sshj 及其传递依赖） ----------
# sshj 用反射查找算法实现，整体保留（代价很小）
-keep class net.schmizz.sshj.** { *; }
-keep class net.schmizz.concurrent.** { *; }
-keep class net.schmizz.keepalive.** { *; }
-keep class com.hierynomus.** { *; }
-keep class net.i2p.crypto.** { *; }

# BouncyCastle：Provider 与算法实现是靠字符串类名反射加载的，
# R8 静态分析看不到引用，必须整体保留，否则运行时报
# NoSuchAlgorithmException / NoClassDefFoundError（X25519、Ed25519、ChaCha20 等）
-keep class org.bouncycastle.jce.provider.** { *; }
-keep class org.bouncycastle.jcajce.** { *; }
-keep class org.bouncycastle.crypto.** { *; }
-keep class org.bouncycastle.asn1.x509.** { *; }
-keep class org.bouncycastle.asn1.pkcs.** { *; }
-keep class org.bouncycastle.math.ec.** { *; }
-dontwarn org.bouncycastle.**
-dontwarn org.slf4j.**
-dontwarn java.lang.management.**
-dontwarn javax.naming.**
-dontwarn com.sun.jna.**

# ---------- R8 "Missing classes" ----------
# 下面这些类在 Android 上根本不存在，只是被第三方库（可选地）引用到。
# R8 8.x 把 missing class 当成 ERROR，必须显式 -dontwarn，否则
# minifyReleaseWithR8 直接失败。这些代码路径在 Android 上永远不会执行。
#
# 1) sshj 的 GSSAPI 认证（Kerberos）—— Android 无 JGSS，我们也不用它
-dontwarn javax.security.auth.**
-dontwarn javax.security.auth.login.**
-dontwarn org.ietf.jgss.**
# 2) eddsa 里的一处反射，引用了 Sun 私有 JDK 类
-dontwarn sun.security.**
-dontwarn sun.security.x509.**
# 3) Tink（androidx.security 依赖）用到的 JSR-305 注解，并非运行时必需
-dontwarn javax.annotation.**
-dontwarn javax.annotation.concurrent.**

# ---------- 通用 ----------
-keepattributes Signature, InnerClasses, EnclosingMethod, *Annotation*
-keepclassmembers class * implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator *;
}
-keepclassmembers class **.R$* { public static <fields>; }

# 配置数据类
-keep class con.android.ssh.data.** { *; }
