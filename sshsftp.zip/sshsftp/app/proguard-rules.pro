# ---------- SSH / SFTP（sshj 及其传递依赖） ----------
# sshj 用反射查找算法实现，整体保留（代价很小）
-keep class net.schmizz.sshj.** { *; }
-keep class net.schmizz.concurrent.** { *; }
-keep class net.schmizz.keepalive.** { *; }
-keep class com.hierynomus.** { *; }
-keep class net.i2p.crypto.** { *; }

# BouncyCastle：Provider 与算法实现是靠字符串类名反射加载的，
# R8 静态分析看不到引用，必须整体保留，否则运行时报
# NoSuchAlgorithmException / NoClassDefFoundError（X25519、Ed25519、ChaCha20 等）
-keep class org.bouncycastle.jce.provider.** { *; }
-keep class org.bouncycastle.jcajce.** { *; }
-keep class org.bouncycastle.crypto.** { *; }
-keep class org.bouncycastle.asn1.x509.** { *; }
-keep class org.bouncycastle.asn1.pkcs.** { *; }
-keep class org.bouncycastle.math.ec.** { *; }
-dontwarn org.bouncycastle.**
-dontwarn org.slf4j.**
-dontwarn java.lang.management.**
-dontwarn javax.naming.**
-dontwarn com.sun.jna.**

# ---------- 通用 ----------
-keepattributes Signature, InnerClasses, EnclosingMethod, *Annotation*
-keepclassmembers class * implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator *;
}
-keepclassmembers class **.R$* { public static <fields>; }

# 配置数据类
-keep class com.sshsftp.app.data.** { *; }
