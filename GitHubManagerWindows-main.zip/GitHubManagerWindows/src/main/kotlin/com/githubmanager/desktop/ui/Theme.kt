package com.githubmanager.desktop.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/**
 * 配色：以靛紫为主色、青绿为辅助色的现代调色板。
 *
 * 相比默认的 Material 基准色，这里的 surface 系列做了轻微的紫色偏移，
 * 让浅色下不会惨白、深色下不会死黑，层次更柔和。
 */

// ---------- 浅色 ----------
private val LightPrimary = Color(0xFF5B5BD6)
private val LightOnPrimary = Color(0xFFFFFFFF)
private val LightPrimaryContainer = Color(0xFFE4E1FF)
private val LightOnPrimaryContainer = Color(0xFF151358)

private val LightSecondary = Color(0xFF7A5CFF)
private val LightOnSecondary = Color(0xFFFFFFFF)
private val LightSecondaryContainer = Color(0xFFEADDFF)
private val LightOnSecondaryContainer = Color(0xFF2A1370)

private val LightTertiary = Color(0xFF00867D)
private val LightOnTertiary = Color(0xFFFFFFFF)
private val LightTertiaryContainer = Color(0xFF9CF3EA)
private val LightOnTertiaryContainer = Color(0xFF003733)

private val LightBackground = Color(0xFFFAF9FF)
private val LightSurface = Color(0xFFFAF9FF)
private val LightSurfaceVariant = Color(0xFFE8E5F5)
private val LightSurfaceContainerLowest = Color(0xFFFFFFFF)
private val LightSurfaceContainerLow = Color(0xFFF5F3FE)
private val LightSurfaceContainer = Color(0xFFEFECFA)
private val LightSurfaceContainerHigh = Color(0xFFE9E6F6)
private val LightSurfaceContainerHighest = Color(0xFFE3E0F1)

private val LightOnSurface = Color(0xFF1B1A24)
private val LightOnSurfaceVariant = Color(0xFF5B5871)
private val LightOutline = Color(0xFF7A768F)
private val LightOutlineVariant = Color(0xFFCBC7DD)

// ---------- 深色 ----------
private val DarkPrimary = Color(0xFFC9C1FF)
private val DarkOnPrimary = Color(0xFF2C2070)
private val DarkPrimaryContainer = Color(0xFF453A9E)
private val DarkOnPrimaryContainer = Color(0xFFE4E1FF)

private val DarkSecondary = Color(0xFFCBB9FF)
private val DarkOnSecondary = Color(0xFF35206E)
private val DarkSecondaryContainer = Color(0xFF4C368F)
private val DarkOnSecondaryContainer = Color(0xFFEADDFF)

private val DarkTertiary = Color(0xFF6EDBD1)
private val DarkOnTertiary = Color(0xFF003733)
private val DarkTertiaryContainer = Color(0xFF00534D)
private val DarkOnTertiaryContainer = Color(0xFF9CF3EA)

private val DarkBackground = Color(0xFF13121B)
private val DarkSurface = Color(0xFF13121B)
private val DarkSurfaceVariant = Color(0xFF2E2B3D)
private val DarkSurfaceContainerLowest = Color(0xFF0E0D15)
private val DarkSurfaceContainerLow = Color(0xFF1C1A26)
private val DarkSurfaceContainer = Color(0xFF211F2D)
private val DarkSurfaceContainerHigh = Color(0xFF2B2839)
private val DarkSurfaceContainerHighest = Color(0xFF363245)

private val DarkOnSurface = Color(0xFFE6E3F0)
private val DarkOnSurfaceVariant = Color(0xFFC8C4DA)
private val DarkOutline = Color(0xFF928EA8)
private val DarkOutlineVariant = Color(0xFF484459)

private val LightColors = lightColorScheme(
    primary = LightPrimary,
    onPrimary = LightOnPrimary,
    primaryContainer = LightPrimaryContainer,
    onPrimaryContainer = LightOnPrimaryContainer,
    secondary = LightSecondary,
    onSecondary = LightOnSecondary,
    secondaryContainer = LightSecondaryContainer,
    onSecondaryContainer = LightOnSecondaryContainer,
    tertiary = LightTertiary,
    onTertiary = LightOnTertiary,
    tertiaryContainer = LightTertiaryContainer,
    onTertiaryContainer = LightOnTertiaryContainer,
    background = LightBackground,
    onBackground = LightOnSurface,
    surface = LightSurface,
    onSurface = LightOnSurface,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = LightOnSurfaceVariant,
    surfaceContainerLowest = LightSurfaceContainerLowest,
    surfaceContainerLow = LightSurfaceContainerLow,
    surfaceContainer = LightSurfaceContainer,
    surfaceContainerHigh = LightSurfaceContainerHigh,
    surfaceContainerHighest = LightSurfaceContainerHighest,
    outline = LightOutline,
    outlineVariant = LightOutlineVariant
)

private val DarkColors = darkColorScheme(
    primary = DarkPrimary,
    onPrimary = DarkOnPrimary,
    primaryContainer = DarkPrimaryContainer,
    onPrimaryContainer = DarkOnPrimaryContainer,
    secondary = DarkSecondary,
    onSecondary = DarkOnSecondary,
    secondaryContainer = DarkSecondaryContainer,
    onSecondaryContainer = DarkOnSecondaryContainer,
    tertiary = DarkTertiary,
    onTertiary = DarkOnTertiary,
    tertiaryContainer = DarkTertiaryContainer,
    onTertiaryContainer = DarkOnTertiaryContainer,
    background = DarkBackground,
    onBackground = DarkOnSurface,
    surface = DarkSurface,
    onSurface = DarkOnSurface,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkOnSurfaceVariant,
    surfaceContainerLowest = DarkSurfaceContainerLowest,
    surfaceContainerLow = DarkSurfaceContainerLow,
    surfaceContainer = DarkSurfaceContainer,
    surfaceContainerHigh = DarkSurfaceContainerHigh,
    surfaceContainerHighest = DarkSurfaceContainerHighest,
    outline = DarkOutline,
    outlineVariant = DarkOutlineVariant
)

/**
 * 形状：这里调大圆角后，Button / Card / Dialog 等使用 ShapeDefaults 的组件会自动跟随，
 * 不必逐个改调用点，风格也能保持统一。
 */
private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun GitHubManagerTheme(
    dark: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (dark) DarkColors else LightColors,
        typography = Typography(),
        shapes = AppShapes,
        content = content
    )
}
