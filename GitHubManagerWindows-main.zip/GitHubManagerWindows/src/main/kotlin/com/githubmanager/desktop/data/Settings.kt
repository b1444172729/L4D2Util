package com.githubmanager.desktop.data

import java.util.prefs.Preferences

/**
 * 轻量偏好存储：令牌、最近使用的仓库与分支、主题。
 *
 * 桌面端用 java.util.prefs.Preferences 替代 Android 的 SharedPreferences。
 * 在 Windows 上它把数据写进注册表 HKCU\Software\JavaSoft\Prefs，
 * 属于当前用户私有，其他用户读不到，语义与 Android 的应用私有存储一致。
 * 令牌明文存放，定位与 Android 版相同：单机自用工具，不引入加密库以免增加构建复杂度。
 */
class Settings {

    private val prefs: Preferences = Preferences.userNodeForPackage(Settings::class.java)

    var token: String
        get() = prefs.get("token", "")
        set(value) = prefs.put("token", value.trim())

    var lastOwner: String
        get() = prefs.get("owner", "")
        set(value) = prefs.put("owner", value)

    var lastRepo: String
        get() = prefs.get("repo", "")
        set(value) = prefs.put("repo", value)

    var darkTheme: Boolean
        get() = prefs.getBoolean("dark", false)
        set(value) = prefs.putBoolean("dark", value)

    /** 提交文件时使用的默认提交信息前缀 */
    var commitPrefix: String
        get() = prefs.get("prefix", "")
        set(value) = prefs.put("prefix", value)

    fun remember(owner: String, repo: String) {
        lastOwner = owner
        lastRepo = repo
    }

    fun clear() = prefs.remove("token")

    /** 退出时调用，确保写入磁盘 */
    fun flush() = runCatching { prefs.flush() }
}
