package com.githubmanager.desktop.util

import java.awt.Desktop
import java.awt.Toolkit
import java.awt.datatransfer.StringSelection
import java.io.File
import java.net.URI
import javax.swing.JFileChooser
import javax.swing.JOptionPane
import javax.swing.SwingUtilities

/**
 * 桌面端平台能力：文件选择、剪贴板、打开浏览器 / 文件夹。
 *
 * Android 版这些能力分散在 Context、MediaStore、SAF、ClipboardManager 里，
 * 桌面版统一收拢到这里，业务代码只依赖这个对象，便于以后换实现（比如换成 JavaFX 的 FileChooser）。
 */
object DesktopPlatform {

    /** 是否支持 AWT Desktop（无头环境或某些 Linux 发行版可能不支持） */
    private val desktopSupported: Boolean =
        runCatching { Desktop.isDesktopSupported() }.getOrDefault(false)

    // ---------- 剪贴板 ----------

    fun copyToClipboard(text: String) {
        runCatching {
            val selection = StringSelection(text)
            Toolkit.getDefaultToolkit().systemClipboard.setContents(selection, selection)
        }
    }

    // ---------- 打开外部资源 ----------

    /** 用系统默认浏览器打开网址；失败时返回 false 由界面提示 */
    fun openUrl(url: String): Boolean {
        if (!desktopSupported) return false
        return runCatching {
            Desktop.getDesktop().browse(URI(url))
            true
        }.getOrDefault(false)
    }

    /** 在文件管理器里打开某个文件所在目录（下载完成后很实用） */
    fun reveal(file: File): Boolean {
        if (!desktopSupported) return false
        return runCatching {
            val d = Desktop.getDesktop()
            when {
                // Windows 上 explorer /select, 可以顺便选中文件
                System.getProperty("os.name").contains("Windows", true) ->
                    Runtime.getRuntime().exec(arrayOf("explorer", "/select,", file.absolutePath))
                d.isSupported(Desktop.Action.BROWSE_FILE_DIR) -> d.browseFileDirectory(file)
                else -> d.open(file.parentFile)
            }
            true
        }.getOrDefault(false)
    }

    // ---------- 文件选择 ----------

    /**
     * 选择单个文件进行上传。
     * @return 选中的文件，取消时返回 null
     */
    fun chooseFile(parent: java.awt.Window? = null, title: String = "选择文件"): File? {
        return runOnEdt {
            val chooser = JFileChooser().apply {
                dialogTitle = title
                isMultiSelectionEnabled = false
                fileSelectionMode = JFileChooser.FILES_ONLY
                // 允许选择任意类型，上传不做后缀限制
                isAcceptAllFileFilterUsed = true
            }
            if (chooser.showOpenDialog(parent) == JFileChooser.APPROVE_OPTION) chooser.selectedFile else null
        }
    }

    /**
     * 选择多个文件。
     * @return 选中的文件列表，取消时返回空
     */
    fun chooseFiles(parent: java.awt.Window? = null, title: String = "选择文件（可多选）"): List<File> {
        return runOnEdt {
            val chooser = JFileChooser().apply {
                dialogTitle = title
                isMultiSelectionEnabled = true
                fileSelectionMode = JFileChooser.FILES_ONLY
            }
            if (chooser.showOpenDialog(parent) == JFileChooser.APPROVE_OPTION) {
                chooser.selectedFiles.toList()
            } else emptyList()
        } ?: emptyList()
    }

    /**
     * 选择文件夹用于整体上传。
     *
     * 用 Swing 的 JFileChooser（DIRECTORIES_ONLY）而不是 AWT 的 FileDialog：
     * FileDialog 没有真正的「只选目录」模式，靠 FilenameFilter 过滤后
     * getDirectory() 返回的是当前所在目录而非用户选中的那个，容易选错。
     * JFileChooser 的 selectedFile 才是准确的。
     *
     * 桌面端不存在 Android 那种「选不了文件夹」的限制。
     */
    fun chooseFolder(parent: java.awt.Window? = null, title: String = "选择文件夹"): File? {
        return runOnEdt {
            val chooser = JFileChooser().apply {
                dialogTitle = title
                fileSelectionMode = JFileChooser.DIRECTORIES_ONLY
                isMultiSelectionEnabled = false
                isAcceptAllFileFilterUsed = false
            }
            if (chooser.showOpenDialog(parent) == JFileChooser.APPROVE_OPTION) chooser.selectedFile else null
        }
    }

    /** 弹一个简单提示框（用于打开浏览器失败之类的兜底） */
    fun alert(message: String, title: String = "GitHubManager") {
        runOnEdt {
            JOptionPane.showMessageDialog(null, message, title, JOptionPane.INFORMATION_MESSAGE)
        }
    }

    /**
     * 在 AWT 事件派发线程上执行并等待结果。
     *
     * Swing / AWT 组件只能在 EDT 上创建和显示；Compose Desktop 的渲染线程不是 EDT，
     * 直接 new JFileChooser() 并 show 会出现偶发卡死或绘制异常。
     */
    private fun <T> runOnEdt(block: () -> T): T? {
        if (SwingUtilities.isEventDispatchThread()) return runCatching { block() }.getOrNull()
        var result: T? = null
        runCatching {
            SwingUtilities.invokeAndWait { result = runCatching { block() }.getOrNull() }
        }
        return result
    }
}
