package com.githubmanager.desktop.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.githubmanager.desktop.vm.AppViewModel
import com.githubmanager.desktop.vm.Tab as PageTab
import kotlinx.coroutines.launch

// ExperimentalFoundationApi 不写在这里：Compose Multiplatform 1.6.11 内置的 foundation
// 是 1.6.7，HorizontalPager / rememberPagerState 仍标为实验性，需要的 opt-in 已在
// build.gradle.kts 的 compilerOptions 里全局放行。这里再写注解反而要额外 import，
// 漏一行 import 就会直接编译失败（Android 版用 BOM 2025.08，pager 已稳定，故无此问题）。
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(vm: AppViewModel, onOpenUrl: (String) -> Unit) {
    val tabs = PageTab.entries
    val scope = rememberCoroutineScope()
    val pagerState = rememberPagerState(initialPage = vm.tab.ordinal) { tabs.size }

    // 外部切换 Tab（例如打开仓库时）同步到分页
    LaunchedEffect(vm.tab) {
        val target = vm.tab.ordinal
        if (pagerState.currentPage != target) pagerState.animateScrollToPage(target)
    }
    // 分页滑动同步回 ViewModel
    LaunchedEffect(pagerState.currentPage) {
        val next = tabs[pagerState.currentPage]
        if (vm.tab != next) vm.switchTab(next)
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            // 顶部：返回 + 渐变徽标 + 仓库名
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = vm::backToRepos) {
                    Icon(Icons.Rounded.ArrowBack, "返回")
                }
                Box(
                    Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(GitHubBrandDark),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        GitHubMark, null, Modifier.size(20.dp),
                        tint = GitHubBrandOnDark
                    )
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        vm.repo?.name.orEmpty(),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        vm.repo?.fullName.orEmpty(),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                CircleIconButton(Icons.Rounded.OpenInNew, "浏览器打开") {
                    onOpenUrl(vm.repo?.htmlUrl ?: "https://github.com")
                }
            }

            BusyBar(if (vm.busy) vm.busyLabel else "")

            // 胶囊式标签栏：比默认 Tab 行更现代
            Row(
                Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                tabs.forEachIndexed { index, tab ->
                    val selected = pagerState.currentPage == index
                    Surface(
                        onClick = { scope.launch { pagerState.animateScrollToPage(index) } },
                        shape = RoundedCornerShape(Dimens.ChipRadius),
                        color = if (selected) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.surfaceContainerHigh
                    ) {
                        Text(
                            tab.label(),
                            Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                            color = if (selected) MaterialTheme.colorScheme.onPrimary
                            else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            HorizontalPager(state = pagerState, modifier = Modifier.fillMaxSize()) { page ->
                when (tabs[page]) {
                    PageTab.FILES -> FilesScreen(vm, onOpenUrl)
                    PageTab.ACTIONS -> ActionsScreen(vm, onOpenUrl)
                    PageTab.DOWNLOADS -> TransfersScreen(vm)
                    PageTab.ISSUES -> IssuesScreen(vm, onOpenUrl)
                    PageTab.PULLS -> PullsScreen(vm, onOpenUrl)
                    PageTab.RELEASES -> ReleasesScreen(vm, onOpenUrl)
                    PageTab.COMMITS -> CommitsScreen(vm, onOpenUrl)
                    PageTab.BRANCHES -> BranchesScreen(vm)
                }
            }
        }
    }
}

private fun PageTab.label(): String = when (this) {
    PageTab.FILES -> "文件"
    PageTab.ACTIONS -> "编译"
    PageTab.DOWNLOADS -> "传输"
    PageTab.ISSUES -> "Issues"
    PageTab.PULLS -> "PR"
    PageTab.RELEASES -> "版本"
    PageTab.COMMITS -> "提交"
    PageTab.BRANCHES -> "分支"
}
