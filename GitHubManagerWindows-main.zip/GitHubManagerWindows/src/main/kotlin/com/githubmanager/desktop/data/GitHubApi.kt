package com.githubmanager.desktop.data

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.URLEncoder
import java.util.Base64
import java.util.concurrent.TimeUnit

class ApiException(val code: Int, message: String) : IOException(message)

/** 单次下载体积上限：防止超大日志 / 产物把内存打爆 */
internal const val MAX_DOWNLOAD = 200L * 1024 * 1024

/** 流式上传失败时，允许退化为「整文件读入内存」的体积上限 */
private const val FALLBACK_LIMIT = 20L * 1024 * 1024

/**
 * 超过这个体积改走 Git Data API。
 *
 * PUT /repos/{owner}/{repo}/contents/{path} 要求把整个文件 base64 塞进一个 JSON，
 * 服务端还要在同一请求里完成「解码 → 建 blob → 建 tree → 建 commit → 更新 ref」。
 * 实测超过约 40 MB 就返回 422「Sorry, the file is too large to be processed」，
 * 而且该阈值会随服务端负载浮动。取 32 MB 留安全边际：
 * 小文件继续走已验证稳定的 Contents API，大文件走拆开的 Git Data API。
 */
private const val GIT_DATA_THRESHOLD = 32L * 1024 * 1024


/**
 * GitHub REST API 客户端。
 *
 * 设计要点：
 * 1. 全部通过官方 REST API 完成，不依赖任何本地 Git 实现，因此不受 Android 版本限制。
 * 2. 文件上传走两条路径：≤32 MB 用 Contents API（一次 PUT 完成提交）；
 *    更大文件改走 Git Data API（blobs → trees → commits → refs），
 *    绕开 Contents API 在约 40 MB 处的 422 限制。任意二进制文件都支持，
 *    GitHub 仓库单文件硬上限仍是 100 MB（超过需 Git LFS）。
 * 3. 日志与产物下载会 302 跳转到 Azure Blob，跳转后的请求不能携带令牌，否则会被拒绝，
 *    因此这里统一用「先拿 Location，再用无令牌客户端下载」的两段式下载。
 */
class GitHubApi(private val tokenProvider: () -> String) {

    private val jsonMedia = "application/json; charset=utf-8".toMediaType()

    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .callTimeout(60, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    // 不跟随重定向：用于解析 Location
    private val noRedirect = http.newBuilder().followRedirects(false).followSslRedirects(false).build()

    // 无令牌、超时更长：用于流式下载大文件
    private val transfer = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .callTimeout(0, TimeUnit.SECONDS)
        .followSslRedirects(true)
        .build()

    // 上传 / 下载大文件：超时放宽，且不做整体 callTimeout 限制
    private val transferLong = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(300, TimeUnit.SECONDS)
        .writeTimeout(300, TimeUnit.SECONDS)
        .callTimeout(0, TimeUnit.SECONDS)
        .build()

    private fun token(): String {
        val t = tokenProvider().trim()
        if (t.isBlank()) throw ApiException(401, "未登录或令牌为空")
        return t
    }

    private fun url(path: String) = "https://api.github.com$path"

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8").replace("+", "%20")
    /** ref 路径里的分支名：斜杠必须保留为路径分隔符，其余字符照常编码 */
    private fun encRef(s: String) = s.split('/').joinToString("/") { enc(it) }


    private fun headers(builder: Request.Builder): Request.Builder = builder
        .header("Authorization", "Bearer ${token()}")
        .header("Accept", "application/vnd.github+json")
        .header("X-GitHub-Api-Version", "2022-11-28")
        .header("User-Agent", "GitHubManager-Android")

    private fun call(path: String, method: String = "GET", body: String? = null): String {
        val builder = Request.Builder().url(url(path))
        headers(builder)
        if (body != null) {
            builder.method(method, body.toRequestBody(jsonMedia))
        } else if (method != "GET") {
            builder.method(method, "".toRequestBody(jsonMedia))
        }
        http.newCall(builder.build()).execute().use { resp ->
            val text = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) throw ApiException(resp.code, parseError(resp.code, text))
            return text
        }
    }

    private fun parseError(code: Int, text: String): String {
        val msg = runCatching { JSONObject(text).optString("message") }.getOrDefault("").orEmpty()
        val friendly = when (code) {
            401 -> "令牌无效或已过期（401）"
            403 -> if (text.contains("rate limit", true)) "API 调用频率超限，请稍后再试（403）" else "没有权限，请检查令牌是否勾选 repo / workflow 权限（403）"
            404 -> "资源不存在，或令牌无权访问（404）"
            409 -> "冲突：$msg"
            422 -> "请求被拒绝：${msg.ifBlank { "可能是同名文件已存在，或内容为空" }}"
            else -> msg
        }
        return friendly.ifBlank { "HTTP $code" }
    }

    private fun repo(owner: String, name: String) = "/repos/${enc(owner)}/${enc(name)}"

    // ---------- 账户 ----------

    fun user(): User {
        val j = JSONObject(call("/user"))
        return User(
            j.optString("login"),
            j.optString("name").ifBlank { j.optString("login") },
            j.optString("avatar_url"),
            j.optInt("public_repos"),
            j.optString("html_url")
        )
    }

    fun repos(): List<Repo> {
        val all = mutableListOf<Repo>()
        for (page in 1..3) {
            val a = JSONArray(call("/user/repos?sort=updated&per_page=100&page=$page&affiliation=owner,collaborator,organization_member"))
            for (i in 0 until a.length()) all += parseRepo(a.getJSONObject(i))
            if (a.length() < 100) break
        }
        return all
    }

    fun searchRepos(query: String): List<Repo> {
        if (query.isBlank()) return emptyList()
        val j = JSONObject(call("/search/repositories?q=${enc(query)}&per_page=50&sort=updated"))
        val a = j.optJSONArray("items") ?: return emptyList()
        return (0 until a.length()).map { parseRepo(a.getJSONObject(it)) }
    }

    private fun parseRepo(j: JSONObject) = Repo(
        j.optLong("id"),
        j.optString("name"),
        j.optString("full_name"),
        j.optJSONObject("owner")?.optString("login").orEmpty(),
        j.optString("description").orEmpty(),
        j.optBoolean("private"),
        j.optString("default_branch", "main"),
        j.optString("language").orEmpty(),
        j.optInt("stargazers_count"),
        j.optInt("forks_count"),
        j.optLong("size"),
        j.optString("pushed_at").orEmpty(),
        j.optString("html_url")
    )

    fun createRepo(name: String, description: String, privateRepo: Boolean): Repo {
        val body = JSONObject().put("name", name).put("description", description).put("private", privateRepo)
            .put("auto_init", true)
        return parseRepo(JSONObject(call("/user/repos", "POST", body.toString())))
    }

    fun deleteRepo(owner: String, name: String) {
        call(repo(owner, name), "DELETE")
    }

    fun star(owner: String, name: String) = call("/user/starred/${enc(owner)}/${enc(name)}", "PUT")
    fun unstar(owner: String, name: String) = call("/user/starred/${enc(owner)}/${enc(name)}", "DELETE")

    /** 204 表示已星标，404 表示未星标 */
    fun isStarred(owner: String, name: String): Boolean {
        val request = headers(Request.Builder().url(url("/user/starred/${enc(owner)}/${enc(name)}"))).build()
        http.newCall(request).execute().use { resp ->
            when (resp.code) {
                204 -> return true
                404 -> return false
                else -> throw ApiException(resp.code, parseError(resp.code, resp.body?.string().orEmpty()))
            }
        }
    }

    // ---------- 分支 ----------

    fun branches(owner: String, name: String): List<Branch> {
        val a = JSONArray(call("${repo(owner, name)}/branches?per_page=100"))
        return (0 until a.length()).map {
            val j = a.getJSONObject(it)
            Branch(j.optString("name"), j.optJSONObject("commit")?.optString("sha").orEmpty(), j.optBoolean("protected"))
        }
    }

    /** 基于某个分支创建新分支（用 sha 建 ref，不需要本地仓库） */
    fun createBranch(owner: String, name: String, newBranch: String, from: String) {
        val source = if (from.isBlank()) {
            JSONObject(call(repo(owner, name))).optString("default_branch", "main")
        } else from
        val sha = JSONObject(call("${repo(owner, name)}/git/ref/heads/${enc(source)}"))
            .optJSONObject("object")?.optString("sha")
            ?: throw ApiException(404, "找不到源分支 $source")
        val body = JSONObject().put("ref", "refs/heads/$newBranch").put("sha", sha)
        call("${repo(owner, name)}/git/refs", "POST", body.toString())
    }

    fun deleteBranch(owner: String, name: String, branch: String) {
        call("${repo(owner, name)}/git/refs/heads/${enc(branch)}", "DELETE")
    }

    // ---------- 文件（Contents API） ----------

    fun contents(owner: String, name: String, path: String, ref: String): List<ContentEntry> {
        val query = if (ref.isBlank()) "" else "?ref=${enc(ref)}"
        val raw = call("${repo(owner, name)}/contents/${path.encodePath()}$query")
        // 单文件时返回对象，目录时返回数组
        val array = if (raw.trimStart().startsWith("[")) JSONArray(raw) else JSONArray().put(JSONObject(raw))
        val list = mutableListOf<ContentEntry>()
        for (i in 0 until array.length()) {
            val j = array.getJSONObject(i)
            list += ContentEntry(
                j.optString("name"),
                j.optString("path"),
                j.optString("type"),
                j.optLong("size"),
                j.optString("sha"),
                j.optString("html_url"),
                j.optString("download_url")
            )
        }
        // 目录在前、文件在后，各自按名排序
        return list.sortedWith(compareBy({ !it.isDir }, { it.name.lowercase() }))
    }

    /** 读取单个文件；大文件（>1MB）content 为 null，需要用 rawBytes 下载 */
    fun file(owner: String, name: String, path: String, ref: String): FileContent {
        val query = if (ref.isBlank()) "" else "?ref=${enc(ref)}"
        val j = JSONObject(call("${repo(owner, name)}/contents/${path.encodePath()}$query"))
        return FileContent(
            j.optString("name"),
            j.optString("path"),
            j.optString("sha"),
            j.optLong("size"),
            j.optString("content").takeIf { it.isNotBlank() },
            j.optString("encoding").takeIf { it.isNotBlank() },
            j.optString("download_url").takeIf { it.isNotBlank() }
        )
    }

    /** 用 raw 形式取原始字节（支持私有仓库，且不受 base64 体积膨胀影响） */
    fun rawBytes(owner: String, name: String, path: String, ref: String): ByteArray {
        val query = if (ref.isBlank()) "" else "?ref=${enc(ref)}"
        val builder = Request.Builder().url(url("${repo(owner, name)}/contents/${path.encodePath()}$query"))
            .header("Authorization", "Bearer ${token()}")
            .header("Accept", "application/vnd.github.raw")
            .header("X-GitHub-Api-Version", "2022-11-28")
            .header("User-Agent", "GitHubManager-Android")
        http.newCall(builder.build()).execute().use { resp ->
            if (!resp.isSuccessful) throw ApiException(resp.code, parseError(resp.code, resp.body?.string().orEmpty()))
            return resp.body?.bytes() ?: throw ApiException(500, "空响应")
        }
    }

    /**
     * 创建或更新文件。sha 为空表示新建，非空表示更新（GitHub 用它做并发校验）。
     * content 必须是原始字节的 base64。
     */
    fun putFile(
        owner: String, name: String, path: String, message: String,
        contentBase64: String, sha: String?, branch: String
    ): CommitResult {
        val body = JSONObject()
            .put("message", message.ifBlank { "Update ${path.substringAfterLast('/')}" })
            .put("content", contentBase64)
        if (!sha.isNullOrBlank()) body.put("sha", sha)
        if (branch.isNotBlank()) body.put("branch", branch)
        val j = JSONObject(call("${repo(owner, name)}/contents/${path.encodePath()}", "PUT", body.toString()))
        val content = j.optJSONObject("content")
        val commit = j.optJSONObject("commit")
        return CommitResult(
            commit?.optString("sha").orEmpty(),
            content?.optString("sha"),
            commit?.optString("html_url").orEmpty()
        )
    }

    /**
     * 流式上传本地文件（GitHub 仓库单文件硬上限 100 MB）。
     *
     * 两条路径（按体积自动分流，所有上传入口都汇聚到这里，无需调用方关心）：
     *  - ≤ 32 MB：Contents API 的 PUT /contents，一次请求完成提交，最快。
     *  - > 32 MB：Git Data API（见 putFileViaGitData），绕开 /contents 在约 40 MB 处的 422。
     *
     * 为什么不用 putFile：putFile 需要先把整个文件读成 ByteArray 再做 base64，
     * 100 MB 文件编码后约 133 MB 字符串，加上原始数组会直接 OOM。
     * 这里边读文件边编码边写入请求体，内存占用恒定在几十 KB。
     *
     * 注：sha 参数只给 Contents API 做并发校验用；Git Data API 走 base_tree + path
     * 覆盖，不需要旧 blob sha，因此大文件分支会忽略它（现有调用点也都传 null）。
     */
    fun putFileStream(
        file: File, owner: String, name: String, path: String,
        message: String, sha: String?, branch: String
    ): CommitResult {
        val size = file.length()

        // 大文件改走 Git Data API：Contents API 的 PUT /contents 实测超过约 40 MB
        // 就会返回 422「Sorry, the file is too large to be processed」。
        // 阈值取 32 MB 留出安全边际（该阈值会随服务端负载浮动）。
        // 必须早于下面的 runCatching 直接返回：大文件上传失败时绝不能回退到
        // Contents API，那条路必然也失败，只会白等一整轮上传。
        if (size > GIT_DATA_THRESHOLD) {
            return putFileViaGitData(file, owner, name, path, message, branch, size)
        }

        return runCatching {
            putFileStreamOnce(file, owner, name, path, message, sha, branch, size)
        }.getOrElse { e ->
            //
            // 安全网：流式路径一旦出错（报文长度、协议层异常等），
            // 对体积可控的文件退化为「整文件读入 -> 普通 PUT」。
            // 普通 PUT 走 OkHttp 的 toRequestBody，长度由它自己按 UTF-8 精确算出，
            // 不存在手写长度算错的可能。这样即使流式实现还有没测到的边界问题，
            // 中文名文件也照样能传上去。
            //
            if (size !in 0..FALLBACK_LIMIT) throw e
            val encoded = Base64.getEncoder().encodeToString(file.readBytes())
            putFile(owner, name, path, message, encoded, sha, branch)
        }
    }

    private fun putFileStreamOnce(
        file: File, owner: String, name: String, path: String,
        message: String, sha: String?, branch: String, size: Long
    ): CommitResult {
        val body = StreamUploadBody(file, message, sha, branch, size)
        val request = headers(Request.Builder().url(url("${repo(owner, name)}/contents/${path.encodePath()}")))
            .method("PUT", body).build()
        transferLong.newCall(request).execute().use { resp ->
            val text = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) throw ApiException(resp.code, parseError(resp.code, text))
            return parseCommitResult(text)
        }
    }


    /**
     * 大文件走 Git Data API（单文件提交）。
     *
     * Contents API 把整条提交链压在一个 PUT 里，服务端处理不了大请求体；
     * 这里拆成 1 个大请求 + 4~5 个几 KB 的小请求，其中只有「创建 blob」是大请求，
     * 而 /git/blobs 是专为大对象设计的端点（官方标注支持 100 MB）。
     *
     *   1. POST   /git/blobs            → blob sha      （流式，唯一的大请求）
     *   2. GET    /git/ref/heads/{b}    → 当前 commit sha
     *   3. GET    /git/commits/{sha}    → base tree sha （必须是 tree sha，不是 commit sha）
     *   4. POST   /git/trees            → 新 tree sha   （base_tree + 单个 entry）
     *   5. POST   /git/commits          → 新 commit sha （tree + parents）
     *   6. PATCH  /git/refs/heads/{b}  （force=false，避免覆盖别人的推送）
     *
     * 空仓库（GET ref 返回 404）走无 parent / 无 base_tree 的初始化分支。
     */
    private fun putFileViaGitData(
        file: File, owner: String, name: String, path: String,
        message: String, branch: String, size: Long
    ): CommitResult {
        val base = repo(owner, name)
        val b = branch.ifBlank {
            JSONObject(call(base)).optString("default_branch", "main").ifBlank { "main" }
        }
        val msg = message.ifBlank { "Upload ${path.substringAfterLast('/')}" }

        // 1. 创建 blob。流式边读边编码，内存占用恒定在几十 KB。
        val blobSha = createBlob(file, base, size)

        // 2~3. 当前分支 HEAD 与 base tree。空仓库时两者皆 null。
        var parentSha: String? = null
        var baseTreeSha: String? = null
        val refJson: JSONObject? = try {
            JSONObject(call("$base/git/ref/heads/${encRef(b)}"))
        } catch (e: ApiException) {
            if (e.code == 404) null else throw e
        }
        if (refJson != null) {
            parentSha = refJson.optJSONObject("object")?.optString("sha")?.takeIf { it.isNotBlank() }
            if (parentSha != null) {
                baseTreeSha = JSONObject(call("$base/git/commits/${enc(parentSha)}"))
                    .optJSONObject("tree")?.optString("sha")?.takeIf { it.isNotBlank() }
            }
        }

        // 4. 创建 tree。
        //    tree[].path 允许带斜杠，GitHub 会自动建立中间子树（官方文档明确支持嵌套条目）。
        //    base_tree 绝不能省：不带它，新 tree 里就只剩这一个文件，等于把仓库清空。
        val entry = JSONObject()
            .put("path", path)
            .put("mode", "100644")
            .put("type", "blob")
            .put("sha", blobSha)
        val treeBody = JSONObject().put("tree", JSONArray().put(entry))
        if (baseTreeSha != null) treeBody.put("base_tree", baseTreeSha)
        val newTreeSha = JSONObject(call("$base/git/trees", "POST", treeBody.toString()))
            .optString("sha").takeIf { it.isNotBlank() }
            ?: throw ApiException(500, "创建 tree 失败：响应里没有 sha")

        // 5. 创建 commit
        val commitBody = JSONObject().put("message", msg).put("tree", newTreeSha)
        if (parentSha != null) commitBody.put("parents", JSONArray().put(parentSha))
        val newCommitSha = JSONObject(call("$base/git/commits", "POST", commitBody.toString()))
            .optString("sha").takeIf { it.isNotBlank() }
            ?: throw ApiException(500, "创建 commit 失败：响应里没有 sha")

        // 6. 移动分支引用
        if (parentSha != null) {
            // force=false：期间若别人推过新提交，这里会 422 而不是静默覆盖
            call("$base/git/refs/heads/${encRef(b)}", "PATCH",
                JSONObject().put("sha", newCommitSha).put("force", false).toString())
        } else {
            // 空仓库：创建 ref
            call("$base/git/refs", "POST",
                JSONObject().put("ref", "refs/heads/$b").put("sha", newCommitSha).toString())
        }

        return CommitResult(
            newCommitSha,
            blobSha,
            "https://github.com/$owner/$name/commit/$newCommitSha"
        )
    }

    /** 创建 blob：流式把文件 base64 写进 {"content":"...","encoding":"base64"} */
    private fun createBlob(file: File, base: String, size: Long): String {
        val body = BlobUploadBody(file, size)
        val request = headers(Request.Builder().url(url("$base/git/blobs")))
            .post(body).build()
        transferLong.newCall(request).execute().use { resp ->
            val text = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) {
                val detail = parseError(resp.code, text)
                if (resp.code == 413 || resp.code == 422) {
                    throw ApiException(
                        resp.code,
                        "GitHub 拒绝了这个大文件（单次请求过大）。$detail\n" +
                            "建议改用 git push、Git LFS，或把文件拆成小于 40 MB 的分卷。"
                    )
                }
                throw ApiException(resp.code, detail)
            }
            return JSONObject(text).optString("sha").takeIf { it.isNotBlank() }
                ?: throw ApiException(500, "创建 blob 失败：响应里没有 sha")
        }
    }

    private fun parseCommitResult(text: String): CommitResult {
        val j = JSONObject(text)
        return CommitResult(
            j.optJSONObject("commit")?.optString("sha").orEmpty(),
            j.optJSONObject("content")?.optString("sha"),
            j.optJSONObject("commit")?.optString("html_url").orEmpty()
        )
    }

    /** 删除文件：必须带 sha */
    fun deleteFile(owner: String, name: String, path: String, message: String, sha: String, branch: String): CommitResult {
        val body = JSONObject()
            .put("message", message.ifBlank { "Delete ${path.substringAfterLast('/')}" })
            .put("sha", sha)
        if (branch.isNotBlank()) body.put("branch", branch)
        val j = JSONObject(call("${repo(owner, name)}/contents/${path.encodePath()}", "DELETE", body.toString()))
        return CommitResult(
            j.optJSONObject("commit")?.optString("sha").orEmpty(),
            null,
            j.optJSONObject("commit")?.optString("html_url").orEmpty()
        )
    }

    // ---------- 提交历史 ----------

    fun commits(owner: String, name: String, branch: String): List<Commit> {
        val query = if (branch.isBlank()) "" else "?sha=${enc(branch)}&per_page=50"
        val a = JSONArray(call("${repo(owner, name)}/commits$query"))
        return (0 until a.length()).map {
            val j = a.getJSONObject(it)
            val c = j.optJSONObject("commit")
            Commit(
                j.optString("sha").take(7),
                c?.optString("message").orEmpty().substringBefore("\n"),
                c?.optJSONObject("author")?.optString("name").orEmpty(),
                c?.optJSONObject("author")?.optString("date").orEmpty(),
                j.optString("html_url")
            )
        }
    }

    // ---------- Actions ----------

    fun workflows(owner: String, name: String): List<Workflow> {
        val j = JSONObject(call("${repo(owner, name)}/actions/workflows?per_page=100"))
        val a = j.optJSONArray("workflows") ?: return emptyList()
        return (0 until a.length()).map {
            val w = a.getJSONObject(it)
            Workflow(w.optLong("id"), w.optString("name"), w.optString("path").substringAfterLast('/'), w.optString("state"))
        }
    }

    /** 触发 workflow_dispatch。inputs 为空对象时也必须传 {} */
    fun dispatch(owner: String, name: String, workflowId: Long, ref: String, inputs: Map<String, String>) {
        val body = JSONObject().put("ref", ref).put("inputs", JSONObject().apply {
            inputs.forEach { (k, v) -> put(k, v) }
        })
        call("${repo(owner, name)}/actions/workflows/$workflowId/dispatches", "POST", body.toString())
    }

    fun runs(owner: String, name: String): List<WorkflowRun> {
        val j = JSONObject(call("${repo(owner, name)}/actions/runs?per_page=30"))
        return parseRuns(j.optJSONArray("workflow_runs"))
    }

    /** 只看某个工作流的运行记录 */
    fun runsFor(owner: String, name: String, workflowId: Long): List<WorkflowRun> {
        val j = JSONObject(call("${repo(owner, name)}/actions/workflows/$workflowId/runs?per_page=30"))
        return parseRuns(j.optJSONArray("workflow_runs"))
    }

    private fun parseRuns(a: JSONArray?): List<WorkflowRun> {
        a ?: return emptyList()
        return (0 until a.length()).map {
            val j = a.getJSONObject(it)
            WorkflowRun(
                j.optLong("id"),
                j.optString("name").ifBlank { j.optString("display_title") },
                j.optInt("run_number"),
                j.optString("status"),
                j.optString("conclusion").takeIf { s -> s != "null" }.orEmpty(),
                j.optString("head_branch"),
                j.optString("head_sha").take(7),
                j.optString("event"),
                j.optString("created_at"),
                j.optString("updated_at"),
                j.optString("html_url")
            )
        }
    }

    fun jobs(owner: String, name: String, runId: Long): List<WorkflowJob> {
        val j = JSONObject(call("${repo(owner, name)}/actions/runs/$runId/jobs?per_page=100"))
        val a = j.optJSONArray("jobs") ?: return emptyList()
        return (0 until a.length()).map {
            val x = a.getJSONObject(it)
            WorkflowJob(
                x.optLong("id"),
                x.optString("name"),
                x.optString("status"),
                x.optString("conclusion").takeIf { s -> s != "null" }.orEmpty(),
                x.optString("started_at"),
                x.optString("completed_at")
            )
        }
    }

    fun cancelRun(owner: String, name: String, runId: Long) =
        call("${repo(owner, name)}/actions/runs/$runId/cancel", "POST")

    fun rerunRun(owner: String, name: String, runId: Long) =
        call("${repo(owner, name)}/actions/runs/$runId/rerun", "POST")

    fun rerunFailed(owner: String, name: String, runId: Long) =
        call("${repo(owner, name)}/actions/runs/$runId/rerun-failed-jobs", "POST")

    /** 运行日志（zip 压缩包） */
    fun runLogsZip(owner: String, name: String, runId: Long): ByteArray =
        binary("${repo(owner, name)}/actions/runs/$runId/logs")

    /** 单个任务的日志（同样是 zip，通常只有一个条目） */
    fun jobLogsZip(owner: String, name: String, jobId: Long): ByteArray =
        binary("${repo(owner, name)}/actions/jobs/$jobId/logs")

    fun artifacts(owner: String, name: String, runId: Long): List<Artifact> {
        val j = JSONObject(call("${repo(owner, name)}/actions/runs/$runId/artifacts?per_page=100"))
        val a = j.optJSONArray("artifacts") ?: return emptyList()
        return (0 until a.length()).map {
            val x = a.getJSONObject(it)
            Artifact(
                x.optLong("id"),
                x.optString("name"),
                x.optLong("size_in_bytes"),
                x.optBoolean("expired"),
                x.optString("created_at"),
                x.optString("updated_at")
            )
        }
    }

    /** 产物下载：返回可直接粘到浏览器的最终地址（已跟随 302，不含令牌） */
    fun artifactDownloadUrl(owner: String, name: String, artifactId: Long): String {
        val path = "${repo(owner, name)}/actions/artifacts/$artifactId/zip"
        val request = headers(Request.Builder().url(url(path))).build()
        noRedirect.newCall(request).execute().use { resp ->
            val location = resp.header("Location")
            return when {
                location != null -> resp.request.url.resolve(location)?.toString() ?: location
                resp.isSuccessful -> url(path)
                else -> throw ApiException(resp.code, parseError(resp.code, resp.body?.string().orEmpty()))
            }
        }
    }

    fun artifactWebUrl(owner: String, name: String, runId: Long, artifactId: Long) =
        "https://github.com/$owner/$name/actions/runs/$runId/artifacts/$artifactId"

    fun artifactApiUrl(owner: String, name: String, artifactId: Long) =
        url("${repo(owner, name)}/actions/artifacts/$artifactId/zip")

    fun artifactCurl(owner: String, name: String, artifactId: Long): String =
        "curl -L -o artifact.zip -H 'Authorization: Bearer ${token()}' " +
            "-H 'Accept: application/vnd.github+json' '${artifactApiUrl(owner, name, artifactId)}'"

    /** 产物二进制内容（用于「应用内下载后分享」） */
    fun artifactBytes(owner: String, name: String, artifactId: Long): ByteArray =
        binary("${repo(owner, name)}/actions/artifacts/$artifactId/zip")

    // ---------- Issues / Pull Requests ----------

    fun issues(owner: String, name: String, state: String): List<Issue> {
        val a = JSONArray(call("${repo(owner, name)}/issues?state=$state&per_page=50&sort=updated"))
        return (0 until a.length()).map { parseIssue(a.getJSONObject(it)) }
    }

    fun pulls(owner: String, name: String, state: String): List<Issue> {
        val a = JSONArray(call("${repo(owner, name)}/pulls?state=$state&per_page=50&sort=updated"))
        return (0 until a.length()).map { index ->
            // range.map 的 lambda 参数是索引 Int，必须先取出 JSONObject 再使用
            val j = a.getJSONObject(index)
            parseIssue(j).copy(isPull = true, draft = j.optBoolean("draft"), merged = j.optBoolean("merged"))
        }
    }

    private fun parseIssue(j: JSONObject) = Issue(
        j.optInt("number"),
        j.optString("title"),
        j.optString("state"),
        j.optJSONObject("user")?.optString("login").orEmpty(),
        j.optString("created_at"),
        j.optString("updated_at"),
        j.optInt("comments"),
        j.optString("body").orEmpty(),
        j.optString("html_url")
    )

    fun createIssue(owner: String, name: String, title: String, body: String): Int {
        val payload = JSONObject().put("title", title).put("body", body)
        return JSONObject(call("${repo(owner, name)}/issues", "POST", payload.toString())).optInt("number")
    }

    fun setIssueState(owner: String, name: String, number: Int, state: String) {
        call("${repo(owner, name)}/issues/$number", "PATCH", JSONObject().put("state", state).toString())
    }

    fun comments(owner: String, name: String, number: Int): List<Comment> {
        val a = JSONArray(call("${repo(owner, name)}/issues/$number/comments?per_page=100"))
        return (0 until a.length()).map {
            val j = a.getJSONObject(it)
            Comment(
                j.optLong("id"),
                j.optJSONObject("user")?.optString("login").orEmpty(),
                j.optString("body"),
                j.optString("created_at")
            )
        }
    }

    fun addComment(owner: String, name: String, number: Int, body: String) {
        call("${repo(owner, name)}/issues/$number/comments", "POST", JSONObject().put("body", body).toString())
    }

    fun mergePull(owner: String, name: String, number: Int, method: String = "merge") {
        call("${repo(owner, name)}/pulls/$number/merge", "PUT", JSONObject().put("merge_method", method).toString())
    }

    // ---------- Releases ----------

    fun releases(owner: String, name: String): List<Release> {
        val a = JSONArray(call("${repo(owner, name)}/releases?per_page=30"))
        return (0 until a.length()).map {
            val j = a.getJSONObject(it)
            val assets = j.optJSONArray("assets")
            val list = mutableListOf<ReleaseAsset>()
            if (assets != null) {
                for (i in 0 until assets.length()) {
                    val x = assets.getJSONObject(i)
                    list += ReleaseAsset(
                        x.optLong("id"), x.optString("name"), x.optLong("size"),
                        x.optInt("download_count"), "${repo(owner, name)}/releases/assets/${x.optLong("id")}"
                    )
                }
            }
            Release(
                j.optLong("id"), j.optString("tag_name"), j.optString("name").ifBlank { j.optString("tag_name") },
                j.optString("body"), j.optString("published_at"), j.optString("html_url"),
                j.optBoolean("draft"), j.optBoolean("prerelease"), list
            )
        }
    }

    fun releaseAssetBytes(owner: String, name: String, assetId: Long): ByteArray {
        val path = "${repo(owner, name)}/releases/assets/$assetId"
        val request = headers(Request.Builder().url(url(path)))
            .header("Accept", "application/octet-stream").build()
        noRedirect.newCall(request).execute().use { resp ->
            if (resp.code in 301..308) {
                val location = resp.header("Location") ?: throw ApiException(500, "缺少下载地址")
                return transfer.newCall(Request.Builder().url(location).header("Accept", "application/octet-stream").build())
                    .execute().use { it.body?.bytes() ?: throw ApiException(500, "空响应") }
            }
            if (!resp.isSuccessful) throw ApiException(resp.code, parseError(resp.code, resp.body?.string().orEmpty()))
            return resp.body?.bytes() ?: throw ApiException(500, "空响应")
        }
    }

    // ---------- 通用二进制下载（两段式，跳转后不带令牌） ----------

    /**
     * 下载二进制内容（日志 zip / 产物 zip）。
     *
     * GitHub 的下载接口会 302 到 Azure Blob：如果带着 Authorization 头跟随重定向，
     * Azure 会拒绝，所以这里先不跟随拿到 Location，再用「无令牌」的客户端下载。
     */
    private fun binary(path: String): ByteArray {
        val request = headers(Request.Builder().url(url(path))).build()
        noRedirect.newCall(request).execute().use { first ->
            val redirected = first.code in 301..308
            if (redirected) {
                val location = first.header("Location") ?: throw ApiException(500, "下载链接为空")
                val resolved = first.request.url.resolve(location)?.toString() ?: location
                require(resolved.startsWith("https://")) { "拒绝非 HTTPS 下载地址" }
                // 重定向到 Azure 时不能带 GitHub 令牌，否则会被拒绝
                return downloadWithLimit(resolved, false)
            }
            if (!first.isSuccessful) {
                throw ApiException(first.code, parseError(first.code, first.body?.string().orEmpty()))
            }
            return readCapped(first.body) ?: throw ApiException(500, "响应体为空")
        }
    }

    /** 带体积上限的下载，避免超大日志把内存打爆 */
    private fun downloadWithLimit(target: String, withAuth: Boolean): ByteArray {
        val builder = Request.Builder().url(target).header("User-Agent", "GitHubManager-Android")
        if (withAuth) headers(builder)
        transfer.newCall(builder.build()).execute().use { resp ->
            if (!resp.isSuccessful) throw ApiException(resp.code, "下载失败（HTTP ${resp.code}）")
            return readCapped(resp.body) ?: throw ApiException(500, "响应体为空")
        }
    }

    /**
     * 流式读取并计数；超过 MAX_DOWNLOAD 直接报错，而不是把整个文件读进内存导致 OOM。
     */
    private fun readCapped(body: okhttp3.ResponseBody?): ByteArray? {
        val source = body ?: return null
        val collector = java.io.ByteArrayOutputStream()
        val buffer = ByteArray(64 * 1024)
        source.byteStream().use { stream ->
            var total = 0L
            while (true) {
                val n = stream.read(buffer)
                if (n <= 0) break
                total += n
                if (total > MAX_DOWNLOAD) {
                    throw ApiException(413, "内容超过 ${MAX_DOWNLOAD / 1024 / 1024} MB，已中止下载")
                }
                collector.write(buffer, 0, n)
            }
        }
        return collector.toByteArray()
    }

    /** 路径分段各自的 URL 编码，保留 "/" 作为层级分隔 */
    private fun String.encodePath(): String = split("/").joinToString("/") { enc(it) }
}

/** JSON 字符串转义，避免提交信息里的引号 / 换行破坏结构 */
private fun jsonEscape(s: String): String {
    val sb = StringBuilder(s.length + 8)
    for (c in s) {
        when {
            c == '"' -> sb.append("\\\"")
            c == '\\' -> sb.append("\\\\")
            c == '\n' -> sb.append("\\n")
            c == '\r' -> sb.append("\\r")
            c == '\t' -> sb.append("\\t")
            c.code < 0x20 -> sb.append("\\u").append(c.code.toString(16).padStart(4, '0'))
            else -> sb.append(c)
        }
    }
    return sb.toString()
}

/**
 * 边读边编码的 Base64 写入器：把输入流直接编码进 Okio sink，
 * 不需要把整个文件读进内存，因此支持上传 100 MB 的文件。
 */
private class Base64Encoder(private val sink: okio.BufferedSink) {
    private val table = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".toByteArray()
    private var acc = 0
    private var bits = 0
    private val buf = ByteArray(4)
    private var pos = 0

    private fun emit(value: Int) {
        buf[pos++] = value.toByte()
        if (pos == 4) {
            sink.write(buf, 0, 4)
            pos = 0
        }
    }

    fun update(bytes: ByteArray, length: Int) {
        for (i in 0 until length) {
            acc = (acc shl 8) or (bytes[i].toInt() and 0xFF)
            bits += 8
            while (bits >= 6) {
                bits -= 6
                emit(table[(acc shr bits) and 0x3F].toInt())
            }
        }
    }

    /** 写出剩余位并补 '=' 填充，使总长度为 4 的倍数 */
    fun finish() {
        if (bits > 0) emit(table[(acc shl (6 - bits)) and 0x3F].toInt())
        while (pos != 0) emit('='.code)
    }
}

/** 流式上传请求体：JSON 头 → Base64 正文 → JSON 尾，全程不落地、不整体驻留内存 */
private class StreamUploadBody(
    private val file: File,
    message: String,
    sha: String?,
    branch: String,
    private val fileSize: Long
) : okhttp3.RequestBody() {

    private val head: String = buildString {
        append("{\"message\":\"").append(jsonEscape(message)).append('"')
        if (!sha.isNullOrBlank()) append(",\"sha\":\"").append(jsonEscape(sha)).append('"')
        if (branch.isNotBlank()) append(",\"branch\":\"").append(jsonEscape(branch)).append('"')
        append(",\"content\":\"")
    }
    private val tail = "\"}"

    //
    // ⚠ 关键：长度必须按 UTF-8「字节数」算，不能用 String.length（UTF-16 字符数）。
    //
    // 提交信息里含中文（例如 Upload 中文.txt）时，一个汉字在 UTF-8 里是 3 字节，
    // 但 String.length 只算 1。用 .length 得到的 Content-Length 会比真实报文短，
    // 服务端按这个长度截报文，收到的 JSON 被砍掉尾巴 → 报 400 / "Problems parsing JSON"。
    // 纯英文时两者相等，所以问题只在中文文件名/提交信息上暴露出来。
    //
    private val headBytes: ByteArray = head.toByteArray(Charsets.UTF_8)
    private val tailBytes: ByteArray = tail.toByteArray(Charsets.UTF_8)

    override fun contentType() = "application/json; charset=utf-8".toMediaType()

    override fun contentLength(): Long {
        if (fileSize < 0) return -1L
        // Base64：每 3 字节输入产出 4 字节输出（含填充）
        val encoded = ((fileSize + 2) / 3) * 4
        return headBytes.size.toLong() + encoded + tailBytes.size
    }

    override fun writeTo(sink: okio.BufferedSink) {
        sink.write(headBytes).flush()
        val encoder = Base64Encoder(sink)
        val input = file.inputStream()
        input.use { stream ->
            val buffer = ByteArray(64 * 1024)
            while (true) {
                val n = stream.read(buffer)
                if (n <= 0) break
                encoder.update(buffer, n)
            }
        }
        encoder.finish()
        sink.write(tailBytes).flush()
    }
}


/**
 * 创建 blob 用的流式请求体：{"content":"<base64>","encoding":"base64"}。
 *
 * 与 StreamUploadBody 的区别只是 JSON 字段名：Contents API 用 message/content/branch，
 * Git Data API 的 /git/blobs 用 content/encoding。
 * Content-Length 同样按 UTF-8 字节数算，不能拿 String.length 当字节数。
 */
private class BlobUploadBody(
    private val file: File,
    private val fileSize: Long
) : okhttp3.RequestBody() {

    private val headBytes = "{\"content\":\"".toByteArray(Charsets.UTF_8)
    private val tailBytes = "\",\"encoding\":\"base64\"}".toByteArray(Charsets.UTF_8)

    override fun contentType() = "application/json; charset=utf-8".toMediaType()

    override fun contentLength(): Long {
        if (fileSize < 0) return -1L
        // Base64：每 3 字节输入产出 4 字节输出（含 = 填充）
        val encoded = ((fileSize + 2) / 3) * 4
        return headBytes.size.toLong() + encoded + tailBytes.size
    }

    override fun writeTo(sink: okio.BufferedSink) {
        sink.write(headBytes).flush()
        val encoder = Base64Encoder(sink)
        file.inputStream().use { stream ->
            val buffer = ByteArray(64 * 1024)
            while (true) {
                val n = stream.read(buffer)
                if (n <= 0) break
                encoder.update(buffer, n)
            }
        }
        encoder.finish()
        sink.write(tailBytes).flush()
    }
}
