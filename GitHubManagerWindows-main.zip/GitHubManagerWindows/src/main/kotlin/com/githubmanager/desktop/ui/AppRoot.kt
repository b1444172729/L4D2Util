package com.githubmanager.desktop.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border.BorderStroke
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Upload
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.githubmanager.desktop.vm.AppViewModel
import com.githubmanager.desktop.vm.Screen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppRoot(vm: AppViewModel, onOpenUrl: (String) -> Unit, modifier: Modifier = Modifier) {
    val snackbar = remember { SnackbarHostState() }

    /**
     * Esc 键处理：桌面端没有 Android 的系统返回键，但用户习惯用 Esc 逐层退出。
     * 优先级与 Android 版一致 —— 先关日志页，再关运行详情页。
     *
     * ⚠ 注意：requestFocus() 必须在 Box 的 content 里调用（见下方），
     * 不能写在这里。写在外面的话，首帧时 focusRequester 修饰符还没挂到节点上，
     * 会抛 IllegalStateException: FocusRequester is not initialized，
     * 桌面端表现为启动即弹 Error 对话框。
     */
    val focusRequester = remember { FocusRequester() }

    // 提示信息：一次性消费后弹出
    LaunchedEffect(vm.message) {
        val text = vm.message ?: return@LaunchedEffect
        snackbar.showSnackbar(text)
        vm.consumeMessage()
    }
    LaunchedEffect(vm.error) {
        val text = vm.error ?: return@LaunchedEffect
        snackbar.showSnackbar("出错了：$text")
        vm.consumeError()
    }

    Scaffold(
        modifier = modifier,
        snackbarHost = { SnackbarHost(snackbar) }
    ) { padding ->
        // padding 由各页面自行处理，这里避免嵌套 Scaffold 造成双重留白
        val unused = padding

        // 页面主体
        Box(
            Modifier
                .fillMaxSize()
                .focusRequester(focusRequester)
                .focusable()
                .onKeyEvent { event ->
                    if (event.type == KeyEventType.KeyDown && event.key == Key.Escape) {
                        when {
                            vm.logViewerOpen -> vm.closeLogViewer()
                            vm.runDetailOpen -> vm.closeRunDetailAll()
                            else -> return@onKeyEvent false
                        }
                        true
                    } else false
                }
        ) {
            // 必须放在 Box 的 content 内部：此时 Box 自己的修饰符节点
            // （含 focusRequester）已经挂好，FocusRequester 一定已初始化。
            // 再套一层 runCatching：万一将来某个 Compose 版本时序有变，
            // 最坏结果是 Esc 键失效，而不是整个应用崩溃。
            LaunchedEffect(Unit) {
                runCatching { focusRequester.requestFocus() }
            }

            AnimatedContent(
                targetState = vm.screen,
                transitionSpec = {
                    slideInHorizontally { it } togetherWith slideOutHorizontally { -it }
                },
                label = "screen"
            ) { screen ->
                when (screen) {
                    Screen.LOGIN -> LoginScreen(vm, onOpenUrl)
                    Screen.REPOS -> ReposScreen(vm, onOpenUrl)
                    Screen.DETAIL -> DetailScreen(vm, onOpenUrl)
                }
            }

            // 日志查看器必须在最外层全屏渲染：放在编译页内部会随 HorizontalPager
            // 一起测量和滑动，导致「点击运行不显示、滑到相邻页才显示」。
            // 只用 logViewerOpen 判断：运行中的任务日志可能暂时为空，
            // 若再加 logText != null 会导致「运行中点了没反应」，由 LogViewer 内部显示等待状态。
            // 运行详情页：点击运行记录后打开的一屏
            if (vm.runDetailOpen) {
                RunDetailScreen(vm, onOpenUrl)
            }

            // 完整日志：只有点「打开完整日志」才展示
            if (vm.logViewerOpen) {
                LogViewer(vm)
            }

            // 拖拽上传提示层：放最后声明，保证盖在所有页面与浮层之上
            if (vm.dropActive) {
                DropHintOverlay(vm)
            }
        }
    }
}

/**
 * 拖拽悬停时的提示层。
 *
 * 只是视觉反馈：真正的拖放由 Main.kt 里挂的 AWT DropTarget 处理。
 * 这里刻意不加任何点击/手势处理，避免抢走事件。
 */
@Composable
private fun DropHintOverlay(vm: AppViewModel) {
    Box(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.scrim.copy(alpha = 0.5f)),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            shape = RoundedCornerShape(Dimens.CardRadius),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp,
            border = BorderStroke(2.dp, MaterialTheme.colorScheme.primary)
        ) {
            Column(
                Modifier.padding(horizontal = 48.dp, vertical = 36.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    Icons.Rounded.Upload, null,
                    Modifier.size(56.dp),
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(Modifier.height(16.dp))
                Text(
                    "松开即可上传",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    "上传到：${vm.path.ifBlank { "仓库根目录" }}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    "文件直接上传；文件夹会保留原有目录结构",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
