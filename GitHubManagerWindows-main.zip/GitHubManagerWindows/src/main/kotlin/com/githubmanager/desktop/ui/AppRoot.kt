package com.githubmanager.desktop.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import com.githubmanager.desktop.vm.AppViewModel
import com.githubmanager.desktop.vm.Screen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppRoot(vm: AppViewModel, onOpenUrl: (String) -> Unit, modifier: Modifier = Modifier) {
    val snackbar = remember { SnackbarHostState() }

    /**
     * Esc 键处理：桌面端没有 Android 的系统返回键，但用户习惯用 Esc 逐层退出。
     * 优先级与 Android 版一致 —— 先关日志页，再关运行详情页。
     *
     * ⚠ 注意：requestFocus() 必须在 Box 的 content 里调用（见下方），
     * 不能写在这里。写在外面的话，首帧时 focusRequester 修饰符还没挂到节点上，
     * 会抛 IllegalStateException: FocusRequester is not initialized，
     * 桌面端表现为启动即弹 Error 对话框。
     */
    val focusRequester = remember { FocusRequester() }

    // 提示信息：一次性消费后弹出
    LaunchedEffect(vm.message) {
        val text = vm.message ?: return@LaunchedEffect
        snackbar.showSnackbar(text)
        vm.consumeMessage()
    }
    LaunchedEffect(vm.error) {
        val text = vm.error ?: return@LaunchedEffect
        snackbar.showSnackbar("出错了：$text")
        vm.consumeError()
    }

    androidx.compose.material3.Scaffold(
        modifier = modifier,
        snackbarHost = { SnackbarHost(snackbar) }
    ) { padding ->
        // padding 由各页面自行处理，这里避免嵌套 Scaffold 造成双重留白
        val unused = padding

        // 页面主体
        Box(
            Modifier
                .fillMaxSize()
                .focusRequester(focusRequester)
                .focusable()
                .onKeyEvent { event ->
                    if (event.type == KeyEventType.KeyDown && event.key == Key.Escape) {
                        when {
                            vm.logViewerOpen -> vm.closeLogViewer()
                            vm.runDetailOpen -> vm.closeRunDetailAll()
                            else -> return@onKeyEvent false
                        }
                        true
                    } else false
                }
        ) {
            // 必须放在 Box 的 content 内部：此时 Box 自己的修饰符节点
            // （含 focusRequester）已经挂好，FocusRequester 一定已初始化。
            // 再套一层 runCatching：万一将来某个 Compose 版本时序有变，
            // 最坏结果是 Esc 键失效，而不是整个应用崩溃。
            LaunchedEffect(Unit) {
                runCatching { focusRequester.requestFocus() }
            }

            AnimatedContent(
                targetState = vm.screen,
                transitionSpec = {
                    slideInHorizontally { it } togetherWith slideOutHorizontally { -it }
                },
                label = "screen"
            ) { screen ->
                when (screen) {
                    Screen.LOGIN -> LoginScreen(vm, onOpenUrl)
                    Screen.REPOS -> ReposScreen(vm, onOpenUrl)
                    Screen.DETAIL -> DetailScreen(vm, onOpenUrl)
                }
            }

            // 日志查看器必须在最外层全屏渲染：放在编译页内部会随 HorizontalPager
            // 一起测量和滑动，导致「点击运行不显示、滑到相邻页才显示」。
            // 只用 logViewerOpen 判断：运行中的任务日志可能暂时为空，
            // 若再加 logText != null 会导致「运行中点了没反应」，由 LogViewer 内部显示等待状态。
            // 运行详情页：点击运行记录后打开的一屏
            if (vm.runDetailOpen) {
                RunDetailScreen(vm, onOpenUrl)
            }

            // 完整日志：只有点「打开完整日志」才展示
            if (vm.logViewerOpen) {
                LogViewer(vm)
            }
        }
    }
}
