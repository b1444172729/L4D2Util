package com.githubmanager.desktop.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.githubmanager.desktop.data.Branch
import com.githubmanager.desktop.data.Commit
import com.githubmanager.desktop.data.Issue
import com.githubmanager.desktop.data.Release
import com.githubmanager.desktop.util.Helpers
import com.githubmanager.desktop.vm.AppViewModel

// ---------------- Issues ----------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IssuesScreen(vm: AppViewModel, onOpenUrl: (String) -> Unit) {
    var showCreate by remember { mutableStateOf(false) }
    var filter by remember { mutableStateOf("open") }

    LaunchedEffect(Unit) { vm.loadIssues("open") }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
            item {
                SectionHeader("Issues", "问题与需求") {
                    FilterChip(selected = filter == "open", onClick = { filter = "open"; vm.loadIssues("open") },
                        label = { Text("开启") })
                    Spacer(Modifier.width(6.dp))
                    FilterChip(selected = filter == "closed", onClick = { filter = "closed"; vm.loadIssues("closed") },
                        label = { Text("已关闭") })
                }
                Row(Modifier.padding(horizontal = 16.dp)) {
                    Button(onClick = { showCreate = true }, enabled = !vm.busy, modifier = Modifier.heightIn(min = 44.dp)) {
                        Icon(Icons.Rounded.Add, null, Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("新建 Issue")
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
            if (vm.issues.isEmpty() && !vm.busy) {
                item { EmptyState(Icons.Rounded.BugReport, "没有 Issue", "点上方按钮新建一个") }
            }
            items(vm.issues, key = { "issue-${it.number}" }) { issue ->
                IssueCard(issue, vm, onOpenUrl, onToggle = {
                    vm.setIssueState(issue, if (issue.state == "open") "closed" else "open")
                })
            }
        }
    }

    if (showCreate) {
        var title by remember { mutableStateOf("") }
        var body by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showCreate = false },
            title = { Text("新建 Issue") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(title, { title = it }, modifier = Modifier.fillMaxWidth(),
                        label = { Text("标题") }, singleLine = true)
                    OutlinedTextField(body, { body = it }, modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp),
                        label = { Text("内容") })
                }
            },
            confirmButton = {
                TextButton(onClick = { vm.createIssue(title, body); showCreate = false },
                    enabled = title.isNotBlank()) { Text("创建") }
            },
            dismissButton = { TextButton(onClick = { showCreate = false }) { Text("取消") } }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun IssueCard(issue: Issue, vm: AppViewModel, onOpenUrl: (String) -> Unit, onToggle: () -> Unit) {
    ItemCard(modifier = Modifier.padding(horizontal = 16.dp, vertical = 5.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        Brush.linearGradient(
                            if (issue.state == "open") listOf(
                                MaterialTheme.colorScheme.primary,
                                MaterialTheme.colorScheme.secondary
                            ) else listOf(
                                MaterialTheme.colorScheme.surfaceContainerHighest,
                                MaterialTheme.colorScheme.surfaceContainerHigh
                            )
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    if (issue.state == "open") Icons.Rounded.ErrorOutline else Icons.Rounded.CheckCircleOutline,
                    null,
                    Modifier.size(20.dp),
                    tint = if (issue.state == "open") MaterialTheme.colorScheme.onPrimary
                    else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(issue.title, style = MaterialTheme.typography.bodyMedium, maxLines = 2,
                    overflow = TextOverflow.Ellipsis)
                MetaLine("#${issue.number}", issue.author, "${issue.comments} 条评论", Helpers.time(issue.updatedAt))
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onToggle, modifier = Modifier.weight(1f), enabled = !vm.busy) {
                Text(if (issue.state == "open") "关闭" else "重新打开")
            }
            OutlinedButton(onClick = { onOpenUrl(issue.htmlUrl) }, modifier = Modifier.weight(1f)) {
                Icon(Icons.Rounded.OpenInNew, null, Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("网页")
            }
        }
    }
}

// ---------------- Pull Requests ----------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PullsScreen(vm: AppViewModel, onOpenUrl: (String) -> Unit) {
    var filter by remember { mutableStateOf("open") }
    LaunchedEffect(Unit) { vm.loadPulls("open") }

    LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            SectionHeader("Pull Requests", "合并请求") {
                FilterChip(selected = filter == "open", onClick = { filter = "open"; vm.loadPulls("open") },
                    label = { Text("开启") })
                Spacer(Modifier.width(6.dp))
                FilterChip(selected = filter == "closed", onClick = { filter = "closed"; vm.loadPulls("closed") },
                    label = { Text("已关闭") })
            }
        }
        if (vm.pulls.isEmpty() && !vm.busy) {
            item { EmptyState(Icons.Rounded.CallMerge, "没有 PR", "") }
        }
        items(vm.pulls, key = { "pr-${it.number}" }) { pull ->
            ItemCard(modifier = Modifier.padding(horizontal = 16.dp, vertical = 5.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                Brush.linearGradient(
                                    listOf(
                                        MaterialTheme.colorScheme.primary,
                                        MaterialTheme.colorScheme.tertiary
                                    )
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Rounded.CallMerge, null, Modifier.size(20.dp),
                            tint = MaterialTheme.colorScheme.onPrimary
                        )
                    }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(pull.title, style = MaterialTheme.typography.bodyMedium, maxLines = 2,
                            overflow = TextOverflow.Ellipsis)
                        MetaLine("#${pull.number}", pull.author, if (pull.draft) "草稿" else "", Helpers.time(pull.updatedAt))
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.mergePull(pull) }, modifier = Modifier.weight(1f),
                        enabled = !vm.busy && pull.state == "open") {
                        Icon(Icons.Rounded.Check, null, Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("合并")
                    }
                    OutlinedButton(onClick = { onOpenUrl(pull.htmlUrl) }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Rounded.OpenInNew, null, Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("网页")
                    }
                }
            }
        }
    }
}

// ---------------- Releases ----------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReleasesScreen(vm: AppViewModel, onOpenUrl: (String) -> Unit) {
    LaunchedEffect(Unit) { vm.loadReleases() }

    LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
        item { SectionHeader("Releases", "版本与附件") }
        if (vm.releases.isEmpty() && !vm.busy) {
            item { EmptyState(Icons.Rounded.NewReleases, "没有 Release", "打 tag 并在 Actions 里发布后会出现") }
        }
        items(vm.releases, key = { it.id }) { release ->
            ReleaseCard(release, vm, onOpenUrl)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ReleaseCard(release: Release, vm: AppViewModel, onOpenUrl: (String) -> Unit) {
    ItemCard(modifier = Modifier.padding(horizontal = 16.dp, vertical = 5.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(
                                MaterialTheme.colorScheme.tertiary,
                                MaterialTheme.colorScheme.primary
                            )
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Rounded.NewReleases, null, Modifier.size(20.dp),
                    tint = MaterialTheme.colorScheme.onPrimary
                )
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(release.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold,
                    maxLines = 2, overflow = TextOverflow.Ellipsis)
                MetaLine(release.tagName, Helpers.time(release.publishedAt),
                    if (release.prerelease) "预发布" else "", if (release.draft) "草稿" else "")
            }
        }
        if (release.body.isNotBlank()) {
            Spacer(Modifier.height(6.dp))
            Text(release.body, style = MaterialTheme.typography.bodySmall, maxLines = 4,
                overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (release.assets.isNotEmpty()) {
            HorizontalDivider(Modifier.padding(vertical = 8.dp))
            Text("附件", style = MaterialTheme.typography.labelMedium)
            release.assets.forEach { asset ->
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.AttachFile, null, Modifier.size(16.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        Text(asset.name, style = MaterialTheme.typography.bodySmall, maxLines = 1,
                            overflow = TextOverflow.Ellipsis)
                        MetaLine(Helpers.size(asset.size), "下载 ${asset.downloadCount} 次")
                    }
                    TextButton(onClick = { vm.downloadAsset(asset) }, enabled = !vm.busy) { Text("下载") }
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        OutlinedButton(onClick = { onOpenUrl(release.htmlUrl) }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Rounded.OpenInNew, null, Modifier.size(16.dp)); Spacer(Modifier.width(6.dp)); Text("在浏览器打开")
        }
    }
}

// ---------------- Commits ----------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CommitsScreen(vm: AppViewModel, onOpenUrl: (String) -> Unit) {
    LaunchedEffect(Unit) { vm.loadCommits() }

    LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
        item { SectionHeader("提交历史", "分支：${vm.branch}") }
        if (vm.commits.isEmpty() && !vm.busy) {
            item { EmptyState(Icons.Rounded.History, "没有提交", "") }
        }
        items(vm.commits, key = { it.sha }) { commit ->
            ItemCard(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                onClick = { onOpenUrl(commit.htmlUrl) }
            ) {
                Text(commit.message, style = MaterialTheme.typography.bodyMedium, maxLines = 2,
                    overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(commit.sha, style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(8.dp))
                    MetaLine(commit.author, Helpers.time(commit.date))
                }
            }
        }
    }
}

// ---------------- Branches ----------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BranchesScreen(vm: AppViewModel) {
    var showCreate by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf<Branch?>(null) }
    LaunchedEffect(Unit) { vm.loadBranches() }

    LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            SectionHeader("分支", "${vm.branches.size} 个")
            Row(Modifier.padding(horizontal = 16.dp)) {
                Button(onClick = { showCreate = true }, enabled = !vm.busy) {
                    Icon(Icons.Rounded.Add, null, Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("新建分支")
                }
            }
            Spacer(Modifier.height(8.dp))
        }
        items(vm.branches, key = { it.name }) { branch ->
            ItemCard(modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                Brush.linearGradient(
                                    listOf(
                                        MaterialTheme.colorScheme.secondary,
                                        MaterialTheme.colorScheme.primary
                                    )
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Rounded.AccountTree, null, Modifier.size(20.dp),
                            tint = MaterialTheme.colorScheme.onPrimary
                        )
                    }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(branch.name, style = MaterialTheme.typography.bodyMedium, maxLines = 1,
                            overflow = TextOverflow.Ellipsis)
                        MetaLine(branch.sha.take(7), if (branch.protected) "受保护" else "",
                            if (branch.name == vm.branch) "当前" else "")
                    }
                    if (branch.name != vm.branch) {
                        IconButton(onClick = { confirmDelete = branch }, enabled = !vm.busy) {
                            Icon(Icons.Rounded.DeleteOutline, null, tint = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }
        }
    }

    if (showCreate) {
        var name by remember { mutableStateOf("") }
        var from by remember { mutableStateOf(vm.branch) }
        AlertDialog(
            onDismissRequest = { showCreate = false },
            title = { Text("新建分支") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(name, { name = it }, modifier = Modifier.fillMaxWidth(),
                        label = { Text("新分支名") }, singleLine = true, placeholder = { Text("feature/x") })
                    OutlinedTextField(from, { from = it }, modifier = Modifier.fillMaxWidth(),
                        label = { Text("基于哪个分支") }, singleLine = true)
                }
            },
            confirmButton = {
                TextButton(onClick = { vm.createBranch(name, from); showCreate = false },
                    enabled = name.isNotBlank()) { Text("创建") }
            },
            dismissButton = { TextButton(onClick = { showCreate = false }) { Text("取消") } }
        )
    }

    confirmDelete?.let { branch ->
        ConfirmDialog(
            title = "删除分支 ${branch.name}？",
            text = "删除后无法恢复（除非本地仍有该分支）。",
            confirmLabel = "删除",
            onDismiss = { confirmDelete = null },
            onConfirm = { vm.deleteBranch(branch.name) }
        )
    }
}
