package com.githubmanager.desktop

import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.application
import androidx.compose.ui.window.rememberWindowState
import androidx.compose.ui.unit.dp
import com.githubmanager.desktop.ui.AppRoot
import com.githubmanager.desktop.ui.GitHubManagerTheme
import com.githubmanager.desktop.util.DesktopPlatform
import com.githubmanager.desktop.vm.AppViewModel
import java.awt.Dimension
import java.awt.dnd.DnDConstants
import java.awt.dnd.DropTarget
import java.awt.dnd.DropTargetDragEvent
import java.awt.dnd.DropTargetDropEvent
import java.awt.dnd.DropTargetEvent
import java.awt.datatransfer.DataFlavor
import java.awt.datatransfer.Transferable
import java.io.File
import java.net.URI

fun main() = application {
    val vm = remember { AppViewModel() }

    // 退出时保存偏好并释放协程
    androidx.compose.runtime.DisposableEffect(Unit) {
        onDispose { vm.dispose() }
    }

    Window(
        onCloseRequest = ::exitApplication,
        title = "Github 管理器",
        state = rememberWindowState(width = 1100.dp, height = 780.dp)
    ) {
        // 桌面上窗口更大，给个最小尺寸避免布局被挤变形
        window.minimumSize = Dimension(900, 620)

        // ------------------------------------------------------------------
        // 拖拽上传：把文件/文件夹从资源管理器直接拖进窗口即可上传
        //
        // Compose Multiplatform 1.6 还没有 dragAndDropTarget 修饰符，
        // 桌面端要走 AWT 的 DropTarget，挂在窗口的 rootPane 上。
        // Compose 的绘制画布本身不接收拖放事件，会向上冒泡到 rootPane，
        // 所以挂在这里能覆盖整个窗口区域。
        // 这些回调运行在 AWT 事件派发线程上，正好就是 Compose 的主线程，
        // 因此直接改 mutableStateOf 状态是安全的。
        // ------------------------------------------------------------------
        LaunchedEffect(Unit) {
            window.rootPane.dropTarget = object : DropTarget() {
                private fun supported(e: DropTargetDragEvent): Boolean =
                    vm.canAcceptDrop() && e.transferable.isDataFlavorSupported(DataFlavor.javaFileListFlavor)

                override fun dragEnter(e: DropTargetDragEvent) {
                    if (supported(e)) {
                        e.acceptDrag(DnDConstants.ACTION_COPY)
                        vm.dropActive = true
                    } else {
                        e.rejectDrag()
                        vm.dropActive = false
                    }
                }

                override fun dragOver(e: DropTargetDragEvent) {
                    // 必须每次都 acceptDrag，否则光标会变成「禁止」图标
                    if (supported(e)) {
                        e.acceptDrag(DnDConstants.ACTION_COPY)
                        vm.dropActive = true
                    } else {
                        e.rejectDrag()
                        vm.dropActive = false
                    }
                }

                override fun dragExit(e: DropTargetEvent) {
                    vm.dropActive = false
                }

                override fun drop(e: DropTargetDropEvent) {
                    vm.dropActive = false
                    if (!vm.canAcceptDrop() ||
                        !e.transferable.isDataFlavorSupported(DataFlavor.javaFileListFlavor)
                    ) {
                        e.rejectDrop()
                        return
                    }
                    e.acceptDrop(DnDConstants.ACTION_COPY)
                    val dropped = readDroppedFiles(e.transferable)
                    e.dropComplete(true)
                    vm.handleDroppedPaths(dropped)
                }
            }
        }

        GitHubManagerTheme(dark = vm.darkTheme) {
            AppRoot(
                vm = vm,
                onOpenUrl = { url ->
                    // 打开系统浏览器；不支持时给出提示而不是静默失败
                    if (!DesktopPlatform.openUrl(url)) {
                        DesktopPlatform.alert("无法打开浏览器，请手动访问：\n$url", "提示")
                    }
                }
            )
        }
    }
}

// ----------------------------------------------------------------------
// 拖入文件的读取。
//
// Windows 上 javaFileListFlavor 返回的 File 是用 sun.jnu.encoding
// （系统 ANSI 代码页，中文 Windows 是 GBK，英文 Windows 是 Cp1252）解码出来的。
// 遇到代码页表示不了的中文名会变成乱码，File 指向一个根本不存在的路径，
// 于是后续 isFile / isDirectory 全是 false，文件被静默丢弃 ——
// 表现就是「英文名能拖，中文名拖不了」。
//
// text/uri-list 里的地址是 UTF-8 百分号编码，中文名能完好保留。
// 所以这里两种都读，取「真实存在的条目更多」的那一份。
// ----------------------------------------------------------------------

private fun readDroppedFiles(t: Transferable): List<File> {
    val fromList = runCatching {
        if (t.isDataFlavorSupported(DataFlavor.javaFileListFlavor)) {
            @Suppress("UNCHECKED_CAST")
            (t.getTransferData(DataFlavor.javaFileListFlavor) as? List<*>)
                ?.filterIsInstance<File>().orEmpty()
        } else {
            emptyList()
        }
    }.getOrDefault(emptyList())

    val fromUri = readUriList(t)

    return if (fromUri.count { it.exists() } > fromList.count { it.exists() }) fromUri else fromList
}

/** 从 text/uri-list 读取（UTF-8 百分号编码，中文名安全） */
private fun readUriList(t: Transferable): List<File> {
    val flavor = t.transferDataFlavors.firstOrNull { f ->
        f.primaryType.equals("text", true) && f.subType.equals("uri-list", true)
    } ?: return emptyList()

    val raw = runCatching {
        when (val d = t.getTransferData(flavor)) {
            is String -> d
            is java.io.Reader -> d.readText()
            else -> null
        }
    }.getOrNull() ?: return emptyList()

    return raw.lineSequence()
        .map { it.trim() }
        .filter { it.isNotBlank() && !it.startsWith("#") }
        .mapNotNull(::uriToFile)
        .toList()
}

/** file:///C:/目录/中文.txt -> C:\目录\中文.txt */
private fun uriToFile(raw: String): File? {
    val uri = runCatching { URI(raw) }.getOrNull() ?: return null
    if (!uri.scheme.equals("file", true)) return null
    val path = uri.path ?: return null          // URI 已按 UTF-8 解码
    if (path.isBlank()) return null
    val host = uri.authority?.takeIf { it.isNotBlank() && !it.equals("localhost", true) }
    return if (host == null) {
        // /C:/xxx 去掉盘符前那个斜杠；其他形态（如 Linux 的 /home/...）保持原样
        val p = if (path.length >= 3 && path[0] == '/' && path[2] == ':') path.substring(1) else path
        File(p)
    } else {
        File("\\\\$host${path.replace('/', '\\')}")   // UNC：\\host\share\...
    }
}
