package com.githubmanager.desktop

import androidx.compose.runtime.remember
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.application
import androidx.compose.ui.window.rememberWindowState
import androidx.compose.ui.unit.dp
import com.githubmanager.desktop.ui.AppRoot
import com.githubmanager.desktop.ui.GitHubManagerTheme
import com.githubmanager.desktop.util.DesktopPlatform
import com.githubmanager.desktop.vm.AppViewModel
import java.awt.Dimension

fun main() = application {
    val vm = remember { AppViewModel() }

    // 退出时保存偏好并释放协程
    androidx.compose.runtime.DisposableEffect(Unit) {
        onDispose { vm.dispose() }
    }

    Window(
        onCloseRequest = ::exitApplication,
        title = "GitHub 管理器",
        state = rememberWindowState(width = 1100.dp, height = 780.dp)
    ) {
        // 桌面上窗口更大，给个最小尺寸避免布局被挤变形
        window.minimumSize = Dimension(900, 620)

        GitHubManagerTheme(dark = vm.darkTheme) {
            AppRoot(
                vm = vm,
                onOpenUrl = { url ->
                    // 打开系统浏览器；不支持时给出提示而不是静默失败
                    if (!DesktopPlatform.openUrl(url)) {
                        DesktopPlatform.alert("无法打开浏览器，请手动访问：\n$url", "提示")
                    }
                }
            )
        }
    }
}
