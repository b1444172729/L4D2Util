package com.githubmanager.desktop

import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.application
import androidx.compose.ui.window.rememberWindowState
import androidx.compose.ui.unit.dp
import com.githubmanager.desktop.ui.AppRoot
import com.githubmanager.desktop.ui.GitHubManagerTheme
import com.githubmanager.desktop.util.DesktopPlatform
import com.githubmanager.desktop.vm.AppViewModel
import java.awt.Dimension
import java.awt.dnd.DnDConstants
import java.awt.dnd.DropTarget
import java.awt.dnd.DropTargetDragEvent
import java.awt.dnd.DropTargetDropEvent
import java.awt.dnd.DropTargetEvent
import java.awt.datatransfer.DataFlavor
import java.io.File

fun main() = application {
    val vm = remember { AppViewModel() }

    // 退出时保存偏好并释放协程
    androidx.compose.runtime.DisposableEffect(Unit) {
        onDispose { vm.dispose() }
    }

    Window(
        onCloseRequest = ::exitApplication,
        title = "Github 管理器",
        state = rememberWindowState(width = 1100.dp, height = 780.dp)
    ) {
        // 桌面上窗口更大，给个最小尺寸避免布局被挤变形
        window.minimumSize = Dimension(900, 620)

        // ------------------------------------------------------------------
        // 拖拽上传：把文件/文件夹从资源管理器直接拖进窗口即可上传
        //
        // Compose Multiplatform 1.6 还没有 dragAndDropTarget 修饰符，
        // 桌面端要走 AWT 的 DropTarget，挂在窗口的 rootPane 上。
        // Compose 的绘制画布本身不接收拖放事件，会向上冒泡到 rootPane，
        // 所以挂在这里能覆盖整个窗口区域。
        // 这些回调运行在 AWT 事件派发线程上，正好就是 Compose 的主线程，
        // 因此直接改 mutableStateOf 状态是安全的。
        // ------------------------------------------------------------------
        LaunchedEffect(Unit) {
            window.rootPane.dropTarget = object : DropTarget() {
                private fun supported(e: DropTargetDragEvent): Boolean =
                    vm.canAcceptDrop() && e.transferable.isDataFlavorSupported(DataFlavor.javaFileListFlavor)

                override fun dragEnter(e: DropTargetDragEvent) {
                    if (supported(e)) {
                        e.acceptDrag(DnDConstants.ACTION_COPY)
                        vm.dropActive = true
                    } else {
                        e.rejectDrag()
                        vm.dropActive = false
                    }
                }

                override fun dragOver(e: DropTargetDragEvent) {
                    // 必须每次都 acceptDrag，否则光标会变成「禁止」图标
                    if (supported(e)) {
                        e.acceptDrag(DnDConstants.ACTION_COPY)
                        vm.dropActive = true
                    } else {
                        e.rejectDrag()
                        vm.dropActive = false
                    }
                }

                override fun dragExit(e: DropTargetEvent) {
                    vm.dropActive = false
                }

                override fun drop(e: DropTargetDropEvent) {
                    vm.dropActive = false
                    if (!vm.canAcceptDrop() ||
                        !e.transferable.isDataFlavorSupported(DataFlavor.javaFileListFlavor)
                    ) {
                        e.rejectDrop()
                        return
                    }
                    e.acceptDrop(DnDConstants.ACTION_COPY)
                    val dropped = runCatching {
                        @Suppress("UNCHECKED_CAST")
                        val list = e.transferable.getTransferData(DataFlavor.javaFileListFlavor) as? List<*>
                        list?.filterIsInstance<File>().orEmpty()
                    }.getOrElse { emptyList() }
                    e.dropComplete(true)
                    vm.handleDroppedPaths(dropped)
                }
            }
        }

        GitHubManagerTheme(dark = vm.darkTheme) {
            AppRoot(
                vm = vm,
                onOpenUrl = { url ->
                    // 打开系统浏览器；不支持时给出提示而不是静默失败
                    if (!DesktopPlatform.openUrl(url)) {
                        DesktopPlatform.alert("无法打开浏览器，请手动访问：\n$url", "提示")
                    }
                }
            )
        }
    }
}
