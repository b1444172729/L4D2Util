package com.githubmanager.desktop.util

import com.githubmanager.desktop.data.LogBundle
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.nio.file.Files
import java.util.zip.ZipInputStream

object Helpers {

    /** 便于阅读的体积文案 */
    fun size(bytes: Long): String = when {
        bytes < 1024 -> "$bytes B"
        bytes < 1024 * 1024 -> "%.1f KB".format(bytes / 1024.0)
        bytes < 1024 * 1024 * 1024 -> "%.2f MB".format(bytes / 1048576.0)
        else -> "%.2f GB".format(bytes / 1073741824.0)
    }

    /** 把 2024-05-01T08:00:00Z 变成 2024-05-01 08:00 */
    fun time(iso: String): String {
        if (iso.isBlank()) return ""
        return iso.replace("T", " ").removeSuffix("Z").take(16)
    }

    fun mimeOf(name: String): String = runCatching {
        Files.probeContentType(File(name).toPath())
    }.getOrNull() ?: when (name.substringAfterLast('.', "").lowercase()) {
        "apk" -> "application/vnd.android.package-archive"
        "zip" -> "application/zip"
        "txt", "log" -> "text/plain"
        "json" -> "application/json"
        "yml", "yaml" -> "text/yaml"
        "md" -> "text/markdown"
        "png" -> "image/png"
        "jpg", "jpeg" -> "image/jpeg"
        else -> "application/octet-stream"
    }

    /** 下载根目录：用户目录下的 Downloads/GitHubManager，不存在时自动创建 */
    fun downloadsDir(): File = File(System.getProperty("user.home"), "Downloads/GitHubManager")
        .apply { if (!exists()) mkdirs() }

    /** 文件名里的非法字符替换成下划线（Windows 不允许 \ / : * ? " < > |） */
    fun safeName(name: String): String =
        name.replace(Regex("[/\\\\:*?\"<>|]"), "_").ifBlank { "download" }

    /**
     * 保存字节到 Downloads/GitHubManager 目录。
     * 桌面端直接写文件系统，不再需要 MediaStore。
     * @return 完整路径，方便界面直接展示或打开所在文件夹
     */
    fun saveToDownloads(bytes: ByteArray, fileName: String, mime: String): String {
        val target = File(downloadsDir(), safeName(fileName))
        target.writeBytes(bytes)
        return target.absolutePath
    }

    /**
     * GitHub 的运行日志是一个 zip（每个 step 一个文本文件）。
     * 这里解压并拼接成可阅读的文本，方便直接查看；同时保留 zip 供保存。
     */
    fun zipToText(bytes: ByteArray): String {
        val output = StringBuilder()
        ZipInputStream(ByteArrayInputStream(bytes)).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                if (entry.isDirectory) {
                    zip.closeEntry()
                    continue
                }
                output.append("\n===== ${entry.name} =====\n")
                val buffer = ByteArrayOutputStream()
                val tmp = ByteArray(8192)
                while (true) {
                    val n = zip.read(tmp)
                    if (n <= 0) break
                    buffer.write(tmp, 0, n)
                }
                output.append(buffer.toString("UTF-8"))
                zip.closeEntry()
            }
        }
        val merged = output.toString()
        return if (merged.isBlank()) PLACEHOLDER_EMPTY_LOG else stripAnsi(merged)
    }

    /** 从 zip 中挑出指定后缀的文件字节（例如从产物 zip 里直接取出 apk） */
    fun extractFirst(bytes: ByteArray, suffix: String): Pair<String, ByteArray>? {
        ZipInputStream(ByteArrayInputStream(bytes)).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                if (entry.isDirectory || !entry.name.endsWith(suffix, true)) {
                    zip.closeEntry()
                    continue
                }
                val buffer = ByteArrayOutputStream()
                val tmp = ByteArray(65536)
                while (true) {
                    val n = zip.read(tmp)
                    if (n <= 0) break
                    buffer.write(tmp, 0, n)
                }
                zip.closeEntry()
                return entry.name.substringAfterLast('/') to buffer.toByteArray()
            }
        }
        return null
    }

    /** 读取文件全部字节（用于上传） */
    fun readFile(file: File): ByteArray {
        val bytes = file.readBytes()
        if (bytes.isEmpty()) throw IllegalStateException("所选文件为空")
        return bytes
    }

    /**
     * 把已存在的大文件写入 Downloads。
     * 与 saveToDownloads(bytes) 的区别：走流拷贝，不会把整个文件读进内存。
     * @return 完整路径
     */
    fun saveFileToDownloads(source: File, fileName: String, mime: String): String {
        val target = File(downloadsDir(), safeName(fileName))
        source.inputStream().use { input -> target.outputStream().use { out -> input.copyTo(out) } }
        return target.absolutePath
    }

    /**
     * 读取文件开头的最多 n 个字节。
     *
     * 注意：不能用 InputStream.readNBytes(int) —— 那是 Android 13（API 33）才提供的方法，
     * 低版本会直接 NoSuchMethodError 崩溃。
     */
    private fun readHead(file: File, n: Int): ByteArray {
        val buf = ByteArray(n)
        FileInputStream(file).use { input ->
            var off = 0
            while (off < n) {
                val r = input.read(buf, off, n - off)
                if (r <= 0) break
                off += r
            }
            return if (off == n) buf else buf.copyOf(off)
        }
    }

    /**
     * 校验文件是否为 ZIP（开头 4 字节的 PK 魔数 0x50 0x4B）。
     *
     * 为什么需要：产物下载偶尔会拿到 HTML 错误页或空响应，此时若直接当 zip 解压
     * 会失败并静默退化成「保存原始 zip」，用户就会以为「下载 APK 得到的也是 zip」。
     * 先校验就能把真实原因报出来。
     */
    fun isZip(file: File): Boolean = runCatching {
        val head = readHead(file, 4)
        head.size == 4 && head[0] == 0x50.toByte() && head[1] == 0x4B.toByte()
    }.getOrDefault(false)

    /** 文件开头的十六进制片段，用于在报错时判断到底下载到了什么 */
    fun headHex(file: File, bytes: Int = 24): String = runCatching {
        readHead(file, bytes).joinToString(" ") { b -> "%02X".format(b) }
    }.getOrDefault("<无法读取>")

    /** 列出 zip 内的条目名（最多 limit 个），用于诊断「为什么没找到 APK」 */
    fun listZipEntries(zip: File, limit: Int = 20): List<String> {
        val names = mutableListOf<String>()
        runCatching {
            ZipInputStream(FileInputStream(zip)).use { stream ->
                while (names.size < limit) {
                    val entry = stream.nextEntry ?: break
                    names += if (entry.isDirectory) "${entry.name}/" else entry.name
                }
            }
        }
        return names
    }

    /**
     * 从 zip 文件里解出第一个指定后缀的条目，写到 destDir。
     * 返回 (文件名, 文件)；找不到返回 null。同样走流，适合大文件。
     */
    fun extractFirstToFile(zip: File, suffix: String, destDir: File): Pair<String, File>? {
        ZipInputStream(zip.inputStream()).use { stream ->
            while (true) {
                val entry = stream.nextEntry ?: break
                if (entry.isDirectory || !entry.name.endsWith(suffix, true)) {
                    stream.closeEntry()
                    continue
                }
                val name = entry.name.substringAfterLast('/').ifBlank { "app.apk" }
                if (!destDir.exists()) destDir.mkdirs()
                val out = File(destDir, name)
                out.outputStream().use { output -> stream.copyTo(output) }
                stream.closeEntry()
                return name to out
            }
        }
        return null
    }

    /** 文件大小；取不到时返回 -1 */
    fun fileSize(file: File): Long = runCatching { file.length() }.getOrDefault(-1L)

    /** 文件显示名 */
    fun displayName(file: File): String = file.name.ifBlank { "file" }

    /** 判断字节内容是否为文本（不含 0 字节，且能按 UTF-8 解码） */
    fun isText(bytes: ByteArray): Boolean {
        if (bytes.isEmpty()) return true
        if (bytes.any { it == 0.toByte() }) return false
        return runCatching { String(bytes, Charsets.UTF_8) }.isSuccess
    }

    /** 日志为空时的占位文案（不含括号，便于各处统一判断） */
    const val PLACEHOLDER_EMPTY_LOG = "日志为空，可能尚未开始或已过期"

    /** 目录树中的一个文件：relativePath 是相对所选文件夹的路径，用于拼出仓库内的目标路径 */
    data class TreeFile(val relativePath: String, val file: File, val size: Long)

    /** 单次上传文件夹的文件数上限，防止误选根目录导致卡死 */
    const val MAX_TREE_FILES = 300

    /**
     * 递归遍历文件夹，返回其中所有文件（含子目录，保留相对路径）。
     *
     * 桌面端比 Android 简单得多：直接用 java.io.File 遍历即可，
     * 不需要 SAF 的目录树 URI，也不存在「选不了文件夹」的问题。
     */
    fun listTree(root: File): List<TreeFile> {
        val result = mutableListOf<TreeFile>()
        fun walk(dir: File, prefix: String, depth: Int) {
            if (depth > 10 || result.size >= MAX_TREE_FILES) return
            val children = dir.listFiles() ?: return
            for (f in children) {
                if (result.size >= MAX_TREE_FILES) return
                val rel = if (prefix.isBlank()) f.name else "$prefix/${f.name}"
                if (f.isDirectory) {
                    walk(f, rel, depth + 1)
                } else {
                    result.add(TreeFile(rel, f, f.length()))
                }
            }
        }
        walk(root, "", 0)
        return result
    }

    /** ANSI 转义序列（终端颜色、光标控制），形如 ESC[31m */
    private val ANSI = Regex("\u001B\\[[0-9;?]*[ -/]*[@-~]")

    /**
     * 去掉终端颜色控制符。
     * GitHub Actions 的日志里混有 ANSI 序列，直接显示会看到乱码字符。
     */
    fun stripAnsi(text: String): String = ANSI.replace(text, "")

    /** zipToText 在没有任何内容时会返回占位提示，这里判断是否真的为空 */
    fun isEmptyLog(text: String): Boolean =
        text.isBlank() || text.startsWith(PLACEHOLDER_EMPTY_LOG)

    /**
     * 把完整日志按「重点 / 错误 / 警告」分级。
     * 目的：手机上不用在几千行里翻，直接看关键结论。
     */
    fun parseLogs(raw: String, sizeBytes: Long): LogBundle {
        val key = LinkedHashSet<String>()
        val errors = LinkedHashSet<String>()
        val warnings = LinkedHashSet<String>()

        // 无意义的行不进重点，避免刷屏
        fun isNoise(line: String): Boolean {
            val t = line.trim()
            return t.isBlank() || t.startsWith("=====") ||
                "UP-TO-DATE" in t || "NO-SOURCE" in t || "SKIPPED" in t ||
                t.startsWith("To honour the JVM settings") ||
                t.startsWith("Daemon will be stopped")
        }

        raw.lineSequence().forEach { line ->
            val t = line.trim()
            if (t.isBlank()) return@forEach

            // 错误：Kotlin e: 、Gradle 失败、异常
            val isError = t.startsWith("e: ") || ": error:" in t ||
                t.startsWith("FAILURE:") || t.endsWith("FAILED") ||
                "Execution failed for task" in t || "Compilation error" in t ||
                (t.contains("Exception") && !t.contains("继续"))

            // 警告：Kotlin w: 、Gradle warning
            val isWarning = t.startsWith("w: ") || ": warning:" in t ||
                t.startsWith("WARNING:") || "warning:" in t.lowercase() ||
                "is deprecated" in t.lowercase()

            when {
                isError -> errors += t
                isWarning -> warnings += t
            }

            // 重点：构建结论、实际执行的任务、产物路径、耗时
            val isKey = "BUILD SUCCESSFUL" in t || "BUILD FAILED" in t ||
                "actionable tasks" in t || "actionable task" in t ||
                (t.startsWith("> Task") && !isNoise(t)) ||
                (".apk" in t && ("/" in t || "outputs" in t))
            if (isKey && !isNoise(t)) key += t
        }

        // 完全没有重点时（例如日志还没开始），给一句提示
        if (key.isEmpty()) key += "（暂无关键输出，运行可能尚未开始或日志为空）"
        return LogBundle(raw, key.toList(), errors.toList(), warnings.toList(), sizeBytes)
    }
}
