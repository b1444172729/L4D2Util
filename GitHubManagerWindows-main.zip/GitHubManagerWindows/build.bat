@echo off
chcp 65001 >nul
setlocal

echo ============================================
echo   GitHub 管理器 · Windows 版构建脚本
echo ============================================
echo.

REM ---- 1. 检查 Java ----
where java >nul 2>nul
if errorlevel 1 (
    echo [错误] 没有找到 java，请先安装 JDK 17 或更高版本。
    echo        下载地址：https://adoptium.net/
    goto :fail
)

for /f "tokens=3" %%v in ('java -version 2^>^&1 ^| findstr /i "version"') do set JVER=%%v
set JVER=%JVER:"=%
echo 检测到 Java 版本：%JVER%

REM 取主版本号（17 / 21 ...）；JDK 9 以前是 1.8 这种写法
for /f "tokens=1 delims=." %%a in ("%JVER%") do set JMAJOR=%%a
if "%JMAJOR%"=="1" (
    for /f "tokens=2 delims=." %%b in ("%JVER%") do set JMAJOR=%%b
)
if %JMAJOR% LSS 17 (
    echo [错误] 需要 JDK 17 或更高，当前是 %JVER%。
    echo        Compose Desktop 不支持更低的版本。
    goto :fail
)

REM ---- 2. 定位 Gradle ----
set GRADLE_CMD=
if exist "%~dp0gradlew.bat" (
    set GRADLE_CMD=%~dp0gradlew.bat
    echo 使用项目自带的 Gradle Wrapper
) else (
    where gradle >nul 2>nul
    if errorlevel 1 (
        echo [错误] 既没有 gradlew.bat，PATH 里也没有 gradle。
        echo.
        echo 两种解决办法（任选其一）：
        echo   1. 用 IntelliJ IDEA 打开本项目，它会自动生成 gradlew 并下载 Gradle
        echo   2. 手动安装 Gradle 8.7：https://gradle.org/releases/ 并加入 PATH
        echo   3. 直接用 GitHub Actions 构建（见 README.md 方式 A）
        goto :fail
    )
    set GRADLE_CMD=gradle
    echo 使用 PATH 中的 gradle
)

REM ---- 3. 选择任务 ----
echo.
echo 请选择要执行的任务：
echo   [1] 直接运行            （gradle run，调试最快）
echo   [2] 生成 exe 免安装版   （gradle packageExe）
echo   [3] 生成 msi 安装包     （gradle packageMsi）
echo   [4] 两者都生成
echo.
set /p CHOICE=输入序号后回车（默认 1）：
if "%CHOICE%"=="" set CHOICE=1

if "%CHOICE%"=="1" set TASK=run
if "%CHOICE%"=="2" set TASK=packageExe
if "%CHOICE%"=="3" set TASK=packageMsi
if "%CHOICE%"=="4" set TASK=packageExe packageMsi
if not defined TASK (
    echo [错误] 无效选项：%CHOICE%
    goto :fail
)

echo.
echo 执行：%GRADLE_CMD% %TASK%
echo 首次构建会下载依赖，可能需要 5-15 分钟，请耐心等待...
echo.

call %GRADLE_CMD% --console=plain %TASK%
if errorlevel 1 (
    echo.
    echo [失败] 构建出错，请把上面的报错信息反馈。
    goto :fail
)

echo.
echo ============================================
echo   构建成功
echo ============================================
if not "%TASK%"=="run" (
    echo 产物位置：
    echo   build\compose\binaries\main-release\exe\
    echo   build\compose\binaries\main-release\msi\
)
endlocal
exit /b 0

:fail
echo.
echo 按任意键退出...
pause >nul
endlocal
exit /b 1
