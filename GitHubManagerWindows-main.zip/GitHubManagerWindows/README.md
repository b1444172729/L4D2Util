# GitHub 管理器 · Windows 桌面版

由 Android 版源码移植而来，功能一一对应：上传 / 下载 / 删除 / 重命名、触发编译、
实时日志、下载 APK 与产物、分支、Issue、PR、Release 等。

技术栈：Kotlin + Compose Desktop（Material3），运行在 JVM 17 上。

---

## 一、环境要求

| 项目 | 版本 | 说明 |
|---|---|---|
| JDK | **17 或以上** | Compose Desktop 强制要求，JDK 11/8 不行 |
| Gradle | 8.7 | 用 IntelliJ 打开会自动下载，无需手动装 |

检查 Java 版本：

```bat
java -version
```

若显示不是 17，去装一个 [Temurin JDK 17](https://adoptium.net/)，装完重启命令行再试。

---

## 二、三种构建方式

### 方式 A：GitHub Actions（推荐，不用配环境）

1. 把整个 `GitHubManagerWindows` 文件夹打包成 zip 上传到你的 GitHub 仓库根目录
2. 仓库里需要有本项目的 `.github/workflows/build-windows.yml`
   （**注意要放在 zip 外面**，即仓库根的 `.github/workflows/` 下，就和 Android 版一样）
3. 推送后 Actions 自动在 `windows-latest` 上编译，产出 `.exe` 和 `.msi`
4. 下载 Artifacts 即可安装

> 为什么必须用 Windows 运行器：Compose Desktop 的 exe / msi 只能在 Windows 上打包，
> Linux / macOS 运行器打不出来。

### 方式 B：IntelliJ IDEA（本地开发最省事）

1. IDEA → File → Open，选择 `GitHubManagerWindows` 文件夹
2. IDEA 会自动识别 Gradle 项目并下载 Gradle 8.7 与依赖，右下角进度条走完即可
3. 右侧 Gradle 面板 → `Tasks` → `compose desktop`：
   - `run` —— 直接启动应用（调试用，最快）
   - `packageExe` —— 生成免安装版 `GitHubManager.exe`
   - `packageMsi` —— 生成 `GitHubManager.msi` 安装包

### 方式 C：命令行

装好 Gradle 8.7 并加入 PATH 后，在项目目录执行：

```bat
gradle run          :: 直接运行
gradle packageExe   :: 生成 exe
gradle packageMsi   :: 生成 msi
```

也可用本目录下的 `build.bat`，它会自动检查 Java 版本并调用 Gradle。

产物位置：

```
build/compose/binaries/main-release/exe/GitHubManager.exe
build/compose/binaries/main-release/msi/GitHubManager.msi
```

---

## 三、首次运行

启动后用 GitHub 私人令牌登录（和 Android 版一样）：

- 需要 `repo`（读写文件）+ `workflow`（触发编译 / 读日志）权限
- 没有 `workflow` 也能管文件，但编译页的触发与日志会 403

---

## 四、与 Android 版的差异

| 能力 | Android 版 | Windows 版 |
|---|---|---|
| 文件保存位置 | 手机「下载/GitHubManager」 | `C:\Users\你的用户名\Downloads\GitHubManager` |
| 文件选择 | 系统文件选择器 | 原生文件对话框（文件 / 多选 / 文件夹） |
| 剪贴板 | 系统剪贴板 | 系统剪贴板 |
| 打开网页 | 浏览器 | 系统默认浏览器 |
| 设置存储 | SharedPreferences | 系统偏好（Windows 上存注册表用户项） |
| 返回键 | 系统返回键 | **Esc** 键（先关日志页，再关运行详情页） |
| 上传文件夹 | 受 SAF 限制，部分管理器选不了目录 | 直接选目录，无限制 |

窗口默认 1100×780，最小 900×620。

---

## 五、常见问题

**Q：提示 `Unsupported class file major version` 或 Kotlin 版本报错**
JDK 版本不对，必须是 17。用 `java -version` 确认。

**Q：Gradle 下载依赖很慢**
在 `settings.gradle.kts` 的 `repositories` 里加阿里云镜像：

```kotlin
maven("https://maven.aliyun.com/repository/public")
maven("https://maven.aliyun.com/repository/google")
```

**Q：点「上传文件夹」没反应**
确认选的是文件夹而不是文件。桌面端不存在手机端那种选不了目录的问题。

**Q：下载 APK 得到的是 zip**
传输页会显示原因。若提示「产物 ZIP 里没有 .apk」，说明产物本身不含 apk
（比如只有 aab），此时保存原始 zip 是正确行为。
