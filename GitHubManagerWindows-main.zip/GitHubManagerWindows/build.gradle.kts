import org.jetbrains.compose.desktop.application.dsl.TargetFormat

plugins {
    kotlin("jvm") version "2.0.21"
    id("org.jetbrains.compose") version "1.6.11"
    // 自 Kotlin 2.0 起，Compose 编译器从 Compose Multiplatform 插件中剥离、
    // 合并进了 Kotlin 官方仓库。官方明确要求：从 Compose Multiplatform 1.6.10 起，
    // 凡是使用 org.jetbrains.compose 的模块，都必须显式再声明这个插件，
    // 且版本要与 Kotlin 版本一致（这里是 2.0.21）。
    // 少了它，@Composable 函数不会被编译器插桩，构建会失败或运行时报奇怪的错误。
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.21"
}

group = "com.githubmanager"
version = "1.0.0"

repositories {
    mavenCentral()
    maven("https://maven.pkg.jetbrains.space/public/p/compose/dev")
    google()
}

dependencies {
    // Compose Desktop 运行时（按当前系统自动选择 windows-x64 / linux-x64 / macos-x64）
    implementation(compose.desktop.currentOs)
    implementation(compose.material3)
    // Icons.Rounded.* 全部来自这个扩展包
    implementation(compose.materialIconsExtended)

    // 网络与 JSON。
    // 注意：org.json 在 Android 上是系统内置库，但桌面 JVM 没有，必须显式引入，
    // 否则 GitHubApi.kt 里的 JSONObject / JSONArray 会全部报 unresolved reference。
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.json:json:20240303")

    // Dispatchers.Main 在桌面端需要绑定到 Swing 的事件派发线程
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-swing:1.9.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.9.0")

    implementation(kotlin("stdlib"))
}

kotlin {
    jvmToolchain(17)

    //
    // 全局豁免 Compose 的实验性 API（等价于给每个文件加 @OptIn）。
    //
    // 为什么必须这么做：Android 版用的是 androidx Compose BOM 2025.08，
    // 其中 HorizontalPager 等 foundation API 早已稳定，不需要任何 opt-in；
    // 而桌面版用的 Compose Multiplatform 1.6.11，内置的 foundation 才 1.6.7，
    // 这些 API 仍标着 @ExperimentalFoundationApi，不声明就直接编译失败。
    //
    // 与其逐个文件补 @OptIn（漏一个就要再跑一轮十几分钟的 CI），
    // 不如在编译期统一放行。这只影响编译期检查，不改变运行时行为。
    //
    compilerOptions {
        freeCompilerArgs.addAll(
            "-opt-in=androidx.compose.foundation.ExperimentalFoundationApi",
            "-opt-in=androidx.compose.material3.ExperimentalMaterial3Api",
            "-opt-in=androidx.compose.ui.ExperimentalComposeUiApi",
            "-opt-in=androidx.compose.animation.ExperimentalAnimationApi",
            "-opt-in=androidx.compose.foundation.layout.ExperimentalLayoutApi",
            "-opt-in=kotlinx.coroutines.ExperimentalCoroutinesApi"
        )
    }
}

compose.desktop {
    application {
        mainClass = "com.githubmanager.desktop.MainKt"

        nativeDistributions {
            targetFormats(TargetFormat.Msi, TargetFormat.Exe)
            packageName = "GitHubManager"
            packageVersion = "1.0.0"
            description = "GitHub 仓库管理器（桌面版）"
            vendor = "GitHubManager"

            windows {
                // 生成开始菜单快捷方式与桌面快捷方式
                menuGroup = "GitHubManager"
                shortcut = true
                dirChooser = true
                upgradeUuid = "b6f2f0a4-3f6d-4a2e-9a71-0f7f2c8e5d31"
            }
        }
    }
}
