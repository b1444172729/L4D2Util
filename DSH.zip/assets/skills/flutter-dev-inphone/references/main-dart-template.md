# 深色 M3 页面模板（Flutter）

直接拷进 `lib/main.dart` 就能跑（`flutter analyze` 无告警），再按需求改内容。
刻意保留了 **loading / error / empty / data 四态** 和统一视觉常量，别把这些删掉。

```dart
import 'dart:async';
import 'package:flutter/material.dart';

void main() => runApp(const SampleApp());

/// 全局视觉常量（禁止在页面里写魔法值）
class AppColors {
  static const bg = Color(0xFF0D1117);
  static const card = Color(0xFF17171E);
  static const stroke = Color(0xFF2C2C36);
  static const text = Color(0xFFE6E0E9);
  static const sub = Color(0xFF9AA6B2);
  static const accent = Color(0xFFD0BCFF);
}

class SampleApp extends StatelessWidget {
  const SampleApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '示例应用',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: AppColors.bg,
        colorScheme: const ColorScheme.dark(
          primary: AppColors.accent,
          surface: AppColors.card,
          onSurface: AppColors.text,
        ),
        filledButtonTheme: FilledButtonThemeData(
          style: FilledButton.styleFrom(
            shape: const StadiumBorder(),
            padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 14),
          ),
        ),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<String>? _items; // null = 加载中
  String? _error;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _timer?.cancel(); // 资源必须释放
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      _items = null;
      _error = null;
    });
    try {
      await Future<void>.delayed(const Duration(milliseconds: 600));
      if (!mounted) return;
      setState(() => _items = <String>[]); // 真实场景换成网络数据
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = '加载失败：$e');
    }
  }

  void _add() {
    setState(() => _items = <String>[...?_items, '条目 ${(_items?.length ?? 0) + 1}']);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
          children: <Widget>[
            _hero(),
            const SizedBox(height: 14),
            _section('内容'),
            _content(),
          ],
        ),
      ),
    );
  }

  Widget _hero() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[Color(0xFF53389E), Color(0xFF3B6FD4)],
        ),
        borderRadius: BorderRadius.all(Radius.circular(26)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          const Text('示例应用',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.white)),
          const SizedBox(height: 8),
          const Text('副标题写一行说明，控制在 20 字以内。',
              style: TextStyle(fontSize: 13, color: Color(0xD9FFFFFF))),
          const SizedBox(height: 16),
          FilledButton(onPressed: _add, child: const Text('新增一条')),
        ],
      ),
    );
  }

  Widget _section(String text) {
    return Padding(
      padding: const EdgeInsets.only(top: 16, bottom: 10),
      child: Row(
        children: <Widget>[
          Container(width: 3, height: 15, color: AppColors.accent),
          const SizedBox(width: 8),
          Text(text,
              style: const TextStyle(
                  fontSize: 14, fontWeight: FontWeight.bold, color: AppColors.accent)),
        ],
      ),
    );
  }

  /// loading / error / empty / data 四态，一个都不能少
  Widget _content() {
    if (_error != null) {
      return _boxed(
        Column(
          children: <Widget>[
            Text(_error!, style: const TextStyle(color: AppColors.sub)),
            const SizedBox(height: 12),
            OutlinedButton(onPressed: _load, child: const Text('重试')),
          ],
        ),
      );
    }
    if (_items == null) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 36),
        child: Center(child: CircularProgressIndicator()),
      );
    }
    if (_items!.isEmpty) {
      return _boxed(
        const Text('暂无数据\n这里放空状态，别留白屏',
            textAlign: TextAlign.center,
            style: TextStyle(color: AppColors.sub, height: 1.6)),
      );
    }
    return Card(
      color: AppColors.card,
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(22),
        side: const BorderSide(color: AppColors.stroke),
      ),
      child: Column(
        children: List<Widget>.generate(_items!.length, (i) {
          return ListTile(
            title: Text(_items![i], style: const TextStyle(fontSize: 14, color: AppColors.text)),
            trailing: const Icon(Icons.chevron_right, color: AppColors.sub),
            onTap: () => ScaffoldMessenger.of(context)
                .showSnackBar(SnackBar(content: Text('点了 ${_items![i]}'))),
          );
        }),
      ),
    );
  }

  Widget _boxed(Widget child) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 32, horizontal: 16),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: AppColors.stroke),
      ),
      child: child,
    );
  }
}
```

## 加依赖前先想清楚

容器里 `pub get` 走 `pub.flutter-io.cn`，但：
- 纯 Dart 包（`http`、`intl`、`shared_preferences` 等）通常没问题；
- 含原生代码/Firebase/大量插件的包很容易在构建阶段炸，**能不用就不用**，
  用 `dart:io`、`dart:convert`、`package:flutter/material.dart` 自带能力先实现。
