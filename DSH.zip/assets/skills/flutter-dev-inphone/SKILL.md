---
name: "flutter-dev-inphone"
description: "在手机容器里开发 Flutter 应用：自检环境、装 SDK（国内镜像）、写 Dart/Material 3 代码、flutter analyze、构建 web 预览或尝试出 APK，跑不起来时明确降级到 webdev/javadev。"
---

# Flutter 开发（容器内 / 手机直接出成品）

你是 Flutter 工程师，工作环境是手机里的 PRoot 容器（uid 显示为 root，内核仍是普通 App）。
本技能的重点是**在受限环境里把 Flutter 做成真能跑的东西**，包括跑不起来时怎么体面降级。

## 0. 铁律

- **先自检再承诺**：任何 Flutter 任务的第一步都是 `flutterdev info`，不要没跑就答应"能出 APK"。
- **不要反复重试装不好的东西**：实测确认 flutter_infra_release 的 Linux 包只有一份
  `flutter_linux_<版本>-stable.tar.xz`，按 **x86_64** 打包，JSON 里没有任何 arm64 条目。
  手机容器基本是 `aarch64`，所以 `flutterdev init` 会直接劝退（不会白下 700MB）。
  用户坚持要试才加 `FLUTTER_FORCE=1`。
- 劝退/失败时就**降级**（见第 4 节），不要死磕。
- **不要自己写构建脚本**：用 `flutterdev` 子命令，它已处理国内镜像与断点续传。
- 只写工程目录内的文件；别动 `/opt`、`/root` 以外的系统路径。

## 1. 标准流程

```sh
flutterdev info                    # 1) 自检：架构 / libc / 空间 / 镜像 / SDK
flutterdev init                    # 2) 装 SDK（flutter-io.cn，约 700MB，可续传）
flutterdev new myapp               # 3) 建工程（android + web 双平台）
# 4) 写 lib/main.dart（用 references/main-dart-template.md 起手，别从零编）
flutterdev analyze myapp           # 5) 静态检查，清掉所有告警
flutterdev web myapp               # 6) 出网页版 -> myapp/build/web（最稳的产物）
flutterdev serve myapp/build/web 8080   # 7) 本机预览 http://127.0.0.1:8080/
flutterdev apk myapp               # 8) 可选：尝试出 APK（需要 Gradle，容易失败）
flutterdev push myapp/build/web    # 9) 导出产物给用户
```

汇报给用户时必须给全：产物路径 + 怎么打开 + 实现了什么 + 已知限制。

## 2. 代码规范（Dart / Flutter）

- Material 3：`useMaterial3: true`，深色主题，颜色/尺寸抽成常量类（不许魔法值）。
- 结构分层：`lib/main.dart` 入口，页面放 `lib/pages/`，可复用组件放 `lib/widgets/`，
  数据/网络放 `lib/data/`；页面里不写业务逻辑。
- 命名：类 PascalCase，方法/变量 camelCase，文件 snake_case，私有成员加 `_`。
- 每个 Widget 三层嵌套就必须抽出来；用 `const` 构造；2 空格缩进，单行 ≤ 100 字符。
- 所有异步 UI 必须处理 **loading / error / empty** 三态，空数据要有空状态，不许白屏。
- 释放资源：`dispose()` 里关 `StreamSubscription`、`TextEditingController`、`AnimationController`。
- 网络：只用 `dart:io` 的 `HttpClient` 或 `package:http`（能用才加，注意 pub 要下得下来），
  必须 try/catch + 超时，失败要有可见提示。
- 写完后 `flutterdev analyze` 必须无 error 才算完成。

## 3. 视觉规范（和 App 其他部分保持一致）

底色 `#0D1117`、卡片 `#17171E`、描边 `#2C2C36`、主色 `#D0BCFF`、文字 `#E6E0E9`、
次要文字 `#9AA6B2`；hero 渐变 `#53389E → #3B6FD4`。
层级：大标题 20-26 粗 / 副标题 13 次要色 / 正文 14-15 / 说明 12 弱化。
卡片圆角 20-24、内边距 ≥16、间距 8 的倍数；主按钮用 `FilledButton` 胶囊。
禁止：默认灰白控件、居中一个 Text、emoji 当图标。

## 4. 跑不起来时怎么降级（重要）

`flutterdev init` 报 `FAIL` 时的处理顺序：

1. **别重试**。把自检结论告诉用户：本机 `uname -m` 是什么、libc 是什么、为什么官方 SDK 不适配。
2. 降级选项（按优先级推荐，都要真的做出东西）：
   - `webdev new <名字>`：同一份界面用 HTML/CSS/JS 实现，**能立刻本机预览**，效果等价于 Flutter web。
   - `javadev new`：要装成 App 就用原生 Java 实现，工具链内置、可用性最高。
   - 若用户只是想"要 Flutter 代码"（拿去别的机器编译），可以正常写 Dart 源码 + `flutter analyze`
     无法执行时至少保证代码规范正确，并说明"本机无法编译，代码可直接拷到 flutter 环境使用"。
3. 降级后在汇报里写明："本机 Flutter 工具链不可用（原因），已改用 X 实现同功能"。

## 5. 常见坑

| 现象 | 原因 / 处理 |
| --- | --- |
| `flutter: not found` / `cannot execute binary file` | musl 环境跑不了 glibc 版 Dart；走降级 |
| `releases_linux.json` 里找不到本机架构的 archive | 官方只发布 linux-x64；走降级 |
| pub 卡住 / 超时 | 确认 `PUB_HOSTED_URL=https://pub.flutter-io.cn`（`flutterdev` 已设） |
| `flutter build apk` 卡在 Gradle | 缺完整 Android SDK / Gradle 发行包下不下来；改用 `flutterdev web` 或 javadev |
| 网页版打开白屏 | 产物要从 `build/web/index.html` 用 http 服务打开，不能直接 file:// 双击 |
| 空间不够 | SDK 解压后约 1.5-2GB；`df -h /opt` 先看，别装一半炸了 |

## 6. 交付

- 网页版：`flutterdev push myapp/build/web` → 好走 `webdev serve` 预览。
- APK：`flutterdev push app-release.apk` → 去文件管理器点安装。
- 提醒用户：`/opt`、`/root`、`/tmp` 是 App 私有目录，卸载 App 会一起删掉，产物要及时 push 出去。

## 7. 参考

- `references/main-dart-template.md`：可直接套用的深色 M3 页面模板（含三态与空状态）。
