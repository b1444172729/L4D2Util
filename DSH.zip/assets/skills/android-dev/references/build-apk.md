# 构建 APK 细节（容器内）

## 最小手动流水线（javadev build 就是这么做的）

```bash
P=/root/prj; A=/opt/dt/android.jar; T=/opt/dt
mkdir -p $P/build/{compiled,gen,classes,dex}

# 1) 资源（有 res/ 才需要）
$T/bin/aapt2 compile --dir $P/res -o $P/build/compiled/res.zip

# 2) 链接：产出二进制清单 + resources.arsc + R.java
$T/bin/aapt2 link -o $P/build/base.apk -I $A \
    --manifest $P/AndroidManifest.xml --java $P/build/gen \
    --min-sdk-version 21 --target-sdk-version 34 \
    $P/build/compiled/res.zip

# 3) javac
javac -source 8 -target 8 -classpath $A -d $P/build/classes \
      $(find $P/src $P/build/gen -name '*.java')

# 4) d8 转 dex
( cd $P/build/classes && jar cf $P/build/classes.jar . )
java -cp $T/jar/r8.jar com.android.tools.r8.D8 \
     --min-api 21 --lib $A --output $P/build/dex $P/build/classes.jar

# 5) 塞进 APK + 对齐
cp $P/build/base.apk $P/build/unsigned.apk
( cd $P/build/dex && zip -q -X $P/build/unsigned.apk classes.dex )
$T/bin/zipalign -f -p 4 $P/build/unsigned.apk $P/build/aligned.apk

# 6) 签名
java -jar $T/jar/uber-apk-signer.jar -a $P/build/aligned.apk -o $P/build/out --allowResign
```

产物：`$P/build/out/*-aligned-signed.apk`，可直接安装。

## 什么时候需要 Gradle / AAPT 之外的东西

- 依赖多（AndroidX、Compose、OkHttp…）：手写 javac 不现实，用 Gradle。
  精简版联网时可 `javadev deps git openjdk17-jdk`，然后 `./gradlew assembleDebug`。
- 需要 `aar` 依赖：先解压 `classes.jar` 丢进 `libs/`。
- 原生库 `.so`：放 `lib/<abi>/`，清单加 `android:extractNativeLibs="true"`。
- 想缩小包：用 `r8`（`java -cp /opt/dt/jar/r8.jar com.android.tools.r8.R8 ...`）而不是 D8。

## 常见报错

- `aapt2: not found` → 没执行 `javadev init`（精简版）或内置资产没解出。
- `error: resource ... not found` → 忘了 `-I android.jar`，或 res/ 没 compile。
- `D8: Unsupported class file` → javac 用了高版本，改成 `-source 8 -target 8`。
- `Failure [INSTALL_PARSE_FAILED_NO_CERTIFICATES]` → 没签名，跑第 6 步。
- 装不上（与旧包冲突）→ `adb uninstall` 或先卸载同包名的旧版本。
