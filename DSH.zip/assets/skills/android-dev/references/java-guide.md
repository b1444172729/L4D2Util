# Java 速查（够用来写安卓 App 的日常语法）

## 变量与类型
```java
int i = 0; long l = 10L; double d = 1.5; boolean b = true;
String s = "hi"; int[] a = {1,2,3}; List<String> xs = new ArrayList<>();
Map<String,Integer> m = new HashMap<>(); m.put("k", 1);
```

## 控制流
```java
if (x > 0) { } else if (x == 0) { } else { }
for (int i = 0; i < n; i++) { }
for (String s : xs) { }
while (cond) { }   do { } while (cond);
switch (v) { case 1: break; default: break; }
```

## 类
```java
public class Foo {
    private int x;                       // 字段
    public Foo(int x) { this.x = x; }    // 构造
    public int get() { return x; }       // 方法
    public static void main(String[] a) { }
}
interface Bar { void run(); }
```

## 异常
```java
try { risky(); }
catch (IOException e) { e.printStackTrace(); }
finally { cleanup(); }
```

## 字符串 / 集合
```java
s.length(); s.substring(1); s.split(","); s.trim();
s.replace("a","b"); String.format("%d-%s", 1, "x");
StringBuilder sb = new StringBuilder(); sb.append("x");
xs.size(); xs.get(0); xs.add("y"); xs.contains("y");
m.get("k"); m.containsKey("k"); for (var e : m.entrySet()) { }
```

## 文件 / IO
```java
File f = new File("/root/a.txt");
try (FileInputStream in = new FileInputStream(f)) { byte[] b = in.readAllBytes(); }
Files.writeString(Path.of("/root/a.txt"), "hi");
```

## 线程
```java
new Thread(() -> { /* 后台 */ }).start();
// 回到主线程（Android）：activity.runOnUiThread(() -> { });
```

## 安卓最小 Activity
```java
public class MainActivity extends Activity {
  @Override protected void onCreate(Bundle s) {
    super.onCreate(s);
    TextView v = new TextView(this);
    v.setText("Hello"); v.setTextSize(20);
    setContentView(v);
  }
}
```

## 清单要点
```xml
<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="com.demo.hello">
  <application android:label="Hello" android:theme="@android:style/Theme.Material.Light">
    <activity android:name=".MainActivity" android:exported="true">
      <intent-filter>
        <action android:name="android.intent.action.MAIN"/>
        <category android:name="android.intent.category.LAUNCHER"/>
      </intent-filter>
    </activity>
  </application>
</manifest>
```

## 常用 Android API
```java
// 提示
Toast.makeText(this, "保存成功", Toast.LENGTH_SHORT).show();
// 布局（代码写，不用 XML）
LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL);
l.addView(new TextView(this));
// 读写私有文件
File f = new File(getFilesDir(), "x.txt");
// 启动 Activity
startActivity(new Intent(this, OtherActivity.class));
// 权限（运行时）
if (checkSelfPermission("android.permission.CAMERA") != PackageManager.PERMISSION_GRANTED)
    requestPermissions(new String[]{"android.permission.CAMERA"}, 1);
```
