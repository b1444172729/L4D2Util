---
name: android-dev
description: 在手机内置 Linux 容器里写代码、跑脚本、构建安卓 APK。涵盖 Java 开发模板、常用语言（Python/JS/C/Shell）速查、以及用 javadev 一条命令「编译→dex→打包→对齐→签名」出可安装 APK 的完整流程。
---

# Android 开发（容器内直接写代码 + 出 APK）

你现在处在一台手机上的 Alpine Linux 容器里（PRoot 沙箱，容器内 uid=0）。
工具链在 `/opt/dt`，**内置版离线可用**；精简版执行 `javadev init` / `apkmod init`
会从国内镜像（清华 Alpine / 阿里云 Google Maven）补齐。

## 0. 先确认环境

```bash
javadev info          # 看 JDK / aapt2 / r8 / android.jar 是否就绪
apkmod which          # 看逆向工具链来源（内置 or 需下载）
```

缺工具就先补：

```bash
javadev init                    # JDK + 构建工具（内置版秒过）
javadev deps python3 nodejs git vim   # 常用运行时/工具（走国内镜像）
```

## 1. Java 开发：写工程 → 出 APK

### 1.1 生成一个最小可编译工程

```bash
javadev new com.demo.hello Hello
# 生成：
#   hello/AndroidManifest.xml   （package=com.demo.hello）
#   hello/src/com/demo/hello/MainActivity.java
#   hello/build.sh
```

### 1.2 工程结构（javadev 认这一套，不依赖 Gradle）

```
<工程目录>/
  AndroidManifest.xml      # 文本清单，package 就是包名
  src/**/*.java            # Java 源码，目录层级随意
  res/                     # 可选：layout / drawable / values 等
  libs/*.jar               # 可选：第三方依赖 jar
```

### 1.3 构建（一条命令）

```bash
cd hello && javadev build .            # 产物在 build/out/，已签名可直接安装
javadev build hello -o /sdcard/Download/hello.apk
javadev push hello/build/out/xxx.apk   # 复制到 /sdcard/Download 去点安装
```

构建流水线（javadev build 内部）：
`aapt2 compile`（可选资源） → `aapt2 link`（二进制清单 + resources.arsc + R.java）
→ `javac` → `d8`（r8 里的 D8 转 classes.dex） → `zip` 塞进 APK → `zipalign -p 4` → 签名器签名。

### 1.4 纯 Java 程序（不打包，直接跑）

```bash
cat > Hello.java <<'EOF'
public class Hello {
  public static void main(String[] a) { System.out.println("hi " + (a.length>0?a[0]:"world")); }
}
EOF
javac Hello.java && java Hello 容器
```

## 2. 常用语言速查

- **Java**：`javac X.java && java X`；多文件 `javac -d out $(find . -name '*.java')`；打 jar `jar cf x.jar -C out .`
- **Python3**：`javadev deps python3` 后用 `python3 x.py`；装库 `pip install -i https://pypi.tuna.tsinghua.edu.cn/simple <包>`
- **Node.js**：`javadev deps nodejs npm` 后用 `node x.js`；装包 `npm config set registry https://registry.npmmirror.com`
- **C/C++**：`apk add gcc musl-dev` 后 `gcc -O2 x.c -o x && ./x`（arm64 原生）
- **Shell**：`/bin/ash`（BusyBox），和 bash 基本兼容；写脚本记得 `#!/bin/sh`
- **Git**：`javadev deps git`；clone GitHub 慢时可 `export GH_ACC=https://ghproxy.net/`

## 3. 改别人 APK 出包（配合 apkmod）

```bash
apkmod d   app.apk          # apktool 拆包
apkmod dex app.apk          # 反编 dex -> smali
# 编辑 smali 里的代码
java -jar /opt/dt/jar/apktool.jar b app.smali -o app-new.apk
apkmod sign app-new.apk     # 对齐 + 签名
apkmod push app-new-signed.apk
```

## 4. 关键约束与避坑

- 容器内路径：`/opt/dt`（工具）、`/root`、`/tmp`、`/skills/<技能名>/`。`/sdcard` 需 App 有存储权限。
- 全部工具是 **arm64** 静态 ELF 或纯 jar，不依赖系统库版本，可直接在 PRoot 里执行。
- `aapt2 link` 需要 `-I android.jar`（`/opt/dt/platform/android.jar`），否则资源链接失败。
- `d8` 通过 `java -cp /opt/dt/jar/r8.jar com.android.tools.r8.D8 ...` 调用。
- 第三方依赖：把 jar 丢进 `libs/`，`javadev build` 会自动加进编译 classpath；
  运行时需要的库放 `libs/` 或 `res/raw`，复杂依赖建议改用 Gradle（见 references/build-apk.md）。
- 详情见 `references/`：`java-guide.md`（Java 语法/常用 API 速查）、`build-apk.md`（构建细节与 Gradle 方案）。
