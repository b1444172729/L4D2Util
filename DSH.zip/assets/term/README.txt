DeepSeek 增强 · 内置 Alpine 容器
==============================

你现在的身份
  PRoot 沙箱内 uid=0（只是"显示为 root"，内核权限仍是 Android 普通应用）。
  能读写：本应用私有目录（/root、/tmp、/opt 都在这里）
  能读写：/sdcard（若 App 已获得存储权限）；/、/system、/data 只读或不可见。

工具链（不随包内置，进容器联网装）
  /opt/dt  工具目录：aapt2 / zipalign / r8 / apktool / uber-apk-signer / android.jar
           首次用之前先跑一次： apkmod init   或   javadev init
  java     apkmod init / javadev init 会用 apk 从清华镜像装 openjdk17

国内镜像（容器内已默认配好）
  Alpine 软件包：清华镜像 mirrors.tuna.tsinghua.edu.cn（/etc/apk/repositories 已写好）
  r8 / d8      ：阿里云 Google Maven 镜像 maven.aliyun.com
  GitHub 资源  ：自动尝试 ghfast.top / ghproxy.net / gh-proxy.com，最后直连
                 （也可自己指定： export GH_ACC=https://你的加速前缀/ ）
  android.jar  ：来自 dl.google.com；国内不通时自行指定：
                 export GOOGLE_DL=https://你的镜像

包管理
  apk update                刷新索引（源已是清华镜像）
  apk add nodejs python3 git vim …   装东西
  javadev deps python3 nodejs git    等价写法

逆向 / 改包
  apkmod which             看工具链装了没有
  apkmod init              准备工具（走国内镜像）
  apkmod info app.apk      看 dex / so / 签名
  apkmod d  app.apk        拆包（apktool 或 zip）
  apkmod dex app.apk       反编 dex -> smali（改代码）
  apkmod b  app.dir        回编译
  apkmod sign app.apk      对齐 + 签名
  apkmod push out.apk      复制到 /sdcard/Download 方便点安装

Java 开发 / 出 APK
  javadev info                       看工具与 JVM 状态
  javadev init                       准备工具（走国内镜像）
  javadev new com.demo.hello Hello   生成一个最小可编译工程
      · 自带 src/<包>/Ui.java      深色 M3 外观工具类（hero/card/section/primary/ghost），
                                  界面直接复用，别退回系统默认灰白控件
      · AndroidManifest.xml 里预置了常用权限注释（INTERNET/CAMERA/定位等），
        需要哪条取消注释；危险权限还要在代码里运行时申请
      · 主题已是 Theme.Material.NoActionBar
  javadev build hello                编译 -> dex -> 打包 -> 对齐 -> 签名
  javadev push hello/build/out/*.apk 导出到可写目录（Download 写不进会自动退到 App 目录）
  javadev deps python3 nodejs git vim  装常用运行时/工具

网页开发（纯 HTML/CSS/JS，不需要编译器）
  webdev info                    自检（python3 / 产物目录）
  webdev new mysite              生成精美响应式单页（深色 M3、卡片、空状态）
  webdev serve mysite 8080       起本地静态服务器 -> 手机浏览器开 http://127.0.0.1:8080/
  webdev push mysite             导出到可写目录 web/
  预览原理：容器与手机共用网络，本机 127.0.0.1 端口手机浏览器能直接访问。

Flutter 开发
  flutterdev info                自检：架构 / libc / 空间 / 镜像连通 / SDK 能不能跑
  flutterdev init                装 Flutter SDK（flutter-io.cn 镜像，约 700MB）
  flutterdev new myapp           生成工程（android + web 双平台）
  flutterdev analyze myapp       静态检查
  flutterdev web myapp           出网页版 -> myapp/build/web（最稳的产物）
  flutterdev serve myapp/build/web 8080   本机预览
  flutterdev apk myapp           尝试出 APK（要 Gradle + Android SDK，容易失败）
  flutterdev push <路径>         导出到可写目录
  ⚠ 事实（实测）：flutter_infra_release 的 Linux 包只有一份 flutter_linux_<版本>-stable.tar.xz，
    按 x86_64 打包，没有 arm64 条目。手机容器基本都是 aarch64 -> init 会直接劝退，
    请改走 webdev（网页）或 javadev（原生 APK）。确实想试：FLUTTER_FORCE=1 flutterdev init
  预览原理同 webdev：容器与手机共用网络，http://127.0.0.1:端口/ 手机浏览器可直接打开。

多语言开发（除 Java/网页/Flutter 之外的任何语言）
  langdev list                     看支持哪些语言（python/node/go/rust/c/cpp/php/ruby/
                                   perl/lua/r/julia/elixir/erlang/swift/dotnet/kotlin…）+ 装没装
  langdev init                     装「常用一套」（python node java go rust c cpp php ruby git sqlite）
  langdev init python go rust      只装指定语言
  langdev all                      装全部支持的语言（体积大，Wi-Fi 下用）
  langdev add <alpine包…>           装任意 Alpine 包（官方仓库没收录的包用这个兜底）
  langdev run python a.py          直接用对应运行时跑文件（python/node/go/java/php/ruby/perl/lua/bash）
  langdev push ./out               导出产物到可写目录
  各语言自带包管理器：pip / npm / cargo / go get / gem / composer / mix …
  需要系统库（libssl、postgresql-dev 等）用 langdev add。

连服务器（SSH）
  ssh init                         装 openssh-client（走国内镜像）
  ssh key [名字]                    生成 ed25519 密钥，并打印公钥（贴到服务器 authorized_keys）
  ssh host add vps root@1.2.3.4 -p 22 -i id_ed25519    保存一台主机
  ssh host ls / ssh host del vps   管理已保存主机
  ssh run vps "uname -a && df -h"  远端非交互执行命令（可管道喂命令）
  ssh shell vps                    进交互式 shell（人在终端时用）
  ssh put vps ./app.apk /root/app.apk     上传（scp）
  ssh get vps /root/log.txt ./log.txt     下载（scp）
  ssh raw vps -L 8080:127.0.0.1:80 -N     端口转发等透传参数
  ssh one root@1.2.3.4 -- "uptime"        一次性临时主机（不保存）
  密码登录加 -P 密码（需 sshpass，ssh init 已一并安装）；优先用密钥。

导出产物（重要）
  容器里的产物默认在 App 私有目录，文件管理器不好进。约定：
    /root/export/            容器内的「待导出区」
  让 AI 把要交付的东西（APK / 反编译目录 / 网页 / 工程）cp 到这里，两种方式搬出去：
    ① 有「所有文件访问」权限：沙箱可直接写 /sdcard/Download（push 里已优先用它）
    ② App「关于 / 工具」页点「导出产物到可见文件夹」：递归写进你选的工作区（免权限）
  脚本的 push 现在按这个顺序找位置：
    你指定的目录 > $DS_EXPORT（App 注入：工作区真实路径 / 已授权时的 /sdcard/Download）
    > /sdcard/Download 等公共目录 > /root/export/（App 里一键搬出去）
  文件和整个文件夹都能导：  apkmod push app.dir   /   javadev push hello/build/out
  看容器当前该往哪写：      echo $DS_EXPORT   （为空说明既没授权也没选工作区）

内置人设（关于/工具 页可切，不联网）
  开发    assets/term/persona_dev.txt      Android 全栈 + 强制精美 UI
  逆向    assets/term/persona_reverse.txt
  无限制  assets/term/persona_free.txt
  改这些文件即改默认人设；也可在「全屏编辑人设」里自己写（优先于内置）。

注意
  /opt、/root、/tmp 属于 App 私有目录，卸载 App 会一起删除；
  要长期保存的产物记得 apkmod push / 复制到 /sdcard。
  公共「下载」目录需要 App 有存储权限；没权限时 push 会自动写到
  /sdcard/Android/data/com.dsmod.deepseek/files/ 这类宿主授权目录。
