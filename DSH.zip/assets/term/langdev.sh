#!/usr/bin/env ash
# langdev —— 容器内「多语言开发工具链」管理器（Alpine · PRoot · uid=0）
#
# 目的：不局限于 Java/网页/Flutter。市面主流语言都能在这里一键装好、直接写代码。
# 所有包都从国内镜像（清华 Alpine）装，不需要 root、不需要 AIDE。
#
# 用法：
#   langdev list                 列出全部支持的语言 + 当前是否已装
#   langdev info                 同 list（别名）
#   langdev init [语言…]          装指定语言（不给参数=装「常用一套」）
#   langdev all                  装全部支持的语言（体积大，慎用）
#   langdev add <alpine包…>       直接装任意 Alpine 软件包（兜底任意语言）
#   langdev run <语言> <文件>     用对应运行时跑一个文件（python/node/go/php…）
#   langdev push <文件/目录>      导出产物到用户可见目录
#
# 语言别名见 `langdev list`。第三方库/包管理器各语言自带（pip/npm/cargo/go get…），
# 需要系统库（如 libssl、postgresql-dev）时用 `langdev add <包>`。

ALPINE_MIRROR="${ALPINE_MIRROR:-https://mirrors.tuna.tsinghua.edu.cn/alpine}"
ALPINE_VER="${ALPINE_VER:-v3.20}"

mkd() {
  for d in "$@"; do
    [ -d "$d" ] && continue
    chain=""
    oldIFS="$IFS"; IFS='/'
    for seg in $d; do
      if [ -z "$seg" ]; then chain="/"
      elif [ "$chain" = "/" ]; then chain="/$seg"
      else chain="${chain:+$chain/}$seg"; fi
      [ -d "$chain" ] || mkdir "$chain" 2>/dev/null
    done
    IFS="$oldIFS"
    mkdir -p "$d" 2>/dev/null
  done
}

usage() { sed -n '2,20p' "$0" | sed 's/^# \{0,1\}//'; }
fail() { echo "FAIL: $1"; exit 1; }

setup_mirror() {
  printf '%s/%s/main\n%s/%s/community\n%s/%s/testing\n' \
    "$ALPINE_MIRROR" "$ALPINE_VER" "$ALPINE_MIRROR" "$ALPINE_VER" "$ALPINE_MIRROR" "$ALPINE_VER" \
    > /etc/apk/repositories
  apk update >/dev/null 2>&1 || true
}

# ---------- 语言表：别名 -> alpine 包（可多包） ----------
# 说明：Alpine 官方仓库包名随版本略有差异；这里给的是常见可用名，
#       装不上会自动提示用 `langdev add` 换包名手动装（不臆造可用性）。
pkgs_for() {
  case "$1" in
    python|py)          echo "python3 py3-pip" ;;
    node|nodejs|js)     echo "nodejs npm" ;;
    typescript|ts)      echo "nodejs npm" ;;
    deno)               echo "deno" ;;
    bun)                echo "bun" ;;
    java|jdk|javadev)   echo "openjdk17-jdk" ;;
    kotlin)             echo "openjdk17-jdk kotlin" ;;
    groovy)             echo "openjdk17-jdk groovy" ;;
    scala)              echo "openjdk17-jdk" ;;
    clojure)            echo "openjdk17-jdk clojure" ;;
    go|golang)          echo "go" ;;
    rust)               echo "rust cargo" ;;
    c)                  echo "build-base gcc" ;;
    cpp|c++|cxx)        echo "build-base gcc g++" ;;
    clang|llvm)         echo "clang compiler-rt lld" ;;
    dotnet|csharp|cs)   echo "dotnet8" ;;
    mono)               echo "mono mono-dev" ;;
    php)                echo "php83 php83-cli php83-phar" ;;
    ruby|rails)         echo "ruby ruby-dev ruby-bundler" ;;
    perl)               echo "perl" ;;
    lua)                echo "lua5.4" ;;
    luajit)             echo "luajit" ;;
    r|R)                echo "R" ;;
    julia)              echo "julia" ;;
    haskell|ghc)        echo "ghc" ;;
    elixir)             echo "elixir erlang" ;;
    erlang)             echo "erlang" ;;
    swift)              echo "swift" ;;
    dart|flutter)       echo "_use:flutterdev" ;;
    bash|zsh|shell)     echo "bash zsh" ;;
    sqlite|sql)         echo "sqlite" ;;
    postgres|psql)      echo "postgresql-client" ;;
    mysql|maria)        echo "mariadb-client" ;;
    redis)              echo "redis" ;;
    nginx)              echo "nginx" ;;
    git|vcs)            echo "git" ;;
    *)                  echo "" ;;
  esac
}

# 别名的“显示名”，让 list 输出好看
names() {
  echo "python node typescript deno bun java kotlin groovy scala clojure go rust c cpp clang dotnet mono php ruby perl lua luajit r julia haskell elixir erlang swift dart bash sqlite postgres mysql redis nginx git"
}

# 备选包（主包在镜像里没有时逐个试），避免臆造“一定能装”
alt_for() {
  case "$1" in
    php)    echo "php82 php82-cli php82-phar php php-cli php-phar" ;;
    dotnet|csharp|cs) echo "dotnet7 dotnet6 dotnet-sdk-8.0 dotnet-sdk-7.0" ;;
    kotlin) echo "kotlin" ;;
    bun)    echo "bun-bin" ;;
    julia)  echo "julia julia-bin" ;;
    swift)  echo "swift swift-bin" ;;
    *)      echo "" ;;
  esac
}

# 运行时命令（run 用）
runner_for() {
  case "$1" in
    python|py)      echo "python3" ;;
    node|nodejs|js) echo "node" ;;
    go|golang)      echo "go run" ;;
    java|jdk)       echo "java" ;;         # 直接 java File.java（JDK11+ 支持单文件）
    php)            echo "php" ;;
    ruby)           echo "ruby" ;;
    perl)           echo "perl" ;;
    lua)            echo "lua5.4" ;;
    bash|zsh|shell) echo "bash" ;;
    *)              echo "" ;;
  esac
}

installed_of() {
  # 该语言是否已装（用运行时命令探测）
  r="$(runner_for "$1")"
  [ -n "$r" ] || return 1
  command -v "${r%% *}" >/dev/null 2>&1
}

do_list() {
  echo "语言          状态       Alpine 包"
  echo "-----------------------------------------------"
  for n in $(names); do
    p="$(pkgs_for "$n")"
    case "$p" in
      _use:*) st="走其它工具" ;;
      *)      if installed_of "$n"; then st="已装"; else st="未装"; fi ;;
    esac
    printf '%-13s %-9s %s\n' "$n" "$st" "$p"
  done
  echo ""
  echo "其它任意语言/工具：langdev add <alpine包>   （先 apk search <关键词> 查包名）"
}

# 装单个语言；成功返回 0，失败返回 1（不中断整体）
install_one() {
  lang="$1"
  p="$(pkgs_for "$lang")"
  if [ -z "$p" ]; then
    echo "  · $lang：不支持（可用 langdev add <包> 手动装）"; return 1
  fi
  case "$p" in
    _use:*) echo "  · $lang：请用 ${p#_use:}（语言专用工具链）"; return 0 ;;
  esac
  for cand in $p $(alt_for "$lang"); do
    if apk add --no-cache $cand >/dev/null 2>&1; then
      echo "  ✓ $lang：已装（$cand）"
      post_install "$lang"
      return 0
    fi
  done
  echo "  ✗ $lang：包 ($p) 在本镜像装不上，换名试试：apk search <关键词> 后 langdev add <包>"
  return 1
}

post_install() {
  case "$1" in
    typescript|ts) command -v npm >/dev/null 2>&1 && npm i -g typescript >/dev/null 2>&1 ;;
    *) : ;;
  esac
}

DEFAULT_SET="python node java go rust c cpp php ruby git bash sqlite"

do_init() {
  setup_mirror
  if [ $# -gt 0 ]; then set="$*"; echo "安装：$set"; else set="$DEFAULT_SET"; echo "安装常用一套：$set"; fi
  ok=0; bad=0
  for l in $set; do
    if install_one "$l"; then ok=$((ok+1)); else bad=$((bad+1)); fi
  done
  echo "-----------------------------------------------"
  echo "完成：成功 $ok，失败 $bad。复核： langdev list"
  echo "第三方库：pip / npm / cargo / go get / gem / composer 等各语言自带。"
}

do_all() {
  setup_mirror
  echo "安装全部支持的语言（体积很大，耗时较长，建议 Wi-Fi）…"
  ok=0; bad=0
  for l in $(names); do
    if install_one "$l"; then ok=$((ok+1)); else bad=$((bad+1)); fi
  done
  echo "-----------------------------------------------"
  echo "完成：成功 $ok，失败 $bad。复核： langdev list"
}

do_add() {
  [ $# -gt 0 ] || { echo "用法：langdev add <alpine包…>"; return 1; }
  setup_mirror
  apk add --no-cache "$@"
}

do_run() {
  lang="$1"; shift 2>/dev/null
  [ -n "$lang" ] && [ $# -gt 0 ] || { echo "用法：langdev run <语言> <文件…>"; return 1; }
  r="$(runner_for "$lang")"
  [ -n "$r" ] || { echo "$lang 不支持 run（未定义运行时）。可先 apk add 对应运行时，再手动跑。"; return 1; }
  # shellcheck disable=SC2086
  exec $r "$@"
}

do_info() { do_list; }

# 导出：① 你指定 > ② $DS_EXPORT（App 注入） > ③ 公共目录 > ④ 容器导出区 /root/export/
do_push() {
  SRC="$1"; D="$2"
  [ -e "$SRC" ] || { echo "找不到 $SRC"; exit 1; }
  B="$(basename "$SRC")"
  if [ -n "${D:-}" ]; then
    mkd "$D"; cp -rf "$SRC" "$D/" 2>/dev/null && { echo "已复制到 $D/$B"; return 0; }
    echo "写入 $D 失败"; return 1
  fi
  if [ -n "${DS_EXPORT:-}" ]; then
    mkd "$DS_EXPORT"
    cp -rf "$SRC" "$DS_EXPORT/" 2>/dev/null && { echo "已复制到 $DS_EXPORT/$B"; return 0; }
    echo "注：DS_EXPORT=$DS_EXPORT 写不进去，换其它位置"
  fi
  for d in /sdcard/Download /storage/emulated/0/Download "$DS_EXT_DIR" /data/local/tmp; do
    mkd "$d"
    cp -rf "$SRC" "$d/" 2>/dev/null && { echo "已复制到 $d/$B"; return 0; }
  done
  mkd /root/export
  if cp -rf "$SRC" /root/export/ 2>/dev/null; then
    echo "公共目录写不进去（缺「所有文件访问」权限，App 里可一键授予）。"
    echo "已放进容器导出区：/root/export/$B"
    echo "回 App「关于 / 工具」页点「导出产物到可见文件夹」就能拿到。"
    return 0
  fi
  echo "导出失败：所有目标都写不进去"; return 1
}

CMD="${1:-help}"; shift 2>/dev/null
case "$CMD" in
  list|info)  do_list ;;
  init)       do_init "$@" ;;
  all)        do_all ;;
  add)        do_add "$@" ;;
  run)        do_run "$@" ;;
  push)       do_push "$@" ;;
  help|--help|-h) usage ;;
  *) usage; exit 1 ;;
esac
