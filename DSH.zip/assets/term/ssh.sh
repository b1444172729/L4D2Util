#!/usr/bin/env ash
# ssh —— 连服务器 / 远程执行 / 传文件（Alpine · PRoot · 需联网装 openssh-client）
#
# 让 AI（或你）能直接连到自己的服务器：拉代码、跑命令、传产物、部署。
# 主机配置保存在 App 私有目录 /root/.ssh/hosts（一行一台，卸载 App 会清）。
#
# 用法：
#   ssh init                              安装 openssh-client（走国内镜像）
#   ssh key [名字]                         生成 ed25519 密钥对（默认 id_ed25519），打印公钥
#   ssh host add <名> <user@host> [-p 端口] [-i 密钥] [-P 密码]   保存一台主机
#   ssh host ls                            列出已保存主机
#   ssh host del <名>                       删除
#   ssh run <名> <命令…>                    在远端非交互执行（命令可从标准输入读）
#   ssh shell <名>                          进交互式 shell（人在终端时用）
#   ssh put <名> <本地> <远端>               上传（scp）
#   ssh get <名> <远端> <本地>               下载（scp）
#   ssh raw <名> <ssh附加参数…>              透传（端口转发 -L/-R、-N 等）
#   ssh one <user@host> [-p 端口] [-i 密钥] [-P 密码] -- <命令…>   一次性临时主机
#   ssh <user@host> …                       不认识的首参直接交给原生 ssh（如 ssh -i k root@h）
#
# 例：
#   ssh key mykey
#   ssh host add vps root@1.2.3.4 -p 22 -i mykey
#   ssh run vps "uname -a && df -h"
#   ssh put vps ./app.apk /root/app.apk
#   ssh one root@1.2.3.4 -P 'mypass' -- "uptime"

ALPINE_MIRROR="${ALPINE_MIRROR:-https://mirrors.tuna.tsinghua.edu.cn/alpine}"
ALPINE_VER="${ALPINE_VER:-v3.20}"
SSH_DIR="${SSH_DIR:-/root/.ssh}"
HOSTS="$SSH_DIR/hosts"
KNOWN="$SSH_DIR/known_hosts"

mkd() { for d in "$@"; do [ -d "$d" ] || mkdir -p "$d" 2>/dev/null; done; }
usage() { sed -n '2,27p' "$0" | sed 's/^# \{0,1\}//'; }
fail() { echo "FAIL: $1" >&2; exit 1; }

# 关键：本脚本被装到 /usr/local/bin/ssh，会盖住原生 ssh；所以这里一律用绝对路径找原生程序，
# 只看 /usr/bin /bin 等系统目录，绝不落到我们自己的包装脚本上（否则会递归调用自己）。
_real() {
  for d in /usr/bin /bin /usr/sbin /sbin; do
    [ -x "$d/$1" ] && { echo "$d/$1"; return; }
  done
}
ssh_bin()    { _real ssh; }
scp_bin()    { _real scp; }
keygen_bin() { _real ssh-keygen; }
keybin()     { _real ssh-keyscan; }
sshpass_bin(){ _real sshpass; }

setup_mirror() {
  printf '%s/%s/main\n%s/%s/community\n' "$ALPINE_MIRROR" "$ALPINE_VER" "$ALPINE_MIRROR" "$ALPINE_VER" \
    > /etc/apk/repositories
  apk update >/dev/null 2>&1 || true
}

do_init() {
  mkd "$SSH_DIR"; chmod 700 "$SSH_DIR" 2>/dev/null
  b="$(ssh_bin)"
  if [ -n "$b" ]; then
    echo "openssh-client 已就绪：$("$b" -V 2>&1)"
  else
    echo "安装 openssh-client（国内镜像）…"
    setup_mirror
    apk add --no-cache openssh-client openssh-keygen sshpass >/dev/null 2>&1 \
      || apk add --no-cache openssh-client >/dev/null 2>&1 \
      || fail "安装 openssh-client 失败"
    b="$(ssh_bin)"
    [ -n "$b" ] && echo "已安装：$("$b" -V 2>&1)" || fail "装完仍找不到原生 ssh"
  fi
  echo "主机配置：$HOSTS"
}

# ---------- 主机配置读写 ----------
# 每行： name|user|host|port|identity|password
field_of() {  # $1=name $2=field-index(1..6)
  [ -f "$HOSTS" ] || return 1
  awk -F'|' -v n="$1" -v i="$2" '$1==n{print $i; exit}' "$HOSTS"
}

# 解析主机 -> 设置全局 U H P I W（本函数在当前 shell 里跑，fail 能真正退出）
load_host() {
  _u="$(field_of "$1" 2)"; _h="$(field_of "$1" 3)"; _p="$(field_of "$1" 4)"
  _i="$(field_of "$1" 5)"; _w="$(field_of "$1" 6)"
  [ -n "$_u" ] && [ -n "$_h" ] || fail "未知主机 $1（先 ssh host add <名> <user@host>）"
  [ -n "$_p" ] || _p="22"
  U="$_u"; H="$_h"; P="$_p"; I="$_i"; W="$_w"
}

do_host() {
  sub="$1"; shift 2>/dev/null
  case "$sub" in
    add)  host_add "$@" ;;
    ls|list) host_ls ;;
    del|rm) [ -n "$1" ] || { echo "用法：ssh host del <名>"; return 1; }
            mkd "$SSH_DIR"
            awk -F'|' -v n="$1" '$1!=n' "$HOSTS" > "$HOSTS.tmp" 2>/dev/null
            mv "$HOSTS.tmp" "$HOSTS"; echo "已删除主机 $1" ;;
    *)    echo "用法：ssh host add|ls|del …" ;;
  esac
}

host_add() {
  name="$1"; target="$2"; shift 2 2>/dev/null
  [ -n "$name" ] && [ -n "$target" ] || { echo "用法：ssh host add <名> <user@host> [-p 端口] [-i 密钥] [-P 密码]"; return 1; }
  port="22"; ident=""; pass=""
  while [ $# -gt 0 ]; do
    case "$1" in
      -p) port="$2"; shift 2 ;;
      -i) ident="$2"; shift 2 ;;
      -P) pass="$2"; shift 2 ;;
      *) shift ;;
    esac
  done
  case "$target" in
    *@*) user="${target%@*}"; h="${target#*@}" ;;
    *)   echo "目标要写成 user@host 形式，例如 root@1.2.3.4"; return 1 ;;
  esac
  [ -n "$user" ] && [ -n "$h" ] || { echo "无法解析 $target"; return 1; }
  mkd "$SSH_DIR"; chmod 700 "$SSH_DIR" 2>/dev/null
  awk -F'|' -v n="$name" '$1!=n' "$HOSTS" > "$HOSTS.tmp" 2>/dev/null; mv "$HOSTS.tmp" "$HOSTS" 2>/dev/null
  printf '%s|%s|%s|%s|%s|%s\n' "$name" "$user" "$h" "$port" "$ident" "$pass" >> "$HOSTS"
  echo "已保存主机：$name -> $user@$h:$port${ident:+ (key=$ident)}"
}

host_ls() {
  [ -s "$HOSTS" ] || { echo "还没有保存的主机。用：ssh host add <名> <user@host>"; return 0; }
  echo "名字            目标                        密钥"
  echo "--------------------------------------------------------"
  awk -F'|' '{printf "%-15s %-27s %s\n", $1, $2"@"$3":"$4, ($5==""?"(密码/默认)":$5)}' "$HOSTS"
}

# ---------- 公共选项 ----------
# $1=identity  $2=password  $3=mode(run|shell)
# run 模式：有密钥没密码时禁交互（失败即回，不挂起）；密码认证不禁交互（交给 sshpass）。
mk_opts() {
  o="-o StrictHostKeyChecking=accept-new -o UserKnownHostsFile=$KNOWN -o LogLevel=ERROR -o ConnectTimeout=20"
  [ -n "$1" ] && o="$o -i $1"
  case "$3" in
    shell) : ;;
    *) if [ -z "$2" ]; then o="$o -o BatchMode=yes"; fi ;;
  esac
  echo "$o"
}

# 密码认证前缀（sshpass）
pass_prefix() {
  if [ -n "$1" ]; then
    w="$(sshpass_bin)"
    [ -n "$w" ] || fail "需要 sshpass 收密码：ssh init（或改用密钥 -i）"
    echo "$w -p $1"
  fi
}

# ---------- run / shell / put / get / raw ----------
do_run() {
  name="$1"; shift 2>/dev/null
  [ -n "$name" ] || { usage; return 1; }
  load_host "$name"
  cmd="$*"
  [ -n "$cmd" ] || cmd="$(cat)"       # 允许从管道读命令
  [ -n "$cmd" ] || fail "没有命令"
  b="$(ssh_bin)"; [ -n "$b" ] || fail "没装 openssh-client：先 ssh init"
  OPTS="$(mk_opts "$I" "$W" run)"
  PF="$(pass_prefix "$W")"
  echo "== $name ($U@$H:$P) =="
  # shellcheck disable=SC2086
  $PF "$b" $OPTS -p "$P" "$U@$H" "$cmd"
}

ssh_shell() {
  name="$1"
  [ -n "$name" ] || { usage; return 1; }
  load_host "$name"
  b="$(ssh_bin)"; [ -n "$b" ] || fail "没装 openssh-client：先 ssh init"
  OPTS="$(mk_opts "$I" "$W" shell)"
  PF="$(pass_prefix "$W")"
  echo "进入 $name（$U@$H:$P）… 退出：输入 exit"
  # shellcheck disable=SC2086
  $PF "$b" $OPTS -p "$P" "$U@$H"
}

do_put() {
  name="$1"; local_f="$2"; remote_f="$3"
  [ -n "$name" ] && [ -n "$local_f" ] && [ -n "$remote_f" ] || { echo "用法：ssh put <名> <本地> <远端>"; return 1; }
  [ -e "$local_f" ] || fail "本地不存在：$local_f"
  load_host "$name"
  b="$(scp_bin)"; [ -n "$b" ] || fail "缺 scp：ssh init"
  OPTS="$(mk_opts "$I" "$W" run)"; PF="$(pass_prefix "$W")"
  echo "上传 $local_f -> $name:$remote_f"
  # shellcheck disable=SC2086
  $PF "$b" $OPTS -P "$P" -r "$local_f" "$U@$H:$remote_f"
}

do_get() {
  name="$1"; remote_f="$2"; local_f="$3"
  [ -n "$name" ] && [ -n "$remote_f" ] && [ -n "$local_f" ] || { echo "用法：ssh get <名> <远端> <本地>"; return 1; }
  load_host "$name"
  b="$(scp_bin)"; [ -n "$b" ] || fail "缺 scp：ssh init"
  OPTS="$(mk_opts "$I" "$W" run)"; PF="$(pass_prefix "$W")"
  echo "下载 $name:$remote_f -> $local_f"
  # shellcheck disable=SC2086
  $PF "$b" $OPTS -P "$P" -r "$U@$H:$remote_f" "$local_f"
}

do_raw() {
  name="$1"; shift 2>/dev/null
  [ -n "$name" ] || { usage; return 1; }
  load_host "$name"
  b="$(ssh_bin)"; [ -n "$b" ] || fail "没装 openssh-client：先 ssh init"
  OPTS="$(mk_opts "$I" "$W" shell)"; PF="$(pass_prefix "$W")"
  # shellcheck disable=SC2086
  exec $PF "$b" $OPTS -p "$P" "$@" "$U@$H"
}

# 一次性：ssh one user@host [-p 端口] [-i 密钥] [-P 密码] -- <命令…>
do_one() {
  target="$1"; shift 2>/dev/null
  [ -n "$target" ] || { echo "用法：ssh one <user@host> [-p 端口] [-i 密钥] [-P 密码] -- <命令…>"; return 1; }
  port="22"; ident=""; pass=""
  while [ $# -gt 0 ]; do
    case "$1" in
      --) shift; break ;;
      -p) port="$2"; shift 2 ;;
      -i) ident="$2"; shift 2 ;;
      -P) pass="$2"; shift 2 ;;
      *) break ;;
    esac
  done
  cmd="$*"
  case "$target" in *@*) ;; *) echo "要写成 user@host"; return 1 ;; esac
  b="$(ssh_bin)"; [ -n "$b" ] || fail "没装 openssh-client：先 ssh init"
  OPTS="$(mk_opts "$ident" "$pass" run)"; PF="$(pass_prefix "$pass")"
  # shellcheck disable=SC2086
  $PF "$b" $OPTS -p "$port" "$target" "$cmd"
}

do_key() {
  name="${1:-id_ed25519}"
  mkd "$SSH_DIR"; chmod 700 "$SSH_DIR" 2>/dev/null
  f="$SSH_DIR/$name"
  if [ -f "$f" ]; then echo "密钥已存在：$f"; else
    g="$(keygen_bin)"
    [ -n "$g" ] || { setup_mirror; apk add --no-cache openssh-keygen >/dev/null 2>&1; g="$(keygen_bin)"; }
    [ -n "$g" ] || fail "缺 ssh-keygen：先 ssh init"
    "$g" -t ed25519 -N "" -f "$f" -C "dsmod@phone" >/dev/null 2>&1 || fail "生成密钥失败"
    chmod 600 "$f"; echo "已生成：$f"
  fi
  echo "---- 公钥（贴到服务器 /root/.ssh/authorized_keys）----"
  cat "$f.pub" 2>/dev/null
}

CMD="${1:-help}"; shift 2>/dev/null
case "$CMD" in
  init)  do_init ;;
  key)   do_key "$@" ;;
  host)  do_host "$@" ;;
  run)   do_run "$@" ;;
  shell|sh) ssh_shell "$@" ;;
  put)   do_put "$@" ;;
  get)   do_get "$@" ;;
  raw)   do_raw "$@" ;;
  one)   do_one "$@" ;;
  help|--help|-h) usage ;;
  *)
    # 不认识的首参（如 user@host、-o 选项）→ 交给原生 ssh
    b="$(ssh_bin)"; [ -n "$b" ] || { echo "未安装 openssh-client：先执行 ssh init"; exit 1; }
    exec "$b" "$CMD" "$@" ;;
esac
