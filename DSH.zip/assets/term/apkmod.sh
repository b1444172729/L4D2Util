#!/usr/bin/env ash
# apkmod —— 容器内 APK 逆向 / 改包工具（arm64 · Alpine · PRoot）
#
# 离线优先：内置版把工具随 App 打进 /opt/dt，不联网直接能用。
# 精简版 /opt/dt 为空时，执行 `apkmod init` 会从国内镜像补齐。
#
# 用法：
#   apkmod init                      准备工具链（内置版秒过；精简版走国内镜像）
#   apkmod which                     看当前工具是「内置」还是「下载」的
#   apkmod d    <apk> [目录]          拆包（apktool，失败回退 zip）
#   apkmod dex  <apk> [目录]          反编 classes*.dex -> smali（改代码用）
#   apkmod b    <目录> [out.apk]      回编译（apktool，失败回退 zip）
#   apkmod sign <apk>  [out.apk]      对齐 + 签名（uber-apk-signer，回退 jarsigner）
#   apkmod info <apk>                看包结构 / dex / so / 签名
#   apkmod push <apk>  [目录]         复制到共享存储，方便去文件管理器点安装
#
# 说明：
#   - 全程在容器里跑，不需要手机 root。
#   - java 由内置 JVM 提供（内置版随包），精简版用 apk add 从镜像装。

TROOT="${TROOT:-/opt/dt}"
AAPT2="$TROOT/bin/aapt2"
ZIPALIGN="$TROOT/bin/zipalign"
APKTOOL="$TROOT/jar/apktool.jar"
SIGNER="$TROOT/jar/uber-apk-signer.jar"
R8="$TROOT/jar/r8.jar"
ANDROID_JAR="$TROOT/platform/android.jar"

# ---------- 国内镜像 ----------
ALPINE_MIRROR="${ALPINE_MIRROR:-https://mirrors.tuna.tsinghua.edu.cn/alpine}"
ALPINE_VER="${ALPINE_VER:-v3.20}"
MAVEN_GOOGLE="${MAVEN_GOOGLE:-https://maven.aliyun.com/repository/google}"
GOOGLE_DL="${GOOGLE_DL:-https://dl.google.com}"
GH_ACC="${GH_ACC:-}"     # 可选 GitHub 加速前缀，例：https://ghproxy.net/
# 默认加速镜像（按顺序尝试，失败自动换下一个；最后回退 GitHub 直连）
GH_MIRRORS="${GH_MIRRORS:-https://ghfast.top/ https://ghproxy.net/ https://gh-proxy.com/}"

BT_ZIP="https://github.com/lzhiyong/android-sdk-tools/releases/download/35.0.2/android-sdk-tools-static-aarch64.zip"
APKTOOL_URL="https://github.com/iBotPeaches/Apktool/releases/download/v2.9.3/apktool_2.9.3.jar"
SIGNER_URL="https://github.com/patrickfav/uber-apk-signer/releases/download/v1.3.0/uber-apk-signer-1.3.0.jar"
R8_URL="$MAVEN_GOOGLE/com/android/tools/r8/8.3.37/r8-8.3.37.jar"
PLATFORM_URL="$GOOGLE_DL/android/repository/platform-35_r02.zip"

usage() { sed -n '2,20p' "$0" | sed 's/^# \{0,1\}//'; }

# 下载：先试用户指定的加速前缀，再依次试内置镜像，最后 GitHub 直连
dl() {
  u="$1"; out="$2"
  if command -v curl >/dev/null 2>&1; then
    curl -fL --connect-timeout 15 --max-time 1800 -o "$out" "$u"
  else
    wget -q -T 15 -O "$out" "$u"
  fi
}
fetch() {
  url="$1"; out="$2"
  if [ -n "$GH_ACC" ] && dl "$GH_ACC$url" "$out"; then return 0; fi
  for m in $GH_MIRRORS; do
    rm -f "$out"
    if dl "$m$url" "$out"; then return 0; fi
  done
  rm -f "$out"
  dl "$url" "$out"
}

need_java() {
  command -v java >/dev/null 2>&1 || {
    echo "缺少 java：内置版应已随包；精简版请先执行 apkmod init"; exit 1; }
  command -v jar >/dev/null 2>&1 || command -v jarsigner >/dev/null 2>&1 || true
}

builtin() { [ -x "$AAPT2" ] && [ -f "$APKTOOL" ] && [ -f "$SIGNER" ]; }

do_which() {
  if builtin; then
    echo "工具链来源：内置（$TROOT，离线可用）"
  else
    echo "工具链来源：未内置（精简版）—— 执行 apkmod init 从国内镜像下载"
    echo "镜像：$ALPINE_MIRROR  $MAVEN_GOOGLE"
  fi
  command -v java >/dev/null 2>&1 && echo "java：$(java -version 2>&1 | head -1)" || echo "java：未安装"
}

setup_apk_mirror() {
  printf '%s/%s/main\n%s/%s/community\n' "$ALPINE_MIRROR" "$ALPINE_VER" "$ALPINE_MIRROR" "$ALPINE_VER" \
    > /etc/apk/repositories
  apk update >/dev/null 2>&1 || true
}

do_init() {
  # 1) java
  if ! command -v java >/dev/null 2>&1; then
    echo "[1/3] 安装 JVM（国内镜像 openjdk17-jre-headless）…"
    setup_apk_mirror
    apk add --no-cache openjdk17-jre-headless unzip zip curl || exit 1
  else
    echo "[1/3] JVM 已就绪：$(java -version 2>&1 | head -1)"
  fi

  # 2) 内置？
  if builtin; then
    echo "[2/3] 工具链已内置，无需下载：$TROOT"
    echo "[3/3] 完成。"
    return 0
  fi

  # 3) 精简版：从国内镜像下载
  echo "[2/3] 下载工具链（国内镜像 / 加速）…"
  mkdir -p "$TROOT/bin" "$TROOT/jar" "$TROOT/platform"
  command -v unzip >/dev/null 2>&1 || apk add --no-cache unzip
  command -v curl  >/dev/null 2>&1 || apk add --no-cache curl

  tmp="$(mktemp -d)"
  echo "  · aapt2 / zipalign (arm64 静态)"
  fetch "$BT_ZIP" "$tmp/bt.zip" && \
    unzip -oq "$tmp/bt.zip" build-tools/aapt2 build-tools/zipalign build-tools/aapt -d "$tmp/bt" && \
    cp -f "$tmp/bt/build-tools/"* "$TROOT/bin/" && chmod 0755 "$TROOT/bin/"* || \
    echo "  ! arm64 构建工具下载失败（可换 GH_ACC 重试）"

  echo "  · apktool.jar"
  fetch "$APKTOOL_URL" "$TROOT/jar/apktool.jar" || echo "  ! apktool 下载失败"
  echo "  · uber-apk-signer.jar"
  fetch "$SIGNER_URL" "$TROOT/jar/uber-apk-signer.jar" || echo "  ! 签名器下载失败"
  echo "  · r8.jar（d8，来自阿里云 Google Maven 镜像）"
  fetch "$R8_URL" "$TROOT/jar/r8.jar" || echo "  ! r8 下载失败"
  echo "  · android.jar（platform-35）"
  fetch "$PLATFORM_URL" "$tmp/pf.zip" && \
    unzip -oq "$tmp/pf.zip" 'android-35/android.jar' -d "$tmp/pf" && \
    cp -f "$tmp/pf/android-35/android.jar" "$ANDROID_JAR" || \
    echo "  ! android.jar 下载失败（dl.google.com 不通时可设 GOOGLE_DL 指向镜像）"

  rm -rf "$tmp"
  echo "[3/3] 完成。"
}

do_decode() {
  APK="$1"; OUT="${2:-${APK%.apk}.dir}"
  [ -f "$APK" ] || { echo "找不到 $APK"; exit 1; }
  need_java
  if [ -f "$APKTOOL" ]; then
    if java -jar "$APKTOOL" d -f -o "$OUT" "$APK"; then
      echo "已用 apktool 拆包 -> $OUT"; return 0
    fi
    echo "apktool 拆包失败，改用 zip 方式"
  fi
  rm -rf "$OUT"; mkdir -p "$OUT"
  unzip -o "$APK" -d "$OUT" >/dev/null && echo "已解包(zip) -> $OUT"
}

do_dex() {
  APK="$1"; OUT="${2:-${APK%.apk}.smali}"
  [ -f "$APK" ] || { echo "找不到 $APK"; exit 1; }
  need_java
  [ -f "$APKTOOL" ] || { echo "需要 apktool.jar：先执行 apkmod init"; exit 1; }
  rm -rf "$OUT"
  java -jar "$APKTOOL" d -f -r -o "$OUT" "$APK" && echo "dex 已反编 -> $OUT"
  echo "（改完回编译： java -jar $APKTOOL b \"$OUT\" -o out.apk）"
}

do_build() {
  DIR="$1"; OUT="${2:-$(basename "$DIR").apk}"
  [ -d "$DIR" ] || { echo "找不到目录 $DIR"; exit 1; }
  need_java
  case "$OUT" in /*) ;; *) OUT="$(pwd)/$OUT" ;; esac
  if [ -f "$DIR/apktool.yml" ] && [ -f "$APKTOOL" ]; then
    java -jar "$APKTOOL" b "$DIR" -o "$OUT" && { echo "回编译完成(apktool) -> $OUT"; return 0; }
    echo "apktool 回编译失败，改用 zip 方式"
  fi
  rm -f "$OUT"
  ( cd "$DIR" && zip -qr9 "$OUT" . ) && echo "回编译完成(zip) -> $OUT"
}

do_sign() {
  APK="$1"; OUT="${2:-${APK%.apk}-signed.apk}"
  [ -f "$APK" ] || { echo "找不到 $APK"; exit 1; }
  need_java
  if [ -f "$SIGNER" ]; then
    if java -jar "$SIGNER" -a "$APK" -o "$(dirname "$OUT")" --allowResign; then
      echo "签名完成 -> $(dirname "$OUT")"; return 0
    fi
  fi
  KS="${APKMOD_KS:-$TROOT/ks.jks}"
  [ -f "$KS" ] || keytool -genkeypair -keystore "$KS" -storepass android -keypass android \
      -alias apkmod -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=apkmod, O=apkmod, C=CN" >/dev/null 2>&1
  cp -f "$APK" "$OUT"
  jarsigner -keystore "$KS" -storepass android -keypass android "$OUT" apkmod \
    && echo "已用 jarsigner(v1) 签名 -> $OUT"
}

do_info() {
  APK="$1"; [ -f "$APK" ] || { echo "找不到 $APK"; exit 1; }
  echo "== 概览 =="; unzip -l "$APK" | sed -n '1,4p'
  echo "== dex =="; unzip -l "$APK" | grep -E 'classes[0-9]*\.dex' || echo "  (无)"
  echo "== native libs =="; unzip -l "$APK" | grep -E '\.so$' | head -20 || echo "  (无)"
  echo "== 签名 =="; unzip -l "$APK" | grep -E 'META-INF/.*\.(RSA|DSA|EC|SF)' || echo "  (无 v1 签名)"
}

# 导出：① 你指定 > ② App 注入的 $DS_EXPORT（工作区/已授权的下载目录）
#       ③ 常见公共目录 > ④ 容器导出区 /root/export/（App 里一键搬出去）
# 文件和整个文件夹都能导（cp -rf）。
do_push() {
  SRC="$1"; D="${2:-}"
  [ -e "$SRC" ] || { echo "找不到 $SRC"; exit 1; }
  B="$(basename "$SRC")"

  if [ -n "$D" ]; then
    mkdir -p "$D" 2>/dev/null
    cp -rf "$SRC" "$D/" 2>/dev/null && { echo "已复制到 $D/$B"; return 0; }
    echo "写入 $D 失败"; return 1
  fi

  if [ -n "${DS_EXPORT:-}" ]; then
    mkdir -p "$DS_EXPORT" 2>/dev/null
    if cp -rf "$SRC" "$DS_EXPORT/" 2>/dev/null; then
      echo "已复制到 $DS_EXPORT/$B"
      return 0
    fi
    echo "注：DS_EXPORT=$DS_EXPORT 写不进去，换其它位置"
  fi

  for d in /sdcard/Download /storage/emulated/0/Download \
           "${DS_EXT_DIR:-/sdcard/Android/data/com.dsmod.deepseek/files}" /data/local/tmp; do
    mkdir -p "$d" 2>/dev/null
    if cp -rf "$SRC" "$d/" 2>/dev/null; then
      echo "已复制到 $d/$B"
      case "$B" in *.apk) echo "去文件管理器点这个 apk 即可安装";; esac
      return 0
    fi
  done

  mkdir -p /root/export 2>/dev/null
  if cp -rf "$SRC" /root/export/ 2>/dev/null; then
    echo "公共目录写不进去（缺「所有文件访问」权限，App 里可一键授予）。"
    echo "已放进容器导出区：/root/export/$B"
    echo "回 App「关于 / 工具」页点「导出产物到可见文件夹」就能拿到。"
    return 0
  fi
  echo "导出失败：所有目标都写不进去"
  return 1
}

CMD="${1:-help}"; shift 2>/dev/null
case "$CMD" in
  init)   do_init ;;
  which)  do_which ;;
  d|decode) do_decode "$@" ;;
  dex)    do_dex "$@" ;;
  b|build) do_build "$@" ;;
  sign)   do_sign "$@" ;;
  info)   do_info "$@" ;;
  push)   do_push "$@" ;;
  help|--help|-h) usage ;;
  *) usage; exit 1 ;;
esac
