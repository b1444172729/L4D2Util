#!/bin/sh
# webdev —— 网页开发小工具（HTML/CSS/JS，无需任何编译环境）
#
#   webdev info                自检：静态服务器 / 产物目录
#   webdev new <名字> [目录]    生成一个精美响应式单页（深色 M3 风格）
#   webdev serve [目录] [端口]  起本地静态服务器，手机浏览器直接预览
#   webdev push <路径>          导出到宿主可写目录
#
# 预览原理：容器与手机共用网络，python3 -m http.server 起的端口
# 手机浏览器访问 http://127.0.0.1:<端口>/ 即可。
set -u

DS_EXT_DIR="${DS_EXT_DIR:-/sdcard/Android/data/com.dsmod.deepseek/files}"

need_cmd() { command -v "$1" >/dev/null 2>&1; }

do_info() {
  echo "=== 网页开发自检 ==="
  if need_cmd python3; then echo "python3 : $(python3 -V 2>&1)  （webdev serve 用它起服务）"
  else echo "python3 : 未安装 -> 跑一次  javadev deps python3  （或 apk add python3）"; fi
  echo "产物目录 : $DS_EXT_DIR/web/"
  echo "预览地址 : http://127.0.0.1:8080/  （serve 默认端口）"
  echo "提示     : 纯网页不需要装任何编译器；写好 index.html 直接 serve 即可"
}

do_new() {
  N="${1:-web}"; D="${2:-$N}"
  mkdir -p "$D" || { echo "FAIL: 建目录 $D"; exit 1; }
  cat > "$D/index.html" <<HTML
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#0D1117">
<title>$N</title>
<style>
:root{
  --bg:#0D1117; --card:#17171E; --stroke:#2C2C36;
  --text:#E6E0E9; --sub:#9AA6B2; --accent:#D0BCFF;
  --accent-2:#8AB4F8; --on-accent:#2A1F4D;
  --r:22px; --gap:16px;
}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{margin:0;padding:0}
body{
  background:var(--bg); color:var(--text);
  font:15px/1.65 -apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif;
  padding:20px 16px 40px; max-width:720px; margin:0 auto;
  -webkit-font-smoothing:antialiased;
}
.hero{
  background:linear-gradient(135deg,#53389E 0%,#3B6FD4 100%);
  border-radius:28px; padding:26px 22px; color:#fff;
  box-shadow:0 12px 30px rgba(83,56,158,.35);
}
.hero h1{margin:0;font-size:26px;font-weight:700;letter-spacing:.2px}
.hero p{margin:10px 0 0;font-size:13.5px;color:rgba(255,255,255,.86)}
.hero .row{display:flex;gap:10px;margin-top:18px;flex-wrap:wrap}
.btn{
  border:0;border-radius:999px;padding:13px 22px;font-size:15px;font-weight:700;
  background:var(--accent);color:var(--on-accent);cursor:pointer;
  transition:transform .12s ease,filter .12s ease;
}
.btn:active{transform:scale(.97);filter:brightness(1.08)}
.btn.ghost{background:rgba(255,255,255,.14);color:#fff;font-weight:600}
h2{
  font-size:14px;color:var(--accent);font-weight:700;letter-spacing:.4px;
  margin:26px 0 12px;padding-left:10px;border-left:3px solid var(--accent);
}
.grid{display:grid;gap:var(--gap);grid-template-columns:repeat(auto-fit,minmax(150px,1fr))}
.card{
  background:var(--card);border:1px solid var(--stroke);border-radius:var(--r);
  padding:18px;transition:border-color .16s ease,transform .16s ease;
}
.card:active{border-color:var(--accent);transform:translateY(-2px)}
.card h3{margin:0 0 6px;font-size:15px}
.card p{margin:0;font-size:13px;color:var(--sub)}
.badge{
  display:inline-block;font-size:11.5px;color:var(--accent);
  background:rgba(208,188,255,.14);border-radius:999px;padding:3px 10px;margin-bottom:8px;
}
.list{list-style:none;padding:0;margin:0;background:var(--card);
  border:1px solid var(--stroke);border-radius:var(--r);overflow:hidden}
.list li{display:flex;justify-content:space-between;align-items:center;
  padding:14px 18px;font-size:14px;border-top:1px solid var(--stroke)}
.list li:first-child{border-top:0}
.list .k{color:var(--sub);font-size:13px}
.empty{text-align:center;color:var(--sub);padding:36px 12px;font-size:13.5px;
  background:var(--card);border:1px dashed var(--stroke);border-radius:var(--r)}
footer{margin-top:28px;text-align:center;color:var(--sub);font-size:12px}
@media (prefers-reduced-motion:reduce){*{transition:none!important}}
</style>
</head>
<body>
  <header class="hero">
    <h1>$N</h1>
    <p>改 index.html 里的文字与卡片即可；配色在 :root 变量里统一改。</p>
    <div class="row">
      <button class="btn" id="go">主操作</button>
      <button class="btn ghost">次要操作</button>
    </div>
  </header>

  <h2>卡片区</h2>
  <section class="grid">
    <article class="card"><span class="badge">状态</span><h3>标题一</h3><p>一行说明文字，简短最好。</p></article>
    <article class="card"><span class="badge">状态</span><h3>标题二</h3><p>一行说明文字，简短最好。</p></article>
    <article class="card"><span class="badge">状态</span><h3>标题三</h3><p>一行说明文字，简短最好。</p></article>
  </section>

  <h2>列表 / 数据</h2>
  <ul class="list" id="list"></ul>

  <h2>空状态示例</h2>
  <div class="empty">暂无数据<br>这里放空状态，别留白屏</div>

  <footer>webdev 生成 · 本地预览 http://127.0.0.1:8080/</footer>

<script>
var rows = [["条目 A","值 1"],["条目 B","值 2"],["条目 C","值 3"]];
var ul = document.getElementById("list");
function render(data){
  ul.innerHTML = "";
  if(!data.length){
    var d = document.createElement("div");
    d.className = "empty"; d.textContent = "暂无数据";
    ul.parentNode.insertBefore(d, ul); ul.style.display = "none"; return;
  }
  data.forEach(function(it){
    var li = document.createElement("li");
    var k = document.createElement("span"); k.className = "k"; k.textContent = it[0];
    var v = document.createElement("span"); v.textContent = it[1];
    li.appendChild(k); li.appendChild(v); ul.appendChild(li);
  });
}
render(rows);
document.getElementById("go").addEventListener("click", function(){
  rows.push(["新增 " + rows.length, "值 " + rows.length]);
  render(rows);
});
</script>
</body>
</html>
HTML
  echo "已生成网页：$D/index.html"
  echo "预览： webdev serve \"$D\" 8080   然后手机浏览器打开 http://127.0.0.1:8080/"
}

do_serve() {
  D="${1:-.}"; P="${2:-8080}"
  [ -d "$D" ] || { echo "FAIL: 目录不存在 $D"; exit 1; }
  [ -f "$D/index.html" ] || echo "提示：$D 里没有 index.html，只当静态目录用"
  need_cmd python3 || { echo "FAIL: 缺 python3 -> javadev deps python3"; exit 1; }
  echo "预览地址： http://127.0.0.1:$P/   （手机浏览器打开；Ctrl+C 结束）"
  cd "$D" && exec python3 -m http.server "$P" --bind 0.0.0.0
}

# 导出：① 你指定 > ② App 注入的 $DS_EXPORT > ③ 常见公共目录 > ④ 容器导出区 /root/export/
# 文件和整个文件夹都能导（cp -rf）。
do_push() {
  SRC="$1"; D="${2:-}"
  [ -e "$SRC" ] || { echo "找不到 $SRC"; exit 1; }
  B="$(basename "$SRC")"

  if [ -n "$D" ]; then
    mkdir -p "$D" 2>/dev/null
    cp -rf "$SRC" "$D/" 2>/dev/null && { echo "已复制到 $D/$B"; return 0; }
    echo "写入 $D 失败"; return 1
  fi

  if [ -n "${DS_EXPORT:-}" ]; then
    mkdir -p "$DS_EXPORT" 2>/dev/null
    if cp -rf "$SRC" "$DS_EXPORT/" 2>/dev/null; then
      echo "已复制到 $DS_EXPORT/$B"
      return 0
    fi
    echo "注：DS_EXPORT=$DS_EXPORT 写不进去，换其它位置"
  fi

  for d in "$DS_EXT_DIR/web" /sdcard/Download /data/local/tmp; do
    mkdir -p "$d" 2>/dev/null
    if cp -rf "$SRC" "$d/" 2>/dev/null; then
      echo "已复制到 $d/$B"
      return 0
    fi
  done

  mkdir -p /root/export 2>/dev/null
  if cp -rf "$SRC" /root/export/ 2>/dev/null; then
    echo "公共目录写不进去（缺「所有文件访问」权限，App 里可一键授予）。"
    echo "已放进容器导出区：/root/export/$B"
    echo "回 App「关于 / 工具」页点「导出产物到可见文件夹」就能拿到。"
    return 0
  fi
  echo "导出失败：所有目标都写不进去"
  return 1
}

usage() { sed -n '2,10p' "$0" | sed 's/^# \{0,1\}//'; }

CMD="${1:-help}"; shift 2>/dev/null
case "$CMD" in
  info|i) do_info ;;
  new)    do_new "$@" ;;
  serve|s) do_serve "$@" ;;
  push|p) do_push "$@" ;;
  help|--help|-h|"") usage ;;
  *) usage; exit 1 ;;
esac
