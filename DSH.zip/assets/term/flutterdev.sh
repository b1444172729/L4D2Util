#!/bin/sh
# flutterdev —— 在手机容器里开发 Flutter（国内镜像 + 自检 + 明确的降级提示）
#
#   flutterdev info              自检：架构 / libc / 空间 / 镜像连通 / SDK 是否可用
#   flutterdev init              装 Flutter SDK（走 flutter-io.cn 镜像，自动选架构）
#   flutterdev new <名字>        生成 Flutter 工程骨架
#   flutterdev analyze <目录>    dart/flutter 静态检查
#   flutterdev web <目录>        flutter build web（产物在 <目录>/build/web）
#   flutterdev serve [目录] [端口]   起本地静态服务器预览（手机浏览器打开）
#   flutterdev apk <目录>        尝试 flutter build apk（需要 Android SDK + Gradle）
#   flutterdev push <路径>       导出到宿主可写目录
#   flutterdev doctor            透传 flutter doctor
#
# 说明：Flutter 官方桌面工具链只发布 linux-x64（glibc）。若本机是 aarch64
# 或纯 musl，SDK 很可能跑不起来 —— 此时别硬撑，直接用 webdev / javadev 出同功能版本。
set -u

FROOT="${FLUTTER_ROOT:-/opt/flutter}"
DIST="${FLUTTER_DIST:-/opt/flutter-sdk}"
BASE="${FLUTTER_STORAGE_BASE_URL:-https://storage.flutter-io.cn}"
TROOT="${TROOT:-/opt/dt}"

export PUB_HOSTED_URL="${PUB_HOSTED_URL:-https://pub.flutter-io.cn}"
export FLUTTER_STORAGE_BASE_URL="$BASE"
export PATH="$FROOT/bin:$TROOT/bin:$PATH"

export DS_EXT_DIR="${DS_EXT_DIR:-/sdcard/Android/data/com.dsmod.deepseek/files}"

ALPINE_MIRROR="${ALPINE_MIRROR:-https://mirrors.tuna.tsinghua.edu.cn/alpine}"
ALPINE_VER="${ALPINE_VER:-v3.20}"

dl() {
  u="$1"; out="$2"
  if command -v curl >/dev/null 2>&1; then
    curl -fL -C - --connect-timeout 20 --max-time 3600 -o "$out" "$u"
  else
    wget -c -T 20 -O "$out" "$u"
  fi
}

setup_apk_mirror() {
  printf '%s/%s/main\n%s/%s/community\n' "$ALPINE_MIRROR" "$ALPINE_VER" "$ALPINE_MIRROR" "$ALPINE_VER" \
    > /etc/apk/repositories
  apk update >/dev/null 2>&1 || true
}

need_cmd() {
  command -v "$1" >/dev/null 2>&1
}

arch_key() {
  case "$(uname -m)" in
    x86_64|amd64) echo "linux-x64" ;;
    aarch64|arm64) echo "linux-arm64" ;;
    armv7l|armv8l) echo "linux-armv7" ;;
    *) echo "linux-$(uname -m)" ;;
  esac
}

libc_kind() {
  if ls /lib/ld-musl-* >/dev/null 2>&1 || [ -f /etc/alpine-release ]; then echo "musl"
  elif ls /lib64/ld-linux-* >/dev/null 2>&1 || ls /lib/ld-linux-* >/dev/null 2>&1; then echo "glibc"
  else echo "未知"; fi
}

free_mb() { df -k /opt 2>/dev/null | awk 'NR==2{printf "%d", $4/1024}'; }

have_sdk() { [ -x "$FROOT/bin/flutter" ]; }

sdk_works() {
  have_sdk || return 1
  timeout 120 "$FROOT/bin/flutter" --version >/dev/null 2>&1
}

do_info() {
  echo "=== Flutter 开发环境自检 ==="
  echo "架构        : $(uname -m)  -> SDK 平台标识 $(arch_key)"
  echo "libc        : $(libc_kind)"
  echo "可用空间    : $(free_mb) MB（安装 SDK 建议 ≥ 2500 MB）"
  if have_sdk; then
    if sdk_works; then
      echo "Flutter SDK : 已安装且可运行"
      "$FROOT/bin/flutter" --version 2>&1 | sed -n '1,3p' | sed 's/^/              /'
    else
      echo "Flutter SDK : 已下载但【跑不起来】（多半是 glibc 版 Dart 在 musl 环境下无法加载）"
      echo "              -> 执行 flutterdev init 会再试一次；仍失败请走 webdev / javadev 替代"
    fi
  else
    echo "Flutter SDK : 未安装（执行 flutterdev init）"
  fi
  if need_cmd curl; then
    if curl -fsSI --connect-timeout 12 "$BASE/flutter_infra_release/releases/releases_linux.json" >/dev/null 2>&1; then
      echo "镜像连通    : $BASE 可达"
    else
      echo "镜像连通    : $BASE 不可达（检查网络/代理）"
    fi
  else
    echo "镜像连通    : 缺 curl（apk add curl）"
  fi
  echo "本地预览    : $(need_cmd python3 && echo "python3 就绪" || echo "缺 python3 -> javadev deps python3")"
  echo
  echo "结论："
  if [ "$(arch_key)" != "linux-x64" ] || [ "$(libc_kind)" = "musl" ]; then
    echo "  Flutter 官方桌面工具链只有 linux-x64 / glibc 版，本机不一定能装起来。"
    echo "  init 失败就不要硬试；改用："
    echo "    webdev  new  → 用 HTML/CSS/JS 做网页版（能直接预览，效果等同前端 App）"
    echo "    javadev new  → 用 Java 做原生 APK"
  else
    echo "  环境看起来可以，执行 flutterdev init 安装 SDK。"
  fi
}

do_init() {
  echo "[1/6] 准备基础工具（走清华镜像）"
  setup_apk_mirror
  apk add curl tar xz jq ca-certificates >/dev/null 2>&1 || true
  need_cmd curl || { echo "FAIL: 没有 curl，无法下载 SDK"; exit 1; }
  need_cmd tar  || { echo "FAIL: 没有 tar"; exit 1; }
  need_cmd jq   || { echo "FAIL: 没有 jq（apk add jq）"; exit 1; }

  K="$(arch_key)"
  L="$(libc_kind)"
  echo "     架构=$K  libc=$L  可用空间=$(free_mb)MB"
  # 事实：flutter_infra_release 里 Linux 只有一份 flutter_linux_<版本>-stable.tar.xz（x86_64），
  # 官方没有 arm64 条目。手机容器几乎都是 aarch64，下完也跑不起来 —— 直接劝退，别浪费 700MB。
  if [ "$(uname -m)" != "x86_64" ]; then
    echo "     本机是 $(uname -m)：官方 Linux SDK 只按 x86_64 发布，装上也基本跑不动。"
    echo "     建议直接降级：webdev（网页，能立刻预览）/ javadev（原生 APK，工具链已内置）。"
    echo "     确实想试一次：FLUTTER_FORCE=1 flutterdev init"
    [ "${FLUTTER_FORCE:-}" = "1" ] || exit 1
  fi
  if [ "$L" = "musl" ]; then
    echo "     装 glibc 兼容层（gcompat），否则 Dart 二进制加载不了"
    apk add gcompat libstdc++ >/dev/null 2>&1 || true
  fi

  echo "[2/6] 查询当前 stable 版本"
  TMP="$(mktemp -d)"
  dl "$BASE/flutter_infra_release/releases/releases_linux.json" "$TMP/r.json" \
    || { echo "FAIL: 取 releases_linux.json（镜像不可达）"; exit 1; }
  H="$(jq -r '.current_release.stable // empty' "$TMP/r.json")"
  [ -n "$H" ] || { echo "FAIL: 解析 stable hash"; exit 1; }
  ARC="$(jq -r --arg h "$H" \
        '.releases[] | select(.hash==$h) | select(.archive|test("linux")) | .archive' \
        "$TMP/r.json" | head -1)"
  if [ -z "$ARC" ]; then
    echo "FAIL: releases 里没有 linux 包"
    echo "     本机装不了 Flutter 工具链，请改用 webdev（网页）或 javadev（原生 APK）。"
    exit 1
  fi
  VER="$(echo "$ARC" | sed -n 's/.*flutter_linux_\([0-9.]*\)-stable.*/\1/p')"
  echo "     stable=$VER  archive=$ARC"

  echo "[3/6] 下载 SDK（约 700MB，可断点续传，慢是正常的）"
  mkdir -p "$DIST"
  if ! dl "$BASE/flutter_infra_release/releases/$ARC" "$DIST/flutter.tar.xz"; then
    echo "FAIL: 下载 SDK（网络中断，重跑 flutterdev init 会续传）"
    exit 1
  fi

  echo "[4/6] 解压到 $DIST"
  rm -rf "$DIST/flutter"
  tar -xJf "$DIST/flutter.tar.xz" -C "$DIST" || { echo "FAIL: 解压 SDK"; exit 1; }
  rm -f "$DIST/flutter.tar.xz"
  [ -d "$DIST/flutter" ] || { echo "FAIL: 解压后没找到 $DIST/flutter"; exit 1; }

  echo "[5/6] 链接到 $FROOT"
  if [ "$DIST/flutter" != "$FROOT" ]; then
    rm -rf "$FROOT"
    mkdir -p "$(dirname "$FROOT")"
    ln -sfn "$DIST/flutter" "$FROOT"
  fi
  chmod -R 0755 "$FROOT/bin" 2>/dev/null
  ln -sf "$FROOT/bin/flutter" /usr/local/bin/flutter 2>/dev/null
  ln -sf "$FROOT/bin/dart" /usr/local/bin/dart 2>/dev/null

  echo "[6/6] 首次运行 + 关掉统计 + 配 Gradle 国内镜像"
  mkdir -p /root/.gradle
  cat > /root/.gradle/init.gradle <<'GEOF'
// 强制走阿里云镜像，避免 Gradle 直连 Google/Maven 卡死
allprojects {
    buildscript {
        repositories {
            maven { url 'https://maven.aliyun.com/repository/google' }
            maven { url 'https://maven.aliyun.com/repository/gradle-plugin' }
            maven { url 'https://maven.aliyun.com/repository/public' }
            mavenCentral()
        }
    }
    repositories {
        maven { url 'https://maven.aliyun.com/repository/google' }
        maven { url 'https://maven.aliyun.com/repository/public' }
        mavenCentral()
    }
}
GEOF
  "$FROOT/bin/flutter" config --no-analytics >/dev/null 2>&1 || true

  if sdk_works; then
    echo "=================================================="
    echo "Flutter SDK 安装完成：$("$FROOT/bin/flutter" --version 2>&1 | head -1)"
    echo "下一步： flutterdev new myapp"
  else
    echo "=================================================="
    echo "FAIL: SDK 装上了但跑不起来（$(libc_kind) 环境下 glibc 版 Dart 无法加载）"
    echo "本机不适合用 Flutter 工具链，请改用："
    echo "  webdev new   → 网页（HTML/CSS/JS，能本机预览）"
    echo "  javadev new  → 原生 APK"
    exit 1
  fi
}

do_new() {
  N="${1:-}"; D="${2:-$N}"
  [ -n "$N" ] || { echo "用法：flutterdev new <名字> [目录]"; exit 1; }
  sdk_works || { echo "FAIL: Flutter SDK 不可用，先 flutterdev init（或改用 webdev/javadev）"; exit 1; }
  "$FROOT/bin/flutter" create --platforms=android,web --org com.dsmod --project-name "$N" "$D" \
    || { echo "FAIL: flutter create"; exit 1; }
  echo "已生成工程：$D"
  echo "  $D/lib/main.dart      界面写这里"
  echo "下一步： flutterdev web $D   （出网页版预览）"
}

do_analyze() {
  D="${1:-.}"
  sdk_works || { echo "FAIL: Flutter SDK 不可用"; exit 1; }
  "$FROOT/bin/flutter" analyze "$D"
}

do_web() {
  D="${1:-.}"
  sdk_works || { echo "FAIL: Flutter SDK 不可用，先 flutterdev init"; exit 1; }
  ( cd "$D" || exit 1; "$FROOT/bin/flutter" build web --release ) || { echo "FAIL: flutter build web"; exit 1; }
  W="$D/build/web"
  [ -f "$W/index.html" ] || { echo "FAIL: 没生成 $W/index.html"; exit 1; }
  echo "=================================================="
  echo "网页版产物：$W"
  echo "本机预览： flutterdev serve \"$W\" 8080   然后手机浏览器打开 http://127.0.0.1:8080/"
  echo "导出给别人： flutterdev push \"$W\""
}

do_serve() {
  D="${1:-.}"; P="${2:-8080}"
  [ -d "$D" ] || { echo "目录不存在：$D"; exit 1; }
  need_cmd python3 || { echo "缺 python3：先跑 javadev deps python3（或 apk add python3）"; exit 1; }
  echo "预览地址： http://127.0.0.1:$P/   （手机浏览器打开；Ctrl+C 结束）"
  cd "$D" && exec python3 -m http.server "$P" --bind 0.0.0.0
}

do_apk() {
  D="${1:-.}"
  sdk_works || { echo "FAIL: Flutter SDK 不可用，先 flutterdev init"; exit 1; }
  # 复用 javadev 解出的 Android 工具拼一个最小 SDK 目录，省掉再下一次 Android SDK
  if [ -x "$TROOT/bin/aapt2" ] && [ -f "$TROOT/platform/android.jar" ]; then
    SDK="${ANDROID_SDK_ROOT:-/opt/android-sdk}"
    mkdir -p "$SDK/platforms/android-34" "$SDK/build-tools/34.0.0" "$SDK/platform-tools" "$SDK/cmdline-tools/latest/bin" "$SDK/licenses"
    ln -sf "$TROOT/platform/android.jar" "$SDK/platforms/android-34/android.jar" 2>/dev/null
    for b in aapt2 zipalign apksigner d8; do
      [ -e "$TROOT/bin/$b" ] && ln -sf "$TROOT/bin/$b" "$SDK/build-tools/34.0.0/$b" 2>/dev/null
    done
    printf '\n24333f8a63b6825ea9c5514f83c2829b004d1fee\n8933bad161af4178b1185d1a37fbf41ea5269c55\nd56f5187479451eabf01fb78af6dfcb131a6481e\n' > "$SDK/licenses/android-sdk-license" 2>/dev/null
    export ANDROID_SDK_ROOT="$SDK" ANDROID_HOME="$SDK"
    echo "已用 javadev 内置工具拼出 ANDROID_HOME=$SDK"
  fi
  echo "开始构建 APK（会下载 Gradle 与依赖，慢且吃空间；失败属正常）"
  ( cd "$D" || exit 1; "$FROOT/bin/flutter" build apk --release ) || {
    echo "=================================================="
    echo "FAIL: flutter build apk"
    echo "常见原因：Gradle 发行包下不下来 / 缺完整 Android SDK / 空间不足。"
    echo "替代方案（都能出可安装/可用的成果）："
    echo "  1) flutterdev web <目录>   → 出网页版，本机可预览"
    echo "  2) javadev new + build     → 用 Java 写原生 APK，工具链已内置"
    exit 1
  }
  echo "=================================================="
  echo "APK：$D/build/app/outputs/flutter-apk/app-release.apk"
}

# 导出：① 你指定 > ② App 注入的 $DS_EXPORT > ③ 常见公共目录 > ④ 容器导出区 /root/export/
# 文件和整个文件夹（build/web 整个目录）都能导（cp -rf）。
do_push() {
  SRC="$1"; D="${2:-}"
  [ -e "$SRC" ] || { echo "找不到 $SRC"; exit 1; }
  B="$(basename "$SRC")"

  if [ -n "$D" ]; then
    mkdir -p "$D" 2>/dev/null
    cp -rf "$SRC" "$D/" 2>/dev/null && { echo "已复制到 $D/$B"; return 0; }
    echo "写入 $D 失败"; return 1
  fi

  if [ -n "${DS_EXPORT:-}" ]; then
    mkdir -p "$DS_EXPORT" 2>/dev/null
    if cp -rf "$SRC" "$DS_EXPORT/" 2>/dev/null; then
      echo "已复制到 $DS_EXPORT/$B"
      case "$B" in *.apk) echo "去文件管理器点这个 apk 即可安装";; esac
      return 0
    fi
    echo "注：DS_EXPORT=$DS_EXPORT 写不进去，换其它位置"
  fi

  for d in /sdcard/Download /storage/emulated/0/Download "$DS_EXT_DIR" /data/local/tmp; do
    mkdir -p "$d" 2>/dev/null
    if cp -rf "$SRC" "$d/" 2>/dev/null; then
      echo "已复制到 $d/$B"
      case "$B" in *.apk) echo "去文件管理器点这个 apk 即可安装";; esac
      return 0
    fi
  done

  mkdir -p /root/export 2>/dev/null
  if cp -rf "$SRC" /root/export/ 2>/dev/null; then
    echo "公共目录写不进去（缺「所有文件访问」权限，App 里可一键授予）。"
    echo "已放进容器导出区：/root/export/$B"
    echo "回 App「关于 / 工具」页点「导出产物到可见文件夹」就能拿到。"
    return 0
  fi
  echo "导出失败：所有目标都写不进去"
  return 1
}

usage() { sed -n '2,17p' "$0" | sed 's/^# \{0,1\}//'; }

CMD="${1:-help}"; shift 2>/dev/null
case "$CMD" in
  info|i)   do_info ;;
  init)     do_init ;;
  new)      do_new "$@" ;;
  analyze|a) do_analyze "$@" ;;
  web|w)    do_web "$@" ;;
  serve|s)  do_serve "$@" ;;
  apk)      do_apk "$@" ;;
  doctor)   sdk_works && "$FROOT/bin/flutter" doctor -v || echo "FAIL: Flutter SDK 不可用" ;;
  push|p)   do_push "$@" ;;
  help|--help|-h|"") usage ;;
  *) usage; exit 1 ;;
esac
