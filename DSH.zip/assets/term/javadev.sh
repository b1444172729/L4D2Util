#!/usr/bin/env ash
# javadev —— 容器内 Java / Android 开发与构建（arm64 · Alpine · PRoot）
#
# 离线优先：内置版把 JDK + aapt2/zipalign + r8(d8) + apksigner + android.jar
# 全部随 App 打包，不联网即可「写代码 -> 出 APK」。
# 精简版 /opt/dt 为空，执行 `javadev init` 从国内镜像补齐。
#
# 用法：
#   javadev init                       准备工具链（内置版秒过；精简版走国内镜像）
#   javadev info                       查看工具 / JVM 状态
#   javadev new <包名> <应用名> [目录]   生成一个可编译的最小工程（Java + AndroidManifest）
#   javadev build [工程目录] [-o 输出.apk]  编译 -> dex -> 打包 -> 对齐 -> 签名
#   javadev deps [包…]                  安装常用运行时/工具（python3 nodejs git vim …）
#   javadev push <apk>                 复制到 /sdcard/Download 方便安装
#
# 工程结构（javadev new 会生成）：
#   <目录>/AndroidManifest.xml   （文本，package 就是你的包名）
#   <目录>/src/**.java           （Java 源码，包名目录层级随意）
#   <目录>/res/…                 （可选；放布局/图片/values）
#   <目录>/libs/*.jar            （可选；第三方依赖 jar）
#
# 生成的 APK 在 <目录>/build/out/ 下，已对齐并签名（可直接安装）。

TROOT="${TROOT:-/opt/dt}"
AAPT2="$TROOT/bin/aapt2"
ZIPALIGN="$TROOT/bin/zipalign"
R8="$TROOT/jar/r8.jar"
ANDROID_JAR="$TROOT/platform/android.jar"
SIGNER="$TROOT/jar/uber-apk-signer.jar"

MIN_API="${MIN_API:-21}"
TGT_API="${TGT_API:-34}"
JSRC="${JSRC:-8}"

ALPINE_MIRROR="${ALPINE_MIRROR:-https://mirrors.tuna.tsinghua.edu.cn/alpine}"
ALPINE_VER="${ALPINE_VER:-v3.20}"
MAVEN_GOOGLE="${MAVEN_GOOGLE:-https://maven.aliyun.com/repository/google}"
GOOGLE_DL="${GOOGLE_DL:-https://dl.google.com}"
GH_ACC="${GH_ACC:-}"
# 默认加速镜像（按顺序尝试，失败自动换下一个；最后回退 GitHub 直连）
GH_MIRRORS="${GH_MIRRORS:-https://ghfast.top/ https://ghproxy.net/ https://gh-proxy.com/}"

# 关键：把工具目录放进 PATH。uber-apk-signer 会到 PATH 里找 zipalign，
# 不导出这个 PATH 它就会报 could not execute zipalign。
export PATH="$TROOT/bin:$PATH"

# PRoot 下 `mkdir -p a b c` 偶发丢目录、嵌套 -p 有时只建一级；
# 这里改成逐级、逐个建，确保目录一定存在。
mkd() {
  for d in "$@"; do
    [ -d "$d" ] && continue
    chain=""
    oldIFS="$IFS"; IFS='/'
    for seg in $d; do
      if [ -z "$seg" ]; then chain="/"
      elif [ "$chain" = "/" ]; then chain="/$seg"
      else chain="${chain:+$chain/}$seg"; fi
      [ -d "$chain" ] || mkdir "$chain" 2>/dev/null
    done
    IFS="$oldIFS"
    mkdir -p "$d" 2>/dev/null
  done
}

# 出错即停，并说明卡在哪一步
fail() { echo "FAIL: $1"; exit 1; }

usage() { sed -n '2,22p' "$0" | sed 's/^# \{0,1\}//'; }

dl() {
  u="$1"; out="$2"
  if command -v curl >/dev/null 2>&1; then
    curl -fL --connect-timeout 15 --max-time 1800 -o "$out" "$u"
  else
    wget -q -T 15 -O "$out" "$u"
  fi
}
fetch() {
  url="$1"; out="$2"
  if [ -n "$GH_ACC" ] && dl "$GH_ACC$url" "$out"; then return 0; fi
  for m in $GH_MIRRORS; do
    rm -f "$out"
    if dl "$m$url" "$out"; then return 0; fi
  done
  rm -f "$out"
  dl "$url" "$out"
}

has_java()  { command -v java >/dev/null 2>&1 && command -v javac >/dev/null 2>&1; }
builtin()   { [ -x "$AAPT2" ] && [ -f "$R8" ] && [ -f "$ANDROID_JAR" ]; }

setup_apk_mirror() {
  printf '%s/%s/main\n%s/%s/community\n' "$ALPINE_MIRROR" "$ALPINE_VER" "$ALPINE_MIRROR" "$ALPINE_VER" \
    > /etc/apk/repositories
  apk update >/dev/null 2>&1 || true
}

do_info() {
  echo "工具根目录：$TROOT"
  builtin && echo "构建工具：内置（aapt2 / zipalign / r8 / android.jar 就绪）" \
           || echo "构建工具：未内置（精简版，执行 javadev init 下载）"
  has_java && echo "JDK：$(javac -version 2>&1)" || echo "JDK：未安装"
  command -v zip >/dev/null 2>&1 && echo "zip：ok" || echo "zip：缺"
}

do_init() {
  if ! has_java; then
    echo "[1/2] 安装 JDK（国内镜像 openjdk17-jdk）…"
    setup_apk_mirror
    apk add --no-cache openjdk17-jdk unzip zip || exit 1
  else
    echo "[1/2] JDK 已就绪：$(javac -version 2>&1)"
  fi
  if builtin; then
    echo "[2/2] 构建工具已内置，无需下载。"
    return 0
  fi
  echo "[2/2] 下载构建工具（国内镜像 / 加速）…"
  mkd "$TROOT/bin" "$TROOT/jar" "$TROOT/platform"
  command -v zip   >/dev/null 2>&1 || apk add --no-cache zip
  command -v unzip >/dev/null 2>&1 || apk add --no-cache unzip

  tmp="$(mktemp -d)"
  fetch "https://github.com/lzhiyong/android-sdk-tools/releases/download/35.0.2/android-sdk-tools-static-aarch64.zip" "$tmp/bt.zip" \
    && unzip -oq "$tmp/bt.zip" 'build-tools/*' -d "$tmp/bt" \
    && cp -f "$tmp/bt/build-tools/"* "$TROOT/bin/" && chmod 0755 "$TROOT/bin/"* \
    || echo "  ! aapt2 / zipalign 下载失败"
  fetch "$MAVEN_GOOGLE/com/android/tools/r8/8.3.37/r8-8.3.37.jar" "$TROOT/jar/r8.jar" \
    || echo "  ! r8(d8) 下载失败"
  fetch "$GOOGLE_DL/android/repository/platform-35_r02.zip" "$tmp/pf.zip" \
    && unzip -oq "$tmp/pf.zip" 'android-35/android.jar' -d "$tmp/pf" \
    && cp -f "$tmp/pf/android-35/android.jar" "$ANDROID_JAR" \
    || echo "  ! android.jar 下载失败（可设 GOOGLE_DL 指向镜像）"
  fetch "https://github.com/patrickfav/uber-apk-signer/releases/download/v1.3.0/uber-apk-signer-1.3.0.jar" "$SIGNER" \
    || echo "  ! 签名器下载失败（会用 jarsigner 兜底）"
  rm -rf "$tmp"
  echo "完成。"
}

do_deps() {
  [ $# -gt 0 ] || { echo "用法：javadev deps <包…>  例如 python3 nodejs git vim"; return 1; }
  setup_apk_mirror
  apk add --no-cache "$@"
}

# ---------- 生成最小工程 ----------
do_new() {
  PKG="$1"; APP="$2"; DIR="${3:-$(echo "$PKG" | awk -F. '{print $NF}')}"
  [ -n "$PKG" ] && [ -n "$APP" ] || { echo "用法：javadev new <包名> <应用名> [目录]"; exit 1; }
  case "$PKG" in *.*) ;; *) echo "包名要带点，例如 com.example.hello"; exit 1;; esac
  mkd "$DIR/src" || exit 1
  PF="$(echo "$PKG" | tr '.' '/')"
  mkd "$DIR/src/$PF"

  cat > "$DIR/AndroidManifest.xml" <<EOF
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="$PKG">

    <!-- 需要哪条就取消注释；危险权限还要在代码里运行时申请 -->
    <!-- <uses-permission android:name="android.permission.INTERNET" /> -->
    <!-- <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" /> -->
    <!-- <uses-permission android:name="android.permission.POST_NOTIFICATIONS" /> -->
    <!-- <uses-permission android:name="android.permission.CAMERA" /> -->
    <!-- <uses-permission android:name="android.permission.RECORD_AUDIO" /> -->
    <!-- <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" /> -->
    <!-- <uses-permission android:name="android.permission.READ_MEDIA_IMAGES" /> -->

    <application
        android:label="$APP"
        android:usesCleartextTraffic="false"
        android:theme="@android:style/Theme.Material.NoActionBar">
        <activity
            android:name=".MainActivity"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
EOF

  # 附带的 Ui.java：统一深色 M3 外观，界面直接复用，别退回系统默认控件
  cat > "$DIR/src/$PF/Ui.java" <<EOF
package $PKG;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** 统一外观工具：颜色/圆角/投影全部用代码画，保证深色 M3 风格一致。 */
public final class Ui {
    public static final int BG        = 0xFF0D1117;
    public static final int CARD      = 0xFF1B1B22;
    public static final int STROKE    = 0xFF2C2C36;
    public static final int TEXT      = 0xFFE6E0E9;
    public static final int SUB       = 0xFF9AA6B2;
    public static final int ACCENT    = 0xFFD0BCFF;
    public static final int ACCENT_D  = 0xFFBFA6F5;
    public static final int ON_ACCENT = 0xFF2A1F4D;

    private Ui() { }

    public static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    public static LinearLayout.LayoutParams fill() {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    public static LinearLayout.LayoutParams fillTop(Context c, float topDp) {
        LinearLayout.LayoutParams p = fill(); p.topMargin = dp(c, topDp); return p;
    }

    public static LinearLayout.LayoutParams weight() {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
    }

    public static LinearLayout.LayoutParams grow() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
    }

    public static GradientDrawable round(Context c, int fillColor, float radiusDp, int strokeColor) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.RECTANGLE);
        g.setColor(fillColor);
        g.setCornerRadius(dp(c, radiusDp));
        if (strokeColor != 0) g.setStroke(Math.max(1, dp(c, 1)), strokeColor);
        return g;
    }

    private static StateListDrawable stateful(Context c, int fill, int fillPressed,
                                              float radiusDp, int stroke, int strokePressed) {
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_pressed}, round(c, fillPressed, radiusDp, strokePressed));
        s.addState(new int[]{}, round(c, fill, radiusDp, stroke));
        return s;
    }

    public static LinearLayout screen(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackgroundColor(BG);
        int p = dp(c, 16);
        l.setPadding(p, dp(c, 12), p, dp(c, 24));
        return l;
    }

    public static LinearLayout row(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    public static LinearLayout card(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        int p = dp(c, 16);
        l.setPadding(p, p, p, p);
        l.setBackground(round(c, CARD, 22, STROKE));
        l.setElevation(dp(c, 1));
        return l;
    }

    /** 顶部标题区：主色渐变卡。 */
    public static LinearLayout hero(Context c, String title, String subtitle) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        int p = dp(c, 20);
        l.setPadding(p, p, p, p);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF53389E, 0xFF3B6FD4});
        g.setShape(GradientDrawable.RECTANGLE);
        g.setCornerRadius(dp(c, 26));
        l.setBackground(g);
        l.setElevation(dp(c, 3));
        TextView t = new TextView(c);
        t.setText(title); t.setTextSize(20); t.setTextColor(0xFFFFFFFF);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        l.addView(t, fill());
        if (subtitle != null && subtitle.length() > 0) {
            TextView s = new TextView(c);
            s.setText(subtitle); s.setTextSize(13); s.setTextColor(0xD9FFFFFF);
            s.setLineSpacing(dp(c, 3), 1f);
            l.addView(s, fillTop(c, 8));
        }
        return l;
    }

    public static TextView title(Context c, String s) {
        TextView t = new TextView(c);
        t.setText(s); t.setTextSize(20); t.setTextColor(TEXT);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    public static TextView body(Context c, String s) {
        TextView t = new TextView(c);
        t.setText(s); t.setTextSize(14); t.setTextColor(TEXT);
        t.setLineSpacing(dp(c, 4), 1f);
        return t;
    }

    public static TextView sub(Context c, String s) {
        TextView t = new TextView(c);
        t.setText(s); t.setTextSize(13); t.setTextColor(SUB);
        t.setLineSpacing(dp(c, 4), 1f);
        return t;
    }

    public static TextView section(Context c, String s) {
        TextView t = new TextView(c);
        t.setText("▎ " + s); t.setTextSize(14); t.setTextColor(ACCENT);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(dp(c, 2), dp(c, 22), dp(c, 2), dp(c, 8));
        return t;
    }

    public static Button primary(Context c, String s) {
        Button b = new Button(c);
        b.setText(s); b.setAllCaps(false); b.setTextSize(15);
        b.setTextColor(ON_ACCENT); b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setBackground(stateful(c, ACCENT, ACCENT_D, 20, 0, 0));
        b.setPadding(dp(c, 20), dp(c, 14), dp(c, 20), dp(c, 14));
        b.setMinHeight(dp(c, 48));
        b.setElevation(dp(c, 2));
        return b;
    }

    public static Button ghost(Context c, String s) {
        Button b = new Button(c);
        b.setText(s); b.setAllCaps(false); b.setTextSize(14);
        b.setTextColor(TEXT);
        b.setBackground(stateful(c, 0xFF22222B, 0xFF2D2D38, 20, STROKE, ACCENT));
        b.setPadding(dp(c, 16), dp(c, 12), dp(c, 16), dp(c, 12));
        b.setMinHeight(dp(c, 46));
        return b;
    }

    public static ScrollView scroll(Context c, View child) {
        ScrollView sv = new ScrollView(c);
        sv.setBackgroundColor(BG);
        sv.setFillViewport(true);
        sv.addView(child, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return sv;
    }
}
EOF

  # 演示用 MainActivity：直接用 Ui，把「好看」做成起点
  cat > "$DIR/src/$PF/MainActivity.java" <<EOF
package $PKG;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = Ui.screen(this);

        root.addView(Ui.hero(this, "$APP", "在 $PF 里改这个界面"), Ui.fill());

        LinearLayout card = Ui.card(this);
        card.addView(Ui.body(this, "把内容放在卡片里：标题 + 说明 + 主按钮。"), Ui.fill());
        Button go = Ui.primary(this, "开始");
        go.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Toast.makeText(MainActivity.this, "点到了", Toast.LENGTH_SHORT).show();
            }
        });
        card.addView(go, Ui.fillTop(this, 16));
        root.addView(card, Ui.fillTop(this, 14));

        root.addView(Ui.section(this, "更多"));
        root.addView(Ui.sub(this, "复制 card/section/primary 这套写法，保持整页风格统一。"), Ui.fill());

        setContentView(Ui.scroll(this, root));
    }
}
EOF

  cat > "$DIR/build.sh" <<'EOF'
#!/bin/sh
# 一条命令出 APK（自动解析成绝对路径，避免 PRoot 下相对路径失效）
exec javadev build "$(cd "$(dirname "$0")" && pwd)" "$@"
EOF
  chmod 0755 "$DIR/build.sh"

  echo "已生成工程：$DIR"
  echo "  $DIR/AndroidManifest.xml   （package=$PKG，权限在这里按需取消注释）"
  echo "  $DIR/src/$PF/Ui.java       （深色 M3 外观工具类，界面直接复用）"
  echo "  $DIR/src/$PF/MainActivity.java"
  echo "下一步： javadev build $DIR"
}

# ---------- 构建 APK ----------
do_build() {
  PRJ="$1"; [ -n "$PRJ" ] || PRJ="."
  shift 2>/dev/null
  OUT=""
  while [ $# -gt 0 ]; do case "$1" in -o) OUT="$2"; shift 2;; *) shift;; esac; done

  [ -d "$PRJ" ] || { echo "找不到工程目录：$PRJ"; exit 1; }
  # 一律转成绝对路径（PRoot 下相对路径时好时坏）
  case "$PRJ" in /*) ;; *) PRJ="$(pwd)/$PRJ" ;; esac
  PRJ="$(cd "$PRJ" && pwd)" || fail "解析工程目录"
  [ -f "$PRJ/AndroidManifest.xml" ] || { echo "缺 AndroidManifest.xml"; exit 1; }
  has_java || { echo "缺 JDK：先执行 javadev init"; exit 1; }
  builtin  || { echo "缺构建工具（aapt2/r8/android.jar）：先执行 javadev init"; exit 1; }

  BD="$PRJ/build"
  rm -rf "$BD"
  mkd "$BD/compiled" "$BD/gen" "$BD/classes" "$BD/dex" "$BD/out"
  [ -d "$BD/classes" ] && [ -d "$BD/dex" ] || fail "创建 build 目录"

  # 1) 资源（可选）
  RESARG=""
  if [ -d "$PRJ/res" ]; then
    echo "[1/6] 编译资源 aapt2 compile …"
    "$AAPT2" compile --dir "$PRJ/res" -o "$BD/compiled/res.zip" || fail "aapt2 compile"
    RESARG="$BD/compiled/res.zip"
  else
    echo "[1/6] 无 res/，跳过资源编译"
  fi

  # 2) 链接：生成二进制清单 + resources.arsc + R.java
  echo "[2/6] aapt2 link …"
  "$AAPT2" link -o "$BD/base.apk" -I "$ANDROID_JAR" \
      --manifest "$PRJ/AndroidManifest.xml" \
      --java "$BD/gen" \
      --min-sdk-version "$MIN_API" --target-sdk-version "$TGT_API" \
      $RESARG || fail "aapt2 link"

  # 3) javac
  echo "[3/6] javac 编译 Java …"
  find "$PRJ/src" -name '*.java' > "$BD/sources.txt" 2>/dev/null
  find "$BD/gen"  -name '*.java' >> "$BD/sources.txt" 2>/dev/null
  [ -s "$BD/sources.txt" ] || fail "没有 .java 源码"
  CP="$ANDROID_JAR"
  for j in "$PRJ"/libs/*.jar; do [ -f "$j" ] && CP="$CP:$j"; done
  javac -encoding UTF-8 -nowarn -source "$JSRC" -target "$JSRC" \
        -classpath "$CP" -d "$BD/classes" @"$BD/sources.txt" || fail "javac 编译"

  # 4) d8 转 dex
  echo "[4/6] d8 转 dex …"
  ( cd "$BD/classes" && jar cf "$BD/classes.jar" . ) || fail "打包 classes.jar"
  java -cp "$R8" com.android.tools.r8.D8 \
       --min-api "$MIN_API" --lib "$ANDROID_JAR" \
       --classpath "$ANDROID_JAR" \
       --output "$BD/dex" "$BD/classes.jar" || fail "d8 转 dex"

  # 5) 把 classes.dex 塞进 APK + 对齐
  echo "[5/6] 打包 + zipalign …"
  cp -f "$BD/base.apk" "$BD/unsigned.apk" || fail "复制 base.apk"
  ( cd "$BD/dex" && zip -q -X "$BD/unsigned.apk" classes.dex ) || fail "写入 classes.dex"
  "$ZIPALIGN" -f -p 4 "$BD/unsigned.apk" "$BD/aligned.apk" || fail "zipalign"

  # 6) 签名（PATH 里已含 $TROOT/bin，签名器能找到 zipalign）
  echo "[6/6] 签名 …"
  FINAL=""
  if [ -f "$SIGNER" ]; then
    java -jar "$SIGNER" -a "$BD/aligned.apk" -o "$BD/out" --allowResign || fail "签名（uber-apk-signer）"
    FINAL="$(ls -t "$BD/out"/*.apk 2>/dev/null | head -1)"
  fi
  if [ -z "$FINAL" ]; then
    apkmod sign "$BD/aligned.apk" "$BD/out/$(basename "$PRJ").apk" >/dev/null 2>&1 || fail "签名（apkmod 兜底）"
    FINAL="$BD/out/$(basename "$PRJ").apk"
  fi

  if [ -n "$OUT" ]; then
    case "$OUT" in /*) ;; *) OUT="$(pwd)/$OUT" ;; esac
    cp -f "$FINAL" "$OUT" || fail "复制产物到 $OUT"
    FINAL="$OUT"
  fi
  echo "=================================================="
  echo "构建完成：$FINAL"
  echo "安装： javadev push \"$FINAL\"   （自动找可写目录导出）"
}

# 导出：① 你指定 > ② App 注入的 $DS_EXPORT（工作区/已授权的下载目录）
#       ③ 常见公共目录 > ④ 容器导出区 /root/export/（App 里一键搬出去）
# APK 和整个文件夹都能导（cp -rf）。
do_push() {
  SRC="$1"; D="$2"
  [ -e "$SRC" ] || { echo "找不到 $SRC"; exit 1; }
  B="$(basename "$SRC")"

  if [ -n "${D:-}" ]; then
    mkd "$D"
    cp -rf "$SRC" "$D/" 2>/dev/null && { echo "已复制到 $D/$B"; return 0; }
    echo "写入 $D 失败"; return 1
  fi

  if [ -n "${DS_EXPORT:-}" ]; then
    mkd "$DS_EXPORT"
    if cp -rf "$SRC" "$DS_EXPORT/" 2>/dev/null; then
      echo "已复制到 $DS_EXPORT/$B"
      case "$B" in *.apk) echo "去文件管理器点这个 apk 即可安装";; esac
      return 0
    fi
    echo "注：DS_EXPORT=$DS_EXPORT 写不进去，换其它位置"
  fi

  for d in /sdcard/Download /storage/emulated/0/Download "$DS_EXT_DIR" /data/local/tmp; do
    mkd "$d"
    if cp -rf "$SRC" "$d/" 2>/dev/null; then
      echo "已复制到 $d/$B"
      case "$B" in *.apk) echo "去文件管理器点这个 apk 即可安装";; esac
      return 0
    fi
  done

  mkd /root/export
  if cp -rf "$SRC" /root/export/ 2>/dev/null; then
    echo "公共目录写不进去（缺「所有文件访问」权限，App 里可一键授予）。"
    echo "已放进容器导出区：/root/export/$B"
    echo "回 App「关于 / 工具」页点「导出产物到可见文件夹」就能拿到。"
    return 0
  fi
  echo "导出失败：所有目标都写不进去"
  return 1
}

CMD="${1:-help}"; shift 2>/dev/null
case "$CMD" in
  init)  do_init ;;
  info)  do_info ;;
  new)   do_new "$@" ;;
  build|b) do_build "$@" ;;
  deps)  do_deps "$@" ;;
  push)  do_push "$@" ;;
  help|--help|-h) usage ;;
  *) usage; exit 1 ;;
esac
