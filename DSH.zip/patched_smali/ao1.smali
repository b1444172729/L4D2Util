.class public final Lao1;
.super Ljava/lang/Object;
.source "r8-map-id-24591713727e7837693cdfec6d15fe2ce5f4987b5aba1f4bab3573f0d74a433d"

# interfaces
.implements Lk55;
.implements Ljb1;
.implements Lhe1;
.implements Lif1;


# static fields
.field public static final E:Lcl5;


# instance fields
.field public final A:Lrs8;

.field public final B:Lrs8;

.field public final C:Lz09;

.field public final D:Lvta;

.field public final synthetic a:Lfg1;

.field public final b:Lc31;

.field public final c:Lis9;

.field public final d:Lgy;

.field public final e:Lkm4;

.field public final f:Lp66;

.field public final g:Lwv3;

.field public final h:Lxv3;

.field public final i:Lsv3;

.field public final j:Lxe1;

.field public final k:Lbs0;

.field public l:Lwr8;

.field public final m:Lz09;

.field public final n:Lz09;

.field public final o:Lz09;

.field public final p:Lz09;

.field public final q:Lib1;

.field public final r:Lxg1;

.field public final s:Lz09;

.field public final t:Lz09;

.field public final u:Lib1;

.field public final v:Lrs8;

.field public final w:Lgh7;

.field public final x:Ljd1;

.field public final y:Lgh7;

.field public final z:Ldh8;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "ChatSessionComponent"

    .line 2
    .line 3
    invoke-static {v0}, Lv9a;->Y(Ljava/lang/String;)Lcl5;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    sput-object v0, Lao1;->E:Lcl5;

    .line 8
    .line 9
    return-void
.end method

.method public constructor <init>(Lwr;Lc31;Lis9;Lgy;Lkm4;Lp66;Ld22;Ln5;Lxv3;Lsv3;I)V
    .locals 4

    .line 1
    and-int/lit16 p11, p11, 0x80

    .line 2
    .line 3
    if-eqz p11, :cond_0

    .line 4
    .line 5
    new-instance p8, Lhw0;

    .line 6
    .line 7
    const/16 p11, 0x8

    .line 8
    .line 9
    invoke-direct {p8, p11}, Lhw0;-><init>(I)V

    .line 10
    .line 11
    .line 12
    :cond_0
    new-instance p11, Lyp1;

    .line 13
    .line 14
    invoke-direct {p11}, Lyp1;-><init>()V

    .line 15
    .line 16
    .line 17
    new-instance v0, Lxe1;

    .line 18
    .line 19
    invoke-direct {v0, p2, p7, p5}, Lxe1;-><init>(Lc31;Ld22;Lkm4;)V

    .line 20
    .line 21
    .line 22
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 23
    .line 24
    .line 25
    new-instance v1, Lfg1;

    .line 26
    .line 27
    new-instance v2, Lj;

    .line 28
    .line 29
    const/16 v3, 0x1c

    .line 30
    .line 31
    invoke-direct {v2, v3, v0}, Lj;-><init>(ILjava/lang/Object;)V

    .line 32
    .line 33
    .line 34
    invoke-direct {v1, p7, p2, v2}, Lfg1;-><init>(Ld22;Lc31;Lhv3;)V

    .line 35
    .line 36
    .line 37
    iput-object v1, p0, Lao1;->a:Lfg1;

    .line 38
    .line 39
    iput-object p2, p0, Lao1;->b:Lc31;

    .line 40
    .line 41
    iput-object p3, p0, Lao1;->c:Lis9;

    .line 42
    .line 43
    iput-object p4, p0, Lao1;->d:Lgy;

    .line 44
    .line 45
    iput-object p5, p0, Lao1;->e:Lkm4;

    .line 46
    .line 47
    iput-object p6, p0, Lao1;->f:Lp66;

    .line 48
    .line 49
    iput-object p8, p0, Lao1;->g:Lwv3;

    .line 50
    .line 51
    iput-object p9, p0, Lao1;->h:Lxv3;

    .line 52
    .line 53
    iput-object p10, p0, Lao1;->i:Lsv3;

    .line 54
    .line 55
    iput-object v0, p0, Lao1;->j:Lxe1;

    .line 56
    .line 57
    iget-object p2, p7, Ld22;->a:Lag2;

    .line 58
    .line 59
    sget-object p3, Lqga;->n:Lqga;

    .line 60
    .line 61
    invoke-interface {p2, p3}, Lag2;->R(Lzf2;)Lyf2;

    .line 62
    .line 63
    .line 64
    move-result-object p3

    .line 65
    check-cast p3, Lht4;

    .line 66
    .line 67
    new-instance p4, Lmz8;

    .line 68
    .line 69
    invoke-direct {p4, p3}, Ljt4;-><init>(Lht4;)V

    .line 70
    .line 71
    .line 72
    invoke-interface {p2, p4}, Lag2;->N(Lag2;)Lag2;

    .line 73
    .line 74
    .line 75
    move-result-object p2

    .line 76
    invoke-static {p2}, Lv9a;->k(Lag2;)Lbs0;

    .line 77
    .line 78
    .line 79
    move-result-object p2

    .line 80
    iput-object p2, p0, Lao1;->k:Lbs0;

    .line 81
    .line 82
    new-instance p2, Lmm1;

    .line 83
    .line 84
    const/16 p3, 0xa

    .line 85
    .line 86
    invoke-direct {p2, p0, p3}, Lmm1;-><init>(Lao1;I)V

    .line 87
    .line 88
    .line 89
    new-instance p3, Lz09;

    .line 90
    .line 91
    invoke-direct {p3, p2}, Lz09;-><init>(Lhv3;)V

    .line 92
    .line 93
    .line 94
    iput-object p3, p0, Lao1;->m:Lz09;

    .line 95
    .line 96
    new-instance p2, Lmm1;

    .line 97
    .line 98
    const/16 p3, 0xb

    .line 99
    .line 100
    invoke-direct {p2, p0, p3}, Lmm1;-><init>(Lao1;I)V

    .line 101
    .line 102
    .line 103
    new-instance p3, Lz09;

    .line 104
    .line 105
    invoke-direct {p3, p2}, Lz09;-><init>(Lhv3;)V

    .line 106
    .line 107
    .line 108
    iput-object p3, p0, Lao1;->n:Lz09;

    .line 109
    .line 110
    new-instance p2, Lmm1;

    .line 111
    .line 112
    const/16 p3, 0xc

    .line 113
    .line 114
    invoke-direct {p2, p0, p3}, Lmm1;-><init>(Lao1;I)V

    .line 115
    .line 116
    .line 117
    new-instance p3, Lz09;

    .line 118
    .line 119
    invoke-direct {p3, p2}, Lz09;-><init>(Lhv3;)V

    .line 120
    .line 121
    .line 122
    iput-object p3, p0, Lao1;->o:Lz09;

    .line 123
    .line 124
    new-instance p2, Lna;

    .line 125
    .line 126
    const/16 p3, 0x1a

    .line 127
    .line 128
    invoke-direct {p2, p3, p0, p11}, Lna;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 129
    .line 130
    .line 131
    new-instance p3, Lz09;

    .line 132
    .line 133
    invoke-direct {p3, p2}, Lz09;-><init>(Lhv3;)V

    .line 134
    .line 135
    .line 136
    iput-object p3, p0, Lao1;->p:Lz09;

    .line 137
    .line 138
    new-instance p2, Lib1;

    .line 139
    .line 140
    invoke-direct {p2}, Lib1;-><init>()V

    .line 141
    .line 142
    .line 143
    iput-object p2, p0, Lao1;->q:Lib1;

    .line 144
    .line 145
    new-instance p2, Lxg1;

    .line 146
    .line 147
    invoke-direct {p2, p7}, Lxg1;-><init>(Ld22;)V

    .line 148
    .line 149
    .line 150
    iput-object p2, p0, Lao1;->r:Lxg1;

    .line 151
    .line 152
    new-instance p2, Lmm1;

    .line 153
    .line 154
    const/4 p3, 0x0

    .line 155
    invoke-direct {p2, p0, p3}, Lmm1;-><init>(Lao1;I)V

    .line 156
    .line 157
    .line 158
    new-instance p4, Lz09;

    .line 159
    .line 160
    invoke-direct {p4, p2}, Lz09;-><init>(Lhv3;)V

    .line 161
    .line 162
    .line 163
    iput-object p4, p0, Lao1;->s:Lz09;

    .line 164
    .line 165
    new-instance p2, Lmm1;

    .line 166
    .line 167
    const/4 p4, 0x1

    .line 168
    invoke-direct {p2, p0, p4}, Lmm1;-><init>(Lao1;I)V

    .line 169
    .line 170
    .line 171
    new-instance p5, Lz09;

    .line 172
    .line 173
    invoke-direct {p5, p2}, Lz09;-><init>(Lhv3;)V

    .line 174
    .line 175
    .line 176
    iput-object p5, p0, Lao1;->t:Lz09;

    .line 177
    .line 178
    new-instance p2, Lib1;

    .line 179
    .line 180
    new-instance p5, Lmm1;

    .line 181
    .line 182
    const/4 p8, 0x2

    .line 183
    invoke-direct {p5, p0, p8}, Lmm1;-><init>(Lao1;I)V

    .line 184
    .line 185
    .line 186
    invoke-direct {p2, p4, p5}, Lib1;-><init>(ILjava/lang/Object;)V

    .line 187
    .line 188
    .line 189
    iput-object p2, p0, Lao1;->u:Lib1;

    .line 190
    .line 191
    invoke-static {p1}, Ltga;->Q(Lwr;)Z

    .line 192
    .line 193
    .line 194
    move-result p2

    .line 195
    if-eqz p2, :cond_1

    .line 196
    .line 197
    new-instance p2, Lgo1;

    .line 198
    .line 199
    invoke-direct {p2, p1}, Lgo1;-><init>(Lwr;)V

    .line 200
    .line 201
    .line 202
    goto :goto_0

    .line 203
    :cond_1
    new-instance p2, Leo1;

    .line 204
    .line 205
    invoke-direct {p2, p1}, Leo1;-><init>(Lwr;)V

    .line 206
    .line 207
    .line 208
    :goto_0
    invoke-static {p2}, Lzya;->s(Ljava/lang/Object;)Lrs8;

    .line 209
    .line 210
    .line 211
    move-result-object p8

    .line 212
    iput-object p8, p0, Lao1;->v:Lrs8;

    .line 213
    .line 214
    new-instance p1, Lh5;

    .line 215
    .line 216
    invoke-direct {p1, p8, p4}, Lh5;-><init>(Lrs8;I)V

    .line 217
    .line 218
    .line 219
    invoke-virtual {p8}, Lrs8;->getValue()Ljava/lang/Object;

    .line 220
    .line 221
    .line 222
    move-result-object p2

    .line 223
    check-cast p2, Lho1;

    .line 224
    .line 225
    invoke-interface {p2}, Lho1;->b()Lwr;

    .line 226
    .line 227
    .line 228
    move-result-object p2

    .line 229
    sget-object p5, Luh8;->a:Lt60;

    .line 230
    .line 231
    invoke-static {p1, p7, p5, p2}, Llj0;->p0(Lki3;Lig2;Lvh8;Ljava/lang/Object;)Lgh7;

    .line 232
    .line 233
    .line 234
    move-result-object p1

    .line 235
    iput-object p1, p0, Lao1;->w:Lgh7;

    .line 236
    .line 237
    new-instance p5, Ljd1;

    .line 238
    .line 239
    new-instance p9, Lmm1;

    .line 240
    .line 241
    const/4 p2, 0x3

    .line 242
    invoke-direct {p9, p0, p2}, Lmm1;-><init>(Lao1;I)V

    .line 243
    .line 244
    .line 245
    move-object p10, p6

    .line 246
    move-object p6, p7

    .line 247
    move-object p7, p1

    .line 248
    invoke-direct/range {p5 .. p10}, Ljd1;-><init>(Ld22;Lgh7;Lrs8;Lhv3;Lp66;)V

    .line 249
    .line 250
    .line 251
    iput-object p5, p0, Lao1;->x:Ljd1;

    .line 252
    .line 253
    iget-object p1, p5, Ljd1;->g:Lgh7;

    .line 254
    .line 255
    iput-object p1, p0, Lao1;->y:Lgh7;

    .line 256
    .line 257
    const/4 p1, 0x7

    .line 258
    invoke-static {p3, p3, p1}, Luk8;->o(III)Ldh8;

    .line 259
    .line 260
    .line 261
    move-result-object p1

    .line 262
    iput-object p1, p0, Lao1;->z:Ldh8;

    .line 263
    .line 264
    sget-object p1, Le06;->a:Le06;

    .line 265
    .line 266
    invoke-static {p1}, Lzya;->s(Ljava/lang/Object;)Lrs8;

    .line 267
    .line 268
    .line 269
    move-result-object p1

    .line 270
    iput-object p1, p0, Lao1;->A:Lrs8;

    .line 271
    .line 272
    iput-object p1, p0, Lao1;->B:Lrs8;

    .line 273
    .line 274
    new-instance p1, Li11;

    .line 275
    .line 276
    const/4 p5, 0x0

    .line 277
    invoke-direct {p1, p0, p5, p4}, Li11;-><init>(Ljava/lang/Object;Lhf2;I)V

    .line 278
    .line 279
    .line 280
    iput-object p1, v0, Lxe1;->l:Lsv3;

    .line 281
    .line 282
    new-instance p1, Ll4;

    .line 283
    .line 284
    const/16 p4, 0x13

    .line 285
    .line 286
    invoke-direct {p1, p0, p5, p4}, Ll4;-><init>(Ljava/lang/Object;Lhf2;I)V

    .line 287
    .line 288
    .line 289
    invoke-static {p6, p5, p3, p1, p2}, Lv9a;->P(Lig2;Lag2;ILwv3;I)Lwr8;

    .line 290
    .line 291
    .line 292
    new-instance p1, Lmm1;

    .line 293
    .line 294
    const/4 p2, 0x4

    .line 295
    invoke-direct {p1, p0, p2}, Lmm1;-><init>(Lao1;I)V

    .line 296
    .line 297
    .line 298
    new-instance p2, Lz09;

    .line 299
    .line 300
    invoke-direct {p2, p1}, Lz09;-><init>(Lhv3;)V

    .line 301
    .line 302
    .line 303
    iput-object p2, p0, Lao1;->C:Lz09;

    .line 304
    .line 305
    new-instance p1, Lvta;

    .line 306
    .line 307
    invoke-direct {p1, p0}, Lvta;-><init>(Ljava/lang/Object;)V

    .line 308
    .line 309
    .line 310
    iput-object p1, p0, Lao1;->D:Lvta;

    .line 311
    .line 312
    return-void
.end method

.method public static final D(Lao1;Lif2;)V
    .locals 4

    .line 1
    instance-of v0, p1, Lmn1;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object v0, p1

    .line 6
    check-cast v0, Lmn1;

    .line 7
    .line 8
    iget v1, v0, Lmn1;->f:I

    .line 9
    .line 10
    const/high16 v2, -0x80000000

    .line 11
    .line 12
    and-int v3, v1, v2

    .line 13
    .line 14
    if-eqz v3, :cond_0

    .line 15
    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, Lmn1;->f:I

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, Lmn1;

    .line 21
    .line 22
    invoke-direct {v0, p0, p1}, Lmn1;-><init>(Lao1;Lif2;)V

    .line 23
    .line 24
    .line 25
    :goto_0
    iget-object p1, v0, Lmn1;->d:Ljava/lang/Object;

    .line 26
    .line 27
    iget v1, v0, Lmn1;->f:I

    .line 28
    .line 29
    const/4 v2, 0x1

    .line 30
    if-eqz v1, :cond_2

    .line 31
    .line 32
    if-eq v1, v2, :cond_1

    .line 33
    .line 34
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 35
    .line 36
    invoke-static {p0}, Lpm0;->e(Ljava/lang/String;)V

    .line 37
    .line 38
    .line 39
    return-void

    .line 40
    :cond_1
    invoke-static {p1}, Los8;->r(Ljava/lang/Object;)Lv52;

    .line 41
    .line 42
    .line 43
    move-result-object p0

    .line 44
    throw p0

    .line 45
    :cond_2
    invoke-static {p1}, Lwe5;->F(Ljava/lang/Object;)V

    .line 46
    .line 47
    .line 48
    iget-object p1, p0, Lao1;->x:Ljd1;

    .line 49
    .line 50
    iget-object p1, p1, Ljd1;->f:Leh7;

    .line 51
    .line 52
    new-instance v1, Lnm1;

    .line 53
    .line 54
    const/4 v3, 0x3

    .line 55
    invoke-direct {v1, p0, v3}, Lnm1;-><init>(Lao1;I)V

    .line 56
    .line 57
    .line 58
    iput v2, v0, Lmn1;->f:I

    .line 59
    .line 60
    iget-object p0, p1, Leh7;->a:Ldh8;

    .line 61
    .line 62
    invoke-virtual {p0, v1, v0}, Ldh8;->b(Lli3;Lhf2;)Ljava/lang/Object;

    .line 63
    .line 64
    .line 65
    return-void
.end method

.method public static final E(Lao1;Luy5;Lif2;)Ljava/lang/Object;
    .locals 4

    .line 1
    instance-of v0, p2, Lqn1;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object v0, p2

    .line 6
    check-cast v0, Lqn1;

    .line 7
    .line 8
    iget v1, v0, Lqn1;->f:I

    .line 9
    .line 10
    const/high16 v2, -0x80000000

    .line 11
    .line 12
    and-int v3, v1, v2

    .line 13
    .line 14
    if-eqz v3, :cond_0

    .line 15
    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, Lqn1;->f:I

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, Lqn1;

    .line 21
    .line 22
    invoke-direct {v0, p0, p2}, Lqn1;-><init>(Lao1;Lif2;)V

    .line 23
    .line 24
    .line 25
    :goto_0
    iget-object p2, v0, Lqn1;->d:Ljava/lang/Object;

    .line 26
    .line 27
    iget v1, v0, Lqn1;->f:I

    .line 28
    .line 29
    const/4 v2, 0x1

    .line 30
    if-eqz v1, :cond_2

    .line 31
    .line 32
    if-ne v1, v2, :cond_1

    .line 33
    .line 34
    invoke-static {p2}, Lwe5;->F(Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    goto :goto_1

    .line 38
    :cond_1
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 39
    .line 40
    invoke-static {p0}, Lpm0;->e(Ljava/lang/String;)V

    .line 41
    .line 42
    .line 43
    const/4 p0, 0x0

    .line 44
    return-object p0

    .line 45
    :cond_2
    invoke-static {p2}, Lwe5;->F(Ljava/lang/Object;)V

    .line 46
    .line 47
    .line 48
    iget-object p2, p0, Lao1;->o:Lz09;

    .line 49
    .line 50
    invoke-virtual {p2}, Lz09;->getValue()Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object p2

    .line 54
    check-cast p2, Lxp1;

    .line 55
    .line 56
    iput v2, v0, Lqn1;->f:I

    .line 57
    .line 58
    iget-object p2, p2, Lxp1;->a:Lnp1;

    .line 59
    .line 60
    invoke-virtual {p2, p1, v0}, Lnp1;->c(Luy5;Lif2;)Ljava/lang/Object;

    .line 61
    .line 62
    .line 63
    move-result-object p2

    .line 64
    sget-object p1, Ljg2;->a:Ljg2;

    .line 65
    .line 66
    if-ne p2, p1, :cond_3

    .line 67
    .line 68
    return-object p1

    .line 69
    :cond_3
    :goto_1
    check-cast p2, Ld21;

    .line 70
    .line 71
    if-eqz p2, :cond_4

    .line 72
    .line 73
    invoke-static {p0, p2}, Lao1;->T(Lao1;Ld21;)V

    .line 74
    .line 75
    .line 76
    :cond_4
    sget-object p0, Llp9;->a:Llp9;

    .line 77
    .line 78
    return-object p0
.end method

.method public static synthetic T(Lao1;Ld21;)V
    .locals 3

    .line 1
    new-instance v0, Lc11;

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    const/4 v2, 0x2

    .line 5
    invoke-direct {v0, v1, v2}, Lc11;-><init>(ZI)V

    .line 6
    .line 7
    .line 8
    invoke-virtual {p0, p1, v0}, Lao1;->S(Ld21;Lc11;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public static U(Lao1;Ljava/lang/String;Ln1;Ljava/lang/String;ZI)V
    .locals 16

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    and-int/lit8 v1, p5, 0x8

    .line 4
    .line 5
    const/4 v11, 0x0

    .line 6
    if-eqz v1, :cond_0

    .line 7
    .line 8
    move-object v3, v11

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    move-object/from16 v3, p3

    .line 11
    .line 12
    :goto_0
    and-int/lit8 v1, p5, 0x20

    .line 13
    .line 14
    if-eqz v1, :cond_1

    .line 15
    .line 16
    const/4 v9, 0x0

    .line 17
    goto :goto_1

    .line 18
    :cond_1
    move/from16 v9, p4

    .line 19
    .line 20
    :goto_1
    and-int/lit8 v1, p5, 0x40

    .line 21
    .line 22
    const/4 v10, 0x1

    .line 23
    if-eqz v1, :cond_2

    .line 24
    .line 25
    const/4 v8, 0x0

    .line 26
    goto :goto_2

    .line 27
    :cond_2
    move v8, v10

    .line 28
    :goto_2
    iget-object v13, v0, Lao1;->u:Lib1;

    .line 29
    .line 30
    new-instance v4, Lpr8;

    .line 31
    .line 32
    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    .line 33
    .line 34
    .line 35
    move-result-object v1

    .line 36
    invoke-virtual {v1}, Ljava/util/UUID;->toString()Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object v1

    .line 40
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 41
    .line 42
    .line 43
    move-result-wide v5

    .line 44
    invoke-direct {v4, v5, v6, v1}, Lpr8;-><init>(JLjava/lang/String;)V

    .line 45
    .line 46
    .line 47
    iget-object v1, v0, Lao1;->v:Lrs8;

    .line 48
    .line 49
    invoke-virtual {v1}, Lrs8;->getValue()Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    move-result-object v1

    .line 53
    check-cast v1, Lho1;

    .line 54
    .line 55
    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 56
    .line 57
    .line 58
    instance-of v2, v1, Lfo1;

    .line 59
    .line 60
    const/16 v14, 0xb

    .line 61
    .line 62
    if-eqz v2, :cond_3

    .line 63
    .line 64
    if-eqz v9, :cond_a

    .line 65
    .line 66
    new-instance v0, Lsi1;

    .line 67
    .line 68
    invoke-direct {v0, v14}, Lsi1;-><init>(I)V

    .line 69
    .line 70
    .line 71
    invoke-static {v13, v0}, Luia;->S(Lk55;Lsv3;)V

    .line 72
    .line 73
    .line 74
    return-void

    .line 75
    :cond_3
    invoke-interface {v1}, Lho1;->b()Lwr;

    .line 76
    .line 77
    .line 78
    move-result-object v5

    .line 79
    instance-of v6, v1, Lgo1;

    .line 80
    .line 81
    iget-object v15, v5, Lwr;->i:Lrs8;

    .line 82
    .line 83
    invoke-virtual {v15}, Lrs8;->getValue()Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    move-result-object v1

    .line 87
    sget-object v2, Lir;->a:Lir;

    .line 88
    .line 89
    invoke-static {v1, v2}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 90
    .line 91
    .line 92
    move-result v1

    .line 93
    invoke-virtual {v15}, Lrs8;->getValue()Ljava/lang/Object;

    .line 94
    .line 95
    .line 96
    move-result-object v2

    .line 97
    sget-object v7, Lir;->b:Lir;

    .line 98
    .line 99
    invoke-static {v2, v7}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 100
    .line 101
    .line 102
    move-result v2

    .line 103
    if-eqz v1, :cond_4

    .line 104
    .line 105
    move-object/from16 v1, p1

    .line 106
    .line 107
    move v7, v2

    .line 108
    move-object/from16 v2, p2

    .line 109
    .line 110
    invoke-static/range {v0 .. v8}, Lao1;->V(Lao1;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Lpr8;Lwr;ZZZ)V

    .line 111
    .line 112
    .line 113
    return-void

    .line 114
    :cond_4
    move-object v12, v7

    .line 115
    move v7, v2

    .line 116
    const-class v0, Ltk1;

    .line 117
    .line 118
    invoke-static {}, Ltga;->I()Lcj;

    .line 119
    .line 120
    .line 121
    move-result-object v1

    .line 122
    iget-object v1, v1, Lcj;->a:Ljava/lang/Object;

    .line 123
    .line 124
    check-cast v1, Lqra;

    .line 125
    .line 126
    iget-object v1, v1, Lqra;->e:Ljava/lang/Object;

    .line 127
    .line 128
    check-cast v1, Li08;

    .line 129
    .line 130
    sget-object v2, Lan7;->a:Lbn7;

    .line 131
    .line 132
    invoke-virtual {v2, v0}, Lbn7;->b(Ljava/lang/Class;)Lf15;

    .line 133
    .line 134
    .line 135
    move-result-object v0

    .line 136
    invoke-virtual {v1, v0, v11, v11}, Li08;->b(Lf15;Lev6;Lmf7;)Ljava/lang/Object;

    .line 137
    .line 138
    .line 139
    move-result-object v0

    .line 140
    check-cast v0, Ltk1;

    .line 141
    .line 142
    if-eqz v9, :cond_6

    .line 143
    .line 144
    invoke-virtual {v15}, Lrs8;->getValue()Ljava/lang/Object;

    .line 145
    .line 146
    .line 147
    move-result-object v1

    .line 148
    invoke-static {v1, v12}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 149
    .line 150
    .line 151
    move-result v1

    .line 152
    if-eqz v1, :cond_6

    .line 153
    .line 154
    invoke-virtual {v5}, Lwr;->y()Ljava/lang/Integer;

    .line 155
    .line 156
    .line 157
    move-result-object v1

    .line 158
    if-eqz v1, :cond_5

    .line 159
    .line 160
    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    .line 161
    .line 162
    .line 163
    move-result v1

    .line 164
    invoke-virtual {v5, v1}, Lwr;->l(I)Z

    .line 165
    .line 166
    .line 167
    move-result v1

    .line 168
    goto :goto_3

    .line 169
    :cond_5
    const/4 v1, 0x0

    .line 170
    :goto_3
    if-eqz v1, :cond_6

    .line 171
    .line 172
    move v1, v10

    .line 173
    goto :goto_4

    .line 174
    :cond_6
    const/4 v1, 0x0

    .line 175
    :goto_4
    invoke-virtual {v5}, Lwr;->m()Z

    .line 176
    .line 177
    .line 178
    move-result v2

    .line 179
    invoke-virtual {v0, v1, v2}, Ltk1;->b(ZZ)I

    .line 180
    .line 181
    .line 182
    move-result v0

    .line 183
    invoke-static {v0}, Los8;->E(I)I

    .line 184
    .line 185
    .line 186
    move-result v1

    .line 187
    const/4 v12, 0x3

    .line 188
    const/4 v2, 0x2

    .line 189
    if-eq v1, v2, :cond_8

    .line 190
    .line 191
    if-eq v1, v12, :cond_7

    .line 192
    .line 193
    goto :goto_5

    .line 194
    :cond_7
    new-instance v1, Lsi1;

    .line 195
    .line 196
    const/16 v9, 0xc

    .line 197
    .line 198
    invoke-direct {v1, v9}, Lsi1;-><init>(I)V

    .line 199
    .line 200
    .line 201
    invoke-static {v13, v1}, Luia;->S(Lk55;Lsv3;)V

    .line 202
    .line 203
    .line 204
    goto :goto_5

    .line 205
    :cond_8
    new-instance v1, Lsi1;

    .line 206
    .line 207
    invoke-direct {v1, v14}, Lsi1;-><init>(I)V

    .line 208
    .line 209
    .line 210
    invoke-static {v13, v1}, Luia;->S(Lk55;Lsv3;)V

    .line 211
    .line 212
    .line 213
    :goto_5
    invoke-static {v0}, Los8;->E(I)I

    .line 214
    .line 215
    .line 216
    move-result v0

    .line 217
    if-eqz v0, :cond_c

    .line 218
    .line 219
    if-eq v0, v10, :cond_b

    .line 220
    .line 221
    if-eq v0, v2, :cond_a

    .line 222
    .line 223
    if-ne v0, v12, :cond_9

    .line 224
    .line 225
    goto :goto_6

    .line 226
    :cond_9
    invoke-static {}, Ld42;->d()V

    .line 227
    .line 228
    .line 229
    :cond_a
    :goto_6
    return-void

    .line 230
    :cond_b
    move-object/from16 v0, p0

    .line 231
    .line 232
    move-object/from16 v1, p1

    .line 233
    .line 234
    move-object/from16 v2, p2

    .line 235
    .line 236
    invoke-static/range {v0 .. v8}, Lao1;->V(Lao1;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Lpr8;Lwr;ZZZ)V

    .line 237
    .line 238
    .line 239
    return-void

    .line 240
    :cond_c
    move-object/from16 v0, p0

    .line 241
    .line 242
    iget-object v13, v0, Lao1;->k:Lbs0;

    .line 243
    .line 244
    new-instance v0, Lyn1;

    .line 245
    .line 246
    const/4 v10, 0x0

    .line 247
    move-object/from16 v2, p0

    .line 248
    .line 249
    move-object v1, v5

    .line 250
    move v9, v8

    .line 251
    move-object v5, v3

    .line 252
    move v8, v7

    .line 253
    move-object/from16 v3, p1

    .line 254
    .line 255
    move v7, v6

    .line 256
    move-object v6, v4

    .line 257
    move-object/from16 v4, p2

    .line 258
    .line 259
    invoke-direct/range {v0 .. v10}, Lyn1;-><init>(Lwr;Lao1;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Lpr8;ZZZLhf2;)V

    .line 260
    .line 261
    .line 262
    const/4 v1, 0x0

    .line 263
    invoke-static {v13, v11, v1, v0, v12}, Lv9a;->P(Lig2;Lag2;ILwv3;I)Lwr8;

    .line 264
    .line 265
    .line 266
    return-void
.end method

.method public static final V(Lao1;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Lpr8;Lwr;ZZZ)V
    .locals 14

    .line 1
    iget-object v0, p0, Lao1;->c:Lis9;

    .line 2
    .line 3
    invoke-virtual {v0}, Lis9;->b()Z

    .line 4
    .line 5
    .line 6
    move-result v5

    .line 7
    invoke-virtual {v0}, Lis9;->a()Z

    .line 8
    .line 9
    .line 10
    move-result v6

    .line 11
    iget-object v0, p0, Lao1;->k:Lbs0;

    .line 12
    .line 13
    new-instance v1, Lnn1;

    .line 14
    .line 15
    const/4 v13, 0x0

    .line 16
    move-object v4, p0

    .line 17
    move-object v8, p1

    .line 18
    move-object/from16 v9, p2

    .line 19
    .line 20
    move-object/from16 v3, p3

    .line 21
    .line 22
    move-object/from16 v7, p4

    .line 23
    .line 24
    move-object/from16 v2, p5

    .line 25
    .line 26
    move/from16 v11, p6

    .line 27
    .line 28
    move/from16 v10, p7

    .line 29
    .line 30
    move/from16 v12, p8

    .line 31
    .line 32
    invoke-direct/range {v1 .. v13}, Lnn1;-><init>(Lwr;Ljava/lang/String;Lao1;ZZLpr8;Ljava/lang/String;Ljava/util/List;ZZZLhf2;)V

    .line 33
    .line 34
    .line 35
    const/4 p0, 0x3

    .line 36
    const/4 p1, 0x0

    .line 37
    const/4 v2, 0x0

    .line 38
    invoke-static {v0, v2, p1, v1, p0}, Lv9a;->P(Lig2;Lag2;ILwv3;I)Lwr8;

    .line 39
    .line 40
    .line 41
    return-void
.end method


# virtual methods
.method public final A()Lps8;
    .locals 0

    .line 1
    iget-object p0, p0, Lao1;->r:Lxg1;

    .line 2
    .line 3
    iget-object p0, p0, Lxg1;->c:Lrs8;

    .line 4
    .line 5
    return-object p0
.end method

.method public final B(Landroid/graphics/Bitmap;Lhf2;)Ljava/lang/Object;
    .locals 0

    .line 1
    iget-object p0, p0, Lao1;->q:Lib1;

    .line 2
    .line 3
    invoke-virtual {p0, p1, p2}, Lib1;->g(Landroid/graphics/Bitmap;Lhf2;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    return-object p0
.end method

.method public final C(Lzr1;)V
    .locals 15

    .line 1
    move-object/from16 v3, p1

    .line 2
    .line 3
    sget-object v0, Lqga;->f:Lqga;

    .line 4
    .line 5
    invoke-virtual {v3, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    const/4 v6, 0x0

    .line 10
    const/4 v7, 0x3

    .line 11
    const/4 v4, 0x0

    .line 12
    iget-object v12, p0, Lao1;->k:Lbs0;

    .line 13
    .line 14
    iget-object v1, p0, Lao1;->q:Lib1;

    .line 15
    .line 16
    if-eqz v0, :cond_0

    .line 17
    .line 18
    invoke-virtual {v1}, Lib1;->m()Landroid/net/Uri;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    if-eqz v0, :cond_8

    .line 23
    .line 24
    iget-object v1, p0, Lao1;->x:Ljd1;

    .line 25
    .line 26
    invoke-virtual {v1}, Ljd1;->a()Z

    .line 27
    .line 28
    .line 29
    move-result v1

    .line 30
    if-eqz v1, :cond_8

    .line 31
    .line 32
    new-instance v1, Lon1;

    .line 33
    .line 34
    const/4 v2, 0x1

    .line 35
    invoke-direct {v1, p0, v0, v4, v2}, Lon1;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lhf2;I)V

    .line 36
    .line 37
    .line 38
    invoke-static {v12, v4, v6, v1, v7}, Lv9a;->P(Lig2;Lag2;ILwv3;I)Lwr8;

    .line 39
    .line 40
    .line 41
    return-void

    .line 42
    :cond_0
    sget-object v0, Lbea;->g:Lbea;

    .line 43
    .line 44
    invoke-virtual {v3, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-nez v0, :cond_8

    .line 49
    .line 50
    sget-object v0, Luka;->h:Luka;

    .line 51
    .line 52
    invoke-virtual {v3, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 53
    .line 54
    .line 55
    move-result v0

    .line 56
    if-eqz v0, :cond_1

    .line 57
    .line 58
    invoke-virtual {v1}, Lib1;->o()V

    .line 59
    .line 60
    .line 61
    return-void

    .line 62
    :cond_1
    sget-object v0, Lgra;->g:Lgra;

    .line 63
    .line 64
    invoke-virtual {v3, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 65
    .line 66
    .line 67
    move-result v0

    .line 68
    if-eqz v0, :cond_2

    .line 69
    .line 70
    invoke-virtual {p0}, Lao1;->M()Lwr;

    .line 71
    .line 72
    .line 73
    move-result-object v0

    .line 74
    iget-object v0, v0, Lwr;->a:Ljava/lang/String;

    .line 75
    .line 76
    invoke-virtual {p0}, Lao1;->L()Lv56;

    .line 77
    .line 78
    .line 79
    move-result-object p0

    .line 80
    iget-object p0, p0, Lv56;->a:Ljava/lang/String;

    .line 81
    .line 82
    invoke-virtual {v1, v12, v0, p0}, Lib1;->r(Lig2;Ljava/lang/String;Ljava/lang/String;)V

    .line 83
    .line 84
    .line 85
    return-void

    .line 86
    :cond_2
    sget-object v0, Lmva;->t:Lmva;

    .line 87
    .line 88
    invoke-virtual {v3, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 89
    .line 90
    .line 91
    move-result v0

    .line 92
    if-eqz v0, :cond_3

    .line 93
    .line 94
    invoke-virtual {v1}, Lib1;->t()V

    .line 95
    .line 96
    .line 97
    return-void

    .line 98
    :cond_3
    sget-object v0, Ltya;->d:Ltya;

    .line 99
    .line 100
    invoke-virtual {v3, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 101
    .line 102
    .line 103
    move-result v0

    .line 104
    if-eqz v0, :cond_4

    .line 105
    .line 106
    invoke-virtual {v1}, Lib1;->c()V

    .line 107
    .line 108
    .line 109
    return-void

    .line 110
    :cond_4
    instance-of v0, v3, Lxr1;

    .line 111
    .line 112
    if-eqz v0, :cond_5

    .line 113
    .line 114
    move-object v0, v3

    .line 115
    check-cast v0, Lxr1;

    .line 116
    .line 117
    iget-object v0, v0, Lxr1;->b:Landroid/graphics/Bitmap;

    .line 118
    .line 119
    invoke-virtual {v1, v0}, Lib1;->n(Landroid/graphics/Bitmap;)Ljava/lang/String;

    .line 120
    .line 121
    .line 122
    move-result-object v2

    .line 123
    new-instance v0, Lre;

    .line 124
    .line 125
    const/4 v5, 0x6

    .line 126
    move-object v1, p0

    .line 127
    invoke-direct/range {v0 .. v5}, Lre;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lhf2;I)V

    .line 128
    .line 129
    .line 130
    invoke-static {v12, v4, v6, v0, v7}, Lv9a;->P(Lig2;Lag2;ILwv3;I)Lwr8;

    .line 131
    .line 132
    .line 133
    return-void

    .line 134
    :cond_5
    sget-object v2, Lhp0;->f:Lhp0;

    .line 135
    .line 136
    invoke-virtual {v3, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 137
    .line 138
    .line 139
    move-result v2

    .line 140
    if-eqz v2, :cond_6

    .line 141
    .line 142
    invoke-virtual {v1}, Lib1;->h()V

    .line 143
    .line 144
    .line 145
    return-void

    .line 146
    :cond_6
    instance-of v1, v3, Lyr1;

    .line 147
    .line 148
    if-eqz v1, :cond_7

    .line 149
    .line 150
    move-object v1, v3

    .line 151
    check-cast v1, Lyr1;

    .line 152
    .line 153
    iget-object v9, v1, Lyr1;->a:Landroid/net/Uri;

    .line 154
    .line 155
    iget-object v10, v1, Lyr1;->b:Ljava/lang/String;

    .line 156
    .line 157
    iget-object v11, v1, Lyr1;->c:Lqt3;

    .line 158
    .line 159
    invoke-virtual {p0}, Lao1;->M()Lwr;

    .line 160
    .line 161
    .line 162
    move-result-object v1

    .line 163
    iget-object v13, v1, Lwr;->a:Ljava/lang/String;

    .line 164
    .line 165
    invoke-virtual {p0}, Lao1;->L()Lv56;

    .line 166
    .line 167
    .line 168
    move-result-object v1

    .line 169
    iget-object v14, v1, Lv56;->a:Ljava/lang/String;

    .line 170
    .line 171
    iget-object v8, p0, Lao1;->q:Lib1;

    .line 172
    .line 173
    invoke-virtual/range {v8 .. v14}, Lib1;->s(Landroid/net/Uri;Ljava/lang/String;Lqt3;Lig2;Ljava/lang/String;Ljava/lang/String;)V

    .line 174
    .line 175
    .line 176
    return-void

    .line 177
    :cond_7
    invoke-static {}, Ld42;->d()V

    .line 178
    .line 179
    .line 180
    :cond_8
    return-void
.end method

.method public final F(Ljava/lang/String;)V
    .locals 8

    .line 1
    invoke-virtual {p0}, Lao1;->Q()Loc1;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Loc1;->j()Lhy5;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    instance-of v1, v0, Lfy5;

    .line 10
    .line 11
    if-eqz v1, :cond_0

    .line 12
    .line 13
    invoke-virtual {p0}, Lao1;->M()Lwr;

    .line 14
    .line 15
    .line 16
    move-result-object v3

    .line 17
    new-instance v2, Lre;

    .line 18
    .line 19
    move-object v4, v0

    .line 20
    check-cast v4, Lfy5;

    .line 21
    .line 22
    const/4 v7, 0x5

    .line 23
    const/4 v6, 0x0

    .line 24
    move-object v5, p1

    .line 25
    invoke-direct/range {v2 .. v7}, Lre;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lhf2;I)V

    .line 26
    .line 27
    .line 28
    const/4 p1, 0x3

    .line 29
    iget-object v0, p0, Lao1;->k:Lbs0;

    .line 30
    .line 31
    const/4 v1, 0x0

    .line 32
    invoke-static {v0, v6, v1, v2, p1}, Lv9a;->P(Lig2;Lag2;ILwv3;I)Lwr8;

    .line 33
    .line 34
    .line 35
    invoke-virtual {p0}, Lao1;->Q()Loc1;

    .line 36
    .line 37
    .line 38
    move-result-object p0

    .line 39
    invoke-virtual {p0, v1}, Loc1;->c(Z)V

    .line 40
    .line 41
    .line 42
    :cond_0
    return-void
.end method

.method public final G()V
    .locals 0

    .line 1
    iget-object p0, p0, Lao1;->j:Lxe1;

    .line 2
    .line 3
    invoke-virtual {p0}, Lxe1;->F()V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final H()V
    .locals 3

    .line 1
    iget-object v0, p0, Lao1;->o:Lz09;

    .line 2
    .line 3
    invoke-virtual {v0}, Lz09;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lxp1;

    .line 8
    .line 9
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    iget-object v0, p0, Lao1;->a:Lfg1;

    .line 13
    .line 14
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    new-instance v1, Lnf1;

    .line 18
    .line 19
    const-string v2, "session_closed"

    .line 20
    .line 21
    invoke-direct {v1, v2}, Lnf1;-><init>(Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    invoke-virtual {v0, v1}, Lfg1;->k(Lrf1;)V

    .line 25
    .line 26
    .line 27
    iget-object p0, p0, Lao1;->k:Lbs0;

    .line 28
    .line 29
    const/4 v0, 0x0

    .line 30
    invoke-static {p0, v0}, Lv9a;->x(Lig2;Ljava/util/concurrent/CancellationException;)V

    .line 31
    .line 32
    .line 33
    return-void
.end method

.method public final I(Lyp1;)V
    .locals 31

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    invoke-virtual/range {p1 .. p1}, Lyp1;->b()Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    invoke-virtual {v1}, Ljava/lang/String;->toString()Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    iget-object v2, v0, Lao1;->u:Lib1;

    .line 12
    .line 13
    invoke-virtual {v2, v1}, Lib1;->e(Ljava/lang/String;)Z

    .line 14
    .line 15
    .line 16
    move-result v1

    .line 17
    if-nez v1, :cond_0

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    iget-object v1, v0, Lao1;->v:Lrs8;

    .line 21
    .line 22
    invoke-virtual {v1}, Lrs8;->getValue()Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    check-cast v1, Lho1;

    .line 27
    .line 28
    instance-of v2, v1, Lfo1;

    .line 29
    .line 30
    if-eqz v2, :cond_1

    .line 31
    .line 32
    :goto_0
    return-void

    .line 33
    :cond_1
    invoke-interface {v1}, Lho1;->b()Lwr;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    iget-object v2, v1, Lwr;->a:Ljava/lang/String;

    .line 38
    .line 39
    invoke-static {v1}, Ltga;->F(Lwr;)I

    .line 40
    .line 41
    .line 42
    move-result v3

    .line 43
    move-object/from16 v13, p1

    .line 44
    .line 45
    iget-object v4, v13, Lyp1;->a:Lhp8;

    .line 46
    .line 47
    invoke-virtual {v4}, Lhp8;->i()Ln1;

    .line 48
    .line 49
    .line 50
    move-result-object v10

    .line 51
    invoke-virtual {v0}, Lao1;->Q()Loc1;

    .line 52
    .line 53
    .line 54
    move-result-object v4

    .line 55
    invoke-virtual {v4}, Loc1;->j()Lhy5;

    .line 56
    .line 57
    .line 58
    move-result-object v4

    .line 59
    invoke-interface {v4}, Lhy5;->a()Lvq;

    .line 60
    .line 61
    .line 62
    move-result-object v4

    .line 63
    const/4 v14, 0x0

    .line 64
    if-eqz v4, :cond_2

    .line 65
    .line 66
    const/4 v4, 0x1

    .line 67
    move v5, v4

    .line 68
    goto :goto_1

    .line 69
    :cond_2
    move v5, v14

    .line 70
    :goto_1
    iget-object v4, v0, Lao1;->c:Lis9;

    .line 71
    .line 72
    invoke-virtual {v4}, Lis9;->b()Z

    .line 73
    .line 74
    .line 75
    move-result v6

    .line 76
    invoke-virtual {v4}, Lis9;->a()Z

    .line 77
    .line 78
    .line 79
    move-result v7

    .line 80
    new-instance v8, Lpr8;

    .line 81
    .line 82
    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    .line 83
    .line 84
    .line 85
    move-result-object v4

    .line 86
    invoke-virtual {v4}, Ljava/util/UUID;->toString()Ljava/lang/String;

    .line 87
    .line 88
    .line 89
    move-result-object v4

    .line 90
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 91
    .line 92
    .line 93
    move-result-wide v11

    .line 94
    invoke-direct {v8, v11, v12, v4}, Lpr8;-><init>(JLjava/lang/String;)V

    .line 95
    .line 96
    .line 97
    invoke-virtual {v13}, Lyp1;->b()Ljava/lang/String;

    .line 98
    .line 99
    .line 100
    move-result-object v4

    .line 101
    invoke-virtual {v4}, Ljava/lang/String;->toString()Ljava/lang/String;

    .line 102
    .line 103
    .line 104
    move-result-object v9

    .line 105
    invoke-virtual {v1}, Lwr;->h()Ljava/lang/String;

    .line 106
    .line 107
    .line 108
    move-result-object v4

    .line 109
    if-nez v4, :cond_3

    .line 110
    .line 111
    invoke-virtual {v0}, Lao1;->N()Ljava/lang/String;

    .line 112
    .line 113
    .line 114
    move-result-object v4

    .line 115
    :cond_3
    move-object v11, v4

    .line 116
    iget-object v4, v1, Lwr;->i:Lrs8;

    .line 117
    .line 118
    invoke-virtual {v4}, Lrs8;->getValue()Ljava/lang/Object;

    .line 119
    .line 120
    .line 121
    move-result-object v4

    .line 122
    sget-object v12, Lir;->b:Lir;

    .line 123
    .line 124
    invoke-static {v4, v12}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 125
    .line 126
    .line 127
    move-result v12

    .line 128
    const/4 v4, 0x1

    .line 129
    invoke-static/range {v2 .. v12}, Ltya;->l(Ljava/lang/String;IZZZZLpr8;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Z)V

    .line 130
    .line 131
    .line 132
    move-object/from16 v20, v8

    .line 133
    .line 134
    invoke-virtual {v0}, Lao1;->L()Lv56;

    .line 135
    .line 136
    .line 137
    move-result-object v2

    .line 138
    iget-object v2, v2, Lv56;->a:Ljava/lang/String;

    .line 139
    .line 140
    new-instance v3, Ljava/util/ArrayList;

    .line 141
    .line 142
    invoke-virtual {v10}, Ll0;->a()I

    .line 143
    .line 144
    .line 145
    move-result v4

    .line 146
    invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(I)V

    .line 147
    .line 148
    .line 149
    invoke-virtual {v10}, Ll0;->a()I

    .line 150
    .line 151
    .line 152
    move-result v4

    .line 153
    move v5, v14

    .line 154
    :goto_2
    const/4 v6, 0x0

    .line 155
    if-ge v5, v4, :cond_7

    .line 156
    .line 157
    invoke-interface {v10, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 158
    .line 159
    .line 160
    move-result-object v7

    .line 161
    check-cast v7, Lz61;

    .line 162
    .line 163
    invoke-virtual {v7, v2}, Lz61;->k(Ljava/lang/String;)Lhr;

    .line 164
    .line 165
    .line 166
    move-result-object v21

    .line 167
    if-eqz v21, :cond_5

    .line 168
    .line 169
    iget-object v8, v7, Lz61;->e:Lc02;

    .line 170
    .line 171
    if-eqz v8, :cond_4

    .line 172
    .line 173
    iget-boolean v9, v7, Lz61;->l:Z

    .line 174
    .line 175
    if-eqz v9, :cond_4

    .line 176
    .line 177
    move-object/from16 v28, v8

    .line 178
    .line 179
    goto :goto_3

    .line 180
    :cond_4
    move-object/from16 v28, v6

    .line 181
    .line 182
    :goto_3
    new-instance v6, Lof3;

    .line 183
    .line 184
    iget-object v8, v7, Lz61;->n:Ljava/lang/Long;

    .line 185
    .line 186
    iget v7, v7, Lz61;->c:I

    .line 187
    .line 188
    invoke-static {v7}, Lrj2;->k(I)Ljava/lang/String;

    .line 189
    .line 190
    .line 191
    move-result-object v7

    .line 192
    invoke-direct {v6, v7, v8}, Lof3;-><init>(Ljava/lang/String;Ljava/lang/Long;)V

    .line 193
    .line 194
    .line 195
    const v30, 0xffff

    .line 196
    .line 197
    .line 198
    const/16 v22, 0x0

    .line 199
    .line 200
    const/16 v23, 0x0

    .line 201
    .line 202
    const/16 v24, 0x0

    .line 203
    .line 204
    const/16 v25, 0x0

    .line 205
    .line 206
    const/16 v26, 0x0

    .line 207
    .line 208
    const/16 v27, 0x0

    .line 209
    .line 210
    move-object/from16 v29, v6

    .line 211
    .line 212
    invoke-static/range {v21 .. v30}, Lhr;->a(Lhr;Lm31;ZZLjava/lang/Integer;Ljava/lang/Integer;Lkf3;Lc02;Lof3;I)Lhr;

    .line 213
    .line 214
    .line 215
    move-result-object v6

    .line 216
    :cond_5
    if-eqz v6, :cond_6

    .line 217
    .line 218
    invoke-virtual {v3, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 219
    .line 220
    .line 221
    :cond_6
    add-int/lit8 v5, v5, 0x1

    .line 222
    .line 223
    goto :goto_2

    .line 224
    :cond_7
    invoke-virtual {v10, v14}, Lc1;->listIterator(I)Ljava/util/ListIterator;

    .line 225
    .line 226
    .line 227
    move-result-object v4

    .line 228
    :cond_8
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 229
    .line 230
    .line 231
    move-result v5

    .line 232
    if-eqz v5, :cond_b

    .line 233
    .line 234
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 235
    .line 236
    .line 237
    move-result-object v5

    .line 238
    check-cast v5, Lz61;

    .line 239
    .line 240
    invoke-virtual {v5, v2}, Lz61;->g(Ljava/lang/String;)Lw61;

    .line 241
    .line 242
    .line 243
    move-result-object v7

    .line 244
    instance-of v8, v7, Lg61;

    .line 245
    .line 246
    if-eqz v8, :cond_9

    .line 247
    .line 248
    check-cast v7, Lg61;

    .line 249
    .line 250
    iget-object v5, v7, Lg61;->b:Ljava/lang/String;

    .line 251
    .line 252
    goto :goto_4

    .line 253
    :cond_9
    sget-object v8, Lf61;->a:Lf61;

    .line 254
    .line 255
    invoke-static {v7, v8}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 256
    .line 257
    .line 258
    move-result v7

    .line 259
    if-eqz v7, :cond_a

    .line 260
    .line 261
    iget-object v5, v5, Lz61;->j:Ljava/lang/String;

    .line 262
    .line 263
    goto :goto_4

    .line 264
    :cond_a
    move-object v5, v6

    .line 265
    :goto_4
    if-eqz v5, :cond_8

    .line 266
    .line 267
    move-object v6, v5

    .line 268
    :cond_b
    if-nez v6, :cond_c

    .line 269
    .line 270
    invoke-virtual {v1}, Lwr;->h()Ljava/lang/String;

    .line 271
    .line 272
    .line 273
    move-result-object v6

    .line 274
    if-nez v6, :cond_c

    .line 275
    .line 276
    invoke-virtual {v0}, Lao1;->N()Ljava/lang/String;

    .line 277
    .line 278
    .line 279
    move-result-object v6

    .line 280
    :cond_c
    move-object/from16 v18, v6

    .line 281
    .line 282
    new-instance v15, Luy5;

    .line 283
    .line 284
    invoke-virtual {v13}, Lyp1;->b()Ljava/lang/String;

    .line 285
    .line 286
    .line 287
    move-result-object v16

    .line 288
    move-object/from16 v19, v2

    .line 289
    .line 290
    move-object/from16 v17, v3

    .line 291
    .line 292
    invoke-direct/range {v15 .. v20}, Luy5;-><init>(Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Lpr8;)V

    .line 293
    .line 294
    .line 295
    new-instance v1, Lmm1;

    .line 296
    .line 297
    const/16 v2, 0x9

    .line 298
    .line 299
    invoke-direct {v1, v0, v2}, Lmm1;-><init>(Lao1;I)V

    .line 300
    .line 301
    .line 302
    iget-object v2, v0, Lao1;->h:Lxv3;

    .line 303
    .line 304
    invoke-interface {v2, v0, v15, v1}, Lxv3;->f(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 305
    .line 306
    .line 307
    return-void
.end method

.method public final J(Ljn1;)V
    .locals 38

    invoke-static/range {p0 .. p1}, Lcom/ds/dspatch/Exp;->captureVm(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v0, p1

    .line 4
    .line 5
    sget-object v2, Lwp1;->b:Lwp1;

    .line 6
    .line 7
    instance-of v3, v0, Lwm1;

    .line 8
    .line 9
    iget-object v4, v1, Lao1;->a:Lfg1;

    .line 10
    .line 11
    if-eqz v3, :cond_2

    .line 12
    .line 13
    move-object v3, v0

    .line 14
    check-cast v3, Lwm1;

    .line 15
    .line 16
    instance-of v5, v3, Lzm1;

    .line 17
    .line 18
    if-eqz v5, :cond_0

    .line 19
    .line 20
    const-string v3, "regenerate"

    .line 21
    .line 22
    goto :goto_0

    .line 23
    :cond_0
    instance-of v3, v3, Lcn1;

    .line 24
    .line 25
    if-eqz v3, :cond_1

    .line 26
    .line 27
    invoke-virtual {v1}, Lao1;->Q()Loc1;

    .line 28
    .line 29
    .line 30
    move-result-object v3

    .line 31
    invoke-virtual {v3}, Loc1;->j()Lhy5;

    .line 32
    .line 33
    .line 34
    move-result-object v3

    .line 35
    invoke-interface {v3}, Lhy5;->a()Lvq;

    .line 36
    .line 37
    .line 38
    move-result-object v3

    .line 39
    if-eqz v3, :cond_1

    .line 40
    .line 41
    const-string v3, "edit"

    .line 42
    .line 43
    goto :goto_0

    .line 44
    :cond_1
    const-string v3, "send"

    .line 45
    .line 46
    :goto_0
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 47
    .line 48
    .line 49
    new-instance v5, Lnf1;

    .line 50
    .line 51
    invoke-direct {v5, v3}, Lnf1;-><init>(Ljava/lang/String;)V

    .line 52
    .line 53
    .line 54
    invoke-virtual {v4, v5}, Lfg1;->k(Lrf1;)V

    .line 55
    .line 56
    .line 57
    :cond_2
    instance-of v3, v0, Lcn1;

    .line 58
    .line 59
    iget-object v5, v1, Lao1;->v:Lrs8;

    .line 60
    .line 61
    const-class v10, Ldo8;

    .line 62
    .line 63
    const-class v11, Landroid/content/Context;

    .line 64
    .line 65
    iget-object v13, v1, Lao1;->c:Lis9;

    .line 66
    .line 67
    iget-object v8, v1, Lao1;->u:Lib1;

    .line 68
    .line 69
    iget-object v15, v1, Lao1;->k:Lbs0;

    .line 70
    .line 71
    const/16 v18, 0x0

    .line 72
    .line 73
    if-eqz v3, :cond_d

    .line 74
    .line 75
    invoke-virtual {v1}, Lao1;->Q()Loc1;

    .line 76
    .line 77
    .line 78
    move-result-object v3

    .line 79
    invoke-virtual {v3}, Loc1;->j()Lhy5;

    .line 80
    .line 81
    .line 82
    move-result-object v3

    .line 83
    invoke-interface {v3}, Lhy5;->a()Lvq;

    .line 84
    .line 85
    .line 86
    move-result-object v3

    .line 87
    if-eqz v3, :cond_9

    .line 88
    .line 89
    check-cast v0, Lcn1;

    .line 90
    .line 91
    iget-object v0, v0, Lcn1;->b:Ljava/lang/String;

    .line 92
    .line 93
    invoke-virtual {v1}, Lao1;->M()Lwr;

    .line 94
    .line 95
    .line 96
    move-result-object v3

    .line 97
    invoke-static {v3}, Ltga;->Q(Lwr;)Z

    .line 98
    .line 99
    .line 100
    move-result v4

    .line 101
    iget-object v6, v3, Lwr;->i:Lrs8;

    .line 102
    .line 103
    if-eqz v4, :cond_3

    .line 104
    .line 105
    goto/16 :goto_1a

    .line 106
    .line 107
    :cond_3
    invoke-virtual {v8, v3}, Lib1;->f(Lwr;)Z

    .line 108
    .line 109
    .line 110
    move-result v4

    .line 111
    if-nez v4, :cond_4

    .line 112
    .line 113
    goto/16 :goto_1a

    .line 114
    .line 115
    :cond_4
    invoke-virtual {v1}, Lao1;->Q()Loc1;

    .line 116
    .line 117
    .line 118
    move-result-object v4

    .line 119
    invoke-virtual {v4}, Loc1;->l()Lyp1;

    .line 120
    .line 121
    .line 122
    move-result-object v4

    .line 123
    invoke-virtual {v1}, Lao1;->Q()Loc1;

    .line 124
    .line 125
    .line 126
    move-result-object v7

    .line 127
    invoke-virtual {v7}, Loc1;->j()Lhy5;

    .line 128
    .line 129
    .line 130
    move-result-object v7

    .line 131
    instance-of v9, v7, Lfy5;

    .line 132
    .line 133
    if-nez v9, :cond_5

    .line 134
    .line 135
    goto/16 :goto_1a

    .line 136
    .line 137
    :cond_5
    check-cast v7, Lfy5;

    .line 138
    .line 139
    iget-object v9, v7, Lfy5;->a:Lvq;

    .line 140
    .line 141
    iget-object v7, v7, Lfy5;->b:Ljava/lang/String;

    .line 142
    .line 143
    if-nez v0, :cond_6

    .line 144
    .line 145
    invoke-virtual {v4}, Lyp1;->b()Ljava/lang/String;

    .line 146
    .line 147
    .line 148
    move-result-object v0

    .line 149
    :cond_6
    invoke-virtual {v8, v0}, Lib1;->e(Ljava/lang/String;)Z

    .line 150
    .line 151
    .line 152
    move-result v8

    .line 153
    if-nez v8, :cond_7

    .line 154
    .line 155
    goto/16 :goto_1a

    .line 156
    .line 157
    :cond_7
    iget-object v8, v4, Lyp1;->a:Lhp8;

    .line 158
    .line 159
    invoke-virtual {v8}, Lhp8;->i()Ln1;

    .line 160
    .line 161
    .line 162
    move-result-object v16

    .line 163
    invoke-virtual {v5}, Lrs8;->getValue()Ljava/lang/Object;

    .line 164
    .line 165
    .line 166
    move-result-object v5

    .line 167
    check-cast v5, Lho1;

    .line 168
    .line 169
    invoke-virtual {v6}, Lrs8;->getValue()Ljava/lang/Object;

    .line 170
    .line 171
    .line 172
    move-result-object v8

    .line 173
    check-cast v8, Lkr;

    .line 174
    .line 175
    iget-object v12, v3, Lwr;->j:Lrs8;

    .line 176
    .line 177
    invoke-virtual {v12}, Lrs8;->getValue()Ljava/lang/Object;

    .line 178
    .line 179
    .line 180
    move-result-object v12

    .line 181
    check-cast v12, Lor;

    .line 182
    .line 183
    iget-object v14, v3, Lwr;->k:Lrs8;

    .line 184
    .line 185
    invoke-virtual {v14}, Lrs8;->getValue()Ljava/lang/Object;

    .line 186
    .line 187
    .line 188
    move-result-object v14

    .line 189
    check-cast v14, Lsr;

    .line 190
    .line 191
    move-object/from16 v17, v3

    .line 192
    .line 193
    move-object v3, v5

    .line 194
    move-object v5, v4

    .line 195
    move-object v4, v8

    .line 196
    iget-object v8, v1, Lao1;->c:Lis9;

    .line 197
    .line 198
    move-object/from16 v19, v9

    .line 199
    .line 200
    invoke-virtual {v1}, Lao1;->L()Lv56;

    .line 201
    .line 202
    .line 203
    move-result-object v9

    .line 204
    move-object/from16 v37, v14

    .line 205
    .line 206
    move-object v14, v6

    .line 207
    move-object v6, v12

    .line 208
    move-object/from16 v12, v18

    .line 209
    .line 210
    move-object/from16 v18, v7

    .line 211
    .line 212
    move-object/from16 v7, v37

    .line 213
    .line 214
    invoke-virtual/range {v2 .. v9}, Lwp1;->c(Lho1;Lkr;Lyp1;Lor;Lsr;Lis9;Lv56;)Lrp1;

    .line 215
    .line 216
    .line 217
    move-result-object v2

    .line 218
    instance-of v3, v2, Lqp1;

    .line 219
    .line 220
    if-eqz v3, :cond_8

    .line 221
    .line 222
    check-cast v2, Lqp1;

    .line 223
    .line 224
    iget-object v0, v2, Lqp1;->c:Lpp1;

    .line 225
    .line 226
    if-eqz v0, :cond_5a

    .line 227
    .line 228
    invoke-static {}, Ltga;->I()Lcj;

    .line 229
    .line 230
    .line 231
    move-result-object v1

    .line 232
    iget-object v1, v1, Lcj;->a:Ljava/lang/Object;

    .line 233
    .line 234
    check-cast v1, Lqra;

    .line 235
    .line 236
    iget-object v1, v1, Lqra;->e:Ljava/lang/Object;

    .line 237
    .line 238
    check-cast v1, Li08;

    .line 239
    .line 240
    sget-object v2, Lan7;->a:Lbn7;

    .line 241
    .line 242
    invoke-virtual {v2, v11}, Lbn7;->b(Ljava/lang/Class;)Lf15;

    .line 243
    .line 244
    .line 245
    move-result-object v2

    .line 246
    invoke-virtual {v1, v2, v12, v12}, Li08;->b(Lf15;Lev6;Lmf7;)Ljava/lang/Object;

    .line 247
    .line 248
    .line 249
    move-result-object v1

    .line 250
    check-cast v1, Landroid/content/Context;

    .line 251
    .line 252
    invoke-static {}, Ltga;->I()Lcj;

    .line 253
    .line 254
    .line 255
    move-result-object v2

    .line 256
    iget-object v2, v2, Lcj;->a:Ljava/lang/Object;

    .line 257
    .line 258
    check-cast v2, Lqra;

    .line 259
    .line 260
    iget-object v2, v2, Lqra;->e:Ljava/lang/Object;

    .line 261
    .line 262
    check-cast v2, Li08;

    .line 263
    .line 264
    sget-object v3, Lan7;->a:Lbn7;

    .line 265
    .line 266
    invoke-virtual {v3, v10}, Lbn7;->b(Ljava/lang/Class;)Lf15;

    .line 267
    .line 268
    .line 269
    move-result-object v3

    .line 270
    invoke-virtual {v2, v3, v12, v12}, Li08;->b(Lf15;Lev6;Lmf7;)Ljava/lang/Object;

    .line 271
    .line 272
    .line 273
    move-result-object v2

    .line 274
    check-cast v2, Ldo8;

    .line 275
    .line 276
    invoke-virtual {v0, v1, v2}, Lpp1;->a(Landroid/content/Context;Ldo8;)V

    .line 277
    .line 278
    .line 279
    return-void

    .line 280
    :cond_8
    invoke-virtual {v13}, Lis9;->b()Z

    .line 281
    .line 282
    .line 283
    move-result v6

    .line 284
    invoke-virtual {v13}, Lis9;->a()Z

    .line 285
    .line 286
    .line 287
    move-result v7

    .line 288
    new-instance v8, Lpr8;

    .line 289
    .line 290
    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    .line 291
    .line 292
    .line 293
    move-result-object v2

    .line 294
    invoke-virtual {v2}, Ljava/util/UUID;->toString()Ljava/lang/String;

    .line 295
    .line 296
    .line 297
    move-result-object v2

    .line 298
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 299
    .line 300
    .line 301
    move-result-wide v3

    .line 302
    invoke-direct {v8, v3, v4, v2}, Lpr8;-><init>(JLjava/lang/String;)V

    .line 303
    .line 304
    .line 305
    invoke-virtual {v14}, Lrs8;->getValue()Ljava/lang/Object;

    .line 306
    .line 307
    .line 308
    move-result-object v2

    .line 309
    sget-object v3, Lir;->b:Lir;

    .line 310
    .line 311
    invoke-static {v2, v3}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 312
    .line 313
    .line 314
    move-result v10

    .line 315
    move-object v4, v0

    .line 316
    new-instance v0, Lvn1;

    .line 317
    .line 318
    const/4 v11, 0x0

    .line 319
    move-object v5, v1

    .line 320
    move-object/from16 v9, v16

    .line 321
    .line 322
    move-object/from16 v1, v17

    .line 323
    .line 324
    move-object/from16 v3, v18

    .line 325
    .line 326
    move-object/from16 v2, v19

    .line 327
    .line 328
    invoke-direct/range {v0 .. v11}, Lvn1;-><init>(Lwr;Lvq;Ljava/lang/String;Ljava/lang/String;Lao1;ZZLpr8;Ljava/util/List;ZLhf2;)V

    .line 329
    .line 330
    .line 331
    move-object v1, v9

    .line 332
    const/4 v10, 0x3

    .line 333
    const/4 v11, 0x0

    .line 334
    invoke-static {v15, v12, v11, v0, v10}, Lv9a;->P(Lig2;Lag2;ILwv3;I)Lwr8;

    .line 335
    .line 336
    .line 337
    new-instance v0, Lxn1;

    .line 338
    .line 339
    const/4 v9, 0x0

    .line 340
    move v2, v7

    .line 341
    move v7, v6

    .line 342
    move-object v6, v8

    .line 343
    move v8, v2

    .line 344
    move-object/from16 v2, p0

    .line 345
    .line 346
    move-object v5, v4

    .line 347
    move-object/from16 v3, v17

    .line 348
    .line 349
    move-object/from16 v4, v19

    .line 350
    .line 351
    invoke-direct/range {v0 .. v9}, Lxn1;-><init>(Ljava/util/List;Lao1;Lwr;Lvq;Ljava/lang/String;Lpr8;ZZLhf2;)V

    .line 352
    .line 353
    .line 354
    invoke-static {v15, v12, v11, v0, v10}, Lv9a;->P(Lig2;Lag2;ILwv3;I)Lwr8;

    .line 355
    .line 356
    .line 357
    return-void

    .line 358
    :cond_9
    check-cast v0, Lcn1;

    .line 359
    .line 360
    iget-boolean v4, v0, Lcn1;->a:Z

    .line 361
    .line 362
    iget-object v0, v0, Lcn1;->b:Ljava/lang/String;

    .line 363
    .line 364
    invoke-virtual/range {p0 .. p0}, Lao1;->Q()Loc1;

    .line 365
    .line 366
    .line 367
    move-result-object v1

    .line 368
    invoke-virtual {v1}, Loc1;->l()Lyp1;

    .line 369
    .line 370
    .line 371
    move-result-object v1

    .line 372
    if-nez v0, :cond_a

    .line 373
    .line 374
    invoke-virtual {v1}, Lyp1;->b()Ljava/lang/String;

    .line 375
    .line 376
    .line 377
    move-result-object v0

    .line 378
    invoke-virtual {v0}, Ljava/lang/String;->toString()Ljava/lang/String;

    .line 379
    .line 380
    .line 381
    move-result-object v0

    .line 382
    :cond_a
    invoke-virtual {v8, v0}, Lib1;->e(Ljava/lang/String;)Z

    .line 383
    .line 384
    .line 385
    move-result v2

    .line 386
    if-nez v2, :cond_b

    .line 387
    .line 388
    goto/16 :goto_1a

    .line 389
    .line 390
    :cond_b
    iget-object v1, v1, Lyp1;->a:Lhp8;

    .line 391
    .line 392
    invoke-virtual {v1}, Lhp8;->i()Ln1;

    .line 393
    .line 394
    .line 395
    move-result-object v2

    .line 396
    invoke-virtual/range {p0 .. p0}, Lao1;->M()Lwr;

    .line 397
    .line 398
    .line 399
    move-result-object v1

    .line 400
    invoke-virtual {v8, v1}, Lib1;->d(Lwr;)Z

    .line 401
    .line 402
    .line 403
    move-result v1

    .line 404
    if-nez v1, :cond_c

    .line 405
    .line 406
    goto/16 :goto_1a

    .line 407
    .line 408
    :cond_c
    const/4 v3, 0x0

    .line 409
    const/16 v5, 0x4c

    .line 410
    .line 411
    move-object v1, v0

    .line 412
    move-object/from16 v0, p0

    .line 413
    .line 414
    invoke-static/range {v0 .. v5}, Lao1;->U(Lao1;Ljava/lang/String;Ln1;Ljava/lang/String;ZI)V

    .line 415
    .line 416
    .line 417
    return-void

    .line 418
    :cond_d
    move-object v9, v1

    .line 419
    move-object/from16 v12, v18

    .line 420
    .line 421
    instance-of v1, v0, Lfn1;

    .line 422
    .line 423
    const-string v14, ""

    .line 424
    .line 425
    if-eqz v1, :cond_1a

    .line 426
    .line 427
    check-cast v0, Lfn1;

    .line 428
    .line 429
    iget-object v13, v0, Lfn1;->a:Ljava/lang/String;

    .line 430
    .line 431
    iget-object v15, v0, Lfn1;->b:Ljava/lang/String;

    .line 432
    .line 433
    invoke-virtual {v9}, Lao1;->Q()Loc1;

    .line 434
    .line 435
    .line 436
    move-result-object v0

    .line 437
    invoke-virtual {v0}, Loc1;->l()Lyp1;

    .line 438
    .line 439
    .line 440
    move-result-object v3

    .line 441
    iget-object v0, v3, Lyp1;->a:Lhp8;

    .line 442
    .line 443
    invoke-virtual {v0}, Lhp8;->i()Ln1;

    .line 444
    .line 445
    .line 446
    move-result-object v16

    .line 447
    invoke-virtual {v13}, Ljava/lang/String;->length()I

    .line 448
    .line 449
    .line 450
    move-result v0

    .line 451
    if-nez v0, :cond_e

    .line 452
    .line 453
    invoke-virtual/range {v16 .. v16}, Ll0;->isEmpty()Z

    .line 454
    .line 455
    .line 456
    move-result v0

    .line 457
    if-eqz v0, :cond_e

    .line 458
    .line 459
    goto/16 :goto_1a

    .line 460
    .line 461
    :cond_e
    invoke-virtual {v8, v13}, Lib1;->e(Ljava/lang/String;)Z

    .line 462
    .line 463
    .line 464
    move-result v0

    .line 465
    if-nez v0, :cond_f

    .line 466
    .line 467
    goto/16 :goto_1a

    .line 468
    .line 469
    :cond_f
    invoke-virtual {v9}, Lao1;->M()Lwr;

    .line 470
    .line 471
    .line 472
    move-result-object v0

    .line 473
    invoke-virtual {v5}, Lrs8;->getValue()Ljava/lang/Object;

    .line 474
    .line 475
    .line 476
    move-result-object v1

    .line 477
    check-cast v1, Lho1;

    .line 478
    .line 479
    iget-object v4, v0, Lwr;->i:Lrs8;

    .line 480
    .line 481
    invoke-virtual {v4}, Lrs8;->getValue()Ljava/lang/Object;

    .line 482
    .line 483
    .line 484
    move-result-object v4

    .line 485
    check-cast v4, Lkr;

    .line 486
    .line 487
    iget-object v5, v0, Lwr;->j:Lrs8;

    .line 488
    .line 489
    invoke-virtual {v5}, Lrs8;->getValue()Ljava/lang/Object;

    .line 490
    .line 491
    .line 492
    move-result-object v5

    .line 493
    check-cast v5, Lor;

    .line 494
    .line 495
    iget-object v6, v0, Lwr;->k:Lrs8;

    .line 496
    .line 497
    invoke-virtual {v6}, Lrs8;->getValue()Ljava/lang/Object;

    .line 498
    .line 499
    .line 500
    move-result-object v6

    .line 501
    check-cast v6, Lsr;

    .line 502
    .line 503
    move-object v7, v0

    .line 504
    move-object v0, v2

    .line 505
    move-object v2, v4

    .line 506
    move-object v4, v5

    .line 507
    move-object v5, v6

    .line 508
    iget-object v6, v9, Lao1;->c:Lis9;

    .line 509
    .line 510
    move-object/from16 v17, v7

    .line 511
    .line 512
    invoke-virtual {v9}, Lao1;->L()Lv56;

    .line 513
    .line 514
    .line 515
    move-result-object v7

    .line 516
    move-object/from16 v35, v17

    .line 517
    .line 518
    invoke-virtual/range {v0 .. v7}, Lwp1;->c(Lho1;Lkr;Lyp1;Lor;Lsr;Lis9;Lv56;)Lrp1;

    .line 519
    .line 520
    .line 521
    move-result-object v0

    .line 522
    sget-object v1, Lgra;->f:Lgra;

    .line 523
    .line 524
    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 525
    .line 526
    .line 527
    move-result v1

    .line 528
    if-eqz v1, :cond_10

    .line 529
    .line 530
    const/4 v4, 0x0

    .line 531
    const/16 v5, 0x24

    .line 532
    .line 533
    move-object v0, v9

    .line 534
    move-object v1, v13

    .line 535
    move-object v3, v15

    .line 536
    move-object/from16 v2, v16

    .line 537
    .line 538
    invoke-static/range {v0 .. v5}, Lao1;->U(Lao1;Ljava/lang/String;Ln1;Ljava/lang/String;ZI)V

    .line 539
    .line 540
    .line 541
    move-object v1, v0

    .line 542
    invoke-virtual {v1}, Lao1;->t()V

    .line 543
    .line 544
    .line 545
    return-void

    .line 546
    :cond_10
    move-object v1, v9

    .line 547
    move-object v2, v13

    .line 548
    move-object/from16 v27, v15

    .line 549
    .line 550
    sget-object v4, Lmva;->s:Lmva;

    .line 551
    .line 552
    invoke-virtual {v0, v4}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 553
    .line 554
    .line 555
    move-result v4

    .line 556
    if-eqz v4, :cond_11

    .line 557
    .line 558
    new-instance v0, Lbl2;

    .line 559
    .line 560
    invoke-direct {v0, v2, v12}, Lbl2;-><init>(Ljava/lang/String;Ljo4;)V

    .line 561
    .line 562
    .line 563
    invoke-static {v3, v0}, Lyp1;->a(Lyp1;Lbl2;)Lyp1;

    .line 564
    .line 565
    .line 566
    move-result-object v0

    .line 567
    invoke-virtual {v1, v0}, Lao1;->I(Lyp1;)V

    .line 568
    .line 569
    .line 570
    return-void

    .line 571
    :cond_11
    instance-of v3, v0, Lqp1;

    .line 572
    .line 573
    if-eqz v3, :cond_19

    .line 574
    .line 575
    check-cast v0, Lqp1;

    .line 576
    .line 577
    iget-object v3, v0, Lqp1;->b:Lsr;

    .line 578
    .line 579
    if-eqz v3, :cond_12

    .line 580
    .line 581
    move-object/from16 v7, v35

    .line 582
    .line 583
    invoke-virtual {v8, v7}, Lib1;->d(Lwr;)Z

    .line 584
    .line 585
    .line 586
    const-string v0, "MessageListNotLoaded"

    .line 587
    .line 588
    :goto_1
    move-object/from16 v31, v0

    .line 589
    .line 590
    goto :goto_3

    .line 591
    :cond_12
    move-object/from16 v7, v35

    .line 592
    .line 593
    iget-object v3, v0, Lqp1;->c:Lpp1;

    .line 594
    .line 595
    if-eqz v3, :cond_13

    .line 596
    .line 597
    invoke-static {}, Ltga;->I()Lcj;

    .line 598
    .line 599
    .line 600
    move-result-object v0

    .line 601
    iget-object v0, v0, Lcj;->a:Ljava/lang/Object;

    .line 602
    .line 603
    check-cast v0, Lqra;

    .line 604
    .line 605
    iget-object v0, v0, Lqra;->e:Ljava/lang/Object;

    .line 606
    .line 607
    check-cast v0, Li08;

    .line 608
    .line 609
    sget-object v4, Lan7;->a:Lbn7;

    .line 610
    .line 611
    invoke-virtual {v4, v11}, Lbn7;->b(Ljava/lang/Class;)Lf15;

    .line 612
    .line 613
    .line 614
    move-result-object v4

    .line 615
    invoke-virtual {v0, v4, v12, v12}, Li08;->b(Lf15;Lev6;Lmf7;)Ljava/lang/Object;

    .line 616
    .line 617
    .line 618
    move-result-object v0

    .line 619
    check-cast v0, Landroid/content/Context;

    .line 620
    .line 621
    invoke-static {}, Ltga;->I()Lcj;

    .line 622
    .line 623
    .line 624
    move-result-object v4

    .line 625
    iget-object v4, v4, Lcj;->a:Ljava/lang/Object;

    .line 626
    .line 627
    check-cast v4, Lqra;

    .line 628
    .line 629
    iget-object v4, v4, Lqra;->e:Ljava/lang/Object;

    .line 630
    .line 631
    check-cast v4, Li08;

    .line 632
    .line 633
    sget-object v5, Lan7;->a:Lbn7;

    .line 634
    .line 635
    invoke-virtual {v5, v10}, Lbn7;->b(Ljava/lang/Class;)Lf15;

    .line 636
    .line 637
    .line 638
    move-result-object v5

    .line 639
    invoke-virtual {v4, v5, v12, v12}, Li08;->b(Lf15;Lev6;Lmf7;)Ljava/lang/Object;

    .line 640
    .line 641
    .line 642
    move-result-object v4

    .line 643
    check-cast v4, Ldo8;

    .line 644
    .line 645
    invoke-virtual {v3, v0, v4}, Lpp1;->a(Landroid/content/Context;Ldo8;)V

    .line 646
    .line 647
    .line 648
    const-string v0, "FileInvalid"

    .line 649
    .line 650
    goto :goto_1

    .line 651
    :cond_13
    iget-object v0, v0, Lqp1;->a:Lho1;

    .line 652
    .line 653
    instance-of v0, v0, Lfo1;

    .line 654
    .line 655
    if-eqz v0, :cond_14

    .line 656
    .line 657
    const-string v0, "SessionNotCreated"

    .line 658
    .line 659
    goto :goto_2

    .line 660
    :cond_14
    const-string v0, "InvalidSessionState"

    .line 661
    .line 662
    :goto_2
    new-instance v3, Lsi1;

    .line 663
    .line 664
    const/16 v4, 0x13

    .line 665
    .line 666
    invoke-direct {v3, v4}, Lsi1;-><init>(I)V

    .line 667
    .line 668
    .line 669
    const/4 v10, 0x3

    .line 670
    invoke-static {v10, v3, v1, v12}, Luia;->R(ILsv3;Lk55;Ljava/lang/String;)V

    .line 671
    .line 672
    .line 673
    goto :goto_1

    .line 674
    :goto_3
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 675
    .line 676
    .line 677
    move-result v0

    .line 678
    if-lez v0, :cond_15

    .line 679
    .line 680
    invoke-virtual {v1}, Lao1;->Q()Loc1;

    .line 681
    .line 682
    .line 683
    move-result-object v0

    .line 684
    invoke-virtual {v0, v2}, Loc1;->t(Ljava/lang/String;)V

    .line 685
    .line 686
    .line 687
    :cond_15
    iget-object v0, v1, Lao1;->j:Lxe1;

    .line 688
    .line 689
    iget-object v3, v0, Lxe1;->j:Lld1;

    .line 690
    .line 691
    if-eqz v3, :cond_18

    .line 692
    .line 693
    iget-object v4, v3, Lld1;->c:Ljava/lang/Long;

    .line 694
    .line 695
    if-eqz v4, :cond_18

    .line 696
    .line 697
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 698
    .line 699
    .line 700
    move-result-wide v5

    .line 701
    invoke-virtual {v4}, Ljava/lang/Long;->longValue()J

    .line 702
    .line 703
    .line 704
    move-result-wide v8

    .line 705
    sub-long/2addr v5, v8

    .line 706
    invoke-virtual {v0}, Lxe1;->G()Lnd1;

    .line 707
    .line 708
    .line 709
    move-result-object v0

    .line 710
    iget-object v4, v7, Lwr;->a:Ljava/lang/String;

    .line 711
    .line 712
    iget-object v3, v3, Lld1;->b:Ljava/lang/String;

    .line 713
    .line 714
    invoke-virtual {v1}, Lao1;->Q()Loc1;

    .line 715
    .line 716
    .line 717
    move-result-object v7

    .line 718
    invoke-virtual {v7}, Loc1;->k()I

    .line 719
    .line 720
    .line 721
    move-result v7

    .line 722
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 723
    .line 724
    .line 725
    move-result v2

    .line 726
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 727
    .line 728
    .line 729
    move-result-object v28

    .line 730
    if-nez v4, :cond_16

    .line 731
    .line 732
    move-object/from16 v23, v14

    .line 733
    .line 734
    goto :goto_4

    .line 735
    :cond_16
    move-object/from16 v23, v4

    .line 736
    .line 737
    :goto_4
    invoke-static {v7}, Llx0;->P(I)Z

    .line 738
    .line 739
    .line 740
    move-result v2

    .line 741
    if-eqz v2, :cond_17

    .line 742
    .line 743
    const-string v2, "voice"

    .line 744
    .line 745
    :goto_5
    move-object/from16 v25, v2

    .line 746
    .line 747
    goto :goto_6

    .line 748
    :cond_17
    const-string v2, "text"

    .line 749
    .line 750
    goto :goto_5

    .line 751
    :goto_6
    long-to-int v2, v5

    .line 752
    iget v4, v0, Lnd1;->a:I

    .line 753
    .line 754
    iget v5, v0, Lnd1;->b:I

    .line 755
    .line 756
    iget v0, v0, Lnd1;->c:I

    .line 757
    .line 758
    const/16 v29, 0x0

    .line 759
    .line 760
    const/16 v30, 0x0

    .line 761
    .line 762
    move/from16 v34, v0

    .line 763
    .line 764
    move/from16 v26, v2

    .line 765
    .line 766
    move-object/from16 v24, v3

    .line 767
    .line 768
    move/from16 v32, v4

    .line 769
    .line 770
    move/from16 v33, v5

    .line 771
    .line 772
    invoke-static/range {v23 .. v34}, Lmva;->c0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;III)V

    .line 773
    .line 774
    .line 775
    :cond_18
    invoke-virtual {v1}, Lao1;->G()V

    .line 776
    .line 777
    .line 778
    invoke-virtual {v1}, Lao1;->W()V

    .line 779
    .line 780
    .line 781
    return-void

    .line 782
    :cond_19
    invoke-static {}, Ld42;->d()V

    .line 783
    .line 784
    .line 785
    return-void

    .line 786
    :cond_1a
    move-object v1, v9

    .line 787
    instance-of v2, v0, Ldn1;

    .line 788
    .line 789
    if-eqz v2, :cond_1b

    .line 790
    .line 791
    new-instance v2, Lhz0;

    .line 792
    .line 793
    const/16 v3, 0x1d

    .line 794
    .line 795
    invoke-direct {v2, v1, v0, v12, v3}, Lhz0;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lhf2;I)V

    .line 796
    .line 797
    .line 798
    const/4 v10, 0x3

    .line 799
    const/4 v11, 0x0

    .line 800
    invoke-static {v15, v12, v11, v2, v10}, Lv9a;->P(Lig2;Lag2;ILwv3;I)Lwr8;

    .line 801
    .line 802
    .line 803
    return-void

    .line 804
    :cond_1b
    instance-of v2, v0, Lbn1;

    .line 805
    .line 806
    const/4 v3, 0x2

    .line 807
    const-string v5, "sse_transaction_uuid"

    .line 808
    .line 809
    const-string v6, ":"

    .line 810
    .line 811
    const-string v7, "full_chat_message_id"

    .line 812
    .line 813
    const-string v9, "chat_message_id"

    .line 814
    .line 815
    const-string v10, "chat_session_id"

    .line 816
    .line 817
    if-eqz v2, :cond_21

    .line 818
    .line 819
    check-cast v0, Lbn1;

    .line 820
    .line 821
    iget-object v0, v0, Lbn1;->a:Lnx;

    .line 822
    .line 823
    invoke-virtual {v1}, Lao1;->M()Lwr;

    .line 824
    .line 825
    .line 826
    move-result-object v2

    .line 827
    invoke-static {v2}, Ltga;->Q(Lwr;)Z

    .line 828
    .line 829
    .line 830
    move-result v4

    .line 831
    if-eqz v4, :cond_1c

    .line 832
    .line 833
    goto/16 :goto_1a

    .line 834
    .line 835
    :cond_1c
    invoke-virtual {v8, v2}, Lib1;->f(Lwr;)Z

    .line 836
    .line 837
    .line 838
    move-result v4

    .line 839
    if-nez v4, :cond_1d

    .line 840
    .line 841
    goto/16 :goto_1a

    .line 842
    .line 843
    :cond_1d
    iget-object v4, v0, Lnx;->A:Lxu;

    .line 844
    .line 845
    instance-of v4, v4, Lwu;

    .line 846
    .line 847
    if-eqz v4, :cond_1e

    .line 848
    .line 849
    new-instance v2, Lon1;

    .line 850
    .line 851
    invoke-direct {v2, v1, v0, v12, v3}, Lon1;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lhf2;I)V

    .line 852
    .line 853
    .line 854
    const/4 v10, 0x3

    .line 855
    const/4 v11, 0x0

    .line 856
    invoke-static {v15, v12, v11, v2, v10}, Lv9a;->P(Lig2;Lag2;ILwv3;I)Lwr8;

    .line 857
    .line 858
    .line 859
    return-void

    .line 860
    :cond_1e
    invoke-virtual {v13}, Lis9;->b()Z

    .line 861
    .line 862
    .line 863
    move-result v3

    .line 864
    invoke-virtual {v13}, Lis9;->a()Z

    .line 865
    .line 866
    .line 867
    move-result v4

    .line 868
    new-instance v8, Lpr8;

    .line 869
    .line 870
    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    .line 871
    .line 872
    .line 873
    move-result-object v13

    .line 874
    invoke-virtual {v13}, Ljava/util/UUID;->toString()Ljava/lang/String;

    .line 875
    .line 876
    .line 877
    move-result-object v13

    .line 878
    move/from16 p1, v3

    .line 879
    .line 880
    move/from16 v16, v4

    .line 881
    .line 882
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 883
    .line 884
    .line 885
    move-result-wide v3

    .line 886
    invoke-direct {v8, v3, v4, v13}, Lpr8;-><init>(JLjava/lang/String;)V

    .line 887
    .line 888
    .line 889
    invoke-virtual {v2}, Lwr;->y()Ljava/lang/Integer;

    .line 890
    .line 891
    .line 892
    move-result-object v4

    .line 893
    iget-object v3, v2, Lwr;->a:Ljava/lang/String;

    .line 894
    .line 895
    iget v12, v0, Lnx;->g:I

    .line 896
    .line 897
    iget-object v1, v0, Lvq;->b:Lrs8;

    .line 898
    .line 899
    invoke-virtual {v1}, Lrs8;->getValue()Ljava/lang/Object;

    .line 900
    .line 901
    .line 902
    move-result-object v1

    .line 903
    check-cast v1, Lwy5;

    .line 904
    .line 905
    move-object/from16 v17, v0

    .line 906
    .line 907
    if-eqz v1, :cond_20

    .line 908
    .line 909
    invoke-static {}, Ltga;->I()Lcj;

    .line 910
    .line 911
    .line 912
    move-result-object v0

    .line 913
    iget-object v0, v0, Lcj;->a:Ljava/lang/Object;

    .line 914
    .line 915
    check-cast v0, Lqra;

    .line 916
    .line 917
    iget-object v0, v0, Lqra;->e:Ljava/lang/Object;

    .line 918
    .line 919
    check-cast v0, Li08;

    .line 920
    .line 921
    move-object/from16 v19, v2

    .line 922
    .line 923
    sget-object v2, Lan7;->a:Lbn7;

    .line 924
    .line 925
    invoke-virtual {v2, v11}, Lbn7;->b(Ljava/lang/Class;)Lf15;

    .line 926
    .line 927
    .line 928
    move-result-object v2

    .line 929
    const/4 v11, 0x0

    .line 930
    invoke-virtual {v0, v2, v11, v11}, Li08;->b(Lf15;Lev6;Lmf7;)Ljava/lang/Object;

    .line 931
    .line 932
    .line 933
    move-result-object v0

    .line 934
    check-cast v0, Landroid/content/Context;

    .line 935
    .line 936
    invoke-interface {v1, v0}, Lwy5;->a(Landroid/content/Context;)Ljava/lang/String;

    .line 937
    .line 938
    .line 939
    move-result-object v0

    .line 940
    if-nez v0, :cond_1f

    .line 941
    .line 942
    goto :goto_7

    .line 943
    :cond_1f
    move-object v14, v0

    .line 944
    goto :goto_7

    .line 945
    :cond_20
    move-object/from16 v19, v2

    .line 946
    .line 947
    :goto_7
    invoke-static {v10, v12, v3, v9}, Los8;->z(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;

    .line 948
    .line 949
    .line 950
    move-result-object v0

    .line 951
    const-string v1, "parent_message_id"

    .line 952
    .line 953
    invoke-virtual {v0, v1, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 954
    .line 955
    .line 956
    const-string v1, "sse_error_reason"

    .line 957
    .line 958
    const/4 v11, 0x0

    .line 959
    invoke-virtual {v0, v1, v11}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 960
    .line 961
    .line 962
    const-string v1, "sse_error_message"

    .line 963
    .line 964
    invoke-virtual {v0, v1, v14}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 965
    .line 966
    .line 967
    invoke-virtual {v0, v5, v13}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 968
    .line 969
    .line 970
    new-instance v1, Ljava/lang/StringBuilder;

    .line 971
    .line 972
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 973
    .line 974
    .line 975
    invoke-static {v1, v3, v6, v12}, Lsqa;->a(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/String;

    .line 976
    .line 977
    .line 978
    move-result-object v1

    .line 979
    invoke-virtual {v0, v7, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 980
    .line 981
    .line 982
    new-instance v1, Ljava/lang/StringBuilder;

    .line 983
    .line 984
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 985
    .line 986
    .line 987
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 988
    .line 989
    .line 990
    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 991
    .line 992
    .line 993
    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 994
    .line 995
    .line 996
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 997
    .line 998
    .line 999
    move-result-object v1

    .line 1000
    const-string v2, "full_parent_message_id"

    .line 1001
    .line 1002
    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 1003
    .line 1004
    .line 1005
    sget-object v1, Ldw;->a:Lnqa;

    .line 1006
    .line 1007
    const-string v2, "message_resend_click"

    .line 1008
    .line 1009
    invoke-virtual {v1, v2, v0}, Lnqa;->p(Ljava/lang/String;Lorg/json/JSONObject;)V

    .line 1010
    .line 1011
    .line 1012
    new-instance v0, Lun1;

    .line 1013
    .line 1014
    move-object v7, v8

    .line 1015
    const/4 v8, 0x0

    .line 1016
    move-object/from16 v1, p0

    .line 1017
    .line 1018
    move/from16 v5, p1

    .line 1019
    .line 1020
    move/from16 v6, v16

    .line 1021
    .line 1022
    move-object/from16 v3, v17

    .line 1023
    .line 1024
    move-object/from16 v2, v19

    .line 1025
    .line 1026
    invoke-direct/range {v0 .. v8}, Lun1;-><init>(Lao1;Lwr;Lnx;Ljava/lang/Integer;ZZLpr8;Lhf2;)V

    .line 1027
    .line 1028
    .line 1029
    const/4 v10, 0x3

    .line 1030
    const/4 v11, 0x0

    .line 1031
    const/4 v12, 0x0

    .line 1032
    invoke-static {v15, v12, v11, v0, v10}, Lv9a;->P(Lig2;Lag2;ILwv3;I)Lwr8;

    .line 1033
    .line 1034
    .line 1035
    return-void

    .line 1036
    :cond_21
    sget-object v2, Lrm1;->a:Lrm1;

    .line 1037
    .line 1038
    invoke-static {v0, v2}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1039
    .line 1040
    .line 1041
    move-result v2

    .line 1042
    if-eqz v2, :cond_22

    .line 1043
    .line 1044
    invoke-virtual {v1}, Lao1;->Q()Loc1;

    .line 1045
    .line 1046
    .line 1047
    move-result-object v0

    .line 1048
    invoke-virtual {v0}, Loc1;->l()Lyp1;

    .line 1049
    .line 1050
    .line 1051
    move-result-object v0

    .line 1052
    invoke-virtual {v1, v0}, Lao1;->I(Lyp1;)V

    .line 1053
    .line 1054
    .line 1055
    return-void

    .line 1056
    :cond_22
    instance-of v2, v0, Lhn1;

    .line 1057
    .line 1058
    if-eqz v2, :cond_23

    .line 1059
    .line 1060
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1061
    .line 1062
    .line 1063
    new-instance v0, Lnf1;

    .line 1064
    .line 1065
    const-string v2, "abort_generation"

    .line 1066
    .line 1067
    invoke-direct {v0, v2}, Lnf1;-><init>(Ljava/lang/String;)V

    .line 1068
    .line 1069
    .line 1070
    invoke-virtual {v4, v0}, Lfg1;->k(Lrf1;)V

    .line 1071
    .line 1072
    .line 1073
    const-string v0, "stop_button"

    .line 1074
    .line 1075
    invoke-virtual {v1, v0}, Lao1;->Y(Ljava/lang/String;)V

    .line 1076
    .line 1077
    .line 1078
    return-void

    .line 1079
    :cond_23
    sget-object v2, Lum1;->b:Lum1;

    .line 1080
    .line 1081
    invoke-static {v0, v2}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1082
    .line 1083
    .line 1084
    move-result v11

    .line 1085
    if-eqz v11, :cond_24

    .line 1086
    .line 1087
    new-instance v0, Lom1;

    .line 1088
    .line 1089
    const/4 v2, 0x4

    .line 1090
    const/4 v11, 0x0

    .line 1091
    invoke-direct {v0, v1, v11, v2}, Lom1;-><init>(Lao1;Lhf2;I)V

    .line 1092
    .line 1093
    .line 1094
    const/4 v1, 0x0

    .line 1095
    const/4 v10, 0x3

    .line 1096
    invoke-static {v15, v11, v1, v0, v10}, Lv9a;->P(Lig2;Lag2;ILwv3;I)Lwr8;

    .line 1097
    .line 1098
    .line 1099
    return-void

    .line 1100
    :cond_24
    instance-of v11, v0, Lym1;

    .line 1101
    .line 1102
    if-eqz v11, :cond_26

    .line 1103
    .line 1104
    check-cast v0, Lym1;

    .line 1105
    .line 1106
    iget-boolean v2, v0, Lym1;->a:Z

    .line 1107
    .line 1108
    iget-object v4, v0, Lym1;->b:Ljava/lang/String;

    .line 1109
    .line 1110
    move v0, v2

    .line 1111
    invoke-virtual {v1}, Lao1;->M()Lwr;

    .line 1112
    .line 1113
    .line 1114
    move-result-object v2

    .line 1115
    invoke-static {v2}, Ltga;->Q(Lwr;)Z

    .line 1116
    .line 1117
    .line 1118
    move-result v3

    .line 1119
    if-nez v3, :cond_5a

    .line 1120
    .line 1121
    iget-object v3, v1, Lao1;->l:Lwr8;

    .line 1122
    .line 1123
    const/4 v11, 0x0

    .line 1124
    if-eqz v3, :cond_25

    .line 1125
    .line 1126
    invoke-virtual {v3, v11}, Lut4;->b(Ljava/util/concurrent/CancellationException;)V

    .line 1127
    .line 1128
    .line 1129
    :cond_25
    move v1, v0

    .line 1130
    new-instance v0, Lsn1;

    .line 1131
    .line 1132
    const/4 v5, 0x0

    .line 1133
    move-object/from16 v3, p0

    .line 1134
    .line 1135
    invoke-direct/range {v0 .. v5}, Lsn1;-><init>(ZLwr;Lao1;Ljava/lang/String;Lhf2;)V

    .line 1136
    .line 1137
    .line 1138
    move-object v1, v3

    .line 1139
    const/4 v2, 0x0

    .line 1140
    const/4 v10, 0x3

    .line 1141
    invoke-static {v15, v11, v2, v0, v10}, Lv9a;->P(Lig2;Lag2;ILwv3;I)Lwr8;

    .line 1142
    .line 1143
    .line 1144
    move-result-object v0

    .line 1145
    iput-object v0, v1, Lao1;->l:Lwr8;

    .line 1146
    .line 1147
    return-void

    .line 1148
    :cond_26
    instance-of v11, v0, Lzm1;

    .line 1149
    .line 1150
    const-string v12, "fragment_types"

    .line 1151
    .line 1152
    const-string v3, "fragment_count"

    .line 1153
    .line 1154
    const-string v1, "total_branch_count"

    .line 1155
    .line 1156
    move/from16 v17, v11

    .line 1157
    .line 1158
    const-string v11, "current_branch_index"

    .line 1159
    .line 1160
    move-object/from16 v19, v13

    .line 1161
    .line 1162
    const-string v13, "is_latest_round"

    .line 1163
    .line 1164
    move-object/from16 v20, v14

    .line 1165
    .line 1166
    const-string v14, "chat_context_length"

    .line 1167
    .line 1168
    move-object/from16 v21, v2

    .line 1169
    .line 1170
    const-string v2, "model_type"

    .line 1171
    .line 1172
    move-object/from16 v22, v4

    .line 1173
    .line 1174
    if-eqz v17, :cond_37

    .line 1175
    .line 1176
    check-cast v0, Lzm1;

    .line 1177
    .line 1178
    iget-object v4, v0, Lzm1;->a:Lvq;

    .line 1179
    .line 1180
    move-object/from16 v24, v15

    .line 1181
    .line 1182
    iget-object v15, v0, Lzm1;->b:Ljava/lang/String;

    .line 1183
    .line 1184
    iget-object v0, v0, Lzm1;->c:Lpn7;

    .line 1185
    .line 1186
    move-object/from16 v25, v7

    .line 1187
    .line 1188
    invoke-virtual/range {p0 .. p0}, Lao1;->M()Lwr;

    .line 1189
    .line 1190
    .line 1191
    move-result-object v7

    .line 1192
    invoke-static {v7}, Ltga;->Q(Lwr;)Z

    .line 1193
    .line 1194
    .line 1195
    move-result v16

    .line 1196
    move-object/from16 v26, v6

    .line 1197
    .line 1198
    iget-object v6, v7, Lwr;->a:Ljava/lang/String;

    .line 1199
    .line 1200
    if-eqz v16, :cond_27

    .line 1201
    .line 1202
    goto/16 :goto_1a

    .line 1203
    .line 1204
    :cond_27
    invoke-virtual {v8, v7}, Lib1;->f(Lwr;)Z

    .line 1205
    .line 1206
    .line 1207
    move-result v16

    .line 1208
    if-nez v16, :cond_28

    .line 1209
    .line 1210
    goto/16 :goto_1a

    .line 1211
    .line 1212
    :cond_28
    move-object/from16 v27, v2

    .line 1213
    .line 1214
    iget-object v2, v7, Lwr;->f:Ljava/util/LinkedHashMap;

    .line 1215
    .line 1216
    invoke-virtual {v4}, Lvq;->K()I

    .line 1217
    .line 1218
    .line 1219
    move-result v16

    .line 1220
    move-object/from16 v28, v5

    .line 1221
    .line 1222
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1223
    .line 1224
    .line 1225
    move-result-object v5

    .line 1226
    invoke-virtual {v2, v5}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1227
    .line 1228
    .line 1229
    move-result-object v2

    .line 1230
    check-cast v2, Lvq;

    .line 1231
    .line 1232
    if-nez v2, :cond_29

    .line 1233
    .line 1234
    sget-object v0, Lao1;->E:Lcl5;

    .line 1235
    .line 1236
    const-string v1, "regenerate: parentMessage is null"

    .line 1237
    .line 1238
    invoke-virtual {v0, v1}, Lcl5;->c(Ljava/lang/String;)V

    .line 1239
    .line 1240
    .line 1241
    invoke-virtual {v4}, Lvq;->x()I

    .line 1242
    .line 1243
    .line 1244
    move-result v0

    .line 1245
    invoke-virtual {v4}, Lvq;->K()I

    .line 1246
    .line 1247
    .line 1248
    move-result v1

    .line 1249
    const-string v2, "session_id"

    .line 1250
    .line 1251
    const-string v3, "message_id"

    .line 1252
    .line 1253
    invoke-static {v2, v0, v6, v3}, Los8;->z(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;

    .line 1254
    .line 1255
    .line 1256
    move-result-object v0

    .line 1257
    const-string v2, "target_parent_id"

    .line 1258
    .line 1259
    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 1260
    .line 1261
    .line 1262
    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    .line 1263
    .line 1264
    .line 1265
    move-result-object v0

    .line 1266
    const-string v1, "event_name"

    .line 1267
    .line 1268
    const-string v2, "extra_data"

    .line 1269
    .line 1270
    const-string v3, "message_parent_not_found"

    .line 1271
    .line 1272
    invoke-static {v1, v3, v2, v0}, Lsqa;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;

    .line 1273
    .line 1274
    .line 1275
    move-result-object v0

    .line 1276
    sget-object v1, Ldw;->a:Lnqa;

    .line 1277
    .line 1278
    const-string v2, "client_monitor"

    .line 1279
    .line 1280
    invoke-virtual {v1, v2, v0}, Lnqa;->p(Ljava/lang/String;Lorg/json/JSONObject;)V

    .line 1281
    .line 1282
    .line 1283
    return-void

    .line 1284
    :cond_29
    invoke-virtual {v2}, Lvq;->D()Ljava/lang/String;

    .line 1285
    .line 1286
    .line 1287
    move-result-object v5

    .line 1288
    sget-object v16, Lpj1;->Companion:Loj1;

    .line 1289
    .line 1290
    invoke-virtual/range {v16 .. v16}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1291
    .line 1292
    .line 1293
    move-object/from16 p1, v2

    .line 1294
    .line 1295
    const-string v2, "USER"

    .line 1296
    .line 1297
    invoke-static {v5, v2}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1298
    .line 1299
    .line 1300
    move-result v2

    .line 1301
    if-nez v2, :cond_2a

    .line 1302
    .line 1303
    const/16 v17, 0x1

    .line 1304
    .line 1305
    goto :goto_8

    .line 1306
    :cond_2a
    invoke-virtual/range {p1 .. p1}, Lvq;->r()Ljava/lang/String;

    .line 1307
    .line 1308
    .line 1309
    move-result-object v2

    .line 1310
    invoke-virtual {v8, v2}, Lib1;->e(Ljava/lang/String;)Z

    .line 1311
    .line 1312
    .line 1313
    move-result v2

    .line 1314
    move/from16 v17, v2

    .line 1315
    .line 1316
    :goto_8
    if-nez v17, :cond_2b

    .line 1317
    .line 1318
    goto/16 :goto_1a

    .line 1319
    .line 1320
    :cond_2b
    invoke-virtual/range {p1 .. p1}, Lvq;->r()Ljava/lang/String;

    .line 1321
    .line 1322
    .line 1323
    move-result-object v2

    .line 1324
    invoke-virtual {v8, v2}, Lib1;->e(Ljava/lang/String;)Z

    .line 1325
    .line 1326
    .line 1327
    move-result v2

    .line 1328
    if-nez v2, :cond_2c

    .line 1329
    .line 1330
    goto/16 :goto_1a

    .line 1331
    .line 1332
    :cond_2c
    invoke-virtual/range {v19 .. v19}, Lis9;->b()Z

    .line 1333
    .line 1334
    .line 1335
    move-result v5

    .line 1336
    invoke-virtual/range {v19 .. v19}, Lis9;->a()Z

    .line 1337
    .line 1338
    .line 1339
    move-result v2

    .line 1340
    new-instance v8, Lpr8;

    .line 1341
    .line 1342
    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    .line 1343
    .line 1344
    .line 1345
    move-result-object v16

    .line 1346
    move-object/from16 v19, v12

    .line 1347
    .line 1348
    invoke-virtual/range {v16 .. v16}, Ljava/util/UUID;->toString()Ljava/lang/String;

    .line 1349
    .line 1350
    .line 1351
    move-result-object v12

    .line 1352
    move-object/from16 v29, v1

    .line 1353
    .line 1354
    move/from16 v16, v2

    .line 1355
    .line 1356
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 1357
    .line 1358
    .line 1359
    move-result-wide v1

    .line 1360
    invoke-direct {v8, v1, v2, v12}, Lpr8;-><init>(JLjava/lang/String;)V

    .line 1361
    .line 1362
    .line 1363
    if-eqz v0, :cond_2d

    .line 1364
    .line 1365
    iget-object v1, v0, Lpn7;->a:Lon7;

    .line 1366
    .line 1367
    goto :goto_9

    .line 1368
    :cond_2d
    const/4 v1, 0x0

    .line 1369
    :goto_9
    sget-object v2, Lon7;->b:Lon7;

    .line 1370
    .line 1371
    if-ne v1, v2, :cond_2e

    .line 1372
    .line 1373
    const-string v1, "verbosity_low"

    .line 1374
    .line 1375
    goto :goto_d

    .line 1376
    :cond_2e
    if-eqz v0, :cond_2f

    .line 1377
    .line 1378
    iget-object v1, v0, Lpn7;->a:Lon7;

    .line 1379
    .line 1380
    goto :goto_a

    .line 1381
    :cond_2f
    const/4 v1, 0x0

    .line 1382
    :goto_a
    sget-object v2, Lon7;->c:Lon7;

    .line 1383
    .line 1384
    if-ne v1, v2, :cond_30

    .line 1385
    .line 1386
    const-string v1, "verbosity_high"

    .line 1387
    .line 1388
    goto :goto_d

    .line 1389
    :cond_30
    if-eqz v0, :cond_31

    .line 1390
    .line 1391
    iget-object v1, v0, Lpn7;->b:Lmn7;

    .line 1392
    .line 1393
    goto :goto_b

    .line 1394
    :cond_31
    const/4 v1, 0x0

    .line 1395
    :goto_b
    sget-object v2, Lmn7;->b:Lmn7;

    .line 1396
    .line 1397
    if-ne v1, v2, :cond_32

    .line 1398
    .line 1399
    const-string v1, "search_force_on"

    .line 1400
    .line 1401
    goto :goto_d

    .line 1402
    :cond_32
    if-eqz v0, :cond_33

    .line 1403
    .line 1404
    iget-object v1, v0, Lpn7;->b:Lmn7;

    .line 1405
    .line 1406
    goto :goto_c

    .line 1407
    :cond_33
    const/4 v1, 0x0

    .line 1408
    :goto_c
    sget-object v2, Lmn7;->c:Lmn7;

    .line 1409
    .line 1410
    if-ne v1, v2, :cond_34

    .line 1411
    .line 1412
    const-string v1, "search_force_off"

    .line 1413
    .line 1414
    goto :goto_d

    .line 1415
    :cond_34
    const-string v1, "none"

    .line 1416
    .line 1417
    :goto_d
    invoke-static {v7}, Ltga;->F(Lwr;)I

    .line 1418
    .line 1419
    .line 1420
    move-result v2

    .line 1421
    move-object/from16 v21, v0

    .line 1422
    .line 1423
    invoke-static {v4, v7}, Loba;->z(Lvq;Lwr;)Lnu6;

    .line 1424
    .line 1425
    .line 1426
    move-result-object v0

    .line 1427
    move-object/from16 v22, v4

    .line 1428
    .line 1429
    iget-object v4, v0, Lnu6;->a:Ljava/lang/Object;

    .line 1430
    .line 1431
    check-cast v4, Ljava/lang/Number;

    .line 1432
    .line 1433
    invoke-virtual {v4}, Ljava/lang/Number;->intValue()I

    .line 1434
    .line 1435
    .line 1436
    move-result v4

    .line 1437
    iget-object v0, v0, Lnu6;->b:Ljava/lang/Object;

    .line 1438
    .line 1439
    check-cast v0, Ljava/lang/Number;

    .line 1440
    .line 1441
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 1442
    .line 1443
    .line 1444
    move-result v0

    .line 1445
    move-object/from16 v17, v8

    .line 1446
    .line 1447
    invoke-virtual/range {v22 .. v22}, Lvq;->x()I

    .line 1448
    .line 1449
    .line 1450
    move-result v8

    .line 1451
    move-object/from16 v30, v12

    .line 1452
    .line 1453
    invoke-virtual/range {v22 .. v22}, Lvq;->F()Z

    .line 1454
    .line 1455
    .line 1456
    move-result v12

    .line 1457
    move-object/from16 v31, v1

    .line 1458
    .line 1459
    const-string v1, "ASSISTANT"

    .line 1460
    .line 1461
    move-object/from16 v32, v3

    .line 1462
    .line 1463
    invoke-virtual/range {v22 .. v22}, Lvq;->x()I

    .line 1464
    .line 1465
    .line 1466
    move-result v3

    .line 1467
    invoke-static {v7, v1, v3}, Loba;->O(Lwr;Ljava/lang/String;I)Z

    .line 1468
    .line 1469
    .line 1470
    move-result v1

    .line 1471
    sget-object v3, Lh31;->a:Ldv8;

    .line 1472
    .line 1473
    invoke-virtual/range {v22 .. v22}, Lvq;->s()Lb41;

    .line 1474
    .line 1475
    .line 1476
    move-result-object v3

    .line 1477
    invoke-interface {v3}, Ljava/util/List;->size()I

    .line 1478
    .line 1479
    .line 1480
    move-result v3

    .line 1481
    move-object/from16 v33, v7

    .line 1482
    .line 1483
    invoke-static/range {v22 .. v22}, Lh31;->a(Lvq;)[Ljava/lang/String;

    .line 1484
    .line 1485
    .line 1486
    move-result-object v7

    .line 1487
    invoke-virtual/range {v33 .. v33}, Lwr;->h()Ljava/lang/String;

    .line 1488
    .line 1489
    .line 1490
    move-result-object v34

    .line 1491
    if-nez v34, :cond_35

    .line 1492
    .line 1493
    move-object/from16 v36, v20

    .line 1494
    .line 1495
    goto :goto_e

    .line 1496
    :cond_35
    move-object/from16 v36, v34

    .line 1497
    .line 1498
    :goto_e
    invoke-static {v10, v8, v6, v9}, Los8;->z(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;

    .line 1499
    .line 1500
    .line 1501
    move-result-object v9

    .line 1502
    invoke-virtual {v9, v14, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 1503
    .line 1504
    .line 1505
    const-string v2, "is_think_enable"

    .line 1506
    .line 1507
    invoke-virtual {v9, v2, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 1508
    .line 1509
    .line 1510
    const-string v2, "is_search_enable"

    .line 1511
    .line 1512
    move/from16 v10, v16

    .line 1513
    .line 1514
    invoke-virtual {v9, v2, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 1515
    .line 1516
    .line 1517
    const-string v2, "is_search_triggered"

    .line 1518
    .line 1519
    invoke-virtual {v9, v2, v12}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 1520
    .line 1521
    .line 1522
    const-string v2, "message_action_button_position"

    .line 1523
    .line 1524
    invoke-virtual {v9, v2, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 1525
    .line 1526
    .line 1527
    invoke-virtual {v9, v13, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 1528
    .line 1529
    .line 1530
    invoke-virtual {v9, v11, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 1531
    .line 1532
    .line 1533
    move-object/from16 v1, v29

    .line 1534
    .line 1535
    invoke-virtual {v9, v1, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 1536
    .line 1537
    .line 1538
    move-object/from16 v2, v32

    .line 1539
    .line 1540
    invoke-virtual {v9, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 1541
    .line 1542
    .line 1543
    new-instance v0, Lorg/json/JSONArray;

    .line 1544
    .line 1545
    invoke-direct {v0}, Lorg/json/JSONArray;-><init>()V

    .line 1546
    .line 1547
    .line 1548
    array-length v1, v7

    .line 1549
    const/4 v2, 0x0

    .line 1550
    :goto_f
    if-ge v2, v1, :cond_36

    .line 1551
    .line 1552
    aget-object v3, v7, v2

    .line 1553
    .line 1554
    invoke-virtual {v0, v3}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    .line 1555
    .line 1556
    .line 1557
    add-int/lit8 v2, v2, 0x1

    .line 1558
    .line 1559
    goto :goto_f

    .line 1560
    :cond_36
    move-object/from16 v3, v19

    .line 1561
    .line 1562
    invoke-virtual {v9, v3, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 1563
    .line 1564
    .line 1565
    const-string v0, "regenerate_option"

    .line 1566
    .line 1567
    move-object/from16 v1, v31

    .line 1568
    .line 1569
    invoke-virtual {v9, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 1570
    .line 1571
    .line 1572
    move-object/from16 v4, v28

    .line 1573
    .line 1574
    move-object/from16 v0, v30

    .line 1575
    .line 1576
    invoke-virtual {v9, v4, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 1577
    .line 1578
    .line 1579
    move-object/from16 v7, v27

    .line 1580
    .line 1581
    move-object/from16 v0, v36

    .line 1582
    .line 1583
    invoke-virtual {v9, v7, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 1584
    .line 1585
    .line 1586
    new-instance v0, Ljava/lang/StringBuilder;

    .line 1587
    .line 1588
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 1589
    .line 1590
    .line 1591
    move-object/from16 v12, v26

    .line 1592
    .line 1593
    invoke-static {v0, v6, v12, v8}, Lsqa;->a(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/String;

    .line 1594
    .line 1595
    .line 1596
    move-result-object v0

    .line 1597
    move-object/from16 v6, v25

    .line 1598
    .line 1599
    invoke-virtual {v9, v6, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 1600
    .line 1601
    .line 1602
    sget-object v0, Ldw;->a:Lnqa;

    .line 1603
    .line 1604
    const-string v1, "regenerate_click"

    .line 1605
    .line 1606
    invoke-virtual {v0, v1, v9}, Lnqa;->p(Ljava/lang/String;Lorg/json/JSONObject;)V

    .line 1607
    .line 1608
    .line 1609
    invoke-virtual/range {p0 .. p0}, Lao1;->t()V

    .line 1610
    .line 1611
    .line 1612
    new-instance v0, Ltn1;

    .line 1613
    .line 1614
    const/4 v9, 0x0

    .line 1615
    move-object/from16 v1, p0

    .line 1616
    .line 1617
    move-object/from16 v2, p1

    .line 1618
    .line 1619
    move v6, v10

    .line 1620
    move-object/from16 v8, v17

    .line 1621
    .line 1622
    move-object/from16 v7, v21

    .line 1623
    .line 1624
    move-object/from16 v3, v22

    .line 1625
    .line 1626
    move-object/from16 v4, v33

    .line 1627
    .line 1628
    invoke-direct/range {v0 .. v9}, Ltn1;-><init>(Lao1;Lvq;Lvq;Lwr;ZZLpn7;Lpr8;Lhf2;)V

    .line 1629
    .line 1630
    .line 1631
    move-object/from16 v15, v24

    .line 1632
    .line 1633
    const/4 v10, 0x3

    .line 1634
    const/4 v11, 0x0

    .line 1635
    const/4 v12, 0x0

    .line 1636
    invoke-static {v15, v12, v11, v0, v10}, Lv9a;->P(Lig2;Lag2;ILwv3;I)Lwr8;

    .line 1637
    .line 1638
    .line 1639
    return-void

    .line 1640
    :cond_37
    move-object/from16 v28, v7

    .line 1641
    .line 1642
    move-object v7, v2

    .line 1643
    move-object v2, v3

    .line 1644
    move-object v3, v12

    .line 1645
    move-object v12, v6

    .line 1646
    move-object/from16 v6, v28

    .line 1647
    .line 1648
    move-object/from16 v28, v5

    .line 1649
    .line 1650
    instance-of v4, v0, Lin1;

    .line 1651
    .line 1652
    if-eqz v4, :cond_3b

    .line 1653
    .line 1654
    check-cast v0, Lin1;

    .line 1655
    .line 1656
    iget-object v2, v0, Lin1;->a:Lvq;

    .line 1657
    .line 1658
    iget v3, v0, Lin1;->c:I

    .line 1659
    .line 1660
    iget v4, v0, Lin1;->b:I

    .line 1661
    .line 1662
    iget v8, v0, Lin1;->d:I

    .line 1663
    .line 1664
    invoke-virtual/range {p0 .. p0}, Lao1;->P()Z

    .line 1665
    .line 1666
    .line 1667
    move-result v14

    .line 1668
    if-eqz v14, :cond_38

    .line 1669
    .line 1670
    goto :goto_10

    .line 1671
    :cond_38
    invoke-virtual/range {p0 .. p0}, Lao1;->M()Lwr;

    .line 1672
    .line 1673
    .line 1674
    move-result-object v14

    .line 1675
    invoke-static {v14}, Ltga;->Q(Lwr;)Z

    .line 1676
    .line 1677
    .line 1678
    move-result v16

    .line 1679
    if-eqz v16, :cond_39

    .line 1680
    .line 1681
    :goto_10
    move-object/from16 v24, v15

    .line 1682
    .line 1683
    goto :goto_11

    .line 1684
    :cond_39
    move-object/from16 v16, v2

    .line 1685
    .line 1686
    iget-object v2, v14, Lwr;->a:Ljava/lang/String;

    .line 1687
    .line 1688
    move-object/from16 v24, v15

    .line 1689
    .line 1690
    invoke-virtual/range {v16 .. v16}, Lvq;->x()I

    .line 1691
    .line 1692
    .line 1693
    move-result v15

    .line 1694
    invoke-virtual/range {v16 .. v16}, Lvq;->D()Ljava/lang/String;

    .line 1695
    .line 1696
    .line 1697
    move-result-object v17

    .line 1698
    invoke-static/range {v17 .. v17}, Lh31;->b(Ljava/lang/String;)Ljava/lang/String;

    .line 1699
    .line 1700
    .line 1701
    move-result-object v5

    .line 1702
    move-object/from16 p1, v0

    .line 1703
    .line 1704
    invoke-virtual/range {v16 .. v16}, Lvq;->D()Ljava/lang/String;

    .line 1705
    .line 1706
    .line 1707
    move-result-object v0

    .line 1708
    move-object/from16 v25, v6

    .line 1709
    .line 1710
    invoke-virtual/range {v16 .. v16}, Lvq;->x()I

    .line 1711
    .line 1712
    .line 1713
    move-result v6

    .line 1714
    invoke-static {v14, v0, v6}, Loba;->O(Lwr;Ljava/lang/String;I)Z

    .line 1715
    .line 1716
    .line 1717
    move-result v0

    .line 1718
    invoke-virtual {v14}, Lwr;->h()Ljava/lang/String;

    .line 1719
    .line 1720
    .line 1721
    move-result-object v6

    .line 1722
    if-nez v6, :cond_3a

    .line 1723
    .line 1724
    invoke-virtual/range {p0 .. p0}, Lao1;->N()Ljava/lang/String;

    .line 1725
    .line 1726
    .line 1727
    move-result-object v6

    .line 1728
    :cond_3a
    invoke-static {v10, v15, v2, v9}, Los8;->z(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;

    .line 1729
    .line 1730
    .line 1731
    move-result-object v9

    .line 1732
    const-string v10, "chat_message_role"

    .line 1733
    .line 1734
    invoke-virtual {v9, v10, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 1735
    .line 1736
    .line 1737
    invoke-virtual {v9, v11, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 1738
    .line 1739
    .line 1740
    const-string v4, "target_branch_index"

    .line 1741
    .line 1742
    invoke-virtual {v9, v4, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 1743
    .line 1744
    .line 1745
    invoke-virtual {v9, v1, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 1746
    .line 1747
    .line 1748
    invoke-virtual {v9, v13, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 1749
    .line 1750
    .line 1751
    invoke-virtual {v9, v7, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 1752
    .line 1753
    .line 1754
    new-instance v0, Ljava/lang/StringBuilder;

    .line 1755
    .line 1756
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 1757
    .line 1758
    .line 1759
    invoke-static {v0, v2, v12, v15}, Lsqa;->a(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/String;

    .line 1760
    .line 1761
    .line 1762
    move-result-object v0

    .line 1763
    move-object/from16 v6, v25

    .line 1764
    .line 1765
    invoke-virtual {v9, v6, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 1766
    .line 1767
    .line 1768
    sget-object v0, Ldw;->a:Lnqa;

    .line 1769
    .line 1770
    const-string v1, "switch_message_branch"

    .line 1771
    .line 1772
    invoke-virtual {v0, v1, v9}, Lnqa;->p(Ljava/lang/String;Lorg/json/JSONObject;)V

    .line 1773
    .line 1774
    .line 1775
    invoke-virtual/range {v16 .. v16}, Lvq;->x()I

    .line 1776
    .line 1777
    .line 1778
    move-result v0

    .line 1779
    invoke-virtual {v14, v0, v3}, Lwr;->w(II)V

    .line 1780
    .line 1781
    .line 1782
    move-object/from16 v0, p1

    .line 1783
    .line 1784
    :goto_11
    iget-object v0, v0, Lin1;->e:Lno1;

    .line 1785
    .line 1786
    if-eqz v0, :cond_5a

    .line 1787
    .line 1788
    new-instance v1, Lon1;

    .line 1789
    .line 1790
    const/4 v4, 0x0

    .line 1791
    const/4 v11, 0x0

    .line 1792
    move-object/from16 v5, p0

    .line 1793
    .line 1794
    invoke-direct {v1, v5, v0, v4, v11}, Lon1;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lhf2;I)V

    .line 1795
    .line 1796
    .line 1797
    move-object/from16 v15, v24

    .line 1798
    .line 1799
    const/4 v10, 0x3

    .line 1800
    invoke-static {v15, v4, v11, v1, v10}, Lv9a;->P(Lig2;Lag2;ILwv3;I)Lwr8;

    .line 1801
    .line 1802
    .line 1803
    return-void

    .line 1804
    :cond_3b
    move-object/from16 v5, p0

    .line 1805
    .line 1806
    const/4 v4, 0x0

    .line 1807
    instance-of v1, v0, Lvm1;

    .line 1808
    .line 1809
    if-eqz v1, :cond_3d

    .line 1810
    .line 1811
    check-cast v0, Lvm1;

    .line 1812
    .line 1813
    iget-object v0, v0, Lvm1;->a:Lvq;

    .line 1814
    .line 1815
    invoke-virtual {v5}, Lao1;->O()Llb1;

    .line 1816
    .line 1817
    .line 1818
    move-result-object v1

    .line 1819
    iget-object v2, v1, Llb1;->c:Lfc;

    .line 1820
    .line 1821
    invoke-virtual {v2}, Lfc;->v()Ljava/lang/Object;

    .line 1822
    .line 1823
    .line 1824
    move-result-object v2

    .line 1825
    move-object/from16 v21, v2

    .line 1826
    .line 1827
    check-cast v21, Lwr;

    .line 1828
    .line 1829
    invoke-static/range {v21 .. v21}, Ltga;->Q(Lwr;)Z

    .line 1830
    .line 1831
    .line 1832
    move-result v2

    .line 1833
    if-eqz v2, :cond_3c

    .line 1834
    .line 1835
    goto/16 :goto_1a

    .line 1836
    .line 1837
    :cond_3c
    iget-object v2, v1, Llb1;->b:Lig2;

    .line 1838
    .line 1839
    new-instance v16, Lz4;

    .line 1840
    .line 1841
    const/16 v17, 0xc

    .line 1842
    .line 1843
    const/16 v22, 0x0

    .line 1844
    .line 1845
    move-object/from16 v19, v0

    .line 1846
    .line 1847
    move-object/from16 v20, v1

    .line 1848
    .line 1849
    move-object/from16 v18, v4

    .line 1850
    .line 1851
    invoke-direct/range {v16 .. v22}, Lz4;-><init>(ILhf2;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Z)V

    .line 1852
    .line 1853
    .line 1854
    move-object/from16 v0, v16

    .line 1855
    .line 1856
    move-object/from16 v11, v18

    .line 1857
    .line 1858
    const/4 v1, 0x0

    .line 1859
    const/4 v10, 0x3

    .line 1860
    invoke-static {v2, v11, v1, v0, v10}, Lv9a;->P(Lig2;Lag2;ILwv3;I)Lwr8;

    .line 1861
    .line 1862
    .line 1863
    return-void

    .line 1864
    :cond_3d
    move-object v11, v4

    .line 1865
    instance-of v1, v0, Ltm1;

    .line 1866
    .line 1867
    if-eqz v1, :cond_3f

    .line 1868
    .line 1869
    check-cast v0, Ltm1;

    .line 1870
    .line 1871
    iget-object v3, v0, Ltm1;->a:Lvq;

    .line 1872
    .line 1873
    iget-object v5, v0, Ltm1;->b:Lsy5;

    .line 1874
    .line 1875
    iget-object v6, v0, Ltm1;->c:Ljava/lang/String;

    .line 1876
    .line 1877
    invoke-virtual/range {p0 .. p0}, Lao1;->O()Llb1;

    .line 1878
    .line 1879
    .line 1880
    move-result-object v2

    .line 1881
    iget-object v0, v2, Llb1;->c:Lfc;

    .line 1882
    .line 1883
    invoke-virtual {v0}, Lfc;->v()Ljava/lang/Object;

    .line 1884
    .line 1885
    .line 1886
    move-result-object v0

    .line 1887
    move-object v4, v0

    .line 1888
    check-cast v4, Lwr;

    .line 1889
    .line 1890
    invoke-static {v4}, Ltga;->Q(Lwr;)Z

    .line 1891
    .line 1892
    .line 1893
    move-result v0

    .line 1894
    if-eqz v0, :cond_3e

    .line 1895
    .line 1896
    goto/16 :goto_1a

    .line 1897
    .line 1898
    :cond_3e
    iget-object v0, v2, Llb1;->b:Lig2;

    .line 1899
    .line 1900
    new-instance v1, Lgj;

    .line 1901
    .line 1902
    const/4 v7, 0x0

    .line 1903
    invoke-direct/range {v1 .. v7}, Lgj;-><init>(Llb1;Lvq;Lwr;Lsy5;Ljava/lang/String;Lhf2;)V

    .line 1904
    .line 1905
    .line 1906
    const/4 v2, 0x0

    .line 1907
    const/4 v10, 0x3

    .line 1908
    invoke-static {v0, v11, v2, v1, v10}, Lv9a;->P(Lig2;Lag2;ILwv3;I)Lwr8;

    .line 1909
    .line 1910
    .line 1911
    return-void

    .line 1912
    :cond_3f
    instance-of v1, v0, Lqm1;

    .line 1913
    .line 1914
    if-eqz v1, :cond_49

    .line 1915
    .line 1916
    check-cast v0, Lqm1;

    .line 1917
    .line 1918
    iget-object v0, v0, Lqm1;->a:Lvq;

    .line 1919
    .line 1920
    invoke-virtual/range {p0 .. p0}, Lao1;->M()Lwr;

    .line 1921
    .line 1922
    .line 1923
    move-result-object v1

    .line 1924
    invoke-static {v1}, Ltga;->Q(Lwr;)Z

    .line 1925
    .line 1926
    .line 1927
    move-result v4

    .line 1928
    if-eqz v4, :cond_40

    .line 1929
    .line 1930
    goto/16 :goto_1a

    .line 1931
    .line 1932
    :cond_40
    invoke-virtual {v8, v1}, Lib1;->f(Lwr;)Z

    .line 1933
    .line 1934
    .line 1935
    move-result v4

    .line 1936
    if-nez v4, :cond_41

    .line 1937
    .line 1938
    goto/16 :goto_1a

    .line 1939
    .line 1940
    :cond_41
    invoke-virtual {v0}, Lvq;->L()Lla1;

    .line 1941
    .line 1942
    .line 1943
    move-result-object v4

    .line 1944
    sget-object v5, Lja1;->d:Lja1;

    .line 1945
    .line 1946
    invoke-virtual {v4, v5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 1947
    .line 1948
    .line 1949
    move-result v5

    .line 1950
    if-eqz v5, :cond_42

    .line 1951
    .line 1952
    goto :goto_12

    .line 1953
    :cond_42
    instance-of v5, v4, Lia1;

    .line 1954
    .line 1955
    if-eqz v5, :cond_43

    .line 1956
    .line 1957
    check-cast v4, Lia1;

    .line 1958
    .line 1959
    iget-boolean v4, v4, Lia1;->a:Z

    .line 1960
    .line 1961
    if-eqz v4, :cond_43

    .line 1962
    .line 1963
    :goto_12
    const/4 v4, 0x1

    .line 1964
    goto :goto_13

    .line 1965
    :cond_43
    const/4 v4, 0x0

    .line 1966
    :goto_13
    if-nez v4, :cond_44

    .line 1967
    .line 1968
    goto/16 :goto_1a

    .line 1969
    .line 1970
    :cond_44
    iget-object v4, v1, Lwr;->f:Ljava/util/LinkedHashMap;

    .line 1971
    .line 1972
    invoke-virtual {v0}, Lvq;->K()I

    .line 1973
    .line 1974
    .line 1975
    move-result v5

    .line 1976
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1977
    .line 1978
    .line 1979
    move-result-object v5

    .line 1980
    invoke-virtual {v4, v5}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1981
    .line 1982
    .line 1983
    move-result-object v4

    .line 1984
    check-cast v4, Lvq;

    .line 1985
    .line 1986
    if-eqz v4, :cond_45

    .line 1987
    .line 1988
    invoke-virtual {v4}, Lvq;->r()Ljava/lang/String;

    .line 1989
    .line 1990
    .line 1991
    move-result-object v4

    .line 1992
    invoke-virtual {v8, v4}, Lib1;->e(Ljava/lang/String;)Z

    .line 1993
    .line 1994
    .line 1995
    move-result v4

    .line 1996
    if-nez v4, :cond_45

    .line 1997
    .line 1998
    goto/16 :goto_1a

    .line 1999
    .line 2000
    :cond_45
    new-instance v4, Lpr8;

    .line 2001
    .line 2002
    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    .line 2003
    .line 2004
    .line 2005
    move-result-object v5

    .line 2006
    invoke-virtual {v5}, Ljava/util/UUID;->toString()Ljava/lang/String;

    .line 2007
    .line 2008
    .line 2009
    move-result-object v5

    .line 2010
    move-object/from16 v26, v12

    .line 2011
    .line 2012
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 2013
    .line 2014
    .line 2015
    move-result-wide v11

    .line 2016
    invoke-direct {v4, v11, v12, v5}, Lpr8;-><init>(JLjava/lang/String;)V

    .line 2017
    .line 2018
    .line 2019
    invoke-static {v1}, Ltga;->F(Lwr;)I

    .line 2020
    .line 2021
    .line 2022
    move-result v8

    .line 2023
    iget-object v11, v1, Lwr;->a:Ljava/lang/String;

    .line 2024
    .line 2025
    invoke-virtual {v0}, Lvq;->x()I

    .line 2026
    .line 2027
    .line 2028
    move-result v12

    .line 2029
    sget-object v13, Lh31;->a:Ldv8;

    .line 2030
    .line 2031
    invoke-virtual {v0}, Lvq;->s()Lb41;

    .line 2032
    .line 2033
    .line 2034
    move-result-object v13

    .line 2035
    invoke-interface {v13}, Ljava/util/List;->size()I

    .line 2036
    .line 2037
    .line 2038
    move-result v13

    .line 2039
    move-object/from16 v16, v0

    .line 2040
    .line 2041
    invoke-static/range {v16 .. v16}, Lh31;->a(Lvq;)[Ljava/lang/String;

    .line 2042
    .line 2043
    .line 2044
    move-result-object v0

    .line 2045
    invoke-virtual {v1}, Lwr;->h()Ljava/lang/String;

    .line 2046
    .line 2047
    .line 2048
    move-result-object v19

    .line 2049
    move-object/from16 p1, v1

    .line 2050
    .line 2051
    if-nez v19, :cond_46

    .line 2052
    .line 2053
    move-object/from16 v1, v20

    .line 2054
    .line 2055
    goto :goto_14

    .line 2056
    :cond_46
    move-object/from16 v1, v19

    .line 2057
    .line 2058
    :goto_14
    invoke-virtual/range {v16 .. v16}, Lvq;->t()Ljava/lang/String;

    .line 2059
    .line 2060
    .line 2061
    move-result-object v19

    .line 2062
    if-eqz v19, :cond_47

    .line 2063
    .line 2064
    move-object/from16 v19, v4

    .line 2065
    .line 2066
    const/4 v4, 0x1

    .line 2067
    goto :goto_15

    .line 2068
    :cond_47
    move-object/from16 v19, v4

    .line 2069
    .line 2070
    const/4 v4, 0x0

    .line 2071
    :goto_15
    invoke-static {v10, v12, v11, v9}, Los8;->z(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;

    .line 2072
    .line 2073
    .line 2074
    move-result-object v9

    .line 2075
    invoke-virtual {v9, v14, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 2076
    .line 2077
    .line 2078
    invoke-virtual {v9, v2, v13}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 2079
    .line 2080
    .line 2081
    new-instance v2, Lorg/json/JSONArray;

    .line 2082
    .line 2083
    invoke-direct {v2}, Lorg/json/JSONArray;-><init>()V

    .line 2084
    .line 2085
    .line 2086
    array-length v8, v0

    .line 2087
    const/4 v10, 0x0

    .line 2088
    :goto_16
    if-ge v10, v8, :cond_48

    .line 2089
    .line 2090
    aget-object v13, v0, v10

    .line 2091
    .line 2092
    invoke-virtual {v2, v13}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    .line 2093
    .line 2094
    .line 2095
    add-int/lit8 v10, v10, 0x1

    .line 2096
    .line 2097
    goto :goto_16

    .line 2098
    :cond_48
    invoke-virtual {v9, v3, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 2099
    .line 2100
    .line 2101
    move-object/from16 v2, v28

    .line 2102
    .line 2103
    invoke-virtual {v9, v2, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 2104
    .line 2105
    .line 2106
    invoke-virtual {v9, v7, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 2107
    .line 2108
    .line 2109
    const-string v0, "has_incomplete_message"

    .line 2110
    .line 2111
    invoke-virtual {v9, v0, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 2112
    .line 2113
    .line 2114
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2115
    .line 2116
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 2117
    .line 2118
    .line 2119
    move-object/from16 v1, v26

    .line 2120
    .line 2121
    invoke-static {v0, v11, v1, v12}, Lsqa;->a(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/String;

    .line 2122
    .line 2123
    .line 2124
    move-result-object v0

    .line 2125
    invoke-virtual {v9, v6, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 2126
    .line 2127
    .line 2128
    sget-object v0, Ldw;->a:Lnqa;

    .line 2129
    .line 2130
    const-string v1, "chat_continue_click"

    .line 2131
    .line 2132
    invoke-virtual {v0, v1, v9}, Lnqa;->p(Ljava/lang/String;Lorg/json/JSONObject;)V

    .line 2133
    .line 2134
    .line 2135
    invoke-virtual/range {p0 .. p0}, Lao1;->h()V

    .line 2136
    .line 2137
    .line 2138
    new-instance v0, Lln1;

    .line 2139
    .line 2140
    const/4 v5, 0x0

    .line 2141
    const/4 v6, 0x0

    .line 2142
    move-object/from16 v1, p0

    .line 2143
    .line 2144
    move-object/from16 v2, p1

    .line 2145
    .line 2146
    move-object/from16 v3, v16

    .line 2147
    .line 2148
    move-object/from16 v4, v19

    .line 2149
    .line 2150
    invoke-direct/range {v0 .. v6}, Lln1;-><init>(Lao1;Lwr;Lvq;Lpr8;Lhf2;I)V

    .line 2151
    .line 2152
    .line 2153
    const/4 v10, 0x3

    .line 2154
    const/4 v11, 0x0

    .line 2155
    const/4 v12, 0x0

    .line 2156
    invoke-static {v15, v12, v11, v0, v10}, Lv9a;->P(Lig2;Lag2;ILwv3;I)Lwr8;

    .line 2157
    .line 2158
    .line 2159
    return-void

    .line 2160
    :cond_49
    move-object v1, v12

    .line 2161
    move-object/from16 v2, v28

    .line 2162
    .line 2163
    instance-of v3, v0, Lan1;

    .line 2164
    .line 2165
    if-eqz v3, :cond_4b

    .line 2166
    .line 2167
    check-cast v0, Lan1;

    .line 2168
    .line 2169
    iget-object v3, v0, Lan1;->a:Lvq;

    .line 2170
    .line 2171
    invoke-virtual/range {p0 .. p0}, Lao1;->M()Lwr;

    .line 2172
    .line 2173
    .line 2174
    move-result-object v0

    .line 2175
    invoke-static {v0}, Ltga;->Q(Lwr;)Z

    .line 2176
    .line 2177
    .line 2178
    move-result v4

    .line 2179
    if-eqz v4, :cond_4a

    .line 2180
    .line 2181
    goto/16 :goto_1a

    .line 2182
    .line 2183
    :cond_4a
    new-instance v4, Lpr8;

    .line 2184
    .line 2185
    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    .line 2186
    .line 2187
    .line 2188
    move-result-object v5

    .line 2189
    invoke-virtual {v5}, Ljava/util/UUID;->toString()Ljava/lang/String;

    .line 2190
    .line 2191
    .line 2192
    move-result-object v5

    .line 2193
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 2194
    .line 2195
    .line 2196
    move-result-wide v7

    .line 2197
    invoke-direct {v4, v7, v8, v5}, Lpr8;-><init>(JLjava/lang/String;)V

    .line 2198
    .line 2199
    .line 2200
    iget-object v7, v0, Lwr;->a:Ljava/lang/String;

    .line 2201
    .line 2202
    invoke-virtual {v3}, Lvq;->x()I

    .line 2203
    .line 2204
    .line 2205
    move-result v8

    .line 2206
    invoke-static {v10, v8, v7, v9}, Los8;->z(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;

    .line 2207
    .line 2208
    .line 2209
    move-result-object v9

    .line 2210
    invoke-virtual {v9, v2, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 2211
    .line 2212
    .line 2213
    const-string v2, "resume_trigger"

    .line 2214
    .line 2215
    const-string v5, "button"

    .line 2216
    .line 2217
    invoke-virtual {v9, v2, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 2218
    .line 2219
    .line 2220
    new-instance v2, Ljava/lang/StringBuilder;

    .line 2221
    .line 2222
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 2223
    .line 2224
    .line 2225
    invoke-static {v2, v7, v1, v8}, Lsqa;->a(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/String;

    .line 2226
    .line 2227
    .line 2228
    move-result-object v1

    .line 2229
    invoke-virtual {v9, v6, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 2230
    .line 2231
    .line 2232
    sget-object v1, Ldw;->a:Lnqa;

    .line 2233
    .line 2234
    const-string v2, "message_resume"

    .line 2235
    .line 2236
    invoke-virtual {v1, v2, v9}, Lnqa;->p(Ljava/lang/String;Lorg/json/JSONObject;)V

    .line 2237
    .line 2238
    .line 2239
    move-object v2, v0

    .line 2240
    new-instance v0, Lln1;

    .line 2241
    .line 2242
    const/4 v5, 0x0

    .line 2243
    const/4 v6, 0x2

    .line 2244
    move-object/from16 v1, p0

    .line 2245
    .line 2246
    invoke-direct/range {v0 .. v6}, Lln1;-><init>(Lao1;Lwr;Lvq;Lpr8;Lhf2;I)V

    .line 2247
    .line 2248
    .line 2249
    const/4 v10, 0x3

    .line 2250
    const/4 v11, 0x0

    .line 2251
    const/4 v12, 0x0

    .line 2252
    invoke-static {v15, v12, v11, v0, v10}, Lv9a;->P(Lig2;Lag2;ILwv3;I)Lwr8;

    .line 2253
    .line 2254
    .line 2255
    return-void

    .line 2256
    :cond_4b
    move-object/from16 v1, p0

    .line 2257
    .line 2258
    instance-of v2, v0, Lsm1;

    .line 2259
    .line 2260
    if-eqz v2, :cond_54

    .line 2261
    .line 2262
    check-cast v0, Lsm1;

    .line 2263
    .line 2264
    iget-object v3, v0, Lsm1;->a:Li06;

    .line 2265
    .line 2266
    invoke-virtual {v1}, Lao1;->R()Lbf1;

    .line 2267
    .line 2268
    .line 2269
    move-result-object v2

    .line 2270
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2271
    .line 2272
    .line 2273
    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    .line 2274
    .line 2275
    .line 2276
    move-result v0

    .line 2277
    if-eqz v0, :cond_4d

    .line 2278
    .line 2279
    const/4 v1, 0x1

    .line 2280
    if-eq v0, v1, :cond_5a

    .line 2281
    .line 2282
    const/4 v4, 0x2

    .line 2283
    if-ne v0, v4, :cond_4c

    .line 2284
    .line 2285
    move v6, v1

    .line 2286
    const/4 v7, 0x0

    .line 2287
    goto :goto_17

    .line 2288
    :cond_4c
    invoke-static {}, Ld42;->d()V

    .line 2289
    .line 2290
    .line 2291
    return-void

    .line 2292
    :cond_4d
    const/4 v1, 0x1

    .line 2293
    move v7, v1

    .line 2294
    const/4 v6, 0x0

    .line 2295
    :goto_17
    iget-object v0, v2, Lbf1;->c:Lfc;

    .line 2296
    .line 2297
    invoke-virtual {v0}, Lfc;->v()Ljava/lang/Object;

    .line 2298
    .line 2299
    .line 2300
    move-result-object v0

    .line 2301
    move-object v4, v0

    .line 2302
    check-cast v4, Lwr;

    .line 2303
    .line 2304
    invoke-static {v4}, Ltga;->Q(Lwr;)Z

    .line 2305
    .line 2306
    .line 2307
    move-result v0

    .line 2308
    if-eqz v0, :cond_4e

    .line 2309
    .line 2310
    goto/16 :goto_1a

    .line 2311
    .line 2312
    :cond_4e
    iget-object v0, v2, Lbf1;->d:Lmm1;

    .line 2313
    .line 2314
    invoke-virtual {v0}, Lmm1;->v()Ljava/lang/Object;

    .line 2315
    .line 2316
    .line 2317
    move-result-object v0

    .line 2318
    instance-of v5, v0, Lc06;

    .line 2319
    .line 2320
    if-eqz v5, :cond_4f

    .line 2321
    .line 2322
    check-cast v0, Lc06;

    .line 2323
    .line 2324
    move-object v5, v0

    .line 2325
    goto :goto_18

    .line 2326
    :cond_4f
    const/4 v5, 0x0

    .line 2327
    :goto_18
    if-nez v5, :cond_50

    .line 2328
    .line 2329
    goto/16 :goto_1a

    .line 2330
    .line 2331
    :cond_50
    iget-object v0, v2, Lbf1;->h:Lrs8;

    .line 2332
    .line 2333
    invoke-virtual {v0}, Lrs8;->getValue()Ljava/lang/Object;

    .line 2334
    .line 2335
    .line 2336
    move-result-object v0

    .line 2337
    instance-of v0, v0, Ldz5;

    .line 2338
    .line 2339
    if-nez v0, :cond_52

    .line 2340
    .line 2341
    iget-object v0, v2, Lbf1;->i:Lrs8;

    .line 2342
    .line 2343
    invoke-virtual {v0}, Lrs8;->getValue()Ljava/lang/Object;

    .line 2344
    .line 2345
    .line 2346
    move-result-object v0

    .line 2347
    instance-of v0, v0, Lgz5;

    .line 2348
    .line 2349
    if-eqz v0, :cond_51

    .line 2350
    .line 2351
    goto :goto_19

    .line 2352
    :cond_51
    const/4 v1, 0x0

    .line 2353
    :cond_52
    :goto_19
    if-eqz v1, :cond_53

    .line 2354
    .line 2355
    goto/16 :goto_1a

    .line 2356
    .line 2357
    :cond_53
    iget-object v0, v2, Lbf1;->b:Lig2;

    .line 2358
    .line 2359
    new-instance v1, Lad0;

    .line 2360
    .line 2361
    const/4 v8, 0x0

    .line 2362
    invoke-direct/range {v1 .. v8}, Lad0;-><init>(Lbf1;Li06;Lwr;Lc06;ZZLhf2;)V

    .line 2363
    .line 2364
    .line 2365
    const/4 v10, 0x3

    .line 2366
    const/4 v11, 0x0

    .line 2367
    const/4 v12, 0x0

    .line 2368
    invoke-static {v0, v12, v11, v1, v10}, Lv9a;->P(Lig2;Lag2;ILwv3;I)Lwr8;

    .line 2369
    .line 2370
    .line 2371
    return-void

    .line 2372
    :cond_54
    instance-of v2, v0, Len1;

    .line 2373
    .line 2374
    if-eqz v2, :cond_56

    .line 2375
    .line 2376
    new-instance v3, Luy5;

    .line 2377
    .line 2378
    check-cast v0, Len1;

    .line 2379
    .line 2380
    iget-object v2, v0, Len1;->a:Lvq;

    .line 2381
    .line 2382
    invoke-virtual {v2}, Lvq;->r()Ljava/lang/String;

    .line 2383
    .line 2384
    .line 2385
    move-result-object v4

    .line 2386
    invoke-virtual {v2}, Lvq;->q()Ljava/util/List;

    .line 2387
    .line 2388
    .line 2389
    move-result-object v5

    .line 2390
    invoke-virtual {v1}, Lao1;->M()Lwr;

    .line 2391
    .line 2392
    .line 2393
    move-result-object v2

    .line 2394
    invoke-virtual {v2}, Lwr;->h()Ljava/lang/String;

    .line 2395
    .line 2396
    .line 2397
    move-result-object v2

    .line 2398
    if-nez v2, :cond_55

    .line 2399
    .line 2400
    invoke-virtual {v1}, Lao1;->N()Ljava/lang/String;

    .line 2401
    .line 2402
    .line 2403
    move-result-object v2

    .line 2404
    :cond_55
    move-object v6, v2

    .line 2405
    iget-object v7, v0, Len1;->b:Ljava/lang/String;

    .line 2406
    .line 2407
    new-instance v8, Lpr8;

    .line 2408
    .line 2409
    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    .line 2410
    .line 2411
    .line 2412
    move-result-object v0

    .line 2413
    invoke-virtual {v0}, Ljava/util/UUID;->toString()Ljava/lang/String;

    .line 2414
    .line 2415
    .line 2416
    move-result-object v0

    .line 2417
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 2418
    .line 2419
    .line 2420
    move-result-wide v9

    .line 2421
    invoke-direct {v8, v9, v10, v0}, Lpr8;-><init>(JLjava/lang/String;)V

    .line 2422
    .line 2423
    .line 2424
    invoke-direct/range {v3 .. v8}, Luy5;-><init>(Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Lpr8;)V

    .line 2425
    .line 2426
    .line 2427
    new-instance v0, Lld0;

    .line 2428
    .line 2429
    const/16 v2, 0x1c

    .line 2430
    .line 2431
    invoke-direct {v0, v2}, Lld0;-><init>(I)V

    .line 2432
    .line 2433
    .line 2434
    iget-object v2, v1, Lao1;->h:Lxv3;

    .line 2435
    .line 2436
    invoke-interface {v2, v1, v3, v0}, Lxv3;->f(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 2437
    .line 2438
    .line 2439
    return-void

    .line 2440
    :cond_56
    instance-of v2, v0, Lxm1;

    .line 2441
    .line 2442
    if-eqz v2, :cond_57

    .line 2443
    .line 2444
    check-cast v0, Lxm1;

    .line 2445
    .line 2446
    iget-object v0, v0, Lxm1;->a:Lvq;

    .line 2447
    .line 2448
    invoke-virtual {v1}, Lao1;->M()Lwr;

    .line 2449
    .line 2450
    .line 2451
    move-result-object v1

    .line 2452
    move-object/from16 v2, v22

    .line 2453
    .line 2454
    invoke-virtual {v2, v0, v1}, Lfg1;->n(Lvq;Lwr;)V

    .line 2455
    .line 2456
    .line 2457
    return-void

    .line 2458
    :cond_57
    move-object/from16 v2, v22

    .line 2459
    .line 2460
    sget-object v3, Lum1;->c:Lum1;

    .line 2461
    .line 2462
    invoke-static {v0, v3}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 2463
    .line 2464
    .line 2465
    move-result v3

    .line 2466
    if-eqz v3, :cond_58

    .line 2467
    .line 2468
    const-string v0, "user_cancelled"

    .line 2469
    .line 2470
    invoke-virtual {v2, v0}, Lfg1;->o(Ljava/lang/String;)V

    .line 2471
    .line 2472
    .line 2473
    return-void

    .line 2474
    :cond_58
    move-object/from16 v2, v21

    .line 2475
    .line 2476
    invoke-static {v0, v2}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 2477
    .line 2478
    .line 2479
    move-result v3

    .line 2480
    if-eqz v3, :cond_59

    .line 2481
    .line 2482
    new-instance v0, Lom1;

    .line 2483
    .line 2484
    const/4 v2, 0x5

    .line 2485
    const/4 v12, 0x0

    .line 2486
    invoke-direct {v0, v1, v12, v2}, Lom1;-><init>(Lao1;Lhf2;I)V

    .line 2487
    .line 2488
    .line 2489
    const/4 v10, 0x3

    .line 2490
    const/4 v11, 0x0

    .line 2491
    invoke-static {v15, v12, v11, v0, v10}, Lv9a;->P(Lig2;Lag2;ILwv3;I)Lwr8;

    .line 2492
    .line 2493
    .line 2494
    return-void

    .line 2495
    :cond_59
    instance-of v3, v0, Lgn1;

    .line 2496
    .line 2497
    if-eqz v3, :cond_5b

    .line 2498
    .line 2499
    invoke-virtual {v1}, Lao1;->P()Z

    .line 2500
    .line 2501
    .line 2502
    move-result v2

    .line 2503
    if-nez v2, :cond_5a

    .line 2504
    .line 2505
    invoke-virtual {v1}, Lao1;->O()Llb1;

    .line 2506
    .line 2507
    .line 2508
    move-result-object v1

    .line 2509
    check-cast v0, Lgn1;

    .line 2510
    .line 2511
    iget-object v2, v0, Lgn1;->a:Lvq;

    .line 2512
    .line 2513
    iget-boolean v0, v0, Lgn1;->b:Z

    .line 2514
    .line 2515
    iget-object v1, v1, Llb1;->e:Lrs8;

    .line 2516
    .line 2517
    new-instance v3, Lqy5;

    .line 2518
    .line 2519
    invoke-direct {v3, v2, v0}, Lqy5;-><init>(Lvq;Z)V

    .line 2520
    .line 2521
    .line 2522
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2523
    .line 2524
    .line 2525
    const/4 v12, 0x0

    .line 2526
    invoke-virtual {v1, v12, v3}, Lrs8;->m(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 2527
    .line 2528
    .line 2529
    :cond_5a
    :goto_1a
    return-void

    .line 2530
    :cond_5b
    const/4 v12, 0x0

    .line 2531
    sget-object v3, Lum1;->a:Lum1;

    .line 2532
    .line 2533
    invoke-static {v0, v3}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 2534
    .line 2535
    .line 2536
    move-result v3

    .line 2537
    if-eqz v3, :cond_5c

    .line 2538
    .line 2539
    invoke-virtual {v1}, Lao1;->O()Llb1;

    .line 2540
    .line 2541
    .line 2542
    move-result-object v0

    .line 2543
    iget-object v0, v0, Llb1;->e:Lrs8;

    .line 2544
    .line 2545
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2546
    .line 2547
    .line 2548
    sget-object v1, Lpy5;->a:Lpy5;

    .line 2549
    .line 2550
    invoke-virtual {v0, v12, v1}, Lrs8;->m(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 2551
    .line 2552
    .line 2553
    return-void

    .line 2554
    :cond_5c
    invoke-static {v0, v2}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 2555
    .line 2556
    .line 2557
    move-result v0

    .line 2558
    if-eqz v0, :cond_5d

    .line 2559
    .line 2560
    new-instance v0, Lom1;

    .line 2561
    .line 2562
    const/4 v2, 0x6

    .line 2563
    invoke-direct {v0, v1, v12, v2}, Lom1;-><init>(Lao1;Lhf2;I)V

    .line 2564
    .line 2565
    .line 2566
    const/4 v10, 0x3

    .line 2567
    const/4 v11, 0x0

    .line 2568
    invoke-static {v15, v12, v11, v0, v10}, Lv9a;->P(Lig2;Lag2;ILwv3;I)Lwr8;

    .line 2569
    .line 2570
    .line 2571
    return-void

    .line 2572
    :cond_5d
    invoke-static {}, Ld42;->d()V

    .line 2573
    .line 2574
    .line 2575
    return-void
.end method

.method public final K(Lkn1;)V
    .locals 3

    .line 1
    invoke-virtual {p0}, Lao1;->M()Lwr;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-static {v0}, Ltga;->Q(Lwr;)Z

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    if-eqz v1, :cond_0

    .line 10
    .line 11
    return-void

    .line 12
    :cond_0
    if-eqz p1, :cond_1

    .line 13
    .line 14
    new-instance v1, Lwi1;

    .line 15
    .line 16
    const/4 v2, 0x0

    .line 17
    invoke-direct {v1, p0, v0, p1, v2}, Lwi1;-><init>(Lao1;Lwr;Lkn1;Lhf2;)V

    .line 18
    .line 19
    .line 20
    const/4 p1, 0x3

    .line 21
    const/4 v0, 0x0

    .line 22
    iget-object p0, p0, Lao1;->k:Lbs0;

    .line 23
    .line 24
    invoke-static {p0, v2, v0, v1, p1}, Lv9a;->P(Lig2;Lag2;ILwv3;I)Lwr8;

    .line 25
    .line 26
    .line 27
    return-void

    .line 28
    :cond_1
    invoke-static {}, Ld42;->d()V

    .line 29
    .line 30
    .line 31
    return-void
.end method

.method public final L()Lv56;
    .locals 0

    .line 1
    iget-object p0, p0, Lao1;->y:Lgh7;

    .line 2
    .line 3
    iget-object p0, p0, Lgh7;->a:Lps8;

    .line 4
    .line 5
    invoke-interface {p0}, Lps8;->getValue()Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    check-cast p0, Lv56;

    .line 10
    .line 11
    return-object p0
.end method

.method public final M()Lwr;
    .locals 0

    .line 1
    iget-object p0, p0, Lao1;->v:Lrs8;

    .line 2
    .line 3
    invoke-virtual {p0}, Lrs8;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Lho1;

    .line 8
    .line 9
    invoke-interface {p0}, Lho1;->b()Lwr;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    return-object p0
.end method

.method public final N()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lao1;->m:Lz09;

    .line 2
    .line 3
    invoke-virtual {p0}, Lz09;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Ljava/lang/String;

    .line 8
    .line 9
    return-object p0
.end method

.method public final O()Llb1;
    .locals 0

    .line 1
    iget-object p0, p0, Lao1;->t:Lz09;

    .line 2
    .line 3
    invoke-virtual {p0}, Lz09;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Llb1;

    .line 8
    .line 9
    return-object p0
.end method

.method public final P()Z
    .locals 3

    .line 1
    iget-object v0, p0, Lao1;->r:Lxg1;

    .line 2
    .line 3
    iget-object v1, v0, Lxg1;->b:Lrs8;

    .line 4
    .line 5
    invoke-virtual {v1}, Lrs8;->getValue()Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    sget-object v2, Ls99;->a:Ls99;

    .line 10
    .line 11
    invoke-static {v1, v2}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    if-eqz v1, :cond_1

    .line 16
    .line 17
    iget-object v0, v0, Lxg1;->c:Lrs8;

    .line 18
    .line 19
    invoke-virtual {v0}, Lrs8;->getValue()Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    sget-object v1, Lq28;->a:Lq28;

    .line 24
    .line 25
    invoke-static {v0, v1}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    if-eqz v0, :cond_1

    .line 30
    .line 31
    invoke-virtual {p0}, Lao1;->O()Llb1;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    iget-object v0, v0, Llb1;->f:Lgh7;

    .line 36
    .line 37
    iget-object v0, v0, Lgh7;->a:Lps8;

    .line 38
    .line 39
    invoke-interface {v0}, Lps8;->getValue()Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    sget-object v1, Lpy5;->a:Lpy5;

    .line 44
    .line 45
    invoke-static {v0, v1}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    if-eqz v0, :cond_1

    .line 50
    .line 51
    invoke-virtual {p0}, Lao1;->Q()Loc1;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    iget-object v0, v0, Loc1;->l:Lrs8;

    .line 56
    .line 57
    invoke-virtual {v0}, Lrs8;->getValue()Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    sget-object v1, Lgy5;->a:Lgy5;

    .line 62
    .line 63
    invoke-static {v0, v1}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 64
    .line 65
    .line 66
    move-result v0

    .line 67
    if-eqz v0, :cond_1

    .line 68
    .line 69
    iget-object p0, p0, Lao1;->B:Lrs8;

    .line 70
    .line 71
    invoke-virtual {p0}, Lrs8;->getValue()Ljava/lang/Object;

    .line 72
    .line 73
    .line 74
    move-result-object p0

    .line 75
    sget-object v0, Le06;->a:Le06;

    .line 76
    .line 77
    invoke-static {p0, v0}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 78
    .line 79
    .line 80
    move-result p0

    .line 81
    if-nez p0, :cond_0

    .line 82
    .line 83
    goto :goto_0

    .line 84
    :cond_0
    const/4 p0, 0x0

    .line 85
    return p0

    .line 86
    :cond_1
    :goto_0
    const/4 p0, 0x1

    .line 87
    return p0
.end method

.method public final Q()Loc1;
    .locals 0

    .line 1
    iget-object p0, p0, Lao1;->p:Lz09;

    .line 2
    .line 3
    invoke-virtual {p0}, Lz09;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Loc1;

    .line 8
    .line 9
    return-object p0
.end method

.method public final R()Lbf1;
    .locals 0

    .line 1
    iget-object p0, p0, Lao1;->s:Lz09;

    .line 2
    .line 3
    invoke-virtual {p0}, Lz09;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Lbf1;

    .line 8
    .line 9
    return-object p0
.end method

.method public final S(Ld21;Lc11;)V
    .locals 11

    .line 1
    iget-object v0, p0, Lao1;->C:Lz09;

    .line 2
    .line 3
    invoke-virtual {v0}, Lz09;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Ld11;

    .line 8
    .line 9
    iget-object v1, v0, Ld11;->a:Landroid/content/Context;

    .line 10
    .line 11
    iget-boolean v2, p2, Lc11;->b:Z

    .line 12
    .line 13
    iget-object p0, p0, Lao1;->D:Lvta;

    .line 14
    .line 15
    if-eqz v2, :cond_0

    .line 16
    .line 17
    instance-of p2, p1, Lc21;

    .line 18
    .line 19
    if-eqz p2, :cond_7

    .line 20
    .line 21
    check-cast p1, Lc21;

    .line 22
    .line 23
    iget-object p2, p1, Lc21;->a:Llg6;

    .line 24
    .line 25
    instance-of v1, p2, Lig6;

    .line 26
    .line 27
    if-eqz v1, :cond_7

    .line 28
    .line 29
    check-cast p2, Lig6;

    .line 30
    .line 31
    iget-boolean p1, p1, Lc21;->b:Z

    .line 32
    .line 33
    invoke-virtual {v0, p2, p1, p0}, Ld11;->a(Lig6;ZLvta;)V

    .line 34
    .line 35
    .line 36
    return-void

    .line 37
    :cond_0
    instance-of v2, p1, Lc21;

    .line 38
    .line 39
    const/4 v3, 0x6

    .line 40
    const/4 v4, 0x3

    .line 41
    const/4 v5, 0x0

    .line 42
    if-eqz v2, :cond_8

    .line 43
    .line 44
    check-cast p1, Lc21;

    .line 45
    .line 46
    iget-object v2, p1, Lc21;->c:Ljava/util/Set;

    .line 47
    .line 48
    iget-object v6, p1, Lc21;->a:Llg6;

    .line 49
    .line 50
    iget-boolean v7, p1, Lc21;->b:Z

    .line 51
    .line 52
    instance-of v8, v6, Leg6;

    .line 53
    .line 54
    if-eqz v8, :cond_2

    .line 55
    .line 56
    move-object p2, v6

    .line 57
    check-cast p2, Leg6;

    .line 58
    .line 59
    iget-object p2, p2, Leg6;->b:Ljava/lang/Object;

    .line 60
    .line 61
    move-object v9, p2

    .line 62
    check-cast v9, Lyz0;

    .line 63
    .line 64
    instance-of v9, v9, Lwz0;

    .line 65
    .line 66
    if-eqz v9, :cond_6

    .line 67
    .line 68
    check-cast p2, Lwz0;

    .line 69
    .line 70
    iget-object p2, p2, Lwz0;->a:Lx01;

    .line 71
    .line 72
    iget-object p2, p2, Lx01;->b:Ljava/lang/Double;

    .line 73
    .line 74
    iget-object v0, v0, Ld11;->b:Lgy;

    .line 75
    .line 76
    iget-object v0, v0, Lgy;->i:Lrs8;

    .line 77
    .line 78
    :cond_1
    invoke-virtual {v0}, Lrs8;->getValue()Ljava/lang/Object;

    .line 79
    .line 80
    .line 81
    move-result-object v9

    .line 82
    move-object v10, v9

    .line 83
    check-cast v10, Lat9;

    .line 84
    .line 85
    new-instance v10, Lat9;

    .line 86
    .line 87
    invoke-direct {v10, p2}, Lat9;-><init>(Ljava/lang/Double;)V

    .line 88
    .line 89
    .line 90
    invoke-virtual {v0, v9, v10}, Lrs8;->j(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 91
    .line 92
    .line 93
    move-result v9

    .line 94
    if-eqz v9, :cond_1

    .line 95
    .line 96
    goto :goto_0

    .line 97
    :cond_2
    instance-of v9, v6, Lig6;

    .line 98
    .line 99
    if-eqz v9, :cond_3

    .line 100
    .line 101
    move-object p2, v6

    .line 102
    check-cast p2, Lig6;

    .line 103
    .line 104
    invoke-virtual {v0, p2, v7, p0}, Ld11;->a(Lig6;ZLvta;)V

    .line 105
    .line 106
    .line 107
    goto :goto_0

    .line 108
    :cond_3
    instance-of v0, v6, Lgg6;

    .line 109
    .line 110
    if-eqz v0, :cond_6

    .line 111
    .line 112
    if-nez v7, :cond_4

    .line 113
    .line 114
    goto/16 :goto_1

    .line 115
    .line 116
    :cond_4
    move-object v0, v6

    .line 117
    check-cast v0, Lgg6;

    .line 118
    .line 119
    iget-object v9, v0, Lgg6;->a:Lcg6;

    .line 120
    .line 121
    instance-of v9, v9, Lxf6;

    .line 122
    .line 123
    if-eqz v9, :cond_5

    .line 124
    .line 125
    iget-boolean p2, p2, Lc11;->a:Z

    .line 126
    .line 127
    if-eqz p2, :cond_6

    .line 128
    .line 129
    invoke-static {v0, v1}, Lhe5;->W0(Lgg6;Landroid/content/Context;)Ljava/lang/String;

    .line 130
    .line 131
    .line 132
    move-result-object p2

    .line 133
    iget-object v0, p0, Lvta;->a:Ljava/lang/Object;

    .line 134
    .line 135
    check-cast v0, Lao1;

    .line 136
    .line 137
    new-instance v9, Ltv;

    .line 138
    .line 139
    invoke-direct {v9, p2, v3}, Ltv;-><init>(Ljava/lang/String;I)V

    .line 140
    .line 141
    .line 142
    invoke-static {v0, v9}, Luia;->S(Lk55;Lsv3;)V

    .line 143
    .line 144
    .line 145
    goto :goto_0

    .line 146
    :cond_5
    invoke-static {v0, v1}, Lhe5;->W0(Lgg6;Landroid/content/Context;)Ljava/lang/String;

    .line 147
    .line 148
    .line 149
    move-result-object p2

    .line 150
    iget-object v0, p0, Lvta;->a:Ljava/lang/Object;

    .line 151
    .line 152
    check-cast v0, Lao1;

    .line 153
    .line 154
    new-instance v9, Ltv;

    .line 155
    .line 156
    invoke-direct {v9, p2, v3}, Ltv;-><init>(Ljava/lang/String;I)V

    .line 157
    .line 158
    .line 159
    invoke-static {v0, v9}, Luia;->S(Lk55;Lsv3;)V

    .line 160
    .line 161
    .line 162
    :cond_6
    :goto_0
    if-eqz v7, :cond_7

    .line 163
    .line 164
    if-eqz v8, :cond_7

    .line 165
    .line 166
    check-cast v6, Leg6;

    .line 167
    .line 168
    iget-object p2, v6, Leg6;->b:Ljava/lang/Object;

    .line 169
    .line 170
    instance-of p2, p2, Lxz0;

    .line 171
    .line 172
    if-eqz p2, :cond_7

    .line 173
    .line 174
    new-instance p2, Lfw8;

    .line 175
    .line 176
    invoke-direct {p2, v5}, Lfw8;-><init>(Ljava/lang/String;)V

    .line 177
    .line 178
    .line 179
    invoke-interface {v2, p2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 180
    .line 181
    .line 182
    move-result p2

    .line 183
    if-nez p2, :cond_7

    .line 184
    .line 185
    new-instance p2, Lfw8;

    .line 186
    .line 187
    const-string v0, "toast"

    .line 188
    .line 189
    invoke-direct {p2, v0}, Lfw8;-><init>(Ljava/lang/String;)V

    .line 190
    .line 191
    .line 192
    invoke-interface {v2, p2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 193
    .line 194
    .line 195
    move-result p2

    .line 196
    if-nez p2, :cond_7

    .line 197
    .line 198
    new-instance p2, Lfw8;

    .line 199
    .line 200
    const-string v0, "hint"

    .line 201
    .line 202
    invoke-direct {p2, v0}, Lfw8;-><init>(Ljava/lang/String;)V

    .line 203
    .line 204
    .line 205
    invoke-interface {v2, p2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 206
    .line 207
    .line 208
    move-result p2

    .line 209
    if-nez p2, :cond_7

    .line 210
    .line 211
    iget-boolean p1, p1, Lc21;->d:Z

    .line 212
    .line 213
    if-nez p1, :cond_7

    .line 214
    .line 215
    const p1, 0x7f0f0131

    .line 216
    .line 217
    .line 218
    invoke-virtual {v1, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 219
    .line 220
    .line 221
    move-result-object p1

    .line 222
    iget-object p0, p0, Lvta;->a:Ljava/lang/Object;

    .line 223
    .line 224
    check-cast p0, Lao1;

    .line 225
    .line 226
    new-instance p2, Ltv;

    .line 227
    .line 228
    invoke-direct {p2, p1, v3}, Ltv;-><init>(Ljava/lang/String;I)V

    .line 229
    .line 230
    .line 231
    invoke-static {v4, p2, p0, v5}, Luia;->R(ILsv3;Lk55;Ljava/lang/String;)V

    .line 232
    .line 233
    .line 234
    :cond_7
    :goto_1
    return-void

    .line 235
    :cond_8
    instance-of p2, p1, Lb21;

    .line 236
    .line 237
    if-eqz p2, :cond_9

    .line 238
    .line 239
    const p1, 0x7f0f009f

    .line 240
    .line 241
    .line 242
    invoke-virtual {v1, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 243
    .line 244
    .line 245
    move-result-object p1

    .line 246
    iget-object p0, p0, Lvta;->a:Ljava/lang/Object;

    .line 247
    .line 248
    check-cast p0, Lao1;

    .line 249
    .line 250
    new-instance p2, Ltv;

    .line 251
    .line 252
    invoke-direct {p2, p1, v3}, Ltv;-><init>(Ljava/lang/String;I)V

    .line 253
    .line 254
    .line 255
    invoke-static {v4, p2, p0, v5}, Luia;->R(ILsv3;Lk55;Ljava/lang/String;)V

    .line 256
    .line 257
    .line 258
    return-void

    .line 259
    :cond_9
    instance-of p0, p1, La21;

    .line 260
    .line 261
    if-eqz p0, :cond_a

    .line 262
    .line 263
    return-void

    .line 264
    :cond_a
    invoke-static {}, Ld42;->d()V

    .line 265
    .line 266
    .line 267
    return-void
.end method

.method public final W()V
    .locals 1

    .line 1
    iget-object p0, p0, Lao1;->j:Lxe1;

    .line 2
    .line 3
    const/4 v0, 0x0

    .line 4
    iput-object v0, p0, Lxe1;->j:Lld1;

    .line 5
    .line 6
    return-void
.end method

.method public final X()V
    .locals 3

    .line 1
    const-class p0, Ldo8;

    .line 2
    .line 3
    const/4 v0, 0x0

    .line 4
    invoke-static {}, Ltga;->I()Lcj;

    .line 5
    .line 6
    .line 7
    move-result-object v1

    .line 8
    iget-object v1, v1, Lcj;->a:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v1, Lqra;

    .line 11
    .line 12
    iget-object v1, v1, Lqra;->e:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast v1, Li08;

    .line 15
    .line 16
    sget-object v2, Lan7;->a:Lbn7;

    .line 17
    .line 18
    invoke-virtual {v2, p0}, Lbn7;->b(Ljava/lang/Class;)Lf15;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    invoke-virtual {v1, p0, v0, v0}, Li08;->b(Lf15;Lev6;Lmf7;)Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object p0

    .line 26
    check-cast p0, Ldo8;

    .line 27
    .line 28
    new-instance v1, Lsi1;

    .line 29
    .line 30
    const/16 v2, 0x12

    .line 31
    .line 32
    invoke-direct {v1, v2}, Lsi1;-><init>(I)V

    .line 33
    .line 34
    .line 35
    const/4 v2, 0x3

    .line 36
    invoke-static {p0, v0, v1, v2}, Ldo8;->a(Ldo8;Ljava/lang/String;Lsv3;I)V

    .line 37
    .line 38
    .line 39
    return-void
.end method

.method public final Y(Ljava/lang/String;)V
    .locals 8

    .line 1
    invoke-virtual {p0}, Lao1;->M()Lwr;

    .line 2
    .line 3
    .line 4
    move-result-object v4

    .line 5
    invoke-static {v4}, Ltga;->Q(Lwr;)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    return-void

    .line 12
    :cond_0
    const-string v0, "stop_button"

    .line 13
    .line 14
    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    const/4 v2, 0x0

    .line 19
    const/4 v6, 0x0

    .line 20
    if-eqz v0, :cond_6

    .line 21
    .line 22
    iget-object v0, v4, Lwr;->q:Ljava/util/HashMap;

    .line 23
    .line 24
    invoke-virtual {v0}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    check-cast v0, Ljava/lang/Iterable;

    .line 29
    .line 30
    move-object v1, v0

    .line 31
    check-cast v1, Ljava/util/Collection;

    .line 32
    .line 33
    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    .line 34
    .line 35
    .line 36
    move-result v1

    .line 37
    if-eqz v1, :cond_1

    .line 38
    .line 39
    move v1, v6

    .line 40
    goto :goto_1

    .line 41
    :cond_1
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    move v1, v6

    .line 46
    :cond_2
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 47
    .line 48
    .line 49
    move-result v3

    .line 50
    if-eqz v3, :cond_4

    .line 51
    .line 52
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    move-result-object v3

    .line 56
    check-cast v3, Lhv1;

    .line 57
    .line 58
    iget-object v3, v3, Lhv1;->c:Lgv1;

    .line 59
    .line 60
    instance-of v3, v3, Lfv1;

    .line 61
    .line 62
    if-nez v3, :cond_2

    .line 63
    .line 64
    add-int/lit8 v1, v1, 0x1

    .line 65
    .line 66
    if-ltz v1, :cond_3

    .line 67
    .line 68
    goto :goto_0

    .line 69
    :cond_3
    invoke-static {}, Lfya;->q0()V

    .line 70
    .line 71
    .line 72
    throw v2

    .line 73
    :cond_4
    :goto_1
    iget-object v0, v4, Lwr;->a:Ljava/lang/String;

    .line 74
    .line 75
    invoke-virtual {v4}, Lwr;->y()Ljava/lang/Integer;

    .line 76
    .line 77
    .line 78
    move-result-object v3

    .line 79
    if-eqz v3, :cond_5

    .line 80
    .line 81
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 82
    .line 83
    .line 84
    move-result v3

    .line 85
    goto :goto_2

    .line 86
    :cond_5
    move v3, v6

    .line 87
    :goto_2
    const-string v5, "chat_session_id"

    .line 88
    .line 89
    const-string v7, "chat_message_id"

    .line 90
    .line 91
    invoke-static {v5, v3, v0, v7}, Los8;->z(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;

    .line 92
    .line 93
    .line 94
    move-result-object v5

    .line 95
    const-string v7, "is_pending_stop"

    .line 96
    .line 97
    invoke-virtual {v5, v7, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 98
    .line 99
    .line 100
    const-string v7, "stop_msg_cnt"

    .line 101
    .line 102
    invoke-virtual {v5, v7, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 103
    .line 104
    .line 105
    new-instance v1, Ljava/lang/StringBuilder;

    .line 106
    .line 107
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 108
    .line 109
    .line 110
    const-string v7, ":"

    .line 111
    .line 112
    invoke-static {v1, v0, v7, v3}, Lsqa;->a(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/String;

    .line 113
    .line 114
    .line 115
    move-result-object v0

    .line 116
    const-string v1, "full_chat_message_id"

    .line 117
    .line 118
    invoke-virtual {v5, v1, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 119
    .line 120
    .line 121
    sget-object v0, Ldw;->a:Lnqa;

    .line 122
    .line 123
    const-string v1, "stop_button_click"

    .line 124
    .line 125
    invoke-virtual {v0, v1, v5}, Lnqa;->p(Ljava/lang/String;Lorg/json/JSONObject;)V

    .line 126
    .line 127
    .line 128
    :cond_6
    new-instance v0, Lwi1;

    .line 129
    .line 130
    const/4 v1, 0x3

    .line 131
    move-object v3, p0

    .line 132
    move-object v5, p1

    .line 133
    invoke-direct/range {v0 .. v5}, Lwi1;-><init>(ILhf2;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V

    .line 134
    .line 135
    .line 136
    const/4 p0, 0x3

    .line 137
    iget-object p1, v3, Lao1;->k:Lbs0;

    .line 138
    .line 139
    invoke-static {p1, v2, v6, v0, p0}, Lv9a;->P(Lig2;Lag2;ILwv3;I)Lwr8;

    .line 140
    .line 141
    .line 142
    return-void
.end method

.method public final a()Lah8;
    .locals 0

    .line 1
    invoke-virtual {p0}, Lao1;->Q()Loc1;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    iget-object p0, p0, Loc1;->k:Ldh8;

    .line 6
    .line 7
    return-object p0
.end method

.method public final b(Lcc1;)V
    .locals 6

    .line 1
    instance-of v0, p1, Lbc1;

    .line 2
    .line 3
    iget-object v1, p0, Lao1;->x:Ljd1;

    .line 4
    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    invoke-virtual {v1}, Ljd1;->a()Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    invoke-virtual {p0}, Lao1;->Q()Loc1;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    check-cast p1, Lbc1;

    .line 18
    .line 19
    iget-object v1, p1, Lbc1;->a:Ljava/util/List;

    .line 20
    .line 21
    iget p1, p1, Lbc1;->b:I

    .line 22
    .line 23
    invoke-virtual {p0}, Lao1;->M()Lwr;

    .line 24
    .line 25
    .line 26
    move-result-object p0

    .line 27
    iget-object p0, p0, Lwr;->a:Ljava/lang/String;

    .line 28
    .line 29
    invoke-virtual {v0, p1, p0, v1}, Loc1;->z(ILjava/lang/String;Ljava/util/List;)V

    .line 30
    .line 31
    .line 32
    return-void

    .line 33
    :cond_0
    invoke-virtual {p0}, Lao1;->X()V

    .line 34
    .line 35
    .line 36
    return-void

    .line 37
    :cond_1
    instance-of v0, p1, Lac1;

    .line 38
    .line 39
    const/4 v2, 0x0

    .line 40
    if-eqz v0, :cond_4

    .line 41
    .line 42
    invoke-virtual {v1}, Ljd1;->a()Z

    .line 43
    .line 44
    .line 45
    move-result v0

    .line 46
    if-eqz v0, :cond_3

    .line 47
    .line 48
    invoke-virtual {p0}, Lao1;->Q()Loc1;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    check-cast p1, Lac1;

    .line 53
    .line 54
    iget-object p1, p1, Lac1;->a:Lfa2;

    .line 55
    .line 56
    invoke-virtual {p0}, Lao1;->M()Lwr;

    .line 57
    .line 58
    .line 59
    move-result-object p0

    .line 60
    iget-object p0, p0, Lwr;->a:Ljava/lang/String;

    .line 61
    .line 62
    const/4 v1, 0x1

    .line 63
    invoke-virtual {v0, v1, v1, p0}, Loc1;->m(IILjava/lang/String;)I

    .line 64
    .line 65
    .line 66
    move-result v3

    .line 67
    if-nez v3, :cond_2

    .line 68
    .line 69
    return-void

    .line 70
    :cond_2
    invoke-virtual {v0, p1, v1, p0, v2}, Loc1;->u(Lfa2;ILjava/lang/String;Lz61;)V

    .line 71
    .line 72
    .line 73
    return-void

    .line 74
    :cond_3
    invoke-virtual {p0}, Lao1;->X()V

    .line 75
    .line 76
    .line 77
    return-void

    .line 78
    :cond_4
    instance-of v0, p1, Lyb1;

    .line 79
    .line 80
    if-eqz v0, :cond_6

    .line 81
    .line 82
    invoke-virtual {v1}, Ljd1;->a()Z

    .line 83
    .line 84
    .line 85
    move-result v0

    .line 86
    if-eqz v0, :cond_5

    .line 87
    .line 88
    invoke-virtual {p0}, Lao1;->Q()Loc1;

    .line 89
    .line 90
    .line 91
    move-result-object v0

    .line 92
    check-cast p1, Lyb1;

    .line 93
    .line 94
    iget-object v1, p1, Lyb1;->a:Ljava/lang/String;

    .line 95
    .line 96
    iget-object p1, p1, Lyb1;->b:Lfa2;

    .line 97
    .line 98
    invoke-virtual {p0}, Lao1;->M()Lwr;

    .line 99
    .line 100
    .line 101
    move-result-object p0

    .line 102
    iget-object p0, p0, Lwr;->a:Ljava/lang/String;

    .line 103
    .line 104
    invoke-virtual {v0, v1, p1, p0}, Loc1;->q(Ljava/lang/String;Lfa2;Ljava/lang/String;)V

    .line 105
    .line 106
    .line 107
    return-void

    .line 108
    :cond_5
    invoke-virtual {p0}, Lao1;->X()V

    .line 109
    .line 110
    .line 111
    return-void

    .line 112
    :cond_6
    instance-of v0, p1, Ltb1;

    .line 113
    .line 114
    if-eqz v0, :cond_7

    .line 115
    .line 116
    invoke-virtual {p0}, Lao1;->Q()Loc1;

    .line 117
    .line 118
    .line 119
    move-result-object p0

    .line 120
    check-cast p1, Ltb1;

    .line 121
    .line 122
    iget-object p1, p1, Ltb1;->a:Lz61;

    .line 123
    .line 124
    invoke-virtual {p0, p1}, Loc1;->f(Lz61;)V

    .line 125
    .line 126
    .line 127
    return-void

    .line 128
    :cond_7
    instance-of v0, p1, Lzb1;

    .line 129
    .line 130
    if-eqz v0, :cond_8

    .line 131
    .line 132
    invoke-virtual {p0}, Lao1;->Q()Loc1;

    .line 133
    .line 134
    .line 135
    move-result-object p0

    .line 136
    check-cast p1, Lzb1;

    .line 137
    .line 138
    iget-object p1, p1, Lzb1;->a:Lz61;

    .line 139
    .line 140
    invoke-virtual {p0, p1}, Loc1;->s(Lz61;)V

    .line 141
    .line 142
    .line 143
    return-void

    .line 144
    :cond_8
    instance-of v0, p1, Lwb1;

    .line 145
    .line 146
    const/4 v1, 0x0

    .line 147
    const/4 v3, 0x3

    .line 148
    iget-object v4, p0, Lao1;->k:Lbs0;

    .line 149
    .line 150
    if-eqz v0, :cond_b

    .line 151
    .line 152
    move-object v0, p1

    .line 153
    check-cast v0, Lwb1;

    .line 154
    .line 155
    instance-of v5, v0, Lvb1;

    .line 156
    .line 157
    if-eqz v5, :cond_9

    .line 158
    .line 159
    check-cast p1, Lvb1;

    .line 160
    .line 161
    new-instance v0, Lre;

    .line 162
    .line 163
    const/4 v5, 0x7

    .line 164
    invoke-direct {v0, p1, p0, v2, v5}, Lre;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lhf2;I)V

    .line 165
    .line 166
    .line 167
    invoke-static {v4, v2, v1, v0, v3}, Lv9a;->P(Lig2;Lag2;ILwv3;I)Lwr8;

    .line 168
    .line 169
    .line 170
    return-void

    .line 171
    :cond_9
    instance-of v0, v0, Lub1;

    .line 172
    .line 173
    if-eqz v0, :cond_a

    .line 174
    .line 175
    invoke-virtual {p0}, Lao1;->t()V

    .line 176
    .line 177
    .line 178
    check-cast p1, Lub1;

    .line 179
    .line 180
    iget-object p1, p1, Lub1;->a:Ljava/lang/String;

    .line 181
    .line 182
    invoke-virtual {p0, p1}, Lao1;->F(Ljava/lang/String;)V

    .line 183
    .line 184
    .line 185
    return-void

    .line 186
    :cond_a
    invoke-static {}, Ld42;->d()V

    .line 187
    .line 188
    .line 189
    return-void

    .line 190
    :cond_b
    sget-object v0, Lsb1;->b:Lsb1;

    .line 191
    .line 192
    invoke-static {p1, v0}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 193
    .line 194
    .line 195
    move-result v0

    .line 196
    if-eqz v0, :cond_c

    .line 197
    .line 198
    new-instance p1, Lq50;

    .line 199
    .line 200
    invoke-direct {p1, p0, v2}, Lq50;-><init>(Lao1;Lhf2;)V

    .line 201
    .line 202
    .line 203
    invoke-static {v4, v2, v1, p1, v3}, Lv9a;->P(Lig2;Lag2;ILwv3;I)Lwr8;

    .line 204
    .line 205
    .line 206
    return-void

    .line 207
    :cond_c
    sget-object v0, Lsb1;->a:Lsb1;

    .line 208
    .line 209
    invoke-static {p1, v0}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 210
    .line 211
    .line 212
    move-result p1

    .line 213
    if-eqz p1, :cond_d

    .line 214
    .line 215
    invoke-virtual {p0}, Lao1;->h()V

    .line 216
    .line 217
    .line 218
    return-void

    .line 219
    :cond_d
    invoke-static {}, Ld42;->d()V

    .line 220
    .line 221
    .line 222
    return-void
.end method

.method public final c()Lps8;
    .locals 0

    .line 1
    iget-object p0, p0, Lao1;->r:Lxg1;

    .line 2
    .line 3
    iget-object p0, p0, Lxg1;->d:Lrs8;

    .line 4
    .line 5
    return-object p0
.end method

.method public final d()Lps8;
    .locals 0

    .line 1
    iget-object p0, p0, Lao1;->w:Lgh7;

    .line 2
    .line 3
    return-object p0
.end method

.method public final e()Ljava/lang/String;
    .locals 0

    .line 1
    invoke-virtual {p0}, Lao1;->M()Lwr;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    iget-object p0, p0, Lwr;->a:Ljava/lang/String;

    .line 6
    .line 7
    return-object p0
.end method

.method public final f()Ljd1;
    .locals 0

    .line 1
    iget-object p0, p0, Lao1;->x:Ljd1;

    .line 2
    .line 3
    return-object p0
.end method

.method public final g(Ltg1;)V
    .locals 16

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    instance-of v2, v1, Lrg1;

    .line 6
    .line 7
    const/4 v3, 0x3

    .line 8
    const/4 v4, 0x0

    .line 9
    iget-object v5, v0, Lao1;->k:Lbs0;

    .line 10
    .line 11
    const/4 v6, 0x0

    .line 12
    if-eqz v2, :cond_0

    .line 13
    .line 14
    new-instance v2, Lpn1;

    .line 15
    .line 16
    invoke-direct {v2, v0, v1, v6, v4}, Lpn1;-><init>(Lao1;Ltg1;Lhf2;I)V

    .line 17
    .line 18
    .line 19
    invoke-static {v5, v6, v4, v2, v3}, Lv9a;->P(Lig2;Lag2;ILwv3;I)Lwr8;

    .line 20
    .line 21
    .line 22
    return-void

    .line 23
    :cond_0
    instance-of v2, v1, Lpg1;

    .line 24
    .line 25
    const/4 v7, 0x1

    .line 26
    if-eqz v2, :cond_1

    .line 27
    .line 28
    new-instance v2, Lpn1;

    .line 29
    .line 30
    invoke-direct {v2, v0, v1, v6, v7}, Lpn1;-><init>(Lao1;Ltg1;Lhf2;I)V

    .line 31
    .line 32
    .line 33
    invoke-static {v5, v6, v4, v2, v3}, Lv9a;->P(Lig2;Lag2;ILwv3;I)Lwr8;

    .line 34
    .line 35
    .line 36
    return-void

    .line 37
    :cond_1
    instance-of v2, v1, Lng1;

    .line 38
    .line 39
    iget-object v8, v0, Lao1;->r:Lxg1;

    .line 40
    .line 41
    if-eqz v2, :cond_3

    .line 42
    .line 43
    iget-object v2, v8, Lxg1;->b:Lrs8;

    .line 44
    .line 45
    :cond_2
    invoke-virtual {v2}, Lrs8;->getValue()Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    move-object v1, v0

    .line 50
    check-cast v1, Lu99;

    .line 51
    .line 52
    sget-object v1, Ls99;->a:Ls99;

    .line 53
    .line 54
    invoke-virtual {v2, v0, v1}, Lrs8;->j(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    if-eqz v0, :cond_2

    .line 59
    .line 60
    goto/16 :goto_3

    .line 61
    .line 62
    :cond_3
    instance-of v2, v1, Lqg1;

    .line 63
    .line 64
    const/16 v9, 0x14

    .line 65
    .line 66
    if-eqz v2, :cond_4

    .line 67
    .line 68
    new-instance v2, Ll4;

    .line 69
    .line 70
    invoke-direct {v2, v0, v1, v6, v9}, Ll4;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lhf2;I)V

    .line 71
    .line 72
    .line 73
    invoke-static {v5, v6, v4, v2, v3}, Lv9a;->P(Lig2;Lag2;ILwv3;I)Lwr8;

    .line 74
    .line 75
    .line 76
    return-void

    .line 77
    :cond_4
    instance-of v2, v1, Lmg1;

    .line 78
    .line 79
    if-eqz v2, :cond_6

    .line 80
    .line 81
    iget-object v2, v8, Lxg1;->c:Lrs8;

    .line 82
    .line 83
    :cond_5
    invoke-virtual {v2}, Lrs8;->getValue()Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    move-result-object v0

    .line 87
    move-object v1, v0

    .line 88
    check-cast v1, Ls28;

    .line 89
    .line 90
    sget-object v1, Lq28;->a:Lq28;

    .line 91
    .line 92
    invoke-virtual {v2, v0, v1}, Lrs8;->j(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 93
    .line 94
    .line 95
    move-result v0

    .line 96
    if-eqz v0, :cond_5

    .line 97
    .line 98
    goto/16 :goto_3

    .line 99
    .line 100
    :cond_6
    instance-of v2, v1, Llg1;

    .line 101
    .line 102
    if-eqz v2, :cond_8

    .line 103
    .line 104
    invoke-virtual {v0}, Lao1;->R()Lbf1;

    .line 105
    .line 106
    .line 107
    move-result-object v0

    .line 108
    iget-object v1, v0, Lbf1;->i:Lrs8;

    .line 109
    .line 110
    invoke-virtual {v1}, Lrs8;->getValue()Ljava/lang/Object;

    .line 111
    .line 112
    .line 113
    move-result-object v1

    .line 114
    sget-object v2, Lfz5;->a:Lfz5;

    .line 115
    .line 116
    invoke-static {v1, v2}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 117
    .line 118
    .line 119
    move-result v1

    .line 120
    if-eqz v1, :cond_16

    .line 121
    .line 122
    iget-object v0, v0, Lbf1;->h:Lrs8;

    .line 123
    .line 124
    :cond_7
    invoke-virtual {v0}, Lrs8;->getValue()Ljava/lang/Object;

    .line 125
    .line 126
    .line 127
    move-result-object v1

    .line 128
    move-object v2, v1

    .line 129
    check-cast v2, Lez5;

    .line 130
    .line 131
    sget-object v2, Lbz5;->a:Lbz5;

    .line 132
    .line 133
    invoke-virtual {v0, v1, v2}, Lrs8;->j(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 134
    .line 135
    .line 136
    move-result v1

    .line 137
    if-eqz v1, :cond_7

    .line 138
    .line 139
    goto/16 :goto_3

    .line 140
    .line 141
    :cond_8
    instance-of v2, v1, Lkg1;

    .line 142
    .line 143
    iget-object v10, v0, Lao1;->A:Lrs8;

    .line 144
    .line 145
    if-eqz v2, :cond_10

    .line 146
    .line 147
    invoke-virtual {v0}, Lao1;->P()Z

    .line 148
    .line 149
    .line 150
    move-result v2

    .line 151
    if-nez v2, :cond_16

    .line 152
    .line 153
    invoke-virtual {v0}, Lao1;->M()Lwr;

    .line 154
    .line 155
    .line 156
    move-result-object v2

    .line 157
    invoke-static {v2}, Ltga;->Q(Lwr;)Z

    .line 158
    .line 159
    .line 160
    move-result v3

    .line 161
    if-eqz v3, :cond_9

    .line 162
    .line 163
    goto/16 :goto_3

    .line 164
    .line 165
    :cond_9
    check-cast v1, Lkg1;

    .line 166
    .line 167
    iget-object v3, v1, Lkg1;->a:Lvq;

    .line 168
    .line 169
    iget-object v7, v2, Lwr;->a:Ljava/lang/String;

    .line 170
    .line 171
    invoke-virtual {v3}, Lvq;->x()I

    .line 172
    .line 173
    .line 174
    move-result v8

    .line 175
    invoke-virtual {v3}, Lvq;->D()Ljava/lang/String;

    .line 176
    .line 177
    .line 178
    move-result-object v9

    .line 179
    invoke-static {v9}, Lh31;->b(Ljava/lang/String;)Ljava/lang/String;

    .line 180
    .line 181
    .line 182
    move-result-object v9

    .line 183
    invoke-virtual {v3}, Lvq;->D()Ljava/lang/String;

    .line 184
    .line 185
    .line 186
    move-result-object v11

    .line 187
    invoke-virtual {v3}, Lvq;->x()I

    .line 188
    .line 189
    .line 190
    move-result v12

    .line 191
    invoke-static {v2, v11, v12}, Loba;->O(Lwr;Ljava/lang/String;I)Z

    .line 192
    .line 193
    .line 194
    move-result v11

    .line 195
    iget-object v1, v1, Lkg1;->b:Ljava/lang/String;

    .line 196
    .line 197
    invoke-virtual {v3}, Lvq;->s()Lb41;

    .line 198
    .line 199
    .line 200
    move-result-object v12

    .line 201
    invoke-interface {v12}, Ljava/util/List;->size()I

    .line 202
    .line 203
    .line 204
    move-result v12

    .line 205
    invoke-virtual {v3}, Lvq;->s()Lb41;

    .line 206
    .line 207
    .line 208
    move-result-object v13

    .line 209
    new-instance v14, Ljava/util/ArrayList;

    .line 210
    .line 211
    invoke-direct {v14}, Ljava/util/ArrayList;-><init>()V

    .line 212
    .line 213
    .line 214
    invoke-interface {v13}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 215
    .line 216
    .line 217
    move-result-object v13

    .line 218
    :goto_0
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    .line 219
    .line 220
    .line 221
    move-result v15

    .line 222
    if-eqz v15, :cond_b

    .line 223
    .line 224
    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 225
    .line 226
    .line 227
    move-result-object v15

    .line 228
    move-object v6, v15

    .line 229
    check-cast v6, Lv81;

    .line 230
    .line 231
    instance-of v6, v6, Lqg0;

    .line 232
    .line 233
    if-nez v6, :cond_a

    .line 234
    .line 235
    invoke-virtual {v14, v15}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 236
    .line 237
    .line 238
    :cond_a
    const/4 v6, 0x0

    .line 239
    goto :goto_0

    .line 240
    :cond_b
    new-instance v6, Ljava/util/ArrayList;

    .line 241
    .line 242
    const/16 v13, 0xa

    .line 243
    .line 244
    invoke-static {v14, v13}, Lj32;->B0(Ljava/lang/Iterable;I)I

    .line 245
    .line 246
    .line 247
    move-result v13

    .line 248
    invoke-direct {v6, v13}, Ljava/util/ArrayList;-><init>(I)V

    .line 249
    .line 250
    .line 251
    invoke-virtual {v14}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 252
    .line 253
    .line 254
    move-result-object v13

    .line 255
    :goto_1
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    .line 256
    .line 257
    .line 258
    move-result v14

    .line 259
    if-eqz v14, :cond_c

    .line 260
    .line 261
    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 262
    .line 263
    .line 264
    move-result-object v14

    .line 265
    check-cast v14, Lv81;

    .line 266
    .line 267
    invoke-interface {v14}, Lv81;->e()Ljava/lang/String;

    .line 268
    .line 269
    .line 270
    move-result-object v14

    .line 271
    invoke-virtual {v6, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 272
    .line 273
    .line 274
    goto :goto_1

    .line 275
    :cond_c
    invoke-static {v6}, Li32;->D1(Ljava/lang/Iterable;)Ljava/util/Set;

    .line 276
    .line 277
    .line 278
    move-result-object v6

    .line 279
    check-cast v6, Ljava/util/Collection;

    .line 280
    .line 281
    new-array v13, v4, [Ljava/lang/String;

    .line 282
    .line 283
    invoke-interface {v6, v13}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 284
    .line 285
    .line 286
    move-result-object v6

    .line 287
    check-cast v6, [Ljava/lang/String;

    .line 288
    .line 289
    invoke-virtual {v2}, Lwr;->h()Ljava/lang/String;

    .line 290
    .line 291
    .line 292
    move-result-object v13

    .line 293
    if-nez v13, :cond_d

    .line 294
    .line 295
    invoke-virtual {v0}, Lao1;->N()Ljava/lang/String;

    .line 296
    .line 297
    .line 298
    move-result-object v13

    .line 299
    :cond_d
    const-string v0, "chat_session_id"

    .line 300
    .line 301
    const-string v14, "chat_message_id"

    .line 302
    .line 303
    invoke-static {v0, v8, v7, v14}, Los8;->z(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;

    .line 304
    .line 305
    .line 306
    move-result-object v0

    .line 307
    const-string v14, "chat_message_role"

    .line 308
    .line 309
    invoke-virtual {v0, v14, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 310
    .line 311
    .line 312
    const-string v9, "is_latest_round"

    .line 313
    .line 314
    invoke-virtual {v0, v9, v11}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 315
    .line 316
    .line 317
    const-string v9, "message_action_button_position"

    .line 318
    .line 319
    invoke-virtual {v0, v9, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 320
    .line 321
    .line 322
    const-string v1, "fragment_count"

    .line 323
    .line 324
    invoke-virtual {v0, v1, v12}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 325
    .line 326
    .line 327
    new-instance v1, Lorg/json/JSONArray;

    .line 328
    .line 329
    invoke-direct {v1}, Lorg/json/JSONArray;-><init>()V

    .line 330
    .line 331
    .line 332
    array-length v9, v6

    .line 333
    :goto_2
    if-ge v4, v9, :cond_e

    .line 334
    .line 335
    aget-object v11, v6, v4

    .line 336
    .line 337
    invoke-virtual {v1, v11}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    .line 338
    .line 339
    .line 340
    add-int/lit8 v4, v4, 0x1

    .line 341
    .line 342
    goto :goto_2

    .line 343
    :cond_e
    const-string v4, "fragment_types"

    .line 344
    .line 345
    invoke-virtual {v0, v4, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 346
    .line 347
    .line 348
    const-string v1, "model_type"

    .line 349
    .line 350
    invoke-virtual {v0, v1, v13}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 351
    .line 352
    .line 353
    new-instance v1, Ljava/lang/StringBuilder;

    .line 354
    .line 355
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 356
    .line 357
    .line 358
    const-string v4, ":"

    .line 359
    .line 360
    invoke-static {v1, v7, v4, v8}, Lsqa;->a(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/String;

    .line 361
    .line 362
    .line 363
    move-result-object v1

    .line 364
    const-string v4, "full_chat_message_id"

    .line 365
    .line 366
    invoke-virtual {v0, v4, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 367
    .line 368
    .line 369
    sget-object v1, Ldw;->a:Lnqa;

    .line 370
    .line 371
    const-string v4, "share_button_tap"

    .line 372
    .line 373
    invoke-virtual {v1, v4, v0}, Lnqa;->p(Ljava/lang/String;Lorg/json/JSONObject;)V

    .line 374
    .line 375
    .line 376
    invoke-virtual {v2}, Lwr;->x()Lhp8;

    .line 377
    .line 378
    .line 379
    move-result-object v0

    .line 380
    if-nez v0, :cond_f

    .line 381
    .line 382
    goto/16 :goto_3

    .line 383
    .line 384
    :cond_f
    new-instance v1, Lc06;

    .line 385
    .line 386
    invoke-direct {v1, v0, v5}, Lc06;-><init>(Lhp8;Lbs0;)V

    .line 387
    .line 388
    .line 389
    invoke-virtual {v1, v3}, Lc06;->c(Lvq;)V

    .line 390
    .line 391
    .line 392
    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 393
    .line 394
    .line 395
    const/4 v2, 0x0

    .line 396
    invoke-virtual {v10, v2, v1}, Lrs8;->m(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 397
    .line 398
    .line 399
    return-void

    .line 400
    :cond_10
    move-object v2, v6

    .line 401
    sget-object v5, Log1;->a:Log1;

    .line 402
    .line 403
    invoke-static {v1, v5}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 404
    .line 405
    .line 406
    move-result v5

    .line 407
    if-eqz v5, :cond_11

    .line 408
    .line 409
    invoke-virtual {v10}, Lrs8;->getValue()Ljava/lang/Object;

    .line 410
    .line 411
    .line 412
    move-result-object v0

    .line 413
    check-cast v0, Lf06;

    .line 414
    .line 415
    instance-of v0, v0, Lc06;

    .line 416
    .line 417
    if-eqz v0, :cond_16

    .line 418
    .line 419
    sget-object v0, Le06;->a:Le06;

    .line 420
    .line 421
    invoke-virtual {v10, v2, v0}, Lrs8;->m(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 422
    .line 423
    .line 424
    return-void

    .line 425
    :cond_11
    instance-of v2, v1, Lsg1;

    .line 426
    .line 427
    if-eqz v2, :cond_12

    .line 428
    .line 429
    invoke-virtual {v10}, Lrs8;->getValue()Ljava/lang/Object;

    .line 430
    .line 431
    .line 432
    move-result-object v0

    .line 433
    check-cast v0, Lf06;

    .line 434
    .line 435
    instance-of v2, v0, Lc06;

    .line 436
    .line 437
    if-eqz v2, :cond_16

    .line 438
    .line 439
    check-cast v0, Lc06;

    .line 440
    .line 441
    check-cast v1, Lsg1;

    .line 442
    .line 443
    iget-object v1, v1, Lsg1;->a:Lvq;

    .line 444
    .line 445
    invoke-virtual {v0, v1}, Lc06;->c(Lvq;)V

    .line 446
    .line 447
    .line 448
    return-void

    .line 449
    :cond_12
    sget-object v2, Log1;->c:Log1;

    .line 450
    .line 451
    invoke-static {v1, v2}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 452
    .line 453
    .line 454
    move-result v2

    .line 455
    if-eqz v2, :cond_17

    .line 456
    .line 457
    invoke-virtual {v10}, Lrs8;->getValue()Ljava/lang/Object;

    .line 458
    .line 459
    .line 460
    move-result-object v1

    .line 461
    check-cast v1, Lf06;

    .line 462
    .line 463
    instance-of v2, v1, Lc06;

    .line 464
    .line 465
    if-eqz v2, :cond_16

    .line 466
    .line 467
    check-cast v1, Lc06;

    .line 468
    .line 469
    iget-object v2, v1, Lc06;->a:Lop8;

    .line 470
    .line 471
    invoke-virtual {v1}, Lc06;->a()Ljava/util/LinkedHashSet;

    .line 472
    .line 473
    .line 474
    move-result-object v5

    .line 475
    invoke-interface {v5}, Ljava/util/Collection;->isEmpty()Z

    .line 476
    .line 477
    .line 478
    move-result v6

    .line 479
    if-nez v6, :cond_13

    .line 480
    .line 481
    invoke-virtual {v2, v5}, Lop8;->containsAll(Ljava/util/Collection;)Z

    .line 482
    .line 483
    .line 484
    move-result v5

    .line 485
    if-eqz v5, :cond_13

    .line 486
    .line 487
    move v4, v7

    .line 488
    :cond_13
    if-eqz v4, :cond_14

    .line 489
    .line 490
    invoke-virtual {v2}, Lop8;->clear()V

    .line 491
    .line 492
    .line 493
    return-void

    .line 494
    :cond_14
    invoke-virtual {v1}, Lc06;->a()Ljava/util/LinkedHashSet;

    .line 495
    .line 496
    .line 497
    move-result-object v4

    .line 498
    invoke-virtual {v2, v4}, Lop8;->addAll(Ljava/util/Collection;)Z

    .line 499
    .line 500
    .line 501
    iget-object v1, v1, Lc06;->b:Lhp8;

    .line 502
    .line 503
    invoke-virtual {v1}, Lhp8;->listIterator()Ljava/util/ListIterator;

    .line 504
    .line 505
    .line 506
    move-result-object v1

    .line 507
    :cond_15
    move-object v2, v1

    .line 508
    check-cast v2, Lp74;

    .line 509
    .line 510
    invoke-virtual {v2}, Lp74;->hasNext()Z

    .line 511
    .line 512
    .line 513
    move-result v4

    .line 514
    if-eqz v4, :cond_16

    .line 515
    .line 516
    invoke-virtual {v2}, Lp74;->next()Ljava/lang/Object;

    .line 517
    .line 518
    .line 519
    move-result-object v2

    .line 520
    check-cast v2, Lvq;

    .line 521
    .line 522
    invoke-virtual {v2}, Lvq;->N()Z

    .line 523
    .line 524
    .line 525
    move-result v4

    .line 526
    if-nez v4, :cond_15

    .line 527
    .line 528
    invoke-virtual {v2}, Lvq;->D()Ljava/lang/String;

    .line 529
    .line 530
    .line 531
    move-result-object v4

    .line 532
    sget-object v5, Lpj1;->Companion:Loj1;

    .line 533
    .line 534
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 535
    .line 536
    .line 537
    const-string v5, "ASSISTANT"

    .line 538
    .line 539
    invoke-static {v4, v5}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 540
    .line 541
    .line 542
    move-result v4

    .line 543
    if-eqz v4, :cond_15

    .line 544
    .line 545
    invoke-virtual {v2}, Lvq;->L()Lla1;

    .line 546
    .line 547
    .line 548
    move-result-object v2

    .line 549
    invoke-static {v2}, Lg06;->a(Lla1;)Z

    .line 550
    .line 551
    .line 552
    move-result v2

    .line 553
    if-nez v2, :cond_15

    .line 554
    .line 555
    new-instance v1, Lsi1;

    .line 556
    .line 557
    invoke-direct {v1, v9}, Lsi1;-><init>(I)V

    .line 558
    .line 559
    .line 560
    const/4 v2, 0x0

    .line 561
    invoke-static {v3, v1, v0, v2}, Luia;->R(ILsv3;Lk55;Ljava/lang/String;)V

    .line 562
    .line 563
    .line 564
    :cond_16
    :goto_3
    return-void

    .line 565
    :cond_17
    sget-object v0, Log1;->b:Log1;

    .line 566
    .line 567
    invoke-static {v1, v0}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 568
    .line 569
    .line 570
    move-result v0

    .line 571
    if-eqz v0, :cond_18

    .line 572
    .line 573
    invoke-virtual {v8}, Lxg1;->a()V

    .line 574
    .line 575
    .line 576
    return-void

    .line 577
    :cond_18
    invoke-static {}, Ld42;->d()V

    .line 578
    .line 579
    .line 580
    return-void
.end method

.method public final h()V
    .locals 1

    .line 1
    invoke-virtual {p0}, Lao1;->Q()Loc1;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    sget-object v0, Lqb1;->a:Lqb1;

    .line 6
    .line 7
    invoke-virtual {p0, v0}, Loc1;->g(Lqb1;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public final i(Lvm0;)Lna;
    .locals 0

    .line 1
    invoke-virtual {p0}, Lao1;->Q()Loc1;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    invoke-virtual {p0, p1}, Loc1;->o(Lvm0;)Lna;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    return-object p0
.end method

.method public final j()Lps8;
    .locals 0

    .line 1
    iget-object p0, p0, Lao1;->r:Lxg1;

    .line 2
    .line 3
    iget-object p0, p0, Lxg1;->b:Lrs8;

    .line 4
    .line 5
    return-object p0
.end method

.method public final k()V
    .locals 1

    .line 1
    iget-object p0, p0, Lao1;->j:Lxe1;

    .line 2
    .line 3
    const/4 v0, 0x0

    .line 4
    invoke-virtual {p0, v0}, Lxe1;->J(Z)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public final l()Lps8;
    .locals 0

    .line 1
    iget-object p0, p0, Lao1;->j:Lxe1;

    .line 2
    .line 3
    iget-object p0, p0, Lxe1;->e:Lgh7;

    .line 4
    .line 5
    return-object p0
.end method

.method public final m()Lah8;
    .locals 0

    .line 1
    iget-object p0, p0, Lao1;->z:Ldh8;

    .line 2
    .line 3
    return-object p0
.end method

.method public final n()Lps8;
    .locals 0

    .line 1
    iget-object p0, p0, Lao1;->j:Lxe1;

    .line 2
    .line 3
    iget-object p0, p0, Lxe1;->i:Lrs8;

    .line 4
    .line 5
    return-object p0
.end method

.method public final o()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lao1;->j:Lxe1;

    .line 2
    .line 3
    iget-object p0, p0, Lxe1;->k:Ljava/lang/String;

    .line 4
    .line 5
    return-object p0
.end method

.method public final q()Lps8;
    .locals 0

    .line 1
    iget-object p0, p0, Lao1;->y:Lgh7;

    .line 2
    .line 3
    return-object p0
.end method

.method public final r()Lps8;
    .locals 0

    .line 1
    invoke-virtual {p0}, Lao1;->Q()Loc1;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    iget-object p0, p0, Loc1;->j:Lrs8;

    .line 6
    .line 7
    return-object p0
.end method

.method public final s(Lgz3;Ljava/lang/String;)Z
    .locals 0

    .line 1
    iget-object p0, p0, Lao1;->j:Lxe1;

    .line 2
    .line 3
    invoke-virtual {p0, p1, p2}, Lxe1;->s(Lgz3;Ljava/lang/String;)Z

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final t()V
    .locals 1

    .line 1
    invoke-virtual {p0}, Lao1;->Q()Loc1;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    sget-object v0, Lqb1;->b:Lqb1;

    .line 6
    .line 7
    invoke-virtual {p0, v0}, Loc1;->g(Lqb1;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public final u()Lps8;
    .locals 0

    .line 1
    iget-object p0, p0, Lao1;->q:Lib1;

    .line 2
    .line 3
    iget-object p0, p0, Lib1;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast p0, Lrs8;

    .line 6
    .line 7
    return-object p0
.end method

.method public final v()V
    .locals 1

    .line 1
    invoke-virtual {p0}, Lao1;->Q()Loc1;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    sget-object v0, Lqb1;->c:Lqb1;

    .line 6
    .line 7
    invoke-virtual {p0, v0}, Loc1;->g(Lqb1;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public final w()Lah8;
    .locals 0

    .line 1
    invoke-virtual {p0}, Lao1;->Q()Loc1;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    iget-object p0, p0, Loc1;->n:Ldh8;

    .line 6
    .line 7
    return-object p0
.end method

.method public final x()Lps8;
    .locals 0

    .line 1
    invoke-virtual {p0}, Lao1;->Q()Loc1;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    iget-object p0, p0, Loc1;->l:Lrs8;

    .line 6
    .line 7
    return-object p0
.end method

.method public final bridge y()Lcj;
    .locals 0

    .line 1
    invoke-static {}, Ltga;->I()Lcj;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public final z()Lps8;
    .locals 0

    .line 1
    iget-object p0, p0, Lao1;->a:Lfg1;

    .line 2
    .line 3
    iget-object p0, p0, Lfg1;->i:Lgh7;

    .line 4
    .line 5
    return-object p0
.end method
