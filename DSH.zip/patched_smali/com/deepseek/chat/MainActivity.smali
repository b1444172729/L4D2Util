.class public final Lcom/deepseek/chat/MainActivity;
.super Lgs;
.source "r8-map-id-24591713727e7837693cdfec6d15fe2ce5f4987b5aba1f4bab3573f0d74a433d"


# static fields
.field public static final synthetic B:I


# instance fields
.field public final A:Lta5;


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Lgs;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Lms4;

    .line 5
    .line 6
    const/16 v1, 0x9

    .line 7
    .line 8
    invoke-direct {v0, v1, p0}, Lms4;-><init>(ILjava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    const/4 v1, 0x1

    .line 12
    invoke-static {v1, v0}, Lyb5;->J(ILhv3;)Lta5;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    iput-object v0, p0, Lcom/deepseek/chat/MainActivity;->A:Lta5;

    .line 17
    .line 18
    return-void
.end method


# virtual methods
.method public final onConfigurationChanged(Landroid/content/res/Configuration;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Lgs;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Lcom/deepseek/chat/MainActivity;->t()V

    .line 5
    .line 6
    .line 7
    iget-object p1, p0, Lcom/deepseek/chat/MainActivity;->A:Lta5;

    .line 8
    .line 9
    invoke-interface {p1}, Lta5;->getValue()Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    check-cast p1, Lyo3;

    .line 14
    .line 15
    invoke-virtual {p1, p0}, Lyo3;->d(Landroid/content/Context;)V

    .line 16
    .line 17
    .line 18
    return-void
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .locals 4

    .line 1
    invoke-super {p0, p1}, Lbr3;->onCreate(Landroid/os/Bundle;)V

    .line 2
    .line 3
    .line 4
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 5
    .line 6
    const/16 v0, 0x21

    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    const/4 v2, 0x1

    .line 10
    if-lt p1, v0, :cond_0

    .line 11
    .line 12
    goto :goto_0

    .line 13
    :cond_0
    invoke-static {p0}, Lgh6;->y(Landroid/content/ComponentCallbacks;)Li08;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    const-class v0, Lv77;

    .line 18
    .line 19
    sget-object v3, Lan7;->a:Lbn7;

    .line 20
    .line 21
    invoke-virtual {v3, v0}, Lbn7;->b(Ljava/lang/Class;)Lf15;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    const/4 v3, 0x0

    .line 26
    invoke-virtual {p1, v0, v3, v3}, Li08;->b(Lf15;Lev6;Lmf7;)Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object p1

    .line 30
    check-cast p1, Lv77;

    .line 31
    .line 32
    iget-object p1, p1, Lv77;->c:Lrs8;

    .line 33
    .line 34
    invoke-virtual {p1}, Lrs8;->getValue()Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object p1

    .line 38
    check-cast p1, Lcy;

    .line 39
    .line 40
    iget-object p1, p1, Lcy;->b:Ljava/lang/String;

    .line 41
    .line 42
    invoke-static {p1}, Lsv;->a(Ljava/lang/String;)Ljava/util/Locale;

    .line 43
    .line 44
    .line 45
    move-result-object p1

    .line 46
    if-eqz p1, :cond_1

    .line 47
    .line 48
    new-array v0, v2, [Ljava/util/Locale;

    .line 49
    .line 50
    aput-object p1, v0, v1

    .line 51
    .line 52
    invoke-static {v0}, Lek5;->a([Ljava/util/Locale;)Lek5;

    .line 53
    .line 54
    .line 55
    move-result-object p1

    .line 56
    invoke-static {p1}, Landroidx/appcompat/app/a;->j(Lek5;)V

    .line 57
    .line 58
    .line 59
    :cond_1
    :goto_0
    iget-object p1, p0, Lcom/deepseek/chat/MainActivity;->A:Lta5;

    .line 60
    .line 61
    invoke-interface {p1}, Lta5;->getValue()Ljava/lang/Object;

    .line 62
    .line 63
    .line 64
    move-result-object p1

    .line 65
    check-cast p1, Lyo3;

    .line 66
    .line 67
    invoke-virtual {p1, p0}, Lyo3;->d(Landroid/content/Context;)V

    .line 68
    .line 69
    .line 70
    new-instance p1, Lff8;

    .line 71
    .line 72
    const/16 v0, 0x1a

    .line 73
    .line 74
    invoke-direct {p1, v0}, Lff8;-><init>(I)V

    .line 75
    .line 76
    .line 77
    new-instance v0, Lc19;

    .line 78
    .line 79
    invoke-direct {v0, v1, v1, p1}, Lc19;-><init>(IILff8;)V

    .line 80
    .line 81
    .line 82
    invoke-static {p0, v0}, Lf63;->a(Lgs;Lc19;)V

    .line 83
    .line 84
    .line 85
    invoke-virtual {p0}, Lcom/deepseek/chat/MainActivity;->t()V

    .line 86
    .line 87
    .line 88
    new-instance p1, Lkp5;

    .line 89
    .line 90
    invoke-direct {p1, p0, v2, v1}, Lkp5;-><init>(Lcom/deepseek/chat/MainActivity;IB)V

    .line 91
    .line 92
    .line 93
    new-instance v0, Lt62;

    .line 94
    .line 95
    const v1, 0x6d86a9c3

    .line 96
    .line 97
    .line 98
    invoke-direct {v0, p1, v2, v1}, Lt62;-><init>(Ljava/lang/Object;ZI)V

    .line 99
    .line 100
    .line 101
    invoke-static {p0, v0}, Lm62;->a(Lgs;Lt62;)V

    .line 102
    .line 103
    .line 104
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 105
    .line 106
    .line 107
    move-result-object p1

    .line 108
    invoke-virtual {p0, p1}, Lcom/deepseek/chat/MainActivity;->s(Landroid/content/Intent;)V

    # DS 增强：挂上「关于 / 工具」悬浮入口
    invoke-static {p0}, Lcom/ds/dspatch/Exp;->attachEntry(Landroid/app/Activity;)V

    .line 109
    .line 110
    .line 111
    return-void
.end method

.method public final onNewIntent(Landroid/content/Intent;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Ll62;->onNewIntent(Landroid/content/Intent;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0, p1}, Lcom/deepseek/chat/MainActivity;->s(Landroid/content/Intent;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public final onResume()V
    .locals 2

    .line 1
    invoke-super {p0}, Lbr3;->onResume()V

    .line 2
    .line 3
    .line 4
    sget-boolean v0, Lcom/deepseek/chat/ui/pages/table/TablePreviewActivity;->U:Z

    .line 5
    .line 6
    const/4 v1, 0x0

    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    sput-boolean v1, Lcom/deepseek/chat/ui/pages/table/TablePreviewActivity;->U:Z

    .line 10
    .line 11
    goto :goto_0

    .line 12
    :cond_0
    const v0, 0x7f010018

    .line 13
    .line 14
    .line 15
    invoke-virtual {p0, v1, v0}, Landroid/app/Activity;->overridePendingTransition(II)V

    .line 16
    .line 17
    .line 18
    :goto_0
    iget-object v0, p0, Lcom/deepseek/chat/MainActivity;->A:Lta5;

    .line 19
    .line 20
    invoke-interface {v0}, Lta5;->getValue()Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    check-cast v0, Lyo3;

    .line 25
    .line 26
    invoke-virtual {v0, p0}, Lyo3;->d(Landroid/content/Context;)V

    .line 27
    .line 28
    .line 29
    invoke-virtual {p0}, Lcom/deepseek/chat/MainActivity;->t()V

    .line 30
    .line 31
    .line 32
    return-void
.end method

.method public final r(ILey3;)V
    .locals 9

    .line 1
    const v0, -0x7e892b7a

    .line 2
    .line 3
    .line 4
    invoke-virtual {p2, v0}, Ley3;->i0(I)Ley3;

    .line 5
    .line 6
    .line 7
    invoke-virtual {p2, p0}, Ley3;->h(Ljava/lang/Object;)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    const/4 v1, 0x2

    .line 12
    if-eqz v0, :cond_0

    .line 13
    .line 14
    const/4 v0, 0x4

    .line 15
    goto :goto_0

    .line 16
    :cond_0
    move v0, v1

    .line 17
    :goto_0
    or-int/2addr v0, p1

    .line 18
    and-int/lit8 v2, v0, 0x3

    .line 19
    .line 20
    const/4 v3, 0x1

    .line 21
    if-eq v2, v1, :cond_1

    .line 22
    .line 23
    move v1, v3

    .line 24
    goto :goto_1

    .line 25
    :cond_1
    const/4 v1, 0x0

    .line 26
    :goto_1
    and-int/2addr v0, v3

    .line 27
    invoke-virtual {p2, v0, v1}, Ley3;->X(IZ)Z

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    if-eqz v0, :cond_5

    .line 32
    .line 33
    invoke-static {}, Lj92;->d()Z

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    if-eqz v0, :cond_2

    .line 38
    .line 39
    const-string v0, "com.deepseek.chat.MainActivity.FitStatusBarColor (MainActivity.kt:74)"

    .line 40
    .line 41
    invoke-static {v0}, Lj92;->f(Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    :cond_2
    sget-object v0, Landroidx/compose/ui/platform/AndroidCompositionLocals_androidKt;->f:Ldv8;

    .line 45
    .line 46
    invoke-virtual {p2, v0}, Ley3;->j(Lqd7;)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    move-object v3, v0

    .line 51
    check-cast v3, Landroid/view/View;

    .line 52
    .line 53
    sget-object v0, Lca2;->a:Lha2;

    .line 54
    .line 55
    invoke-virtual {p2, v0}, Ley3;->j(Lqd7;)Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    check-cast v0, Lfm2;

    .line 60
    .line 61
    iget v0, v0, Lfm2;->a:I

    .line 62
    .line 63
    invoke-static {v0, p2}, Lfm2;->a(ILey3;)Z

    .line 64
    .line 65
    .line 66
    move-result v4

    .line 67
    sget-object v0, Landroidx/compose/ui/platform/AndroidCompositionLocals_androidKt;->a:Lha2;

    .line 68
    .line 69
    invoke-virtual {p2, v0}, Ley3;->j(Lqd7;)Ljava/lang/Object;

    .line 70
    .line 71
    .line 72
    move-result-object v0

    .line 73
    check-cast v0, Landroid/content/res/Configuration;

    .line 74
    .line 75
    iget v0, v0, Landroid/content/res/Configuration;->uiMode:I

    .line 76
    .line 77
    invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 78
    .line 79
    .line 80
    move-result-object v7

    .line 81
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 82
    .line 83
    .line 84
    move-result-object v8

    .line 85
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 86
    .line 87
    .line 88
    move-result-object v0

    .line 89
    invoke-virtual {p2, p0}, Ley3;->h(Ljava/lang/Object;)Z

    .line 90
    .line 91
    .line 92
    move-result v1

    .line 93
    invoke-virtual {p2, v3}, Ley3;->h(Ljava/lang/Object;)Z

    .line 94
    .line 95
    .line 96
    move-result v2

    .line 97
    or-int/2addr v1, v2

    .line 98
    invoke-virtual {p2, v4}, Ley3;->g(Z)Z

    .line 99
    .line 100
    .line 101
    move-result v2

    .line 102
    or-int/2addr v1, v2

    .line 103
    invoke-virtual {p2}, Ley3;->S()Ljava/lang/Object;

    .line 104
    .line 105
    .line 106
    move-result-object v2

    .line 107
    if-nez v1, :cond_4

    .line 108
    .line 109
    sget-object v1, Lf92;->a:Lrn0;

    .line 110
    .line 111
    if-ne v2, v1, :cond_3

    .line 112
    .line 113
    goto :goto_2

    .line 114
    :cond_3
    move-object v1, v2

    .line 115
    move-object v2, p0

    .line 116
    goto :goto_3

    .line 117
    :cond_4
    :goto_2
    new-instance v1, Llp5;

    .line 118
    .line 119
    const/4 v5, 0x0

    .line 120
    const/4 v6, 0x0

    .line 121
    move-object v2, p0

    .line 122
    invoke-direct/range {v1 .. v6}, Llp5;-><init>(Lgs;Landroid/view/View;ZLhf2;I)V

    .line 123
    .line 124
    .line 125
    invoke-virtual {p2, v1}, Ley3;->q0(Ljava/lang/Object;)V

    .line 126
    .line 127
    .line 128
    :goto_3
    check-cast v1, Lwv3;

    .line 129
    .line 130
    invoke-static {v7, v8, v0, v1, p2}, Li52;->s(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lwv3;Ley3;)V

    .line 131
    .line 132
    .line 133
    invoke-static {}, Lj92;->d()Z

    .line 134
    .line 135
    .line 136
    move-result p0

    .line 137
    if-eqz p0, :cond_6

    .line 138
    .line 139
    invoke-static {}, Lj92;->e()V

    .line 140
    .line 141
    .line 142
    goto :goto_4

    .line 143
    :cond_5
    move-object v2, p0

    .line 144
    invoke-virtual {p2}, Ley3;->a0()V

    .line 145
    .line 146
    .line 147
    :cond_6
    :goto_4
    invoke-virtual {p2}, Ley3;->v()Ljk7;

    .line 148
    .line 149
    .line 150
    move-result-object p0

    .line 151
    if-eqz p0, :cond_7

    .line 152
    .line 153
    new-instance p2, Lkp5;

    .line 154
    .line 155
    invoke-direct {p2, v2, p1}, Lkp5;-><init>(Lcom/deepseek/chat/MainActivity;I)V

    .line 156
    .line 157
    .line 158
    iput-object p2, p0, Ljk7;->d:Lwv3;

    .line 159
    .line 160
    :cond_7
    return-void
.end method

.method public final s(Landroid/content/Intent;)V
    .locals 16

    .line 1
    invoke-static/range {p0 .. p0}, Lgh6;->y(Landroid/content/ComponentCallbacks;)Li08;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const-class v1, Luo4;

    .line 6
    .line 7
    sget-object v2, Lan7;->a:Lbn7;

    .line 8
    .line 9
    invoke-virtual {v2, v1}, Lbn7;->b(Ljava/lang/Class;)Lf15;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    const/4 v6, 0x0

    .line 14
    invoke-virtual {v0, v1, v6, v6}, Li08;->b(Lf15;Lev6;Lmf7;)Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    move-object v3, v0

    .line 19
    check-cast v3, Luo4;

    .line 20
    .line 21
    iget-object v0, v3, Luo4;->e:Lig2;

    .line 22
    .line 23
    iget-object v1, v3, Luo4;->b:Laj4;

    .line 24
    .line 25
    iget-object v2, v3, Luo4;->a:Luj1;

    .line 26
    .line 27
    invoke-virtual/range {p1 .. p1}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    .line 28
    .line 29
    .line 30
    move-result-object v4

    .line 31
    if-eqz v4, :cond_0

    .line 32
    .line 33
    invoke-virtual {v4}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object v4

    .line 37
    goto :goto_0

    .line 38
    :cond_0
    move-object v4, v6

    .line 39
    :goto_0
    invoke-virtual/range {p1 .. p1}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    .line 40
    .line 41
    .line 42
    move-result-object v5

    .line 43
    if-eqz v5, :cond_1

    .line 44
    .line 45
    invoke-virtual {v5}, Landroid/net/Uri;->getHost()Ljava/lang/String;

    .line 46
    .line 47
    .line 48
    move-result-object v5

    .line 49
    goto :goto_1

    .line 50
    :cond_1
    move-object v5, v6

    .line 51
    :goto_1
    const-string v7, "com.deepseek.chat"

    .line 52
    .line 53
    invoke-static {v4, v7}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 54
    .line 55
    .line 56
    move-result v4

    .line 57
    const/4 v14, 0x3

    .line 58
    const/4 v15, 0x1

    .line 59
    const/4 v8, 0x0

    .line 60
    if-eqz v4, :cond_6

    .line 61
    .line 62
    const-string v4, "authorized_android"

    .line 63
    .line 64
    invoke-static {v5, v4}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 65
    .line 66
    .line 67
    move-result v5

    .line 68
    if-eqz v5, :cond_6

    .line 69
    .line 70
    iget-object v0, v3, Luo4;->c:Lj14;

    .line 71
    .line 72
    invoke-virtual/range {p1 .. p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 73
    .line 74
    .line 75
    move-result-object v1

    .line 76
    invoke-virtual/range {p1 .. p1}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    .line 77
    .line 78
    .line 79
    move-result-object v2

    .line 80
    const-string v3, "android.intent.action.VIEW"

    .line 81
    .line 82
    invoke-static {v1, v3}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 83
    .line 84
    .line 85
    move-result v1

    .line 86
    if-eqz v1, :cond_11

    .line 87
    .line 88
    if-eqz v2, :cond_11

    .line 89
    .line 90
    invoke-virtual {v2}, Landroid/net/Uri;->getHost()Ljava/lang/String;

    .line 91
    .line 92
    .line 93
    move-result-object v1

    .line 94
    invoke-static {v1, v4}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 95
    .line 96
    .line 97
    move-result v1

    .line 98
    if-nez v1, :cond_2

    .line 99
    .line 100
    goto/16 :goto_b

    .line 101
    .line 102
    :cond_2
    const-string v1, "nonce"

    .line 103
    .line 104
    invoke-virtual {v2, v1}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    .line 105
    .line 106
    .line 107
    move-result-object v1

    .line 108
    if-eqz v1, :cond_4

    .line 109
    .line 110
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 111
    .line 112
    .line 113
    move-result v3

    .line 114
    if-nez v3, :cond_3

    .line 115
    .line 116
    goto :goto_2

    .line 117
    :cond_3
    sget-object v2, Lek6;->Companion:Ldk6;

    .line 118
    .line 119
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 120
    .line 121
    .line 122
    move v2, v8

    .line 123
    goto :goto_3

    .line 124
    :cond_4
    :goto_2
    const-string v3, "code"

    .line 125
    .line 126
    invoke-virtual {v2, v3}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    .line 127
    .line 128
    .line 129
    move-result-object v2

    .line 130
    if-eqz v2, :cond_5

    .line 131
    .line 132
    invoke-static {v2}, Lsx8;->V(Ljava/lang/String;)Ljava/lang/Integer;

    .line 133
    .line 134
    .line 135
    move-result-object v2

    .line 136
    if-eqz v2, :cond_5

    .line 137
    .line 138
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 139
    .line 140
    .line 141
    move-result v2

    .line 142
    goto :goto_3

    .line 143
    :cond_5
    sget-object v2, Lek6;->Companion:Ldk6;

    .line 144
    .line 145
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 146
    .line 147
    .line 148
    const/4 v2, 0x2

    .line 149
    :goto_3
    iget-object v3, v0, Lj14;->b:Lig2;

    .line 150
    .line 151
    new-instance v4, Lr50;

    .line 152
    .line 153
    invoke-direct {v4, v1, v2, v0, v6}, Lr50;-><init>(Ljava/lang/String;ILj14;Lhf2;)V

    .line 154
    .line 155
    .line 156
    invoke-static {v3, v6, v8, v4, v14}, Lv9a;->P(Lig2;Lag2;ILwv3;I)Lwr8;

    .line 157
    .line 158
    .line 159
    goto/16 :goto_b

    .line 160
    .line 161
    :cond_6
    invoke-virtual/range {p1 .. p1}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    .line 162
    .line 163
    .line 164
    move-result-object v4

    .line 165
    if-eqz v4, :cond_7

    .line 166
    .line 167
    invoke-static {v4}, Luj1;->a(Landroid/net/Uri;)Z

    .line 168
    .line 169
    .line 170
    move-result v4

    .line 171
    goto :goto_4

    .line 172
    :cond_7
    move v4, v8

    .line 173
    :goto_4
    if-eqz v4, :cond_a

    .line 174
    .line 175
    :cond_8
    iget-object v4, v1, Laj4;->c:Lno0;

    .line 176
    .line 177
    invoke-virtual {v4}, Lno0;->c()Ljava/lang/Object;

    .line 178
    .line 179
    .line 180
    move-result-object v4

    .line 181
    instance-of v4, v4, Lby0;

    .line 182
    .line 183
    if-eqz v4, :cond_8

    .line 184
    .line 185
    invoke-virtual/range {p1 .. p1}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    .line 186
    .line 187
    .line 188
    move-result-object v1

    .line 189
    if-eqz v1, :cond_9

    .line 190
    .line 191
    iget-object v4, v2, Luj1;->a:Lig2;

    .line 192
    .line 193
    new-instance v5, Lhz0;

    .line 194
    .line 195
    const/16 v7, 0x14

    .line 196
    .line 197
    invoke-direct {v5, v1, v2, v6, v7}, Lhz0;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lhf2;I)V

    .line 198
    .line 199
    .line 200
    invoke-static {v4, v6, v8, v5, v14}, Lv9a;->P(Lig2;Lag2;ILwv3;I)Lwr8;

    .line 201
    .line 202
    .line 203
    :cond_9
    new-instance v2, Lzi4;

    .line 204
    .line 205
    const/4 v7, 0x2

    .line 206
    move-object/from16 v5, p0

    .line 207
    .line 208
    move-object/from16 v4, p1

    .line 209
    .line 210
    invoke-direct/range {v2 .. v7}, Lzi4;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lhf2;I)V

    .line 211
    .line 212
    .line 213
    invoke-static {v0, v6, v8, v2, v14}, Lv9a;->P(Lig2;Lag2;ILwv3;I)Lwr8;

    .line 214
    .line 215
    .line 216
    goto/16 :goto_b

    .line 217
    .line 218
    :cond_a
    invoke-virtual/range {p1 .. p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 219
    .line 220
    .line 221
    move-result-object v4

    .line 222
    const-string v5, "android.intent.action.SEND"

    .line 223
    .line 224
    invoke-static {v4, v5}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 225
    .line 226
    .line 227
    move-result v4

    .line 228
    const-string v5, "android.intent.action.PROCESS_TEXT"

    .line 229
    .line 230
    if-nez v4, :cond_d

    .line 231
    .line 232
    invoke-virtual/range {p1 .. p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 233
    .line 234
    .line 235
    move-result-object v4

    .line 236
    const-string v7, "android.intent.action.SEND_MULTIPLE"

    .line 237
    .line 238
    invoke-static {v4, v7}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 239
    .line 240
    .line 241
    move-result v4

    .line 242
    if-nez v4, :cond_d

    .line 243
    .line 244
    invoke-virtual/range {p1 .. p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 245
    .line 246
    .line 247
    move-result-object v4

    .line 248
    invoke-static {v4, v5}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 249
    .line 250
    .line 251
    move-result v4

    .line 252
    if-nez v4, :cond_d

    .line 253
    .line 254
    invoke-virtual/range {p1 .. p1}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    .line 255
    .line 256
    .line 257
    move-result-object v4

    .line 258
    if-eqz v4, :cond_b

    .line 259
    .line 260
    invoke-virtual {v4}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    .line 261
    .line 262
    .line 263
    move-result-object v4

    .line 264
    goto :goto_5

    .line 265
    :cond_b
    move-object v4, v6

    .line 266
    :goto_5
    const-string v7, "content"

    .line 267
    .line 268
    invoke-static {v4, v7}, Lup4;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 269
    .line 270
    .line 271
    move-result v4

    .line 272
    if-eqz v4, :cond_c

    .line 273
    .line 274
    goto :goto_6

    .line 275
    :cond_c
    move v4, v8

    .line 276
    goto :goto_7

    .line 277
    :cond_d
    :goto_6
    move v4, v15

    .line 278
    :goto_7
    if-eqz v4, :cond_10

    .line 279
    .line 280
    iget-object v2, v2, Luj1;->b:Ldh8;

    .line 281
    .line 282
    invoke-virtual {v2}, Ldh8;->h()V

    .line 283
    .line 284
    .line 285
    move-object/from16 v4, p1

    .line 286
    .line 287
    invoke-virtual {v1, v4}, Laj4;->c(Landroid/content/Intent;)V

    .line 288
    .line 289
    .line 290
    invoke-virtual {v4}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 291
    .line 292
    .line 293
    move-result-object v1

    .line 294
    if-eqz v1, :cond_f

    .line 295
    .line 296
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    .line 297
    .line 298
    .line 299
    move-result v2

    .line 300
    const v7, 0x6590ee62

    .line 301
    .line 302
    .line 303
    if-eq v2, v7, :cond_e

    .line 304
    .line 305
    goto :goto_9

    .line 306
    :cond_e
    invoke-virtual {v1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 307
    .line 308
    .line 309
    move-result v1

    .line 310
    if-eqz v1, :cond_f

    .line 311
    .line 312
    const-string v1, "process_text"

    .line 313
    .line 314
    :goto_8
    move-object v11, v1

    .line 315
    goto :goto_a

    .line 316
    :cond_f
    :goto_9
    const-string v1, "send_content"

    .line 317
    .line 318
    goto :goto_8

    .line 319
    :goto_a
    new-instance v7, Lqj3;

    .line 320
    .line 321
    const/4 v12, 0x0

    .line 322
    const/4 v13, 0x4

    .line 323
    move-object/from16 v10, p0

    .line 324
    .line 325
    move-object v9, v4

    .line 326
    move v1, v8

    .line 327
    move-object v8, v3

    .line 328
    invoke-direct/range {v7 .. v13}, Lqj3;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lhf2;I)V

    .line 329
    .line 330
    .line 331
    invoke-static {v0, v6, v1, v7, v14}, Lv9a;->P(Lig2;Lag2;ILwv3;I)Lwr8;

    .line 332
    .line 333
    .line 334
    goto :goto_b

    .line 335
    :cond_10
    move v1, v8

    .line 336
    move v15, v1

    .line 337
    :cond_11
    :goto_b
    if-eqz v15, :cond_12

    .line 338
    .line 339
    move-object/from16 v5, p0

    .line 340
    .line 341
    invoke-virtual {v5, v6}, Landroid/app/Activity;->setIntent(Landroid/content/Intent;)V

    .line 342
    .line 343
    .line 344
    :cond_12
    return-void
.end method

.method public final t()V
    .locals 3

    .line 1
    sget-object v0, Ly7a;->a:Lx7a;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    sget-object v0, Lx7a;->b:Lz7a;

    .line 7
    .line 8
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9
    .line 10
    .line 11
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 12
    .line 13
    const/16 v2, 0x22

    .line 14
    .line 15
    if-lt v1, v2, :cond_0

    .line 16
    .line 17
    sget-object v1, Lxu2;->b:Lxu2;

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    const/16 v2, 0x1e

    .line 21
    .line 22
    if-lt v1, v2, :cond_1

    .line 23
    .line 24
    sget-object v1, Lom0;->b:Lom0;

    .line 25
    .line 26
    goto :goto_0

    .line 27
    :cond_1
    sget-object v1, Lmva;->j0:Lmva;

    .line 28
    .line 29
    :goto_0
    iget-object v0, v0, Lz7a;->b:Lwu2;

    .line 30
    .line 31
    invoke-interface {v1, p0, v0}, La8a;->k(Lcom/deepseek/chat/MainActivity;Lwu2;)Lw7a;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    iget-object v0, v0, Lw7a;->a:Ljm0;

    .line 36
    .line 37
    invoke-virtual {v0}, Ljm0;->c()Landroid/graphics/Rect;

    .line 38
    .line 39
    .line 40
    move-result-object v1

    .line 41
    invoke-virtual {v1}, Landroid/graphics/Rect;->width()I

    .line 42
    .line 43
    .line 44
    move-result v1

    .line 45
    invoke-virtual {v0}, Ljm0;->c()Landroid/graphics/Rect;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    invoke-virtual {v0}, Landroid/graphics/Rect;->height()I

    .line 50
    .line 51
    .line 52
    move-result v0

    .line 53
    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    .line 54
    .line 55
    .line 56
    move-result v2

    .line 57
    invoke-static {v1, v0}, Ljava/lang/Math;->min(II)I

    .line 58
    .line 59
    .line 60
    move-result v0

    .line 61
    int-to-float v1, v2

    .line 62
    int-to-float v0, v0

    .line 63
    div-float/2addr v1, v0

    .line 64
    invoke-virtual {p0}, Lgs;->getResources()Landroid/content/res/Resources;

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    .line 69
    .line 70
    .line 71
    move-result-object v0

    .line 72
    iget v0, v0, Landroid/content/res/Configuration;->smallestScreenWidthDp:I

    .line 73
    .line 74
    const/high16 v2, 0x3fe00000    # 1.75f

    .line 75
    .line 76
    cmpl-float v1, v1, v2

    .line 77
    .line 78
    if-ltz v1, :cond_2

    .line 79
    .line 80
    const/16 v1, 0x258

    .line 81
    .line 82
    if-ge v0, v1, :cond_2

    .line 83
    .line 84
    const/4 v0, 0x1

    .line 85
    goto :goto_1

    .line 86
    :cond_2
    const/16 v0, 0xd

    .line 87
    .line 88
    :goto_1
    invoke-virtual {p0, v0}, Landroid/app/Activity;->setRequestedOrientation(I)V

    .line 89
    .line 90
    .line 91
    return-void
.end method
