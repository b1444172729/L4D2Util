.class public final Lcom/deepseek/chat/App;
.super Landroid/app/Application;
.source "r8-map-id-24591713727e7837693cdfec6d15fe2ce5f4987b5aba1f4bab3573f0d74a433d"

# interfaces
.implements Lil8;


# static fields
.field public static a:Lbs0;

.field public static final b:Lcg2;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    sget-object v0, Ldz2;->a:Lyr2;

    .line 2
    .line 3
    sget-object v0, Ler2;->c:Ler2;

    .line 4
    .line 5
    const/16 v1, 0x32

    .line 6
    .line 7
    invoke-virtual {v0, v1}, Ler2;->K(I)Lcg2;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    sput-object v0, Lcom/deepseek/chat/App;->b:Lcg2;

    .line 12
    .line 13
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Landroid/app/Application;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final a(Landroid/content/Context;)Luh7;
    .locals 17

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    new-instance v1, Lfj0;

    .line 4
    .line 5
    invoke-direct {v1, v0}, Lfj0;-><init>(Landroid/content/Context;)V

    .line 6
    .line 7
    .line 8
    invoke-virtual {v1}, Lfj0;->b()Luh7;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    new-instance v2, Lfj0;

    .line 13
    .line 14
    iget-object v1, v1, Luh7;->a:Lsh7;

    .line 15
    .line 16
    invoke-direct {v2, v1}, Lfj0;-><init>(Lsh7;)V

    .line 17
    .line 18
    .line 19
    sget-boolean v1, Lzu7;->b:Z

    .line 20
    .line 21
    sget-object v3, Ldh4;->a:Lm02;

    .line 22
    .line 23
    iget-object v3, v2, Lfj0;->h:Ljava/lang/Object;

    .line 24
    .line 25
    check-cast v3, Lhd3;

    .line 26
    .line 27
    sget-object v4, Ldh4;->f:Lm02;

    .line 28
    .line 29
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    invoke-virtual {v3, v4, v1}, Lhd3;->a(Lm02;Ljava/lang/Object;)V

    .line 34
    .line 35
    .line 36
    new-instance v1, Ljava/util/ArrayList;

    .line 37
    .line 38
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 39
    .line 40
    .line 41
    new-instance v3, Ljava/util/ArrayList;

    .line 42
    .line 43
    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 44
    .line 45
    .line 46
    new-instance v4, Ljava/util/ArrayList;

    .line 47
    .line 48
    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 49
    .line 50
    .line 51
    new-instance v5, Ljava/util/ArrayList;

    .line 52
    .line 53
    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    .line 54
    .line 55
    .line 56
    new-instance v6, Ljava/util/ArrayList;

    .line 57
    .line 58
    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 59
    .line 60
    .line 61
    new-instance v7, Lh;

    .line 62
    .line 63
    const/4 v8, 0x6

    .line 64
    invoke-direct {v7, v8}, Lh;-><init>(I)V

    .line 65
    .line 66
    .line 67
    new-instance v8, Lh;

    .line 68
    .line 69
    const/4 v9, 0x7

    .line 70
    invoke-direct {v8, v9}, Lh;-><init>(I)V

    .line 71
    .line 72
    .line 73
    invoke-static {v7, v8}, Lz65;->w(Lhv3;Lhv3;)Lnf6;

    .line 74
    .line 75
    .line 76
    move-result-object v7

    .line 77
    const-class v8, Lrr9;

    .line 78
    .line 79
    sget-object v9, Lan7;->a:Lbn7;

    .line 80
    .line 81
    invoke-virtual {v9, v8}, Lbn7;->b(Ljava/lang/Class;)Lf15;

    .line 82
    .line 83
    .line 84
    move-result-object v8

    .line 85
    new-instance v9, Lna;

    .line 86
    .line 87
    const/16 v10, 0x1c

    .line 88
    .line 89
    invoke-direct {v9, v10, v7, v8}, Lna;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 90
    .line 91
    .line 92
    invoke-virtual {v5, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 93
    .line 94
    .line 95
    new-instance v11, Lr62;

    .line 96
    .line 97
    invoke-static {v1}, Lzya;->c0(Ljava/util/List;)Ljava/util/List;

    .line 98
    .line 99
    .line 100
    move-result-object v12

    .line 101
    invoke-static {v3}, Lzya;->c0(Ljava/util/List;)Ljava/util/List;

    .line 102
    .line 103
    .line 104
    move-result-object v13

    .line 105
    invoke-static {v4}, Lzya;->c0(Ljava/util/List;)Ljava/util/List;

    .line 106
    .line 107
    .line 108
    move-result-object v14

    .line 109
    invoke-static {v5}, Lzya;->c0(Ljava/util/List;)Ljava/util/List;

    .line 110
    .line 111
    .line 112
    move-result-object v15

    .line 113
    invoke-static {v6}, Lzya;->c0(Ljava/util/List;)Ljava/util/List;

    .line 114
    .line 115
    .line 116
    move-result-object v16

    .line 117
    invoke-direct/range {v11 .. v16}, Lr62;-><init>(Ljava/util/List;Ljava/util/List;Ljava/util/List;Ljava/util/List;Ljava/util/List;)V

    .line 118
    .line 119
    .line 120
    iput-object v11, v2, Lfj0;->g:Ljava/lang/Object;

    .line 121
    .line 122
    new-instance v1, Lh;

    .line 123
    .line 124
    const/16 v3, 0x8

    .line 125
    .line 126
    invoke-direct {v1, v3}, Lh;-><init>(I)V

    .line 127
    .line 128
    .line 129
    new-instance v3, Lz09;

    .line 130
    .line 131
    invoke-direct {v3, v1}, Lz09;-><init>(Lhv3;)V

    .line 132
    .line 133
    .line 134
    iput-object v3, v2, Lfj0;->d:Ljava/lang/Object;

    .line 135
    .line 136
    new-instance v1, Lgp;

    .line 137
    .line 138
    invoke-direct {v1, v0}, Lgp;-><init>(Landroid/content/Context;)V

    .line 139
    .line 140
    .line 141
    new-instance v0, Lz09;

    .line 142
    .line 143
    invoke-direct {v0, v1}, Lz09;-><init>(Lhv3;)V

    .line 144
    .line 145
    .line 146
    iput-object v0, v2, Lfj0;->e:Ljava/lang/Object;

    .line 147
    .line 148
    invoke-virtual {v2}, Lfj0;->b()Luh7;

    .line 149
    .line 150
    .line 151
    move-result-object v0

    .line 152
    return-object v0
.end method

.method public final attachBaseContext(Landroid/content/Context;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroid/app/Application;->attachBaseContext(Landroid/content/Context;)V

    invoke-static {p1}, Lcom/ds/dspatch/Exp;->init(Landroid/content/Context;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public final onCreate()V
    .locals 7

    .line 1
    invoke-super {p0}, Landroid/app/Application;->onCreate()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Lxk5;

    .line 5
    .line 6
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    const-string v1, "X-LOG"

    .line 10
    .line 11
    iput-object v1, v0, Lxk5;->b:Ljava/lang/String;

    .line 12
    .line 13
    const/4 v1, 0x5

    .line 14
    iput v1, v0, Lxk5;->a:I

    .line 15
    .line 16
    invoke-virtual {v0}, Lxk5;->a()Lxk5;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    sget-object v1, Lh37;->a:Lh37;

    .line 21
    .line 22
    invoke-virtual {v1}, Lh37;->b()Lx87;

    .line 23
    .line 24
    .line 25
    move-result-object v2

    .line 26
    const/4 v3, 0x1

    .line 27
    new-array v4, v3, [Lx87;

    .line 28
    .line 29
    const/4 v5, 0x0

    .line 30
    aput-object v2, v4, v5

    .line 31
    .line 32
    sget-boolean v2, Lv9a;->d:Z

    .line 33
    .line 34
    if-eqz v2, :cond_0

    .line 35
    .line 36
    invoke-virtual {v1}, Lh37;->d()V

    .line 37
    .line 38
    .line 39
    :cond_0
    sput-boolean v3, Lv9a;->d:Z

    .line 40
    .line 41
    sput-object v0, Lv9a;->b:Lxk5;

    .line 42
    .line 43
    new-instance v1, Lnsa;

    .line 44
    .line 45
    const/16 v2, 0xe

    .line 46
    .line 47
    invoke-direct {v1, v2, v5}, Lnsa;-><init>(IZ)V

    .line 48
    .line 49
    .line 50
    iput-object v4, v1, Lnsa;->b:Ljava/lang/Object;

    .line 51
    .line 52
    sput-object v1, Lv9a;->c:Lnsa;

    .line 53
    .line 54
    new-instance v2, Lbua;

    .line 55
    .line 56
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 57
    .line 58
    .line 59
    iput-object v0, v2, Lbua;->a:Ljava/lang/Object;

    .line 60
    .line 61
    iput-object v1, v2, Lbua;->b:Ljava/lang/Object;

    .line 62
    .line 63
    sput-object v2, Lv9a;->a:Lbua;

    .line 64
    .line 65
    invoke-static {p0}, Lcom/tencent/mmkv/MMKV;->s(Lcom/deepseek/chat/App;)V

    .line 66
    .line 67
    .line 68
    invoke-static {}, Lxd5;->e()Lmz8;

    .line 69
    .line 70
    .line 71
    move-result-object v0

    .line 72
    sget-object v1, Ldz2;->a:Lyr2;

    .line 73
    .line 74
    sget-object v1, Lmp5;->a:Ll44;

    .line 75
    .line 76
    invoke-static {v0, v1}, Llx0;->V(Lag2;Lag2;)Lag2;

    .line 77
    .line 78
    .line 79
    move-result-object v0

    .line 80
    invoke-static {v0}, Lv9a;->k(Lag2;)Lbs0;

    .line 81
    .line 82
    .line 83
    move-result-object v0

    .line 84
    sput-object v0, Lcom/deepseek/chat/App;->a:Lbs0;

    .line 85
    .line 86
    invoke-static {}, Ljt5;->y()Lig2;

    .line 87
    .line 88
    .line 89
    move-result-object v0

    .line 90
    sget-object v1, Ler2;->c:Ler2;

    .line 91
    .line 92
    new-instance v2, Li5;

    .line 93
    .line 94
    const/4 v3, 0x0

    .line 95
    const/4 v4, 0x4

    .line 96
    invoke-direct {v2, p0, v3, v4}, Li5;-><init>(Ljava/lang/Object;Lhf2;I)V

    .line 97
    .line 98
    .line 99
    const/4 v6, 0x2

    .line 100
    invoke-static {v0, v1, v5, v2, v6}, Lv9a;->P(Lig2;Lag2;ILwv3;I)Lwr8;

    .line 101
    .line 102
    .line 103
    new-instance v0, Lk0;

    .line 104
    .line 105
    const/4 v1, 0x6

    .line 106
    invoke-direct {v0, v1, p0}, Lk0;-><init>(ILjava/lang/Object;)V

    .line 107
    .line 108
    .line 109
    invoke-static {v0}, Le65;->H(Lsv3;)Li76;

    .line 110
    .line 111
    .line 112
    move-result-object v0

    .line 113
    sget-object v1, Ltya;->k:Ltya;

    .line 114
    .line 115
    monitor-enter v1

    .line 116
    :try_start_0
    sget-object v2, Ltya;->l:Lcj;

    .line 117
    .line 118
    if-eqz v2, :cond_1

    .line 119
    .line 120
    invoke-virtual {v2}, Lcj;->t()V

    .line 121
    .line 122
    .line 123
    goto :goto_0

    .line 124
    :catchall_0
    move-exception p0

    .line 125
    goto :goto_1

    .line 126
    :cond_1
    :goto_0
    sput-object v3, Ltya;->l:Lcj;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 127
    .line 128
    monitor-exit v1

    .line 129
    new-instance v1, La0;

    .line 130
    .line 131
    invoke-direct {v1, v4, p0, v0}, La0;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 132
    .line 133
    .line 134
    invoke-static {v1}, Lv9a;->X(La0;)V

    .line 135
    .line 136
    .line 137
    sget-object p0, La97;->i:La97;

    .line 138
    .line 139
    iget-object p0, p0, La97;->f:Lhg5;

    .line 140
    .line 141
    new-instance v0, Lip;

    .line 142
    .line 143
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 144
    .line 145
    .line 146
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 147
    .line 148
    .line 149
    move-result-wide v1

    .line 150
    iput-wide v1, v0, Lip;->b:J

    .line 151
    .line 152
    invoke-virtual {p0, v0}, Lhg5;->a(Ldg5;)V

    .line 153
    .line 154
    .line 155
    return-void

    .line 156
    :goto_1
    monitor-exit v1

    .line 157
    throw p0
.end method
