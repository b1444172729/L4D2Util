package com.ds.dspatch;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;

/**
 * 「关于 / 工具」页：从主界面右下角的圆点进入（没有单独桌面图标）。
 * 注入状态 / 内置 root 终端 / 自定义人设（隐藏）/ 全局暂停。
 */
public class AboutActivity extends Activity {

    private static final String SP = "dspatch";
    private static final int REQ_PERSONA = 0x51;
    private static final int REQ_DIR = 0x52;
    private static final int REQ_STORAGE = 0x53;

    private TextView status;
    private TextView noticeText;
    private TextView wsText;
    private TextView exportText;
    private TextView personaPreview;
    private SharedPreferences sp;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setTitle("关于 / 工具");
        sp = getSharedPreferences(SP, 0);
        setContentView(build());
    }

    private View build() {
        final android.content.Context c = this;

        LinearLayout root = Ui.screen(c);

        // ---------- 头部 ----------
        root.addView(Ui.hero(c, "DeepSeek 增强",
                "直改 APK 注入 · 无需 Xposed / LSPatch\n内置 Linux 沙箱（root）· AI 可自己动手完成命令"), Ui.fill());

        // ---------- 状态 ----------
        LinearLayout statusCard = Ui.card(c);
        status = Ui.body(c, "");
        statusCard.addView(status, Ui.fill());
        root.addView(statusCard, Ui.fillTop(c, 10));

        // ---------- 终端 ----------
        root.addView(Ui.section(c, "内置终端（Alpine Linux · root）"));
        Button term = Ui.primary(c, "打开终端（沙箱内 uid=0，无需手机 root）");
        term.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(AboutActivity.this, TerminalActivity.class));
            }
        });
        root.addView(term, Ui.fill());

        // ---------- AI 能力 ----------
        root.addView(Ui.section(c, "AI 能力"));

        LinearLayout caps = Ui.row(c);
        caps.addView(nav("MCP 服务端", McpActivity.class), Ui.weight());
        LinearLayout.LayoutParams p1 = Ui.weight();
        p1.leftMargin = Ui.dp(c, 8);
        caps.addView(nav("技能", SkillActivity.class), p1);
        root.addView(caps, Ui.fill());

        Button mod = Ui.ghost(c, "逆向改包");
        mod.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { open(ApkModActivity.class); }
        });
        root.addView(mod, Ui.fillTop(c, 8));

        // ---------- 自定义人设 ----------
        root.addView(Ui.section(c, "自定义人设 / 隐藏提示词"));

        LinearLayout personaCard = Ui.card(c);
        personaCard.addView(Ui.sub(c, "只在发送时拼进网络请求，聊天界面里完全看不到。\n"
                + "三种内置人设（随包文件 assets/term/persona_*.txt，不联网）：开发 / 逆向 / 无限制。\n"
                + "超过 1000 字这里只显示前 1000 字，点「全屏编辑人设」看全文 / 自己改。"), Ui.fill());

        personaPreview = Ui.body(c, "");
        personaPreview.setTextIsSelectable(true);
        personaCard.addView(personaPreview, Ui.fillTop(c, 8));

        LinearLayout prow1 = Ui.row(c);
        Button edit = Ui.primary(c, "全屏编辑人设");
        edit.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(AboutActivity.this, PersonaActivity.class));
            }
        });
        prow1.addView(edit, Ui.weight());

        Button imp = Ui.ghost(c, "从文件导入");
        imp.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { pickFile(); }
        });
        LinearLayout.LayoutParams q1 = Ui.weight();
        q1.leftMargin = Ui.dp(c, 8);
        prow1.addView(imp, q1);
        personaCard.addView(prow1, Ui.fillTop(c, 10));

        LinearLayout prow2 = Ui.row(c);
        Button presetDev = Ui.ghost(c, "用「开发」人设");
        presetDev.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { usePreset(Exp.KIND_DEV); }
        });
        prow2.addView(presetDev, Ui.weight());

        Button presetRev = Ui.ghost(c, "用「逆向」人设");
        presetRev.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { usePreset(Exp.KIND_REVERSE); }
        });
        LinearLayout.LayoutParams q2 = Ui.weight();
        q2.leftMargin = Ui.dp(c, 8);
        prow2.addView(presetRev, q2);
        personaCard.addView(prow2, Ui.fillTop(c, 8));

        LinearLayout prow3 = Ui.row(c);
        Button presetFree = Ui.ghost(c, "用「无限制」人设");
        presetFree.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { usePreset(Exp.KIND_FREE); }
        });
        prow3.addView(presetFree, Ui.weight());

        Button wipe = Ui.ghost(c, "清空自定义");
        wipe.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Exp.savePersona(AboutActivity.this, "");
                refresh();
                toast("已清空自定义，回到内置人设");
            }
        });
        LinearLayout.LayoutParams q3 = Ui.weight();
        q3.leftMargin = Ui.dp(c, 8);
        prow3.addView(wipe, q3);
        personaCard.addView(prow3, Ui.fillTop(c, 8));
        root.addView(personaCard, Ui.fill());

        // ---------- 工作区 / 保存 ----------
        root.addView(Ui.section(c, "工作区 / 保存"));

        LinearLayout wsCard = Ui.card(c);
        wsCard.addView(Ui.sub(c, "对话记录默认不保存。要保存就先挑一个文件夹当工作区，"
                + "之后每条回答只写一次（不再写进系统「下载」目录，也不会边生成边写盘）。"), Ui.fill());

        wsText = Ui.body(c, "");
        wsCard.addView(wsText, Ui.fillTop(c, 8));

        LinearLayout wrows = Ui.row(c);
        Button pick = Ui.primary(c, "选择工作区");
        pick.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { pickWorkspace(); }
        });
        wrows.addView(pick, Ui.weight());

        Button wclear = Ui.ghost(c, "清除");
        wclear.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Workspace.clear(AboutActivity.this);
                refresh();
                toast("已清除工作区（保存开关仍开时退回应用私有目录）");
            }
        });
        LinearLayout.LayoutParams w1 = Ui.weight();
        w1.leftMargin = Ui.dp(c, 8);
        wrows.addView(wclear, w1);
        wsCard.addView(wrows, Ui.fillTop(c, 10));

        CheckBox saveChat = Ui.check(c, "保存对话记录到工作区（每次回答结束写一次，默认关）",
                sp.getBoolean("save_chat", false));
        saveChat.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                sp.edit().putBoolean("save_chat", on).commit();
                toast(on ? "已开启：回答结束后写入工作区" : "已关闭：不再保存对话记录");
            }
        });
        wsCard.addView(saveChat, Ui.fillTop(c, 6));
        root.addView(wsCard, Ui.fill());

        // ---------- 导出产物 ----------
        root.addView(Ui.section(c, "导出产物（整个文件夹搬出去）"));

        LinearLayout exCard = Ui.card(c);
        exCard.addView(Ui.sub(c, "容器里的产物默认躺在 App 私有目录，文件管理器不好进。两条出路：\n"
                + "① 授予「所有文件访问」→ 沙箱能直接写 /sdcard/Download；\n"
                + "② 选个工作区文件夹 → 点下面按钮把产物整个递归导出进去（不需要任何权限）。\n"
                + "约定：让 AI 把要交付的东西（APK / 反编译目录 / 网页）放进容器里的 /root/export/。"), Ui.fill());

        exportText = Ui.body(c, "");
        exCard.addView(exportText, Ui.fillTop(c, 8));

        LinearLayout erow = Ui.row(c);
        Button grant = Ui.ghost(c, "授予存储权限");
        grant.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { askStorage(); }
        });
        erow.addView(grant, Ui.weight());

        Button doExport = Ui.primary(c, "导出产物到可见文件夹");
        doExport.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { runExport(); }
        });
        LinearLayout.LayoutParams e1 = Ui.weight();
        e1.leftMargin = Ui.dp(c, 8);
        erow.addView(doExport, e1);
        exCard.addView(erow, Ui.fillTop(c, 10));
        root.addView(exCard, Ui.fill());

        // ---------- 开关 ----------
        root.addView(Ui.section(c, "开关"));

        LinearLayout swCard = Ui.card(c);
        CheckBox cb = Ui.check(c, "AI 可执行命令：回复里的 ```bash / ```sh 会在沙箱里自动执行并回传结果",
                sp.getBoolean("exec", false));
        cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                sp.edit().putBoolean("exec", on).commit();
                Exp.setExecEnabled(on);
                refresh();
                toast(on ? "已开启：AI 给的命令会在沙箱里执行并回传" : "已关闭：AI 命令不再执行");
            }
        });
        swCard.addView(cb, Ui.fill());

        CheckBox ws = Ui.check(c, "词替换：把「破解 / 去除」自动换成「逆向」再发送（聊天界面仍显示原样）",
                sp.getBoolean("word_swap", false));
        ws.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                Exp.setWordSwap(AboutActivity.this, on);
                refresh();
                toast(on ? "已开启：发送时「破解 / 去除」→「逆向」" : "已关闭：按原样发送");
            }
        });
        swCard.addView(ws, Ui.fillTop(c, 8));

        final Button pause = Ui.ghost(c, pauseLabel());
        pause.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                boolean on = !Exp.isPaused();
                sp.edit().putBoolean("paused", on).commit();
                Exp.setPaused(on);
                pause.setText(pauseLabel());
                refresh();
                toast(on ? "已全局暂停：AI 命令不再自动执行" : "已恢复运行");
            }
        });
        swCard.addView(pause, Ui.fillTop(c, 8));
        root.addView(swCard, Ui.fill());

        // ---------- 公告（MD3 风格 · 服务器下发，放在「关于」上方） ----------
        root.addView(Ui.section(c, "公告"));
        root.addView(md3Notice(), Ui.fill());

        // ---------- 关于 ----------
        root.addView(Ui.section(c, "关于"));
        LinearLayout infoCard = Ui.card(c);
        infoCard.addView(Ui.sub(c, "版本：DeepSeek 2.5.2 + DS 增强\n"
                + "注入方式：smali 级直接改写 APK\n"
                + "自动续写：已关闭\n"
                + "提示词：只在网络层拼入，客户端界面不可见\n"
                + "词替换：可开启「破解 / 去除」→「逆向」（只改发给服务端的文本，界面显示原样）\n"
                + "AI 能力：执行命令 / 调用 MCP 工具 / 加载技能，结果自动回传给 AI\n"
                + "回传方式：作为一条普通消息发回（显示在聊天里）\n"
                + "终端：内置 PRoot + Alpine 容器，容器内 uid=0（非内核 root）\n"
                + "软件源：清华 Alpine 镜像（容器内 apk add / javadev deps 可用）\n"
                + "开发工具链：javadev（APK）/ webdev（网页）/ flutterdev（Flutter）/ langdev（多语言）/ ssh（连服务器）\n"
                + "对话记录：默认不保存，不写系统「下载」目录\n"
                + "工作区：用户在「工作区 / 保存」里自选文件夹"), Ui.fill());
        root.addView(infoCard, Ui.fill());

        return Ui.scroll(c, root);
    }

    /** MD3 风格公告卡：色调容器填充 + 24dp 圆角 + 标签胶囊 + filled tonal 按钮。 */
    private View md3Notice() {
        final android.content.Context c = this;
        LinearLayout card = Ui.md3Card(c);

        LinearLayout head = Ui.row(c);
        head.addView(Ui.md3Label(c, "公告"));
        TextView title = Ui.md3Title(c, "来自服务器");
        LinearLayout.LayoutParams tp = Ui.weight();
        tp.leftMargin = Ui.dp(c, 10);
        head.addView(title, tp);
        card.addView(head, Ui.fill());

        noticeText = Ui.md3Body(c, Remote.notice(this));
        noticeText.setTextIsSelectable(true);
        card.addView(noticeText, Ui.fillTop(c, 12));

        Button refresh = Ui.md3Tonal(c, "刷新公告");
        refresh.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                toast("正在拉取远程配置…");
                Remote.forceRefresh(AboutActivity.this, new Runnable() {
                    @Override public void run() {
                        if (noticeText != null) noticeText.setText(Remote.notice(AboutActivity.this));
                        refresh();
                        toast("公告已刷新");
                    }
                });
            }
        });
        card.addView(refresh, Ui.fillTop(c, 14));
        return card;
    }

    /** 切到某个内置人设并提示。 */
    private void usePreset(String k) {
        Exp.useBuiltin(this, k);
        refresh();
        toast("已切到内置「" + Exp.kindName(k) + "」人设");
    }

    private Button nav(String text, final Class<?> target) {
        Button b = Ui.ghost(this, text);
        b.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { open(target); }
        });
        return b;
    }

    private void open(Class<?> target) {
        try {
            startActivity(new Intent(this, target));
        } catch (Throwable t) {
            toast("打不开: " + t);
        }
    }

    private void pickFile() {
        try {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            startActivityForResult(i, REQ_PERSONA);
        } catch (Throwable t) {
            toast("无法打开文件选择器: " + t);
        }
    }

    /** 用系统目录选择器挑工作区。 */
    private void pickWorkspace() {
        try {
            startActivityForResult(Workspace.pickIntent(), REQ_DIR);
        } catch (Throwable t) {
            toast("无法打开目录选择器: " + t);
        }
    }

    /** 申请存储权限：API30+ 跳「所有文件访问」设置页，低版本走运行时权限。 */
    private void askStorage() {
        try {
            if (android.os.Build.VERSION.SDK_INT >= 30) {
                toast("请在系统页面里打开「所有文件访问」开关");
                startActivity(Export.manageIntent(this));
            } else {
                requestPermissions(new String[]{"android.permission.WRITE_EXTERNAL_STORAGE",
                        "android.permission.READ_EXTERNAL_STORAGE"}, REQ_STORAGE);
            }
        } catch (Throwable t) {
            toast("打不开系统设置页: " + t);
        }
    }

    /** 把容器里的 /root/export/ 整个搬到用户看得见的地方（耗时，放子线程）。 */
    private void runExport() {
        if (!TermEnv.ready(this)) { toast("容器还没装好，先去终端装一次"); return; }
        toast("正在导出…");
        new Thread(new Runnable() {
            @Override public void run() {
                final Export.Result r = Export.run(AboutActivity.this, Export.PUB_FOLDER);
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (r.ok()) toast("已导出 " + r.files + " 个文件 → " + r.where);
                        else toast("导出失败：" + r.err);
                        refresh();
                    }
                });
            }
        }).start();
    }

    @Override public void onRequestPermissionsResult(int req, String[] perms, int[] grants) {
        super.onRequestPermissionsResult(req, perms, grants);
        if (req == REQ_STORAGE) {
            refresh();
            toast(Export.publicOk(this)
                    ? "已授权：沙箱可直接写 /sdcard/Download" : "未授权，可改用「工作区」文件夹导出");
        }
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;

        if (req == REQ_DIR) {
            if (Workspace.setUri(this, data.getData())) {
                refresh();
                toast("工作区已设为：" + Workspace.describe(this));
            } else {
                toast("设置工作区失败");
            }
            return;
        }
        if (req != REQ_PERSONA) return;
        Uri u = data.getData();
        try {
            InputStream in = getContentResolver().openInputStream(u);
            StringBuilder sb = new StringBuilder();
            byte[] b = new byte[8192];
            int n;
            while ((n = in.read(b)) > 0) sb.append(new String(b, 0, n, "UTF-8"));
            in.close();
            String text = sb.toString().trim();
            if (text.length() == 0) { toast("文件是空的"); return; }
            Exp.savePersona(this, text);
            refresh();
            toast("已导入人设（共 " + text.length() + " 字）");
        } catch (Throwable t) {
            toast("读取失败: " + t);
        }
    }

    @Override protected void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        if (status == null) return;
        StringBuilder sb = new StringBuilder();
        sb.append("注入状态：已生效\n");
        sb.append("会话上下文：").append(Exp.isVmCaptured() ? "已捕获" : "未捕获（先打开一次聊天页）").append('\n');
        sb.append("内置终端：").append(TermEnv.ready(this) ? "已就绪（Alpine 容器）" : "未安装（打开终端自动安装）").append('\n');
        sb.append("AI 执行命令：").append(Exp.isExecEnabled() ? "开" : "关").append('\n');
        sb.append("词替换：" ).append(Exp.isWordSwap() ? "开（破解/去除 → 逆向）" : "关").append('\n');
        sb.append("全局暂停：").append(Exp.isPaused() ? "是（已暂停）" : "否").append('\n');
        sb.append("保存对话：").append(Exp.saveEnabled() ? "开 → " + Workspace.describe(this) : "关");
        sb.append('\n').append("MCP 服务端：").append(Mcp.enabled(this).size()).append(" 个启用");
        sb.append('\n').append("技能：").append(Skill.list(this).size()).append(" 个");
        status.setText(sb.toString());

        if (personaPreview != null) personaPreview.setText(personaPreviewText());

        if (wsText != null) {
            wsText.setText("当前位置：" + Workspace.describe(this)
                    + (Workspace.has(this) ? "（你选定的工作区）" : "（未选工作区，退回应用私有目录）"));
        }

        if (exportText != null) exportText.setText(Export.describe(this));
    }

    /** 人设预览：超过 1000 字只显示前 1000 字（原文不动，全屏编辑页看/改全文）。 */
    private String personaPreviewText() {
        String p = Exp.getPersona();
        boolean custom = new java.io.File(getFilesDir(), "persona.txt").exists();
        String src = custom ? "自定义" : ("内置 · " + Exp.kindName(Exp.kind(this)));
        if (p.length() == 0) return "当前人设：无（内置文件缺失）";
        String head = "当前人设（" + src + "，" + p.length() + " 字，隐藏）：\n";
        if (p.length() <= 1000) return head + p;
        return head + p.substring(0, 1000) + "\n……（超过 1000 字已折叠，点「全屏编辑人设」看全文）";
    }

    private String pauseLabel() {
        return Exp.isPaused()
                ? "▶ 已全局暂停 —— 点一下恢复运行"
                : "⏸ 运行中 —— 点一下全局暂停（停止自动执行）";
    }

    private void toast(String s) {
        try { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); } catch (Throwable ignored) { }
    }
}
