package com.ds.dspatch;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * 内置终端：App 自带的 Alpine Linux 沙箱（PRoot），进去就是 root（uid=0）。
 * 完全不依赖手机 root / Magisk。首次打开会自动解开内置的 Alpine 文件系统。
 * 控制台内保持同一个交互式会话（cwd、环境变量在命令之间保留）。
 */
public class TerminalActivity extends Activity {

    private static final Charset UTF8 = Charset.forName("UTF-8");
    private static final String SP = "dspatch";

    private TextView info;
    private TextView console;
    private ScrollView scroller;
    private EditText input;
    private Button runBtn;

    private Process shell;
    private OutputStream stdin;
    private final AtomicBoolean booting = new AtomicBoolean(false);
    private final StringBuilder buf = new StringBuilder();
    private final Handler ui = new Handler(Looper.getMainLooper());

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setTitle("DS 终端");

        final android.content.Context c = this;

        LinearLayout root = Ui.screen(c);

        info = Ui.sub(c, "环境检测中…");
        root.addView(info, Ui.fill());

        console = new TextView(c);
        console.setTextSize(12);
        console.setTypeface(Typeface.MONOSPACE);
        console.setTextColor(0xFF4CE07A);
        console.setTextIsSelectable(true);
        console.setMovementMethod(new ScrollingMovementMethod());
        console.setPadding(Ui.dp(c, 10), Ui.dp(c, 10), Ui.dp(c, 10), Ui.dp(c, 10));

        LinearLayout consoleCard = Ui.card(c);
        consoleCard.setBackground(Ui.rounded(c, 0xFF06090D, 14, Ui.STROKE));
        consoleCard.addView(console, Ui.fill());

        scroller = new ScrollView(c);
        scroller.setBackgroundColor(Ui.BG);
        scroller.addView(consoleCard, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scroller, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout row = Ui.row(c);
        row.setPadding(0, Ui.dp(c, 10), 0, 0);
        input = Ui.input(c, "输入命令，回车执行", "");
        input.setSingleLine(true);
        input.setTypeface(Typeface.MONOSPACE);
        input.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override public boolean onEditorAction(TextView v, int actionId, android.view.KeyEvent e) {
                if (actionId == EditorInfo.IME_ACTION_DONE || actionId == EditorInfo.IME_ACTION_GO
                        || (e != null && e.getKeyCode() == android.view.KeyEvent.KEYCODE_ENTER)) {
                    submit();
                    return true;
                }
                return false;
            }
        });
        row.addView(input, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        runBtn = Ui.primary(c, "执行");
        LinearLayout.LayoutParams rp = Ui.fill();
        rp.leftMargin = Ui.dp(c, 8);
        row.addView(runBtn, rp);
        runBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { submit(); }
        });
        root.addView(row, Ui.fill());

        final SharedPreferences sp = getSharedPreferences(SP, 0);
        CheckBox cb = Ui.check(c, "AI 可执行命令（回复里 ```bash / ```sh 会在沙箱里自动执行并把结果回传）",
                sp.getBoolean("exec", false));
        cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                sp.edit().putBoolean("exec", on).commit();
                Exp.setExecEnabled(on);
                toast(on ? "已开启：AI 给的命令会在沙箱里执行并回传" : "已关闭：AI 命令不再执行");
            }
        });
        root.addView(cb, Ui.fillTop(c, 6));

        CheckBox pause = Ui.check(c, "全局暂停（停止自动执行命令）", sp.getBoolean("paused", false));
        pause.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                sp.edit().putBoolean("paused", on).commit();
                Exp.setPaused(on);
                toast(on ? "已全局暂停" : "已恢复");
            }
        });
        root.addView(pause, Ui.fill());

        LinearLayout actions = Ui.row(c);
        actions.setPadding(0, Ui.dp(c, 10), 0, 0);

        Button clear = Ui.ghost(c, "清屏");
        clear.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { buf.setLength(0); console.setText(""); }
        });
        actions.addView(clear, Ui.weight());

        Button restart = Ui.ghost(c, "重启终端");
        restart.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { boot(); }
        });
        LinearLayout.LayoutParams a1 = Ui.weight();
        a1.leftMargin = Ui.dp(c, 8);
        actions.addView(restart, a1);

        Button reinstall = Ui.ghost(c, "重装环境");
        reinstall.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (booting.get()) return;
                TermEnv.reset(TerminalActivity.this);
                append("[已清除环境，开始重新安装…]\n");
                boot();
            }
        });
        LinearLayout.LayoutParams a2 = Ui.weight();
        a2.leftMargin = Ui.dp(c, 8);
        actions.addView(reinstall, a2);
        root.addView(actions, Ui.fill());

        setContentView(root);
        boot();
    }

    private void submit() {
        String cmd = input.getText().toString();
        if (cmd.trim().length() == 0) return;
        input.setText("");
        run(cmd);
    }

    /** 准备环境（必要时解开 rootfs）并启动 proot 里的 Alpine 登录 shell。 */
    private void boot() {
        if (!booting.compareAndSet(false, true)) return;
        stopShell();
        info.setText("环境准备中…");
        append("[准备内置 Linux 环境…]\n");
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    final String nd = TermEnv.nativeDir(TerminalActivity.this);
                    if (!new java.io.File(nd, "libproot.so").exists()) {
                        post("\n[错误] 找不到内置的 proot（libproot.so）。安装包可能不完整。\n");
                        postInfo("内置环境不可用");
                        return;
                    }
                    TermEnv.ensure(TerminalActivity.this, new TermEnv.Progress() {
                        @Override public void onProgress(String msg) { post("[ " + msg + " ]\n"); }
                    });
                    startShell();
                } catch (final Throwable t) {
                    post("\n[环境准备失败] " + t + "\n");
                    postInfo("环境准备失败");
                } finally {
                    booting.set(false);
                }
            }
        }, "ds-term-boot").start();
    }

    private void startShell() {
        try {
            ProcessBuilder pb = new ProcessBuilder(TermEnv.loginCmd(this));
            TermEnv.applyEnv(pb, this);
            pb.redirectErrorStream(true);
            shell = pb.start();
            stdin = shell.getOutputStream();
            pump(shell.getInputStream());
            postInfo("Alpine Linux · root(uid=0) · PRoot 沙箱");
            post("\n[已进入内置 Alpine Linux，当前用户为 root]\n");
            run("id");
        } catch (Throwable t) {
            post("\n[启动沙箱失败] " + t + "\n");
            postInfo("沙箱启动失败");
        }
    }

    private void stopShell() {
        if (shell != null) {
            try { shell.destroy(); } catch (Throwable ignored) { }
            shell = null;
            stdin = null;
        }
    }

    private void run(final String cmd) {
        if (stdin == null) { append("[会话未就绪]\n"); return; }
        append("$ " + cmd + "\n");
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    stdin.write((cmd + "\n").getBytes(UTF8));
                    stdin.flush();
                } catch (Throwable t) {
                    post("[写入失败] " + t + "\n");
                }
            }
        }, "ds-term-writer").start();
    }

    private void pump(final InputStream in) {
        Thread t = new Thread(new Runnable() {
            @Override public void run() {
                byte[] b = new byte[4096];
                try {
                    int n;
                    while ((n = in.read(b)) > 0) post(new String(b, 0, n, UTF8));
                } catch (Throwable ignored) { }
            }
        }, "ds-term-reader");
        t.setDaemon(true);
        t.start();
    }

    private void post(final String s) {
        ui.post(new Runnable() { @Override public void run() { append(s); } });
    }

    private void postInfo(final String s) {
        ui.post(new Runnable() { @Override public void run() { info.setText(s); } });
    }

    private void append(String s) {
        if (s.length() == 0) return;
        buf.append(s);
        if (buf.length() > 200000) buf.delete(0, buf.length() - 100000);
        console.setText(buf.toString());
        scroller.post(new Runnable() {
            @Override public void run() { scroller.fullScroll(View.FOCUS_DOWN); }
        });
    }

    private void toast(String s) {
        try { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); } catch (Throwable ignored) { }
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        stopShell();
    }
}
