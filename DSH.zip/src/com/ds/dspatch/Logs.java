package com.ds.dspatch;

import android.content.Context;
import android.util.Log;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.Charset;

/**
 * 执行记录：AI / 终端在沙箱里跑过的每一条命令、MCP 调用、技能加载与它们的输出。
 *
 * - 内存里保留一份最近记录，日志页可以边跑边刷新；
 * - 同时追加写入 应用私有目录/exec.log，可导出到 Download。
 */
public final class Logs {

    static final String TAG = "DS-Log";
    private static final Charset U8 = Charset.forName("UTF-8");
    private static final int MAX_MEM = 200000;
    private static final int MAX_FILE = 1048576;

    private static final StringBuilder MEM = new StringBuilder();
    private static volatile Listener listener;

    private Logs() { }

    public interface Listener { void onLog(String text); }

    public static void setListener(Listener l) { listener = l; }

    private static File file(Context c) {
        File d = new File(c.getFilesDir(), "logs");
        if (!d.exists()) d.mkdirs();
        return new File(d, "exec.log");
    }

    /** 追加一条记录（自动加时间戳）。 */
    public static synchronized void append(Context c, String tag, String body) {
        String s = "[" + stamp() + "] " + (tag == null ? "" : tag + " ") + "\n"
                + (body == null ? "" : body) + "\n"
                + "--------------------------------------------------\n";
        if (MEM.length() > MAX_MEM) MEM.delete(0, MEM.length() - MAX_MEM / 2);
        MEM.append(s);
        try {
            if (c != null) {
                File f = file(c);
                if (f.length() > MAX_FILE) f.delete();
                FileOutputStream os = new FileOutputStream(f, true);
                os.write(s.getBytes(U8));
                os.flush();
                os.close();
            }
        } catch (Throwable t) {
            Log.w(TAG, "写执行记录失败: " + t);
        }
        Listener l = listener;
        if (l != null) {
            try { l.onLog(s); } catch (Throwable ignored) { }
        }
    }

    public static synchronized String mem() { return MEM.toString(); }

    public static String readFile(Context c) {
        try {
            File f = file(c);
            if (!f.exists()) return "";
            FileInputStream in = new FileInputStream(f);
            StringBuilder sb = new StringBuilder();
            byte[] b = new byte[8192];
            int n;
            while ((n = in.read(b)) > 0) sb.append(new String(b, 0, n, U8));
            in.close();
            return sb.toString();
        } catch (Throwable t) {
            return "";
        }
    }

    public static synchronized void clear(Context c) {
        MEM.setLength(0);
        try { file(c).delete(); } catch (Throwable ignored) { }
    }

    private static String stamp() {
        java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("MM-dd HH:mm:ss", java.util.Locale.US);
        return f.format(new java.util.Date());
    }
}
