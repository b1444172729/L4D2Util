package com.ds.dspatch;

import android.content.Context;
import android.content.res.AssetManager;
import android.util.Log;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 技能（Skill）：支持两种形态。
 *
 *   1. 单文件     ：skills/<名字>.md
 *   2. 目录型技能：skills/<名字>/SKILL.md（+ references/、scripts/…，Claude Skills 结构）
 *
 * 只把「技能名 + 一句描述」注入隐藏提示词；AI 输出 ```skill 技能名 才把正文回传，
 * 正文不进聊天框。目录型技能的整个目录会 bind 到容器里的 /skills/<名字>/，
 * 所以 AI 还能自己 cat 参考资料、跑里面的脚本。
 */
public final class Skill {

    static final String TAG = "DS-Skill";
    private static final Charset U8 = Charset.forName("UTF-8");
    private static final String[] MD_EXT = {".md", ".markdown", ".txt"};

    private Skill() { }

    public static final class Item {
        public String name = "";      // 目录名或文件名（AI 引用用这个）
        public String alt = "";       // SKILL.md front matter 里的 name（如果不同）
        public String desc = "";
        public boolean dir;           // true = 目录型技能
        public File file;             // 目录本身，或单文件
    }

    public static File dir(Context c) {
        File f = new File(c.getFilesDir(), "skills");
        if (!f.exists()) f.mkdirs();
        return f;
    }

    // ---------- 列表 ----------

    public static List<Item> list(Context c) {
        List<Item> out = new ArrayList<Item>();
        File[] fs = dir(c).listFiles();
        if (fs == null) return out;
        Arrays.sort(fs);
        for (File f : fs) {
            String n = f.getName();
            if (n.startsWith(".")) continue;
            if (f.isDirectory()) {
                File md = skillMd(f);
                if (md == null) continue;
                Item it = new Item();
                it.dir = true;
                it.file = f;
                it.name = n;
                String body = read(md);
                it.alt = frontValue(body, "name");
                it.desc = describe(body);
                out.add(it);
            } else if (f.isFile() && hasMdExt(n)) {
                Item it = new Item();
                it.file = f;
                it.name = stripExt(n);
                String body = read(f);
                it.alt = frontValue(body, "name");
                it.desc = describe(body);
                out.add(it);
            }
        }
        return out;
    }

    /** 按名字（或 front matter 里的 name）加载正文。 */
    public static String load(Context c, String name) {
        String n = normalize(name);
        if (n.length() == 0) return null;
        for (Item it : list(c)) {
            if (it.name.equalsIgnoreCase(n)
                    || (it.alt.length() > 0 && it.alt.equalsIgnoreCase(n))) {
                if (it.dir) {
                    File md = skillMd(it.file);
                    String body = md == null ? null : read(md);
                    if (body == null) return null;
                    return body + "\n\n---\n【本技能的资源目录】" + it.file.getAbsolutePath()
                            + "\n容器内路径：/skills/" + it.name + "/"
                            + "\n需要参考资料或脚本时，可在命令里直接读取，例如："
                            + " cat /skills/" + it.name + "/references/*.md 或 sh /skills/"
                            + it.name + "/scripts/xxx.sh";
                }
                return read(it.file);
            }
        }
        return null;
    }

    public static boolean delete(Context c, String name) {
        String n = normalize(name);
        for (Item it : list(c)) {
            if (it.name.equalsIgnoreCase(n)) {
                try {
                    if (it.dir) daleteRec(it.file);
                    else it.file.delete();
                    return true;
                } catch (Throwable ignored) { }
            }
        }
        return false;
    }

    // ---------- 用户导入（单文件） ----------

    public static String importSkill(Context c, InputStream in, String displayName) throws Exception {
        String base = displayName == null ? "skill" : displayName;
        base = normalize(base);
        if (base.length() == 0) base = "skill";
        StringBuilder sb = new StringBuilder();
        byte[] b = new byte[8192];
        int n;
        while ((n = in.read(b)) > 0) sb.append(new String(b, 0, n, U8));
        in.close();
        File f = new File(dir(c), base + ".md");
        FileOutputStream os = new FileOutputStream(f);
        os.write(sb.toString().getBytes(U8));
        os.flush();
        os.close();
        return base;
    }

    // ---------- 内置技能包 ----------

    private static final String PACK_MARK = ".pack-v2";

    /**
     * 首次运行把 assets/skills 里的内置技能包展开到 files/skills（幂等，带版本标记）。
     * 返回本次写入的文件数；已展开过返回 0。
     */
    public static int ensurePack(Context c) {
        File marker = new File(dir(c), PACK_MARK);
        // 标记存在但一个技能都认不出来时，说明上次展开不完整，重新展开一次
        if (marker.exists() && !list(c).isEmpty()) return 0;
        int n = 0;
        try {
            n = copyAssetDir(c.getAssets(), "skills", dir(c));
            FileOutputStream os = new FileOutputStream(marker);
            os.write("1".getBytes(U8));
            os.flush();
            os.close();
            Log.i(TAG, "内置技能包已展开：" + n + " 个文件");
        } catch (Throwable t) {
            Log.w(TAG, "展开内置技能包失败: " + t);
        }
        return n;
    }

    public static boolean packInstalled(Context c) {
        return new File(dir(c), PACK_MARK).exists();
    }

    private static int copyAssetDir(AssetManager am, String from, File to) throws IOException {
        String[] names = am.list(from);
        if (names == null) return 0;
        int n = 0;
        for (String name : names) {
            String child = from + "/" + name;
            String[] sub = am.list(child);
            if (sub != null && sub.length > 0) {
                File d = new File(to, name);
                d.mkdirs();
                n += copyAssetDir(am, child, d);
            } else {
                // list() 为空：可能是普通文件，也可能是空目录
                InputStream in = null;
                try {
                    in = am.open(child);
                    File f = new File(to, name);
                    File parent = f.getParentFile();
                    if (parent != null) parent.mkdirs();
                    FileOutputStream os = new FileOutputStream(f);
                    byte[] b = new byte[1 << 15];
                    int r;
                    while ((r = in.read(b)) > 0) os.write(b, 0, r);
                    os.flush();
                    os.close();
                    f.setReadable(true, false);
                    n++;
                } catch (IOException e) {
                    new File(to, name).mkdirs();
                } finally {
                    if (in != null) try { in.close(); } catch (Throwable ignored) { }
                }
            }
        }
        return n;
    }

    // ---------- 给隐藏提示词用的索引 ----------

    public static String index(Context c) {
        StringBuilder sb = new StringBuilder();
        for (Item it : list(c)) {
            sb.append("- ").append(it.name);
            if (it.desc.length() > 0) sb.append("：").append(it.desc);
            sb.append('\n');
        }
        return sb.toString();
    }

    // ---------- 工具 ----------

    private static File skillMd(File d) {
        File a = new File(d, "SKILL.md");
        if (a.isFile()) return a;
        File b = new File(d, "skill.md");
        if (b.isFile()) return b;
        return null;
    }

    private static boolean hasMdExt(String n) {
        String l = n.toLowerCase(java.util.Locale.ROOT);
        for (String e : MD_EXT) if (l.endsWith(e)) return true;
        return false;
    }

    private static String stripExt(String n) {
        String l = n.toLowerCase(java.util.Locale.ROOT);
        for (String e : MD_EXT) if (l.endsWith(e)) return n.substring(0, n.length() - e.length());
        return n;
    }

    /** 取 front matter 里的某个键（--- 之间的 name: / description:）。 */
    private static String frontValue(String body, String key) {
        if (body == null) return "";
        String[] lines = body.split("\n");
        int end = Math.min(lines.length, 40);
        for (int i = 0; i < end; i++) {
            String t = lines[i].trim();
            if (i > 0 && t.equals("---")) break;
            if (t.toLowerCase(java.util.Locale.ROOT).startsWith(key + ":")) {
                return t.substring(key.length() + 1).trim();
            }
        }
        return "";
    }

    /** 描述：优先 front matter 的 description，否则第一段非空正文。 */
    private static String describe(String body) {
        String d = frontValue(body, "description");
        if (d.length() > 0) return cut(d);
        if (body == null) return "";
        String[] lines = body.split("\n");
        boolean fm = false;
        for (int i = 0; i < lines.length; i++) {
            String t = lines[i].trim();
            if (i == 0 && t.equals("---")) { fm = true; continue; }
            if (fm) { if (t.equals("---")) fm = false; continue; }
            if (t.length() == 0 || t.startsWith("#") || t.startsWith(">")) continue;
            return cut(t);
        }
        return "";
    }

    private static String cut(String s) {
        return s.length() > 120 ? s.substring(0, 120) + "…" : s;
    }

    private static String normalize(String s) {
        if (s == null) return "";
        String n = s.trim();
        int slash = Math.max(n.lastIndexOf('/'), n.lastIndexOf('\\'));
        if (slash >= 0) n = n.substring(slash + 1);
        n = stripExt(n);
        return n.replaceAll("[\\s]+", "-").replaceAll("[^0-9A-Za-z_\\-\u4e00-\u9fa5]", "");
    }

    private static void daleteRec(File f) {
        File[] fs = f.listFiles();
        if (fs != null) for (File x : fs) daleteRec(x);
        f.delete();
    }

    private static String read(File f) {
        if (f == null) return null;
        try {
            FileInputStream in = new FileInputStream(f);
            StringBuilder sb = new StringBuilder();
            byte[] b = new byte[8192];
            int n;
            while ((n = in.read(b)) > 0) sb.append(new String(b, 0, n, U8));
            in.close();
            return sb.toString();
        } catch (Throwable t) {
            Log.w(TAG, "读取技能失败 " + f + ": " + t);
            return null;
        }
    }
}
