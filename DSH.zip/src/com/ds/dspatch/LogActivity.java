package com.ds.dspatch;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.OutputStream;
import java.nio.charset.Charset;

/**
 * 执行记录：AI 在沙箱里跑过的命令 / MCP 调用 / 技能加载 以及它们的输出。
 * 边跑边刷新，可清空、可导出到 Download/DeepSeekExport。
 */
public class LogActivity extends Activity {

    private static final Charset U8 = Charset.forName("UTF-8");

    private TextView body;
    private ScrollView scroller;
    private final StringBuilder buf = new StringBuilder();
    private final Handler ui = new Handler(Looper.getMainLooper());

    private final Logs.Listener listener = new Logs.Listener() {
        @Override public void onLog(final String text) {
            ui.post(new Runnable() {
                @Override public void run() {
                    buf.append(text);
                    body.setText(buf.toString());
                    scroller.post(new Runnable() {
                        @Override public void run() { scroller.fullScroll(View.FOCUS_DOWN); }
                    });
                }
            });
        }
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setTitle("执行记录");

        final float d = getResources().getDisplayMetrics().density;
        int pad = (int) (12 * d);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF0E1116);
        root.setPadding(pad, pad, pad, pad);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);

        Button refresh = new Button(this);
        refresh.setText("刷新");
        refresh.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { reload(); }
        });
        row.addView(refresh, weight());

        Button clear = new Button(this);
        clear.setText("清空");
        clear.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Logs.clear(LogActivity.this);
                buf.setLength(0);
                body.setText("（空）");
            }
        });
        row.addView(clear, weight());

        Button export = new Button(this);
        export.setText("导出到 Download");
        export.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { export(); }
        });
        row.addView(export, weight());
        root.addView(row, wrap());

        body = new TextView(this);
        body.setTextSize(11);
        body.setTypeface(Typeface.MONOSPACE);
        body.setTextColor(0xFFD6E2EE);
        body.setTextIsSelectable(true);
        body.setText("（空）");

        scroller = new ScrollView(this);
        scroller.setBackgroundColor(0xFF0E1116);
        scroller.addView(body, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scroller, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
        reload();
    }

    @Override protected void onResume() {
        super.onResume();
        Logs.setListener(listener);
    }

    @Override protected void onPause() {
        super.onPause();
        Logs.setListener(null);
    }

    private void reload() {
        buf.setLength(0);
        String s = Logs.readFile(this);
        if (s == null || s.length() == 0) s = Logs.mem();
        buf.append(s);
        body.setText(s.length() == 0 ? "（还没有执行记录）" : s);
        scroller.post(new Runnable() {
            @Override public void run() { scroller.fullScroll(View.FOCUS_DOWN); }
        });
    }

    private void export() {
        String s = Logs.readFile(this);
        if (s.length() == 0) s = buf.toString();
        if (s.length() == 0) { toast("没有内容可导出"); return; }
        String name = "exec.log";
        Workspace.save(this, name, s);
        toast("已导出到工作区：" + Workspace.describe(this) + "/" + name);
    }

    private void toast(String s) {
        try { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); } catch (Throwable ignored) { }
    }

    private static LinearLayout.LayoutParams wrap() {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private static LinearLayout.LayoutParams weight() {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
    }
}
