package com.ds.dspatch;

import android.app.Activity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * 全屏人设编辑页：显示并编辑完整人设原文。
 * 关于页只显示前 1000 字，这里点进来就能看全 / 改全。
 * 保存后作为「自定义人设」生效（写在应用私有目录 persona.txt，优先于内置人设）。
 */
public class PersonaActivity extends Activity {

    private EditText box;
    private TextView counter;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setTitle("全屏编辑人设");

        final android.content.Context c = this;
        LinearLayout root = Ui.screen(c);

        root.addView(Ui.hero(c, "全屏编辑人设",
                "完整原文，随便改。保存后即作为「自定义人设」生效（优先于内置）。\n"
                        + "只在发送时拼进网络请求，聊天界面里完全看不到。"), Ui.fill());

        box = Ui.input(c, "在这里填写人设…", "");
        box.setMinLines(6);
        box.setGravity(Gravity.TOP | Gravity.LEFT);
        box.setTextSize(14);
        box.setText(Exp.getPersona());

        LinearLayout editCard = Ui.card(c);
        editCard.addView(box, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        root.addView(editCard, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        counter = Ui.sub(c, "");
        root.addView(counter, Ui.fillTop(c, 6));

        LinearLayout row1 = Ui.row(c);
        Button save = Ui.primary(c, "保存");
        save.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Exp.savePersona(PersonaActivity.this, box.getText().toString());
                updateCounter();
                toast("已保存（" + Exp.getPersona().length() + " 字）");
            }
        });
        row1.addView(save, Ui.weight());

        Button clear = Ui.ghost(c, "清空");
        clear.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                box.setText("");
                Exp.savePersona(PersonaActivity.this, "");
                updateCounter();
                toast("已清空，回到内置人设");
            }
        });
        LinearLayout.LayoutParams g1 = Ui.weight();
        g1.leftMargin = Ui.dp(c, 8);
        row1.addView(clear, g1);
        root.addView(row1, Ui.fillTop(c, 8));

        LinearLayout row2 = Ui.row(c);
        Button dev = Ui.ghost(c, "载入「开发」");
        dev.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                box.setText(Exp.builtinPersona(PersonaActivity.this, Exp.KIND_DEV));
                updateCounter();
                toast("已载入内置「开发」人设（还没保存）");
            }
        });
        row2.addView(dev, Ui.weight());

        Button rev = Ui.ghost(c, "载入「逆向」");
        rev.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                box.setText(Exp.builtinPersona(PersonaActivity.this, Exp.KIND_REVERSE));
                updateCounter();
                toast("已载入内置「逆向」人设（还没保存）");
            }
        });
        LinearLayout.LayoutParams g2 = Ui.weight();
        g2.leftMargin = Ui.dp(c, 8);
        row2.addView(rev, g2);
        root.addView(row2, Ui.fillTop(c, 8));

        Button free = Ui.ghost(c, "载入「无限制」");
        free.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                box.setText(Exp.builtinPersona(PersonaActivity.this, Exp.KIND_FREE));
                updateCounter();
                toast("已载入内置「无限制」人设（还没保存）");
            }
        });
        root.addView(free, Ui.fillTop(c, 8));

        box.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int cc) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int cc) { }
            @Override public void afterTextChanged(Editable s) { updateCounter(); }
        });
        updateCounter();

        setContentView(root);
    }

    private void updateCounter() {
        if (counter == null) return;
        int n = box.getText().length();
        counter.setText("当前 " + n + " 字" + (n > 1000 ? "（超过 1000 字）" : ""));
    }

    private void toast(String s) {
        try { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); } catch (Throwable ignored) { }
    }
}
