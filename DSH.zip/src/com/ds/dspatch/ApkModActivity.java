package com.ds.dspatch;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * 逆向改包：在容器里跑 apkmod（拆包 / 反编 dex / 回编译 / 签名），
 * 全部动作都在内置 Alpine 容器里执行，输出实时贴到页面上。
 */
public class ApkModActivity extends Activity {

    private TextView out;
    private ScrollView scroller;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private volatile boolean busy;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setTitle("逆向改包");

        final android.content.Context c = this;

        LinearLayout root = Ui.screen(c);

        LinearLayout head = Ui.card(c);
        head.addView(Ui.big(c, "逆向改包"));
        head.addView(Ui.sub(c, "容器里自带 apkmod 工具，也可以直接在终端 / AI 里用：\n"
                + "  apkmod init                准备工具链（内置版离线秒过；精简版走国内镜像）\n"
                + "  apkmod d app.apk           拆包（apktool，失败回退 zip）\n"
                + "  apkmod dex app.apk         反编 dex -> smali（改代码）\n"
                + "  apkmod b app.dir           回编译\n"
                + "  apkmod sign app.apk        对齐 + 签名\n"
                + "  apkmod push app-signed.apk 复制到 /sdcard/Download 去安装"),
                Ui.fillTop(c, 6));
        root.addView(head, Ui.fill());

        LinearLayout row = Ui.row(c);

        Button term = Ui.primary(c, "打开终端");
        term.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(ApkModActivity.this, TerminalActivity.class));
            }
        });
        row.addView(term, Ui.weight());

        Button init = Ui.ghost(c, "初始化工具链");
        init.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { run("apkmod init"); }
        });
        LinearLayout.LayoutParams p1 = Ui.weight();
        p1.leftMargin = Ui.dp(c, 8);
        row.addView(init, p1);

        Button help = Ui.ghost(c, "查看帮助");
        help.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { run("apkmod help"); }
        });
        LinearLayout.LayoutParams p2 = Ui.weight();
        p2.leftMargin = Ui.dp(c, 8);
        row.addView(help, p2);

        root.addView(row, Ui.fillTop(c, 12));

        LinearLayout outCard = Ui.card(c);
        out = Ui.mono(c, "点上面的按钮开始。首次用「初始化工具链」装依赖（要联网，几分钟）。");
        out.setTypeface(Typeface.MONOSPACE);
        outCard.addView(out, Ui.fill());

        scroller = new ScrollView(c);
        scroller.setBackgroundColor(Ui.BG);
        scroller.addView(outCard, new android.view.ViewGroup.LayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scroller, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        // 输出区自己就是滚动区，所以整页直接用 root，不再套一层 ScrollView
        setContentView(root);
    }

    /** 在容器里执行一条命令，输出实时贴到页面上。 */
    private void run(final String cmd) {
        if (busy) { toast("上一条还在跑，稍等"); return; }
        busy = true;
        out.setText("$ " + cmd + "\n");
        new Thread(new Runnable() {
            @Override public void run() {
                String text;
                try {
                    TermEnv.ensure(ApkModActivity.this, null);
                    text = TermEnv.execOnce(ApkModActivity.this, cmd, 900000L);
                } catch (Throwable t) {
                    text = "执行失败: " + t;
                }
                final String body = text;
                ui.post(new Runnable() {
                    @Override public void run() {
                        out.setText("$ " + cmd + "\n" + body);
                        scroller.post(new Runnable() {
                            @Override public void run() {
                                scroller.fullScroll(View.FOCUS_DOWN);
                            }
                        });
                        busy = false;
                    }
                });
            }
        }, "apkmod").start();
    }

    private void toast(String s) {
        try { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); } catch (Throwable ignored) { }
    }
}
