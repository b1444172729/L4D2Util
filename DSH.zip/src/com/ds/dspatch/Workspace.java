package com.ds.dspatch;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;

/**
 * 工作区（保存目录）。
 *
 * 以前对话记录会被写进「内部存储/Download/DeepSeekExport」，用户没法控制；
 * 现在改成：
 *   - 默认什么都不保存（除非在「关于 / 工具」页里打开开关）；
 *   - 用户可以用系统目录选择器挑一个文件夹当工作区，之后所有落盘都进那里；
 *   - 没挑工作区但打开了保存开关时，退回应用私有目录（files/DeepSeekExport）。
 */
final class Workspace {

    private static final String TAG = "DSWorkspace";
    private static final Charset UTF8 = Charset.forName("UTF-8");
    private static final String SP = "dspatch";
    private static final String KEY_URI = "workspace_uri";
    private static final String KEY_NAME = "workspace_name";
    private static final String PRIVATE_DIR = "DeepSeekExport";

    private Workspace() { }

    private static SharedPreferences sp(Context c) { return c.getSharedPreferences(SP, 0); }

    /** 系统目录选择器的 Intent（配合 startActivityForResult）。 */
    static Intent pickIntent() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        return i;
    }

    /** 用户选定的工作区显示名（没选返回空串）。 */
    static String name(Context c) {
        if (c == null) return "";
        return sp(c).getString(KEY_NAME, "");
    }

    static boolean has(Context c) {
        return uri(c) != null;
    }

    private static Uri uri(Context c) {
        if (c == null) return null;
        String s = sp(c).getString(KEY_URI, "");
        if (s == null || s.length() == 0) return null;
        try { return Uri.parse(s); } catch (Throwable t) { return null; }
    }

    /** 记住用户选的目录（并申请持久化读写权限）。 */
    static boolean setUri(Context c, Uri u) {
        if (c == null || u == null) return false;
        try {
            c.getContentResolver().takePersistableUriPermission(u,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        } catch (Throwable t) {
            Log.w(TAG, "持久化权限申请失败（本次仍可用）: " + t);
        }
        String label = u.getLastPathSegment();
        if (label == null) label = u.toString();
        int c1 = label.indexOf(':');
        if (c1 >= 0 && c1 + 1 < label.length()) label = label.substring(c1 + 1);
        sp(c).edit().putString(KEY_URI, u.toString()).putString(KEY_NAME, label).commit();
        return true;
    }

    static void clear(Context c) {
        if (c == null) return;
        sp(c).edit().remove(KEY_URI).remove(KEY_NAME).commit();
    }

    /** 写一个文件（覆盖）到工作区；没有工作区时退回应用私有目录。 */
    static void save(Context c, String fileName, String text) {
        if (c == null || fileName == null || text == null) return;
        Uri dir = uri(c);
        if (dir != null && saveToTree(c, dir, fileName, text)) return;
        savePrivate(c, fileName, text);
    }

    // ---------- SAF 目录 ----------

    private static boolean saveToTree(Context c, Uri dir, String fileName, String text) {
        String docId;
        try {
            docId = DocumentsContract.getTreeDocumentId(dir);
        } catch (Throwable t) {
            return false;
        }
        Uri parent = DocumentsContract.buildDocumentUriUsingTree(dir, docId);
        Uri doc = null;
        OutputStream os = null;
        try {
            doc = DocumentsContract.createDocument(c.getContentResolver(), parent,
                    "text/markdown", fileName);
        } catch (Throwable t) {
            doc = null;
        }
        if (doc == null) {
            // 同名文件已存在（或 provider 不支持创建）：直接定位它
            doc = DocumentsContract.buildDocumentUriUsingTree(dir, docId + "/" + fileName);
        }
        try {
            os = c.getContentResolver().openOutputStream(doc, "wt");
            if (os == null) return false;
            os.write(text.getBytes(UTF8));
            os.flush();
            return true;
        } catch (Throwable t) {
            Log.w(TAG, "写工作区失败 " + fileName + ": " + t);
            return false;
        } finally {
            try { if (os != null) os.close(); } catch (Throwable ignored) { }
        }
    }

    /** 应用私有目录兜底：不需要任何权限，文件管理器里也能看到。 */
    private static void savePrivate(Context c, String fileName, String text) {
        FileOutputStream os = null;
        try {
            File dir = privateDir(c);
            dir.mkdirs();
            os = new FileOutputStream(new File(dir, fileName));
            os.write(text.getBytes(UTF8));
            os.flush();
        } catch (Throwable t) {
            Log.w(TAG, "写私有目录失败 " + fileName + ": " + t);
        } finally {
            try { if (os != null) os.close(); } catch (Throwable ignored) { }
        }
    }

    static File privateDir(Context c) {
        File ext = c.getExternalFilesDir(null);
        if (ext == null) ext = c.getFilesDir();
        File f = new File(ext, PRIVATE_DIR);
        if (!f.exists()) f.mkdirs();
        return f;
    }

    /** 当前保存位置的人话描述。 */
    static String describe(Context c) {
        if (has(c)) return name(c);
        return "应用私有目录/" + PRIVATE_DIR;
    }

    /** 给「导出」用的 SAF 目录 Uri（没选过返回 null）。 */
    static Uri treeUri(Context c) {
        return uri(c);
    }

    /**
     * 把选定的 SAF 目录还原成真实文件系统路径，供容器直接写。
     * 只有 primary: / raw: 这两种 docId 能还原（系统「文件」选出来的基本都是）；
     * 第三方 provider（网盘等）拿不到真实路径，返回 null —— 那种情况导出走 SAF 写入。
     */
    static String realPath(Context c) {
        Uri u = uri(c);
        if (u == null) return null;
        try {
            String id = DocumentsContract.getTreeDocumentId(u);
            if (id == null || id.length() == 0) return null;
            if ("primary".equals(id) || "primary:".equals(id)) {
                File sd = android.os.Environment.getExternalStorageDirectory();
                return sd == null ? null : sd.getAbsolutePath();
            }
            if (id.startsWith("primary:")) {
                File sd = android.os.Environment.getExternalStorageDirectory();
                if (sd == null) return null;
                return new File(sd, id.substring("primary:".length())).getAbsolutePath();
            }
            if (id.startsWith("raw:")) return id.substring("raw:".length());
        } catch (Throwable t) {
            Log.w(TAG, "解析工作区真实路径失败: " + t);
        }
        return null;
    }
}
