package com.ds.dspatch;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * MCP（Model Context Protocol）客户端。
 *
 * 两种传输都支持：
 *   - http ：远程 Streamable HTTP / SSE 服务（POST JSON-RPC，按 id 匹配响应）
 *   - stdio：在「内置 Alpine 容器」里长驻一条命令（如 npx / python 的 MCP server），
 *            用换行分隔的 JSON-RPC 通信
 *
 * 配置存在 SharedPreferences("mcp") 的 servers 键里（JSON 数组）。
 */
public final class Mcp {

    static final String TAG = "DS-Mcp";
    private static final String SP = "mcp";
    private static final String KEY = "servers";
    private static final Charset U8 = Charset.forName("UTF-8");
    private static final String PROTO = "2024-11-05";
    private static final AtomicInteger SEQ = new AtomicInteger(1);

    private Mcp() { }

    // ---------- 配置 ----------

    public static final class Server {
        public String name = "";
        public String type = "http";     // http | stdio
        public String url = "";
        public String headers = "";      // JSON 对象字符串，如 {"Authorization":"Bearer xx"}
        public String command = "";      // stdio 启动命令，如 npx -y @modelcontextprotocol/server-filesystem /root
        public boolean enabled = true;

        public String describe() {
            return "http".equals(type) ? ("HTTP " + url) : ("STDIO " + command);
        }
    }

    public static List<Server> load(Context c) {
        List<Server> out = new ArrayList<Server>();
        try {
            SharedPreferences sp = c.getSharedPreferences(SP, 0);
            JSONArray arr = new JSONArray(sp.getString(KEY, "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o == null) continue;
                Server s = new Server();
                s.name = o.optString("name", "");
                s.type = o.optString("type", "http");
                s.url = o.optString("url", "");
                s.headers = o.optString("headers", "");
                s.command = o.optString("command", "");
                s.enabled = o.optBoolean("enabled", true);
                out.add(s);
            }
        } catch (Throwable t) {
            Log.w(TAG, "读取 MCP 配置失败: " + t);
        }
        return out;
    }

    public static void save(Context c, List<Server> list) {
        try {
            JSONArray arr = new JSONArray();
            for (Server s : list) {
                JSONObject o = new JSONObject();
                o.put("name", s.name);
                o.put("type", s.type);
                o.put("url", s.url);
                o.put("headers", s.headers);
                o.put("command", s.command);
                o.put("enabled", s.enabled);
                arr.put(o);
            }
            c.getSharedPreferences(SP, 0).edit()
                    .putString(KEY, arr.toString()).commit();
        } catch (Throwable t) {
            Log.e(TAG, "保存 MCP 配置失败: " + t);
        }
    }

    // ---------- JSON-RPC ----------

    private static JSONObject rpc(int id, String method, JSONObject params) throws Exception {
        JSONObject o = new JSONObject();
        o.put("jsonrpc", "2.0");
        o.put("id", id);
        o.put("method", method);
        if (params != null) o.put("params", params);
        return o;
    }

    private static JSONObject initParams() throws Exception {
        JSONObject p = new JSONObject();
        JSONObject caps = new JSONObject();
        JSONObject info = new JSONObject();
        info.put("name", "ds-enhance");
        info.put("version", "1.0.0");
        p.put("protocolVersion", PROTO);
        p.put("capabilities", caps);
        p.put("clientInfo", info);
        return p;
    }

    // ---------- 对外：列工具 ----------

    /** 列出某服务端的工具，返回 [{"server","tool","description","schema"}]。 */
    public static List<JSONObject> listTools(Context c, Server s) throws Exception {
        List<JSONObject> out = new ArrayList<JSONObject>();
        JSONObject r = request(c, s, 1, "initialize", initParams());
        if (r == null) throw new IllegalStateException("initialize 无响应");
        notify(c, s, "notifications/initialized", null);
        JSONObject res = request(c, s, 2, "tools/list", null);
        if (res == null) return out;
        JSONArray tools = res.optJSONArray("tools");
        if (tools == null) return out;
        for (int i = 0; i < tools.length(); i++) {
            JSONObject t = tools.optJSONObject(i);
            if (t == null) continue;
            JSONObject e = new JSONObject();
            e.put("server", s.name);
            e.put("tool", t.optString("name", ""));
            e.put("description", t.optString("description", ""));
            JSONObject sc = t.optJSONObject("inputSchema");
            e.put("schema", sc == null ? new JSONObject() : sc);
            out.add(e);
        }
        return out;
    }

    /** 调用某服务端的工具，返回纯文本结果。 */
    public static String call(Context c, Server s, String tool, JSONObject args) {
        try {
            JSONObject p = new JSONObject();
            p.put("name", tool);
            p.put("arguments", args == null ? new JSONObject() : args);
            JSONObject res = request(c, s, SEQ.getAndIncrement(), "tools/call", p);
            if (res == null) return "无响应";
            if (res.has("isError") && res.optBoolean("isError")) return "工具报错: " + summarize(res);
            return summarize(res);
        } catch (Throwable t) {
            return "调用失败: " + t;
        }
    }

    /** 把 tools/call 的 content 数组拼成文本。 */
    private static String summarize(JSONObject res) {
        try {
            JSONArray content = res.optJSONArray("content");
            if (content == null) return res.toString();
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < content.length(); i++) {
                JSONObject o = content.optJSONObject(i);
                if (o == null) continue;
                String t = o.optString("type", "");
                if ("text".equals(t)) sb.append(o.optString("text", ""));
                else sb.append("[").append(t).append(" ").append(o.optString("data", "")).append("]");
                if (i + 1 < content.length()) sb.append('\n');
            }
            return sb.length() == 0 ? res.toString() : sb.toString();
        } catch (Throwable t) {
            return res == null ? "" : res.toString();
        }
    }

    private static JSONObject request(Context c, Server s, int id, String method, JSONObject params) throws Exception {
        JSONObject req = rpc(id, method, params);
        if ("stdio".equals(s.type)) return stdioRequest(c, s, id, req);
        return httpRequest(s, id, req);
    }

    private static void notify(Context c, Server s, String method, JSONObject params) {
        try {
            JSONObject o = new JSONObject();
            o.put("jsonrpc", "2.0");
            o.put("method", method);
            if (params != null) o.put("params", params);
            if ("stdio".equals(s.type)) stdioWrite(c, s, o);
            else httpPost(s, o.toString());
        } catch (Throwable ignored) { }
    }

    // ---------- HTTP / SSE ----------

    private static JSONObject httpRequest(Server s, int id, JSONObject req) throws Exception {
        String body = httpPost(s, req.toString());
        if (body == null) return null;
        String t = body.trim();
        if (t.startsWith("{")) {
            JSONObject o = new JSONObject(t);
            return o.optJSONObject("result");
        }
        // SSE：逐行找 data: 里 id 匹配的那条
        String[] lines = t.split("\n");
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i].trim();
            if (!line.startsWith("data:")) continue;
            String payload = line.substring(5).trim();
            if (payload.length() == 0 || "[DONE]".equals(payload)) continue;
            try {
                JSONObject o = new JSONObject(payload);
                if (o.optInt("id", -1) == id) return o.optJSONObject("result");
            } catch (Throwable ignored) { }
        }
        return null;
    }

    private static String httpPost(Server s, String body) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(s.url).openConnection();
        try {
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setConnectTimeout(15000);
            c.setReadTimeout(90000);
            c.setRequestProperty("Content-Type", "application/json");
            c.setRequestProperty("Accept", "application/json, text/event-stream");
            applyHeaders(c, s.headers);
            OutputStream os = c.getOutputStream();
            os.write(body.getBytes(U8));
            os.flush();
            os.close();

            int code = c.getResponseCode();
            InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            String text = readAll(in);
            if (code >= 400) throw new IOException("HTTP " + code + " " + text);
            return text;
        } finally {
            try { c.disconnect(); } catch (Throwable ignored) { }
        }
    }

    private static void applyHeaders(HttpURLConnection c, String json) {
        if (json == null || json.trim().length() == 0) return;
        try {
            JSONObject o = new JSONObject(json);
            java.util.Iterator<String> it = o.keys();
            while (it.hasNext()) {
                String k = it.next();
                c.setRequestProperty(k, o.optString(k, ""));
            }
        } catch (Throwable ignored) { }
    }

    private static String readAll(InputStream in) throws Exception {
        if (in == null) return "";
        BufferedReader r = new BufferedReader(new InputStreamReader(in, U8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = r.readLine()) != null) {
            sb.append(line).append('\n');
            if (sb.length() > 400000) break;
        }
        r.close();
        return sb.toString();
    }

    // ---------- stdio（在容器里长驻） ----------

    private static final Map<String, Session> SESS = new ConcurrentHashMap<String, Session>();

    private static final class Session {
        Process p;
        Writer w;
        LinkedBlockingQueue<String> lines = new LinkedBlockingQueue<String>();
        Thread reader;
    }

    private static Session session(Context c, Server s) throws Exception {
        String key = s.name + "|" + s.command;
        Session se = SESS.get(key);
        if (se != null && se.p.isAlive()) return se;
        if (se != null) SESS.remove(key);

        se = new Session();
        ProcessBuilder pb = new ProcessBuilder(TermEnv.cmd(c, "/bin/sh", "-lc", s.command));
        TermEnv.applyEnv(pb, c);
        pb.redirectErrorStream(false);
        se.p = pb.start();
        se.w = new OutputStreamWriter(se.p.getOutputStream(), U8);
        final InputStream out = se.p.getInputStream();
        final LinkedBlockingQueue<String> q = se.lines;
        se.reader = new Thread(new Runnable() {
            @Override public void run() {
                try {
                    BufferedReader r = new BufferedReader(new InputStreamReader(out, U8));
                    String line;
                    while ((line = r.readLine()) != null) q.offer(line);
                } catch (Throwable ignored) { }
            }
        }, "mcp-stdio");
        se.reader.setDaemon(true);
        se.reader.start();
        SESS.put(key, se);
        return se;
    }

    private static void stdioWrite(Context c, Server s, JSONObject o) throws Exception {
        Session se = session(c, s);
        synchronized (se) {
            se.w.write(o.toString());
            se.w.write("\n");
            se.w.flush();
        }
    }

    private static JSONObject stdioRequest(Context c, Server s, int id, JSONObject req) throws Exception {
        Session se = session(c, s);
        synchronized (se) {
            se.w.write(req.toString());
            se.w.write("\n");
            se.w.flush();
            long deadline = System.currentTimeMillis() + 60000L;
            while (System.currentTimeMillis() < deadline) {
                String line = se.lines.poll(1, TimeUnit.SECONDS);
                if (line == null) continue;
                try {
                    JSONObject o = new JSONObject(line.trim());
                    if (o.optInt("id", -1) == id) return o.optJSONObject("result");
                } catch (Throwable ignored) { }
            }
        }
        return null;
    }

    public static void shutdown() {
        for (Session se : SESS.values()) {
            try { se.p.destroy(); } catch (Throwable ignored) { }
        }
        SESS.clear();
    }

    // ---------- 给隐藏提示词用的工具索引 ----------

    /** 联网拉取所有启用服务端的工具清单并缓存（UI 上的「刷新工具列表」调用）。 */
    public static String refreshIndex(Context c) {
        StringBuilder sb = new StringBuilder();
        for (Server s : load(c)) {
            if (!s.enabled) continue;
            try {
                for (JSONObject t : listTools(c, s)) {
                    sb.append("- ").append(s.name).append(" / ")
                      .append(t.optString("tool", "")).append("：")
                      .append(t.optString("description", "")).append('\n');
                }
            } catch (Throwable t) {
                sb.append("- ").append(s.name).append(" / (连接失败: ")
                  .append(String.valueOf(t)).append(")\n");
                Log.w(TAG, "列工具失败 " + s.name + ": " + t);
            }
        }
        String v = sb.toString();
        try {
            c.getSharedPreferences(SP, 0).edit().putString("cached_index", v).commit();
        } catch (Throwable ignored) { }
        return v;
    }

    /** 读缓存的工具清单；注入隐藏提示词时必须用这个（不能联网，否则会卡住请求）。 */
    public static String cachedIndex(Context c) {
        try {
            return c.getSharedPreferences(SP, 0).getString("cached_index", "");
        } catch (Throwable t) {
            return "";
        }
    }

    public static List<Server> enabled(Context c) {
        List<Server> out = new ArrayList<Server>();
        for (Server s : load(c)) if (s.enabled) out.add(s);
        return out;
    }

    public static Server find(Context c, String name) {
        for (Server s : load(c)) {
            if (s.enabled && s.name.equals(name)) return s;
        }
        return null;
    }
}
