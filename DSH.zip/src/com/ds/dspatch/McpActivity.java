package com.ds.dspatch;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

/**
 * MCP 服务端管理：新增 / 编辑 / 删除 / 启用，测试连接并刷新工具清单。
 *
 * 工具清单只在这里联网拉取并缓存；注入隐藏提示词时读缓存，避免卡住网络请求。
 */
public class McpActivity extends Activity {

    private EditText nameBox, urlBox, headerBox, cmdBox;
    private CheckBox stdioBox;
    private TextView logView;
    private LinearLayout listBox;
    private LinearLayout urlCard, cmdCard;
    private int editing = -1;

    private final Handler ui = new Handler(Looper.getMainLooper());

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setTitle("MCP 服务端");
        setContentView(build());
    }

    private View build() {
        final android.content.Context c = this;

        LinearLayout root = Ui.screen(c);

        LinearLayout head = Ui.card(c);
        head.addView(Ui.big(c, "MCP 服务端"));
        head.addView(Ui.sub(c, "支持两类：HTTP（Streamable HTTP / SSE）远程服务，或 stdio（在 Alpine 容器里跑常驻命令）。\n"
                + "AI 会输出 ```mcp + 一行 JSON 来调用，结果自动回传。"), Ui.fillTop(c, 6));
        root.addView(head, Ui.fill());

        // ---------- 表单 ----------
        root.addView(Ui.section(c, "新增 / 编辑"));

        LinearLayout form = Ui.card(c);

        form.addView(Ui.sub(c, "名称（AI 用它引用，如 fs）"), Ui.fill());
        nameBox = Ui.input(c, "例如 fs", "");
        form.addView(nameBox, Ui.fillTop(c, 4));

        stdioBox = Ui.check(c, "stdio 模式（在容器里跑命令，而不是连 HTTP）", false);
        form.addView(stdioBox, Ui.fillTop(c, 8));

        urlCard = Ui.column(c);
        urlCard.addView(Ui.sub(c, "HTTP 地址"), Ui.fill());
        urlBox = Ui.input(c, "https://host/mcp", "");
        urlCard.addView(urlBox, Ui.fillTop(c, 4));
        urlCard.addView(Ui.sub(c, "请求头 JSON（可空）"), Ui.fillTop(c, 10));
        headerBox = Ui.input(c, "{\"Authorization\":\"Bearer xx\"}", "");
        urlCard.addView(headerBox, Ui.fillTop(c, 4));
        form.addView(urlCard, Ui.fill());

        cmdCard = Ui.column(c);
        cmdCard.addView(Ui.sub(c, "stdio 启动命令"), Ui.fill());
        cmdBox = Ui.input(c, "npx -y @modelcontextprotocol/server-filesystem /root", "");
        cmdCard.addView(cmdBox, Ui.fillTop(c, 4));
        form.addView(cmdCard, Ui.fill());

        stdioBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                urlCard.setVisibility(on ? View.GONE : View.VISIBLE);
                cmdCard.setVisibility(on ? View.VISIBLE : View.GONE);
            }
        });
        cmdCard.setVisibility(View.GONE);

        root.addView(form, Ui.fillTop(c, 0));

        LinearLayout brow = Ui.row(c);
        Button save = Ui.primary(c, "保存");
        save.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { save(); }
        });
        brow.addView(save, Ui.weight());

        Button clear = Ui.ghost(c, "清空表单");
        clear.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { editing = -1; fill(null); }
        });
        LinearLayout.LayoutParams cp = Ui.weight();
        cp.leftMargin = Ui.dp(c, 8);
        brow.addView(clear, cp);

        Button refresh = Ui.ghost(c, "刷新工具清单");
        refresh.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { refreshTools(); }
        });
        LinearLayout.LayoutParams rp = Ui.weight();
        rp.leftMargin = Ui.dp(c, 8);
        brow.addView(refresh, rp);
        root.addView(brow, Ui.fillTop(c, 12));

        // ---------- 列表 ----------
        root.addView(Ui.section(c, "已配置服务端"));
        listBox = Ui.column(c);
        root.addView(listBox, Ui.fill());

        // ---------- 日志 ----------
        root.addView(Ui.section(c, "工具清单 / 连接日志"));
        LinearLayout logCard = Ui.card(c);
        logView = Ui.mono(c, "点「刷新工具清单」联网拉取。");
        logCard.addView(logView, Ui.fill());
        root.addView(logCard, Ui.fill());

        return Ui.scroll(c, root);
    }

    @Override protected void onResume() {
        super.onResume();
        render();
    }

    private void render() {
        if (listBox == null) return;
        listBox.removeAllViews();
        final List<Mcp.Server> list = Mcp.load(this);
        if (list.isEmpty()) {
            LinearLayout empty = Ui.card(this);
            empty.addView(Ui.body(this, "还没有服务端。"));
            empty.addView(Ui.sub(this, "填好上面的表单点「保存」即可添加。"), Ui.fillTop(this, 4));
            listBox.addView(empty, Ui.fillTop(this, 6));
            return;
        }
        final float d = getResources().getDisplayMetrics().density;
        for (int i = 0; i < list.size(); i++) {
            final int idx = i;
            final Mcp.Server s = list.get(i);

            LinearLayout card = Ui.card(this);

            LinearLayout top = Ui.row(this);

            CheckBox on = Ui.check(this, "", s.enabled);
            on.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override public void onCheckedChanged(CompoundButton b, boolean v) {
                    List<Mcp.Server> l = Mcp.load(McpActivity.this);
                    if (idx < l.size()) {
                        l.get(idx).enabled = v;
                        Mcp.save(McpActivity.this, l);
                    }
                }
            });
            top.addView(on, Ui.fill());

            TextView n = new TextView(this);
            n.setTextSize(15);
            n.setTextColor(Ui.TEXT);
            n.setTypeface(Typeface.DEFAULT_BOLD);
            n.setText(s.name + "  [" + s.type + "]");
            LinearLayout.LayoutParams np = Ui.weight();
            np.leftMargin = Ui.dp(this, 4);
            top.addView(n, np);
            card.addView(top, Ui.fill());

            TextView u = Ui.sub(this, s.describe());
            card.addView(u, Ui.fillTop(this, 4));

            LinearLayout brow2 = Ui.row(this);
            Button edit = Ui.small(this, "编辑");
            edit.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { editing = idx; fill(s); }
            });
            brow2.addView(edit, Ui.weight());

            Button del = Ui.small(this, "删除");
            del.setTextColor(Ui.RED);
            del.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { confirmDelete(idx, s.name); }
            });
            LinearLayout.LayoutParams dp2 = Ui.weight();
            dp2.leftMargin = Ui.dp(this, 8);
            brow2.addView(del, dp2);
            card.addView(brow2, Ui.fillTop(this, 10));

            listBox.addView(card, Ui.fillTop(this, 10));
        }
    }

    private void fill(Mcp.Server s) {
        if (s == null) {
            nameBox.setText(""); urlBox.setText(""); headerBox.setText(""); cmdBox.setText("");
            stdioBox.setChecked(false);
            return;
        }
        nameBox.setText(s.name);
        urlBox.setText(s.url);
        headerBox.setText(s.headers);
        cmdBox.setText(s.command);
        stdioBox.setChecked("stdio".equals(s.type));
    }

    private void save() {
        String name = nameBox.getText().toString().trim();
        if (name.length() == 0) { toast("名称不能为空"); return; }
        boolean stdio = stdioBox.isChecked();
        String url = urlBox.getText().toString().trim();
        String cmd = cmdBox.getText().toString().trim();
        if (!stdio && url.length() == 0) { toast("HTTP 模式要填地址"); return; }
        if (stdio && cmd.length() == 0) { toast("stdio 模式要填启动命令"); return; }

        List<Mcp.Server> list = Mcp.load(this);
        Mcp.Server s;
        if (editing >= 0 && editing < list.size()) s = list.get(editing);
        else { s = new Mcp.Server(); list.add(s); }

        s.name = name;
        s.type = stdio ? "stdio" : "http";
        s.url = url;
        s.command = cmd;
        s.headers = headerBox.getText().toString().trim();
        s.enabled = true;

        Mcp.save(this, list);
        Mcp.shutdown();          // 配置变了，旧的长驻进程作废
        editing = -1;
        fill(null);
        render();
        toast("已保存 " + name);
    }

    private void confirmDelete(final int idx, final String name) {
        new AlertDialog.Builder(this)
                .setTitle("删除服务端")
                .setMessage("确定删除「" + name + "」？")
                .setNegativeButton("取消", null)
                .setPositiveButton("删除", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dlg, int w) {
                        List<Mcp.Server> l = Mcp.load(McpActivity.this);
                        if (idx < l.size()) l.remove(idx);
                        Mcp.save(McpActivity.this, l);
                        Mcp.shutdown();
                        render();
                    }
                }).show();
    }

    private void refreshTools() {
        logView.setText("正在连接并拉取工具清单…");
        final List<Mcp.Server> list = Mcp.enabled(this);
        if (list.isEmpty()) { logView.setText("没有启用的服务端。"); return; }
        new Thread(new Runnable() {
            @Override public void run() {
                final StringBuilder sb = new StringBuilder();
                for (Mcp.Server s : list) {
                    sb.append("== ").append(s.name).append(" ==\n");
                    try {
                        for (org.json.JSONObject t : Mcp.listTools(McpActivity.this, s)) {
                            sb.append("  · ").append(t.optString("tool", ""))
                              .append("：").append(t.optString("description", "")).append('\n');
                        }
                    } catch (Throwable t) {
                        sb.append("  连接失败: ").append(t).append('\n');
                    }
                }
                String cached = Mcp.refreshIndex(McpActivity.this);
                final String out = sb.toString()
                        + (cached.length() == 0 ? "\n(缓存为空)" : "\n已缓存 " + cached.split("\n").length + " 条工具");
                ui.post(new Runnable() { @Override public void run() { logView.setText(out); } });
            }
        }, "mcp-refresh").start();
    }

    private void toast(String s) {
        try { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); } catch (Throwable ignored) { }
    }
}
