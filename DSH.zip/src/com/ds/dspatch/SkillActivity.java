package com.ds.dspatch;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

/**
 * 技能（Skill）管理：导入 Markdown 技能包，列表查看、删除。
 *
 * 只有「名字 + 一句描述」会被注入隐藏提示词，AI 用 ```skill 技能名 才会取全文。
 */
public class SkillActivity extends Activity {

    private static final int REQ_IMPORT = 0x61;

    private LinearLayout listBox;
    private TextView status;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setTitle("技能");
        setContentView(build());
    }

    private View build() {
        final android.content.Context c = this;

        LinearLayout root = Ui.screen(c);

        LinearLayout head = Ui.card(c);
        head.addView(Ui.big(c, "技能"));
        head.addView(Ui.sub(c, "内置技能包已预装（反向工程 / 逆向 / 改包类），也可以导入 .md。\n"
                + "只有「技能名 + 描述」会悄悄带进请求；AI 输出 ```skill 技能名 时才把正文回传 —— "
                + "正文不进你的聊天框。目录型技能（SKILL.md + references/ + scripts/）会挂到容器 /skills/ 下。"),
                Ui.fillTop(c, 6));
        root.addView(head, Ui.fill());

        Button imp = Ui.primary(c, "＋ 导入技能文件（可多选）");
        imp.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { pick(); }
        });
        root.addView(imp, Ui.fillTop(c, 12));

        status = Ui.sub(c, "");
        status.setPadding(Ui.dp(c, 4), Ui.dp(c, 10), 0, Ui.dp(c, 2));
        root.addView(status, Ui.fill());

        listBox = Ui.column(c);
        root.addView(listBox, Ui.fillTop(c, 4));

        // 首次打开时展开内置技能包（幂等），完成后刷新列表
        new Thread(new Runnable() {
            @Override public void run() {
                Skill.ensurePack(SkillActivity.this);
                runOnUiThread(new Runnable() {
                    @Override public void run() { render(); }
                });
            }
        }, "skill-pack").start();

        return Ui.scroll(c, root);
    }

    @Override protected void onResume() {
        super.onResume();
        render();
    }

    private void render() {
        if (listBox == null) return;
        listBox.removeAllViews();
        List<Skill.Item> items = Skill.list(this);

        if (status != null) {
            status.setText("内置包：" + (Skill.packInstalled(this) ? "已展开" : "未展开")
                    + "　·　当前技能：" + items.size() + " 个");
        }

        if (items.isEmpty()) {
            LinearLayout empty = Ui.card(this);
            empty.addView(Ui.body(this, "还没有技能。"));
            empty.addView(Ui.sub(this, "点上面的按钮导入 .md 文件，或等待内置技能包展开后重新进入本页。"),
                    Ui.fillTop(this, 4));
            listBox.addView(empty, Ui.fillTop(this, 6));
            return;
        }

        for (final Skill.Item it : items) {
            LinearLayout card = Ui.card(this);

            LinearLayout top = Ui.row(this);

            TextView n = new TextView(this);
            n.setText(it.name);
            n.setTextSize(15);
            n.setTextColor(Ui.TEXT);
            n.setTypeface(Typeface.DEFAULT_BOLD);
            top.addView(n, Ui.weight());

            TextView kind = new TextView(this);
            kind.setText(it.dir ? "目录型" : "文件");
            kind.setTextSize(11);
            kind.setTextColor(Ui.ACCENT);
            top.addView(kind, Ui.fill());
            card.addView(top, Ui.fill());

            TextView s = Ui.sub(this, it.desc.length() == 0 ? "（无描述）" : it.desc);
            card.addView(s, Ui.fillTop(this, 4));

            Button del = Ui.danger(this, "删除");
            del.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { confirmDelete(it.name); }
            });
            card.addView(del, Ui.fillTop(this, 10));

            listBox.addView(card, Ui.fillTop(this, 10));
        }
    }

    private void confirmDelete(final String name) {
        new AlertDialog.Builder(this)
                .setTitle("删除技能")
                .setMessage("确定删除「" + name + "」？")
                .setNegativeButton("取消", null)
                .setPositiveButton("删除", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        Skill.delete(SkillActivity.this, name);
                        render();
                        toast("已删除 " + name);
                    }
                }).show();
    }

    private void pick() {
        try {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            startActivityForResult(i, REQ_IMPORT);
        } catch (Throwable t) {
            toast("打不开文件选择器: " + t);
        }
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_IMPORT || res != RESULT_OK || data == null) return;
        int n = 0;
        try {
            if (data.getClipData() != null) {
                int count = data.getClipData().getItemCount();
                for (int i = 0; i < count; i++) {
                    n += importOne(data.getClipData().getItemAt(i).getUri());
                }
            } else if (data.getData() != null) {
                n += importOne(data.getData());
            }
        } catch (Throwable t) {
            toast("导入失败: " + t);
        }
        render();
        if (n > 0) toast("已导入 " + n + " 个技能");
    }

    private int importOne(Uri u) {
        try {
            String name = displayName(u);
            Skill.importSkill(this, getContentResolver().openInputStream(u), name);
            return 1;
        } catch (Throwable t) {
            toast("导入失败 " + u + ": " + t);
            return 0;
        }
    }

    private String displayName(Uri u) {
        Cursor c = null;
        try {
            c = getContentResolver().query(u, null, null, null, null);
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex("_display_name");
                if (i >= 0) {
                    String s = c.getString(i);
                    if (s != null && s.length() > 0) return s;
                }
            }
        } catch (Throwable ignored) {
        } finally {
            if (c != null) try { c.close(); } catch (Throwable ignored) { }
        }
        String p = u.getLastPathSegment();
        return p == null ? "skill" : p;
    }

    private void toast(String s) {
        try { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); } catch (Throwable ignored) { }
    }
}
