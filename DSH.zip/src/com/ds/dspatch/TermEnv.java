package com.ds.dspatch;

import android.content.Context;
import android.content.res.AssetManager;
import android.system.Os;
import android.util.Log;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PushbackInputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.GZIPInputStream;

/**
 * 内置 Linux 环境（PRoot + Alpine）。
 *
 * 不需要手机 root，也不依赖 Magisk：
 *   - proot / proot-loader / libtalloc / libandroid-shmem 作为 lib*.so 打包进 APK，
 *     安装时被解到 nativeLibraryDir（该目录对应用可执行），直接 exec 即可；
 *   - Alpine rootfs 作为资产打包，首次使用时解到 应用私有目录/term/rootfs；
 *   - 用 proot 的 “-0” 让容器内 uid 显示为 0（只是显示层伪装，内核权限仍是普通应用）。
 */
final class TermEnv {

    static final String TAG = "DS-Term";

    private static final Charset U8 = Charset.forName("UTF-8");
    private static final String ASSET = "term/alpine.tar.gz";

    private TermEnv() { }

    static File base(Context c) {
        File f = new File(c.getFilesDir(), "term");
        if (!f.exists()) f.mkdirs();
        return f;
    }

    static File rootfs(Context c) { return new File(base(c), "rootfs"); }

    static File tmp(Context c) {
        File f = new File(base(c), "tmp");
        if (!f.exists()) f.mkdirs();
        return f;
    }

    private static File marker(Context c) { return new File(base(c), ".rootfs.ok"); }

    /** proot 相关 .so 的私有兜底目录（nativeLibraryDir 里找不到时从这里跑）。 */
    static File libDir(Context c) {
        File f = new File(base(c), "lib");
        if (!f.exists()) f.mkdirs();
        return f;
    }

    /** 环境是否就绪（rootfs 解好、/bin/sh 存在、能拿到可执行的 proot）。 */
    static boolean ready(Context c) {
        try {
            return marker(c).isFile()
                    && lexists(new File(rootfs(c), "bin/sh"))
                    && prootDir(c) != null;
        } catch (Throwable t) {
            return false;
        }
    }

    /**
     * 判断路径存在，但**不跟随符号链接**。
     * Alpine 的 /bin/sh 是绝对软链 -> /bin/busybox，用 File.exists() 会把它解析到
     * 设备真实的 /bin/busybox（不存在）从而误判「环境未就绪」；必须用 lstat。
     */
    private static boolean lexists(File f) {
        try { Os.lstat(f.getAbsolutePath()); return true; }
        catch (Throwable t) { return false; }
    }

    /**
     * 找到可执行 proot 所在目录：
     *   1) 优先 nativeLibraryDir（正常安装时系统已把 lib*.so 解出来，可直接 exec）；
     *   2) 没有就从 APK 自己的 lib/ 里把 proot 相关 .so 解到 files/term/lib 再跑。
     * 某些定制包 nativeLibraryDir 里拿不到 libproot.so，兜底这一步能让容器照常起来。
     */
    static File prootDir(Context c) {
        try {
            File nd = new File(nativeDir(c));
            if (new File(nd, "libproot.so").exists()) return nd;
        } catch (Throwable ignored) { }
        File ld = libDir(c);
        if (new File(ld, "libproot.so").exists()) return ld;
        if (extractLibs(c, ld)) return ld;
        return null;
    }

    private static final String[] PROOT_LIBS = {
            "libproot.so", "libproot_loader.so", "libtalloc.so", "libandroid-shmem.so"
    };

    /** 从安装包（sourceDir）的 lib/<abi>/ 里解出 proot 相关 .so。 */
    private static boolean extractLibs(Context c, File dst) {
        String abi;
        try {
            String[] abis = android.os.Build.SUPPORTED_ABIS;
            abi = (abis != null && abis.length > 0) ? abis[0] : "arm64-v8a";
        } catch (Throwable t) {
            abi = "arm64-v8a";
        }
        dst.mkdirs();
        java.util.zip.ZipFile zf = null;
        try {
            zf = new java.util.zip.ZipFile(new File(c.getApplicationInfo().sourceDir));
            boolean gotProot = false;
            for (String lib : PROOT_LIBS) {
                java.util.zip.ZipEntry ze = zf.getEntry("lib/" + abi + "/" + lib);
                if (ze == null) {
                    java.util.Enumeration<? extends java.util.zip.ZipEntry> en = zf.entries();
                    while (en.hasMoreElements()) {
                        java.util.zip.ZipEntry e2 = en.nextElement();
                        if (e2.getName().endsWith("/" + lib)) { ze = e2; break; }
                    }
                }
                if (ze == null) continue;
                InputStream in = zf.getInputStream(ze);
                File out = new File(dst, lib);
                FileOutputStream os = new FileOutputStream(out);
                byte[] b = new byte[1 << 15];
                int n;
                while ((n = in.read(b)) > 0) os.write(b, 0, n);
                os.flush();
                os.close();
                in.close();
                try { Os.chmod(out.getAbsolutePath(), 0755); } catch (Throwable ignored) { }
                try { out.setExecutable(true, false); } catch (Throwable ignored) { }
                if ("libproot.so".equals(lib)) gotProot = true;
            }
            if (gotProot) Log.i(TAG, "proot 已从 APK 解出 -> " + dst);
            return gotProot;
        } catch (Throwable t) {
            Log.w(TAG, "从 APK 解 proot 失败: " + t);
            return false;
        } finally {
            if (zf != null) try { zf.close(); } catch (Throwable ignored) { }
        }
    }

    /** 逐项自检，回退时把「到底哪一项没过」原样告诉用户 / AI。 */
    static String diagnose(Context c) {
        StringBuilder sb = new StringBuilder();
        sb.append("rootfs 标记=").append(marker(c).isFile() ? "有" : "无");
        sb.append("，rootfs/bin/sh=").append(lexists(new File(rootfs(c), "bin/sh")) ? "有" : "无");
        String ndPath;
        try { ndPath = nativeDir(c); } catch (Throwable t) { ndPath = "(取不到)"; }
        boolean ndOk = false;
        try { ndOk = new File(ndPath, "libproot.so").exists(); } catch (Throwable ignored) { }
        sb.append("，nativeLibDir(").append(ndPath).append(")=").append(ndOk ? "有 libproot.so" : "无 libproot.so");
        File pd = prootDir(c);
        sb.append("，可用 proot=").append(pd != null ? pd.getAbsolutePath() : "无");
        return sb.toString();
    }

    static boolean hasAsset(Context c, String name) {
        InputStream in = null;
        try { in = c.getAssets().open(name); return true; }
        catch (Throwable t) { return false; }
        finally { if (in != null) try { in.close(); } catch (Throwable ignored) { } }
    }

    /** 内置工具目录（解出来的 / 精简版下载后的），容器里挂到 /opt/dt。 */
    static File toolsDir(Context c) {
        File f = new File(base(c), "tools");
        if (!f.exists()) f.mkdirs();
        return f;
    }

    static String nativeDir(Context c) {
        return c.getApplicationInfo().nativeLibraryDir;
    }

    /**
     * 首次使用：把 Alpine rootfs 解开。已经解好会直接返回。
     *
     * @param progress 可选回调，用来在终端里显示进度（在主线程外的线程调用）。
     */
    static synchronized void ensure(Context c, Progress progress) throws IOException {
        if (ready(c)) { writeScripts(c); return; }
        File rf = rootfs(c);
        deleteRec(rf);
        rf.mkdirs();
        say(progress, "正在解开 Alpine rootfs…");
        InputStream in = new BufferedInputStream(c.getAssets().open(ASSET), 1 << 16);
        untar(maybeGunzip(in), rf);
        say(progress, "正在写入 DNS 与国内软件源配置…");
        File etc = new File(rf, "etc");
        etc.mkdirs();
        writeText(new File(etc, "resolv.conf"),
                "nameserver 223.5.5.5\nnameserver 119.29.29.29\nnameserver 8.8.8.8\n");
        writeText(new File(etc, "hosts"),
                "127.0.0.1 localhost localhost.localdomain\n::1 localhost\n");
        // Alpine 官方源（dl-cdn.alpinelinux.org）在国内基本连不上，直接用清华镜像，
        // 这样容器里 `apk add` / `javadev deps` 才能装上工具链。
        File apkEtc = new File(etc, "apk");
        apkEtc.mkdirs();
        writeText(new File(apkEtc, "repositories"),
                "https://mirrors.tuna.tsinghua.edu.cn/alpine/v3.20/main\n"
              + "https://mirrors.tuna.tsinghua.edu.cn/alpine/v3.20/community\n");
        // 叠加层：只有随包资产存在时才解（现在只留 zip 之类小工具；
        // JVM 和逆向工具链改成进容器后用国内镜像装：javadev init / apkmod init）
        installOverlay(c, rf, "term/extras.tar.gz", progress, null);
        writeScripts(c);
        marker(c).createNewFile();
        say(progress, "环境就绪：Alpine 容器（PRoot 沙箱，容器内 uid=0）");
    }

    /** 强制重装环境。 */
    static void reset(Context c) {
        try { marker(c).delete(); } catch (Throwable ignored) { }
        deleteRec(rootfs(c));
    }

    /**
     * 把随包资产里的容器辅助脚本装进 rootfs（幂等，每次进入都补齐）：
     *   /usr/local/bin/apkmod    —— 拆包 / 改 dex / 回编译 / 签名 / 安装
     *   /usr/local/bin/javadev   —— Java 开发 / 构建 APK
     *   /usr/local/bin/webdev    —— 网页开发（生成精美单页 / 本地预览）
     *   /usr/local/bin/flutterdev—— Flutter 开发（装 SDK / 构建 web 与 apk）
     *   /usr/local/bin/langdev   —— 多语言工具链（python/node/go/rust/c/cpp/php/ruby…）
     *   /usr/local/bin/ssh       —— 连服务器 / 远程执行 / 传文件
     * 并把内置工具解到 files/term/tools（容器里挂到 /opt/dt）。
     */
    static void writeScripts(Context c) {
        try {
            File bin = new File(rootfs(c), "usr/local/bin");
            bin.mkdirs();
            copyAsset(c, "term/apkmod.sh", new File(bin, "apkmod"), 0755);
            copyAsset(c, "term/javadev.sh", new File(bin, "javadev"), 0755);
            copyAsset(c, "term/webdev.sh", new File(bin, "webdev"), 0755);
            copyAsset(c, "term/flutterdev.sh", new File(bin, "flutterdev"), 0755);
            copyAsset(c, "term/langdev.sh", new File(bin, "langdev"), 0755);
            copyAsset(c, "term/ssh.sh", new File(bin, "ssh"), 0755);
            File root = new File(rootfs(c), "root");
            root.mkdirs();
            copyAsset(c, "term/README.txt", new File(root, "README.txt"), 0644);
            ensureTools(c);
        } catch (Throwable t) {
            Log.w(TAG, "写入容器脚本失败: " + t);
        }
    }

    /** 解出内置工具（若无该资产则为精简版，什么都不做；下载交给 apkmod/javadev init）。 */
    private static void ensureTools(Context c) {
        File t = toolsDir(c);
        if (new File(t, "bin/aapt2").exists()) return;      // 已解出 / 精简版已下好
        try {
            String[] l = c.getAssets().list("term/tools");
            if (l == null || l.length == 0) return;         // 精简版：没有内置工具
            copyAssetDir(c.getAssets(), "term/tools", t);
            File b = new File(t, "bin");
            File[] fs = b.listFiles();
            if (fs != null) for (File f : fs) {
                try { Os.chmod(f.getAbsolutePath(), 0755); } catch (Throwable ignored) { }
                try { f.setExecutable(true, false); } catch (Throwable ignored) { }
            }
            Log.i(TAG, "内置工具已解出 -> " + t);
        } catch (Throwable x) {
            Log.w(TAG, "解内置工具失败: " + x);
        }
    }

    private static int copyAssetDir(android.content.res.AssetManager am, String from, File to) throws IOException {
        String[] names = am.list(from);
        if (names == null) return 0;
        int n = 0;
        for (String name : names) {
            String child = from + "/" + name;
            String[] sub = am.list(child);
            if (sub != null && sub.length > 0) {
                File d = new File(to, name);
                d.mkdirs();
                n += copyAssetDir(am, child, d);
            } else {
                InputStream in = null;
                try {
                    in = am.open(child);
                    File f = new File(to, name);
                    File parent = f.getParentFile();
                    if (parent != null) parent.mkdirs();
                    FileOutputStream os = new FileOutputStream(f);
                    byte[] b2 = new byte[1 << 15];
                    int r;
                    while ((r = in.read(b2)) > 0) os.write(b2, 0, r);
                    os.flush();
                    os.close();
                    f.setReadable(true, false);
                    n++;
                } catch (IOException e) {
                    new File(to, name).mkdirs();
                } finally {
                    if (in != null) try { in.close(); } catch (Throwable ignored) { }
                }
            }
        }
        return n;
    }

    /** 把某个 tar.gz 资产解开叠加进 rootfs；资产不存在则跳过。 */
    private static void installOverlay(Context c, File rf, String asset,
                                       Progress progress, String msg) throws IOException {
        if (!hasAsset(c, asset)) return;
        if (msg != null) say(progress, msg);
        InputStream in = new BufferedInputStream(c.getAssets().open(asset), 1 << 16);
        untar(maybeGunzip(in), rf);
    }

    private static void copyAsset(Context c, String asset, File dst, int mode) throws IOException {
        InputStream in = c.getAssets().open(asset);
        FileOutputStream os = new FileOutputStream(dst);
        byte[] b = new byte[1 << 15];
        int n;
        while ((n = in.read(b)) > 0) os.write(b, 0, n);
        os.flush();
        os.close();
        in.close();
        try { Os.chmod(dst.getAbsolutePath(), mode); } catch (Throwable ignored) { }
        try { dst.setExecutable(true, false); } catch (Throwable ignored) { }
    }

    // ---------- 启动 proot ----------

    /** 组一条 proot 命令行：proot [选项…] <guest 参数…> */
    static String[] cmd(Context c, String... guest) {
        File rf = rootfs(c);
        File pd = prootDir(c);
        String prootBin = (pd != null ? pd.getAbsolutePath() : nativeDir(c)) + "/libproot.so";
        String tp = tmp(c).getAbsolutePath();

        // proot 的绑定目标点需要先在 rootfs 里存在
        mkdirs(new File(rf, "sdcard"));
        mkdirs(new File(rf, "storage/emulated/0"));
        mkdirs(new File(rf, "tmp"));
        mkdirs(new File(rf, "root"));
        mkdirs(new File(rf, "dev"));

        // 技能目录绑进容器（/skills）：AI 可直接读参考资料、跑技能里的脚本
        File skillDir = new File(c.getFilesDir(), "skills");
        skillDir.mkdirs();
        mkdirs(new File(rf, "skills"));
        mkdirs(new File(rf, "sdcard"));

        // 工具目录绑进容器（/opt/dt）：内置 aapt2/zipalign/r8/apktool/android.jar 等
        File toolDir = toolsDir(c);
        mkdirs(new File(rf, "opt/dt"));
        mkdirs(new File(rf, "opt"));

        List<String> a = new ArrayList<String>();
        a.add(prootBin);
        a.add("--link2symlink");
        a.add("-0");                       // 沙箱内伪装 uid=0 → root
        a.add("-r"); a.add(rf.getAbsolutePath());
        a.add("-w"); a.add("/root");
        a.add("-b"); a.add("/dev");
        addBind(a, "/proc");
        addBind(a, "/sys");
        addBind(a, "/sdcard");
        addBind(a, "/storage");
        a.add("-b"); a.add(tp + ":/tmp");
        a.add("-b"); a.add(skillDir.getAbsolutePath() + ":/skills");
        a.add("-b"); a.add(toolDir.getAbsolutePath() + ":/opt/dt");
        for (String g : guest) a.add(g);
        return a.toArray(new String[0]);
    }

    private static void addBind(List<String> a, String host) {
        if (new File(host).exists()) {
            a.add("-b");
            a.add(host + ":" + host);
        }
    }

    /** 交互式登录 shell（供终端页用）。 */
    static String[] loginCmd(Context c) {
        return cmd(c, "/bin/sh", "-l");
    }

    static void applyEnv(ProcessBuilder pb, Context c) {
        java.util.Map<String, String> e = pb.environment();
        File pd = prootDir(c);
        String pdPath = (pd != null ? pd.getAbsolutePath() : nativeDir(c));
        e.put("LD_LIBRARY_PATH", pdPath);
        e.put("PROOT_LOADER", pdPath + "/libproot_loader.so");
        e.put("PROOT_TMP_DIR", tmp(c).getAbsolutePath());
        e.put("PROOT_NO_SECCOMP", "1");
        e.put("PROOT_VERBOSE", "0");
        e.put("HOME", "/root");
        e.put("TERM", "xterm-256color");
        e.put("LANG", "C.UTF-8");
        e.put("PATH", "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin");
        // 告诉脚本"产物该往哪放"：用户选的工作区真实路径，或已授权时的 /sdcard/Download。
        // 拿不到就留空，脚本会退到 App 私有目录、最后落到容器导出区 /root/export/。
        try {
            String tgt = Export.containerTarget(c);
            if (tgt != null && tgt.length() > 0) e.put("DS_EXPORT", tgt);
        } catch (Throwable ignored) { }
    }

    /** 在沙箱里跑一条命令并取回输出（给 AI 执行命令闭环用）。 */
    static String execOnce(Context c, String command) throws Exception {
        return execOnce(c, command, 180000L);
    }

    /** 同上，可指定超时（安装大包时给长一点）。 */
    static String execOnce(Context c, String command, long timeoutMs) throws Exception {
        ProcessBuilder pb = new ProcessBuilder(cmd(c, "/bin/sh", "-c", command));
        applyEnv(pb, c);
        pb.redirectErrorStream(true);
        Process p = pb.start();
        byte[] buf = new byte[8192];
        StringBuilder out = new StringBuilder();
        InputStream in = p.getInputStream();
        long deadline = System.currentTimeMillis() + timeoutMs;
        int n;
        while ((n = in.read(buf)) > 0) {
            if (out.length() < 400000) out.append(new String(buf, 0, n, U8));
            if (System.currentTimeMillis() > deadline) { p.destroy(); break; }
        }
        p.waitFor();
        return out.toString();
    }

    // ---------- 解压 ----------

    private static InputStream maybeGunzip(InputStream in) throws IOException {
        PushbackInputStream pb = new PushbackInputStream(in, 2);
        int b0 = pb.read();
        int b1 = pb.read();
        if (b1 >= 0) pb.unread(b1);
        if (b0 >= 0) pb.unread(b0);
        if (b0 == 0x1f && b1 == 0x8b) return new GZIPInputStream(pb, 1 << 16);
        return pb;
    }

    /** 极简 tar 解包：支持 普通文件 / 目录 / 符号链接。 */
    private static void untar(InputStream tar, File out) throws IOException {
        byte[] h = new byte[512];
        List<String[]> dirModes = new ArrayList<String[]>();
        while (readFully(tar, h, 512)) {
            if (isZero(h)) break;

            String name = cstr(h, 0, 100);
            String prefix = cstr(h, 345, 155);
            if (prefix.length() > 0) name = prefix + "/" + name;
            name = name.replace('\\', '/');
            while (name.startsWith("./")) name = name.substring(2);
            if (name.startsWith("/")) name = name.substring(1);

            long size = oct(h, 124, 12);
            int mode = (int) oct(h, 100, 8);
            int type = h[156] & 0xFF;
            String link = cstr(h, 157, 100);
            long pad = ((size + 511) / 512) * 512;

            if (name.length() == 0 || name.contains("..")) { skipExact(tar, pad); continue; }

            File f = new File(out, name);
            if (type == '0' || type == 0) {                 // 普通文件
                File p = f.getParentFile();
                if (p != null) p.mkdirs();
                OutputStream os = new FileOutputStream(f);
                copyExact(tar, os, size);
                os.close();
                skipExact(tar, pad - size);
                chmod(f, mode);
            } else if (type == '5') {                       // 目录
                f.mkdirs();
                dirModes.add(new String[]{f.getAbsolutePath(), String.valueOf(mode)});
                skipExact(tar, pad);
            } else if (type == '2' || type == '1') {        // 符号链接 / 硬链接
                File p = f.getParentFile();
                if (p != null) p.mkdirs();
                try { if (f.exists()) f.delete(); } catch (Throwable ignored) { }
                try { Os.symlink(link, f.getAbsolutePath()); } catch (Throwable t) {
                    Log.w(TAG, "symlink 失败 " + name + " -> " + link + ": " + t);
                }
                skipExact(tar, pad);
            } else {                                        // 设备/管道/pax 头等，跳过
                skipExact(tar, pad);
            }
        }
        // 目录权限最后再设，避免解子项时被夺走写权限
        for (String[] dm : dirModes) {
            try { Os.chmod(dm[0], Integer.parseInt(dm[1])); } catch (Throwable ignored) { }
        }
    }

    private static void chmod(File f, int mode) {
        try { Os.chmod(f.getAbsolutePath(), mode); } catch (Throwable ignored) { }
        if ((mode & 0111) != 0) { try { f.setExecutable(true, false); } catch (Throwable ignored) { } }
    }

    private static boolean readFully(InputStream in, byte[] buf, int len) throws IOException {
        int off = 0;
        while (off < len) {
            int n = in.read(buf, off, len - off);
            if (n < 0) return false;
            off += n;
        }
        return true;
    }

    private static void copyExact(InputStream in, OutputStream os, long size) throws IOException {
        byte[] b = new byte[1 << 15];
        long left = size;
        while (left > 0) {
            int n = in.read(b, 0, (int) Math.min(b.length, left));
            if (n < 0) break;
            os.write(b, 0, n);
            left -= n;
        }
        os.flush();
    }

    private static void skipExact(InputStream in, long n) throws IOException {
        byte[] b = new byte[1 << 14];
        long left = n;
        while (left > 0) {
            int r = in.read(b, 0, (int) Math.min(b.length, left));
            if (r < 0) return;
            left -= r;
        }
    }

    private static boolean isZero(byte[] h) {
        for (int i = 0; i < h.length; i++) if (h[i] != 0) return false;
        return true;
    }

    private static String cstr(byte[] b, int off, int len) {
        int end = off;
        int lim = off + len;
        while (end < lim && b[end] != 0) end++;
        return new String(b, off, end - off, U8);
    }

    private static long oct(byte[] b, int off, int len) {
        // 兼容 base-256（高位为 1）与八进制两种写法
        if ((b[off] & 0x80) != 0) {
            long v = b[off] & 0x7f;
            for (int i = off + 1; i < off + len; i++) v = (v << 8) | (b[i] & 0xff);
            return v;
        }
        long v = 0;
        for (int i = off; i < off + len; i++) {
            int c = b[i] & 0xff;
            if (c == 0 || c == ' ') { if (v != 0) break; else continue; }
            if (c < '0' || c > '7') break;
            v = (v << 3) + (c - '0');
        }
        return v;
    }

    private static void mkdirs(File f) { if (!f.exists()) f.mkdirs(); }

    private static void writeText(File f, String s) {
        FileOutputStream os = null;
        try {
            File p = f.getParentFile();
            if (p != null) p.mkdirs();
            os = new FileOutputStream(f);
            os.write(s.getBytes(U8));
            os.flush();
        } catch (Throwable t) {
            Log.w(TAG, "写文件失败 " + f + ": " + t);
        } finally {
            if (os != null) try { os.close(); } catch (Throwable ignored) { }
        }
    }

    static void deleteRec(File f) {
        if (f == null || !f.exists()) return;
        if (f.isDirectory()) {
            File[] cs = f.listFiles();
            if (cs != null) for (File c : cs) deleteRec(c);
        }
        try { f.delete(); } catch (Throwable ignored) { }
    }

    private static void say(Progress p, String s) { if (p != null) p.onProgress(s); }

    interface Progress { void onProgress(String msg); }
}
