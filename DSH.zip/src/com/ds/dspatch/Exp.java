package com.ds.dspatch;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * 直接注入 DeepSeek APK 的助手类（不依赖 Xposed / LSPatch）。
 *
 * 通过三处 smali 注入被调用：
 *   1. com.deepseek.chat.App.attachBaseContext(Context)  -> init(Context)
 *   2. ao1.J(jn1)                                        -> captureVm(Object)  // ao1 = ViewModel
 *   3. k11.a(k11, gw8, if2)                              -> onEvent(k11, gw8)  // SSE 事件
 *
 * 注意：这些混淆类位于“默认包”（jadx 显示为 defpackage，实际无包名）。
 */
public final class Exp {

    private static final String C_CN1 = "cn1";
    private static final String C_JN1 = "jn1";

    private static final String TAG = "DSAutoContinue";

    private static final Charset UTF8 = Charset.forName("UTF-8");
    private static final long IDLE_MS = 1500L;
    /** 单会话内自动执行的轮数上限（到顶会提示，不再静默停）。 */
    private static final int MAX_EXEC = 60;
    private static final int MAX_TEXT = 200000;

    /** 内置环境说明：会自动加在每个会话的第一条用户消息前面。 */
    static final String TEACH_HEAD = "【环境说明】";
    public static final String TEACH = TEACH_HEAD
            + "你现在运行在一台装有完整 Linux 容器的 Android 手机上（Alpine / PRoot 沙箱，容器内 uid=0）。"
            + "你有三种能力，按需使用：\n"
            + "1) 执行命令：把命令放进 ```bash 或 ```sh 代码块，一条命令一块；\n"
            + "2) 调用 MCP 工具：输出 ```mcp 代码块，内容是一行 JSON：{\"server\":\"服务端名\",\"tool\":\"工具名\",\"args\":{...}}；\n"
            + "3) 加载技能：输出 ```skill 代码块，内容写技能名。目录型技能的资源在容器内 /skills/<技能名>/ 下，"
            + "需要参考资料或脚本时可直接 cat /skills/<技能名>/references/*.md 或运行里面的脚本。\n"
            + "首次执行命令会自动安装 Alpine 容器（容器内 uid=0），稍等即可；"
            + "JDK / 逆向工具链默认不预装，需要时先跑一次 `apkmod init` 或 `javadev init`（走国内镜像）。\n"
            + "做开发时用内置工具链，不要自己写临时构建脚本："
            + "`javadev`（Java → 原生 APK）、`webdev`（HTML/CSS/JS 网页，能本机预览 http://127.0.0.1:端口/）、"
            + "`flutterdev`（Flutter，先 `flutterdev info` 自检再决定能不能跑）；"
            + "写其它语言（Python / Node.js / Go / Rust / C·C++ / PHP / Ruby / Perl / Lua / R / Elixir 等）统一用 `langdev`："
            + "`langdev list` 看支持的语言、`langdev init <语言…>` 一键装（不给参数=常用一套）、"
            + "`langdev all` 装全部、`langdev run <语言> <文件>` 直接跑；"
            + "需要官方仓库里没有的包，一律 `langdev add <alpine包>` 或 `apk add <包>`。"
            + "要连服务器 / 远程执行 / 传文件用 `ssh`：先 `ssh init` 装客户端，"
            + "`ssh key` 生成密钥、`ssh host add <名> <user@host> [-p 端口] [-i 密钥]` 保存主机，"
            + "之后 `ssh run <名> \"命令\"` 远端执行、`ssh put`/`ssh get` 传文件。"
            + "容器里的 /root/README.txt 有完整用法。\n"
            + "每条命令返回的头部会标出实际执行环境：显示 `[环境] Alpine 容器 · PRoot 沙箱` 就是在容器里；"
            + "若显示 `[环境] 系统 sh（非容器…）`，说明容器这次没起来，请把后面的失败原因原样告诉用户，"
            + "不要改去折腾 AIDE / MT 之类的绕路，也不要因為一次回退就断言“无法出包 / 无法装环境”。\n"
            + "App 会自动执行并把结果回传给你，你再继续下一步。不要再回答“我无法执行命令”。\n\n";

    // AI 回复里出现这些语言的代码块 / @run 行时，才会被当成待执行命令
    private static final Set<String> SHELL_LANGS = new HashSet<String>(Arrays.asList(
            new String[]{"sh", "bash", "shell", "zsh", "console", "cmd", "bat", "powershell", "ps1", "run", "exec"}));

    private static final Set<String> MCP_LANGS = new HashSet<String>(Arrays.asList(
            new String[]{"mcp", "mcp-tool", "mcp_tool"}));

    private static final Set<String> SKILL_LANGS = new HashSet<String>(Arrays.asList(
            new String[]{"skill", "skills"}));

    /**
     * 视为「本轮回答结束」的 SSE 事件名。
     * 之前只认 close，若服务端用 finish / done 等收尾，就永远触发不了执行 —— 这是
     * 「命令发了却完全不回传、时好时坏」的主因。
     */
    private static final Set<String> CLOSE_EVENTS = new HashSet<String>(Arrays.asList(
            new String[]{"close", "finish", "finished", "done", "end", "stop", "complete",
                    "completed", "error", "cancel", "canceled", "cancelled"}));

    // 随回传结果一起发给 AI 的协议提醒，避免它一句「我无法执行命令」就不干了
    private static final String NUDGE =
            "\n(你现在可以在这台手机上执行命令、调用 MCP 工具、加载技能："
            + "命令用 ```bash / ```sh，MCP 用 ```mcp + 一行 JSON，技能用 ```skill + 技能名。"
            + "App 会自动执行并把结果回传给你。不要再回答“我无法执行命令”。)" ;

    /** 自定义人设文件（放在应用私有目录，用户在「关于/工具」或全屏编辑页里改）。 */
    private static final String PERSONA_FILE = "persona.txt";
    /** 内置人设选择（无自定义时用哪个）：reverse=逆向人设，free=无限制人设，dev=开发人设。 */
    static final String KIND_REVERSE = "reverse";
    static final String KIND_FREE    = "free";
    static final String KIND_DEV     = "dev";
    private static final String PERSONA_KIND = "persona_kind";
    /** 词替换开关（"word_swap"）：把用户输入里的敏感词换成中性词后再发给服务端；界面显示原样。 */
    private static final String KEY_WORDSWAP = "word_swap";
    /** 三个内置人设：随包资产文件，改文件即生效，不联网。 */
    private static final String ASSET_REVERSE = "term/persona_reverse.txt";
    private static final String ASSET_FREE    = "term/persona_free.txt";
    private static final String ASSET_DEV     = "term/persona_dev.txt";

    private static volatile Context ctx;
    private static volatile ClassLoader cl;
    private static volatile Object vm;
    private static volatile Handler handler;
    private static volatile boolean announced;
    private static volatile boolean execEnabled;
    /** 全局暂停：打开后不再自动续写、不再自动执行命令。 */
    private static volatile boolean paused;
    /** 自定义人设（隐藏）：只在发送的网络请求里拼入，界面不可见。 */
    private static volatile String persona = "";
    /** 词替换开关：开启后「破解 / 去除」在发给服务端前自动换成「逆向」（界面仍显示原样）。 */
    private static volatile boolean wordSwap;

    private static final ConcurrentHashMap<String, Runnable> PENDING = new ConcurrentHashMap<String, Runnable>();
    private static final ConcurrentHashMap<String, Boolean>  INIT    = new ConcurrentHashMap<String, Boolean>();
    private static final ConcurrentHashMap<String, StringBuilder> TXT = new ConcurrentHashMap<String, StringBuilder>();
    private static final ConcurrentHashMap<String, Boolean>  CLOSED  = new ConcurrentHashMap<String, Boolean>();
    private static final ConcurrentHashMap<String, Boolean>  EXECED  = new ConcurrentHashMap<String, Boolean>();
    private static final ConcurrentHashMap<String, Boolean>  DONE_CMD = new ConcurrentHashMap<String, Boolean>();
    private static final ConcurrentHashMap<String, Integer>  ROUNDS  = new ConcurrentHashMap<String, Integer>();
    private static final ConcurrentHashMap<String, Runnable> WATCHDOG = new ConcurrentHashMap<String, Runnable>();
    /** 已达到上限并提示过的会话，避免反复弹提示。 */
    private static final ConcurrentHashMap<String, Boolean>  WARNED  = new ConcurrentHashMap<String, Boolean>();

    private Exp() {}

    // ---------- 注入点 1：App.attachBaseContext ----------

    public static void init(Context c) {
        try {
            ctx = c;
            if (cl == null) cl = c.getClassLoader();
            if (handler == null) {
                try { handler = new Handler(Looper.getMainLooper()); } catch (Throwable ignored) { }
            }
            SharedPreferences sp = c.getSharedPreferences("dspatch", 0);
            execEnabled = sp.getBoolean("exec", false);
            paused = sp.getBoolean("paused", false);
            wordSwap = sp.getBoolean(KEY_WORDSWAP, false);
            persona = readPersona(c);
            new Thread(new Runnable() {
                @Override public void run() {
                    Context cc = ctx;
                    if (cc != null) {
                        Skill.ensurePack(cc);          // 首次展开内置技能包
                        persona = readPersona(cc);     // 人设来自本地文件，不联网
                    }
                }
            }, "skill-pack").start();
            if (handler != null) {
                handler.postDelayed(new Runnable() {
                    @Override public void run() {
                        toast("DeepSeek 增强已注入（右下角 ⚙ 进入工具页）");
                    }
                }, 1200L);
            }
        } catch (Throwable t) {
            Log.e(TAG, "init 失败: " + t);
        }
    }

    /** 由内置终端 / 工具页里的开关调用。 */
    public static void setExecEnabled(boolean on) {
        execEnabled = on;
    }

    /** 全局暂停开关。 */
    public static void setPaused(boolean on) {
        paused = on;
    }

    public static boolean isPaused() { return paused; }

    // ---------- 词替换（把敏感词换成中性词，界面显示原样） ----------

    /** 是否开启「破解 / 去除 → 逆向」的词替换。 */
    public static boolean isWordSwap() { return wordSwap; }

    /** 开关词替换；写入偏好，立刻生效。 */
    public static void setWordSwap(Context c, boolean on) {
        wordSwap = on;
        if (c != null) {
            c.getSharedPreferences("dspatch", 0).edit().putBoolean(KEY_WORDSWAP, on).commit();
        }
    }

    /**
     * 词替换表：开启后把敏感词换成中性词。
     * 「破解」「去除」都替换成「逆向」——这两个词常触发服务端的安全拦截。
     * 只改真正发给服务端的那份文本，聊天界面仍显示用户原本输入的内容。
     */
    private static String swapWords(String s) {
        if (!wordSwap || s == null || s.length() == 0) return s;
        return s.replace("破解", "逆向").replace("去除", "逆向");
    }

    // ---------- 自定义人设（隐藏） ----------

    public static String getPersona() { return persona == null ? "" : persona; }

    public static void setPersona(String s) { persona = (s == null ? "" : s.trim()); }

    /** 当前内置人设选择：reverse（逆向）/ free（无限制）/ dev（开发）。 */
    static String kind(Context c) {
        String k = c.getSharedPreferences("dspatch", 0).getString(PERSONA_KIND, KIND_REVERSE);
        if (KIND_FREE.equals(k) || KIND_DEV.equals(k)) return k;
        return KIND_REVERSE;
    }

    /** 内置人设的中文名字（界面提示用）。 */
    static String kindName(String k) {
        if (KIND_FREE.equals(k)) return "无限制";
        if (KIND_DEV.equals(k))  return "开发";
        return "逆向";
    }

    private static String assetOf(String k) {
        if (KIND_FREE.equals(k)) return ASSET_FREE;
        if (KIND_DEV.equals(k))  return ASSET_DEV;
        return ASSET_REVERSE;
    }

    /** 读某个内置人设原文（关于页「无限制 / 逆向」预设按钮用）。 */
    static String builtinPersona(Context c, String k) {
        String t = readAssetText(c, assetOf(k));
        return t == null ? "" : t.trim();
    }

    /** 切到某个内置人设：记住选择、清掉自定义文件，立即生效。 */
    static void useBuiltin(Context c, String k) {
        c.getSharedPreferences("dspatch", 0).edit().putString(PERSONA_KIND, k).commit();
        try {
            File f = new File(c.getFilesDir(), PERSONA_FILE);
            if (f.exists()) f.delete();
        } catch (Throwable ignored) { }
        persona = readPersona(c);
    }

    /**
     * 人设来源（不联网，全部本地）：
     *   1) 应用私有目录 persona.txt —— 用户自定义的（优先）；
     *   2) 随包资产（按 persona_kind 选）—— 内置人设，改文件即改默认；
     *   3) 编译期兜底字符串。
     */
    static String readPersona(Context c) {
        try {
            File f = new File(c.getFilesDir(), PERSONA_FILE);
            if (f.exists()) {
                String s = fileRead(f);
                if (s != null && s.trim().length() > 0) return s.trim();
            }
        } catch (Throwable t) {
            Log.e(TAG, "读人设失败: " + t);
        }
        String asset = readAssetText(c, assetOf(kind(c)));
        if (asset != null && asset.trim().length() > 0) return asset.trim();
        return Remote.fallbackPersona();
    }

    /** 读随包资产里的文本（资产不存在返回 null）。 */
    private static String readAssetText(Context c, String name) {
        InputStream in = null;
        try {
            in = c.getAssets().open(name);
            return drain(in);
        } catch (Throwable t) {
            return null;
        } finally {
            close(in);
        }
    }

    /** 保存自定义人设（写文件 + 立即生效）；传空 = 删掉自定义，回到内置人设。 */
    public static void savePersona(Context c, String s) {
        String v = s == null ? "" : s.trim();
        try {
            File f = new File(c.getFilesDir(), PERSONA_FILE);
            if (v.length() == 0) {
                if (f.exists()) f.delete();
            } else {
                FileOutputStream os = new FileOutputStream(f);
                os.write(v.getBytes(UTF8));
                os.flush();
                os.close();
            }
        } catch (Throwable t) {
            Log.e(TAG, "保存人设失败: " + t);
        }
        persona = readPersona(c);   // 重读：空则回落到内置人设
    }

    /**
     * 由请求体序列化器调用：把「自定义人设 + 环境说明」拼到真正发给服务端的 prompt 前面。
     * 客户端聊天界面永远只显示用户输入的原样文本，看不到这里拼进去的内容。
     */
    public static String injectPrompt(String prompt) {
        try {
            if (prompt == null || prompt.length() == 0) return prompt;
            String head = hiddenHead();
            boolean already = false;
            if (head.length() != 0) {
                already = prompt.startsWith(head)
                        || (persona != null && persona.length() > 0 && prompt.startsWith(persona));
            }
            if (already) return prompt;          // 已注入过：原样返回，不再替换 / 重复拼接
            String p = swapWords(prompt);        // 词替换只作用在用户这份原文上
            return head.length() == 0 ? p : head + p;
        } catch (Throwable t) {
            return prompt;
        }
    }

    private static String hiddenHead() {
        StringBuilder sb = new StringBuilder();
        String p = persona;
        if (p != null && p.trim().length() > 0) sb.append(p.trim()).append("\n\n");
        if (execEnabled) {
            sb.append(TEACH);
            Context c = ctx;
            if (c != null) {
                String sk = Skill.index(c);
                if (sk.length() > 0) {
                    sb.append("【可用技能】需要时用 ```skill + 技能名 展开全文：\n").append(sk).append('\n');
                }
                String mc = Mcp.cachedIndex(c);
                if (mc.length() > 0) {
                    sb.append("【可用 MCP 工具】需要时用 ```mcp + 一行 JSON 调用：\n").append(mc).append('\n');
                }
            }
        }
        return sb.toString();
    }

    // ---------- 注入点 2：ao1.J ----------

    public static void captureVm(Object viewModel, Object intent) {
        try {
            if (viewModel != null) {
                vm = viewModel;
                if (cl == null) cl = viewModel.getClass().getClassLoader();
            }
        } catch (Throwable ignored) { }
    }

    // ---------- 注入点 3：k11.a ----------

    public static void onEvent(Object k11, Object gw8) {
        try {
            if (k11 == null || gw8 == null) return;
            String event = (String) get(gw8, "a");
            String data  = (String) get(gw8, "b");
            String msgId = String.valueOf(get(k11, "i"));
            String sid   = sessionIdOf(k11);

            if (!announced) {
                announced = true;
                log("已捕获到第一条 SSE 事件（注入点 A 生效）");
            }

            String base = sanitize(sid) + "_" + sanitize(msgId);

            if (event == null) onDelta(base, data);
            String ev = event == null ? null : event.toLowerCase(Locale.ROOT);
            boolean closed = ev != null && CLOSE_EVENTS.contains(ev);
            if (closed) {
                CLOSED.put(base, Boolean.TRUE);
                saveChat(base);                     // 一条回答只落盘一次（未开启保存则跳过）
            }

            if (ev == null || closed) scheduleCheck(base, k11);
        } catch (Throwable t) {
            log("SSE 处理异常: " + t);
        }
    }

    private static void onDelta(String base, String data) {
        if (data == null || data.length() == 0) return;
        try {
            JSONObject o = new JSONObject(data);
            Object v = o.opt("v");
            if (v instanceof JSONArray && "BATCH".equalsIgnoreCase(o.optString("o", ""))) {
                JSONArray arr = (JSONArray) v;
                for (int i = 0; i < arr.length(); i++) applyDelta(base, arr.optJSONObject(i));
                return;
            }
            applyDelta(base, o);
        } catch (Throwable ignored) { }
    }

    // 处理单条增量：带 p 的写指定路径；不带 p 的裸 {"v":"..."} 是同一片段的续写
    private static void applyDelta(String base, JSONObject o) {
        if (o == null || !o.has("v")) return;
        Object v = o.opt("v");
        String p = o.optString("p", null);
        if (v instanceof String) {
            String s = (String) v;
            if (s.length() == 0) return;
            boolean isContent = (p == null || p.length() == 0)
                    || p.toLowerCase(Locale.ROOT).indexOf("content") >= 0;
            if (isContent) {
                appendText(base, s);
            }
            return;
        }
        if (v instanceof JSONObject) {
            if (INIT.put(base, Boolean.TRUE) != null) return;   // 只取首次快照作为起始正文
            JSONObject resp = ((JSONObject) v).optJSONObject("response");
            if (resp == null) return;
            JSONArray frags = resp.optJSONArray("fragments");
            if (frags == null) return;
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < frags.length(); i++) {
                JSONObject fr = frags.optJSONObject(i);
                if (fr == null || !"RESPONSE".equals(fr.optString("type"))) continue;
                sb.append(fr.optString("content", ""));
            }
            if (sb.length() > 0) {
                TXT.put(base, new StringBuilder(sb));
            }
        }
    }

    // 累积本轮回答全文，供“AI 执行命令”扫描
    private static void appendText(String base, String s) {
        StringBuilder acc = TXT.get(base);
        if (acc == null) {
            acc = new StringBuilder();
            StringBuilder prev = TXT.putIfAbsent(base, acc);
            if (prev != null) acc = prev;
        }
        if (acc.length() < MAX_TEXT) acc.append(s);
    }

    private static String sessionIdOf(Object k11) {
        try {
            Object sc = get(k11, "k");
            Object sid = get(sc, "h");
            if (sid != null) return String.valueOf(sid);
        } catch (Throwable ignored) { }
        try {
            return String.valueOf(get(get(k11, "b"), "a"));
        } catch (Throwable ignored) { }
        return "unknown";
    }

    // ---------- 自动续写 ----------

    private static void scheduleCheck(final String key, final Object k11) {
        Runnable old = PENDING.get(key);
        if (old != null && handler != null) handler.removeCallbacks(old);

        // 自动续写已取消：这里只作为「AI 能力调用」的落点（技能 / MCP / 命令执行）
        Runnable task = new Runnable() {
            @Override public void run() {
                PENDING.remove(key);
                if (paused || !execEnabled) return;
                final Object k = k11;
                new Thread(new Runnable() {
                    @Override public void run() { handleReply(key, k); }
                }, "dspatch-exec").start();
            }
        };
        PENDING.put(key, task);
        if (handler != null) handler.postDelayed(task, IDLE_MS);
        else new Thread(task).start();

        // 看门狗：万一服务端始终不发结束事件（掉线 / 切后台漏事件），
        // 15 秒后只要已经攒到正文就按「本轮已结束」处理，避免命令永远不执行。
        if (handler != null) {
            Runnable oldWd = WATCHDOG.get(key);
            if (oldWd != null) handler.removeCallbacks(oldWd);
            Runnable wd = new Runnable() {
                @Override public void run() {
                    WATCHDOG.remove(key);
                    if (paused || !execEnabled) return;
                    if (CLOSED.containsKey(key)) return;
                    if (!TXT.containsKey(key)) return;
                    log("看门狗：15s 未收到流结束事件，按已结束处理并执行本轮命令");
                    CLOSED.put(key, Boolean.TRUE);
                    new Thread(new Runnable() {
                        @Override public void run() { handleReply(key, k11); }
                    }, "dspatch-exec").start();
                }
            };
            WATCHDOG.put(key, wd);
            handler.postDelayed(wd, 15000L);
        }
    }

    // ---------- AI 执行命令（闭环） ----------

    /**
     * 回答结束后统一处理三种「能力调用」：技能加载 / MCP 工具调用 / 沙箱命令执行。
     * 处理结果会当成新一轮用户消息发回给 AI（不再写执行记录、不再自动续写）。
     */
    private static boolean handleReply(String base, Object k11) {
        try {
            if (!execEnabled || paused) { log("跳过自动执行：命令执行开关关闭或已暂停"); return false; }
            if (!CLOSED.containsKey(base)) { log("跳过自动执行：本轮未收到结束信号（close/finish…）"); return false; }
            if (EXECED.put(base, Boolean.TRUE) != null) return false;   // 每条回答只处理一次
            StringBuilder sb = TXT.remove(base);
            if (sb == null) { log("跳过自动执行：未捕获到本轮回答正文"); return false; }
            String text = sb.toString();

            List<String> skills = extractBlocks(text, SKILL_LANGS);
            List<String> mcp    = extractBlocks(text, MCP_LANGS);
            List<String> cmds   = extractBlocks(text, SHELL_LANGS);
            if (skills.isEmpty() && mcp.isEmpty() && cmds.isEmpty()) return false;

            String sid = sessionIdOf(k11);
            int round = ROUNDS.containsKey(sid) ? ROUNDS.get(sid).intValue() : 0;
            if (round >= MAX_EXEC) {
                log("已达单会话自动执行上限 " + MAX_EXEC + "，本轮不再回传");
                if (WARNED.put(sid, Boolean.TRUE) == null)
                    toast("本会话自动回传已达上限 " + MAX_EXEC + " 轮；新开对话或继续发消息可恢复");
                return false;
            }
            ROUNDS.put(sid, Integer.valueOf(round + 1));

            StringBuilder fb = new StringBuilder("【App 执行结果】\n");
            int did = 0;

            // 1) 技能：把全文回传给 AI
            for (String name : skills) {
                Context c = ctx;
                String body = c == null ? null : Skill.load(c, name.trim());
                if (body == null) {
                    fb.append("【技能】没有这个技能：").append(name.trim()).append("\n\n");
                } else {
                    fb.append("【技能内容：").append(name.trim()).append("】\n").append(body).append("\n\n");
                }
                did++;
            }

            // 2) MCP 工具调用
            for (String raw : mcp) {
                JSONObject o = null;
                try { o = new JSONObject(raw.trim()); } catch (Throwable t) { }
                if (o == null) {
                    fb.append("【MCP】参数不是合法 JSON：").append(raw.trim()).append("\n\n");
                    did++; continue;
                }
                String sn = o.optString("server", "");
                String tn = o.optString("tool", "");
                Context c = ctx;
                Mcp.Server srv = c == null ? null : Mcp.find(c, sn);
                if (srv == null) {
                    fb.append("【MCP】没有启用的服务端：").append(sn).append("\n\n");
                    did++; continue;
                }
                String res;
                try {
                    res = Mcp.call(c, srv, tn, o.optJSONObject("args"));
                } catch (Throwable t) {
                    res = "调用异常: " + t;
                }
                fb.append("【MCP 结果】").append(sn).append(" / ").append(tn).append('\n')
                  .append("```\n").append(res).append("\n```\n\n");
                did++;
            }

            // 3) 沙箱里执行命令
            for (String cmd : cmds) {
                String c0 = cmd.trim();
                if (c0.length() == 0) continue;
                String ck = base + "#" + c0;
                if (DONE_CMD.put(ck, Boolean.TRUE) != null) continue;   // 同一条命令不重复跑
                String out = runShell(c0);
                fb.append("【本地命令执行结果】\n```\n").append(out).append("\n```\n\n");
                did++;
            }

            if (did == 0) return false;

            String res = sendMessage(fb.append(NUDGE).toString());
            log("已回传 " + did + " 项执行结果，结果=" + res);
            return res.startsWith("ok");
        } catch (Throwable t) {
            log("处理回答异常: " + t);
            return false;
        }
    }

    /**
     * 从回答全文里抽取指定语言的围栏代码块；@run 开头的整行按 shell 处理。
     * 围栏行只认语言名（```mcp / ```skill / ```bash），代码块内容才是参数。
     */
    private static List<String> extractBlocks(String text, Set<String> langs) {
        List<String> out = new ArrayList<String>();
        if (text == null || text.length() == 0) return out;
        String[] lines = text.split("\n");
        StringBuilder cur = null;
        boolean shellLang = (langs == SHELL_LANGS);
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i];
            String t = line.trim();
            if (cur == null) {
                if (t.startsWith("```")) {
                    String lang = t.substring(3).trim().toLowerCase(Locale.ROOT);
                    int sp = lang.indexOf(' ');
                    if (sp > 0) lang = lang.substring(0, sp);
                    if (langs.contains(lang)) cur = new StringBuilder();
                } else if (shellLang && (t.startsWith("@run ") || t.startsWith("@sh "))) {
                    out.add(t.substring(5));
                }
            } else {
                if (t.startsWith("```")) {
                    if (cur.length() > 0) out.add(cur.toString());
                    cur = null;
                } else {
                    cur.append(line).append('\n');
                }
            }
        }
        return out;
    }

    /**
     * 以程序方式发出一条用户消息：走 cn1(text, 0) -> ao1.J(...)，与真人点发送同一条路径。
     * 结果会作为一条普通用户消息出现在聊天里（不再做「静默发送」）。
     */
    static String sendMessage(String text) {
        return send(text);
    }

    private static String send(final String text) {
        final Object vmLocal = vm;
        if (vmLocal == null) return "失败：未捕获 ViewModel（先打开一次聊天页）";
        if (handler == null) return "失败：主线程 Handler 不可用";
        final Object[] res = new Object[1];
        final CountDownLatch latch = new CountDownLatch(1);
        handler.post(new Runnable() {
            @Override public void run() {
                try {
                    ClassLoader L = cl != null ? cl : vmLocal.getClass().getClassLoader();
                    Class<?> cn1 = Class.forName(C_CN1, false, L);
                    Class<?> jn1 = Class.forName(C_JN1, false, L);
                    Object intent = cn1.getConstructor(String.class, int.class)
                            .newInstance(text, Integer.valueOf(0));
                    vmLocal.getClass().getMethod("J", jn1).invoke(vmLocal, intent);
                    res[0] = "ok";
                } catch (Throwable t) {
                    res[0] = "失败: " + t;
                } finally {
                    latch.countDown();
                }
            }
        });
        try { latch.await(5, TimeUnit.SECONDS); } catch (Throwable ignored) { }
        return res[0] == null ? "失败：发送超时" : String.valueOf(res[0]);
    }

    // ---------- 反射工具 ----------

    private static Object get(Object o, String name) throws Exception {
        if (o == null) return null;
        Field f = o.getClass().getField(name);
        return f.get(o);
    }

    private static Object call(Object o, String name) throws Exception {
        if (o == null) return null;
        Method m = o.getClass().getMethod(name);
        return m.invoke(o);
    }

    // ---------- shell ----------

    private static String runShell(String cmd) {
        Context c = ctx;
        String reason = null;
        if (c != null) {
            try {
                // 容器还没装好（用户没点过终端）时，这里自动装一次再执行，
                // 否则会掉进下面的 app 沙箱 sh（uid=11700，非 root、无工具链）。
                if (!TermEnv.ready(c)) {
                    log("容器未就绪，首次自动安装 Alpine 环境…");
                    TermEnv.ensure(c, null);
                }
                if (TermEnv.ready(c)) {
                    String out = TermEnv.execOnce(c, cmd);
                    return "$ " + cmd + "\n[环境] Alpine 容器 · PRoot 沙箱 · 容器内 uid=0\n" + out;
                }
                reason = "容器未就绪：" + TermEnv.diagnose(c);
            } catch (Throwable t) {
                reason = "容器执行异常: " + t;
            }
        } else {
            reason = "未捕获到 App Context";
        }
        log("容器不可用，回退系统 sh：" + reason);
        Process p = null;
        try {
            p = Runtime.getRuntime().exec(new String[]{"sh", "-c", cmd});
            String out = drain(p.getInputStream());
            String err = drain(p.getErrorStream());
            int code = p.waitFor();
            return "$ " + cmd + "\n[环境] 系统 sh（非容器，非 root：" + reason + "）\nexit=" + code + "\n"
                    + out + (err.length() > 0 ? "\n[stderr]\n" + err : "");
        } catch (Throwable t) {
            return "执行失败: " + t;
        } finally {
            if (p != null) try { p.destroy(); } catch (Throwable ignored) { }
        }
    }

    private static String drain(InputStream in) {
        if (in == null) return "";
        StringBuilder sb = new StringBuilder();
        try {
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) sb.append(new String(buf, 0, n, UTF8));
        } catch (Throwable ignored) { }
        return sb.toString();
    }

    // ---------- 存储 ----------
    // 以前是每个 SSE 片段都往「下载目录」写一次（每个 token 一次 MediaStore 查询 + 写入），
    // 这是「一生成消息就卡」的主因。现在只在回答结束（close）时按需写一次，
    // 并且默认不保存；要保存得先在「关于 / 工具」页里选一个工作区。

    /** 一条回答的正文落盘；只在开启保存且用户选过工作区时执行，每次回答只写一次。 */
    private static void saveChat(String base) {
        try {
            if (!saveEnabled()) return;
            Context c = ctx;
            if (c == null) return;
            StringBuilder sb = TXT.get(base);
            if (sb == null || sb.length() == 0) return;
            Workspace.save(c, base + ".md", sb.toString());
        } catch (Throwable t) {
            Log.w(TAG, "保存对话失败: " + t);
        }
    }

    /** 是否保存对话记录（默认关）。 */
    static boolean saveEnabled() {
        Context c = ctx;
        if (c == null) return false;
        return c.getSharedPreferences("dspatch", 0).getBoolean("save_chat", false);
    }

    private static String fileRead(File f) {
        if (!f.exists()) return null;
        FileInputStream in = null;
        try {
            in = new FileInputStream(f);
            return drain(in);
        } catch (Throwable t) {
            return null;
        } finally {
            close(in);
        }
    }

    // ---------- 悬浮入口：挂在 DeepSeek 主界面上的「关于 / 工具」按钮 ----------

    private static final String ENTRY_TAG = "dspatch-entry";
    private static final String PAUSE_TAG = "dspatch-pause";

    /** 在 DeepSeek 主界面挂一个可拖动的圆点，点开「关于 / 工具」页。 */
    public static void attachEntry(final Activity act) {
        try {
            if (act == null) return;
            View content = act.findViewById(android.R.id.content);
            final ViewGroup host = (content instanceof ViewGroup) ? (ViewGroup) content
                    : (ViewGroup) act.getWindow().getDecorView();
            if (host == null) return;
            if (host.findViewWithTag(ENTRY_TAG) != null) return;

            final SharedPreferences sp = act.getSharedPreferences("dspatch", 0);
            final float d = act.getResources().getDisplayMetrics().density;

            // ① 工具入口 ⚙
            addDot(act, host, sp, ENTRY_TAG, "⚙", 0xFF1F6FEB,
                    "entry_x", "entry_y", 0, d, new Runnable() {
                        @Override public void run() {
                            try {
                                act.startActivity(new Intent(act, AboutActivity.class));
                            } catch (Throwable t) {
                                Log.e(TAG, "打开关于页失败: " + t);
                            }
                        }
                    });

            // ② 全局暂停按钮：运行中显示 ⏸（绿），暂停中显示 ▶（橙）
            addDot(act, host, sp, PAUSE_TAG, pauseIcon(), pauseColor(),
                    "pause_x", "pause_y", 1, d, new Runnable() {
                        @Override public void run() {
                            boolean on = !paused;
                            sp.edit().putBoolean("paused", on).commit();
                            setPaused(on);
                            View v = host.findViewWithTag(PAUSE_TAG);
                            if (v instanceof TextView) {
                                ((TextView) v).setText(pauseIcon());
                                ((TextView) v).setBackgroundDrawable(oval(pauseColor()));
                            }
                            toast(on ? "已全局暂停：停止自动续写 / 停止自动执行" : "已恢复运行");
                        }
                    });

            // ③ 首条不同的服务器公告，弹窗提示一次
            showNoticeOnce(act, sp);
        } catch (Throwable t) {
            Log.e(TAG, "attachEntry 失败: " + t);
        }
    }

    /** 拉到服务器公告后，如果和上次看过的不一样，就在主界面弹一次。 */
    private static void showNoticeOnce(final Activity act, final SharedPreferences sp) {
        final Context c = act.getApplicationContext();
        new Thread(new Runnable() {
            @Override public void run() {
                Remote.refresh(c);
                final String n = Remote.notice(c);
                if (n == null || n.length() == 0) return;
                if (n.equals(sp.getString("notice_seen", ""))) return;
                sp.edit().putString("notice_seen", n).commit();
                if (handler == null) return;
                handler.post(new Runnable() {
                    @Override public void run() {
                        try {
                            new android.app.AlertDialog.Builder(act)
                                    .setTitle("公告")
                                    .setMessage(n)
                                    .setPositiveButton("知道了", null)
                                    .show();
                        } catch (Throwable t) {
                            Log.e(TAG, "公告弹窗失败: " + t);
                        }
                    }
                });
            }
        }, "ds-notice").start();
    }

    private static String pauseIcon() { return paused ? "▶" : "⏸"; }

    private static int pauseColor() { return paused ? 0xFFD97706 : 0xFF16A34A; }

    private static GradientDrawable oval(int color) {
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(color);
        return bg;
    }

    /**
     * 加一个可拖动圆点：短按触发 onClick，拖动后记录位置（分别存 xKey/yKey）。
     * index=0 放默认位，index&gt;0 依次往下排。
     */
    private static void addDot(final Activity act, final ViewGroup host, final SharedPreferences sp,
                               final String tag, String text, int color,
                               final String xKey, final String yKey, final int index, final float d,
                               final Runnable onClick) {
        final int size = (int) (46 * d);

        final TextView b = new TextView(act);
        b.setTag(tag);
        b.setText(text);
        b.setTextSize(20);
        b.setTextColor(0xFFFFFFFF);
        b.setGravity(Gravity.CENTER);
        b.setAlpha(0.60f);
        b.setBackgroundDrawable(oval(color));

        final FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(size, size);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.leftMargin = -1000;   // 等布局完成后再摆到右侧
        lp.topMargin = 0;
        b.setLayoutParams(lp);

        final int sx = sp.getInt(xKey, -1);
        final int sy = sp.getInt(yKey, -1);

        b.post(new Runnable() {
            @Override public void run() {
                int w = host.getWidth(), h = host.getHeight();
                if (sx >= 0 && sy >= 0) {
                    lp.leftMargin = sx;
                    lp.topMargin = sy;
                } else {
                    lp.leftMargin = w > size ? w - size - (int) (10 * d) : 0;
                    lp.topMargin = (int) (h * 0.62f) + index * (size + (int) (10 * d));
                }
                b.setLayoutParams(lp);
            }
        });

        b.setOnTouchListener(new View.OnTouchListener() {
            private float downX, downY;
            private int startX, startY;
            private boolean moved;

            @Override public boolean onTouch(View v, MotionEvent e) {
                int a = e.getAction();
                if (a == MotionEvent.ACTION_DOWN) {
                    downX = e.getRawX();
                    downY = e.getRawY();
                    startX = lp.leftMargin;
                    startY = lp.topMargin;
                    moved = false;
                    b.setAlpha(0.95f);
                    return true;
                }
                if (a == MotionEvent.ACTION_MOVE) {
                    float dx = e.getRawX() - downX, dy = e.getRawY() - downY;
                    if (!moved && (Math.abs(dx) > 10 * d || Math.abs(dy) > 10 * d)) moved = true;
                    int nx = startX + (int) dx, ny = startY + (int) dy;
                    int maxX = host.getWidth() - size, maxY = host.getHeight() - size;
                    if (nx < 0) nx = 0;
                    if (ny < 0) ny = 0;
                    if (nx > maxX) nx = maxX;
                    if (ny > maxY) ny = maxY;
                    lp.leftMargin = nx;
                    lp.topMargin = ny;
                    b.requestLayout();
                    return true;
                }
                if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                    b.setAlpha(0.60f);
                    if (moved) {
                        sp.edit().putInt(xKey, lp.leftMargin)
                                 .putInt(yKey, lp.topMargin).commit();
                    } else if (onClick != null) {
                        try { onClick.run(); } catch (Throwable t) {
                            Log.e(TAG, "圆点点击失败: " + t);
                        }
                    }
                    return true;
                }
                return false;
            }
        });

        host.addView(b);
    }

    public static boolean isVmCaptured() { return vm != null; }

    public static boolean isExecEnabled() { return execEnabled; }

    // ---------- 小工具 ----------

    /** 屏幕提示（不落盘）。可从任意线程调用。 */
    static void toast(final String msg) {
        final Context c = ctx;
        if (c == null) return;
        Runnable r = new Runnable() {
            @Override public void run() {
                try { Toast.makeText(c, msg, Toast.LENGTH_LONG).show(); }
                catch (Throwable t) { Log.e(TAG, "弹提示失败: " + t); }
            }
        };
        if (handler != null) handler.post(r); else r.run();
    }

    static void log(String msg) {
        Log.i(TAG, msg);
    }

    private static String sanitize(String s) {
        if (s == null) return "null";
        StringBuilder sb = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            boolean ok = (ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z')
                    || (ch >= '0' && ch <= '9') || ch == '_' || ch == '-' || ch == '.';
            sb.append(ok ? ch : '_');
        }
        return sb.length() == 0 ? "x" : sb.toString();
    }

    private static String jsonString(String s) {
        if (s == null) return "null";
        StringBuilder sb = new StringBuilder(s.length() + 2);
        sb.append('"');
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            switch (ch) {
                case '"':  sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\n': sb.append("\\n");  break;
                case '\r': sb.append("\\r");  break;
                case '\t': sb.append("\\t");  break;
                default:
                    if (ch < 0x20) sb.append(String.format(Locale.ROOT, "\\u%04x", (int) ch));
                    else sb.append(ch);
            }
        }
        sb.append('"');
        return sb.toString();
    }

    private static void close(Object c) {
        try {
            if (c instanceof OutputStream) ((OutputStream) c).close();
            else if (c instanceof InputStream) ((InputStream) c).close();
        } catch (Throwable ignored) { }
    }
}
