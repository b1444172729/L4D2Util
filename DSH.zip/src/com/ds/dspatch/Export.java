package com.ds.dspatch;

import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.Settings;
import android.util.Log;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * 导出：把容器里产出的东西（APK / 反编译目录 / 网页 / 工程）搬到用户看得见的文件夹。
 *
 * 为什么需要它：容器能写的地方只有两类 ——
 *   1) App 私有目录（files/term/...）：不需要权限，但 Android 11+ 的文件管理器很难进去；
 *   2) 宿主授权目录（/sdcard/Android/data/com.dsmod.deepseek/files）：也要用文件管理器钻进去。
 * 都不是"导出一个文件夹"的正常姿势，所以这里提供三条出路，按可行性自动选：
 *   A. 已授予「所有文件访问」(或 ≤API29 的写存储权限) -> 容器可直接写 /sdcard/Download；
 *      同时 App 也能用普通 File 拷贝把导出区搬过去。
 *   B. 用户在「工作区」挑了文件夹 -> 走 SAF 递归写入（不需要任何权限，任何 Android 版本都行）。
 *   C. 都没有 -> 提示用户去挑工作区 / 授权。
 *
 * 容器侧约定：AI 把要交付的东西放进 /root/export/，App 一键搬出去。
 */
public final class Export {

    private static final String TAG = "DSExport";
    /** 容器内的导出区（相对 rootfs） */
    private static final String STAGE = "root/export";
    /** 公共目录里建的产物文件夹名 */
    public static final String PUB_FOLDER = "DeepSeekExport";

    private Export() { }

    public static final class Result {
        public int files;
        public String where = "";
        public String err = "";
        public boolean ok() { return err.length() == 0; }
    }

    /** 容器内的导出区（App 侧路径）。 */
    public static File stage(Context c) {
        File d = new File(TermEnv.rootfs(c), STAGE);
        if (!d.exists()) d.mkdirs();
        return d;
    }

    // ---------- 权限 ----------

    /** 能否直接写公共目录（/sdcard/Download 之类）。 */
    public static boolean publicOk(Context c) {
        if (c == null) return false;
        try {
            if (Build.VERSION.SDK_INT >= 30) return Environment.isExternalStorageManager();
            return c.checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE")
                    == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) {
            return false;
        }
    }

    /** 跳系统设置页开「所有文件访问」（API 30+）。 */
    public static Intent manageIntent(Context c) {
        Intent i = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
        i.setData(Uri.parse("package:" + c.getPackageName()));
        return i;
    }

    /**
     * 容器里可以直接写的目标目录，注入成环境变量 DS_EXPORT 给脚本用；拿不到返回 null。
     */
    public static String containerTarget(Context c) {
        String ws = Workspace.realPath(c);
        if (ws != null) return ws;
        if (publicOk(c)) return "/sdcard/Download";
        return null;
    }

    public static File publicDir() {
        File sd = Environment.getExternalStorageDirectory();
        return sd == null ? null : new File(sd, "Download");
    }

    /** 当前导出能力的人话描述（给「关于/工具」页显示）。 */
    public static String describe(Context c) {
        StringBuilder sb = new StringBuilder();
        sb.append("所有文件访问：").append(Build.VERSION.SDK_INT >= 30
                ? (publicOk(c) ? "已授予（容器可直写 /sdcard/Download）" : "未授予")
                : (publicOk(c) ? "已授予写存储" : "未授予"));
        String ws = Workspace.realPath(c);
        if (ws != null) sb.append('\n').append("工作区真实路径：").append(ws);
        else if (Workspace.has(c)) sb.append('\n').append("工作区：选了但拿不到真实路径（容器写不进，导出仍可走 SAF）");
        String tgt = containerTarget(c);
        sb.append('\n').append("容器默认导出目录：").append(tgt == null ? "无（先授权或选工作区）" : tgt);
        File st = stage(c);
        File[] fs = st.listFiles();
        sb.append('\n').append("待导出区 /root/export/：").append(fs == null ? 0 : fs.length).append(" 项");
        return sb.toString();
    }

    // ---------- 一键导出 ----------

    /** 把 /root/export/ 整个搬到用户看得见的地方。 */
    public static Result run(Context c, String name) {
        Result r = new Result();
        File stage = stage(c);
        File[] fs = stage.listFiles();
        if (fs == null || fs.length == 0) {
            r.err = "待导出区是空的：让 AI 把产物放进容器里的 /root/export/ 再点这里";
            return r;
        }
        if (name == null || name.length() == 0) name = PUB_FOLDER;
        int total = count(stage);

        // A. 公共目录（有权限时最快，直接 File 拷贝）
        if (publicOk(c)) {
            File sd = publicDir();
            if (sd != null) {
                File dst = new File(sd, name);
                try {
                    copyTree(stage, dst);
                    r.files = total;
                    r.where = dst.getAbsolutePath();
                    return r;
                } catch (Throwable t) {
                    Log.w(TAG, "写公共目录失败: " + t);
                }
            }
        }

        // B. 工作区（SAF，不需要任何权限）
        Uri tree = Workspace.treeUri(c);
        if (tree != null) {
            try {
                int n = writeToTree(c, stage, tree);
                if (n > 0) {
                    r.files = n;
                    r.where = "工作区：" + Workspace.name(c);
                    return r;
                }
                r.err = "写入工作区失败（该目录可能不支持新建子文件夹）";
            } catch (Throwable t) {
                r.err = "写入工作区失败: " + t;
            }
            return r;
        }

        r.err = "没有可写目标：点「选择工作区」挑一个文件夹，或授予「所有文件访问」后再试";
        return r;
    }

    // ---------- 实现 ----------

    private static int count(File f) {
        if (!f.isDirectory()) return 1;
        int n = 0;
        File[] fs = f.listFiles();
        if (fs != null) for (File x : fs) n += count(x);
        return n;
    }

    private static void copyTree(File src, File dst) throws Exception {
        if (src.isDirectory()) {
            if (!dst.isDirectory() && !dst.mkdirs()) throw new Exception("建目录失败: " + dst);
            File[] fs = src.listFiles();
            if (fs != null) for (File f : fs) copyTree(f, new File(dst, f.getName()));
            return;
        }
        File p = dst.getParentFile();
        if (p != null && !p.isDirectory()) p.mkdirs();
        InputStream in = new FileInputStream(src);
        OutputStream os = new FileOutputStream(dst);
        try {
            byte[] b = new byte[1 << 15];
            int r;
            while ((r = in.read(b)) > 0) os.write(b, 0, r);
            os.flush();
        } finally {
            try { in.close(); } catch (Throwable ignored) { }
            try { os.close(); } catch (Throwable ignored) { }
        }
    }

    private static int writeToTree(Context c, File src, Uri tree) throws Exception {
        ContentResolver cr = c.getContentResolver();
        String rootId = DocumentsContract.getTreeDocumentId(tree);
        return copyInto(cr, src, tree, rootId);
    }

    private static int copyInto(ContentResolver cr, File dir, Uri tree, String parentId) throws Exception {
        File[] fs = dir.listFiles();
        if (fs == null) return 0;
        int n = 0;
        for (File f : fs) {
            if (f.isDirectory()) {
                Uri sub = ensure(cr, tree, parentId, f.getName(), true);
                if (sub != null) {
                    n += copyInto(cr, f, tree, DocumentsContract.getDocumentId(sub));
                }
                continue;
            }
            Uri doc = ensure(cr, tree, parentId, f.getName(), false);
            if (doc == null) continue;
            OutputStream os = cr.openOutputStream(doc, "wt");
            if (os == null) continue;
            InputStream in = new FileInputStream(f);
            try {
                byte[] b = new byte[1 << 15];
                int r;
                while ((r = in.read(b)) > 0) os.write(b, 0, r);
                os.flush();
            } finally {
                try { in.close(); } catch (Throwable ignored) { }
                try { os.close(); } catch (Throwable ignored) { }
            }
            n++;
        }
        return n;
    }

    /** 找同名子项；没有就新建。 */
    private static Uri ensure(ContentResolver cr, Uri tree, String parentId, String name, boolean dir) {
        Uri found = findChild(cr, tree, parentId, name);
        if (found != null) return found;
        Uri parent = DocumentsContract.buildDocumentUriUsingTree(tree, parentId);
        try {
            return DocumentsContract.createDocument(cr, parent,
                    dir ? DocumentsContract.Document.MIME_TYPE_DIR : mime(name), name);
        } catch (Throwable t) {
            Log.w(TAG, "新建 " + name + " 失败: " + t);
            return null;
        }
    }

    private static Uri findChild(ContentResolver cr, Uri tree, String parentId, String name) {
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentId);
        Cursor cur = null;
        try {
            cur = cr.query(children, new String[]{
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME}, null, null, null);
            if (cur == null) return null;
            while (cur.moveToNext()) {
                if (name.equals(cur.getString(1))) {
                    return DocumentsContract.buildDocumentUriUsingTree(tree, cur.getString(0));
                }
            }
        } catch (Throwable t) {
            Log.w(TAG, "查询子项失败: " + t);
        } finally {
            try { if (cur != null) cur.close(); } catch (Throwable ignored) { }
        }
        return null;
    }

    private static String mime(String n) {
        String l = n.toLowerCase(java.util.Locale.ROOT);
        if (l.endsWith(".apk")) return "application/vnd.android.package-archive";
        if (l.endsWith(".json")) return "application/json";
        if (l.endsWith(".xml")) return "text/xml";
        if (l.endsWith(".html") || l.endsWith(".htm")) return "text/html";
        if (l.endsWith(".css")) return "text/css";
        if (l.endsWith(".png")) return "image/png";
        if (l.endsWith(".jpg") || l.endsWith(".jpeg")) return "image/jpeg";
        if (l.endsWith(".zip") || l.endsWith(".jar")) return "application/zip";
        return "text/plain";
    }
}
