package com.ds.dspatch;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;

/**
 * 远程公告。
 *
 * 公告放在「吾记」的一条分享日记里，App 启动时拉取一次并缓存到应用私有目录。
 * 服务端返回的正文（Result.content）按行分节：
 *
 *     公告:xxxx
 *
 * 人设不再走网络：见 assets/term/persona_reverse.txt 与 persona_free.txt（可直接改文件）。
 * 拉取失败 / 首次离线启动时，退回编译期内置的默认公告。
 */
public final class Remote {

    private static final String TAG = "DSRemote";
    private static final Charset UTF8 = Charset.forName("UTF-8");

    /** 吾记分享接口：POST {"keyValue":"<diaryId>"}，Result 是一段 JSON 字符串。 */
    private static final String API = "https://miniprogramapi.wujiapp.com/api/Diarys/v3PostGetShare";
    private static final String KEY =
            "Oylp0aPisqvkSBHt+FiTesITpno00iTfkiUEWxq2Ykjm6RWLu6DXbwur5gErxUzEobbargdiUMmlLjnBixksIQ==";

    private static final String F_NOTICE  = "notice.txt";

    private static final String DEFAULT_NOTICE = "你们好啊";

    /**
     * 编译期兜底人设：原文保留，尾部压缩成省略号。
     * 真正生效的内置人设是 assets/term/persona_reverse.txt / persona_free.txt —— 想改直接改文件。
     */
    private static final String FALLBACK_PERSONA =
            "你是一名资深 Android 逆向工程师，长期做 APK 拆包、smali 改写、协议还原和风控对抗。\n"
          + "遵循这几条工作方式：\n\n"
          + "1. 先证据、后结论。任何判断都要有出处：dex / smali / 网络包 / 运行时日志，缺证据就说不确定，绝不编造类名、字段名或结论。\n"
          + "2. 讲步骤不空谈。给可直接执行的操作序列（命令行 + 预期输出），而不是泛泛的原则。\n"
          + "……";

    private static volatile String sNotice;
    private static volatile long lastFetch;

    private Remote() {}

    // ---------- 对外 ----------

    /** 当前公告（缓存 / 内置默认）。 */
    public static String notice(Context c) {
        String v = sNotice;
        if (v == null || v.length() == 0) v = readCache(c, F_NOTICE);
        if (v == null || v.length() == 0) v = DEFAULT_NOTICE;
        sNotice = v;
        return v;
    }

    /** 编译期兜底人设（资产的 persona.txt 缺失时才用）。 */
    public static String fallbackPersona() { return FALLBACK_PERSONA; }

    /** 公告是否已从服务器拿到过（有本地缓存）。 */
    public static boolean fromServer(Context c) {
        try {
            return c != null && new File(c.getFilesDir(), F_NOTICE).exists();
        } catch (Throwable t) {
            return false;
        }
    }

    /** 后台拉取（2 分钟节流），失败静默。 */
    public static void refresh(Context c) {
        if (c == null) return;
        final Context cc = c.getApplicationContext();
        new Thread(new Runnable() {
            @Override public void run() { fetchOnce(cc, false); }
        }, "ds-remote").start();
    }

    /** 强制拉取，完成后在主线程回调（供「关于 / 工具」页的刷新按钮用）。 */
    public static void forceRefresh(Context c, final Runnable done) {
        if (c == null) return;
        final Context cc = c.getApplicationContext();
        new Thread(new Runnable() {
            @Override public void run() {
                fetchOnce(cc, true);
                if (done != null) {
                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override public void run() { done.run(); }
                    });
                }
            }
        }, "ds-remote-force").start();
    }

    // ---------- 拉取 ----------

    private static boolean fetchOnce(Context c, boolean force) {
        long now = System.currentTimeMillis();
        if (!force && now - lastFetch < 120000L) return false;
        lastFetch = now;
        try {
            JSONObject body = new JSONObject();
            body.put("keyValue", KEY);

            JSONObject o = new JSONObject(httpPost(body.toString()));
            if (o.optInt("Status", -1) != 1) {
                Log.w(TAG, "接口返回异常: " + o.optString("Message", ""));
                return false;
            }
            JSONObject r = new JSONObject(o.optString("Result", ""));
            String content = r.optString("content", "");
            if (content.length() == 0) return false;

            split(content);
            if (sNotice != null && sNotice.length() > 0) writeCache(c, F_NOTICE, sNotice);
            Log.i(TAG, "公告已更新：" + (sNotice == null ? 0 : sNotice.length()) + " 字");
            return true;
        } catch (Throwable t) {
            Log.w(TAG, "拉取远程配置失败: " + t);
            return false;
        }
    }

    private static String httpPost(String body) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(API).openConnection();
        try {
            conn.setRequestMethod("POST");
            conn.setConnectTimeout(12000);
            conn.setReadTimeout(15000);
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            conn.setRequestProperty("User-Agent", "Mozilla/5.0");
            OutputStream os = conn.getOutputStream();
            os.write(body.getBytes(UTF8));
            os.flush();
            os.close();

            int code = conn.getResponseCode();
            InputStream in = (code >= 400) ? conn.getErrorStream() : conn.getInputStream();
            if (in == null) return "";
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            in.close();
            return new String(bo.toByteArray(), UTF8);
        } finally {
            try { conn.disconnect(); } catch (Throwable ignored) { }
        }
    }

    /** 按行拆出「公告:」一节；带「人设:」的旧格式直接忽略人设部分。 */
    private static void split(String content) {
        String norm = content.replace("\r\n", "\n").replace('\r', '\n');
        String[] lines = norm.split("\n", -1);
        StringBuilder nt = new StringBuilder();
        boolean inPersona = false;
        for (String line : lines) {
            String t = line.trim();
            if (t.startsWith("公告:") || t.startsWith("公告：")) {
                inPersona = false;
                nt.append(t.substring(3).trim());
            } else if (t.startsWith("人设:") || t.startsWith("人设：")) {
                inPersona = true;
            } else if (inPersona) {
                // 旧格式里的人设正文：跳过
            }
        }
        String n = nt.toString().trim();
        if (n.length() > 0) sNotice = n;
    }

    // ---------- 缓存文件 ----------

    private static String readCache(Context c, String name) {
        try {
            File f = new File(c.getFilesDir(), name);
            if (!f.exists()) return null;
            FileInputStream in = new FileInputStream(f);
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            in.close();
            return new String(bo.toByteArray(), UTF8);
        } catch (Throwable t) {
            return null;
        }
    }

    private static void writeCache(Context c, String name, String v) {
        try {
            FileOutputStream os = new FileOutputStream(new File(c.getFilesDir(), name));
            os.write(v.getBytes(UTF8));
            os.flush();
            os.close();
        } catch (Throwable t) {
            Log.e(TAG, "写缓存失败 " + name + ": " + t);
        }
    }
}
