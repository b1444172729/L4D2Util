package com.ds.dspatch;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * 统一的界面外观工具：所有颜色 / 背景都由代码显式指定，
 * 不再依赖系统主题，避免在深色 / 浅色主题下出现「黑底黑字看不见」。
 */
public final class Ui {

    // 调色板
    public static final int BG        = 0xFF0D1117;   // 页面底色
    public static final int CARD      = 0xFF161D27;   // 卡片
    public static final int INPUT     = 0xFF0A0E14;   // 输入框底
    public static final int STROKE    = 0xFF2A3546;   // 描边
    public static final int TEXT      = 0xFFE8EEF5;   // 主文字
    public static final int SUB       = 0xFF9AAABD;   // 次要文字
    public static final int FAINT     = 0xFF6B7A8C;   // 提示 / 占位
    public static final int ACCENT    = 0xFF4C8DF6;   // 主色
    public static final int ACCENT_D  = 0xFF3A73CE;   // 主色按下
    public static final int ON_ACCENT = 0xFFFFFFFF;
    public static final int GREEN     = 0xFF3FCE8B;
    public static final int RED       = 0xFFF87171;
    public static final int RED_D     = 0xFFB91C1C;

    // Material Design 3（深色）配色
    public static final int M3_PRIMARY         = 0xFFD0BCFF;
    public static final int M3_PRIMARY_CONT    = 0xFF4F378B;   // primary container
    public static final int M3_ON_PRIMARY_CONT = 0xFFEADDFF;
    public static final int M3_SEC_CONT        = 0xFF4A4458;   // secondary container
    public static final int M3_SEC_CONT_D      = 0xFF5C566B;
    public static final int M3_ON_SEC_CONT     = 0xFFE8DEF8;
    public static final int M3_SURFACE_CONT    = 0xFF211F26;   // surface container
    public static final int M3_ON_SURFACE      = 0xFFE6E0E9;
    public static final int M3_ON_SURFACE_VAR  = 0xFFCAC4D0;   // on surface variant

    private Ui() { }

    public static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    // ---------- 布局参数 ----------
    public static LinearLayout.LayoutParams fill() {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    public static LinearLayout.LayoutParams fillTop(Context c, float topDp) {
        LinearLayout.LayoutParams p = fill();
        p.topMargin = dp(c, topDp);
        return p;
    }

    public static LinearLayout.LayoutParams weight() {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
    }

    // ---------- 背景 ----------
    public static GradientDrawable rounded(Context c, int fillColor, float radiusDp, int strokeColor) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.RECTANGLE);
        g.setColor(fillColor);
        g.setCornerRadius(dp(c, radiusDp));
        if (strokeColor != 0) g.setStroke(Math.max(1, dp(c, 1)), strokeColor);
        return g;
    }

    private static StateListDrawable stateful(Context c, int fill, int fillPressed,
                                              float radiusDp, int stroke, int strokePressed) {
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_pressed},
                rounded(c, fillPressed, radiusDp, strokePressed));
        s.addState(new int[]{android.R.attr.state_focused},
                rounded(c, fill, radiusDp, strokePressed));
        s.addState(new int[]{}, rounded(c, fill, radiusDp, stroke));
        return s;
    }

    // ---------- 容器 ----------
    public static LinearLayout screen(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackgroundColor(BG);
        int p = dp(c, 14);
        l.setPadding(p, dp(c, 10), p, dp(c, 22));
        return l;
    }

    public static LinearLayout column(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    public static LinearLayout row(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(android.view.Gravity.CENTER_VERTICAL);
        return l;
    }

    public static LinearLayout card(Context c) {
        LinearLayout l = column(c);
        int p = dp(c, 14);
        l.setPadding(p, p, p, p);
        l.setBackground(rounded(c, CARD, 18, STROKE));
        l.setElevation(dp(c, 1));
        return l;
    }

    /** 顶部主视觉卡：主色渐变 + 大圆角，用来放页面标题。 */
    public static LinearLayout hero(Context c, String title, String subtitle) {
        LinearLayout l = column(c);
        int p = dp(c, 20);
        l.setPadding(p, p, p, p);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF53389E, 0xFF3B6FD4});
        g.setShape(GradientDrawable.RECTANGLE);
        g.setCornerRadius(dp(c, 26));
        l.setBackground(g);
        l.setElevation(dp(c, 3));

        TextView t = new TextView(c);
        t.setText(title);
        t.setTextSize(22);
        t.setTextColor(0xFFFFFFFF);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setLetterSpacing(0.01f);
        l.addView(t, fill());

        TextView s = new TextView(c);
        s.setText(subtitle);
        s.setTextSize(12);
        s.setTextColor(0xD9FFFFFF);
        s.setLineSpacing(dp(c, 3), 1f);
        l.addView(s, fillTop(c, 8));
        return l;
    }

    public static ScrollView scroll(Context c, View child) {
        ScrollView sv = new ScrollView(c);
        sv.setBackgroundColor(BG);
        sv.setFillViewport(true);
        sv.addView(child, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return sv;
    }

    // ---------- 文字 ----------
    public static TextView big(Context c, String s) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(21);
        t.setTextColor(TEXT);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    public static TextView body(Context c, String s) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(13);
        t.setTextColor(TEXT);
        t.setLineSpacing(dp(c, 3), 1f);
        return t;
    }

    public static TextView sub(Context c, String s) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(12);
        t.setTextColor(SUB);
        t.setLineSpacing(dp(c, 3), 1f);
        return t;
    }

    public static TextView section(Context c, String s) {
        TextView t = new TextView(c);
        t.setText("▎ " + s);
        t.setTextSize(13);
        t.setTextColor(ACCENT);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setLetterSpacing(0.06f);
        t.setPadding(dp(c, 2), dp(c, 20), dp(c, 2), dp(c, 8));
        return t;
    }

    public static TextView mono(Context c, String s) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(11);
        t.setTextColor(GREEN);
        t.setTypeface(Typeface.MONOSPACE);
        t.setTextIsSelectable(true);
        t.setLineSpacing(dp(c, 2), 1f);
        return t;
    }

    // ---------- 控件 ----------
    public static Button primary(Context c, String s) {
        Button b = new Button(c);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setTextColor(ON_ACCENT);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setBackground(stateful(c, ACCENT, ACCENT_D, 14, 0, 0));
        b.setPadding(dp(c, 16), dp(c, 12), dp(c, 16), dp(c, 12));
        b.setMinHeight(dp(c, 46));
        b.setElevation(dp(c, 2));
        return b;
    }

    public static Button ghost(Context c, String s) {
        Button b = new Button(c);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(13);
        b.setTextColor(TEXT);
        b.setBackground(stateful(c, 0xFF1E2733, 0xFF27313F, 12, STROKE, ACCENT));
        b.setPadding(dp(c, 14), dp(c, 10), dp(c, 14), dp(c, 10));
        b.setMinHeight(dp(c, 42));
        return b;
    }

    public static Button danger(Context c, String s) {
        Button b = ghost(c, s);
        b.setTextColor(RED);
        return b;
    }

    public static Button small(Context c, String s) {
        Button b = ghost(c, s);
        b.setTextSize(12);
        b.setPadding(dp(c, 10), dp(c, 6), dp(c, 10), dp(c, 6));
        b.setMinHeight(dp(c, 34));
        b.setMinWidth(dp(c, 56));
        return b;
    }

    public static EditText input(Context c, String hint, String value) {
        EditText e = new EditText(c);
        e.setHint(hint);
        e.setText(value);
        e.setTextSize(13);
        e.setTextColor(TEXT);
        e.setHintTextColor(FAINT);
        e.setPadding(dp(c, 12), dp(c, 11), dp(c, 12), dp(c, 11));
        e.setBackground(stateful(c, INPUT, INPUT, 10, STROKE, ACCENT));
        return e;
    }

    public static CheckBox check(Context c, String s, boolean checked) {
        CheckBox b = new CheckBox(c);
        b.setText(s);
        b.setTextSize(13);
        b.setTextColor(TEXT);
        b.setButtonTintList(ColorStateList.valueOf(ACCENT));
        b.setChecked(checked);
        b.setPadding(dp(c, 2), dp(c, 6), 0, dp(c, 6));
        return b;
    }

    // ---------- Material Design 3 组件 ----------

    /** MD3 card：24dp 圆角、色调填充、不加描边。 */
    public static LinearLayout md3Card(Context c) {
        LinearLayout l = column(c);
        int p = dp(c, 18);
        l.setPadding(p, p, p, p);
        l.setBackground(rounded(c, M3_SURFACE_CONT, 24, 0));
        l.setElevation(dp(c, 2));
        return l;
    }

    /** MD3 assist chip：小圆角胶囊标签。 */
    public static TextView md3Label(Context c, String s) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(11);
        t.setTextColor(M3_ON_PRIMARY_CONT);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setLetterSpacing(0.08f);
        t.setBackground(rounded(c, M3_PRIMARY_CONT, 20, 0));
        t.setPadding(dp(c, 11), dp(c, 5), dp(c, 11), dp(c, 5));
        return t;
    }

    /** MD3 title medium。 */
    public static TextView md3Title(Context c, String s) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(16);
        t.setTextColor(M3_ON_SURFACE);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setLetterSpacing(0.01f);
        return t;
    }

    /** MD3 body medium。 */
    public static TextView md3Body(Context c, String s) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(14);
        t.setTextColor(M3_ON_SURFACE_VAR);
        t.setLineSpacing(dp(c, 4), 1f);
        return t;
    }

    /** MD3 filled tonal button（secondary container）。 */
    public static Button md3Tonal(Context c, String s) {
        Button b = new Button(c);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setTextColor(M3_ON_SEC_CONT);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setLetterSpacing(0.02f);
        b.setBackground(stateful(c, M3_SEC_CONT, M3_SEC_CONT_D, 20, 0, 0));
        b.setPadding(dp(c, 18), dp(c, 12), dp(c, 18), dp(c, 12));
        b.setMinHeight(dp(c, 46));
        return b;
    }
}
