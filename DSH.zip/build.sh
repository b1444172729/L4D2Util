#!/usr/bin/env bash
# 复现构建：javac -> d8(classes4.dex) -> apktool b -> 注入 dex -> zipalign -> apksigner
#
# 依赖：
#   - JDK 17（javac / java；android-all.jar 为 class 61）
#   - apktool.jar
#   - android-all.jar（编译期提供 android.* / org.json.* API）
#   - Android build-tools 目录（内含 d8 / zipalign / apksigner）
#   - keystore（默认 alias=ds，口令=android）
#
# 用法：
#   BASE=... DSDEC=... BT=... APKTOOL=... bash build.sh <输出.apk>
set -e

BASE=${BASE:-$(cd "$(dirname "$0")" && pwd)}
DSDEC=${DSDEC:-$BASE/dsdec}              # apktool 反编译工程（已打好 smali 注入点）
ANDROID_JAR=${ANDROID_JAR:-$BASE/android-all.jar}
BT=${BT:-$BASE/bt}                       # 含 d8 / zipalign / apksigner
APKTOOL=${APKTOOL:-$BASE/apktool.jar}
KEYSTORE=${KEYSTORE:-$BASE/ds.keystore}
KS_PASS=${KS_PASS:-android}
OUT=${1:-$BASE/DeepSeekMod.apk}

SRC=$BASE/src/com/ds/dspatch
CLS=$BASE/build/cls
DEXDIR=$BASE/build/dex
RB=$BASE/build/_rb.apk
MOD=$BASE/build/_mod.apk
ALIGNED=$BASE/build/_aligned.apk
mkdir -p "$BASE/build"

echo "[1/6] javac"
rm -rf "$CLS"; mkdir -p "$CLS"
javac -nowarn -source 8 -target 8 -d "$CLS" -cp "$ANDROID_JAR" "$SRC"/*.java

echo "[2/6] d8 -> classes4.dex"
rm -rf "$DEXDIR"; mkdir -p "$DEXDIR"
"$BT/d8" --min-api 23 --lib "$ANDROID_JAR" --output "$DEXDIR" $(find "$CLS" -name '*.class')
mv "$DEXDIR/classes.dex" "$DEXDIR/classes4.dex"

echo "[3/6] apktool b"
java -Xmx3g -jar "$APKTOOL" b "$DSDEC" -o "$RB"

echo "[4/6] 注入 classes4.dex"
cp "$RB" "$MOD"
( cd "$DEXDIR" && zip -0 -X -q "$MOD" classes4.dex )

echo "[5/6] zipalign + apksigner"
"$BT/zipalign" -f -p 4 "$MOD" "$ALIGNED"
rm -f "$OUT"
"$BT/apksigner" sign --ks "$KEYSTORE" --ks-pass pass:$KS_PASS --key-pass pass:$KS_PASS \
  --ks-key-alias ds --v1-signing-enabled true --v2-signing-enabled true \
  --out "$OUT" "$ALIGNED"

echo "[6/6] 校验"
"$BT/apksigner" verify "$OUT" && echo "签名校验通过"
echo "OK -> $OUT"
