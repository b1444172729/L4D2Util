# JGit uses ServiceLoader for its platform and transport implementations.
-keep class * extends org.eclipse.jgit.util.FS { public <init>(...); }
-keep class * extends org.eclipse.jgit.transport.SshSessionFactory { *; }
-keep class org.eclipse.jgit.transport.TransportHttp { *; }
-keep class org.eclipse.jgit.transport.TransportLocal { *; }
-keep class org.eclipse.jgit.transport.TransportGitAnon { *; }
-keep class org.eclipse.jgit.transport.TransportBundleFile { *; }
-keep class org.eclipse.jgit.transport.HttpAuthMethod$** { *; }
-keep class org.eclipse.jgit.internal.JGitText { public <fields>; }
-keep class * extends org.eclipse.jgit.nls.TranslationBundle { public <fields>; public <init>(); }
-keepattributes Signature,InnerClasses,EnclosingMethod
-dontwarn org.slf4j.impl.StaticLoggerBinder
-dontwarn org.slf4j.impl.StaticMDCBinder
-dontwarn org.slf4j.impl.StaticMarkerBinder

-keep class org.eclipse.jgit.transport.HttpTransport { *; }
-keep class org.eclipse.jgit.transport.http.JDKHttpConnectionFactory { *; }
-keep class org.eclipse.jgit.util.sha1.SHA1Java { *; }
-keep class org.slf4j.nop.NOPServiceProvider { public <init>(); *; }
-keep class * implements org.eclipse.jgit.transport.http.HttpConnectionFactory { public <init>(); }

# Desktop JVM monitoring and Kerberos are optional JGit paths, unused by GitHub HTTPS/PAT.
-dontwarn javax.management.**
-dontwarn java.lang.management.**
-dontwarn org.ietf.jgss.**

# Android has no ProcessHandle. LocalGit.openGit disables both gc.auto and
# gc.autoPackLimit, including before the initial clone fetch, so JGit's
# GC.PidLock path is never used by this app. Do not enable manual/automatic
# JGit GC without providing an Android-compatible PID implementation first.
-dontwarn java.lang.ProcessHandle

# JGit 通过 ServiceLoader 和反射加载 transport / FS / NLS 实现，R8 全模式会把这些
# “只按名字加载”的类当成无用代码删掉，克隆时报 NoClassDefFoundError / 资源缺失。
# 先在 Release 上整体保留 JGit，确认功能正常后再按需收窄规则以减小体积。
-keep class org.eclipse.jgit.** { *; }
-keep interface org.eclipse.jgit.** { *; }
