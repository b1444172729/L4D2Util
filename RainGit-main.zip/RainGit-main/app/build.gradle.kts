plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "me.rain.git"
    compileSdk = 35

    defaultConfig {
        applicationId = "me.rain.git"
        // JGit 6.10 内部调用 InputStream.readNBytes(int)，该方法 Android 13（API 33）才提供。
        // 低于 API 33 的设备上克隆会抛 NoSuchMethodError 并导致闪退，故下限设为 33。
        // 若必须支持 Android 11/12，请把 JGit 降级到 6.6.1.202309021850-r（尚未引入 readNBytes）。
        minSdk = 33
        targetSdk = 35
        versionCode = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 1
        versionName = "1.3.0"
    }

    signingConfigs {
        val signingPath = System.getenv("RAINGIT_SIGNING_STORE_FILE")
        if (!signingPath.isNullOrBlank()) {
            create("ciRelease") {
                storeFile = file(signingPath)
                storePassword = System.getenv("RAINGIT_SIGNING_STORE_PASSWORD")
                keyAlias = System.getenv("RAINGIT_SIGNING_KEY_ALIAS")
                keyPassword = System.getenv("RAINGIT_SIGNING_KEY_PASSWORD")
            }
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.findByName("ciRelease")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        isCoreLibraryDesugaringEnabled = true
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true; buildConfig = true }
    packaging {
        resources.excludes += setOf("META-INF/DEPENDENCIES")
        resources.merges += setOf("META-INF/NOTICE*", "META-INF/LICENSE*")
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2025.08.01")
    implementation(composeBom)
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.9.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.9.2")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.9.2")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.eclipse.jgit:org.eclipse.jgit:6.10.1.202505221210-r")
    implementation("org.slf4j:slf4j-nop:2.0.16")
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.5")
}
