using System;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using SshAssistant.Models;
using SshAssistant.Ssh;

namespace SshAssistant.Views
{
    /// <summary>文本编辑器：可直接编辑本地或远程文件</summary>
    public partial class EditorWindow : Window
    {
        private readonly LiveSession _session;
        private readonly string _path;
        private readonly bool _remote;
        private string _original;

        public EditorWindow(LiveSession session, string path, bool remote)
        {
            InitializeComponent();
            _session = session;
            _path = path;
            _remote = remote;
            Title = (remote ? "远程文件 - " : "本地文件 - ") + Path.GetFileName(path);
            PathText.Text = path;

            Loaded += (s, e) => Load();
        }

        private async void Load()
        {
            StatusText.Text = "读取中…";
            string content = null;
            string error = null;
            await Task.Run(() =>
            {
                try { content = _remote ? RemoteFs.ReadText(_session, _path) : LocalFs.ReadText(_path); }
                catch (Exception ex) { error = ex.Message; }
            });
            if (error != null)
            {
                StatusText.Text = "读取失败：" + error;
                return;
            }
            _original = content;
            Editor.Text = content;
            StatusText.Text = $"{content.Length} 字符";
        }

        private async void Save_Click(object sender, RoutedEventArgs e)
        {
            var content = Editor.Text;
            StatusText.Text = "保存中…";
            string error = null;
            await Task.Run(() =>
            {
                try
                {
                    if (_remote)
                    {
                        if (_session == null || !_session.IsAlive) throw new IOException("会话未连接");
                        RemoteFs.WriteText(_session, _path, content);
                    }
                    else LocalFs.WriteText(_path, content);
                }
                catch (Exception ex) { error = ex.Message; }
            });
            if (error != null) { StatusText.Text = "保存失败：" + error; return; }
            _original = content;
            // 不弹"已保存"提示：状态栏变化即为反馈（与 Android 版一致）
            StatusText.Text = "已保存 · " + DateTime.Now.ToString("HH:mm:ss");
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            if (Editor.Text != _original)
            {
                var r = MessageBox.Show("有未保存的修改，确定关闭？", "提示",
                    MessageBoxButton.YesNo, MessageBoxImage.Warning);
                if (r != MessageBoxResult.Yes) return;
            }
            Close();
        }
    }
}
