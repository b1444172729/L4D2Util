using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using SshAssistant.Models;
using SshAssistant.Ssh;

namespace SshAssistant.Views
{
    public partial class TransfersWindow : Window
    {
        public TransfersWindow()
        {
            InitializeComponent();
            Loaded += (s, e) =>
            {
                TransferService.Changed += Refresh;
                Refresh();
            };
            Unloaded += (s, e) => TransferService.Changed -= Refresh;
        }

        private void Refresh()
        {
            Dispatcher.Invoke(() =>
            {
                var items = TransferService.All().Select(t => new TaskView(t)).ToList();
                List.ItemsSource = items;
            });
        }

        private void Pause_Click(object s, RoutedEventArgs e)
        { if ((s as Button)?.Tag is TaskView v) { TransferService.Pause(v.Task); Refresh(); } }

        private void Resume_Click(object s, RoutedEventArgs e)
        { if ((s as Button)?.Tag is TaskView v) { TransferService.Resume(v.Task); Refresh(); } }

        private void Retry_Click(object s, RoutedEventArgs e)
        { if ((s as Button)?.Tag is TaskView v) { TransferService.Retry(v.Task); Refresh(); } }

        private void Cancel_Click(object s, RoutedEventArgs e)
        { if ((s as Button)?.Tag is TaskView v) { TransferService.Cancel(v.Task); Refresh(); } }

        private void Clear_Click(object s, RoutedEventArgs e)
        { TransferService.ClearFinished(); Refresh(); }
    }

    public class TaskView
    {
        public TransferTask Task { get; }
        public TaskView(TransferTask t) { Task = t; }
        public string Name => Task.Name;
        public double Percent => Task.Percent;
        public string StateText => Task.State switch
        {
            TaskState.Pending => "等待中",
            TaskState.Running => "传输中",
            TaskState.Paused => "已暂停",
            TaskState.Done => "已完成",
            TaskState.Failed => "失败：" + Task.Error,
            TaskState.Canceled => "已取消",
            _ => ""
        };
        public string StatusText =>
            $"{(Task.Kind == TransferKind.Upload ? "上传" : "下载")} · {StateText} · " +
            $"{FileItem.FormatSize(Task.Done)} / {FileItem.FormatSize(Task.Total)}";
    }
}
