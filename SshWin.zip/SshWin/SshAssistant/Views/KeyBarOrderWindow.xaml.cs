using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using SshAssistant.Data;

namespace SshAssistant.Views
{
    /// <summary>
    /// 按键栏顺序调整。
    /// Android 版只能长按拖动，在对话框里长按手势容易被滚动抢走，
    /// 表现为"调了没反应"。Windows 版同时提供 ▲▼ 按钮，点击必定生效；
    /// 每移动一格立即写入，关闭即已保存。
    /// </summary>
    public partial class KeyBarOrderWindow : Window
    {
        private readonly ObservableCollection<KeyDef> _items = new();

        public KeyBarOrderWindow()
        {
            InitializeComponent();
            Owner = Application.Current.MainWindow;
            Loaded += (s, e) => Reload();
        }

        private void Reload()
        {
            _items.Clear();
            foreach (var id in KeyBar.Order())
            {
                var d = KeyBar.Def(id);
                if (d != null) _items.Add(d);
            }
            List.ItemsSource = _items;
        }

        /// <summary>移动后立刻持久化，不依赖"保存"按钮</summary>
        private void Persist()
        {
            KeyBar.SaveOrder(_items.Select(x => x.Id).ToList());
        }

        private void Up_Click(object sender, RoutedEventArgs e)
        {
            if ((sender as Button)?.Tag is KeyDef d) Move(d.Id, -1);
        }

        private void Down_Click(object sender, RoutedEventArgs e)
        {
            if ((sender as Button)?.Tag is KeyDef d) Move(d.Id, +1);
        }

        private void Move(string id, int delta)
        {
            int i = _items.ToList().FindIndex(x => x.Id == id);
            if (i < 0) return;
            int j = i + delta;
            if (j < 0 || j >= _items.Count) return;
            _items.Move(i, j);
            Persist();
            List.SelectedIndex = j;
        }

        private void Reset_Click(object sender, RoutedEventArgs e)
        {
            KeyBar.ResetOrder();
            Reload();
        }

        private void Close_Click(object sender, RoutedEventArgs e) => Close();
    }
}
