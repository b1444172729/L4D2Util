using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using SshAssistant.Models;

namespace SshAssistant.Views
{
    /// <summary>通用输入对话框（新建文件/文件夹/重命名）</summary>
    public class InputDialog : Window
    {
        private readonly TextBox _tb = new TextBox { Margin = new Thickness(0, 8, 0, 0) };
        public string Value => _tb.Text.Trim();

        public InputDialog(string title, string defaultValue = "")
        {
            Title = title;
            Width = 420; Height = 180;
            WindowStartupLocation = WindowStartupLocation.CenterOwner;
            ResizeMode = ResizeMode.NoResize;
            Owner = Application.Current.MainWindow;
            Background = (Brush)Application.Current.FindResource("SurfaceBrush");

            var root = new StackPanel { Margin = new Thickness(20) };
            root.Children.Add(new TextBlock
            {
                Text = title,
                FontSize = 16,
                FontWeight = FontWeights.SemiBold,
                Foreground = (Brush)Application.Current.FindResource("TextPrimaryBrush")
            });
            _tb.Text = defaultValue;
            root.Children.Add(_tb);

            var bar = new StackPanel
            { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 16, 0, 0) };
            var cancel = new Button { Content = "取消", Style = (Style)Application.Current.FindResource("OutlineButton"), Margin = new Thickness(0, 0, 8, 0) };
            cancel.Click += (s, e) => { DialogResult = false; Close(); };
            var ok = new Button { Content = "确定", Padding = new Thickness(24, 8, 24, 8) };
            ok.Click += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(Value))
                { MessageBox.Show("内容不能为空"); return; }
                DialogResult = true; Close();
            };
            bar.Children.Add(cancel);
            bar.Children.Add(ok);
            root.Children.Add(bar);

            Content = root;
            Loaded += (s, e) => { _tb.SelectAll(); _tb.Focus(); };
        }
    }

    /// <summary>连接密码输入</summary>
    public class PasswordDialog : Window
    {
        private readonly PasswordBox _pb = new PasswordBox { Margin = new Thickness(0, 8, 0, 0) };
        private readonly CheckBox _remember = new CheckBox { Content = "记住密码", IsChecked = true, Margin = new Thickness(0, 10, 0, 0) };
        public string Password => _pb.Password;
        public bool Remember => _remember.IsChecked == true;

        public PasswordDialog(string hostName)
        {
            Title = "需要密码";
            Width = 420; Height = 240;
            WindowStartupLocation = WindowStartupLocation.CenterOwner;
            ResizeMode = ResizeMode.NoResize;
            Owner = Application.Current.MainWindow;
            Background = (Brush)Application.Current.FindResource("SurfaceBrush");

            var root = new StackPanel { Margin = new Thickness(20) };
            root.Children.Add(new TextBlock
            {
                Text = $"请输入「{hostName}」的登录密码",
                FontSize = 15,
                Foreground = (Brush)Application.Current.FindResource("TextPrimaryBrush")
            });
            root.Children.Add(_pb);
            root.Children.Add(_remember);

            var bar = new StackPanel
            { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 16, 0, 0) };
            var cancel = new Button { Content = "取消", Style = (Style)Application.Current.FindResource("OutlineButton"), Margin = new Thickness(0, 0, 8, 0) };
            cancel.Click += (s, e) => { DialogResult = false; Close(); };
            var ok = new Button { Content = "连接", Padding = new Thickness(24, 8, 24, 8) };
            ok.Click += (s, e) => { DialogResult = true; Close(); };
            bar.Children.Add(cancel);
            bar.Children.Add(ok);
            root.Children.Add(bar);

            Content = root;
            Loaded += (s, e) => _pb.Focus();
        }
    }

    /// <summary>快捷命令选择</summary>
    public class ShortcutDialog : Window
    {
        public string Selected { get; private set; }

        public ShortcutDialog(List<string> cmds)
        {
            Title = "快捷命令";
            Width = 460; Height = 400;
            WindowStartupLocation = WindowStartupLocation.CenterOwner;
            Owner = Application.Current.MainWindow;
            Background = (Brush)Application.Current.FindResource("SurfaceBrush");

            var root = new StackPanel { Margin = new Thickness(20) };
            root.Children.Add(new TextBlock
            {
                Text = "选择要发送的命令",
                FontSize = 15,
                Margin = new Thickness(0, 0, 0, 10),
                Foreground = (Brush)Application.Current.FindResource("TextPrimaryBrush")
            });
            var list = new ListBox { Height = 260, Background = Brushes.Transparent, BorderThickness = new Thickness(0) };
            list.ItemsSource = cmds;
            root.Children.Add(list);

            var bar = new StackPanel
            { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 14, 0, 0) };
            var cancel = new Button { Content = "取消", Style = (Style)Application.Current.FindResource("OutlineButton"), Margin = new Thickness(0, 0, 8, 0) };
            cancel.Click += (s, e) => { DialogResult = false; Close(); };
            var ok = new Button { Content = "发送", Padding = new Thickness(24, 8, 24, 8), IsEnabled = false };
            list.SelectionChanged += (s, e) => ok.IsEnabled = list.SelectedItem != null;
            ok.Click += (s, e) => { Selected = list.SelectedItem?.ToString(); DialogResult = true; Close(); };
            bar.Children.Add(cancel);
            bar.Children.Add(ok);
            root.Children.Add(bar);

            Content = root;
        }
    }

    /// <summary>
    /// 权限修改：9 个勾选框 + 顶部全选 + 数值显示。
    /// 只能通过勾选改变 —— Android 版曾加过数字输入框，但它与勾选框双向联动，
    /// 会在用户输入过程中被程序回写覆盖（666 改 777 时刚敲第一个 7 就被改回去），已移除。
    /// </summary>
    public class PermissionsDialog : Window
    {
        private readonly List<(int bit, CheckBox box)> _boxes = new();
        private readonly TextBlock _octal = new TextBlock { FontSize = 18, FontWeight = FontWeights.Bold, Margin = new Thickness(12, 0, 0, 0) };
        private readonly CheckBox _selectAll = new CheckBox { Content = "全选", VerticalAlignment = VerticalAlignment.Center };
        private bool _programmatic;

        public int Value
        {
            get
            {
                int v = 0;
                foreach (var (bit, box) in _boxes) if (box.IsChecked == true) v |= bit;
                return v;
            }
        }

        public PermissionsDialog(int current)
        {
            Title = "权限";
            Width = 380; Height = 400;
            WindowStartupLocation = WindowStartupLocation.CenterOwner;
            ResizeMode = ResizeMode.NoResize;
            Owner = Application.Current.MainWindow;
            Background = (Brush)Application.Current.FindResource("SurfaceBrush");

            var root = new Grid { Margin = new Thickness(24) };
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            // 标题行：左「权限」+ 右「全选」，与内容区同一条起始线
            var titleRow = new Grid { Margin = new Thickness(0, 0, 0, 12) };
            titleRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            titleRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            var title = new TextBlock { Text = "权限", FontSize = 18, FontWeight = FontWeights.SemiBold };
            Grid.SetColumn(title, 0);
            Grid.SetColumn(_selectAll, 1);
            titleRow.Children.Add(title);
            titleRow.Children.Add(_selectAll);
            Grid.SetRow(titleRow, 0);
            root.Children.Add(titleRow);

            // 数值显示
            var octalRow = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 0, 12) };
            octalRow.Children.Add(new TextBlock { Text = "权限值", VerticalAlignment = VerticalAlignment.Center });
            octalRow.Children.Add(_octal);
            Grid.SetRow(octalRow, 1);
            root.Children.Add(octalRow);

            // 9 个勾选框
            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            for (int i = 0; i < 3; i++) grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            string[] groups = { "属主", "属组", "其他" };
            int[] bits = { 0b100000000, 0b010000000, 0b001000000, 0b000100000, 0b000010000,
                           0b000001000, 0b000000100, 0b000000010, 0b000000001 };
            string[] acts = { "读", "写", "执行" };

            for (int g = 0; g < 3; g++)
            {
                grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                var lb = new TextBlock
                {
                    Text = groups[g],
                    VerticalAlignment = VerticalAlignment.Center,
                    Margin = new Thickness(0, 8, 16, 8),
                    Width = 40
                };
                Grid.SetRow(lb, g); Grid.SetColumn(lb, 0);
                grid.Children.Add(lb);

                for (int a = 0; a < 3; a++)
                {
                    int bit = bits[g * 3 + a];
                    var cb = new CheckBox
                    {
                        Content = acts[a],
                        Margin = new Thickness(0, 8, 12, 8),
                        IsChecked = (current & bit) != 0
                    };
                    cb.Checked += (s, e) => { if (!_programmatic) Refresh(); };
                    cb.Unchecked += (s, e) => { if (!_programmatic) Refresh(); };
                    _boxes.Add((bit, cb));
                    Grid.SetRow(cb, g); Grid.SetColumn(cb, a + 1);
                    grid.Children.Add(cb);
                }
            }
            Grid.SetRow(grid, 2);
            root.Children.Add(grid);

            // 按钮
            var bar = new StackPanel
            { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 16, 0, 0) };
            var cancel = new Button { Content = "取消", Style = (Style)Application.Current.FindResource("OutlineButton"), Margin = new Thickness(0, 0, 8, 0) };
            cancel.Click += (s, e) => { DialogResult = false; Close(); };
            var ok = new Button { Content = "确定", Padding = new Thickness(24, 8, 24, 8) };
            ok.Click += (s, e) => { DialogResult = true; Close(); };
            bar.Children.Add(cancel);
            bar.Children.Add(ok);
            Grid.SetRow(bar, 3);
            root.Children.Add(bar);

            _selectAll.Checked += (s, e) => { if (!_programmatic) SetAll(true); };
            _selectAll.Unchecked += (s, e) => { if (!_programmatic) SetAll(false); };

            Content = root;
            Refresh();
        }

        private void SetAll(bool on)
        {
            _programmatic = true;
            try { foreach (var (_, box) in _boxes) box.IsChecked = on; }
            finally { _programmatic = false; }
            UpdateOctal();
        }

        private void Refresh()
        {
            UpdateOctal();
            _programmatic = true;
            try { _selectAll.IsChecked = Value == 0x1FF; }
            finally { _programmatic = false; }
        }

        private void UpdateOctal()
        {
            _octal.Text = Convert.ToString(Value & 0x1FF, 8).PadLeft(3, '0');
        }
    }

    /// <summary>主机密钥信任（TOFU）</summary>
    public class TrustDialog : Window
    {
        public bool AlwaysTrust { get; private set; }

        public TrustDialog(string host, int port, string fingerprint)
        {
            Title = "未知主机密钥";
            Width = 500; Height = 300;
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            ResizeMode = ResizeMode.NoResize;
            Background = (Brush)Application.Current.FindResource("SurfaceBrush");

            var root = new StackPanel { Margin = new Thickness(24) };
            root.Children.Add(new TextBlock
            {
                Text = "首次连接该主机",
                FontSize = 17,
                FontWeight = FontWeights.SemiBold,
                Foreground = (Brush)Application.Current.FindResource("TextPrimaryBrush")
            });
            root.Children.Add(new TextBlock
            {
                Text = $"{host}:{port}",
                Margin = new Thickness(0, 6, 0, 0),
                Foreground = (Brush)Application.Current.FindResource("TextSecondaryBrush")
            });
            root.Children.Add(new TextBlock
            {
                Text = "指纹：" + fingerprint,
                Margin = new Thickness(0, 14, 0, 0),
                FontFamily = new FontFamily("Consolas"),
                TextWrapping = TextWrapping.Wrap,
                Foreground = (Brush)Application.Current.FindResource("TextPrimaryBrush")
            });
            root.Children.Add(new TextBlock
            {
                Text = "请确认指纹与服务器管理员提供的一致，避免中间人攻击。",
                Margin = new Thickness(0, 12, 0, 0),
                TextWrapping = TextWrapping.Wrap,
                Foreground = (Brush)Application.Current.FindResource("TextSecondaryBrush")
            });

            var once = new Button { Content = "仅本次信任", Style = (Style)Application.Current.FindResource("OutlineButton"), Margin = new Thickness(0, 20, 8, 0) };
            var always = new Button { Content = "始终信任", Padding = new Thickness(20, 8, 20, 8), Margin = new Thickness(0, 20, 8, 0) };
            var reject = new Button { Content = "拒绝", Style = (Style)Application.Current.FindResource("OutlineButton"), Margin = new Thickness(0, 20, 0, 0),
                Foreground = (Brush)Application.Current.FindResource("ErrorBrush") };

            once.Click += (s, e) => { AlwaysTrust = false; DialogResult = true; Close(); };
            always.Click += (s, e) => { AlwaysTrust = true; DialogResult = true; Close(); };
            reject.Click += (s, e) => { DialogResult = false; Close(); };

            var bar = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
            bar.Children.Add(reject);
            bar.Children.Add(once);
            bar.Children.Add(always);
            root.Children.Add(bar);

            Content = root;
        }
    }

    /// <summary>
    /// 添加转发规则。
    /// 三个输入框都套 ScrollView：键盘弹出/空间不足时 LinearLayout 会压缩
    /// 最后一个子项导致其高度归零（表现为"能输入但看不见，只剩光标一角"）。
    /// </summary>
    public class ForwardDialog : Window
    {
        private readonly TextBox _local = new TextBox { Margin = new Thickness(0, 6, 0, 0) };
        private readonly TextBox _remoteHost = new TextBox { Text = "127.0.0.1", Margin = new Thickness(0, 6, 0, 0) };
        private readonly TextBox _remotePort = new TextBox { Margin = new Thickness(0, 6, 0, 0) };

        public int LocalPort { get; private set; }
        public string RemoteHost { get; private set; }
        public int RemotePort { get; private set; }

        public ForwardDialog()
        {
            Title = "添加转发";
            Width = 400; Height = 320;
            WindowStartupLocation = WindowStartupLocation.CenterOwner;
            ResizeMode = ResizeMode.NoResize;
            Background = (Brush)Application.Current.FindResource("SurfaceBrush");

            var scroll = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
            var root = new StackPanel { Margin = new Thickness(24) };

            root.Children.Add(Label("本地端口"));
            root.Children.Add(_local);
            root.Children.Add(Label("目标主机"));
            root.Children.Add(_remoteHost);
            root.Children.Add(Label("目标端口"));
            root.Children.Add(_remotePort);

            var bar = new StackPanel
            { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 20, 0, 0) };
            var cancel = new Button { Content = "取消", Style = (Style)Application.Current.FindResource("OutlineButton"), Margin = new Thickness(0, 0, 8, 0) };
            cancel.Click += (s, e) => { DialogResult = false; Close(); };
            var ok = new Button { Content = "确定", Padding = new Thickness(24, 8, 24, 8) };
            ok.Click += (s, e) =>
            {
                if (!int.TryParse(ExtractNumber(_local.Text), out int lp) || lp < 1 || lp > 65535 ||
                    !int.TryParse(ExtractNumber(_remotePort.Text), out int rp) || rp < 1 || rp > 65535 ||
                    string.IsNullOrWhiteSpace(_remoteHost.Text))
                {
                    MessageBox.Show("请填写 1–65535 的端口", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }
                LocalPort = lp; RemoteHost = _remoteHost.Text.Trim(); RemotePort = rp;
                DialogResult = true; Close();
            };
            bar.Children.Add(cancel);
            bar.Children.Add(ok);
            root.Children.Add(bar);

            scroll.Content = root;
            Content = scroll;
            Loaded += (s, e) => _local.Focus();
        }

        private static TextBlock Label(string text) => new TextBlock
        {
            Text = text,
            Margin = new Thickness(0, 10, 0, 0),
            Foreground = (Brush)Application.Current.FindResource("TextSecondaryBrush")
        };

        /// <summary>取字符串中第一段连续数字：即使输入法混入空格/符号也不失败</summary>
        private static string ExtractNumber(string s)
        {
            if (string.IsNullOrWhiteSpace(s)) return null;
            var m = System.Text.RegularExpressions.Regex.Match(s, @"\d+");
            return m.Success ? m.Value : null;
        }
    }
}
