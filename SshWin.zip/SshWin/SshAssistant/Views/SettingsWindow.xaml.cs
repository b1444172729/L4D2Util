using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using SshAssistant.Data;
using SshAssistant.Ssh;
using SshAssistant.Terminal;

namespace SshAssistant.Views
{
    public partial class SettingsWindow : Window
    {
        public SettingsWindow()
        {
            InitializeComponent();
            Owner = Application.Current.MainWindow;
            var s = App.Settings;

            SlFont.Value = s.FontSize;
            LbFont.Text = s.FontSize.ToString();
            TbScrollback.Text = s.Scrollback.ToString();
            CbTerm.Text = s.TermType;
            TbKeepalive.Text = s.Keepalive.ToString();
            TbShortcuts.Text = string.Join("\n", s.Shortcuts);
            ChkKeyBar.IsChecked = s.ShowKeyBar;
            ChkBell.IsChecked = s.Bell;
            ChkHidden.IsChecked = s.ShowHidden;
            TbLocalRoot.Text = s.LocalRoot;
            ChkCompression.IsChecked = s.Compression;

            foreach (ComboBoxItem it in CbConflict.Items)
                if ((string)it.Tag == s.Conflict) CbConflict.SelectedItem = it;
            foreach (ComboBoxItem it in CbTheme.Items)
                if ((string)it.Tag == s.Theme) CbTheme.SelectedItem = it;

            UpdateKnownCount();
            _loading = false;   // 初始化完成，之后的改动都算用户改动
        }

        private void UpdateKnownCount()
        {
            try
            {
                var file = Paths.KnownHostsFile;
                if (System.IO.File.Exists(file))
                {
                    var json = System.IO.File.ReadAllText(file);
                    var dict = System.Text.Json.JsonSerializer.Deserialize<System.Collections.Generic.Dictionary<string, string>>(json);
                    LbKnown.Text = $"已保存 {dict?.Count ?? 0} 条";
                }
                else LbKnown.Text = "已保存 0 条";
            }
            catch { LbKnown.Text = ""; }
        }

        // ==================== 即时生效 ====================
        //
        // 需求：在设置里做任何改动都要立刻生效，不用点"保存"。
        // 做法：每个控件的变更事件都走同一个 ApplyLive()，
        // 它负责收集当前值 → 写回设置 → 落盘 → 让界面/终端马上跟着变。
        private bool _loading = true;

        private void ApplyLive()
        {
            if (_loading) return;    // 初始化填充控件期间不算"用户改动"
            if (!IsLoaded) return;

            var s = App.Settings;
            s.FontSize = (int)SlFont.Value;
            if (int.TryParse(TbScrollback.Text, out int sb)) s.Scrollback = Math.Clamp(sb, 100, 100000);
            s.TermType = CbTerm.Text ?? "";
            if (int.TryParse(TbKeepalive.Text, out int ka)) s.Keepalive = Math.Clamp(ka, 0, 3600);
            s.Shortcuts = (TbShortcuts.Text ?? "")
                .Split(new[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(x => x.Trim()).Where(x => x.Length > 0).ToList();
            s.ShowKeyBar = ChkKeyBar.IsChecked == true;
            s.Bell = ChkBell.IsChecked == true;
            s.ShowHidden = ChkHidden.IsChecked == true;
            s.LocalRoot = (TbLocalRoot.Text ?? "").Trim();
            s.Conflict = ((ComboBoxItem)CbConflict.SelectedItem)?.Tag as string ?? "ask";
            s.Theme = ((ComboBoxItem)CbTheme.SelectedItem)?.Tag as string ?? "dark";
            App.SaveSettings();

            // 主题：立即套用（含终端配色）
            App.ApplyTheme();

            // 终端字号 / 回滚上限 / 按键栏：通知所有已打开的会话窗口刷新
            TerminalEmulator.SetLightTheme(s.Theme == "light" || (s.Theme == "system" && SystemIsLight()));
            foreach (var sess in SessionRegistry.All())
                sess.Emulator.ApplyMaxScrollback(s.Scrollback);
            foreach (System.Windows.Window w in System.Windows.Application.Current.Windows)
                if (w is SessionWindow sw) sw.ApplyPrefs();
        }

        private void AnyControl_Changed(object sender, RoutedEventArgs e) => ApplyLive();

        private void SlFont_Changed(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            // 【重要】XAML 是按从上到下的顺序创建的：
            // SlFont 声明在 LbFont 之前，而 Slider 应用 Minimum 时会把默认 Value
            // 强制抬到 8，从而在【解析过程中】就触发 ValueChanged。
            // 此时 LbFont 还是 null，直接访问会导致 NullReferenceException（窗口一显示就崩）。
            if (LbFont == null) return;
            LbFont.Text = ((int)SlFont.Value).ToString();
            ApplyLive();     // 拖动字号即时生效
        }

        private void TbScrollback_Lost(object sender, RoutedEventArgs e)
        {
            // Android 版这里曾因 EditTextPreference 写入字符串导致 getInt 崩溃，
            // 故一律用 TryParse + 范围收敛，不做类型假设。
            if (!int.TryParse(TbScrollback.Text, out int v)) v = 3000;
            v = Math.Clamp(v, 100, 100000);
            TbScrollback.Text = v.ToString();
        }

        private void ClearKnown_Click(object sender, RoutedEventArgs e)
        {
            int n = HostStore.ClearKnownHosts();
            UpdateKnownCount();
            // 这是真正的动作，需要告知结果（其余设置项一律不弹提示）
            MessageBox.Show($"已清除 {n} 条主机密钥", "提示", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void KeyOrder_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new KeyBarOrderWindow { Owner = this };
            dlg.ShowDialog();
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            ApplyLive();     // 兜底：确保关闭前最后一次改动已落盘
            DialogResult = true;
            Close();
        }

        private void Save_Click_Unused(object sender, RoutedEventArgs e)
        {
            var s = App.Settings;
            s.FontSize = (int)SlFont.Value;
            if (int.TryParse(TbScrollback.Text, out int sb)) s.Scrollback = Math.Clamp(sb, 100, 100000);
            s.TermType = CbTerm.Text;
            if (int.TryParse(TbKeepalive.Text, out int ka)) s.Keepalive = Math.Clamp(ka, 0, 3600);
            s.Shortcuts = TbShortcuts.Text
                .Split(new[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(x => x.Trim()).Where(x => x.Length > 0).ToList();
            s.ShowKeyBar = ChkKeyBar.IsChecked == true;
            s.Bell = ChkBell.IsChecked == true;
            s.ShowHidden = ChkHidden.IsChecked == true;
            s.LocalRoot = TbLocalRoot.Text.Trim();
            s.Conflict = ((ComboBoxItem)CbConflict.SelectedItem)?.Tag as string ?? "ask";
            s.Compression = ChkCompression.IsChecked == true;
            s.Theme = ((ComboBoxItem)CbTheme.SelectedItem)?.Tag as string ?? "dark";
            App.SaveSettings();

            // 设置即时生效：终端配色与回滚上限立刻同步
            TerminalEmulator.SetLightTheme(s.Theme == "light" || (s.Theme == "system" && SystemIsLight()));
            foreach (var sess in SessionRegistry.All())
                sess.Emulator.ApplyMaxScrollback(s.Scrollback);

            DialogResult = true;
            Close();
        }

        private static bool SystemIsLight()
        {
            try
            {
                using var k = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(
                    @"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize");
                return k?.GetValue("AppsUseLightTheme") is int i && i == 1;
            }
            catch { return false; }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}
