using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using SshAssistant.Data;
using SshAssistant.Ssh;
using SshAssistant.Terminal;

namespace SshAssistant.Views
{
    public partial class SettingsWindow : Window
    {
        public SettingsWindow()
        {
            InitializeComponent();
            Owner = Application.Current.MainWindow;
            var s = App.Settings;

            SlFont.Value = s.FontSize;
            LbFont.Text = s.FontSize.ToString();
            TbScrollback.Text = s.Scrollback.ToString();
            CbTerm.Text = s.TermType;
            TbKeepalive.Text = s.Keepalive.ToString();
            TbShortcuts.Text = string.Join("\n", s.Shortcuts);
            ChkKeyBar.IsChecked = s.ShowKeyBar;
            ChkBell.IsChecked = s.Bell;
            ChkHidden.IsChecked = s.ShowHidden;
            TbLocalRoot.Text = s.LocalRoot;
            ChkCompression.IsChecked = s.Compression;

            foreach (ComboBoxItem it in CbConflict.Items)
                if ((string)it.Tag == s.Conflict) CbConflict.SelectedItem = it;
            foreach (ComboBoxItem it in CbTheme.Items)
                if ((string)it.Tag == s.Theme) CbTheme.SelectedItem = it;

            UpdateKnownCount();
        }

        private void UpdateKnownCount()
        {
            try
            {
                var file = Paths.KnownHostsFile;
                if (System.IO.File.Exists(file))
                {
                    var json = System.IO.File.ReadAllText(file);
                    var dict = System.Text.Json.JsonSerializer.Deserialize<System.Collections.Generic.Dictionary<string, string>>(json);
                    LbKnown.Text = $"已保存 {dict?.Count ?? 0} 条";
                }
                else LbKnown.Text = "已保存 0 条";
            }
            catch { LbKnown.Text = ""; }
        }

        private void SlFont_Changed(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            LbFont.Text = ((int)SlFont.Value).ToString();
        }

        private void TbScrollback_Lost(object sender, RoutedEventArgs e)
        {
            // Android 版这里曾因 EditTextPreference 写入字符串导致 getInt 崩溃，
            // 故一律用 TryParse + 范围收敛，不做类型假设。
            if (!int.TryParse(TbScrollback.Text, out int v)) v = 3000;
            v = Math.Clamp(v, 100, 100000);
            TbScrollback.Text = v.ToString();
        }

        private void ClearKnown_Click(object sender, RoutedEventArgs e)
        {
            int n = HostStore.ClearKnownHosts();
            UpdateKnownCount();
            // 这是真正的动作，需要告知结果（其余设置项一律不弹提示）
            MessageBox.Show($"已清除 {n} 条主机密钥", "提示", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void KeyOrder_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new KeyBarOrderWindow { Owner = this };
            dlg.ShowDialog();
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            var s = App.Settings;
            s.FontSize = (int)SlFont.Value;
            if (int.TryParse(TbScrollback.Text, out int sb)) s.Scrollback = Math.Clamp(sb, 100, 100000);
            s.TermType = CbTerm.Text;
            if (int.TryParse(TbKeepalive.Text, out int ka)) s.Keepalive = Math.Clamp(ka, 0, 3600);
            s.Shortcuts = TbShortcuts.Text
                .Split(new[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(x => x.Trim()).Where(x => x.Length > 0).ToList();
            s.ShowKeyBar = ChkKeyBar.IsChecked == true;
            s.Bell = ChkBell.IsChecked == true;
            s.ShowHidden = ChkHidden.IsChecked == true;
            s.LocalRoot = TbLocalRoot.Text.Trim();
            s.Conflict = ((ComboBoxItem)CbConflict.SelectedItem)?.Tag as string ?? "ask";
            s.Compression = ChkCompression.IsChecked == true;
            s.Theme = ((ComboBoxItem)CbTheme.SelectedItem)?.Tag as string ?? "dark";
            App.SaveSettings();

            // 设置即时生效：终端配色与回滚上限立刻同步
            TerminalEmulator.SetLightTheme(s.Theme == "light" || (s.Theme == "system" && SystemIsLight()));
            foreach (var sess in SessionRegistry.All())
                sess.Emulator.ApplyMaxScrollback(s.Scrollback);

            DialogResult = true;
            Close();
        }

        private static bool SystemIsLight()
        {
            try
            {
                using var k = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(
                    @"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize");
                return k?.GetValue("AppsUseLightTheme") is int i && i == 1;
            }
            catch { return false; }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}
