using System;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using SshAssistant.Data;
using SshAssistant.Models;
using SshAssistant.Ssh;

namespace SshAssistant.Views
{
    public partial class HostEditWindow : Window
    {
        private readonly HostConfig _existing;
        public HostConfig Result { get; private set; }

        public HostEditWindow(HostConfig existing)
        {
            InitializeComponent();
            _existing = existing;
            Title = existing == null ? "新增主机" : "编辑主机";
            Owner = Application.Current.MainWindow;

            if (existing != null)
            {
                TbName.Text = existing.Name;
                TbHost.Text = existing.Host;
                TbPort.Text = existing.Port.ToString();
                TbUser.Text = existing.User;
                TbKey.Text = existing.KeyPath;
                TbStartDir.Text = existing.StartDir;
                TbCmd.Text = existing.StartupCmd;
                TbRemark.Text = existing.Remark;
                foreach (ComboBoxItem it in CbAuth.Items)
                    if ((string)it.Tag == existing.AuthType) { CbAuth.SelectedItem = it; break; }
                var pw = HostStore.GetPassword(existing.Id);
                if (pw != null) PbPass.Password = pw;
                var kp = HostStore.GetKeyPassphrase(existing.Id);
                if (kp != null) PbKeyPass.Password = kp;
            }
            UpdateAuthUi();
        }

        private void UpdateAuthUi()
        {
            // 【重要】与 SettingsWindow.SlFont_Changed 同理：
            // CbAuth 声明在 LbPass / PbPass / TbKey 等控件【之前】，
            // 而它的第一项带 IsSelected="True"，加入瞬间就触发 SelectionChanged，
            // 此时后面那些控件尚未创建 —— 必须判空，否则窗口一显示就崩。
            if (LbPass == null || PbPass == null || ChkRemember == null ||
                LbKey == null || TbKey == null ||
                LbKp == null || PbKeyPass == null) return;

            bool isKey = ((ComboBoxItem)CbAuth.SelectedItem)?.Tag as string == "key";
            LbPass.Visibility = isKey ? Visibility.Collapsed : Visibility.Visible;
            PbPass.Visibility = isKey ? Visibility.Collapsed : Visibility.Visible;
            ChkRemember.Visibility = isKey ? Visibility.Collapsed : Visibility.Visible;
            LbKey.Visibility = isKey ? Visibility.Visible : Visibility.Collapsed;
            TbKey.Visibility = isKey ? Visibility.Visible : Visibility.Collapsed;
            LbKp.Visibility = isKey ? Visibility.Visible : Visibility.Collapsed;
            PbKeyPass.Visibility = isKey ? Visibility.Visible : Visibility.Collapsed;
        }

        private void CbAuth_Changed(object sender, SelectionChangedEventArgs e) => UpdateAuthUi();

        private void BrowseKey_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new OpenFileDialog { Filter = "私钥文件|*|所有文件|*.*" };
            if (dlg.ShowDialog() == true) TbKey.Text = dlg.FileName;
        }

        private HostConfig Collect()
        {
            if (string.IsNullOrWhiteSpace(TbHost.Text))
            {
                MessageBox.Show("请填写地址", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                return null;
            }
            if (!int.TryParse(TbPort.Text, out int port) || port < 1 || port > 65535)
            {
                MessageBox.Show("端口需为 1–65535 的数字", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                return null;
            }
            var h = _existing?.Clone() ?? new HostConfig();
            h.Name = TbName.Text.Trim();
            h.Host = TbHost.Text.Trim();
            h.Port = port;
            h.User = TbUser.Text.Trim();
            h.AuthType = ((ComboBoxItem)CbAuth.SelectedItem)?.Tag as string ?? "password";
            h.KeyPath = TbKey.Text.Trim();
            h.StartDir = TbStartDir.Text.Trim();
            h.StartupCmd = TbCmd.Text.Trim();
            h.Remark = TbRemark.Text.Trim();
            return h;
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            var h = Collect();
            if (h == null) return;
            HostStore.Save(h);
            if (h.AuthType == "password")
            {
                var pw = PbPass.Password;
                if (!string.IsNullOrEmpty(pw))
                    HostStore.SetPassword(h.Id, ChkRemember.IsChecked == true ? pw : null);
            }
            else
            {
                var kp = PbKeyPass.Password;
                if (!string.IsNullOrEmpty(kp)) HostStore.SetKeyPassphrase(h.Id, kp);
            }
            Result = h;
            DialogResult = true;
            Close();
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        private async void Test_Click(object sender, RoutedEventArgs e)
        {
            var h = Collect();
            if (h == null) return;
            var pw = PbPass.Password;
            if (string.IsNullOrEmpty(pw) && _existing != null)
                pw = HostStore.GetPassword(_existing.Id);
            var kp = PbKeyPass.Password;
            if (string.IsNullOrEmpty(kp) && _existing != null)
                kp = HostStore.GetKeyPassphrase(_existing.Id);

            var btn = sender as Button;
            btn.IsEnabled = false;
            btn.Content = "测试中…";
            string error = null;
            await Task.Run(() =>
            {
                try
                {
                    using var c = SshConnector.Connect(h, pw, kp);
                    error = null;
                }
                catch (Exception ex) { error = ex.Message; }
            });
            btn.IsEnabled = true;
            btn.Content = "测试连接";
            if (error == null)
                MessageBox.Show("连接成功", "测试连接", MessageBoxButton.OK, MessageBoxImage.Information);
            else
                MessageBox.Show("连接失败：" + error, "测试连接", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }
}
