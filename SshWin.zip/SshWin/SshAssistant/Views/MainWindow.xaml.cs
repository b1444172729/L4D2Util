using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Microsoft.Win32;
using SshAssistant.Data;
using SshAssistant.Models;
using SshAssistant.Ssh;

namespace SshAssistant.Views
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Loaded += (s, e) => { Width = App.Settings.WindowWidth; Height = App.Settings.WindowHeight; Refresh(); };
            Closing += (s, e) =>
            {
                App.Settings.WindowWidth = Width;
                App.Settings.WindowHeight = Height;
                App.SaveSettings();
            };
        }

        private void Refresh()
        {
            var hosts = HostStore.All();
            HostList.ItemsSource = hosts;
            EmptyHint.Visibility = hosts.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new HostEditWindow(null);
            if (dlg.ShowDialog() == true) Refresh();
        }

        private void Edit_Click(object sender, RoutedEventArgs e)
        {
            if ((sender as Button)?.Tag is HostConfig h)
            {
                var dlg = new HostEditWindow(h);
                if (dlg.ShowDialog() == true) Refresh();
            }
        }

        private void Duplicate_Click(object sender, RoutedEventArgs e)
        {
            if ((sender as Button)?.Tag is HostConfig h)
            {
                var copy = h.CopyConfig();
                copy.Name = h.DisplayName + " 副本";
                HostStore.Save(copy);
                // 凭据一起复制，否则副本每次都要重新输密码（与 Android 版一致）
                var pw = HostStore.GetPassword(h.Id);
                var kp = HostStore.GetKeyPassphrase(h.Id);
                if (pw != null) HostStore.SetPassword(copy.Id, pw);
                if (kp != null) HostStore.SetKeyPassphrase(copy.Id, kp);
                Refresh();
            }
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            if ((sender as Button)?.Tag is HostConfig h)
            {
                var r = MessageBox.Show($"确定删除主机「{h.DisplayName}」？", "删除",
                    MessageBoxButton.YesNo, MessageBoxImage.Question);
                if (r != MessageBoxResult.Yes) return;
                SessionRegistry.Close(h.Id);
                HostStore.Delete(h.Id);
                Refresh();
            }
        }

        private void Connect_Click(object sender, RoutedEventArgs e)
        {
            if ((sender as Button)?.Tag is HostConfig h) OpenSession(h);
        }

        private void HostList_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (HostList.SelectedItem is HostConfig h) OpenSession(h);
        }

        private void OpenSession(HostConfig h)
        {
            var win = new SessionWindow(h);
            win.Owner = this;
            win.Show();
        }

        private void Settings_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new SettingsWindow { Owner = this };
            if (dlg.ShowDialog() == true)
            {
                App.ApplyTheme();   // 主题立即生效
                // 已打开的会话窗口同步终端配色
                foreach (Window w in OwnedWindows)
                    if (w is SessionWindow sw) sw.ApplyPrefs();
            }
        }

        private void Transfers_Click(object sender, RoutedEventArgs e)
        {
            var w = Application.Current.Windows.OfType<TransfersWindow>().FirstOrDefault();
            if (w == null) { w = new TransfersWindow { Owner = this }; w.Show(); }
            else w.Activate();
        }

        // ---------- 导入 / 导出（含凭据，与 Android 版一致） ----------

        private void Export_Click(object sender, RoutedEventArgs e)
        {
            var warn = MessageBox.Show(
                "导出的文件将包含登录密码与私钥口令（明文），可直接用于迁移到另一台设备。\n\n" +
                "请勿通过不安全的渠道发送或分享此文件，使用完毕后建议及时删除。",
                "导出配置", MessageBoxButton.OKCancel, MessageBoxImage.Warning);
            if (warn != MessageBoxResult.OK) return;

            var dlg = new SaveFileDialog
            {
                Filter = "JSON 文件|*.json",
                FileName = $"hosts-{DateTime.Now:yyyyMMdd-HHmmss}.json",
                DefaultExt = ".json"
            };
            if (dlg.ShowDialog() != true) return;
            try
            {
                File.WriteAllText(dlg.FileName, HostJson.ExportAll(HostStore.All()));
                MessageBox.Show($"已导出到：\n{dlg.FileName}", "导出成功", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("导出失败：" + ex.Message, "错误", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Import_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new OpenFileDialog { Filter = "JSON 文件|*.json|所有文件|*.*" };
            if (dlg.ShowDialog() != true) return;
            try
            {
                var list = HostJson.ImportAll(File.ReadAllText(dlg.FileName));
                foreach (var h in list)
                {
                    HostStore.Save(h);
                    if (!h.Credentials.IsEmpty)
                    {
                        if (h.Credentials.Password != null) HostStore.SetPassword(h.Id, h.Credentials.Password);
                        if (h.Credentials.KeyPassphrase != null) HostStore.SetKeyPassphrase(h.Id, h.Credentials.KeyPassphrase);
                    }
                }
                Refresh();
                MessageBox.Show($"已导入 {list.Count} 台主机", "导入成功", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("导入失败：" + ex.Message, "错误", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
