using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using SshAssistant.Data;
using SshAssistant.Models;
using SshAssistant.Ssh;
using SshAssistant.Terminal;

namespace SshAssistant.Views
{
    public partial class SessionWindow : Window
    {
        private readonly HostConfig _host;
        private LiveSession _session;

        private string _localDir;
        private string _remoteDir = "/";

        private bool _ctrlArmed;   // Ctrl 修饰键是否待生效
        private Action _contentHandler;
        private TerminalEmulator _lastEmulator;

        public SessionWindow(HostConfig host)
        {
            InitializeComponent();
            _host = host;
            Title = host.DisplayName;
            TitleText.Text = $"{host.DisplayName}  —  {host.User}@{host.Host}:{host.Port}";

            _localDir = LocalFs.Root();

            Loaded += async (s, e) =>
            {
                ApplyPrefs();
                BuildKeyBar();
                await ConnectAsync();
            };
            Closed += (s, e) => { };   // 会话保留在注册表里，供多窗口/重连复用

            // 文件列表右键菜单
            LocalList.ContextMenu = BuildFileMenu(false);
            RemoteList.ContextMenu = BuildFileMenu(true);
        }

        // ==================== 连接 ====================

        private async Task ConnectAsync()
        {
            StateText.Text = "正在连接…";

            // 复用已有会话（多窗口同时打开同一主机时共享）
            var existing = SessionRegistry.Get(_host.Id);
            if (existing != null && existing.IsAlive)
            {
                _session = existing;
                Attach();
                return;
            }

            var pw = HostStore.GetPassword(_host.Id);
            var kp = HostStore.GetKeyPassphrase(_host.Id);

            if (string.IsNullOrEmpty(pw) && _host.AuthType == Models.AuthType.Password)
            {
                var dlg = new PasswordDialog(_host.DisplayName);
                if (dlg.ShowDialog() != true) { StateText.Text = "已取消"; return; }
                pw = dlg.Password;
                if (dlg.Remember) HostStore.SetPassword(_host.Id, pw);
            }

            var s = new LiveSession(_host, 120, 32);
            string error = null;
            await Task.Run(() =>
            {
                try { s.Connect(pw, kp); }
                catch (Exception ex) { error = ex.Message; }
            });

            if (error != null)
            {
                StateText.Text = "连接失败：" + error;
                MessageBox.Show("连接失败：" + error, "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            _session = s;
            SessionRegistry.Put(s);
            Attach();
        }

        /// <summary>
        /// 把键盘焦点交给终端控件。
        /// 【重要】TerminalView 只在鼠标点击时才 Focus()，
        /// 窗口刚打开/从别的标签页切回来时焦点可能在 TabControl 或别处，
        /// 表现就是"连接成功但敲什么都没反应"。
        /// </summary>
        /// <summary>切回"终端"标签时把焦点交还给终端控件</summary>
        private void MainTabs_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // TabControl 切换时 SelectedContent 可能还没更新，延后一拍再聚焦
            if (MainTabs.SelectedIndex == 0) FocusTerminal();
        }

        public void FocusTerminal()
        {
            if (Term == null) return;
            Dispatcher.BeginInvoke(new Action(() =>
            {
                Term.Focus();
                Keyboard.Focus(Term);
            }), System.Windows.Threading.DispatcherPriority.Input);
        }

        private void Attach()
        {
            if (_session == null) return;
            Term.Emulator = _session.Emulator;
            Term.OnUserInput = data =>
            {
                if (_session != null && _session.IsAlive) _session.SendBytes(data);
            };
            _session.OnClosed = () => Dispatcher.Invoke(() => StateText.Text = "已断开");

            // 连接就绪后立刻把焦点交给终端，保证可以直接敲命令
            FocusTerminal();

            // 终端内容变化 → 同步滚动条范围；贴底时始终保持在底部
            // 重连会再次 Attach，必须先解绑上一次的订阅，
            // 否则 handler 累积 → 重复刷新 + 持有旧会话不释放
            if (_contentHandler != null && _lastEmulator != null)
                _lastEmulator.OnContentChanged -= _contentHandler;
            _lastEmulator = _session.Emulator;
            _contentHandler = () => Dispatcher.BeginInvoke(new Action(() =>
            {
                if (TermBar == null) return;
                int max = _session.Emulator.ScrollbackCount;
                if ((int)TermBar.Maximum != max) TermBar.Maximum = max;
                if (Term.ScrollOffset == 0) TermBar.Value = max;
            }));
            _session.Emulator.OnContentChanged += _contentHandler;
            _session.OnTitleChanged = t => Dispatcher.Invoke(() => TitleText.Text = $"{_host.DisplayName}  —  {t}");
            StateText.Text = "已连接";
            RefreshRemote();
        }

        /// <summary>
        /// 滚动条驱动终端回滚。
        /// 值域反转：ScrollBar 顶部=0，而 scrollOffset 是"距底部多少行"（0=贴底）。
        /// 所以 offset = max - value。
        /// </summary>
        private void TermBar_Scroll(object sender, System.Windows.Controls.Primitives.ScrollEventArgs e)
        {
            if (_session == null) return;
            int max = (int)TermBar.Maximum;
            int offset = Math.Clamp(max - (int)TermBar.Value, 0, max);
            Term.ScrollOffset = offset;
        }

        private void Reconnect_Click(object sender, RoutedEventArgs e)
        {
            SessionRegistry.Close(_host.Id);
            _session = null;
            _ = ConnectAsync();
        }

        private void Disconnect_Click(object sender, RoutedEventArgs e)
        {
            SessionRegistry.Close(_host.Id);
            StateText.Text = "已断开";
        }

        public void ApplyPrefs()
        {
            var s = App.Settings;
            Term.FontSizePx = s.FontSize;
            Term.FontFamilyName = "Consolas";
            TerminalEmulator.SetLightTheme(s.Theme == "light" ||
                (s.Theme == "system" && SystemIsLight()));
            if (_session != null) _session.Emulator.ApplyMaxScrollback(s.Scrollback);
            if (KeyBar != null) { KeyBar.Children.Clear(); BuildKeyBar(); }

            // 外层容器底色必须跟随调色板，否则会出现
            // "终端是白的/黑的外面框是黑的白的" 这种黑一块白一块的错乱。
            SyncTermBackground();
        }

        /// <summary>
        /// 让终端外框与终端绘制区用同一个底色（调色板 0 号色）。
        /// 主题切换后必须调用，否则圆角边框与内容区颜色不一致。
        /// </summary>
        private void SyncTermBackground()
        {
            var argb = TerminalEmulator.DefaultBg;
            var c = System.Windows.Media.Color.FromRgb(
                (byte)((argb >> 16) & 0xFF),
                (byte)((argb >> 8) & 0xFF),
                (byte)(argb & 0xFF));
            TermHost.Background = new System.Windows.Media.SolidColorBrush(c);
            Term.InvalidateVisual();
        }

        private static bool SystemIsLight()
        {
            try
            {
                using var k = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(
                    @"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize");
                return k?.GetValue("AppsUseLightTheme") is int i && i == 1;
            }
            catch { return false; }
        }

        private void Shortcuts_Click(object sender, RoutedEventArgs e)
        {
            var cmds = App.Settings.Shortcuts;
            if (cmds == null || cmds.Count == 0)
            {
                MessageBox.Show("还没有快捷命令，可在设置中添加", "快捷命令", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            var dlg = new ShortcutDialog(cmds);
            if (dlg.ShowDialog() == true && _session != null && _session.IsAlive)
                _session.SendText(dlg.Selected + "\n");
        }

        // ==================== 按键栏 ====================

        private void BuildKeyBar()
        {
            if (KeyBar == null) return;
            KeyBar.Children.Clear();
            if (!App.Settings.ShowKeyBar) { KeyBar.Visibility = Visibility.Collapsed; return; }
            KeyBar.Visibility = Visibility.Visible;

            foreach (var id in SshAssistant.Data.KeyBar.Order())
            {
                var def = SshAssistant.Data.KeyBar.Def(id);
                if (def == null) continue;
                var b = new Button
                {
                    Content = def.Label,
                    Style = (Style)FindResource("OutlineButton"),
                    MinWidth = 46,
                    MinHeight = 34,
                    Padding = new Thickness(10, 4, 10, 4),
                    Margin = new Thickness(3),
                    Tag = def
                };
                b.Click += KeyButton_Click;
                KeyBar.Children.Add(b);
            }
        }

        private void KeyButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button b && b.Tag is KeyDef def)
            {
                if (def.Id == "copy")
                {
                    var text = Term.GetSelectedText();
                    if (!string.IsNullOrEmpty(text)) Clipboard.SetText(text);
                    return;
                }
                if (def.Id == "paste")
                {
                    if (Clipboard.ContainsText())
                        _session?.SendBytes(Encoding.UTF8.GetBytes(Clipboard.GetText()));
                    return;
                }
                if (def.Id == "clear")
                {
                    _session?.Emulator.ClearScreen();
                    return;
                }
                if (def.IsModifier)
                {
                    // Ctrl：下一次按键前发送控制码
                    _ctrlArmed = true;
                    b.Background = (System.Windows.Media.Brush)FindResource("PrimaryBrush");
                    return;
                }
                var data = def.Bytes;
                if (_ctrlArmed && data.Length == 1)
                {
                    char c = (char)data[0];
                    if (char.IsLetter(c))
                    {
                        data = new byte[] { (byte)(char.ToLower(c) - 'a' + 1) };
                    }
                    _ctrlArmed = false;
                    BuildKeyBar();
                }
                _session?.SendBytes(data);
                Term.Focus();
            }
        }

        // ==================== 文件管理（本地） ====================

        // ==================== 目录刷新（异步） ====================
        //
        // 【性能/卡顿】原来这两个方法直接在 UI 线程里做枚举：
        //   · 本地：遍历 + 逐项 stat（大目录/网络盘会卡住窗口）
        //   · 远程：SFTP 的 ListDirectory 是一次完整的网络往返
        // 同步执行时整个窗口会冻结到枚举结束，表现就是
        // "点了半天才出列表"。改成后台枚举 + 回到 UI 线程赋值，
        // 窗口始终可操作，并且切换目录时会取消上一次未完成的枚举。

        private System.Threading.CancellationTokenSource _localCts;
        private System.Threading.CancellationTokenSource _remoteCts;

        private async void RefreshLocal()
        {
            var dir = _localDir;
            var showHidden = App.Settings.ShowHidden;

            _localCts?.Cancel();
            var cts = new System.Threading.CancellationTokenSource();
            _localCts = cts;

            try
            {
                LocalList.ItemsSource = null;
                var items = await System.Threading.Tasks.Task.Run(
                    () => LocalFs.List(dir, showHidden), cts.Token);
                if (cts.IsCancellationRequested) return;
                LocalList.ItemsSource = items;
            }
            catch (System.OperationCanceledException) { }
            catch { }
        }

        private async void RefreshRemote()
        {
            if (_session == null || !_session.IsAlive) return;

            var dir = _remoteDir;
            var showHidden = App.Settings.ShowHidden;
            var sess = _session;

            _remoteCts?.Cancel();
            var cts = new System.Threading.CancellationTokenSource();
            _remoteCts = cts;

            try
            {
                RemoteList.ItemsSource = null;
                var items = await System.Threading.Tasks.Task.Run(
                    () => RemoteFs.List(sess, dir, showHidden), cts.Token);
                if (cts.IsCancellationRequested) return;
                RemoteList.ItemsSource = items;
            }
            catch (System.OperationCanceledException) { }
            catch { }
        }

        private void LocalHome_Click(object s, RoutedEventArgs e) { _localDir = LocalFs.Root(); RefreshLocal(); }
        private void LocalUp_Click(object s, RoutedEventArgs e) { _localDir = LocalFs.Parent(_localDir); RefreshLocal(); }
        private void LocalRefresh_Click(object s, RoutedEventArgs e) => RefreshLocal();
        private void RemoteHome_Click(object s, RoutedEventArgs e) { _remoteDir = "/"; RefreshRemote(); }
        private void RemoteUp_Click(object s, RoutedEventArgs e) { _remoteDir = RemoteFs.Parent(_remoteDir); RefreshRemote(); }
        private void RemoteRefresh_Click(object s, RoutedEventArgs e) => RefreshRemote();

        private void LocalList_DoubleClick(object s, MouseButtonEventArgs e)
        {
            if (LocalList.SelectedItem is FileItem it && it.IsDir)
            { _localDir = it.Path; RefreshLocal(); }
        }

        private void RemoteList_DoubleClick(object s, MouseButtonEventArgs e)
        {
            if (RemoteList.SelectedItem is FileItem it && it.IsDir)
            { _remoteDir = it.Path; RefreshRemote(); }
        }

        private void LocalMenu_Click(object s, RoutedEventArgs e) =>
            ShowPaneMenu(false, s as Button);

        private void RemoteMenu_Click(object s, RoutedEventArgs e) =>
            ShowPaneMenu(true, s as Button);

        private void ShowPaneMenu(bool remote, Button anchor)
        {
            var m = new ContextMenu();
            AddItem(m, "新建文件", (_, __) => NewFile(remote));
            AddItem(m, "新建文件夹", (_, __) => NewFolder(remote));
            m.Items.Add(new Separator());
            AddItem(m, "粘贴", (_, __) => PasteHere(remote));
            AddItem(m, "全选", (_, __) => { (remote ? RemoteList : LocalList).SelectAll(); });
            AddItem(m, "取消选择", (_, __) => { (remote ? RemoteList : LocalList).UnselectAll(); });
            m.Items.Add(new Separator());
            AddItem(m, "显示隐藏文件", (_, __) =>
            {
                App.Settings.ShowHidden = !App.Settings.ShowHidden;
                App.SaveSettings();
                RefreshLocal(); RefreshRemote();
            });
            m.IsOpen = true;
            if (anchor != null) m.PlacementTarget = anchor;
        }

        private static void AddItem(ContextMenu m, string header, RoutedEventHandler h)
        {
            var mi = new MenuItem { Header = header };
            mi.Click += h;
            m.Items.Add(mi);
        }

        /// <summary>文件/文件夹右键菜单（与 Android 版 long-press 菜单一致）</summary>
        private ContextMenu BuildFileMenu(bool remote)
        {
            var m = new ContextMenu();
            AddItem(m, "打开", (_, __) => OpenSelected(remote));
            AddItem(m, "编辑", (_, __) => EditSelected(remote));
            m.Items.Add(new Separator());
            AddItem(m, "复制", (_, __) => CopySelected(remote, false));
            AddItem(m, "移动", (_, __) => CopySelected(remote, true));
            AddItem(m, "重命名", (_, __) => RenameSelected(remote));
            AddItem(m, "删除", (_, __) => DeleteSelected(remote));
            AddItem(m, "权限", (_, __) => ChangePermissions(remote));
            AddItem(m, "属性", (_, __) => ShowProperties(remote));
            m.Items.Add(new Separator());
            AddItem(m, "上传", (_, __) => Upload_Click(null, null));
            AddItem(m, "下载", (_, __) => Download_Click(null, null));
            return m;
        }

        private List<FileItem> Selected(bool remote) =>
            (remote ? RemoteList : LocalList).SelectedItems.Cast<FileItem>().ToList();

        private void OpenSelected(bool remote)
        {
            var list = Selected(remote);
            if (list.Count != 1) return;
            var it = list[0];
            if (it.IsDir)
            {
                if (remote) { _remoteDir = it.Path; RefreshRemote(); }
                else { _localDir = it.Path; RefreshLocal(); }
            }
            else if (!remote)
            {
                try { System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(it.Path) { UseShellExecute = true }); }
                catch { }
            }
        }

        private void EditSelected(bool remote)
        {
            var list = Selected(remote);
            if (list.Count == 0) return;
            var w = new EditorWindow(_session, list[0].Path, remote) { Owner = this };
            w.Show();
        }

        private void CopySelected(bool remote, bool move)
        {
            var list = Selected(remote);
            if (list.Count == 0) return;
            PaneClipboard.Set(list, move);
        }

        private void PasteHere(bool remote)
        {
            var entries = PaneClipboard.Entries;
            if (entries.Count == 0) { MessageBox.Show("剪贴板为空", "提示"); return; }
            string dest = remote ? _remoteDir : _localDir;
            try
            {
                foreach (var e in entries)
                {
                    var target = remote ? RemoteFs.Join(dest, e.Name) : LocalFs.Join(dest, e.Name);
                    if (e.Remote == remote)
                    {
                        if (remote) RemoteFs.CopyOrMove(_session, e.Path, target, e.Cut);
                        else LocalFs.CopyOrMove(e.Path, target, e.Cut);
                    }
                }
                PaneClipboard.Clear();
                RefreshLocal(); RefreshRemote();
            }
            catch (Exception ex) { MessageBox.Show("操作失败：" + ex.Message, "错误"); }
        }

        private void RenameSelected(bool remote)
        {
            var list = Selected(remote);
            if (list.Count != 1) return;
            var it = list[0];
            var dlg = new InputDialog("重命名", it.Name);
            if (dlg.ShowDialog() != true) return;
            try
            {
                string newPath = remote
                    ? RemoteFs.Join(RemoteFs.Parent(it.Path), dlg.Value)
                    : LocalFs.Join(LocalFs.Parent(it.Path), dlg.Value);
                if (remote) RemoteFs.Rename(_session, it.Path, newPath);
                else LocalFs.Rename(it.Path, newPath);
                RefreshLocal(); RefreshRemote();
            }
            catch (Exception ex) { MessageBox.Show("重命名失败：" + ex.Message, "错误"); }
        }

        private void DeleteSelected(bool remote)
        {
            var list = Selected(remote);
            if (list.Count == 0) return;
            var r = MessageBox.Show($"确定删除选中的 {list.Count} 项？", "删除",
                MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (r != MessageBoxResult.Yes) return;
            try
            {
                foreach (var it in list)
                {
                    if (remote) RemoteFs.Delete(_session, it.Path, it.IsDir);
                    else LocalFs.Delete(it.Path, it.IsDir);
                }
                RefreshLocal(); RefreshRemote();
            }
            catch (Exception ex) { MessageBox.Show("删除失败：" + ex.Message, "错误"); }
        }

        private void ChangePermissions(bool remote)
        {
            var list = Selected(remote);
            if (list.Count == 0) return;
            int current = remote
                ? RemoteFs.Permissions(_session, list[0].Path)
                : LocalFs.Permissions(list[0].Path);
            var dlg = new PermissionsDialog(current) { Owner = this };
            if (dlg.ShowDialog() != true) return;
            try
            {
                foreach (var it in list)
                {
                    if (remote) RemoteFs.Chmod(_session, it.Path, dlg.Value);
                    else LocalFs.Chmod(it.Path, dlg.Value);
                }
                RefreshLocal(); RefreshRemote();
            }
            catch (Exception ex) { MessageBox.Show("修改权限失败：" + ex.Message, "错误"); }
        }

        private void ShowProperties(bool remote)
        {
            var list = Selected(remote);
            if (list.Count == 0) return;
            var it = list[0];
            var sb = new StringBuilder();
            sb.AppendLine("名称：" + it.Name);
            sb.AppendLine("路径：" + it.Path);
            sb.AppendLine("类型：" + (it.IsDir ? "文件夹" : "文件"));
            if (!it.IsDir) sb.AppendLine("大小：" + FileItem.FormatSize(it.Size));
            sb.AppendLine("修改时间：" + it.TimeText);
            MessageBox.Show(sb.ToString(), "属性", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void NewFile(bool remote)
        {
            var dlg = new InputDialog("新建文件", "newfile.txt");
            if (dlg.ShowDialog() != true) return;
            try
            {
                var path = remote ? RemoteFs.Join(_remoteDir, dlg.Value) : LocalFs.Join(_localDir, dlg.Value);
                if (remote) RemoteFs.WriteText(_session, path, "");
                else LocalFs.WriteText(path, "");
                RefreshLocal(); RefreshRemote();
            }
            catch (Exception ex) { MessageBox.Show("创建失败：" + ex.Message, "错误"); }
        }

        private void NewFolder(bool remote)
        {
            var dlg = new InputDialog("新建文件夹", "新文件夹");
            if (dlg.ShowDialog() != true) return;
            try
            {
                var path = remote ? RemoteFs.Join(_remoteDir, dlg.Value) : LocalFs.Join(_localDir, dlg.Value);
                if (remote) RemoteFs.MakeDir(_session, path);
                else LocalFs.MakeDir(path);
                RefreshLocal(); RefreshRemote();
            }
            catch (Exception ex) { MessageBox.Show("创建失败：" + ex.Message, "错误"); }
        }

        // ==================== 上传 / 下载 ====================

        private void Upload_Click(object sender, RoutedEventArgs e)
        {
            var list = Selected(false);
            if (list.Count == 0) { MessageBox.Show("请先在左侧选中要上传的文件"); return; }
            foreach (var it in list)
            {
                var dest = RemoteFs.Join(_remoteDir, it.Name);
                if (RemoteFs.Exists(_session, dest) && !ConfirmConflict(dest)) continue;
                TransferService.Add(new TransferTask
                {
                    Kind = TransferKind.Upload,
                    HostId = _host.Id,
                    Source = it.Path,
                    Dest = dest
                });
            }
            OpenTransfers();
        }

        // ==================== 拖拽上传 ====================

        private void RemoteList_DragEnter(object sender, DragEventArgs e)
        {
            // 只接受文件拖拽；未连接时明确拒绝并给出光标提示
            bool ok = e.Data.GetDataPresent(DataFormats.FileDrop) && _session != null && _session.IsAlive;
            e.Effects = ok ? DragDropEffects.Copy : DragDropEffects.None;
            e.Handled = true;
        }

        private void RemoteList_DragOver(object sender, DragEventArgs e)
        {
            bool ok = e.Data.GetDataPresent(DataFormats.FileDrop) && _session != null && _session.IsAlive;
            e.Effects = ok ? DragDropEffects.Copy : DragDropEffects.None;
            e.Handled = true;
        }

        private void RemoteList_DragLeave(object sender, DragEventArgs e)
        {
            e.Handled = true;
        }

        private async void RemoteList_Drop(object sender, DragEventArgs e)
        {
            e.Handled = true;

            if (!e.Data.GetDataPresent(DataFormats.FileDrop)) return;
            var paths = e.Data.GetData(DataFormats.FileDrop) as string[];
            if (paths == null || paths.Length == 0) return;

            if (_session == null || !_session.IsAlive)
            {
                MessageBox.Show("尚未连接，无法上传", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            int added = 0;
            foreach (var p in paths)
            {
                // 目录也支持：递归上传目录下的文件（保留相对结构）
                if (Directory.Exists(p))
                {
                    var rootName = new DirectoryInfo(p).Name;
                    foreach (var f in Directory.EnumerateFiles(p, "*", SearchOption.AllDirectories))
                    {
                        var rel = Path.GetRelativePath(p, f);
                        var dest = RemoteFs.Join(RemoteFs.Join(_remoteDir, rootName), rel.Replace('\\', '/'));
                        QueueUpload(f, dest);
                        added++;
                    }
                }
                else if (File.Exists(p))
                {
                    var dest = RemoteFs.Join(_remoteDir, Path.GetFileName(p));
                    QueueUpload(p, dest);
                    added++;
                }
            }

            if (added == 0) return;
            OpenTransfers();
            // 远端目录稍后刷新，让上传出来的文件可见
            await Task.Delay(600);
            RefreshRemote();
        }

        /// <summary>入队一个上传任务（拖拽与按钮两条路径共用）</summary>
        private void QueueUpload(string localPath, string dest)
        {
            TransferService.Add(new TransferTask
            {
                Kind = TransferKind.Upload,
                HostId = _host.Id,
                Source = localPath,
                Dest = dest
            });
        }

        private void Download_Click(object sender, RoutedEventArgs e)
        {
            var list = Selected(true);
            if (list.Count == 0) { MessageBox.Show("请先在右侧选中要下载的文件"); return; }
            foreach (var it in list)
            {
                var dest = LocalFs.Join(_localDir, it.Name);
                if (LocalFs.Exists(dest) && !ConfirmConflict(dest)) continue;
                TransferService.Add(new TransferTask
                {
                    Kind = TransferKind.Download,
                    HostId = _host.Id,
                    Source = it.Path,
                    Dest = dest
                });
            }
            OpenTransfers();
        }

        private bool ConfirmConflict(string dest)
        {
            var s = App.Settings.Conflict;
            if (s == "overwrite") return true;
            if (s == "skip") return false;
            if (s == "resume") return true;   // 续传：由传输层按 offset 处理
            var r = MessageBox.Show($"目标已存在：\n{dest}\n\n是否覆盖？", "冲突",
                MessageBoxButton.YesNo, MessageBoxImage.Question);
            return r == MessageBoxResult.Yes;
        }

        private void OpenTransfers()
        {
            var w = Application.Current.Windows.OfType<TransfersWindow>().FirstOrDefault();
            if (w == null) { w = new TransfersWindow { Owner = this }; w.Show(); }
            else w.Activate();
        }

        // ==================== 端口转发 ====================

        private void RefreshForwards()
        {
            var rules = PortForwardStore.Load().Where(r => r.HostId == _host.Id).ToList();
            var view = rules.Select(r => new ForwardView(r, _session)).ToList();
            ForwardList.ItemsSource = view;
        }

        private void AddForward_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new ForwardDialog { Owner = this };
            if (dlg.ShowDialog() != true) return;
            var rules = PortForwardStore.Load();
            var rule = new PortForwardRule
            {
                HostId = _host.Id,
                LocalPort = dlg.LocalPort,
                RemoteHost = dlg.RemoteHost,
                RemotePort = dlg.RemotePort
            };
            rules.Add(rule);
            PortForwardStore.Save(rules);
            RefreshForwards();
            try { _session?.StartForward(rule); RefreshForwards(); }
            catch (Exception ex) { MessageBox.Show("启动失败：" + ex.Message, "错误"); }
        }

        private void StartForward_Click(object sender, RoutedEventArgs e)
        {
            if (ForwardList.SelectedItem is ForwardView v)
            {
                try { _session?.StartForward(v.Rule); }
                catch (Exception ex) { MessageBox.Show("启动失败：" + ex.Message, "错误"); }
                RefreshForwards();
            }
        }

        private void StopForward_Click(object sender, RoutedEventArgs e)
        {
            if (ForwardList.SelectedItem is ForwardView v)
            {
                _session?.StopForward(v.Rule);
                RefreshForwards();
            }
        }

        private void DeleteForward_Click(object sender, RoutedEventArgs e)
        {
            if (ForwardList.SelectedItem is ForwardView v)
            {
                _session?.StopForward(v.Rule);
                var rules = PortForwardStore.Load();
                rules.RemoveAll(r => r.Id == v.Rule.Id);
                PortForwardStore.Save(rules);
                RefreshForwards();
            }
        }
    }

    public class ForwardView
    {
        public PortForwardRule Rule { get; }
        private readonly LiveSession _s;
        public ForwardView(PortForwardRule r, LiveSession s) { Rule = r; _s = s; }
        public string Text => Rule.Text;
        public string StatusText => (_s != null && _s.IsForwardRunning(Rule)) ? "● 运行中" : "○ 已停止";
    }
}
