using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Threading;
using Renci.SshNet;
using Renci.SshNet.Common;
using SshAssistant.Data;
using SshAssistant.Models;

namespace SshAssistant.Ssh
{
    /// <summary>主机密钥信任请求（TOFU）</summary>
    public class TrustRequest
    {
        public string Host;
        public int Port;
        public string Fingerprint;
        public Action<bool, bool> Reply;   // (trustOnce, alwaysTrust)
    }

    /// <summary>
    /// SSH 连接建立。对应 Android 版的 ssh/SshConnector.kt。
    /// 使用 SSH.NET，认证方式、超时、压缩开关与 Android 版一一对应。
    /// </summary>
    public static class SshConnector
    {
        public static Action<TrustRequest> TrustPrompt;

        /// <summary>计算公钥指纹（SHA256:base64，与 OpenSSH 新版显示一致）</summary>
        public static string Fingerprint(string host, int port, string keyBase64)
        {
            try
            {
                var bytes = Convert.FromBase64String(keyBase64);
                using var sha = SHA256.Create();
                var hash = sha.ComputeHash(bytes);
                return "SHA256:" + Convert.ToBase64String(hash).TrimEnd('=');
            }
            catch
            {
                return "SHA256:unknown";
            }
        }

        /// <summary>
        /// 建立连接。返回的 SshClient 由调用方负责释放。
        /// </summary>
        public static SshClient Connect(HostConfig host, string password, string keyPassphrase)
        {
            ConnectionInfo ci;

            if (host.AuthType == Models.AuthType.Key && !string.IsNullOrWhiteSpace(host.KeyPath))
            {
                PrivateKeyFile key;
                try
                {
                    if (string.IsNullOrEmpty(keyPassphrase))
                        key = new PrivateKeyFile(host.KeyPath);
                    else
                        key = new PrivateKeyFile(host.KeyPath, keyPassphrase);
                }
                catch (Exception e)
                {
                    throw new IOException("无法加载私钥：" + e.Message, e);
                }
                ci = new ConnectionInfo(host.Host, host.Port, host.User,
                    new PrivateKeyAuthenticationMethod(host.User, key));
            }
            else
            {
                ci = new ConnectionInfo(host.Host, host.Port, host.User,
                    new PasswordAuthenticationMethod(host.User, password ?? ""));
            }

            ci.Timeout = TimeSpan.FromSeconds(15);
            ci.RetryAttempts = 1;

            var client = new SshClient(ci);

            // 主机密钥校验：已知则比对，未知则询问用户（TOFU）
            client.HostKeyReceived += (sender, e) =>
            {
                var fp = Fingerprint(host.Host, host.Port, Convert.ToBase64String(e.HostKey));
                var known = HostStore.GetFingerprint(host.Host, host.Port);

                if (known == null)
                {
                    bool trustOnce = false, always = false;
                    using var done = new ManualResetEventSlim(false);
                    var req = new TrustRequest
                    {
                        Host = host.Host,
                        Port = host.Port,
                        Fingerprint = fp,
                        Reply = (once, alw) => { trustOnce = once; always = alw; done.Set(); }
                    };
                    TrustPrompt?.Invoke(req);
                    if (TrustPrompt == null) { e.CanTrust = false; return; }
                    done.Wait(TimeSpan.FromMinutes(2));
                    if (always) HostStore.TrustFingerprint(host.Host, host.Port, fp);
                    e.CanTrust = trustOnce || always;
                }
                else
                {
                    e.CanTrust = (known == fp);
                    if (!e.CanTrust)
                        throw new SshConnectionException("主机密钥与已保存的不一致，可能遭遇中间人攻击",
                            DisconnectReason.HostKeyNotVerifiable);
                }
            };

            try
            {
                client.Connect();
            }
            catch (SshAuthenticationException e)
            {
                client.Dispose();
                throw new IOException("认证失败：" + e.Message, e);
            }
            catch (SshConnectionException e)
            {
                client.Dispose();
                throw new IOException("无法连接：" + e.Message, e);
            }
            catch (Exception e)
            {
                client.Dispose();
                throw new IOException("连接失败：" + e.Message, e);
            }

            return client;
        }
    }
}
