using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading;
using Renci.SshNet;
using SshAssistant.Data;
using SshAssistant.Models;
using SshAssistant.Terminal;

namespace SshAssistant.Ssh
{
    public enum ConnState { Idle, Connecting, Connected, Closed }

    /// <summary>
    /// 一个活跃会话：SSH 连接 + shell 流 + 终端模拟器 + SFTP + 端口转发。
    /// 对应 Android 版的 ssh/SessionRegistry.kt（LiveSession）。
    /// </summary>
    public class LiveSession : IDisposable
    {
        public string HostId { get; }
        public HostConfig Config { get; }
        public ConnState State { get; private set; } = ConnState.Idle;
        public string LastError { get; private set; }

        public TerminalEmulator Emulator { get; }
        public ShellStream Shell { get; private set; }
        public SshClient Client { get; private set; }
        public SftpClient Sftp { get; private set; }

        private readonly List<ForwardedPortLocalEx> _forwards = new List<ForwardedPortLocalEx>();
        private Thread _reader;
        private CancellationTokenSource _cts = new CancellationTokenSource();
        private bool _shellEnded;

        public Action<LiveSession> OnStateChanged;
        public Action OnClosed;
        public Action<string> OnTitleChanged;

        public bool IsAlive => State == ConnState.Connected && Client != null && Client.IsConnected;

        /// <summary>shell 结束不代表 SSH 断开（shell 是独立 channel）</summary>
        public bool ShellEnded => _shellEnded;

        public LiveSession(HostConfig config, int cols, int rows)
        {
            Config = config;
            HostId = config.Id;
            Emulator = new TerminalEmulator(cols, rows, AppSettings.Load().Scrollback);
            Emulator.OnTitleChanged = t => OnTitleChanged?.Invoke(t);
        }

        public void Connect(string password, string keyPassphrase)
        {
            if (State == ConnState.Connecting || State == ConnState.Connected) return;
            State = ConnState.Connecting;
            OnStateChanged?.Invoke(this);

            var settings = AppSettings.Load();

            try
            {
                Client = SshConnector.Connect(Config, password, keyPassphrase);

                // keepalive：与 Android 版一致，按设置间隔发送
                if (settings.Keepalive > 0)
                    Client.KeepAliveInterval = TimeSpan.FromSeconds(settings.Keepalive);

                // 压缩：SSH.NET 的 ConnectionInfo 未提供压缩开关，
                // 因此 Windows 版此项无法生效（Android 版可生效）。
                // 设置界面已将该项置灰并标注，避免用户以为没生效。

                var termType = string.IsNullOrWhiteSpace(settings.TermType) ? "xterm-256color" : settings.TermType;
                Shell = Client.CreateShellStream(termType, (uint)Emulator.Cols, (uint)Emulator.Rows, 0, 0, 4096);

                Sftp = new SftpClient(Client.ConnectionInfo);
                Sftp.Connect();

                State = ConnState.Connected;
                OnStateChanged?.Invoke(this);

                StartReader();

                if (!string.IsNullOrWhiteSpace(Config.StartupCmd))
                {
                    SendText(Config.StartupCmd + "\n");
                }
            }
            catch (Exception e)
            {
                LastError = e.Message;
                State = ConnState.Closed;
                Cleanup();
                OnStateChanged?.Invoke(this);
                throw;
            }
        }

        private void StartReader()
        {
            _reader = new Thread(() =>
            {
                var buf = new byte[8192];
                try
                {
                    while (!_cts.IsCancellationRequested)
                    {
                        int n = Shell.Read(buf, 0, buf.Length);
                        if (n <= 0) break;
                        Emulator.Write(buf, n);
                    }
                }
                catch { }
                finally
                {
                    // shell 结束只标记，不把整个连接判死 —— SFTP 在同一连接上仍可用
                    _shellEnded = true;
                }
            })
            { IsBackground = true, Name = "ssh-reader-" + HostId };
            _reader.Start();
        }

        public void SendText(string text)
        {
            SendBytes(Encoding.UTF8.GetBytes(text));
        }

        public void SendBytes(byte[] data)
        {
            try
            {
                if (Shell != null && Shell.CanWrite)
                {
                    Shell.Write(data, 0, data.Length);
                    Shell.Flush();
                }
            }
            catch (Exception e)
            {
                LastError = e.Message;
            }
        }

        public void Resize(int cols, int rows)
        {
            try { Shell?.ChangeWindowSize((uint)cols, (uint)rows); } catch { }
            Emulator.Resize(cols, rows);
        }

        // ---------- 端口转发 ----------
        public void StartForward(PortForwardRule rule)
        {
            EnsureClient();
            var p = new ForwardedPortLocalEx("127.0.0.1", (uint)rule.LocalPort, rule.RemoteHost, (uint)rule.RemotePort);
            Client.AddForwardedPort(p);
            p.Start();
            lock (_forwards) _forwards.Add(p);
        }

        public void StopForward(PortForwardRule rule)
        {
            lock (_forwards)
            {
                foreach (var p in _forwards)
                {
                    if (p.LocalPort == rule.LocalPort && p.RemoteHost == rule.RemoteHost && p.RemotePort == rule.RemotePort)
                    {
                        try { p.Stop(); Client?.RemoveForwardedPort(p); } catch { }
                        _forwards.Remove(p);
                        break;
                    }
                }
            }
        }

        public bool IsForwardRunning(PortForwardRule rule)
        {
            lock (_forwards)
            {
                foreach (var p in _forwards)
                    if (p.LocalPort == rule.LocalPort && p.RemoteHost == rule.RemoteHost && p.RemotePort == rule.RemotePort)
                        return p.IsStarted;
            }
            return false;
        }

        private void EnsureClient()
        {
            if (Client == null || !Client.IsConnected) throw new IOException("会话未连接");
        }

        public void Close()
        {
            try { _cts?.Cancel(); } catch { }
            State = ConnState.Closed;
            Cleanup();
            OnStateChanged?.Invoke(this);
            OnClosed?.Invoke();
        }

        private void Cleanup()
        {
            try { Sftp?.Disconnect(); } catch { }
            try { Sftp?.Dispose(); } catch { }
            try { Shell?.Dispose(); } catch { }
            try
            {
                if (Client != null)
                {
                    lock (_forwards)
                    {
                        foreach (var p in _forwards) { try { p.Stop(); } catch { } }
                        _forwards.Clear();
                    }
                    Client.Disconnect();
                    Client.Dispose();
                }
            }
            catch { }
            Shell = null; Sftp = null; Client = null;
        }

        public void Dispose() => Close();
    }

    /// <summary>扩展转发端口，便于记录本地/远端端口</summary>
    public class ForwardedPortLocalEx : ForwardedPortLocal
    {
        public int LocalPort => (int)BoundPort;
        public string RemoteHost { get; }
        public int RemotePort { get; }

        public ForwardedPortLocalEx(string bind, uint localPort, string remoteHost, uint remotePort)
            : base(bind, localPort, remoteHost, remotePort)
        {
            RemoteHost = remoteHost;
            RemotePort = (int)remotePort;
        }
    }

    /// <summary>会话注册表：按 hostId 复用会话</summary>
    public static class SessionRegistry
    {
        private static readonly ConcurrentDictionary<string, LiveSession> Map = new();

        public static LiveSession Get(string hostId) => Map.TryGetValue(hostId, out var s) ? s : null;

        public static LiveSession GetOrCreate(HostConfig config, int cols = 80, int rows = 24)
        {
            var s = Get(config.Id);
            if (s != null && s.IsAlive) return s;
            s = new LiveSession(config, cols, rows);
            Map[config.Id] = s;
            return s;
        }

        /// <summary>注册/替换会话（供 SessionWindow 建立连接后登记）</summary>
        public static void Put(LiveSession s)
        {
            Map[s.HostId] = s;
        }

        public static void Close(string hostId)
        {
            if (Map.TryRemove(hostId, out var s)) s.Close();
        }

        public static IEnumerable<LiveSession> All() => Map.Values;

        public static void CloseAll()
        {
            foreach (var s in Map.Values) { try { s.Close(); } catch { } }
            Map.Clear();
        }
    }
}
