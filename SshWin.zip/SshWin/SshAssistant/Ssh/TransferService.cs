using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Renci.SshNet;
using SshAssistant.Data;
using SshAssistant.Models;

namespace SshAssistant.Ssh
{
    public enum TransferKind { Upload, Download }
    public enum TaskState { Pending, Running, Paused, Done, Failed, Canceled }

    public class TransferTask : System.ComponentModel.INotifyPropertyChanged
    {
        public string Id { get; set; } = Guid.NewGuid().ToString("N");
        public TransferKind Kind { get; set; }
        public string HostId { get; set; } = "";
        public string Source { get; set; }
        public string Dest { get; set; }
        public long Total { get; set; }
        public long Done { get; set; }
        public TaskState State { get; set; } = TaskState.Pending;
        public string Error { get; set; }

        public double Percent => Total > 0 ? Math.Min(100.0, Done * 100.0 / Total) : 0;
        public string Name => Path.GetFileName(Kind == TransferKind.Upload ? Source : Dest);

        public CancellationTokenSource Cts { get; set; } = new CancellationTokenSource();
        public bool Paused { get; set; }
        public ManualResetEventSlim Gate { get; set; } = new ManualResetEventSlim(true);

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;
        public void Notify()
        {
            PropertyChanged?.Invoke(this, new System.ComponentModel.PropertyChangedEventArgs(null));
        }
    }

    /// <summary>
    /// 传输服务：上传/下载、冲突策略、断点续传、并发队列。
    /// 对应 Android 版的 ssh/TransferService.kt + TransferPlanner.kt。
    /// </summary>
    public static class TransferService
    {
        private static readonly List<TransferTask> Tasks = new List<TransferTask>();
        private static readonly SemaphoreSlim Sem = new SemaphoreSlim(2, 2);   // 最多 2 个并发

        public static event Action Changed;

        public static List<TransferTask> All()
        {
            lock (Tasks) return Tasks.ToList();
        }

        public static void Add(TransferTask t)
        {
            lock (Tasks) Tasks.Add(t);
            Changed?.Invoke();
            _ = Task.Run(() => RunAsync(t));
        }

        private static async Task RunAsync(TransferTask t)
        {
            await Sem.WaitAsync();
            try
            {
                t.State = TaskState.Running;
                t.Notify(); Changed?.Invoke();

                var session = SessionRegistry.Get(t.HostId);
                if (session == null || !session.IsAlive || session.Sftp == null || !session.Sftp.IsConnected)
                {
                    t.State = TaskState.Failed;
                    t.Error = "会话未连接";
                    t.Notify(); Changed?.Invoke();
                    return;
                }

                t.Total = t.Kind == TransferKind.Upload ? LocalFs.SizeOf(t.Source) : RemoteFs.SizeOf(session, t.Source);
                long offset = 0;

                // 断点续传：目标已存在且长度小于源时从断点继续
                try
                {
                    long destSize = t.Kind == TransferKind.Upload
                        ? RemoteFs.SizeOf(session, t.Dest)
                        : LocalFs.SizeOf(t.Dest);
                    if (destSize > 0 && destSize < t.Total) offset = destSize;
                }
                catch { }

                t.Done = offset;

                var progress = new Action<ulong>(u =>
                {
                    t.Done = offset + (long)u;
                    t.Notify(); Changed?.Invoke();
                    t.Gate.Wait();   // 暂停门
                });

                if (t.Kind == TransferKind.Upload)
                {
                    using var fs = new FileStream(t.Source, FileMode.Open, FileAccess.Read, FileShare.Read);
                    if (offset > 0)
                    {
                        // 真正的断点续传：SSH.NET 的 UploadFile 不支持起始 offset
                        // （第三参数只是 canOverride），所以改用 SftpFileStream：
                        // 打开远端文件并 Seek 到断点，再写剩余部分。
                        // 注意不能用 FileMode.Append —— 追加模式会忽略 Seek 写到末尾，
                        // 与 offset 语义冲突，会写错位置且照样报成功。
                        fs.Seek(offset, SeekOrigin.Begin);
                        using var ws = session.Sftp.Open(t.Dest, FileMode.OpenOrCreate, FileAccess.Write);
                        ws.Seek(offset, SeekOrigin.Begin);
                        var buf = new byte[64 * 1024];
                        int read;
                        while ((read = fs.Read(buf, 0, buf.Length)) > 0)
                        {
                            t.Cts.Token.ThrowIfCancellationRequested();
                            t.Gate.Wait();
                            ws.Write(buf, 0, read);
                            progress((ulong)read);
                        }
                        ws.SetLength(offset + (fs.Length - offset));
                    }
                    else
                    {
                        await Task.Run(() =>
                            session.Sftp.UploadFile(fs, t.Dest, true, progress));
                    }
                }
                else
                {
                    var dir = Path.GetDirectoryName(t.Dest);
                    if (!string.IsNullOrEmpty(dir)) Directory.CreateDirectory(dir);
                    using var fs = new FileStream(t.Dest, offset > 0 ? FileMode.Append : FileMode.Create, FileAccess.Write);
                    await Task.Run(() =>
                        session.Sftp.DownloadFile(t.Source, fs, progress));
                }

                t.Done = t.Total;
                t.State = TaskState.Done;
            }
            catch (OperationCanceledException)
            {
                t.State = TaskState.Canceled;
            }
            catch (Exception e)
            {
                t.State = TaskState.Failed;
                t.Error = e.Message;
            }
            finally
            {
                Sem.Release();
                t.Notify(); Changed?.Invoke();
            }
        }

        public static void Pause(TransferTask t)
        {
            t.Paused = true;
            t.Gate.Reset();
            t.State = TaskState.Paused;
            t.Notify(); Changed?.Invoke();
        }

        public static void Resume(TransferTask t)
        {
            t.Paused = false;
            t.Gate.Set();
            t.State = TaskState.Running;
            t.Notify(); Changed?.Invoke();
        }

        public static void Cancel(TransferTask t)
        {
            t.Cts.Cancel();
            t.Gate.Set();
            t.State = TaskState.Canceled;
            t.Notify(); Changed?.Invoke();
        }

        public static void Retry(TransferTask t)
        {
            var fresh = new TransferTask
            {
                Kind = t.Kind,
                Source = t.Source,
                Dest = t.Dest,
                HostId = t.HostId
            };
            lock (Tasks) Tasks.Remove(t);
            Add(fresh);
        }

        public static void ClearFinished()
        {
            lock (Tasks)
                Tasks.RemoveAll(x => x.State == TaskState.Done || x.State == TaskState.Failed || x.State == TaskState.Canceled);
            Changed?.Invoke();
        }
    }
}
