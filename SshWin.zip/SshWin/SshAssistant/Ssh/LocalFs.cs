using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using SshAssistant.Models;

namespace SshAssistant.Ssh
{
    /// <summary>
    /// 本地文件操作。对应 Android 版的 ssh/LocalFs.kt。
    /// 权限位转换沿用修复后的正确位序。
    /// </summary>
    public static class LocalFs
    {
        public static string Root() => AppSettings.Load().LocalRoot;

        public static string Join(string dir, string name) => Path.Combine(dir, name);

        public static string Parent(string path)
        {
            var p = Path.GetDirectoryName(path.TrimEnd(Path.DirectorySeparatorChar));
            return string.IsNullOrEmpty(p) ? Path.GetPathRoot(path) : p;
        }

        public static List<FileItem> List(string dir, bool showHidden)
        {
            var list = new List<FileItem>();
            try
            {
                foreach (var d in Directory.EnumerateDirectories(dir))
                {
                    var name = Path.GetFileName(d);
                    if (!showHidden && name.StartsWith(".")) continue;
                    var di = new DirectoryInfo(d);
                    list.Add(new FileItem
                    { Name = name, Path = d, IsDir = true, Modified = di.LastWriteTime, Remote = false });
                }
                foreach (var f in Directory.EnumerateFiles(dir))
                {
                    var name = Path.GetFileName(f);
                    if (!showHidden && name.StartsWith(".")) continue;
                    var fi = new FileInfo(f);
                    list.Add(new FileItem
                    { Name = name, Path = f, IsDir = false, Size = fi.Length, Modified = fi.LastWriteTime, Remote = false });
                }
            }
            catch { }
            return list.OrderByDescending(x => x.IsDir).ThenBy(x => x.Name, StringComparer.OrdinalIgnoreCase).ToList();
        }

        public static bool Exists(string path) => File.Exists(path) || Directory.Exists(path);

        public static long SizeOf(string path)
        {
            try { return new FileInfo(path).Length; } catch { return 0; }
        }

        public static void MakeDir(string path) => Directory.CreateDirectory(path);

        public static void Delete(string path, bool isDir)
        {
            if (isDir) Directory.Delete(path, true);
            else File.Delete(path);
        }

        public static void Rename(string from, string to)
        {
            if (File.Exists(to)) File.Delete(to);
            if (Directory.Exists(to)) Directory.Delete(to, true);
            if (Directory.Exists(from)) Directory.Move(from, to);
            else File.Move(from, to);
        }

        public static void CopyOrMove(string from, string to, bool move)
        {
            if (Directory.Exists(from))
            {
                if (IsSameOrChild(from, to))
                    throw new IOException("不能把目录复制/移动到它自己或其子目录中");
                CopyDirRecursive(from, to);
                if (move)
                {
                    try { Directory.Delete(from, true); }
                    catch
                    {
                        // 跨分区删除失败时退化为标记，避免误报成功
                        throw new IOException("移动失败：源目录无法删除");
                    }
                }
            }
            else
            {
                File.Copy(from, to, true);
                if (move) File.Delete(from);
            }
        }

        public static bool IsSameOrChild(string src, string dst)
        {
            try
            {
                var s = Path.GetFullPath(src).TrimEnd(Path.DirectorySeparatorChar).ToLowerInvariant();
                var d = Path.GetFullPath(dst).TrimEnd(Path.DirectorySeparatorChar).ToLowerInvariant();
                return d == s || d.StartsWith(s + Path.DirectorySeparatorChar);
            }
            catch { return false; }
        }

        private static void CopyDirRecursive(string from, string to)
        {
            Directory.CreateDirectory(to);
            foreach (var dir in Directory.EnumerateDirectories(from))
                CopyDirRecursive(dir, Path.Combine(to, Path.GetFileName(dir)));
            foreach (var file in Directory.EnumerateFiles(from))
                File.Copy(file, Path.Combine(to, Path.GetFileName(file)), true);
        }

        public static int Permissions(string path)
        {
            try
            {
                int p = 0;
                var attr = File.GetAttributes(path);
                bool readOnly = (attr & FileAttributes.ReadOnly) != 0;
                if (Directory.Exists(path))
                {
                    p |= 0b100000000 | 0b001000000;  // r-x owner
                    p |= 0b000100000 | 0b000001000;  // r-x group
                    p |= 0b000000100 | 0b000000001;  // r-x others
                    if (!readOnly) p |= 0b010000000 | 0b000010000 | 0b000000010;
                    return p;
                }
                p |= 0b100000000;  // owner r
                if (!readOnly) p |= 0b010000000;
                p |= 0b000100000;  // group r
                if (!readOnly) p |= 0b000010000;
                p |= 0b000000100;  // others r
                if (!readOnly) p |= 0b000000010;
                return p;
            }
            catch { return 0b110100100; }   // 0644
        }

        /// <summary>设置权限：Windows 只支持只读位，写位映射为只读取反</summary>
        public static void Chmod(string path, int perm)
        {
            try
            {
                bool writable = (perm & 0b010000000) != 0;
                var attr = File.GetAttributes(path);
                if (writable) attr &= ~FileAttributes.ReadOnly;
                else attr |= FileAttributes.ReadOnly;
                File.SetAttributes(path, attr);
            }
            catch { }
        }

        public static string ReadText(string path) => File.ReadAllText(path);

        public static void WriteText(string path, string content)
        {
            File.WriteAllText(path, content, new System.Text.UTF8Encoding(false));
        }
    }
}
