using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Renci.SshNet;
using Renci.SshNet.Sftp;
using SshAssistant.Models;

namespace SshAssistant.Ssh
{
    /// <summary>
    /// 远程文件操作（SFTP）。对应 Android 版的 ssh/RemoteFs.kt。
    /// 路径拼接、权限位转换与 Android 版保持一致。
    /// </summary>
    public static class RemoteFs
    {
        private static SftpClient Client(LiveSession s)
        {
            if (s?.Sftp == null || !s.Sftp.IsConnected) throw new IOException("SFTP 未连接");
            return s.Sftp;
        }

        public static string Join(string dir, string name)
        {
            if (string.IsNullOrEmpty(dir)) dir = "/";
            if (dir == "/") return "/" + name.TrimStart('/');
            return dir.TrimEnd('/') + "/" + name;
        }

        public static string Parent(string path)
        {
            if (string.IsNullOrEmpty(path) || path == "/") return "/";
            var i = path.TrimEnd('/').LastIndexOf('/');
            return i <= 0 ? "/" : path.Substring(0, i);
        }

        public static List<FileItem> List(LiveSession s, string dir, bool showHidden)
        {
            var c = Client(s);
            var list = new List<FileItem>();
            foreach (var f in c.ListDirectory(dir))
            {
                if (f.Name == "." || f.Name == "..") continue;
                if (!showHidden && f.Name.StartsWith(".")) continue;
                list.Add(new FileItem
                {
                    Name = f.Name,
                    Path = f.FullName,
                    IsDir = f.IsDirectory,
                    IsLink = f.IsSymbolicLink,
                    Size = f.IsDirectory ? 0 : f.Length,
                    Modified = f.LastWriteTime,
                    Permissions = "",
                    Remote = true
                });
            }
            return SortDefault(list);
        }

        private static List<FileItem> SortDefault(List<FileItem> list)
        {
            return list.OrderByDescending(x => x.IsDir).ThenBy(x => x.Name, StringComparer.OrdinalIgnoreCase).ToList();
        }

        public static bool Exists(LiveSession s, string path)
        {
            try { return Client(s).Exists(path); }
            catch { return false; }
        }

        public static long SizeOf(LiveSession s, string path)
        {
            try
            {
                var f = Client(s).Get(path);
                return f.IsDirectory ? 0 : f.Length;
            }
            catch { return 0; }
        }

        /// <summary>获取文件权限位（0o777 形式的整数）</summary>
        public static int Permissions(LiveSession s, string path)
        {
            try
            {
                var f = Client(s).Get(path);
                int p = 0;
                if (f.OwnerCanRead) p |= 0b100000000;
                if (f.OwnerCanWrite) p |= 0b010000000;
                if (f.OwnerCanExecute) p |= 0b001000000;
                if (f.GroupCanRead) p |= 0b000100000;
                if (f.GroupCanWrite) p |= 0b000010000;
                if (f.GroupCanExecute) p |= 0b000001000;
                if (f.OthersCanRead) p |= 0b000000100;
                if (f.OthersCanWrite) p |= 0b000000010;
                if (f.OthersCanExecute) p |= 0b000000001;
                return p;
            }
            catch { return 0; }
        }

        /// <summary>
        /// 设置权限。位序与 Android 版修复后的版本一致：
        /// owner=r<<6|w<<3|x, group 同理 —— 早期版本曾整体错位导致 chmod 600 把文件变废。
        /// </summary>
        public static void Chmod(LiveSession s, string path, int perm)
        {
            short mode = 0;
            if ((perm & 0b100000000) != 0) mode |= 0b100000000;   // owner r
            if ((perm & 0b010000000) != 0) mode |= 0b010000000;   // owner w
            if ((perm & 0b001000000) != 0) mode |= 0b001000000;   // owner x
            if ((perm & 0b000100000) != 0) mode |= 0b000100000;   // group r
            if ((perm & 0b000010000) != 0) mode |= 0b000010000;
            if ((perm & 0b000001000) != 0) mode |= 0b000001000;
            if ((perm & 0b000000100) != 0) mode |= 0b000000100;   // others r
            if ((perm & 0b000000010) != 0) mode |= 0b000000010;
            if ((perm & 0b000000001) != 0) mode |= 0b000000001;
            Client(s).ChangePermissions(path, mode);
        }

        public static void MakeDir(LiveSession s, string path) => Client(s).CreateDirectory(path);

        public static void Delete(LiveSession s, string path, bool isDir)
        {
            var c = Client(s);
            if (isDir) DeleteRecursive(c, path);
            else c.DeleteFile(path);
        }

        private static void DeleteRecursive(SftpClient c, string dir)
        {
            foreach (var f in c.ListDirectory(dir))
            {
                if (f.Name == "." || f.Name == "..") continue;
                if (f.IsDirectory) DeleteRecursive(c, f.FullName);
                else c.DeleteFile(f.FullName);
            }
            c.DeleteDirectory(dir);
        }

        public static void Rename(LiveSession s, string from, string to)
        {
            var c = Client(s);
            if (c.Exists(to)) c.DeleteFile(to);
            c.RenameFile(from, to);
        }

        /// <summary>复制或移动（跨目录）</summary>
        public static void CopyOrMove(LiveSession s, string from, string to, bool move)
        {
            var c = Client(s);
            var src = c.Get(from);
            if (src.IsDirectory) CopyDirRecursive(c, from, to, move);
            else
            {
                CopyFile(c, from, to);
                if (move) c.DeleteFile(from);
            }
        }

        private static void CopyFile(SftpClient c, string from, string to)
        {
            using var rs = c.OpenRead(from);
            using var ws = c.Create(to);
            rs.CopyTo(ws);
        }

        private static void CopyDirRecursive(SftpClient c, string from, string to, bool move)
        {
            if (!c.Exists(to)) c.CreateDirectory(to);
            foreach (var f in c.ListDirectory(from))
            {
                if (f.Name == "." || f.Name == "..") continue;
                var dst = Join(to, f.Name);
                if (f.IsDirectory) CopyDirRecursive(c, f.FullName, dst, move);
                else
                {
                    CopyFile(c, f.FullName, dst);
                    if (move) c.DeleteFile(f.FullName);
                }
            }
            if (move) c.DeleteDirectory(from);
        }

        public static string ReadText(LiveSession s, string path)
        {
            var c = Client(s);
            using var rs = c.OpenRead(path);
            using var sr = new StreamReader(rs);
            return sr.ReadToEnd();
        }

        public static void WriteText(LiveSession s, string path, string content)
        {
            var c = Client(s);
            using var ws = c.Create(path);
            using var sw = new StreamWriter(ws, new System.Text.UTF8Encoding(false));
            sw.Write(content);
        }
    }
}
