using System.Collections.Generic;
using System.Linq;
using SshAssistant.Models;

namespace SshAssistant.Ssh
{
    /// <summary>面板内剪贴板：记录待复制/移动的文件。对应 Android 版的 PaneClipboard.kt。</summary>
    public class ClipEntry
    {
        public string Path;
        public string Name => System.IO.Path.GetFileName(Path.TrimEnd('/'));
        public bool Remote;
        public bool Cut;
    }

    public static class PaneClipboard
    {
        private static readonly List<ClipEntry> Items = new List<ClipEntry>();

        public static void Set(IEnumerable<FileItem> list, bool cut)
        {
            Items.Clear();
            foreach (var it in list)
                Items.Add(new ClipEntry { Path = it.Path, Remote = it.Remote, Cut = cut });
        }

        /// <summary>
        /// 跨端粘贴时方向由【来源】决定，不是目标 ——
        /// Android 版曾因按目标判断导致方向取反。
        /// </summary>
        public static bool IsUploadTarget(bool destRemote) =>
            Items.Count > 0 && !Items[0].Remote && destRemote;

        public static List<ClipEntry> Entries => Items.ToList();
        public static bool IsEmpty => Items.Count == 0;
        public static void Clear() => Items.Clear();
    }
}
