using System.Windows;
using SshAssistant.Data;
using SshAssistant.Ssh;
using SshAssistant.Terminal;

namespace SshAssistant
{
    public partial class App : Application
    {
        public static AppSettings Settings { get; private set; }

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            // 全局异常兜底：未捕获异常默认会让进程直接消失（"闪退"），
            // 看不到任何原因。这里改成弹窗显示异常，便于定位问题。
            DispatcherUnhandledException += (s, ev) =>
            {
                try
                {
                    MessageBox.Show(
                        ev.Exception?.ToString() ?? "未知异常",
                        "程序出现异常",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                }
                catch { }
                ev.Handled = true;   // 不让进程退出，尽量保住已打开的窗口
            };

            Settings = AppSettings.Load();
            ApplyTheme();

            // 主机密钥信任回调（TOFU）：在弹出的对话框里询问用户
            SshConnector.TrustPrompt = req =>
            {
                var dlg = new Views.TrustDialog(req.Host, req.Port, req.Fingerprint);
                var r = dlg.ShowDialog();
                if (r == true) req.Reply(true, dlg.AlwaysTrust);
                else req.Reply(false, false);
            };

            // 应用关闭时清理所有会话
            Exit += (s, ev) => SessionRegistry.CloseAll();
        }

        /// <summary>
        /// 应用主题：dark / light / system。
        /// 与 Android 版一致 —— 切换后界面立即生效，终端配色同步跟随。
        /// </summary>
        public static void ApplyTheme()
        {
            var res = Current.Resources;
            bool light = Settings.Theme == "light";

            if (Settings.Theme == "system")
            {
                // Windows 系统主题：读注册表 AppsUseLightTheme
                try
                {
                    using var k = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(
                        @"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize");
                    var v = k?.GetValue("AppsUseLightTheme");
                    if (v is int i) light = (i == 1);
                }
                catch { }
            }

            if (light)
            {
                res["Surface"] = System.Windows.Media.Color.FromRgb(0xFA, 0xFB, 0xFF);
                res["SurfaceContainer"] = System.Windows.Media.Color.FromRgb(0xFF, 0xFF, 0xFF);
                res["SurfaceVariant"] = System.Windows.Media.Color.FromRgb(0xEE, 0xF2, 0xF9);
                res["BarBg"] = System.Windows.Media.Color.FromRgb(0xF6, 0xF8, 0xFD);
                res["Divider"] = System.Windows.Media.Color.FromRgb(0xDD, 0xE3, 0xEC);
                res["TextPrimary"] = System.Windows.Media.Color.FromRgb(0x1B, 0x1B, 0x1F);
                res["TextSecondary"] = System.Windows.Media.Color.FromRgb(0x44, 0x47, 0x4B);
                res["Primary"] = System.Windows.Media.Color.FromRgb(0x0B, 0x57, 0xD0);
                res["PrimaryDark"] = System.Windows.Media.Color.FromRgb(0x08, 0x42, 0xA0);
                res["PrimaryContainer"] = System.Windows.Media.Color.FromRgb(0xD8, 0xE2, 0xFF);
                res["OnPrimary"] = System.Windows.Media.Color.FromRgb(0xFF, 0xFF, 0xFF);
                res["OnPrimaryContainer"] = System.Windows.Media.Color.FromRgb(0x00, 0x1A, 0x41);
                res["Error"] = System.Windows.Media.Color.FromRgb(0xB3, 0x26, 0x1E);
                res["Accent"] = System.Windows.Media.Color.FromRgb(0x0B, 0x57, 0xD0);
            }
            else
            {
                res["Surface"] = System.Windows.Media.Color.FromRgb(0x12, 0x14, 0x1C);
                res["SurfaceContainer"] = System.Windows.Media.Color.FromRgb(0x1A, 0x1C, 0x24);
                res["SurfaceVariant"] = System.Windows.Media.Color.FromRgb(0x1E, 0x20, 0x29);
                res["BarBg"] = System.Windows.Media.Color.FromRgb(0x17, 0x19, 0x22);
                res["Divider"] = System.Windows.Media.Color.FromRgb(0x2A, 0x2D, 0x38);
                res["TextPrimary"] = System.Windows.Media.Color.FromRgb(0xE4, 0xE2, 0xE6);
                res["TextSecondary"] = System.Windows.Media.Color.FromRgb(0xCA, 0xC7, 0xD0);
                res["Primary"] = System.Windows.Media.Color.FromRgb(0xAD, 0xC6, 0xFF);
                res["PrimaryDark"] = System.Windows.Media.Color.FromRgb(0x7B, 0xA0, 0xFF);
                res["PrimaryContainer"] = System.Windows.Media.Color.FromRgb(0x00, 0x44, 0x94);
                res["OnPrimary"] = System.Windows.Media.Color.FromRgb(0x00, 0x2E, 0x69);
                res["OnPrimaryContainer"] = System.Windows.Media.Color.FromRgb(0xD8, 0xE2, 0xFF);
                res["Error"] = System.Windows.Media.Color.FromRgb(0xF2, 0xB8, 0xB5);
                res["Accent"] = System.Windows.Media.Color.FromRgb(0xAD, 0xC6, 0xFF);
            }

            // 终端配色跟随主题（只换前 16 色）
            TerminalEmulator.SetLightTheme(light);
        }

        public static void SaveSettings()
        {
            Settings?.Save();
        }
    }
}
