using System.Windows;
using System.Windows.Media;
using System.Runtime.InteropServices;
using SshAssistant.Data;
using SshAssistant.Ssh;
using SshAssistant.Terminal;

namespace SshAssistant
{
    public partial class App : Application
    {
        public static AppSettings Settings { get; private set; }

        private static readonly System.Collections.Generic.HashSet<string> _shownErrors
            = new System.Collections.Generic.HashSet<string>();

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            // 全局异常兜底：未捕获异常默认会让进程直接消失（"闪退"），
            // 看不到任何原因。这里改成弹窗显示异常，便于定位问题。
            //
            // 同时做去重：同一个异常（类型+消息）只弹一次。
            // 否则在布局/渲染里抛异常时会每个元素弹一次，
            // 瞬间糊满整个屏幕，根本没法用。
            DispatcherUnhandledException += (s, ev) =>
            {
                try
                {
                    var ex = ev.Exception;
                    string sig = (ex?.GetType().FullName ?? "?") + "|" + (ex?.Message ?? "");
                    if (_shownErrors.Add(sig))
                    {
                        MessageBox.Show(
                            ex?.ToString() ?? "未知异常",
                            "程序出现异常",
                            MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                    System.Diagnostics.Debug.WriteLine("[UI异常] " + ex);
                }
                catch { }
                ev.Handled = true;   // 不让进程退出，尽量保住已打开的窗口
            };

            Settings = AppSettings.Load();
            ApplyTheme();

            // 主机密钥信任回调（TOFU）：在弹出的对话框里询问用户。
            //
            // 【重要】连接流程跑在 Task.Run 的后台线程里，
            // 而 WPF 窗口只能在 UI 线程（STA）创建和 ShowDialog，
            // 在后台线程直接 new + ShowDialog 会抛异常 ——
            // 这正是"连接 Linux 终端时弹错误提示"的一个成因。
            // 因此这里强制切回 UI 线程执行。
            SshConnector.TrustPrompt = req =>
            {
                var disp = Current?.Dispatcher;
                if (disp == null) { req.Reply(false, false); return; }

                bool? r = null;
                bool always = false;
                disp.Invoke(() =>
                {
                    var dlg = new Views.TrustDialog(req.Host, req.Port, req.Fingerprint);
                    r = dlg.ShowDialog();
                    always = dlg.AlwaysTrust;
                });

                if (r == true) req.Reply(true, always);
                else req.Reply(false, false);
            };

            // 【深色标题栏】窗口标题栏是系统画的，不受我们的资源控制。
            // Windows 处于浅色模式时标题栏就是白的 —— 深色界面配白标题栏，
            // 正是"参杂着白色主题"的一部分。
            // 这里注册一个类级处理器，任何窗口（含以后打开的、以及代码里
            // new 出来的对话框）创建句柄后都自动套用对应主题。
            //
            // 注意：不能用 Window.SourceInitializedEvent ——
            // SourceInitialized 是【CLR 事件】而非路由事件，
            // WPF 并没有生成对应的 RoutedEvent 字段（编译会报 CS0117）。
            // EventManager.RegisterClassHandler 只接受路由事件，
            // 所以改用 Window.LoadedEvent：Loaded 触发时窗口句柄必然已创建。
            EventManager.RegisterClassHandler(typeof(System.Windows.Window),
                System.Windows.Window.LoadedEvent,
                new RoutedEventHandler((s, ev) => ApplyTitleBar(s as System.Windows.Window)));

            // 应用关闭时清理所有会话
            Exit += (s, ev) => SessionRegistry.CloseAll();
        }

        /// <summary>
        /// 应用主题：dark / light / system。
        ///
        /// 【关键修复 · 之前反复出问题的根因】
        /// 原实现只替换 Color 资源（res["Surface"] = ...），
        /// 而界面上用的全是 Brush（Background="{DynamicResource SurfaceBrush}"），
        /// Brush 内部再用 DynamicResource 引用 Color。
        ///
        /// SolidColorBrush 是 Freezable：界面渲染过之后 WPF 会把它【冻结】，
        /// 冻结后无法修改 —— 于是再改 Color 就【不会传播】到 Brush。
        /// 表现就是：启动时主题正常，但在设置里切换主题后
        /// 一部分变了、一部分还是旧颜色（"有黑有白"），
        /// 以及浅色文字压在旧的白底上（"看不清"）。
        ///
        /// 正确做法：直接替换 Brush【对象本身】。
        /// 资源替换走 DynamicResource 的正常路径，与冻结无关，必定生效。
        /// </summary>
        public static void ApplyTheme()
        {
            var res = Current.Resources;
            bool light = Settings.Theme == "light";

            if (Settings.Theme == "system")
            {
                // Windows 系统主题：读注册表 AppsUseLightTheme
                try
                {
                    using var k = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(
                        @"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize");
                    var v = k?.GetValue("AppsUseLightTheme");
                    if (v is int i) light = (i == 1);
                }
                catch { }
            }

            SetPalette(res, light);
            OverrideSystemColors(res, light);
            TerminalEmulator.SetLightTheme(light);

            // 标题栏是系统绘制的，走 DWM 而非 WPF 资源，
            // 所以切换主题时要对【所有已打开的窗口】重新设置一次。
            if (Current != null)
                foreach (System.Windows.Window w in Current.Windows) ApplyTitleBar(w);
        }

        // ---------- 调色板 ----------
        // 键名与 App.xaml 中的 <Color x:Key="..."> 一一对应，
        // 这样 XAML 里写 {DynamicResource Surface} 或 SurfaceBrush 都能命中。
        private static readonly (string Key, uint Dark, uint Light)[] PaletteDef =
        {
            ("Surface",             0xFF12141C, 0xFFFAFBFF),
            ("SurfaceContainer",    0xFF1A1C24, 0xFFFFFFFF),
            ("SurfaceVariant",      0xFF1E2029, 0xFFEEF2F9),
            ("BarBg",               0xFF171922, 0xFFF6F8FD),
            ("Divider",             0xFF2A2D38, 0xFFDDE3EC),
            ("TextPrimary",         0xFFE4E2E6, 0xFF1B1B1F),
            ("TextSecondary",       0xFFCAC7D0, 0xFF44474B),
            ("Primary",             0xFFADC6FF, 0xFF0B57D0),
            ("PrimaryDark",         0xFF7BA0FF, 0xFF0842A0),
            ("PrimaryContainer",    0xFF004494, 0xFFD8E2FF),
            ("OnPrimary",           0xFF002E69, 0xFFFFFFFF),
            ("OnPrimaryContainer",  0xFFD8E2FF, 0xFF001A41),
            ("Error",               0xFFF2B8B5, 0xFFB3261E),
            ("Accent",              0xFFADC6FF, 0xFF0B57D0),
        };

        private static Color C(uint argb) => Color.FromRgb(
            (byte)((argb >> 16) & 0xFF), (byte)((argb >> 8) & 0xFF), (byte)(argb & 0xFF));

        private static void SetPalette(ResourceDictionary res, bool light)
        {
            foreach (var (key, dark, lightc) in PaletteDef)
            {
                var col = C(light ? lightc : dark);

                // 1) Color 资源：直接引用 {DynamicResource Surface} 的地方要用
                res[key] = col;

                // 2) Brush 资源：必须整体替换对象，不能靠改 Color 传播（会被冻结）
                res[key + "Brush"] = new SolidColorBrush(col);
            }
        }

        /// <summary>
        /// 覆盖 WPF 的 SystemColors。
        ///
        /// 所有【没有自定义模板】的控件（ComboBox 下拉弹窗、ScrollBar 滑块、
        /// Slider 轨道、右键菜单、默认 CheckBox 方块……）都会去读 SystemColors，
        /// 而它默认是 Windows 的亮色。只改自己的 Brush 管不到它们 ——
        /// 这就是为什么"很多项看不清"：深色界面上突然冒出一块系统白底。
        ///
        /// 覆盖这些 key 后，默认模板也会跟着应用主题走。
        /// </summary>
        private static void OverrideSystemColors(ResourceDictionary res, bool light)
        {
            var surface     = C(light ? 0xFFFAFBFF : 0xFF12141C);
            var surfaceCont = C(light ? 0xFFFFFFFF : 0xFF1A1C24);
            var surfaceVar  = C(light ? 0xFFEEF2F9 : 0xFF1E2029);
            var divider     = C(light ? 0xFFDDE3EC : 0xFF2A2D38);
            var textPri     = C(light ? 0xFF1B1B1F : 0xFFE4E2E6);
            var textSec     = C(light ? 0xFF44474B : 0xFFCAC7D0);
            var primCont    = C(light ? 0xFFD8E2FF : 0xFF004494);
            var onPrimCont  = C(light ? 0xFF001A41 : 0xFFD8E2FF);

            void Set(object key, Color c) => res[key] = new SolidColorBrush(c);

            // 窗口 / 输入框（含 ComboBox 的下拉弹窗背景）
            Set(SystemColors.WindowBrushKey, surface);
            Set(SystemColors.WindowTextBrushKey, textPri);

            // 通用控件底色与文字
            Set(SystemColors.ControlBrushKey, surfaceCont);
            Set(SystemColors.ControlTextBrushKey, textPri);
            Set(SystemColors.ControlLightBrushKey, surfaceVar);
            Set(SystemColors.ControlLightLightBrushKey, surfaceVar);
            Set(SystemColors.ControlDarkBrushKey, divider);
            Set(SystemColors.ControlDarkDarkBrushKey, divider);

            // 选中 / 高亮
            Set(SystemColors.HighlightBrushKey, primCont);
            Set(SystemColors.HighlightTextBrushKey, onPrimCont);
            Set(SystemColors.InactiveSelectionHighlightBrushKey, surfaceVar);
            Set(SystemColors.InactiveSelectionHighlightTextBrushKey, textSec);

            // 菜单（含文件面板的右键菜单）
            Set(SystemColors.MenuBrushKey, surfaceCont);
            Set(SystemColors.MenuTextBrushKey, textPri);
            Set(SystemColors.MenuHighlightBrushKey, primCont);
            Set(SystemColors.MenuBarBrushKey, surfaceVar);

            // 滚动条滑块、禁用态文字、提示气泡
            Set(SystemColors.ScrollBarBrushKey, surfaceVar);
            Set(SystemColors.GrayTextBrushKey, textSec);
            Set(SystemColors.InfoBrushKey, surfaceCont);
            Set(SystemColors.InfoTextBrushKey, textPri);
        }

        /// <summary>当前是否处于浅色主题</summary>
        public static bool IsLightTheme =>
            Settings != null && Settings.Theme == "light" ||
            (Settings != null && Settings.Theme == "system" && SystemIsLight());

        private static bool SystemIsLight()
        {
            try
            {
                using var k = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(
                    @"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize");
                return k?.GetValue("AppsUseLightTheme") is int i && i == 1;
            }
            catch { return false; }
        }

        private const int DWMWA_USE_IMMERSIVE_DARK_MODE_MODERN = 20;
        private const int DWMWA_USE_IMMERSIVE_DARK_MODE_OLD = 19;

        [DllImport("dwmapi.dll", PreserveSig = false)]
        private static extern void DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int value, int size);

        /// <summary>让标题栏跟随应用主题（深色界面用深色标题栏）</summary>
        public static void ApplyTitleBar(System.Windows.Window w)
        {
            if (w == null) return;
            try
            {
                var hwnd = new System.Windows.Interop.WindowInteropHelper(w).Handle;
                if (hwnd == IntPtr.Zero) return;
                int dark = IsLightTheme ? 0 : 1;
                // 新旧两个属性值都设：新系统认 20，老一些的认 19。
                // 不支持的属性会被系统忽略（有异常兜底），不影响功能。
                try { DwmSetWindowAttribute(hwnd, DWMWA_USE_IMMERSIVE_DARK_MODE_MODERN, ref dark, sizeof(int)); }
                catch { }
                try { DwmSetWindowAttribute(hwnd, DWMWA_USE_IMMERSIVE_DARK_MODE_OLD, ref dark, sizeof(int)); }
                catch { }
            }
            catch { }
        }

        public static void SaveSettings()
        {
            Settings?.Save();
        }
    }
}
