using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using SshAssistant.Models;

namespace SshAssistant.Data
{
    /// <summary>
    /// 主机列表持久化（不含凭据）。凭据走 CredentialStore。
    /// 对应 Android 版的 data/HostStore.kt。
    /// </summary>
    public static class HostStore
    {
        private static readonly List<HostConfig> Hosts = new List<HostConfig>();

        static HostStore()
        {
            Load();
        }

        private static void Load()
        {
            try
            {
                if (File.Exists(Paths.HostsFile))
                {
                    var json = File.ReadAllText(Paths.HostsFile);
                    var list = JsonSerializer.Deserialize<List<HostConfig>>(json);
                    if (list != null)
                    {
                        Hosts.Clear();
                        Hosts.AddRange(list);
                    }
                }
            }
            catch { }
        }

        private static void Persist()
        {
            try
            {
                Directory.CreateDirectory(Paths.DataDir);
                File.WriteAllText(Paths.HostsFile,
                    JsonSerializer.Serialize(Hosts, new JsonSerializerOptions { WriteIndented = true }));
            }
            catch { }
        }

        public static List<HostConfig> All() => Hosts.ToList();

        public static HostConfig Get(string id) => Hosts.FirstOrDefault(h => h.Id == id);

        public static void Save(HostConfig h)
        {
            int idx = Hosts.FindIndex(x => x.Id == h.Id);
            if (idx >= 0) Hosts[idx] = h; else Hosts.Add(h);
            Persist();
        }

        public static void Delete(string id)
        {
            Hosts.RemoveAll(x => x.Id == id);
            Persist();
            CredentialStore.Remove(PwKey(id));
            CredentialStore.Remove(KpKey(id));
        }

        // ---- 凭据 ----
        private static string PwKey(string id) => "pw_" + id;
        private static string KpKey(string id) => "kp_" + id;

        public static string GetPassword(string id) => CredentialStore.Get(PwKey(id));

        public static void SetPassword(string id, string value)
        {
            if (string.IsNullOrEmpty(value)) CredentialStore.Remove(PwKey(id));
            else CredentialStore.Put(PwKey(id), value);
        }

        public static string GetKeyPassphrase(string id) => CredentialStore.Get(KpKey(id));

        public static void SetKeyPassphrase(string id, string value)
        {
            if (string.IsNullOrEmpty(value)) CredentialStore.Remove(KpKey(id));
            else CredentialStore.Put(KpKey(id), value);
        }

        // ---- 主机密钥指纹（TOFU） ----
        private static string HostKeyKey(string host, int port) => $"{host}:{port}";

        private static Dictionary<string, string> KnownHosts()
        {
            try
            {
                if (File.Exists(Paths.KnownHostsFile))
                {
                    var json = File.ReadAllText(Paths.KnownHostsFile);
                    return JsonSerializer.Deserialize<Dictionary<string, string>>(json)
                           ?? new Dictionary<string, string>();
                }
            }
            catch { }
            return new Dictionary<string, string>();
        }

        public static string GetFingerprint(string host, int port)
        {
            return KnownHosts().TryGetValue(HostKeyKey(host, port), out var v) ? v : null;
        }

        public static void TrustFingerprint(string host, int port, string fingerprint)
        {
            var map = KnownHosts();
            map[HostKeyKey(host, port)] = fingerprint;
            try
            {
                Directory.CreateDirectory(Paths.DataDir);
                File.WriteAllText(Paths.KnownHostsFile, JsonSerializer.Serialize(map));
            }
            catch { }
        }

        public static int ClearKnownHosts()
        {
            var map = KnownHosts();
            int n = map.Count;
            try
            {
                Directory.CreateDirectory(Paths.DataDir);
                File.WriteAllText(Paths.KnownHostsFile, "{}");
            }
            catch { }
            return n;
        }
    }

    /// <summary>主机配置导入导出（含凭据，与 Android 版 HostJson 一致）</summary>
    public static class HostJson
    {
        public class ExportRoot
        {
            public int version { get; set; } = 1;
            public bool containsCredentials { get; set; } = true;
            public List<HostConfig> hosts { get; set; } = new List<HostConfig>();
        }

        public static string ExportAll(IEnumerable<HostConfig> hosts)
        {
            var root = new ExportRoot();
            foreach (var h in hosts)
            {
                var copy = h.Clone();
                // 导出带凭据（明文），与 Android 版行为一致：便于迁移到另一台设备
                copy.Credentials = new HostCredentials
                {
                    Password = HostStore.GetPassword(h.Id),
                    KeyPassphrase = HostStore.GetKeyPassphrase(h.Id)
                };
                root.hosts.Add(copy);
            }
            return JsonSerializer.Serialize(root, new JsonSerializerOptions { WriteIndented = true });
        }

        /// <summary>导入；老版本导出文件里没有凭据字段时不会报错</summary>
        public static List<HostConfig> ImportAll(string json)
        {
            var root = JsonSerializer.Deserialize<ExportRoot>(json);
            if (root?.hosts == null) throw new ArgumentException("缺少 hosts 字段");
            foreach (var h in root.hosts)
            {
                if (h.Id == null || h.Id.Length == 0) h.Id = Guid.NewGuid().ToString("N");
            }
            return root.hosts;
        }
    }
}
