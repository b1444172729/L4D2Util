using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace SshAssistant.Data
{
    /// <summary>
    /// 应用设置。对应 Android 版的 data/AppPrefs.kt，键名与取值一一对应，
    /// 这样两边的设置文件语义一致（迁移时不用做映射）。
    /// </summary>
    public class AppSettings
    {
        // ---- 终端 ----
        public int FontSize { get; set; } = 14;
        public int Scrollback { get; set; } = 3000;
        public string TermType { get; set; } = "xterm-256color";
        public int Keepalive { get; set; } = 30;
        public List<string> Shortcuts { get; set; } = new List<string>();
        public bool ShowKeyBar { get; set; } = true;
        public List<string> KeyBarOrder { get; set; } = new List<string>();
        public bool Bell { get; set; } = false;

        // ---- 文件 ----
        public bool ShowHidden { get; set; } = false;
        public string LocalRoot { get; set; } = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
        public string Conflict { get; set; } = "ask";   // ask / overwrite / resume / skip

        // ---- 连接 ----
        public bool Compression { get; set; } = false;

        // ---- 外观 ----
        public string Theme { get; set; } = "dark";     // system / dark / light

        // ---- 窗口 ----
        public double WindowWidth { get; set; } = 1100;
        public double WindowHeight { get; set; } = 720;

        private static string FilePath =>
            Path.Combine(Paths.DataDir, "settings.json");

        private static readonly JsonSerializerOptions Opts = new JsonSerializerOptions
        {
            WriteIndented = true,
            DefaultIgnoreCondition = JsonIgnoreCondition.Never
        };

        public static AppSettings Load()
        {
            try
            {
                if (File.Exists(FilePath))
                {
                    var json = File.ReadAllText(FilePath);
                    return JsonSerializer.Deserialize<AppSettings>(json, Opts) ?? new AppSettings();
                }
            }
            catch { }
            return new AppSettings();
        }

        public void Save()
        {
            try
            {
                Directory.CreateDirectory(Paths.DataDir);
                File.WriteAllText(FilePath, JsonSerializer.Serialize(this, Opts));
            }
            catch { }
        }

        /// <summary>设置是否改变（用于即时生效）</summary>
        public event EventHandler<string> Changed;

        public void NotifyChanged(string key)
        {
            Changed?.Invoke(this, key);
        }
    }

    /// <summary>应用数据目录</summary>
    public static class Paths
    {
        public static string DataDir =>
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "SshAssistant");

        public static string HostsFile => Path.Combine(DataDir, "hosts.json");
        public static string CredFile => Path.Combine(DataDir, "creds.dat");
        public static string KnownHostsFile => Path.Combine(DataDir, "known_hosts.json");
        public static string RulesFile => Path.Combine(DataDir, "forward_rules.json");
    }
}
