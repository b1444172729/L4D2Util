using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using SshAssistant.Models;

namespace SshAssistant.Data
{
    /// <summary>端口转发规则持久化</summary>
    public static class PortForwardStore
    {
        public static List<PortForwardRule> Load()
        {
            try
            {
                if (File.Exists(Paths.RulesFile))
                {
                    var json = File.ReadAllText(Paths.RulesFile);
                    return JsonSerializer.Deserialize<List<PortForwardRule>>(json)
                           ?? new List<PortForwardRule>();
                }
            }
            catch { }
            return new List<PortForwardRule>();
        }

        public static void Save(List<PortForwardRule> rules)
        {
            try
            {
                Directory.CreateDirectory(Paths.DataDir);
                File.WriteAllText(Paths.RulesFile,
                    JsonSerializer.Serialize(rules, new JsonSerializerOptions { WriteIndented = true }));
            }
            catch { }
        }
    }
}
