using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace SshAssistant.Data
{
    /// <summary>
    /// 凭据存储：用 Windows DPAPI（当前用户）加密后落盘。
    /// 对应 Android 版的 data/SecureStore.kt（那里用 Android Keystore）。
    /// DPAPI 的 ProtectedData.Protect 只有当前 Windows 用户能解密，
    /// 换用户/换机器即失效 —— 这与 Android Keystore 的语义一致。
    /// </summary>
    public static class CredentialStore
    {
        private static Dictionary<string, string> _map;

        private static Dictionary<string, string> Map
        {
            get
            {
                if (_map == null) _map = Load();
                return _map;
            }
        }

        private static Dictionary<string, string> Load()
        {
            try
            {
                if (File.Exists(Paths.CredFile))
                {
                    var blob = File.ReadAllBytes(Paths.CredFile);
                    var plain = ProtectedData.Unprotect(blob, null, DataProtectionScope.CurrentUser);
                    var json = Encoding.UTF8.GetString(plain);
                    return JsonSerializer.Deserialize<Dictionary<string, string>>(json)
                           ?? new Dictionary<string, string>();
                }
            }
            catch { }
            return new Dictionary<string, string>();
        }

        private static void Persist()
        {
            try
            {
                Directory.CreateDirectory(Paths.DataDir);
                var json = JsonSerializer.Serialize(Map);
                var plain = Encoding.UTF8.GetBytes(json);
                var blob = ProtectedData.Protect(plain, null, DataProtectionScope.CurrentUser);
                File.WriteAllBytes(Paths.CredFile, blob);
            }
            catch { }
        }

        public static string Get(string key)
        {
            return Map.TryGetValue(key, out var v) ? v : null;
        }

        public static void Put(string key, string value)
        {
            Map[key] = value;
            Persist();
        }

        public static void Remove(string key)
        {
            Map.Remove(key);
            Persist();
        }
    }
}
