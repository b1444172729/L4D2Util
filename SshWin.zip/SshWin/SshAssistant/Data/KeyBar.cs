using System;
using System.Collections.Generic;
using System.Linq;
using SshAssistant.Data;

namespace SshAssistant.Data
{
    /// <summary>
    /// 底部按键栏定义与顺序。对应 Android 版的 data/KeyBar.kt。
    /// 顺序可自定义并持久化；新增按键会自动追加到已保存顺序的末尾，
    /// 不会打乱用户已有的排列。
    /// </summary>
    public class KeyDef
    {
        public string Id { get; set; }
        public string Label { get; set; }
        /// <summary>直接发送的字节（UTF-8 字符串转义序列）</summary>
        public string Data { get; set; }
        /// <summary>修饰键：下一次按键前先按下（如 Ctrl）</summary>
        public bool IsModifier { get; set; }

        public byte[] Bytes =>
            Data == null ? new byte[0] : System.Text.Encoding.UTF8.GetBytes(Unescape(Data));

        private static string Unescape(string s)
        {
            return s.Replace("\\e", "\x1b").Replace("\\r", "\r").Replace("\\n", "\n").Replace("\\t", "\t");
        }
    }

    public static class KeyBar
    {
        public static readonly List<KeyDef> All = new List<KeyDef>
        {
            new KeyDef { Id = "esc",    Label = "Esc",    Data = "\\e" },
            new KeyDef { Id = "ctrl",   Label = "Ctrl",   IsModifier = true },
            new KeyDef { Id = "alt",    Label = "Alt",    Data = "\\ea" },
            new KeyDef { Id = "tab",    Label = "Tab",    Data = "\\t" },
            new KeyDef { Id = "up",     Label = "↑",      Data = "\\e[A" },
            new KeyDef { Id = "down",   Label = "↓",      Data = "\\e[B" },
            new KeyDef { Id = "left",   Label = "←",      Data = "\\e[D" },
            new KeyDef { Id = "right",  Label = "→",      Data = "\\e[C" },
            new KeyDef { Id = "home",   Label = "Home",   Data = "\\e[H" },
            new KeyDef { Id = "end",    Label = "End",    Data = "\\e[F" },
            new KeyDef { Id = "pgup",   Label = "PgUp",   Data = "\\e[5~" },
            new KeyDef { Id = "pgdn",   Label = "PgDn",   Data = "\\e[6~" },
            new KeyDef { Id = "del",    Label = "Del",    Data = "\\e[3~" },
            new KeyDef { Id = "dot",    Label = ".",      Data = "." },
            new KeyDef { Id = "slash",  Label = "/",      Data = "/" },
            new KeyDef { Id = "copy",   Label = "复制",   Data = "" },
            new KeyDef { Id = "paste",  Label = "粘贴",   Data = "" },
            new KeyDef { Id = "enter",  Label = "回车",   Data = "\\r" },
            new KeyDef { Id = "clear",  Label = "清屏",   Data = "" },
        };

        public static KeyDef Def(string id) => All.FirstOrDefault(k => k.Id == id);

        /// <summary>
        /// 当前顺序。已保存列表中缺失的新按键自动追加，失效 id 自动剔除。
        /// </summary>
        public static List<string> Order()
        {
            var saved = AppSettings.Load().KeyBarOrder;
            var result = new List<string>();
            if (saved != null)
                foreach (var id in saved)
                    if (Def(id) != null && !result.Contains(id)) result.Add(id);
            foreach (var k in All)
                if (!result.Contains(k.Id)) result.Add(k.Id);
            return result;
        }

        public static void SaveOrder(List<string> ids)
        {
            var s = AppSettings.Load();
            s.KeyBarOrder = ids;
            s.Save();
        }

        public static void ResetOrder()
        {
            var s = AppSettings.Load();
            s.KeyBarOrder = new List<string>();
            s.Save();
        }
    }
}
