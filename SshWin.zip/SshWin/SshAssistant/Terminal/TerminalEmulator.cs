using System;
using System.Collections.Generic;
using System.Text;

namespace SshAssistant.Terminal
{
    /// <summary>
    /// VT100 / ANSI / xterm 终端模拟器：字符网格 + 颜色属性、滚动区域、
    /// 回滚缓冲、UTF-8、宽字符（CJK / emoji）支持。
    ///
    /// 这是 Android 版 term/TerminalEmulator.kt 的逐行移植 ——
    /// 状态机、属性编码、调色板完全保持一致，因此两边的终端观感与行为相同。
    /// 纯 C# 实现，不依赖 WebView、conpty 或任何 native 代码。
    /// </summary>
    public class TerminalEmulator
    {
        // ---------- 属性标志位（与 Android 版一致） ----------
        public const int F_BOLD = 1 << 16;
        public const int F_FAINT = 1 << 17;
        public const int F_ITALIC = 1 << 18;
        public const int F_UNDERLINE = 1 << 19;
        public const int F_BLINK = 1 << 20;
        public const int F_REVERSE = 1 << 21;
        public const int F_INVISIBLE = 1 << 22;
        public const int F_WIDE = 1 << 23;        // 宽字符第一格
        public const int F_WIDE_CONT = 1 << 24;   // 宽字符续格（绘制/复制时跳过）

        public const int DEFAULT_FG = 7;
        public const int DEFAULT_BG = 0;

        public const int ST_GROUND = 0;
        public const int ST_ESC = 1;
        public const int ST_CSI = 2;
        public const int ST_OSC = 3;

        public static int MakeAttr(int fg, int bg, int flags) => (fg & 0xFF) | ((bg & 0xFF) << 8) | flags;
        public static int FgOf(int attr) => attr & 0xFF;
        public static int BgOf(int attr) => (attr >> 8) & 0xFF;

        // ---------- 行缓冲 ----------
        public class Line
        {
            public char[] Text;
            public int[] Attr;

            public Line(int cols)
            {
                Text = new char[cols];
                Attr = new int[cols];
            }

            public void Fill(char ch, int a)
            {
                for (int i = 0; i < Text.Length; i++) { Text[i] = ch; Attr[i] = a; }
            }

            /// <summary>列数变化时保留原有内容</summary>
            public void CopyFrom(Line o)
            {
                int n = Math.Min(Text.Length, o.Text.Length);
                for (int i = 0; i < Text.Length; i++)
                {
                    if (i < n) { Text[i] = o.Text[i]; Attr[i] = o.Attr[i]; }
                    else { Text[i] = ' '; Attr[i] = MakeAttr(DEFAULT_FG, DEFAULT_BG, 0); }
                }
            }
        }

        public int Cols { get; private set; }
        public int Rows { get; private set; }
        public int MaxScrollback { get; private set; }

        private readonly List<Line> _screen = new List<Line>();
        private readonly List<Line> _scrollback = new List<Line>();

        // ---------- 光标与状态 ----------
        public int Cx;
        public int Cy;
        private int _savedCx, _savedCy;
        private int _savedAttr = MakeAttr(DEFAULT_FG, DEFAULT_BG, 0);

        private int _fg = DEFAULT_FG;
        private int _bg = DEFAULT_BG;
        private int _flags;
        private int _currentAttr = MakeAttr(DEFAULT_FG, DEFAULT_BG, 0);
        private bool _wrapPending;

        public int ScrollTop;
        public int ScrollBottom;
        private bool _originMode;
        public bool AutoWrap = true;
        public bool CursorVisible = true;
        public bool BracketedPaste;

        public string Title;
        public Action<string> OnTitleChanged;
        public Action OnBell;

        /// <summary>
        /// 内容变化通知。必须是【事件】而不是普通委托字段：
        /// TerminalView 与 SessionWindow 都要监听，用普通字段的话
        /// 后一次赋值会覆盖前一次，导致终端不再刷新。
        /// </summary>
        public event Action OnContentChanged;

        private int _state = ST_GROUND;
        private int _csiCount;
        private bool _csiQuestion;
        private readonly int[] _csiParams = new int[16];
        private readonly StringBuilder _oscBuf = new StringBuilder();

        // UTF-8 多字节收集
        private int _uNeed;
        private int _uLen;
        private readonly byte[] _uBuf = new byte[4];

        private readonly object _lock = new object();

        public TerminalEmulator(int cols, int rows, int maxScrollback = 3000)
        {
            Cols = Math.Max(1, cols);
            Rows = Math.Max(1, rows);
            MaxScrollback = Math.Max(0, maxScrollback);
            ScrollTop = 0;
            ScrollBottom = Rows - 1;
            for (int i = 0; i < Rows; i++) _screen.Add(NewBlankLine());
        }

        private Line NewBlankLine()
        {
            var l = new Line(Cols);
            l.Fill(' ', _currentAttr);
            return l;
        }

        private int MakeAttrNow() => MakeAttr(_fg, _bg, _flags);

        public int ScrollbackCount => _scrollback.Count;
        public int TotalLines => _scrollback.Count + Rows;

        /// <summary>按缓冲区绝对行号取行（0 = 最早的历史行）</summary>
        public Line GetBufferedLine(int index)
        {
            if (index < 0) index = 0;
            if (index >= TotalLines) index = TotalLines - 1;
            if (index < _scrollback.Count) return _scrollback[index];
            return _screen[index - _scrollback.Count];
        }

        public Line ScreenLine(int r) => _screen[Math.Clamp(r, 0, Rows - 1)];
        public int CursorBufferLine() => _scrollback.Count + Cy;

        public void Reset()
        {
            _fg = DEFAULT_FG; _bg = DEFAULT_BG; _flags = 0;
            _currentAttr = MakeAttrNow();
            Cx = 0; Cy = 0;
            ScrollTop = 0; ScrollBottom = Rows - 1;
            _originMode = false;
            AutoWrap = true;
            CursorVisible = true;
            _wrapPending = false;
            for (int r = 0; r < Rows; r++) _screen[r].Fill(' ', _currentAttr);
            _state = ST_GROUND;
        }

        public void ClearScrollback()
        {
            _scrollback.Clear();
            NotifyChanged();
        }

        public void ClearScreen()
        {
            var blank = MakeAttrNow();
            for (int r = 0; r < Rows; r++) _screen[r].Fill(' ', blank);
            Cx = 0; Cy = 0;
            NotifyChanged();
        }

        public void Resize(int newCols, int newRows)
        {
            newCols = Math.Max(1, newCols);
            newRows = Math.Max(1, newRows);
            if (newCols == Cols && newRows == Rows) return;

            if (newCols != Cols)
            {
                var newScreen = new List<Line>();
                for (int r = 0; r < Rows; r++)
                {
                    var nl = new Line(newCols);
                    nl.CopyFrom(_screen[r]);
                    newScreen.Add(nl);
                }
                // 回滚区同步改列宽（保留原有内容）
                for (int i = 0; i < _scrollback.Count; i++)
                {
                    var nl = new Line(newCols);
                    nl.CopyFrom(_scrollback[i]);
                    _scrollback[i] = nl;
                }
                _screen.Clear();
                _screen.AddRange(newScreen);
                Cols = newCols;
            }

            if (newRows != Rows)
            {
                while (_screen.Count < newRows) _screen.Add(NewBlankLine());
                while (_screen.Count > newRows)
                {
                    // 多出来的屏幕行推入回滚，避免丢内容
                    PushScrollback(_screen[0]);
                    _screen.RemoveAt(0);
                }
                Rows = newRows;
                ScrollTop = 0;
                ScrollBottom = Rows - 1;
            }

            Cx = Math.Clamp(Cx, 0, Cols - 1);
            Cy = Math.Clamp(Cy, 0, Rows - 1);
            _wrapPending = false;
            NotifyChanged();
        }

        private void PushScrollback(Line l)
        {
            _scrollback.Add(l);
            while (_scrollback.Count > MaxScrollback) _scrollback.RemoveAt(0);
        }

        /// <summary>运行时调整回滚上限（设置即时生效）</summary>
        public void ApplyMaxScrollback(int n)
        {
            MaxScrollback = Math.Max(0, n);
            while (_scrollback.Count > MaxScrollback) _scrollback.RemoveAt(0);
        }

        // ---------- 数据写入 ----------

        public void Write(byte[] data, int length = -1)
        {
            if (length < 0) length = data.Length;
            lock (_lock)
            {
                for (int i = 0; i < length; i++) ProcessByte(data[i]);
                NotifyChanged();
            }
        }

        public void WriteString(string s)
        {
            Write(Encoding.UTF8.GetBytes(s));
        }

        private void ProcessByte(byte b)
        {
            if (_uNeed > 0)
            {
                _uBuf[_uLen++] = b;
                if (_uLen >= _uNeed)
                {
                    var s = Encoding.UTF8.GetString(_uBuf, 0, _uNeed);
                    _uNeed = 0; _uLen = 0;
                    if (s.Length > 0) PrintString(s);
                }
                return;
            }

            switch (_state)
            {
                case ST_GROUND:
                    if (b >= 0x80)
                    {
                        if (b >= 0xF0) _uNeed = 4;
                        else if (b >= 0xE0) _uNeed = 3;
                        else if (b >= 0xC0) _uNeed = 2;
                        else _uNeed = 0;
                        if (_uNeed == 0) return;
                        _uLen = 1;
                        _uBuf[0] = b;
                    }
                    else if (b == 0x1B) _state = ST_ESC;
                    else if (b == 0x0D) { Cx = 0; _wrapPending = false; }
                    else if (b == 0x0A) Newline(false);
                    else if (b == 0x09) TabForward(1);
                    else if (b == 0x08) { if (Cx > 0) Cx--; _wrapPending = false; }
                    else if (b == 0x07) OnBell?.Invoke();
                    else if (b == 0x0E || b == 0x0F || b == 0x00) { }
                    else if (b < 0x20) { }
                    else PrintString(((char)b).ToString());
                    break;

                case ST_ESC:
                    switch ((char)b)
                    {
                        case '[':
                            _state = ST_CSI;
                            _csiCount = 0;
                            _csiQuestion = false;
                            for (int i = 0; i < _csiParams.Length; i++) _csiParams[i] = -1;
                            break;
                        case ']':
                            _state = ST_OSC;
                            _oscBuf.Clear();
                            break;
                        case '7':
                            _savedCx = Cx; _savedCy = Cy; _savedAttr = _currentAttr;
                            _state = ST_GROUND;
                            break;
                        case '8':
                            Cx = _savedCx; Cy = _savedCy; _currentAttr = _savedAttr;
                            RestoreAttrFromCurrent();
                            _state = ST_GROUND;
                            break;
                        case 'D': Newline(false); _state = ST_GROUND; break;
                        case 'E': Newline(true); _state = ST_GROUND; break;
                        case 'M': ReverseIndex(); _state = ST_GROUND; break;
                        case 'c': Reset(); _state = ST_GROUND; break;
                        default: _state = ST_GROUND; break;  // 字符集/keypad/DECALN 等，忽略
                    }
                    break;

                case ST_CSI:
                    CollectCsi(b);
                    break;

                case ST_OSC:
                    if (b == 0x07 || b == 0x1B) FinishOsc();
                    else
                    {
                        _oscBuf.Append((char)b);
                        if (_oscBuf.Length > 512) FinishOsc();
                    }
                    break;
            }
        }

        private void FinishOsc()
        {
            var s = _oscBuf.ToString();
            int semi = s.IndexOf(';');
            if (semi > 0)
            {
                var kind = s.Substring(0, semi);
                if (kind == "0" || kind == "1" || kind == "2")
                {
                    Title = s.Substring(semi + 1);
                    OnTitleChanged?.Invoke(Title);
                }
            }
            _oscBuf.Clear();
            _state = ST_GROUND;
        }

        private void CollectCsi(byte b)
        {
            char c = (char)b;
            if (c >= '0' && c <= '9')
            {
                int idx = (_csiCount == 0) ? 0 : _csiCount - 1;
                if (idx < _csiParams.Length)
                {
                    int cur = _csiParams[idx] < 0 ? 0 : _csiParams[idx];
                    _csiParams[idx] = cur * 10 + (c - '0');
                    if (_csiCount == 0) _csiCount = 1;
                }
            }
            else if (c == ';')
            {
                _csiCount++;
                if (_csiCount <= _csiParams.Length) _csiParams[_csiCount - 1] = -1;
            }
            else if (c == '?') _csiQuestion = true;
            else if (c == ' ' || c == '!' || c == '"' || c == '$' || c == '\'') { }
            else
            {
                DispatchCsi(c);
                _state = ST_GROUND;
            }
        }

        private int P(int i, int def)
        {
            int v = (i < _csiCount) ? _csiParams[i] : -1;
            return v < 0 ? def : v;
        }

        private void DispatchCsi(char c)
        {
            switch (c)
            {
                case '@': InsertChars(P(0, 1)); break;
                case 'A': Cy = Math.Max(ScrollTop, Cy - P(0, 1)); _wrapPending = false; break;
                case 'B':
                case 'e': Cy = Math.Min(ScrollBottom, Cy + P(0, 1)); _wrapPending = false; break;
                case 'C':
                case 'a': Cx = Math.Min(Cols - 1, Cx + P(0, 1)); _wrapPending = false; break;
                case 'D': Cx = Math.Max(0, Cx - P(0, 1)); _wrapPending = false; break;
                case 'E': Cy = Math.Min(ScrollBottom, Cy + P(0, 1)); Cx = 0; _wrapPending = false; break;
                case 'F': Cy = Math.Max(ScrollTop, Cy - P(0, 1)); Cx = 0; _wrapPending = false; break;
                case 'G':
                case '`': Cx = Math.Clamp(P(0, 1) - 1, 0, Cols - 1); _wrapPending = false; break;
                case 'H':
                case 'f':
                    {
                        int r = P(0, 1) - 1;
                        Cy = _originMode ? Math.Clamp(ScrollTop + r, ScrollTop, ScrollBottom)
                                         : Math.Clamp(r, 0, Rows - 1);
                        Cx = Math.Clamp(P(1, 1) - 1, 0, Cols - 1);
                        _wrapPending = false;
                    }
                    break;
                case 'I': TabForward(P(0, 1)); break;
                case 'J': EraseInDisplay(P(0, 0)); break;
                case 'K': EraseInLine(P(0, 0)); break;
                case 'L': InsertLines(P(0, 1)); break;
                case 'M': DeleteLines(P(0, 1)); break;
                case 'P': DeleteChars(P(0, 1)); break;
                case 'S': ScrollUp(P(0, 1)); break;
                case 'T': ScrollDown(P(0, 1)); break;
                case 'X': EraseChars(P(0, 1)); break;
                case 'Z': TabBackward(P(0, 1)); break;
                case 'd': Cy = Math.Clamp(P(0, 1) - 1, 0, Rows - 1); _wrapPending = false; break;
                case 'h': SetMode(true); break;
                case 'l': SetMode(false); break;
                case 'm': Sgr(); break;
                case 'r':
                    {
                        int top = P(0, 1) - 1;
                        int bot = P(1, Rows) - 1;
                        ScrollTop = Math.Clamp(top, 0, Rows - 1);
                        ScrollBottom = Math.Clamp(bot, ScrollTop, Rows - 1);
                        Cx = 0; Cy = _originMode ? ScrollTop : 0;
                        _wrapPending = false;
                    }
                    break;
                case 's': _savedCx = Cx; _savedCy = Cy; break;
                case 'u': Cx = _savedCx; Cy = _savedCy; _wrapPending = false; break;
                default: break;
            }
        }

        private void RestoreAttrFromCurrent()
        {
            _fg = FgOf(_currentAttr);
            _bg = BgOf(_currentAttr);
            _flags = _currentAttr & 0xFF0000;
        }

        private void SetMode(bool enable)
        {
            if (!_csiQuestion) return;
            for (int i = 0; i < _csiCount; i++)
            {
                switch (_csiParams[i])
                {
                    case 6:
                        _originMode = enable;
                        Cx = 0;
                        Cy = enable ? ScrollTop : 0;
                        break;
                    case 7: AutoWrap = enable; break;
                    case 25: CursorVisible = enable; break;
                    case 2004: BracketedPaste = enable; break;
                    case 1047:
                    case 1049:
                        _scrollback.Clear();
                        for (int r = 0; r < Rows; r++) _screen[r].Fill(' ', MakeAttrNow());
                        break;
                }
            }
        }

        private void Sgr()
        {
            if (_csiCount == 0)
            {
                _fg = DEFAULT_FG; _bg = DEFAULT_BG; _flags = 0;
                _currentAttr = MakeAttrNow();
                return;
            }
            int i = 0;
            while (i < _csiCount)
            {
                int v = _csiParams[i];
                switch (v)
                {
                    case 0: _fg = DEFAULT_FG; _bg = DEFAULT_BG; _flags = 0; break;
                    case 1: _flags |= F_BOLD; break;
                    case 2: _flags |= F_FAINT; break;
                    case 3: _flags |= F_ITALIC; break;
                    case 4: _flags |= F_UNDERLINE; break;
                    case 5: _flags |= F_BLINK; break;
                    case 7: _flags |= F_REVERSE; break;
                    case 8: _flags |= F_INVISIBLE; break;
                    case 21:
                    case 22: _flags &= ~(F_BOLD | F_FAINT); break;
                    case 23: _flags &= ~F_ITALIC; break;
                    case 24: _flags &= ~F_UNDERLINE; break;
                    case 25: _flags &= ~F_BLINK; break;
                    case 27: _flags &= ~F_REVERSE; break;
                    case 28: _flags &= ~F_INVISIBLE; break;
                    case 38: i += ReadColor(i); break;
                    case 48: i += ReadColor(i); break;
                    case 39: _fg = DEFAULT_FG; break;
                    case 49: _bg = DEFAULT_BG; break;
                    default:
                        if (v >= 30 && v <= 37) _fg = v - 30;
                        else if (v >= 40 && v <= 47) _bg = v - 40;
                        else if (v >= 90 && v <= 97) _fg = v - 90 + 8;
                        else if (v >= 100 && v <= 107) _bg = v - 100 + 8;
                        break;
                }
                i++;
            }
            _currentAttr = MakeAttrNow();
        }

        /// <summary>返回还需要跳过的参数个数</summary>
        private int ReadColor(int i)
        {
            if (i + 1 >= _csiCount) return 0;
            switch (_csiParams[i + 1])
            {
                case 5:
                    if (i + 2 < _csiCount)
                    {
                        int idx = Math.Clamp(_csiParams[i + 2], 0, 255);
                        if (_csiParams[i] == 38) _fg = idx; else _bg = idx;
                    }
                    return 2;
                case 2:
                    if (i + 4 < _csiCount)
                    {
                        int r = Math.Clamp(_csiParams[i + 2], 0, 255);
                        int g = Math.Clamp(_csiParams[i + 3], 0, 255);
                        int b = Math.Clamp(_csiParams[i + 4], 0, 255);
                        int idx = RgbToIndex(r, g, b);
                        if (_csiParams[i] == 38) _fg = idx; else _bg = idx;
                    }
                    return 4;
                default: return 1;
            }
        }

        private int RgbToIndex(int r, int g, int b)
        {
            if (r == g && g == b)
            {
                if (r < 8) return 16;
                if (r > 248) return 231;
                return 232 + (r - 8) * 24 / 247;
            }
            return 16 + 36 * CubeIndex(r) + 6 * CubeIndex(g) + CubeIndex(b);
        }

        private static int CubeIndex(int v)
        {
            int[] levels = { 0, 0x5F, 0x87, 0xAF, 0xD7, 0xFF };
            int best = 0, bestDiff = int.MaxValue;
            for (int i = 0; i < levels.Length; i++)
            {
                int d = Math.Abs(v - levels[i]);
                if (d < bestDiff) { bestDiff = d; best = i; }
            }
            return best;
        }

        // ---------- 编辑操作 ----------

        private void PrintString(string s)
        {
            int idx = 0;
            while (idx < s.Length)
            {
                int cp = char.ConvertToUtf32(s, idx);
                int charCount = char.IsHighSurrogate(s[idx]) && idx + 1 < s.Length ? 2 : 1;
                var str = s.Substring(idx, charCount);
                PutGlyph(str, IsWide(cp) ? 2 : 1);
                idx += charCount;
            }
        }

        private void PutGlyph(string str, int w)
        {
            if (_wrapPending)
            {
                Cx = 0;
                Newline(false);
                _wrapPending = false;
            }
            if (Cx + w > Cols)
            {
                Cx = 0;
                Newline(false);
            }
            var line = _screen[Cy];
            int a = MakeAttrNow();
            line.Text[Cx] = str[0];
            line.Attr[Cx] = a | (w == 2 ? F_WIDE : 0);
            if (w == 2 && Cx + 1 < Cols)
            {
                // 宽字符第二格：emoji 用低代理填充，CJK 用空格占位
                line.Text[Cx + 1] = str.Length > 1 ? str[1] : ' ';
                line.Attr[Cx + 1] = a | F_WIDE_CONT;
            }
            Cx += w;
            if (Cx >= Cols)
            {
                Cx = Cols - 1;
                _wrapPending = AutoWrap;
            }
        }

        private void Newline(bool carriageReturn)
        {
            if (Cy == ScrollBottom) ScrollUp(1);
            else if (Cy < Rows - 1) Cy++;
            if (carriageReturn) Cx = 0;
            _wrapPending = false;
        }

        private void ReverseIndex()
        {
            if (Cy == ScrollTop) ScrollDown(1);
            else if (Cy > 0) Cy--;
            _wrapPending = false;
        }

        private void TabForward(int n)
        {
            for (int k = 0; k < n; k++)
            {
                int next = ((Cx / 8) + 1) * 8;
                Cx = next >= Cols ? Cols - 1 : next;
            }
            _wrapPending = false;
        }

        private void TabBackward(int n)
        {
            for (int k = 0; k < n; k++)
            {
                int t = (Cx / 8) * 8;
                if (t == Cx && Cx > 0) t -= 8;
                Cx = Math.Max(0, t);
            }
            _wrapPending = false;
        }

        public void ScrollUp(int n)
        {
            int times = Math.Min(n, ScrollBottom - ScrollTop + 1);
            for (int k = 0; k < times; k++)
            {
                var l = _screen[ScrollTop];
                _screen.RemoveAt(ScrollTop);
                PushScrollback(l);
                _screen.Insert(ScrollBottom, NewBlankLine());
            }
        }

        public void ScrollDown(int n)
        {
            int times = Math.Min(n, ScrollBottom - ScrollTop + 1);
            for (int k = 0; k < times; k++)
            {
                _screen.RemoveAt(ScrollBottom);
                _screen.Insert(ScrollTop, NewBlankLine());
            }
        }

        private void EraseInDisplay(int mode)
        {
            var blank = MakeAttrNow();
            switch (mode)
            {
                case 0:
                    EraseInLine(0);
                    for (int r = Cy + 1; r < Rows; r++) _screen[r].Fill(' ', blank);
                    break;
                case 1:
                    for (int r = 0; r < Cy; r++) _screen[r].Fill(' ', blank);
                    EraseInLine(1);
                    break;
                case 2:
                    for (int r = 0; r < Rows; r++) _screen[r].Fill(' ', blank);
                    break;
            }
        }

        private void EraseInLine(int mode)
        {
            var line = _screen[Cy];
            var blank = MakeAttrNow();
            switch (mode)
            {
                case 0:
                    for (int i = Cx; i < Cols; i++) { line.Text[i] = ' '; line.Attr[i] = blank; }
                    break;
                case 1:
                    for (int i = 0; i <= Cx && i < Cols; i++) { line.Text[i] = ' '; line.Attr[i] = blank; }
                    break;
                case 2:
                    line.Fill(' ', blank);
                    break;
            }
            _wrapPending = false;
        }

        private void EraseChars(int n)
        {
            var line = _screen[Cy];
            var blank = MakeAttrNow();
            int end = Math.Min(Cols, Cx + n);
            for (int i = Cx; i < end; i++) { line.Text[i] = ' '; line.Attr[i] = blank; }
            _wrapPending = false;
        }

        private void InsertChars(int n)
        {
            var line = _screen[Cy];
            n = Math.Min(n, Cols - Cx);
            for (int i = Cols - 1; i >= Cx + n; i--)
            {
                line.Text[i] = line.Text[i - n];
                line.Attr[i] = line.Attr[i - n];
            }
            var blank = MakeAttrNow();
            for (int i = Cx; i < Cx + n; i++) { line.Text[i] = ' '; line.Attr[i] = blank; }
            _wrapPending = false;
        }

        private void DeleteChars(int n)
        {
            var line = _screen[Cy];
            n = Math.Min(n, Cols - Cx);
            for (int i = Cx; i + n < Cols; i++)
            {
                line.Text[i] = line.Text[i + n];
                line.Attr[i] = line.Attr[i + n];
            }
            var blank = MakeAttrNow();
            for (int i = Cols - n; i < Cols; i++) { line.Text[i] = ' '; line.Attr[i] = blank; }
            _wrapPending = false;
        }

        private void InsertLines(int n)
        {
            n = Math.Min(n, ScrollBottom - Cy + 1);
            var blank = MakeAttrNow();
            for (int k = 0; k < n; k++)
            {
                _screen.Insert(Cy, NewBlankLine());
                _screen.RemoveAt(ScrollBottom + 1);
            }
        }

        private void DeleteLines(int n)
        {
            n = Math.Min(n, ScrollBottom - Cy + 1);
            for (int k = 0; k < n; k++)
            {
                _screen.RemoveAt(Cy);
                var l = new Line(Cols);
                l.Fill(' ', MakeAttrNow());
                _screen.Insert(ScrollBottom, l);
            }
        }

        private void NotifyChanged()
        {
            OnContentChanged?.Invoke();
        }

        // ---------- 调色板 ----------

        private static readonly int[] BaseDark =
        {
            unchecked((int)0xFF000000), unchecked((int)0xFFCC0000), unchecked((int)0xFF4E9A06), unchecked((int)0xFFC4A000),
            unchecked((int)0xFF3465A4), unchecked((int)0xFF75507B), unchecked((int)0xFF06989A), unchecked((int)0xFFD3D7CF),
            unchecked((int)0xFF555753), unchecked((int)0xFFEF2929), unchecked((int)0xFF8AE234), unchecked((int)0xFFFCE94F),
            unchecked((int)0xFF729FCF), unchecked((int)0xFFAD7FA8), unchecked((int)0xFF34E2E2), unchecked((int)0xFFEEEEEC)
        };

        private static readonly int[] BaseLight =
        {
            unchecked((int)0xFFFAFAFA), unchecked((int)0xFFB00020), unchecked((int)0xFF1B5E20), unchecked((int)0xFF7A5C00),
            unchecked((int)0xFF0D47A1), unchecked((int)0xFF4A148C), unchecked((int)0xFF006064), unchecked((int)0xFF212121),
            unchecked((int)0xFF616161), unchecked((int)0xFFD32F2F), unchecked((int)0xFF388E3C), unchecked((int)0xFFAF9000),
            unchecked((int)0xFF1565C0), unchecked((int)0xFF6A1B9A), unchecked((int)0xFF00838F), unchecked((int)0xFF424242)
        };

        /// <summary>256 色调色板</summary>
        public static readonly int[] Palette = BuildPalette();

        private static bool _lightTheme;

        public static bool LightTheme => _lightTheme;

        /// <summary>
        /// 切换终端配色跟随应用主题。只替换前 16 色（默认前景/背景在其中），
        /// 216 色立方与灰度阶保持不变 —— 它们本身是完整色域，深浅通用。
        /// </summary>
        public static void SetLightTheme(bool light)
        {
            if (_lightTheme == light) return;
            _lightTheme = light;
            Array.Copy(light ? BaseLight : BaseDark, 0, Palette, 0, 16);
        }

        private static int[] BuildPalette()
        {
            var p = new int[256];
            Array.Copy(BaseDark, 0, p, 0, 16);
            int[] levels = { 0, 0x5F, 0x87, 0xAF, 0xD7, 0xFF };
            int i = 16;
            for (int r = 0; r < 6; r++)
                for (int g = 0; g < 6; g++)
                    for (int b = 0; b < 6; b++)
                        p[i++] = unchecked((int)0xFF000000) | (levels[r] << 16) | (levels[g] << 8) | levels[b];
            int v = 8;
            while (i < 256)
            {
                p[i++] = unchecked((int)0xFF000000) | (v << 16) | (v << 8) | v;
                v += 10;
            }
            return p;
        }

        /// <summary>粗略的东亚宽字符 / emoji 判断</summary>
        public static bool IsWide(int cp)
        {
            if (cp >= 0x1100 && cp <= 0x115F) return true;
            if (cp == 0x2329 || cp == 0x232A) return true;
            if (cp >= 0x2E80 && cp <= 0xA4CF) return true;
            if (cp >= 0xAC00 && cp <= 0xD7A3) return true;
            if (cp >= 0xF900 && cp <= 0xFAFF) return true;
            if (cp >= 0xFE10 && cp <= 0xFE19) return true;
            if (cp >= 0xFE30 && cp <= 0xFE6F) return true;
            if (cp >= 0xFF00 && cp <= 0xFF60) return true;
            if (cp >= 0xFFE0 && cp <= 0xFFE6) return true;
            if (cp >= 0x1F300 && cp <= 0x1F64F) return true;
            if (cp >= 0x1F900 && cp <= 0x1F9FF) return true;
            if (cp >= 0x20000 && cp <= 0x3FFFD) return true;
            return false;
        }
    }
}
