using System;
using System.Collections.Generic;
using System.Globalization;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.TextFormatting;

namespace SshAssistant.Terminal
{
    /// <summary>
    /// 终端渲染控件：自绘字符网格，不依赖任何 WebView / conpty。
    /// 对应 Android 版的 term/TerminalView.kt —— 滚动方向、边界、
    /// 选择逻辑均保持一致。
    /// </summary>
    public class TerminalView : FrameworkElement
    {
        private TerminalEmulator _emu;
        private Typeface _typeface = new Typeface("Consolas");
        private double _fontSize = 14;
        private double _cellW = 8;
        private double _cellH = 16;
        private double _ascent;

        /// <summary>距最新内容的行数：0 = 贴底（跟随新输出）</summary>
        private int _scrollOffset;
        private bool _autoFollow = true;

        // 选择
        private bool _selecting;
        private int _selStartBuf, _selStartCol;
        private int _selEndBuf, _selEndCol;
        private bool _hasSelection;

        public Action<byte[]> OnUserInput;
        public Action<int> OnScrollOffsetChanged;

        public TerminalView()
        {
            ClipToBounds = true;
            Focusable = true;
            SnapsToDevicePixels = true;
            UseLayoutRounding = true;
            Cursor = Cursors.IBeam;
            Loaded += (s, e) => StartCaretTimer();
            Unloaded += (s, e) => StopCaretTimer();
        }

        public TerminalEmulator Emulator
        {
            get => _emu;
            set
            {
                if (_emu != null) _emu.OnContentChanged -= OnContent;
                _emu = value;
                if (_emu != null) _emu.OnContentChanged += OnContent;
                MeasureCell();
                InvalidateVisual();
            }
        }

        public double FontSizePx
        {
            get => _fontSize;
            set
            {
                _fontSize = Math.Clamp(value, 6, 40);
                MeasureCell();
                InvalidateVisual();
            }
        }

        public string FontFamilyName
        {
            set
            {
                _typeface = new Typeface(new FontFamily(value), FontStyles.Normal, FontWeights.Normal, FontStretches.Normal);
                MeasureCell();
                InvalidateVisual();
            }
        }

        private void MeasureCell()
        {
            var ft = new FormattedText("M", CultureInfo.CurrentUICulture, FlowDirection.LeftToRight,
                _typeface, _fontSize, Brushes.White, 1.0);
            _cellW = ft.Width;
            _cellH = Math.Ceiling(_fontSize * 1.35);
            _ascent = ft.Baseline;
            InvalidateMeasure();
        }

        private void OnContent()
        {
            // 贴底时自动跟随；在回滚区看历史时保持视野不动（避免文本自己跑）
            if (_autoFollow) _scrollOffset = 0;
            Dispatcher.BeginInvoke(new Action(InvalidateVisual));
        }

        public int ScrollOffset
        {
            get => _scrollOffset;
            set
            {
                int max = MaxOffset();
                _scrollOffset = Math.Clamp(value, 0, max);
                _autoFollow = (_scrollOffset == 0);
                OnScrollOffsetChanged?.Invoke(_scrollOffset);
                InvalidateVisual();
            }
        }

        private int MaxOffset()
        {
            if (_emu == null) return 0;
            return Math.Max(0, _emu.ScrollbackCount);
        }

        // ---------- 布局 ----------
        protected override Size MeasureOverride(Size availableSize)
        {
            double w = double.IsInfinity(availableSize.Width) ? 800 : availableSize.Width;
            double h = double.IsInfinity(availableSize.Height) ? 480 : availableSize.Height;
            return new Size(w, h);
        }

        protected override Size ArrangeOverride(Size finalSize)
        {
            if (_emu != null && _cellW > 0 && _cellH > 0)
            {
                int cols = Math.Max(20, (int)(finalSize.Width / _cellW));
                int rows = Math.Max(4, (int)(finalSize.Height / _cellH));
                if (cols != _emu.Cols || rows != _emu.Rows) _emu.Resize(cols, rows);
            }
            return base.ArrangeOverride(finalSize);
        }

        // ---------- 绘制 ----------
        private bool _caretOn = true;
        private System.Windows.Threading.DispatcherTimer _caretTimer;

        private void StartCaretTimer()
        {
            StopCaretTimer();
            _caretTimer = new System.Windows.Threading.DispatcherTimer
            { Interval = TimeSpan.FromMilliseconds(530) };
            _caretTimer.Tick += (s, e) => { _caretOn = !_caretOn; InvalidateVisual(); };
            _caretTimer.Start();
        }

        private void StopCaretTimer()
        {
            _caretTimer?.Stop();
            _caretTimer = null;
        }

        protected override void OnRender(DrawingContext dc)
        {
            if (_emu == null) return;
            var bg0 = ColorFromPalette(TerminalEmulator.BgOf(
                TerminalEmulator.MakeAttr(TerminalEmulator.DEFAULT_FG, TerminalEmulator.DEFAULT_BG, 0)));
            dc.DrawRectangle(new SolidColorBrush(bg0), null, new Rect(0, 0, ActualWidth, ActualHeight));

            int rows = _emu.Rows, cols = _emu.Cols;
            int total = _emu.TotalLines;
            int firstLine = total - rows - _scrollOffset;   // 缓冲区绝对起始行

            for (int r = 0; r < rows; r++)
            {
                int abs = firstLine + r;
                if (abs < 0 || abs >= total) continue;
                var line = _emu.GetBufferedLine(abs);
                double y = r * _cellH;
                DrawLine(dc, line, cols, y, abs);
            }

            // 光标
            if (_emu.CursorVisible && _scrollOffset == 0 && _caretOn)
            {
                int cx = _emu.Cx, cy = _emu.Cy;
                if (cx < cols && cy < rows)
                {
                    var cur = TerminalEmulator.Palette[7];
                    var brush = new SolidColorBrush(ColorFromArgb(cur));
                    dc.DrawRectangle(brush, null,
                        new Rect(cx * _cellW, cy * _cellH + 1, Math.Max(2, _cellW * 0.9), _cellH - 2));
                }
            }

            // 选择高亮（半透明覆盖）
            if (_hasSelection) DrawSelection(dc, firstLine, rows, cols);
        }

        private void DrawLine(DrawingContext dc, TerminalEmulator.Line line, int cols, double y, int absLine)
        {
            int i = 0;
            while (i < cols)
            {
                int a = line.Attr[i];
                // 合并连续相同属性的字符，减少 DrawText 调用
                int j = i + 1;
                while (j < cols && line.Attr[j] == a) j++;

                // 取出文本（跳过宽字符续格）
                var sb = new System.Text.StringBuilder();
                for (int k = i; k < j; k++)
                {
                    if ((line.Attr[k] & TerminalEmulator.F_WIDE_CONT) != 0) continue;
                    char c = line.Text[k];
                    if (c == 0 || c == ' ') { sb.Append(' '); continue; }
                    sb.Append(c);
                }
                string text = sb.ToString();
                if (text.Trim().Length == 0)
                {
                    i = j;
                    continue;   // 全空白不绘制（背景色由整行底处理）
                }

                int fgIdx = TerminalEmulator.FgOf(a);
                int bgIdx = TerminalEmulator.BgOf(a);
                bool reverse = (a & TerminalEmulator.F_REVERSE) != 0;
                bool invisible = (a & TerminalEmulator.F_INVISIBLE) != 0;

                int fg = reverse ? bgIdx : fgIdx;
                int bg = reverse ? fgIdx : bgIdx;

                if ((a & TerminalEmulator.F_BOLD) != 0 && fg < 16) fg = fg + 8 > 15 ? fg : fg + 8;

                // 只在非默认背景时绘制底色：默认色已由整块背景覆盖，
                // 跳过可大幅减少绘制调用（终端里绝大多数格子是默认背景）
                var bgColor = ColorFromPalette(bg);
                if (bg != TerminalEmulator.DEFAULT_BG)
                    dc.DrawRectangle(new SolidColorBrush(bgColor), null,
                        new Rect(i * _cellW, y, (j - i) * _cellW, _cellH));

                if (!invisible)
                {
                    var brush = new SolidColorBrush(ColorFromPalette(fg));
                    var ft = new FormattedText(text, CultureInfo.CurrentUICulture, FlowDirection.LeftToRight,
                        _typeface, _fontSize, brush, 1.0);
                    dc.DrawText(ft, new Point(i * _cellW, y));

                    if ((a & TerminalEmulator.F_UNDERLINE) != 0)
                    {
                        var pen = new Pen(brush, 1);
                        dc.DrawLine(pen, new Point(i * _cellW, y + _ascent + 2),
                            new Point(i * _cellW + ft.Width, y + _ascent + 2));
                    }
                }
                i = j;
            }
        }

        private void DrawSelection(DrawingContext dc, int firstLine, int rows, int cols)
        {
            // 归一化选择区间
            int sBuf = Math.Min(_selStartBuf, _selEndBuf);
            int eBuf = Math.Max(_selStartBuf, _selEndBuf);
            int sCol = sBuf == _selStartBuf ? _selStartCol : _selEndCol;
            int eCol = eBuf == _selStartBuf ? _selStartCol : _selEndCol;
            var brush = new SolidColorBrush(Color.FromArgb(100, 88, 166, 255));

            for (int buf = sBuf; buf <= eBuf; buf++)
            {
                int r = buf - firstLine;
                if (r < 0 || r >= rows) continue;
                int c0 = (buf == sBuf) ? sCol : 0;
                int c1 = (buf == eBuf) ? eCol : cols - 1;
                if (c1 < c0) continue;
                dc.DrawRectangle(brush, null,
                    new Rect(c0 * _cellW, r * _cellH, (c1 - c0 + 1) * _cellW, _cellH));
            }
        }

        private static Color ColorFromArgb(int argb) => Color.FromRgb(
            (byte)((argb >> 16) & 0xFF), (byte)((argb >> 8) & 0xFF), (byte)(argb & 0xFF));

        private static Color ColorFromPalette(int idx) => ColorFromArgb(TerminalEmulator.Palette[idx & 0xFF]);

        // ---------- 交互 ----------

        protected override void OnMouseWheel(MouseWheelEventArgs e)
        {
            // 与 Android 版一致：滚轮向上 → 走向更新的行 → offset 减小
            int lines = (int)(-e.Delta / 40);
            if (lines == 0) lines = e.Delta > 0 ? -1 : 1;
            ScrollOffset = _scrollOffset + lines;
            e.Handled = true;
            base.OnMouseWheel(e);
        }

        protected override void OnMouseDown(MouseButtonEventArgs e)
        {
            Focus();
            Keyboard.Focus(this);
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                var p = e.GetPosition(this);
                _selecting = true;
                _hasSelection = false;
                _selStartBuf = _selEndBuf = BufLineAt(p.Y);
                _selStartCol = _selEndCol = ColAt(p.X);
                CaptureMouse();
                InvalidateVisual();
            }
            base.OnMouseDown(e);
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            if (_selecting)
            {
                var p = e.GetPosition(this);
                _selEndBuf = BufLineAt(p.Y);
                _selEndCol = ColAt(p.X);
                _hasSelection = (_selStartBuf != _selEndBuf) || (_selStartCol != _selEndCol);
                InvalidateVisual();
            }
            base.OnMouseMove(e);
        }

        protected override void OnMouseUp(MouseButtonEventArgs e)
        {
            if (_selecting)
            {
                _selecting = false;
                ReleaseMouseCapture();
                if (_hasSelection) CopySelection();
            }
            base.OnMouseUp(e);
        }

        private int ColAt(double x) => Math.Clamp((int)(x / _cellW), 0, (_emu?.Cols ?? 80) - 1);

        private int BufLineAt(double y)
        {
            if (_emu == null) return 0;
            int row = Math.Clamp((int)(y / _cellH), 0, _emu.Rows - 1);
            return _emu.TotalLines - _emu.Rows - _scrollOffset + row;
        }

        public string GetSelectedText()
        {
            if (!_hasSelection || _emu == null) return "";
            int sBuf = Math.Min(_selStartBuf, _selEndBuf);
            int eBuf = Math.Max(_selStartBuf, _selEndBuf);
            int sCol = sBuf == _selStartBuf ? _selStartCol : _selEndCol;
            int eCol = eBuf == _selStartBuf ? _selStartCol : _selEndCol;
            var sb = new System.Text.StringBuilder();
            for (int buf = sBuf; buf <= eBuf; buf++)
            {
                var line = _emu.GetBufferedLine(buf);
                int c0 = (buf == sBuf) ? sCol : 0;
                int c1 = (buf == eBuf) ? eCol : line.Text.Length - 1;
                for (int c = c0; c <= c1 && c < line.Text.Length; c++)
                {
                    if ((line.Attr[c] & TerminalEmulator.F_WIDE_CONT) != 0) continue;
                    sb.Append(line.Text[c]);
                }
                sb.Append('\n');
            }
            return sb.ToString();
        }

        private void CopySelection()
        {
            var text = GetSelectedText();
            if (!string.IsNullOrEmpty(text))
            {
                try { Clipboard.SetText(text); } catch { }
            }
        }

        public void ClearSelection()
        {
            _hasSelection = false;
            InvalidateVisual();
        }

        protected override void OnTextInput(TextCompositionEventArgs e)
        {
            var data = System.Text.Encoding.UTF8.GetBytes(e.Text);
            OnUserInput?.Invoke(data);
            ScrollOffset = 0;
            e.Handled = true;
            base.OnTextInput(e);
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            byte[] send = null;
            switch (e.Key)
            {
                case Key.Enter: send = new byte[] { 0x0D }; break;
                case Key.Back: send = new byte[] { 0x7F }; break;
                case Key.Tab: send = new byte[] { 0x09 }; break;
                case Key.Escape: send = new byte[] { 0x1B }; break;
                case Key.Up: send = System.Text.Encoding.UTF8.GetBytes("\x1b[A"); break;
                case Key.Down: send = System.Text.Encoding.UTF8.GetBytes("\x1b[B"); break;
                case Key.Right: send = System.Text.Encoding.UTF8.GetBytes("\x1b[C"); break;
                case Key.Left: send = System.Text.Encoding.UTF8.GetBytes("\x1b[D"); break;
                case Key.Home: send = System.Text.Encoding.UTF8.GetBytes("\x1b[H"); break;
                case Key.End: send = System.Text.Encoding.UTF8.GetBytes("\x1b[F"); break;
                case Key.PageUp: send = System.Text.Encoding.UTF8.GetBytes("\x1b[5~"); break;
                case Key.PageDown: send = System.Text.Encoding.UTF8.GetBytes("\x1b[6~"); break;
                case Key.Delete: send = System.Text.Encoding.UTF8.GetBytes("\x1b[3~"); break;
                case Key.F1: send = System.Text.Encoding.UTF8.GetBytes("\x1bOP"); break;
                case Key.F2: send = System.Text.Encoding.UTF8.GetBytes("\x1bOQ"); break;
                case Key.F3: send = System.Text.Encoding.UTF8.GetBytes("\x1bOR"); break;
                case Key.F4: send = System.Text.Encoding.UTF8.GetBytes("\x1bOS"); break;
                case Key.F5: send = System.Text.Encoding.UTF8.GetBytes("\x1b[15~"); break;
                case Key.F6: send = System.Text.Encoding.UTF8.GetBytes("\x1b[17~"); break;
                case Key.F7: send = System.Text.Encoding.UTF8.GetBytes("\x1b[18~"); break;
                case Key.F8: send = System.Text.Encoding.UTF8.GetBytes("\x1b[19~"); break;
                case Key.F9: send = System.Text.Encoding.UTF8.GetBytes("\x1b[20~"); break;
                case Key.F10: send = System.Text.Encoding.UTF8.GetBytes("\x1b[21~"); break;
                case Key.F11: send = System.Text.Encoding.UTF8.GetBytes("\x1b[23~"); break;
                case Key.F12: send = System.Text.Encoding.UTF8.GetBytes("\x1b[24~"); break;
            }

            if (send != null)
            {
                OnUserInput?.Invoke(send);
                ScrollOffset = 0;
                ClearSelection();
                e.Handled = true;
                return;
            }

            // Ctrl 组合键（Ctrl+C / Ctrl+D / Ctrl+L 等）
            if (Keyboard.Modifiers.HasFlag(ModifierKeys.Control) && e.Key != Key.LeftCtrl && e.Key != Key.RightCtrl)
            {
                if (e.Key == Key.C && _hasSelection)
                {
                    CopySelection();
                    e.Handled = true;
                    return;
                }
                if (e.Key == Key.V)
                {
                    if (Clipboard.ContainsText())
                    {
                        var text = Clipboard.GetText();
                        OnUserInput?.Invoke(System.Text.Encoding.UTF8.GetBytes(text));
                        ScrollOffset = 0;
                    }
                    e.Handled = true;
                    return;
                }
                string name = e.Key.ToString();
                if (name.Length == 1)
                {
                    char c = char.ToLower(name[0]);
                    int code = c - 'a' + 1;   // Ctrl+A = 0x01
                    OnUserInput?.Invoke(new byte[] { (byte)code });
                    ScrollOffset = 0;
                    e.Handled = true;
                    return;
                }
            }

            base.OnKeyDown(e);
        }

        /// <summary>把任意字节序列发给远端（供按键栏、快捷命令调用）</summary>
        public void SendRaw(byte[] data)
        {
            OnUserInput?.Invoke(data);
            ScrollOffset = 0;
        }
    }
}
