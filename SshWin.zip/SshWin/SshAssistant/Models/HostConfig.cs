using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace SshAssistant.Models
{
    /// <summary>认证方式</summary>
    public static class AuthType
    {
        public const string Password = "password";
        public const string Key = "key";
    }

    /// <summary>
    /// 一台远程主机的连接配置。
    /// 对应 Android 版的 data/HostConfig.kt —— 字段与语义保持一致，
    /// 便于两套平台之间互相导入导出配置（JSON 结构兼容）。
    /// </summary>
    public class HostConfig
    {
        public string Id { get; set; } = Guid.NewGuid().ToString("N");
        public string Name { get; set; } = "";
        public string Host { get; set; } = "";
        public int Port { get; set; } = 22;
        public string User { get; set; } = "";

        /// <summary>AuthType.Password 或 AuthType.Key</summary>
        public string AuthType { get; set; } = Models.AuthType.Password;

        public string KeyPath { get; set; } = "";
        public string Remark { get; set; } = "";
        public string StartDir { get; set; } = "";
        public string StartupCmd { get; set; } = "";

        public string DisplayName =>
            string.IsNullOrWhiteSpace(Name)
                ? (string.IsNullOrWhiteSpace(Host) ? "未命名" : Host)
                : Name;

        /// <summary>
        /// 凭据（密码/私钥口令）。
        /// 标记为 JsonIgnore：平时【不】随 hosts.json 落盘（那是明文文件），
        /// 凭据单独存在 DPAPI 加密的 creds.dat 里。
        /// 只有导出配置时才由 HostJson 填充并序列化进导出文件。
        /// </summary>
        [JsonIgnore]
        public HostCredentials Credentials { get; set; } = new HostCredentials();

        public HostConfig Clone()
        {
            return (HostConfig)MemberwiseClone();
        }

        /// <summary>复制出一份新主机（新 Id），凭据需由调用方另行复制</summary>
        public HostConfig CopyConfig()
        {
            var c = (HostConfig)MemberwiseClone();
            c.Id = Guid.NewGuid().ToString("N");
            c.Credentials = new HostCredentials();
            return c;
        }
    }

    /// <summary>凭据：登录密码 + 私钥口令。仅在导出/导入时随配置流动。</summary>
    public class HostCredentials
    {
        public string Password { get; set; }
        public string KeyPassphrase { get; set; }

        public bool IsEmpty => string.IsNullOrEmpty(Password) && string.IsNullOrEmpty(KeyPassphrase);
    }
}
