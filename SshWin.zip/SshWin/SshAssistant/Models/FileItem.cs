using System;

namespace SshAssistant.Models
{
    /// <summary>文件列表中的一项（本地或远程通用）</summary>
    public class FileItem
    {
        public string Name { get; set; } = "";
        public string Path { get; set; } = "";
        public bool IsDir { get; set; }
        public long Size { get; set; }
        public DateTime Modified { get; set; }
        public string Permissions { get; set; } = "";
        public bool IsLink { get; set; }

        /// <summary>所属面板是否为远程</summary>
        public bool Remote { get; set; }

        public string SizeText => IsDir ? "" : FormatSize(Size);

        public string TimeText => Modified == default
            ? ""
            : Modified.ToString("yyyy-MM-dd HH:mm");

        public static string FormatSize(long bytes)
        {
            if (bytes < 0) return "";
            string[] units = { "B", "KB", "MB", "GB", "TB" };
            double v = bytes;
            int i = 0;
            while (v >= 1024 && i < units.Length - 1)
            {
                v /= 1024;
                i++;
            }
            return i == 0 ? $"{bytes} B" : $"{v:F1} {units[i]}";
        }
    }
}
