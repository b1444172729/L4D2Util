using System;

namespace SshAssistant.Models
{
    /// <summary>一条端口转发规则：把本机端口映射到远程网络内的地址</summary>
    public class PortForwardRule
    {
        public string Id { get; set; } = Guid.NewGuid().ToString("N");
        public string HostId { get; set; } = "";
        public int LocalPort { get; set; }
        public string RemoteHost { get; set; } = "127.0.0.1";
        public int RemotePort { get; set; }

        public string Text => $"本地 {LocalPort} → {RemoteHost}:{RemotePort}";
    }
}
