# 终端模拟器 · Windows 版

Android 版（SSH 助手 / 终端模拟器）的功能对等移植。

## 技术栈

- **WPF + C# / .NET 8** —— 原生 Windows 桌面应用，无浏览器依赖
- **SSH.NET 2026.0.0** —— SSH / SFTP / 端口转发
  （必须 ≥ 2026.0.0，旧版有两个高危 CVE，见下方「依赖安全」）
- 序列化用内置 `System.Text.Json`，无第三方 JSON 依赖
- 终端为**自绘控件**，不依赖 WebView、conpty 或任何 native 代码

## 编译运行

### 方式一：Visual Studio 2022

1. 安装 VS 2022，勾选「.NET 桌面开发」
2. 打开 `SshAssistant.sln`
3. NuGet 包会自动还原（首次需联网）
4. F5 运行

### 方式二：命令行

```bash
dotnet restore
dotnet build -c Release
dotnet run
```

## 功能对照

| 模块 | Android 版 | Windows 版 |
|---|---|---|
| 终端 | TerminalEmulator + TerminalView | 同名类，逐行移植（ANSI 状态机、256 色调色板一致） |
| 主机管理 | HostStore + SecureStore(Keystore) | HostStore + CredentialStore(DPAPI) |
| 连接 | SshConnector (sshj) | SshConnector (SSH.NET) |
| 文件 | 双面板 + SFTP | 双面板 + SFTP |
| 传输 | 上传/下载/冲突/续传 | 同 |
| 端口转发 | 本地转发 | 同 |
| 设置 | 15 项 | 同（压缩项见下） |
| 按键栏 | 19 键，顺序可调 | 同 |

## 目录结构

```
SshAssistant/
├─ Models/       HostConfig / FileItem / PortForwardRule
├─ Data/         AppSettings / HostStore / CredentialStore / KeyBar / PortForwardStore
├─ Ssh/          SshConnector / SessionRegistry / RemoteFs / LocalFs / TransferService / PaneClipboard
├─ Terminal/     TerminalEmulator / TerminalView
└─ Views/        MainWindow / SessionWindow / HostEditWindow / SettingsWindow
                 TransfersWindow / EditorWindow / KeyBarOrderWindow / Dialogs
```

## 数据存储

| 内容 | 位置 | 加密 |
|---|---|---|
| 主机列表 | `%APPDATA%\SshAssistant\hosts.json` | 明文（不含凭据） |
| 凭据（密码/私钥口令） | `%APPDATA%\SshAssistant\creds.dat` | **DPAPI 当前用户加密** |
| 主机密钥指纹 | `known_hosts.json` | 明文（指纹本就可公开） |
| 转发规则 | `forward_rules.json` | 明文 |
| 设置 | `settings.json` | 明文 |

**凭据与配置分开存储**：`HostConfig.Credentials` 标了 `[JsonIgnore]`，
平时绝不写入明文 hosts.json；只有导出配置时才填充进导出文件（明文，导出前有风险提示）。

## 与 Android 版的差异

1. **SSH 压缩**：SSH.NET 未提供压缩开关，Windows 版该项无法生效，
   设置界面已置灰并标注。Android 版可生效。
2. **本地文件权限**：Windows 只有只读位，`chmod` 的写位映射为只读取反，
   无法显示/修改完整的 rwx 三元组。
3. **终端尺寸**：随窗口自动计算行列（Android 版随屏幕+键盘变化）。
4. **按键栏**：19 个键一致，顺序可调；Ctrl 键为"按下后下次输入生效"。

## 从 Android 版迁移配置

Android 版导出的 `hosts-*.json` 可直接被 Windows 版导入，反之亦然 ——
两边的 JSON 结构（`version` / `containsCredentials` / `hosts[]`）保持一致，
且都包含凭据。老版本导出的文件（无凭据字段）导入时不会报错，凭据留空。

## 依赖安全

SSH.NET < 2026.0.0 有两个高危漏洞，**均已在本项目使用的 2026.0.0 中修复**：

| CVE | 等级 | 组件 |
|---|---|---|
| CVE-2026-85756 | 7.5 High | `ScpClient` 远程路径命令注入 → 服务端 RCE |
| CVE-2026-48798 | 7.1 High | `ScpClient` 递归下载路径穿越 → 客户端任意文件写 |

本项目**未使用 `ScpClient`**（只用 `SftpClient` / `SshClient` / `ForwardedPortLocal`），
因此这两个漏洞在功能上不可触发；升级到 2026.0.0 是为了消除 NuGet 审计告警（NU1903）。

## 已知限制

- 未实现 SFTP 断点续传的**下载**侧（上传侧已实现）：SSH.NET 的
  `DownloadFile` 不支持起始 offset。
- 终端不支持鼠标报告（如 vim 鼠标模式）、六el 图形等高级特性。
- 多窗口打开同一主机时共享同一会话。
