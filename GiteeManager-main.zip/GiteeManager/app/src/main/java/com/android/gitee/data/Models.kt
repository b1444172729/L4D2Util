package com.android.gitee.data

/** 仓库信息 */
data class Repo(
    val id: Long,
    val name: String,
    val fullName: String,
    val owner: String,
    val description: String,
    val isPrivate: Boolean,
    val defaultBranch: String,
    val language: String,
    val stars: Int,
    val forks: Int,
    val size: Long,
    val pushedAt: String,
    val htmlUrl: String
)

/** 目录 / 文件条目（Contents API 返回） */
data class ContentEntry(
    val name: String,
    val path: String,
    val type: String,       // "file" | "dir" | "symlink" | "submodule"
    val size: Long,
    val sha: String,
    val htmlUrl: String,
    val downloadUrl: String
) {
    val isDir: Boolean get() = type == "dir"
}

/** 文件内容（含 sha，更新 / 删除时必需） */
data class FileContent(
    val name: String,
    val path: String,
    val sha: String,
    val size: Long,
    val contentBase64: String?,   // 大文件（>1MB）时为 null
    val encoding: String?,
    val downloadUrl: String?
) {
    /** 直接解码出文本；二进制文件返回 null */
    fun decodedText(): String? {
        if (contentBase64.isNullOrBlank()) return null
        return try {
            String(android.util.Base64.decode(contentBase64, android.util.Base64.DEFAULT), Charsets.UTF_8)
        } catch (e: Exception) {
            null
        }
    }

    fun decodedBytes(): ByteArray? {
        if (contentBase64.isNullOrBlank()) return null
        return try {
            android.util.Base64.decode(contentBase64, android.util.Base64.DEFAULT)
        } catch (e: Exception) {
            null
        }
    }
}

/** 分支 */
data class Branch(val name: String, val sha: String, val protected: Boolean)

/** 提交 */
data class Commit(
    val sha: String,
    val message: String,
    val author: String,
    val date: String,
    val htmlUrl: String
)

/** 工作流 */
data class Workflow(val id: Long, val name: String, val path: String, val state: String)

/** 工作流运行 */
data class WorkflowRun(
    val id: Long,
    val name: String,
    val number: Int,
    val status: String,          // queued / in_progress / completed
    val conclusion: String,      // success / failure / cancelled / ...
    val branch: String,
    val sha: String,
    val event: String,
    val createdAt: String,
    val updatedAt: String,
    val htmlUrl: String
) {
    val displayStatus: String
        get() = when {
            status != "completed" -> when (status) {
                "queued" -> "排队中"
                "in_progress" -> "运行中"
                "waiting" -> "等待中"
                else -> status
            }
            else -> when (conclusion) {
                "success" -> "成功"
                "failure" -> "失败"
                "cancelled" -> "已取消"
                "skipped" -> "已跳过"
                "timed_out" -> "超时"
                "action_required" -> "需确认"
                "neutral" -> "中性"
                else -> conclusion.ifBlank { "已完成" }
            }
        }
}

/** 运行中的单个任务（用于按任务抓文本日志） */
data class WorkflowJob(
    val id: Long,
    val name: String,
    val status: String,
    val conclusion: String,
    val startedAt: String,
    val completedAt: String
)

/** 构建产物 */
data class Artifact(
    val id: Long,
    val name: String,
    val sizeInBytes: Long,
    val expired: Boolean,
    val createdAt: String,
    val updatedAt: String
)

/** Issue / Pull Request 通用条目 */
data class Issue(
    val number: Int,
    val title: String,
    val state: String,
    val author: String,
    val createdAt: String,
    val updatedAt: String,
    val comments: Int,
    val body: String,
    val htmlUrl: String,
    val isPull: Boolean = false,
    val draft: Boolean = false,
    val merged: Boolean = false,
    val mergeable: Boolean = false
)

/** 评论 */
data class Comment(val id: Long, val author: String, val body: String, val createdAt: String)

/** Release */
data class Release(
    val id: Long,
    val tagName: String,
    val name: String,
    val body: String,
    val publishedAt: String,
    val htmlUrl: String,
    val draft: Boolean,
    val prerelease: Boolean,
    val assets: List<ReleaseAsset>
)

data class ReleaseAsset(
    val id: Long,
    val name: String,
    val size: Long,
    val downloadCount: Int,
    val url: String        // api 地址，下载需带 token
)

/** 当前登录用户 */
data class User(
    val login: String,
    val name: String,
    val avatarUrl: String,
    val publicRepos: Int,
    val htmlUrl: String
)

/** 上传 / 提交结果 */
data class CommitResult(val commitSha: String, val contentSha: String?, val htmlUrl: String)

/** 日志分级类别 */
enum class LogLevel { KEY, ERROR, WARNING, ALL }

/**
 * 分级后的构建日志。
 * raw 是完整原文，key / errors / warnings 是从中筛出的关键行，
 * 便于在手机上快速定位问题，而不是在几千行里翻。
 */
data class LogBundle(
    val raw: String,
    val key: List<String>,
    val errors: List<String>,
    val warnings: List<String>,
    val sizeBytes: Long
) {
    fun linesOf(level: LogLevel): List<String> = when (level) {
        LogLevel.KEY -> key
        LogLevel.ERROR -> errors
        LogLevel.WARNING -> warnings
        LogLevel.ALL -> raw.lineSequence().toList()
    }

    fun isEmpty(level: LogLevel): Boolean = linesOf(level).isEmpty()
}
