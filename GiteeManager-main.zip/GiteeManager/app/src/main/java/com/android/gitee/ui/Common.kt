package com.android.gitee.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.android.gitee.util.Helpers

/** 统一的尺寸常量，改这里就能整体调整观感 */
object Dimens {
    val CardRadius = 20.dp
    val ChipRadius = 50.dp
    val SheetRadius = 28.dp
    val ScreenPadding = 16.dp
    val CardGap = 10.dp
    val CardInner = 16.dp
}

/** 分组标题：带一条同色系的小竖条，层次更清楚 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SectionHeader(title: String, subtitle: String = "", actions: @Composable RowScope.() -> Unit = {}) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = Dimens.ScreenPadding, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // 装饰竖条
        Box(
            Modifier
                .size(width = 3.dp, height = 18.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(MaterialTheme.colorScheme.primary)
        )
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text(
                title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (subtitle.isNotBlank()) {
                Text(
                    subtitle,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        Row(content = actions)
    }
}

/** 空状态：圆形柔和底 + 图标，比纯文字更有质感 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EmptyState(icon: ImageVector, title: String, subtitle: String = "") {
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 40.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(
            Modifier
                .size(84.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.surfaceContainerHigh),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                icon, null, Modifier.size(38.dp),
                tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.85f)
            )
        }
        Text(
            title,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface
        )
        if (subtitle.isNotBlank()) {
            Text(
                subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                lineHeight = 16.sp
            )
        }
    }
}

/** 忙碌进度条：细条 + 文案，弱化存在感但不消失 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BusyBar(label: String) {
    AnimatedVisibility(visible = label.isNotBlank(), enter = fadeIn(), exit = fadeOut()) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = Dimens.ScreenPadding, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                label,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Medium
            )
            Spacer(Modifier.width(10.dp))
            LinearProgressIndicator(
                Modifier
                    .weight(1f)
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
            )
        }
    }
}

/** 单行文本输入对话框 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TextInputDialog(
    title: String,
    label: String,
    hint: String = "",
    initial: String = "",
    singleLine: Boolean = true,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(Dimens.SheetRadius),
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    text, { text = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text(label) },
                    singleLine = singleLine,
                    maxLines = if (singleLine) 1 else 8,
                    shape = RoundedCornerShape(14.dp)
                )
                if (hint.isNotBlank()) {
                    Text(
                        hint,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(text) }, enabled = text.isNotBlank()) { Text("确定") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("取消") } }
    )
}

/** 危险操作确认框 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConfirmDialog(
    title: String,
    text: String,
    confirmLabel: String = "确定",
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(Dimens.SheetRadius),
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = { Text(text, style = MaterialTheme.typography.bodyMedium) },
        confirmButton = {
            TextButton(onClick = { onConfirm(); onDismiss() }) {
                Text(confirmLabel, color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("取消") } }
    )
}

/** 通用卡片：更大圆角 + 更淡的描边，可点击时带涟漪 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ItemCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(Dimens.CardRadius)
    val border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f))
    val base = modifier.fillMaxWidth()
    if (onClick != null) {
        Surface(
            onClick = onClick,
            shape = shape,
            border = border,
            color = MaterialTheme.colorScheme.surfaceContainerLowest,
            modifier = base
        ) {
            Column(Modifier.padding(Dimens.CardInner), content = content)
        }
    } else {
        Surface(
            shape = shape,
            border = border,
            color = MaterialTheme.colorScheme.surfaceContainerLowest,
            modifier = base
        ) {
            Column(Modifier.padding(Dimens.CardInner), content = content)
        }
    }
}

/** 状态胶囊：同色系淡底 + 深色字 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StatusChip(text: String, color: Color) {
    Surface(
        shape = RoundedCornerShape(Dimens.ChipRadius),
        color = color.copy(alpha = 0.14f)
    ) {
        Text(
            text,
            Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            style = MaterialTheme.typography.labelSmall,
            color = color,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1
        )
    }
}

/** 带小圆点的状态标签（用于运行记录，一眼区分成功/失败/进行中） */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DotStatusChip(text: String, color: Color) {
    Surface(
        shape = RoundedCornerShape(Dimens.ChipRadius),
        color = color.copy(alpha = 0.14f)
    ) {
        Row(
            Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(color)
            )
            Spacer(Modifier.width(6.dp))
            Text(
                text,
                style = MaterialTheme.typography.labelSmall,
                color = color,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
@ReadOnlyComposable
fun statusColor(status: String, conclusion: String): Color {
    if (status != "completed") return MaterialTheme.colorScheme.primary
    return when (conclusion) {
        "success" -> Color(0xFF1B8A4B)
        "failure" -> MaterialTheme.colorScheme.error
        "cancelled" -> MaterialTheme.colorScheme.onSurfaceVariant
        "timed_out" -> MaterialTheme.colorScheme.error
        "skipped" -> MaterialTheme.colorScheme.onSurfaceVariant
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }
}

/** 面包屑：胶囊按钮 + 分隔箭头 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Breadcrumbs(path: String, onNavigate: (String) -> Unit) {
    val parts = path.split('/').filter { it.isNotBlank() }
    Row(
        Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 12.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            onClick = { onNavigate("") },
            shape = RoundedCornerShape(Dimens.ChipRadius),
            color = MaterialTheme.colorScheme.secondaryContainer
        ) {
            Text(
                "根目录",
                Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSecondaryContainer,
                fontWeight = FontWeight.SemiBold
            )
        }
        var acc = ""
        parts.forEach { part ->
            acc = if (acc.isBlank()) part else "$acc/$part"
            val target = acc
            Spacer(Modifier.width(4.dp))
            Icon(
                Icons.Rounded.ChevronRight, null, Modifier.size(14.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
            )
            Spacer(Modifier.width(4.dp))
            Surface(
                onClick = { onNavigate(target) },
                shape = RoundedCornerShape(Dimens.ChipRadius),
                color = MaterialTheme.colorScheme.surfaceContainerHigh
            ) {
                Text(
                    part,
                    Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
                    style = MaterialTheme.typography.labelSmall,
                    maxLines = 1,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

/** 次要信息行 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MetaLine(vararg items: String) {
    val text = items.filter { it.isNotBlank() }.joinToString(" · ")
    if (text.isNotBlank()) {
        Text(
            text,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            lineHeight = 15.sp
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CopyButton(text: String, label: String = "复制", onCopy: (String) -> Unit) {
    TextButton(onClick = { onCopy(text) }) {
        Icon(Icons.Rounded.ContentCopy, null, Modifier.size(16.dp))
        Spacer(Modifier.width(5.dp))
        Text(label)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InfoText(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 16.sp
    )
}

/** 横向进度条（自绘，避免依赖不同版本 Material3 的 progress API） */
@Composable
fun ModernProgressBar(progress: Float, color: Color, modifier: Modifier = Modifier) {
    Box(
        modifier
            .fillMaxWidth()
            .height(6.dp)
            .clip(RoundedCornerShape(3.dp))
            .background(MaterialTheme.colorScheme.surfaceContainerHighest)
    ) {
        Box(
            Modifier
                .fillMaxHeight()
                .fillMaxWidth(if (progress > 0f) progress.coerceIn(0f, 1f) else 0.001f)
                .clip(RoundedCornerShape(3.dp))
                .background(color)
        )
    }
}

/**
 * 圆形图标按钮，常用于卡片右上角的操作。
 *
 * 注意参数顺序：尾随 lambda 会绑定到「声明顺序上最后一个参数」。
 * 如果把 tint 放在 onClick 之后，调用处写 CircleIconButton(icon, desc) { ... } 时，
 * lambda 会被当成 tint（Color）传给，而 onClick 反而没值，编译直接报错。
 * 因此 onClick 必须放在最后。
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CircleIconButton(
    icon: ImageVector,
    desc: String,
    tint: Color = MaterialTheme.colorScheme.onSurfaceVariant,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = CircleShape,
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        modifier = Modifier.size(34.dp)
    ) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Icon(icon, desc, Modifier.size(18.dp), tint = tint)
        }
    }
}

fun formatSize(bytes: Long) = Helpers.size(bytes)
