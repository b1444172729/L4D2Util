package com.android.gitee.data

import android.app.Application
import com.android.gitee.util.Helpers
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/** 传输任务状态 */
enum class TransferState { QUEUED, DOWNLOADING, PAUSED, EXTRACTING, COMPLETED, FAILED, CANCELED }

/** 产物下载类型 */
enum class TransferKind { APK, ZIP }

/**
 * 一个下载任务。
 * 所有字段都是不可变的，界面通过整体替换对象来刷新，避免并发修改导致状态错乱。
 */
data class TransferTask(
    val id: String,
    val artifactName: String,
    val fileName: String,
    val kind: TransferKind,
    val state: TransferState,
    val totalBytes: Long = -1L,
    val receivedBytes: Long = 0L,
    val speedBytesPerSec: Long = 0L,
    /** 当前实际使用的下载地址（已解析过重定向），可复制 */
    val url: String = "",
    val savedPath: String? = null,
    val error: String? = null,
    val startedAt: Long = System.currentTimeMillis()
) {
    val isFinished: Boolean
        get() = state == TransferState.COMPLETED || state == TransferState.FAILED || state == TransferState.CANCELED
    val canPause: Boolean
        get() = state == TransferState.QUEUED || state == TransferState.DOWNLOADING
    val canResume: Boolean
        get() = state == TransferState.PAUSED
    val canCancel: Boolean
        get() = !isFinished && state != TransferState.EXTRACTING
    val progress: Float
        get() = if (totalBytes > 0L) (receivedBytes.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f) else 0f
}

/**
 * 产物下载管理器：支持断点续传的暂停 / 继续、取消，以及进度与速度回调。
 *
 * 设计要点：
 * 1. 先下到应用私有的 .part 文件（用 RandomAccessFile 追加写），完成后再写入 Downloads，
 *    这样既能断点续传，也能保证用户只在下载完成时看到成品文件。
 * 2. Gitee 的产物地址会 302 到 Azure 且带时效，所以每次开始 / 恢复都重新解析一次地址。
 * 3. 暂停只是让读取循环退出并保留已下载的部分，下次继续时用 Range 请求续传。
 */
class TransferManager(
    private val app: Application,
    private val onUpdate: (TransferTask) -> Unit
) {
    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .callTimeout(0, TimeUnit.SECONDS)
        .build()

    private data class Params(
        val name: String,
        val fileName: String,
        val kind: TransferKind,
        val knownSize: Long,
        val resolve: suspend () -> String
    )

    private val jobs = ConcurrentHashMap<String, Job>()
    private val params = ConcurrentHashMap<String, Params>()
    private val paused = ConcurrentHashMap.newKeySet<String>()
    private val canceled = ConcurrentHashMap.newKeySet<String>()

    private fun partFile(id: String): File {
        val dir = File(app.cacheDir, "transfers")
        if (!dir.exists()) dir.mkdirs()
        return File(dir, "$id.part")
    }

    fun start(
        id: String,
        name: String,
        fileName: String,
        kind: TransferKind,
        knownSize: Long,
        resolve: suspend () -> String
    ) {
        if (jobs[id]?.isActive == true) return
        paused.remove(id)
        canceled.remove(id)
        params[id] = Params(name, fileName, kind, knownSize, resolve)
        onUpdate(TransferTask(id, name, fileName, kind, TransferState.QUEUED, knownSize, 0L, 0L, ""))
        jobs[id] = scope.launch { execute(id) }
    }

    /** 暂停：保留已下载部分，可继续 */
    fun pause(id: String) {
        if (params[id] == null) return
        paused.add(id)
    }

    /** 继续：从已下载的位置断点续传 */
    fun resume(id: String) {
        val p = params[id] ?: return
        paused.remove(id)
        canceled.remove(id)
        start(id, p.name, p.fileName, p.kind, p.knownSize, p.resolve)
    }

    /** 取消：停止下载并删除临时文件 */
    fun cancel(id: String) {
        val p = params[id] ?: return
        canceled.add(id)
        jobs[id]?.cancel()
        jobs.remove(id)
        paused.remove(id)
        partFile(id).delete()
        params.remove(id)
        onUpdate(TransferTask(id, p.name, p.fileName, p.kind, TransferState.CANCELED, p.knownSize, 0L, 0L, ""))
    }

    private suspend fun execute(id: String) {
        val p = params[id] ?: return
        var task = TransferTask(id, p.name, p.fileName, p.kind, TransferState.QUEUED, p.knownSize, 0L, 0L, "")
        try {
            // 每次都重新解析：Azure 的临时地址会过期
            val url = p.resolve()
            task = task.copy(url = url, state = TransferState.DOWNLOADING)
            onUpdate(task)

            val file = partFile(id)
            downloadInto(id, url, file) { received, total, speed ->
                task = task.copy(
                    state = TransferState.DOWNLOADING,
                    totalBytes = total,
                    receivedBytes = received,
                    speedBytesPerSec = speed
                )
                onUpdate(task)
            }

            if (canceled.contains(id)) return
            if (paused.contains(id)) {
                onUpdate(task.copy(state = TransferState.PAUSED, speedBytesPerSec = 0L))
                return
            }

            task = task.copy(state = TransferState.EXTRACTING, speedBytesPerSec = 0L)
            onUpdate(task)

            val saved = withContext(Dispatchers.IO) { finish(id, p, file) }
            onUpdate(task.copy(state = TransferState.COMPLETED, savedPath = saved, speedBytesPerSec = 0L))
            file.delete()
            params.remove(id)
            jobs.remove(id)
        } catch (e: Exception) {
            if (canceled.contains(id)) return
            if (e is CancellationException) {
                onUpdate(task.copy(state = TransferState.PAUSED, speedBytesPerSec = 0L))
                return
            }
            onUpdate(
                task.copy(
                    state = TransferState.FAILED,
                    error = e.message ?: "下载失败",
                    speedBytesPerSec = 0L
                )
            )
        }
    }

    /** 下载到 .part 文件；支持 Range 续传，遇到 416 会重头再下一次 */
    private fun downloadInto(
        id: String,
        url: String,
        file: File,
        onProgress: (received: Long, total: Long, speed: Long) -> Unit
    ) {
        var done = false
        var attempt = 0
        while (attempt < 2 && !done) {
            attempt++
            val start = if (file.exists()) file.length() else 0L
            val builder = Request.Builder().url(url).header("User-Agent", "GiteeManager-Android")
            if (start > 0L) builder.header("Range", "bytes=$start-")

            client.newCall(builder.build()).execute().use { resp ->
                if (resp.code == 416 && start > 0L) {
                    // 断点不被接受（服务端不支持或资源已变化），删掉重来
                    file.delete()
                    return@use
                }
                if (!resp.isSuccessful && resp.code != 206) {
                    throw IOException("下载失败（HTTP ${resp.code}）")
                }
                val body = resp.body ?: throw IOException("空响应")
                val length = body.contentLength()
                val total = if (length > 0L) length + start else -1L

                var received = start
                var lastTime = System.currentTimeMillis()
                var lastBytes = received

                RandomAccessFile(file, "rw").use { raf ->
                    raf.seek(start)
                    body.byteStream().use { stream ->
                        val buffer = ByteArray(64 * 1024)
                        while (true) {
                            if (paused.contains(id) || canceled.contains(id)) return
                            val n = stream.read(buffer)
                            if (n <= 0) break
                            raf.write(buffer, 0, n)
                            received += n
                            val now = System.currentTimeMillis()
                            if (now - lastTime >= 500L) {
                                val speed = ((received - lastBytes) * 1000L) / (now - lastTime)
                                lastTime = now
                                lastBytes = received
                                onProgress(received, total, speed)
                            }
                        }
                    }
                }
                onProgress(received, total, 0L)
                done = true
            }
        }
        if (!done) throw IOException("下载未完成，请重试")
    }

    /** 下载完成后的收尾：ZIP 直接保存，APK 先从 zip 里解出来 */
    private fun finish(id: String, p: Params, file: File): String {
        if (p.kind == TransferKind.ZIP) {
            return Helpers.saveFileToDownloads(app, file, p.fileName, "application/zip")
        }
        val outDir = File(app.cacheDir, "transfers/out/$id")
        if (!outDir.exists()) outDir.mkdirs()
        val found = Helpers.extractFirstToFile(file, ".apk", outDir)
        if (found == null) {
            // 产物里没有 apk，退化为保存原始 zip，避免用户什么都拿不到
            return Helpers.saveFileToDownloads(app, file, "${p.fileName}.zip", "application/zip")
        }
        val result = Helpers.saveFileToDownloads(
            app, found.second, found.first, "application/vnd.android.package-archive"
        )
        found.second.delete()
        return result
    }
}
