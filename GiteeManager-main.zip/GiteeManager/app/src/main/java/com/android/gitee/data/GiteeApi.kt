package com.android.gitee.data

import android.content.Context
import android.net.Uri
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

class ApiException(val code: Int, message: String) : IOException(message)

/** 单次下载体积上限：防止超大日志 / 产物把内存打爆 */
internal const val MAX_DOWNLOAD = 200L * 1024 * 1024

/**
 * Gitee REST API 客户端。
 *
 * 设计要点：
 * 1. 全部通过官方 REST API 完成，不依赖任何本地 Git 实现，因此不受 Android 版本限制。
 * 2. 文件读写走 Contents API，天然支持任意二进制文件（zip / apk / 图片），上限 100 MB。
 * 3. 日志与产物下载会 302 跳转到 Azure Blob，跳转后的请求不能携带令牌，否则会被拒绝，
 *    因此这里统一用「先拿 Location，再用无令牌客户端下载」的两段式下载。
 */
class GiteeApi(private val tokenProvider: () -> String) {

    private val jsonMedia = "application/json; charset=utf-8".toMediaType()

    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .callTimeout(60, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    // 不跟随重定向：用于解析 Location
    private val noRedirect = http.newBuilder().followRedirects(false).followSslRedirects(false).build()

    // 无令牌、超时更长：用于流式下载大文件
    private val transfer = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .callTimeout(0, TimeUnit.SECONDS)
        .followSslRedirects(true)
        .build()

    // 上传 / 下载大文件：超时放宽，且不做整体 callTimeout 限制
    private val transferLong = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(300, TimeUnit.SECONDS)
        .writeTimeout(300, TimeUnit.SECONDS)
        .callTimeout(0, TimeUnit.SECONDS)
        .build()

    private fun token(): String {
        val t = tokenProvider().trim()
        if (t.isBlank()) throw ApiException(401, "未登录或令牌为空")
        return t
    }

    /**
     * Gitee 用 access_token 作为查询参数鉴权（官方 swagger 中该参数既支持 query 也支持 formData）。
     * 放在 URL 上对 GET / DELETE 尤其必要 —— 这类请求没有请求体可用。
     */
    private fun url(path: String): String {
        val sep = if (path.contains("?")) "&" else "?"
        return "https://gitee.com/api/v5$path${sep}access_token=${enc(token())}"
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8").replace("+", "%20")

    private fun headers(builder: Request.Builder): Request.Builder = builder
        .header("Accept", "application/json")
        .header("User-Agent", "GiteeManager-Android")

    private fun call(path: String, method: String = "GET", body: String? = null): String {
        val builder = Request.Builder().url(url(path))
        headers(builder)
        if (body != null) {
            builder.method(method, body.toRequestBody(jsonMedia))
        } else if (method != "GET") {
            builder.method(method, "".toRequestBody(jsonMedia))
        }
        http.newCall(builder.build()).execute().use { resp ->
            val text = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) throw ApiException(resp.code, parseError(resp.code, text))
            return text
        }
    }

    private fun parseError(code: Int, text: String): String {
        val msg = runCatching { JSONObject(text).optString("message") }.getOrDefault("").orEmpty()
        val friendly = when (code) {
            401 -> "令牌无效或已过期（401）"
            403 -> if (text.contains("rate limit", true)) "API 调用频率超限，请稍后再试（403）" else "没有权限，请检查令牌是否已勾选对应权限（403）"
            404 -> "资源不存在，或令牌无权访问（404）"
            409 -> "冲突：$msg"
            422 -> "请求被拒绝：${msg.ifBlank { "可能是同名文件已存在，或内容为空" }}"
            else -> msg
        }
        return friendly.ifBlank { "HTTP $code" }
    }

    private fun repo(owner: String, name: String) = "/repos/${enc(owner)}/${enc(name)}"

    // ---------- 账户 ----------

    fun user(): User {
        val j = JSONObject(call("/user"))
        return User(
            j.optString("login"),
            j.optString("name").ifBlank { j.optString("login") },
            j.optString("avatar_url"),
            j.optInt("public_repos"),
            j.optString("html_url")
        )
    }

    fun repos(): List<Repo> {
        val all = mutableListOf<Repo>()
        for (page in 1..3) {
            val a = JSONArray(call("/user/repos?sort=updated&per_page=100&page=$page&type=all"))
            for (i in 0 until a.length()) all += parseRepo(a.getJSONObject(i))
            if (a.length() < 100) break
        }
        return all
    }

    fun searchRepos(query: String): List<Repo> {
        if (query.isBlank()) return emptyList()
        val raw = call("/search/repositories?q=${enc(query)}&per_page=50&sort=updated")
        // Gitee 的搜索接口直接返回数组；这里同时兼容 {items:[...]} 结构
        val a = if (raw.trimStart().startsWith("[")) JSONArray(raw)
        else JSONObject(raw).optJSONArray("items") ?: return emptyList()
        return (0 until a.length()).map { parseRepo(a.getJSONObject(it)) }
    }

    private fun parseRepo(j: JSONObject) = Repo(
        j.optLong("id"),
        j.optString("name"),
        j.optString("full_name"),
        j.optJSONObject("owner")?.optString("login").orEmpty(),
        j.optString("description").orEmpty(),
        j.optBoolean("private"),
        j.optString("default_branch", "master"),
        j.optString("language").orEmpty(),
        j.optInt("stargazers_count"),
        j.optInt("forks_count"),
        j.optLong("size"),
        j.optString("pushed_at").orEmpty(),
        j.optString("html_url")
    )

    fun createRepo(name: String, description: String, privateRepo: Boolean): Repo {
        val body = JSONObject().put("name", name).put("description", description).put("private", privateRepo)
            .put("auto_init", true)
        return parseRepo(JSONObject(call("/user/repos", "POST", body.toString())))
    }

    fun deleteRepo(owner: String, name: String) {
        call(repo(owner, name), "DELETE")
    }

    fun star(owner: String, name: String) = call("/user/starred/${enc(owner)}/${enc(name)}", "PUT")
    fun unstar(owner: String, name: String) = call("/user/starred/${enc(owner)}/${enc(name)}", "DELETE")

    /** 204 表示已星标，404 表示未星标 */
    fun isStarred(owner: String, name: String): Boolean {
        val request = headers(Request.Builder().url(url("/user/starred/${enc(owner)}/${enc(name)}"))).build()
        http.newCall(request).execute().use { resp ->
            when (resp.code) {
                204 -> return true
                404 -> return false
                else -> throw ApiException(resp.code, parseError(resp.code, resp.body?.string().orEmpty()))
            }
        }
    }

    // ---------- 分支 ----------

    fun branches(owner: String, name: String): List<Branch> {
        val a = JSONArray(call("${repo(owner, name)}/branches?per_page=100"))
        return (0 until a.length()).map {
            val j = a.getJSONObject(it)
            Branch(j.optString("name"), j.optJSONObject("commit")?.optString("sha").orEmpty(), j.optBoolean("protected"))
        }
    }

    /** 基于某个分支创建新分支（用 sha 建 ref，不需要本地仓库） */
    fun createBranch(owner: String, name: String, newBranch: String, from: String) {
        // Gitee 用的是 branch_name / refs，与 Gitee 的 ref / sha 不同
        val body = JSONObject()
            .put("branch_name", newBranch)
            .put("refs", from.ifBlank { "master" })
        call("${repo(owner, name)}/branches", "POST", body.toString())
    }

    fun deleteBranch(owner: String, name: String, branch: String) {
        call("${repo(owner, name)}/git/refs/heads/${enc(branch)}", "DELETE")
    }

    // ---------- 文件（Contents API） ----------

    fun contents(owner: String, name: String, path: String, ref: String): List<ContentEntry> {
        val query = if (ref.isBlank()) "" else "?ref=${enc(ref)}"
        val raw = call("${repo(owner, name)}/contents/${path.encodePath()}$query")
        // 单文件时返回对象，目录时返回数组
        val array = if (raw.trimStart().startsWith("[")) JSONArray(raw) else JSONArray().put(JSONObject(raw))
        val list = mutableListOf<ContentEntry>()
        for (i in 0 until array.length()) {
            val j = array.getJSONObject(i)
            list += ContentEntry(
                j.optString("name"),
                j.optString("path"),
                j.optString("type"),
                j.optLong("size"),
                j.optString("sha"),
                j.optString("html_url"),
                j.optString("download_url")
            )
        }
        // 目录在前、文件在后，各自按名排序
        return list.sortedWith(compareBy({ !it.isDir }, { it.name.lowercase() }))
    }

    /** 读取单个文件；大文件（>1MB）content 为 null，需要用 rawBytes 下载 */
    fun file(owner: String, name: String, path: String, ref: String): FileContent {
        val query = if (ref.isBlank()) "" else "?ref=${enc(ref)}"
        val j = JSONObject(call("${repo(owner, name)}/contents/${path.encodePath()}$query"))
        return FileContent(
            j.optString("name"),
            j.optString("path"),
            j.optString("sha"),
            j.optLong("size"),
            j.optString("content").takeIf { it.isNotBlank() }?.stripBase64(),
            j.optString("encoding").takeIf { it.isNotBlank() },
            j.optString("download_url").takeIf { it.isNotBlank() }
        )
    }

    /**
     * 取文件原始字节。
     *
     * 优先走 raw 端点：它直接返回文件内容，不经过 base64，比 contents 接口省约 33% 内存。
     * Gitee 的 raw 端点在部分情况下会返回 JSON（而不是文件流），此时回退到 contents 解码。
     */
    fun rawBytes(owner: String, name: String, path: String, ref: String): ByteArray {
        val query = if (ref.isBlank()) "" else "?ref=${enc(ref)}"
        runCatching {
            val builder = Request.Builder().url(url("${repo(owner, name)}/raw/${path.encodePath()}$query"))
            headers(builder).header("Accept", "application/octet-stream")
            http.newCall(builder.build()).execute().use { resp ->
                if (resp.isSuccessful) {
                    val bytes = resp.body?.bytes()
                    // 返回的是 JSON 说明 raw 端点未命中，交给下面的回退逻辑
                    if (bytes != null && bytes.isNotEmpty() && bytes[0] != '{'.code.toByte()) return bytes
                }
            }
        }
        val fc = file(owner, name, path, ref)
        val b64 = fc.contentBase64 ?: throw ApiException(404, "文件内容为空或过大，无法读取")
        return android.util.Base64.decode(b64, android.util.Base64.DEFAULT)
    }

    /** Gitee 返回的 base64 内容里含换行符，Base64 解码前必须剔除 */
    private fun String.stripBase64(): String = replace("\n", "").replace("\r", "").trim()

    /**
     * 创建或更新文件。sha 为空表示新建，非空表示更新（Gitee 用它做并发校验）。
     * content 必须是原始字节的 base64。
     */
    fun putFile(
        owner: String, name: String, path: String, message: String,
        contentBase64: String, sha: String?, branch: String
    ): CommitResult {
        val body = JSONObject()
            .put("message", message.ifBlank { "Update ${path.substringAfterLast('/')}" })
            .put("content", contentBase64)
        if (!sha.isNullOrBlank()) body.put("sha", sha)
        if (branch.isNotBlank()) body.put("branch", branch)
        // Gitee 把新建与更新拆成两个接口：新建 POST、更新 PUT（带 sha）
        val method = if (sha.isNullOrBlank()) "POST" else "PUT"
        val j = JSONObject(call("${repo(owner, name)}/contents/${path.encodePath()}", method, body.toString()))
        val content = j.optJSONObject("content")
        val commit = j.optJSONObject("commit")
        return CommitResult(
            commit?.optString("sha").orEmpty(),
            content?.optString("sha"),
            commit?.optString("html_url").orEmpty()
        )
    }

    /**
     * 流式上传本地文件（支持最大 100 MB）。
     *
     * 为什么不用 putFile：putFile 需要先把整个文件读成 ByteArray 再做 base64，
     * 100 MB 文件编码后约 133 MB 字符串，加上原始数组会直接 OOM。
     * 这里边读 Uri 边编码边写入请求体，内存占用恒定在几十 KB。
     */
    fun putFileStream(
        context: Context, uri: Uri, owner: String, name: String, path: String,
        message: String, sha: String?, branch: String
    ): CommitResult {
        val size = uriSize(context, uri)
        val body = StreamUploadBody(context, uri, message, sha, branch, size)
        val method = if (sha.isNullOrBlank()) "POST" else "PUT"
        val request = headers(Request.Builder().url(url("${repo(owner, name)}/contents/${path.encodePath()}")))
            .method(method, body).build()
        transferLong.newCall(request).execute().use { resp ->
            val text = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) throw ApiException(resp.code, parseError(resp.code, text))
            return parseCommitResult(text)
        }
    }

    /** 文件大小；拿不到时返回 -1（此时 contentLength 走 chunked） */
    private fun uriSize(context: Context, uri: Uri): Long {
        runCatching {
            context.contentResolver.openAssetFileDescriptor(uri, "r")?.use { return it.length }
        }
        runCatching {
            context.contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val i = c.getColumnIndex(android.provider.OpenableColumns.SIZE)
                    if (i >= 0 && !c.isNull(i)) return c.getLong(i)
                }
            }
        }
        return -1L
    }

    private fun parseCommitResult(text: String): CommitResult {
        val j = JSONObject(text)
        return CommitResult(
            j.optJSONObject("commit")?.optString("sha").orEmpty(),
            j.optJSONObject("content")?.optString("sha"),
            j.optJSONObject("commit")?.optString("html_url").orEmpty()
        )
    }

    /** 删除文件：必须带 sha */
    fun deleteFile(owner: String, name: String, path: String, message: String, sha: String, branch: String): CommitResult {
        // Gitee 的删除接口要求 sha / message / branch 都在 query 里，不能放请求体
        val query = buildString {
            append("?sha=").append(enc(sha))
            append("&message=").append(enc(message.ifBlank { "Delete ${path.substringAfterLast('/')}" }))
            if (branch.isNotBlank()) append("&branch=").append(enc(branch))
        }
        val j = JSONObject(call("${repo(owner, name)}/contents/${path.encodePath()}$query", "DELETE"))
        return CommitResult(
            j.optJSONObject("commit")?.optString("sha").orEmpty(),
            null,
            j.optJSONObject("commit")?.optString("html_url").orEmpty()
        )
    }

    // ---------- 提交历史 ----------

    fun commits(owner: String, name: String, branch: String): List<Commit> {
        val query = if (branch.isBlank()) "" else "?sha=${enc(branch)}&per_page=50"
        val a = JSONArray(call("${repo(owner, name)}/commits$query"))
        return (0 until a.length()).map {
            val j = a.getJSONObject(it)
            val c = j.optJSONObject("commit")
            Commit(
                j.optString("sha").take(7),
                c?.optString("message").orEmpty().substringBefore("\n"),
                c?.optJSONObject("author")?.optString("name").orEmpty(),
                c?.optJSONObject("author")?.optString("date").orEmpty(),
                j.optString("html_url")
            )
        }
    }

    // ---------- Gitee Go（流水线） ----------

    /**
     * Gitee Go 目前**没有**公开的 REST API。
     * Gitee 官方 issue（oschina/git-osc IHWZMT）已确认：
     *   GET /v5/repos/{owner}/{repo}/pipelines  -> 404
     *   GET /v5/repos/{owner}/{repo}/actions/runs -> 405
     * 所以这里不伪造数据，而是给出明确原因，让界面提示去网页端操作。
     */
    private fun giteeGoUnsupported(): Nothing =
        throw ApiException(501, "Gitee Go 未提供公开的流水线 API，无法在应用内触发构建或读取日志，请在网页端 Gitee Go 页面操作")

    fun workflows(owner: String, name: String): List<Workflow> = emptyList()

    fun dispatch(owner: String, name: String, workflowId: Long, ref: String, inputs: Map<String, String>) {
        giteeGoUnsupported()
    }

    fun runs(owner: String, name: String): List<WorkflowRun> = emptyList()

    fun runsFor(owner: String, name: String, workflowId: Long): List<WorkflowRun> = emptyList()

    fun jobs(owner: String, name: String, runId: Long): List<WorkflowJob> = emptyList()

    fun cancelRun(owner: String, name: String, runId: Long) { giteeGoUnsupported() }

    fun rerunRun(owner: String, name: String, runId: Long) { giteeGoUnsupported() }

    fun rerunFailed(owner: String, name: String, runId: Long) { giteeGoUnsupported() }

    fun runLogsZip(owner: String, name: String, runId: Long): ByteArray = giteeGoUnsupported()

    fun jobLogsZip(owner: String, name: String, jobId: Long): ByteArray = giteeGoUnsupported()

    fun artifacts(owner: String, name: String, runId: Long): List<Artifact> = emptyList()

    fun artifactDownloadUrl(owner: String, name: String, artifactId: Long): String = giteeGoUnsupported()

    fun artifactWebUrl(owner: String, name: String, runId: Long, artifactId: Long) =
        "https://gitee.com/$owner/$name"

    fun artifactApiUrl(owner: String, name: String, artifactId: Long) =
        "https://gitee.com/$owner/$name"

    fun artifactCurl(owner: String, name: String, artifactId: Long): String =
        "# Gitee Go 无公开产物 API，请在网页端 Gitee Go 的构建历史里下载"

    fun artifactBytes(owner: String, name: String, artifactId: Long): ByteArray = giteeGoUnsupported()

    // ---------- Issues / Pull Requests ----------

    fun issues(owner: String, name: String, state: String): List<Issue> {
        val a = JSONArray(call("${repo(owner, name)}/issues?state=$state&per_page=50&sort=updated"))
        return (0 until a.length()).map { parseIssue(a.getJSONObject(it)) }
    }

    fun pulls(owner: String, name: String, state: String): List<Issue> {
        val a = JSONArray(call("${repo(owner, name)}/pulls?state=$state&per_page=50&sort=updated"))
        return (0 until a.length()).map { index ->
            // range.map 的 lambda 参数是索引 Int，必须先取出 JSONObject 再使用
            val j = a.getJSONObject(index)
            parseIssue(j).copy(isPull = true, draft = j.optBoolean("draft"), merged = j.optBoolean("merged"))
        }
    }

    private fun parseIssue(j: JSONObject) = Issue(
        j.optInt("number"),
        j.optString("title"),
        j.optString("state"),
        j.optJSONObject("user")?.optString("login").orEmpty(),
        j.optString("created_at"),
        j.optString("updated_at"),
        j.optInt("comments"),
        j.optString("body").orEmpty(),
        j.optString("html_url")
    )

    fun createIssue(owner: String, name: String, title: String, body: String): Int {
        val payload = JSONObject().put("title", title).put("body", body)
        return JSONObject(call("${repo(owner, name)}/issues", "POST", payload.toString())).optInt("number")
    }

    fun setIssueState(owner: String, name: String, number: Int, state: String) {
        call("${repo(owner, name)}/issues/$number", "PATCH", JSONObject().put("state", state).toString())
    }

    fun comments(owner: String, name: String, number: Int): List<Comment> {
        val a = JSONArray(call("${repo(owner, name)}/issues/$number/comments?per_page=100"))
        return (0 until a.length()).map {
            val j = a.getJSONObject(it)
            Comment(
                j.optLong("id"),
                j.optJSONObject("user")?.optString("login").orEmpty(),
                j.optString("body"),
                j.optString("created_at")
            )
        }
    }

    fun addComment(owner: String, name: String, number: Int, body: String) {
        call("${repo(owner, name)}/issues/$number/comments", "POST", JSONObject().put("body", body).toString())
    }

    fun mergePull(owner: String, name: String, number: Int, method: String = "merge") {
        call("${repo(owner, name)}/pulls/$number/merge", "PUT", JSONObject().put("merge_method", method).toString())
    }

    // ---------- Releases ----------

    fun releases(owner: String, name: String): List<Release> {
        val a = JSONArray(call("${repo(owner, name)}/releases?per_page=30"))
        return (0 until a.length()).map {
            val j = a.getJSONObject(it)
            val assets = j.optJSONArray("assets")
            val list = mutableListOf<ReleaseAsset>()
            if (assets != null) {
                for (i in 0 until assets.length()) {
                    val x = assets.getJSONObject(i)
                    list += ReleaseAsset(
                        x.optLong("id"), x.optString("name"), x.optLong("size"),
                        x.optInt("download_count"), "${repo(owner, name)}/releases/assets/${x.optLong("id")}"
                    )
                }
            }
            Release(
                j.optLong("id"), j.optString("tag_name"), j.optString("name").ifBlank { j.optString("tag_name") },
                j.optString("body"), j.optString("created_at").ifBlank { j.optString("published_at") }, j.optString("html_url"),
                j.optBoolean("draft"), j.optBoolean("prerelease"), list
            )
        }
    }

    fun releaseAssetBytes(owner: String, name: String, assetId: Long): ByteArray {
        val path = "${repo(owner, name)}/releases/assets/$assetId"
        val request = headers(Request.Builder().url(url(path)))
            .header("Accept", "application/octet-stream").build()
        noRedirect.newCall(request).execute().use { resp ->
            if (resp.code in 301..308) {
                val location = resp.header("Location") ?: throw ApiException(500, "缺少下载地址")
                return transfer.newCall(Request.Builder().url(location).header("Accept", "application/octet-stream").build())
                    .execute().use { it.body?.bytes() ?: throw ApiException(500, "空响应") }
            }
            if (!resp.isSuccessful) throw ApiException(resp.code, parseError(resp.code, resp.body?.string().orEmpty()))
            return resp.body?.bytes() ?: throw ApiException(500, "空响应")
        }
    }

    // ---------- 通用二进制下载（两段式，跳转后不带令牌） ----------

    /**
     * 下载二进制内容（日志 zip / 产物 zip）。
     *
     * Gitee 的下载接口会 302 到 Azure Blob：如果带着 Authorization 头跟随重定向，
     * Azure 会拒绝，所以这里先不跟随拿到 Location，再用「无令牌」的客户端下载。
     */
    private fun binary(path: String): ByteArray {
        val request = headers(Request.Builder().url(url(path))).build()
        noRedirect.newCall(request).execute().use { first ->
            val redirected = first.code in 301..308
            if (redirected) {
                val location = first.header("Location") ?: throw ApiException(500, "下载链接为空")
                val resolved = first.request.url.resolve(location)?.toString() ?: location
                require(resolved.startsWith("https://")) { "拒绝非 HTTPS 下载地址" }
                // 重定向到 Azure 时不能带 Gitee 令牌，否则会被拒绝
                return downloadWithLimit(resolved, false)
            }
            if (!first.isSuccessful) {
                throw ApiException(first.code, parseError(first.code, first.body?.string().orEmpty()))
            }
            return readCapped(first.body) ?: throw ApiException(500, "响应体为空")
        }
    }

    /** 带体积上限的下载，避免超大日志把内存打爆 */
    private fun downloadWithLimit(target: String, withAuth: Boolean): ByteArray {
        val builder = Request.Builder().url(target).header("User-Agent", "GiteeManager-Android")
        if (withAuth) headers(builder)
        transfer.newCall(builder.build()).execute().use { resp ->
            if (!resp.isSuccessful) throw ApiException(resp.code, "下载失败（HTTP ${resp.code}）")
            return readCapped(resp.body) ?: throw ApiException(500, "响应体为空")
        }
    }

    /**
     * 流式读取并计数；超过 MAX_DOWNLOAD 直接报错，而不是把整个文件读进内存导致 OOM。
     */
    private fun readCapped(body: okhttp3.ResponseBody?): ByteArray? {
        val source = body ?: return null
        val collector = java.io.ByteArrayOutputStream()
        val buffer = ByteArray(64 * 1024)
        source.byteStream().use { stream ->
            var total = 0L
            while (true) {
                val n = stream.read(buffer)
                if (n <= 0) break
                total += n
                if (total > MAX_DOWNLOAD) {
                    throw ApiException(413, "内容超过 ${MAX_DOWNLOAD / 1024 / 1024} MB，已中止下载")
                }
                collector.write(buffer, 0, n)
            }
        }
        return collector.toByteArray()
    }

    /** 路径分段各自的 URL 编码，保留 "/" 作为层级分隔 */
    private fun String.encodePath(): String = split("/").joinToString("/") { enc(it) }
}

/** JSON 字符串转义，避免提交信息里的引号 / 换行破坏结构 */
private fun jsonEscape(s: String): String {
    val sb = StringBuilder(s.length + 8)
    for (c in s) {
        when {
            c == '"' -> sb.append("\\\"")
            c == '\\' -> sb.append("\\\\")
            c == '\n' -> sb.append("\\n")
            c == '\r' -> sb.append("\\r")
            c == '\t' -> sb.append("\\t")
            c.code < 0x20 -> sb.append("\\u").append(c.code.toString(16).padStart(4, '0'))
            else -> sb.append(c)
        }
    }
    return sb.toString()
}

/**
 * 边读边编码的 Base64 写入器：把输入流直接编码进 Okio sink，
 * 不需要把整个文件读进内存，因此支持上传 100 MB 的文件。
 */
private class Base64Encoder(private val sink: okio.BufferedSink) {
    private val table = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".toByteArray()
    private var acc = 0
    private var bits = 0
    private val buf = ByteArray(4)
    private var pos = 0

    private fun emit(value: Int) {
        buf[pos++] = value.toByte()
        if (pos == 4) {
            sink.write(buf, 0, 4)
            pos = 0
        }
    }

    fun update(bytes: ByteArray, length: Int) {
        for (i in 0 until length) {
            acc = (acc shl 8) or (bytes[i].toInt() and 0xFF)
            bits += 8
            while (bits >= 6) {
                bits -= 6
                emit(table[(acc shr bits) and 0x3F].toInt())
            }
        }
    }

    /** 写出剩余位并补 '=' 填充，使总长度为 4 的倍数 */
    fun finish() {
        if (bits > 0) emit(table[(acc shl (6 - bits)) and 0x3F].toInt())
        while (pos != 0) emit('='.code)
    }
}

/** 流式上传请求体：JSON 头 → Base64 正文 → JSON 尾，全程不落地、不整体驻留内存 */
private class StreamUploadBody(
    private val context: android.content.Context,
    private val uri: android.net.Uri,
    message: String,
    sha: String?,
    branch: String,
    private val fileSize: Long
) : okhttp3.RequestBody() {

    private val head: String = buildString {
        append("{\"message\":\"").append(jsonEscape(message)).append('"')
        if (!sha.isNullOrBlank()) append(",\"sha\":\"").append(jsonEscape(sha)).append('"')
        if (branch.isNotBlank()) append(",\"branch\":\"").append(jsonEscape(branch)).append('"')
        append(",\"content\":\"")
    }
    private val tail = "\"}"

    override fun contentType() = "application/json; charset=utf-8".toMediaType()

    override fun contentLength(): Long {
        if (fileSize < 0) return -1L
        val encoded = ((fileSize + 2) / 3) * 4
        return head.length.toLong() + encoded + tail.length
    }

    override fun writeTo(sink: okio.BufferedSink) {
        sink.writeUtf8(head)
        val encoder = Base64Encoder(sink)
        val input = context.contentResolver.openInputStream(uri)
            ?: throw java.io.IOException("无法读取所选文件")
        input.use { stream ->
            val buffer = ByteArray(64 * 1024)
            while (true) {
                val n = stream.read(buffer)
                if (n <= 0) break
                encoder.update(buffer, n)
            }
        }
        encoder.finish()
        sink.writeUtf8(tail)
    }
}
