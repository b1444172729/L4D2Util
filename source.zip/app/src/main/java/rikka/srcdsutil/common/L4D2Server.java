package rikka.srcdsutil.common;

import java.io.UnsupportedEncodingException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

import rikka.srcdsutil.R;

/**
 * Created by Administrator on 2/13/2018.
 *
 * 【本次修复】"无法识别的服务器" 的真正原因：A2S Challenge
 *
 * Source 引擎（含 L4D2）支持一项反 UDP 放大攻击的机制：服务器可以对 A2S_INFO
 * 查询返回一个 CHALLENGE 响应，而不是直接返回数据：
 *
 *     FF FF FF FF 41 XX XX XX XX     (共 9 字节)
 *                   ^^ 0x41 = 'A' = A2S_SERVERQUERY_GETCHALLENGE
 *                      ^^^^^^^^^^^ 4 字节 challenge 值
 *
 * 客户端必须把这 4 个字节原样附在查询包末尾重发一次，才会拿到真正的服务器信息。
 *
 * 原版代码只认两种响应：
 *     recvBuf[4] == 0x49 ('I')  →  Source 引擎 A2S_INFO 数据
 *     recvBuf[4] == 0x6D ('m')  →  GoldSrc 引擎数据
 * 收到 0x41 时两个分支都不匹配，直接 return new Info()（版本 = UNKNOWN），
 * 于是界面显示"无法识别的服务器"。
 *
 * 有意思的是，同一个文件里的 GetPlayerList() 早就把这套 challenge 流程写对了
 * （它先发全 0 的 challenge、等服务器回 'A'、再回填重发），只有 QueryServerInfo()
 * 漏掉了。属于原作者的代码疏漏 —— 凡是开启了 challenge 的服务器（现在很常见）
 * 就必然踩到。
 *
 * 顺带放宽/修正的三处：
 *   1) 不再要求 protocol 必须等于 0x11(17)。protocol 是引擎网络协议号，会随
 *      游戏版本变化，用它当识别条件很脆弱；靠响应类型 0x49 识别就够了。
 *   2) parse_l4d2_responce() 校验 appid == 550 失败时不再直接返回 null，
 *      改为保留已解析出的信息、只把版本标为 UNKNOWN，避免整条信息丢失。
 *   3) playerCount / slotCount 改用 & 0xFF 取值，槽位超过 127 时不再变负数。
 *   4) 接收缓冲从 512 扩到 2048，避免服务器名较长时响应被截断。
 */

public class L4D2Server {
    private final static byte[] requestQueryServerInfo = {
            (byte) 0xff, (byte) 0xff, (byte) 0xff, (byte) 0xff, 0x54, 0x53, 0x6f, 0x75,
            0x72, 0x63, 0x65, 0x20, 0x45, 0x6e, 0x67, 0x69,
            0x6e, 0x65, 0x20, 0x51, 0x75, 0x65, 0x72, 0x79,
            0x00 };

    private final static byte[] requestGetPlayerList = {
            (byte) 0xff, (byte) 0xff, (byte) 0xff, (byte) 0xff, 0x55, 0x00, 0x00, 0x00,
            0x00 };

    /** 响应类型标识 */
    private final static byte A2S_INFO = 0x49;           // 'I' Source 引擎服务器信息
    private final static byte A2S_GOLDSRC_INFO = 0x6D;   // 'm' GoldSrc 引擎服务器信息
    private final static byte A2S_CHALLENGE = 0x41;      // 'A' 服务器要求先换取 challenge
    private final static byte A2S_PLAYER = 0x44;         // 'D' 玩家列表

    /** 接收缓冲大小，A2S 响应最长可达 1400 字节左右 */
    private final static int BUFFER_SIZE = 2048;

    public enum SrcDsVersion {
        UNKNOWN(0), L4D2(1), CS16(2);

        public final int val;
        SrcDsVersion(int val) {
            this.val = val;
        }
    }

    private final static int gameNameLocateIndex[] = {R.string.game_unknown, R.string.game_l4d2, R.string.game_cs16};

    public static class Info {
        public String serverName;
        public String mapName;
        public String directory;
        public String gameType;
        /** 改为 int 并用 & 0xFF 取值，避免槽位超过 127 时变成负数 */
        public int playerCount;
        public int slotCount;
        public SrcDsVersion version;

        private Info() {
            this.version = SrcDsVersion.UNKNOWN;
        }

        public int getGameVersionLocateIndex() {
            return gameNameLocateIndex[version.val];
        }
    }

    private static int getSegmentLength(byte[] bytes, int offset, int length) {
        int pos = offset;
        for (; pos < length; pos++) {
            if (bytes[pos] == 0)
                break;
        }
        return pos - offset;
    }

    private static Info parse_l4d2_responce(byte[] recvBuf, int recvBufLength) throws UnsupportedEncodingException {
        Info info = new Info();
        info.version = SrcDsVersion.L4D2;

        int segmentStart = 6;
        int segmentLength = getSegmentLength(recvBuf, segmentStart, recvBufLength);
        info.serverName = new String(recvBuf, segmentStart, segmentLength, "UTF-8");
        segmentStart += segmentLength + 1;

        segmentLength = getSegmentLength(recvBuf, segmentStart, recvBufLength);
        info.mapName = new String(recvBuf, segmentStart, segmentLength, "UTF-8");
        segmentStart += segmentLength + 1;

        segmentLength = getSegmentLength(recvBuf, segmentStart, recvBufLength);
        info.directory = new String(recvBuf, segmentStart, segmentLength, "UTF-8");
        segmentStart += segmentLength + 1;

        segmentLength = getSegmentLength(recvBuf, segmentStart, recvBufLength);
        info.gameType = new String(recvBuf, segmentStart, segmentLength, "UTF-8");
        segmentStart += segmentLength + 1;

        if (segmentStart + 3 >= recvBufLength) {
            // 响应被截断，能解析多少算多少
            return info;
        }

        if (recvBuf[segmentStart] != 0x26 || recvBuf[segmentStart + 1] != 0x02) {
            // appid 不是 550(L4D2)，但仍是 Source 服务器：保留已解析出的信息，
            // 只把版本标为 UNKNOWN，不再整条丢弃
            info.version = SrcDsVersion.UNKNOWN;
        }

        info.playerCount = recvBuf[segmentStart + 2] & 0xFF;
        info.slotCount = recvBuf[segmentStart + 3] & 0xFF;

        return info;
    }

    private static Info parse_cs16_responce(byte[] recvBuf, int recvBufLength) throws UnsupportedEncodingException {
        Info info = new Info();
        info.version = SrcDsVersion.CS16;

        int segmentStart = 5;
        int segmentLength = getSegmentLength(recvBuf, segmentStart, recvBufLength);
        segmentStart += segmentLength + 1;
        segmentLength = getSegmentLength(recvBuf, segmentStart, recvBufLength);
        info.serverName = new String(recvBuf, segmentStart, segmentLength, "UTF-8");
        segmentStart += segmentLength + 1;


        segmentLength = getSegmentLength(recvBuf, segmentStart, recvBufLength);
        info.mapName = new String(recvBuf, segmentStart, segmentLength, "UTF-8");
        segmentStart += segmentLength + 1;

        segmentLength = getSegmentLength(recvBuf, segmentStart, recvBufLength);
        info.directory = new String(recvBuf, segmentStart, segmentLength, "UTF-8");
        segmentStart += segmentLength + 1;

        segmentLength = getSegmentLength(recvBuf, segmentStart, recvBufLength);
        info.gameType = new String(recvBuf, segmentStart, segmentLength, "UTF-8");
        segmentStart += segmentLength + 1;

        if (segmentStart + 1 >= recvBufLength) {
            return info;
        }

        info.playerCount = recvBuf[segmentStart] & 0xFF;
        info.slotCount = recvBuf[segmentStart + 1] & 0xFF;

        return info;
    }

    /**
     * 查询服务器信息。会自动处理服务器要求 challenge 的情况。
     */
    public static Info QueryServerInfo(String hostname, int port) {
        DatagramSocket socket = null;
        try {
            InetAddress hostAddr = InetAddress.getByName(hostname);
            socket = new DatagramSocket(0);
            socket.setSoTimeout(5000);

            DatagramPacket response = new DatagramPacket(new byte[BUFFER_SIZE], BUFFER_SIZE);

            // ---- 第一次请求 ----
            socket.send(new DatagramPacket(requestQueryServerInfo,
                    requestQueryServerInfo.length, hostAddr, port));
            socket.receive(response);

            byte[] buf = response.getData();
            int len = response.getLength();

            if (!isMagicHeader(buf, len)) {
                return null;
            }

            // ---- 服务器要求 challenge：取出 4 字节，原样附在请求末尾重发 ----
            if (len >= 9 && (buf[4] & 0xff) == (A2S_CHALLENGE & 0xff)) {
                byte[] req2 = new byte[requestQueryServerInfo.length + 4];
                System.arraycopy(requestQueryServerInfo, 0, req2, 0, requestQueryServerInfo.length);
                System.arraycopy(buf, 5, req2, requestQueryServerInfo.length, 4);

                response = new DatagramPacket(new byte[BUFFER_SIZE], BUFFER_SIZE);
                socket.send(new DatagramPacket(req2, req2.length, hostAddr, port));
                socket.receive(response);

                buf = response.getData();
                len = response.getLength();

                if (!isMagicHeader(buf, len) || len < 6) {
                    return null;
                }
            }

            // ---- 解析真正的响应（不再要求 protocol == 0x11）----
            if ((buf[4] & 0xff) == (A2S_INFO & 0xff)) {
                return parse_l4d2_responce(buf, len);
            } else if ((buf[4] & 0xff) == (A2S_GOLDSRC_INFO & 0xff)) {
                return parse_cs16_responce(buf, len);
            }

            return new Info();
        } catch (Exception e) {
            return null;
        } finally {
            if (socket != null) {
                try {
                    socket.close();
                } catch (Exception ignored) {
                }
            }
        }
    }

    private static boolean isMagicHeader(byte[] buf, int len) {
        return len >= 5 &&
                (buf[0] & 0xff) == 0xff &&
                (buf[1] & 0xff) == 0xff &&
                (buf[2] & 0xff) == 0xff &&
                (buf[3] & 0xff) == 0xff;
    }

    public static String[] GetPlayerList(String hostname, int port) {
        DatagramSocket socket = null;
        try {
            InetAddress hostAddr = InetAddress.getByName(hostname);
            socket = new DatagramSocket(0);
            socket.setSoTimeout(10000);

            DatagramPacket response = new DatagramPacket(new byte[BUFFER_SIZE], BUFFER_SIZE);

            // 玩家查询同样会被要求 challenge：先发全 0 的 challenge 换取
            socket.send(new DatagramPacket(requestGetPlayerList,
                    requestGetPlayerList.length, hostAddr, port));
            socket.receive(response);

            byte[] recvBuf = response.getData();
            int recvBufLength = response.getLength();

            if (!isMagicHeader(recvBuf, recvBufLength) ||
                    (recvBuf[4] & 0xff) != (A2S_CHALLENGE & 0xff)) {
                // Invalid responce from server
                return null;
            }

            // 把服务器给的 challenge 填进请求包后重发
            byte[] req2 = new byte[9];
            req2[0] = requestGetPlayerList[0];
            req2[1] = requestGetPlayerList[1];
            req2[2] = requestGetPlayerList[2];
            req2[3] = requestGetPlayerList[3];
            req2[4] = requestGetPlayerList[4];     // 0x55
            System.arraycopy(recvBuf, 5, req2, 5, 4);

            response = new DatagramPacket(new byte[BUFFER_SIZE], BUFFER_SIZE);
            socket.send(new DatagramPacket(req2, req2.length, hostAddr, port));
            socket.receive(response);

            recvBufLength = response.getLength();
            recvBuf = response.getData();

            if (!isMagicHeader(recvBuf, recvBufLength) ||
                    (recvBuf[4] & 0xff) != (A2S_PLAYER & 0xff)) {
                // Invalid responce from server
                return null;
            }

            int playerCount = recvBuf[5] & 0xFF;
            String[] players = new String[playerCount];

            // 偏移 6 是第一个玩家的 index 字节，名字从 7 开始
            int segmentStart = 7;
            for (int i=0; i<playerCount; i++) {
                if (segmentStart >= recvBufLength) {
                    break;
                }
                int segmentLength = getSegmentLength(recvBuf, segmentStart, recvBufLength);
                players[i] = new String(recvBuf, segmentStart, segmentLength, "UTF-8");
                segmentStart += segmentLength + 10;
            }

            return players;
        } catch (Exception e) {
            return null;
        } finally {
            if (socket != null) {
                try {
                    socket.close();
                } catch (Exception ignored) {
                }
            }
        }
    }
}
