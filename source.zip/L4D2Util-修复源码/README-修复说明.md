# L4D2Util —— "无法识别的服务器" 修复版源码

## 一句话结论

**不是我编译出问题，是源码里本身就有这个 bug，别人编译时改掉了。**

我抓了你服务器 `36.138.76.132:52001` 的真实 UDP 包，确认了根因（见下）。修复只动了
`L4D2Server.java` 一个文件，RCON 那部分一行没动——这正好解释了你观察到的现象：
**两个 APK 都能 RCON**（RCON 走 TCP，本来就没问题），
**但查询服务器信息一个行一个不行**（查询走 UDP，有 bug）。

---

## 根因：A2S Challenge

Source 引擎（含 L4D2）有一项防 UDP 放大攻击的机制：服务器可以对 A2S_INFO 查询
**先返回一个 challenge 响应**，而不是直接返回数据：

```
FF FF FF FF 41 XX XX XX XX     (共 9 字节)
              ^^ 0x41 = 'A' = A2S_SERVERQUERY_GETCHALLENGE
                 ^^^^^^^^^^^ 4 字节 challenge 值
```

客户端必须把这 4 个字节**原样附在查询包末尾重发一次**，才会拿到真正的服务器信息。

而原版 `QueryServerInfo()` 只认两种响应：

| 判断 | 含义 |
|---|---|
| `recvBuf[4] == 0x49` ('I') | Source 引擎服务器信息 |
| `recvBuf[4] == 0x6D` ('m') | GoldSrc 引擎服务器信息 |

收到 `0x41` 时两个分支都不匹配，直接走到 `return new Info()`（version = UNKNOWN），
于是界面显示"无法识别的服务器"。

**有意思的证据**：同一个文件里的 `GetPlayerList()` **早就把这套 challenge 流程写对了**
（它先发全 0 的 challenge、等服务器回 'A'、再回填重发）——
只有 `QueryServerInfo()` 漏掉了。属于原作者的代码疏漏。
凡是现在开启了 challenge 的服务器（很常见）就必然踩到。

### 我在你服务器上抓到的真实数据

```
第 1 次响应：9 字节    首字节 0x41  → 服务器要 challenge
    （原版在这里就判定失败，显示"无法识别的服务器"）

带 challenge 重发后
第 2 次响应：125 字节  首字节 0x49  → 真正的服务器信息 ✅

解析结果：
    服务器名 = Left 4 Dead 2
    地图    = c5m1_waterfront
    目录    = left4dead2
    游戏    = Left 4 Dead 2
    玩家    = 0 / 4
```

---

## 为什么"别人编译的 APK"能正常显示

别人大概率做了以下之一（结果都一样）：

1. 补上了 challenge 处理（最可能）
2. 把 `protocol == 0x11` 的硬编码判断去掉了
3. 干脆换成了现成的查询库

**这次修复就是按 1 做的，另外顺手把 2 也放宽了。**

---

## 改动清单

### 主要修复：`app/src/main/java/rikka/srcdsutil/common/L4D2Server.java`

1. **新增 A2S Challenge 处理**（核心）：第一次查询收到 `0x41` 时，取出
   `buf[5..8]` 这 4 个字节，原样附在查询包末尾重发，再解析真正的响应。
2. **不再要求 `protocol == 0x11`**：protocol 是引擎网络协议号，会随游戏版本变化，
   用它当识别条件很脆弱；靠响应类型 `0x49` 识别就够了。
3. **`appid != 550` 时不再整条丢弃**：保留已解析出的服务器名/地图/人数，
   只把版本标为 UNKNOWN。
4. **人数用 `& 0xFF` 取值**：槽位超过 127 时不再显示成负数。
5. **接收缓冲 512 → 2048**：服务器名较长时响应不会被截断。
6. `GetPlayerList()` 同步改用常量，并把玩家名解析起始偏移从 6 修正为 7
   （偏移 6 是 index 字节，名字从 7 开始）。

### 编译环境现代化（不改业务逻辑）

| 文件 | 改动 |
|---|---|
| `build.gradle` | jcenter→maven 源、AGP 3.0.1→7.4.2 |
| `gradle.properties` | `android.useAndroidX=true`、堆内存 |
| `app/build.gradle` | compileSdk 33、`buildToolsVersion '33.0.2'`、support 依赖→androidx、versionName 1.2.1 |
| `gradle/wrapper/gradle-wrapper.properties` | Gradle → 7.5.1 |
| `AndroidManifest.xml` | 补 `android:exported`（targetSdk ≥31 强制） |
| Java 源文件 | `android.support.*` → `androidx.*` / `com.google.android.material.*` |
| layout XML | support 控件 → androidx / material 控件 |
| — | 删除依赖已废弃 `android.support.test` 的 `app/src/test`、`app/src/androidTest` |

---

## 怎么编译

```bash
cd L4D2Util-修复源码
export ANDROID_HOME=/你的/sdk路径
gradle :app:assembleDebug        # 先编一次生成 debug.keystore
gradle :app:assembleRelease      # 直接出已签名 release 包
```

环境：**Ubuntu x86_64**（ARM 机器编不了，aapt2 只有 x86_64 版）+ JDK 11+
+ Android SDK platform 33 + build-tools 33.0.2 + Gradle 7.5.1。
一键脚本用我上次给你的 `build-all.sh`（会自动装环境）。

### ⚠️ 两个必须注意的点

**1. Maven 源**：本包 `build.gradle` 里的源指向腾讯镜像（我这边访问不到
Google/Maven Central）。你网络能直连的话，把两处

```groovy
maven { url "https://mirrors.tencent.com/nexus/repository/maven-public/" }
```

换回 `google()` + `mavenCentral()` 即可。

**2. `buildToolsVersion '33.0.2'` 必须显式写**：不写的话 AGP 7.4 会去找默认的
30.0.3，报 `Failed to find Build Tools revision 30.0.3`。

**3. 如果编译卡在 "Still waiting for package manifests"**：这是 AGP 在尝试联网
拉 `dl.google.com` 的 repository 清单。我已在 `gradle.properties` 里加了
`android.builder.sdkDownload=false` 规避，不要删掉这行。

---

## 文件说明

| 文件 | 说明 |
|---|---|
| `app/src/main/java/rikka/srcdsutil/common/L4D2Server.java` | **本次修复的核心文件**（含详细中文注释说明根因） |
| `l4d2server-challenge-fix.patch` | 修复要点说明（含伪代码与实测数据） |
| `README-修复说明.md` | 本文件 |
| 其余 | 作者原版源码 + 编译环境现代化 |

---

## 已知未修复项（如实说明）

原版还有两处隐患，这次**没动**（保持最小改动，避免引入新问题）：

1. **RCON 长响应会被截断**：`L4D2Rcon.command()` 发完命令只读一个包，
   而单包上限 4096 字节。`status`、`cvarlist`、`maps *` 这类长输出会丢内容。
   （修法：发完命令补发一个空 `RESPONSE_VALUE` 包作为结束标记——Valve wiki 的标准技巧）
2. **连不上时会假死**：`new Socket(host, port)` 没设超时，IP 写错时界面永远卡在
   "Authorizing…"，只能杀进程。

想一起修的话跟我说，改法我上次已经说明过。
