package rikka.android;

import android.content.Context;
import android.content.DialogInterface;
import android.text.InputType;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;

/**
 * Created by Rikka0w0 on 2/13/2018.
 *
 * 改动一：原来 message 用 builder.setMessage() 显示、输入框用 builder.setView() 单独设置，
 * AlertDialog 会在 message 区和自定义内容区之间留一大段空白，看起来像隔了几个空行。
 * 现在把 message 和输入框放进同一个垂直 LinearLayout 一起作为 setView 的内容，两者紧挨着。
 *
 * 改动二：提示文字与标题左对齐。
 * 对话框标题由系统布局渲染（带自己的左内边距），自定义内容区又有另一套内边距，
 * 两边数值不同，所以提示文字和标题不对齐。
 * 这里在对话框显示后实测两者的屏幕坐标，把差值补到提示文字的左内边距上，
 * 不依赖任何具体数值，换主题/换系统版本也不会错位。
 */
public class InputBox {
    public static void show(Context context, String message, String title, String defaultText, final IInputBoxHandler eventHandler) {
        show(context, message, title, defaultText, InputType.TYPE_CLASS_TEXT, eventHandler);
    }

    public static void show(Context context, String message, String title, String defaultText, int inputType, final IInputBoxHandler eventHandler) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(title);

        float density = context.getResources().getDisplayMetrics().density;
        int padH = (int) (20 * density);   // 左右留白
        int padTop = (int) (8 * density);  // 标题与第一行之间的间距
        int gap = (int) (8 * density);     // 提示文字与输入框之间的间距

        // 把提示文字和输入框放进同一个容器，保证两者紧挨着
        final LinearLayout container = new LinearLayout(context);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setPadding(padH, padTop, padH, 0);

        final TextView messageView;
        if (message != null && message.length() > 0) {
            messageView = new TextView(context);
            messageView.setText(message);
            messageView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            // 用主题的次要文字颜色，和系统默认提示文字观感一致
            messageView.setTextColor(resolveSecondaryTextColor(context));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.bottomMargin = gap;   // 提示文字与输入框之间只留很小的间距
            container.addView(messageView, lp);
        } else {
            messageView = null;
        }

        // Set up the input
        final EditText input = new EditText(context);
        // Specify the type of input expected; this, for example, sets the input as a password, and will mask the text
        input.setInputType(inputType);
        input.setText(defaultText);
        container.addView(input, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        builder.setView(container);

        // Set up the buttons
        builder.setNegativeButton(context.getString(android.R.string.cancel), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                eventHandler.onClose(null);
                dialog.cancel();
            }
        });

        builder.setPositiveButton(context.getString(android.R.string.ok), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                eventHandler.onClose(input.getText().toString());
            }
        });

        final AlertDialog dialog = builder.create();
        final String finalTitle = title;
        dialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface d) {
                alignMessageWithTitle(dialog, container, messageView, finalTitle);
            }
        });
        dialog.show();
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    /// 标题与提示文字左对齐
    //////////////////////////////////////////////////////////////////////////////////////////////

    /**
     * 让提示文字的"文字起始位置"与标题的"文字起始位置"对齐。
     *
     * 做法：对话框显示并布局完成后，实测两者在屏幕上的横坐标（含各自内边距），
     * 把差值补到提示文字的左内边距上。
     * 不写死任何 dp 数值，因此不同主题、不同系统版本都不会错位。
     */
    private static void alignMessageWithTitle(final AlertDialog dialog, final LinearLayout container,
                                              final TextView messageView, final String title) {
        if (messageView == null) return;
        messageView.post(new Runnable() {
            @Override
            public void run() {
                View titleView = findTitleView(dialog, title);
                if (titleView == null || titleView.getWidth() == 0) return;

                int[] t = new int[2];
                int[] m = new int[2];
                titleView.getLocationOnScreen(t);
                messageView.getLocationOnScreen(m);

                // 文字起始位置 = 视图左边缘 + 自身左内边距
                int titleTextX = t[0] + titleView.getPaddingLeft();
                int messageTextX = m[0] + messageView.getPaddingLeft();

                int delta = titleTextX - messageTextX;
                if (delta == 0) return;

                // 把差值补到【容器】的左内边距上，而不是提示文字自己：
                // 提示文字往左移只能用负内边距，做不到；容器往回收才正确。
                int newLeft = container.getPaddingLeft() + delta;
                if (newLeft < 0) newLeft = 0;
                container.setPadding(newLeft, container.getPaddingTop(),
                        container.getPaddingRight(), container.getPaddingBottom());
            }
        });
    }

    /**
     * 找到对话框的标题视图。
     *
     * 不写死 AppCompat 的内部 id（不同版本 id 名可能变），
     * 而是先试系统标准的 android.R.id.title，
     * 找不到就在窗口里按"文字等于标题"遍历定位——这样换主题、换 AppCompat 版本都不会失效。
     */
    private static View findTitleView(AlertDialog dialog, String title) {
        try {
            View v = dialog.findViewById(android.R.id.title);
            if (v != null && v.getWidth() > 0) {
                return v;
            }
        } catch (Throwable ignored) {
        }

        android.view.Window window = dialog.getWindow();
        if (window == null) {
            return null;
        }
        return findTextViewWithText(window.getDecorView(), title);
    }

    /** 在视图树里找文本内容等于给定文本的 TextView */
    private static View findTextViewWithText(View root, String text) {
        if (root == null || text == null) {
            return null;
        }
        if (root instanceof TextView) {
            CharSequence t = ((TextView) root).getText();
            if (t != null && text.equals(t.toString())) {
                return root;
            }
        }
        if (root instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) root;
            for (int i = 0; i < group.getChildCount(); i++) {
                View r = findTextViewWithText(group.getChildAt(i), text);
                if (r != null) {
                    return r;
                }
            }
        }
        return null;
    }

    /** 取主题的次要文字颜色，取不到就用灰色兜底 */
    private static int resolveSecondaryTextColor(Context context) {
        TypedValue tv = new TypedValue();
        if (context.getTheme().resolveAttribute(android.R.attr.textColorSecondary, tv, true)
                && tv.type >= TypedValue.TYPE_FIRST_COLOR_INT && tv.type <= TypedValue.TYPE_LAST_COLOR_INT) {
            return tv.data;
        }
        return 0xFF757575;
    }

    public interface IInputBoxHandler {
        /**
         * @param text null if cancelled
         */
        void onClose(String text);
    }
}
