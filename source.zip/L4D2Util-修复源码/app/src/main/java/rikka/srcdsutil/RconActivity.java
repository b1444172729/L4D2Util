package rikka.srcdsutil;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.InputType;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

import rikka.android.InputBox;
import rikka.srcdsutil.common.L4D2Cmds;
import rikka.srcdsutil.common.L4D2Rcon;
import rikka.srcdsutil.common.L4D2Server;
import rikka.srcdsutil.common.Player;
import rikka.srcdsutil.common.ServerInfoText;

/**
 * RCON 远程控制界面。
 *
 * 功能菜单取自最新 Windows 版 RCON.bat，顺序与界面一致：
 *   1 信息查询 / 2 设置人数 / 3 更换地图 / 4 踢出玩家 / 5 队友伤害
 *   6 难度更改 / 7 更换模式 / 8 关闭服务 / 9 协议诊断
 *
 * （RCON.bat 主菜单里还有 [9] 执行命令 / [10] 切换服务器，
 *   "执行命令"对应界面底部那条手输命令栏，"切换服务器"在 App 里本来就是返回服务器列表，
 *   所以没有重复做成菜单项。）
 *
 * 沿用脚本踩坑后定下的经验：
 *  - 进界面只建一条 TCP 连接、只认证一次，之后所有命令复用它。
 *    每条命令都新建连接 + 重新认证，连续操作会触发 srcds 的 RCON 防护，
 *    表现为第二条命令"服务器没有回应认证包"。
 *  - 相邻命令之间至少间隔 200ms。
 *  - 认证失败只对 NOAUTH 重试；BADPASS（密码错）和 CONNECT（端口不通）不重试，
 *    重试只会累积失败次数，触发 sv_rcon_banpenalty 把 IP 临时封掉。
 */
public class RconActivity extends AppCompatActivity {

    private String hostname;
    private int port;
    private String password;
    private volatile L4D2Rcon rcon;

    /** 命令节流（脚本 CMD_THROTTLE_MS = 200） */
    private static final long CMD_THROTTLE_MS = 200;
    private volatile long lastCmdMs = 0;

    /** 认证重试（脚本 AUTH_RETRY = 3，间隔 0.3 / 0.8 / 1.5 秒） */
    private static final int AUTH_RETRY = 3;
    private static final long[] AUTH_RETRY_DELAYS = {300, 800, 1500};

    /**
     * 换图后的重连参数。
     * changelevel 之后 srcds 会重置已认证的 RCON 连接（或直接断开），
     * 原连接继续发命令会全部无回显。服务器加载新图期间连不上是正常的，
     * 所以这里要重试一段时间而不是只试一次。
     */
    private static final int RECONNECT_TRIES = 10;
    private static final long RECONNECT_DELAY_MS = 3000;

    /** 换图后标记为 true，下次执行命令前先重新建连 + 重新认证 */
    private volatile boolean needReconnect = false;

    /** 已执行关闭/重启类命令后为 true，此后不再尝试重连（服务器确实没了，重连只会空等 30 秒） */
    private volatile boolean serverStopped = false;

    private TextView textStatus;
    private Button btnSend;
    private EditText editTextRconCommand;
    private TextView textViewRconResponce;
    private ScrollView scroll;

    private final int[] MENU_IDS = {
            R.id.menu_info,
            R.id.menu_maxplayers,
            R.id.menu_map,
            R.id.menu_kick,
            R.id.menu_friendlyfire,
            R.id.menu_difficulty,
            R.id.menu_mode,
            R.id.menu_quit,
            R.id.menu_diag,
    };

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_rcon, menu);
        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rcon);

        textStatus = (TextView) findViewById(R.id.text_rconStatus);
        btnSend = (Button) findViewById(R.id.btnSend);
        editTextRconCommand = (EditText) findViewById(R.id.text_rconCommand);
        textViewRconResponce = (TextView) findViewById(R.id.text_rconResponce);
        scroll = (ScrollView) findViewById(R.id.scroll_rconResponce);

        Intent intent = getIntent();
        this.hostname = intent.getStringExtra("hostname");
        this.port = intent.getIntExtra("port", 27015);
        this.password = intent.getStringExtra("password");

        setTitle(R.string.action_rcon);

        textStatus.setText(hostname + ":" + port + "\n" + getString(R.string.rcon_status_authorizing));
        btnSend.setEnabled(false);
        setMenuEnabled(false);
        bindMenu();

        appendLog(getString(R.string.rcon_status_authorizing));
        (new AuthTask()).execute();
    }

    private void bindMenu() {
        View.OnClickListener l = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.menu_info:          onInfoClick(); break;
                    case R.id.menu_maxplayers:    onMaxPlayersClick(); break;
                    case R.id.menu_map:           onMapClick(); break;
                    case R.id.menu_kick:          onKickClick(); break;
                    case R.id.menu_friendlyfire:  onFriendlyFireClick(); break;
                    case R.id.menu_difficulty:    onDifficultyClick(); break;
                    case R.id.menu_mode:          onModeClick(); break;
                    case R.id.menu_quit:          onQuitClick(); break;
                    case R.id.menu_diag:          onDiagClick(); break;
                }
            }
        };
        for (int id : MENU_IDS) {
            View v = findViewById(id);
            if (v != null) v.setOnClickListener(l);
        }
    }

    private void setMenuEnabled(boolean enabled) {
        for (int id : MENU_IDS) {
            View v = findViewById(id);
            if (v != null) v.setEnabled(enabled);
        }
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    /// 1 信息查询（A2S / UDP，对应 RCON.bat 的 [1] + rcon.ps1 的 -Mode a2s）
    //////////////////////////////////////////////////////////////////////////////////////////////

    private void onInfoClick() {
        appendLog(getString(R.string.menu_info) + " ...");
        (new InfoTask()).execute();
    }

    private class InfoTask extends AsyncTask<Void, Void, Object[]> {
        @Override
        protected Object[] doInBackground(Void... v) {
            L4D2Server.Info info = L4D2Server.QueryServerInfo(hostname, port);
            String[] players = L4D2Server.GetPlayerList(hostname, port);
            return new Object[]{info, players};
        }

        @Override
        protected void onPostExecute(Object[] res) {
            L4D2Server.Info info = (L4D2Server.Info) res[0];
            String[] players = (String[]) res[1];
            // 与服务器详情页完全一致（同一方法、同一格式）
            appendLog(ServerInfoText.buildBrief(RconActivity.this, hostname, port, info, players));
        }
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    /// 2 设置人数（M_MAXP）
    //////////////////////////////////////////////////////////////////////////////////////////////

    private void onMaxPlayersClick() {
        InputBox.show(this,
                getString(R.string.msg_maxplayers_hint),
                getString(R.string.menu_maxplayers),
                "",
                InputType.TYPE_CLASS_NUMBER,
                new InputBox.IInputBoxHandler() {
                    @Override
                    public void onClose(String text) {
                        if (text == null) return;
                        String t = text.trim();
                        if (t.isEmpty()) return;
                        if (!t.matches("^\\d+$")) {
                            toast(R.string.msg_need_number);
                            return;
                        }
                        int n;
                        try {
                            n = Integer.parseInt(t);
                        } catch (Exception e) {
                            toast(R.string.msg_need_number);
                            return;
                        }
                        if (n < 1 || n > 32) {
                            toast(R.string.msg_maxplayers_range);
                            return;
                        }
                        // 脚本执行两条：sv_maxplayers + sv_visiblemaxplayers
                        runCommands(L4D2Cmds.cmdMaxPlayers(n));
                    }
                });
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    /// 3 更换地图（M_MAP：官方地图 / 所有地图 / 手动输入）
    //////////////////////////////////////////////////////////////////////////////////////////////

    private void onMapClick() {
        final String[] items = new String[]{
                getString(R.string.map_official),
                getString(R.string.map_all),
                getString(R.string.map_manual),
        };
        new AlertDialog.Builder(this)
                .setTitle(R.string.menu_map)
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        if (which == 0) showOfficialMaps();
                        else if (which == 1) loadAllMaps();
                        else showManualMap();
                    }
                })
                .show();
    }

    private void showOfficialMaps() {
        String[] labels = new String[L4D2Cmds.OFFICIAL_MAPS.length];
        for (int i = 0; i < labels.length; i++) {
            labels[i] = L4D2Cmds.OFFICIAL_MAPS[i][0] + "    " + L4D2Cmds.OFFICIAL_MAPS[i][1];
        }
        new AlertDialog.Builder(this)
                .setTitle(R.string.map_official)
                .setItems(labels, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        runCommands(new String[]{
                                L4D2Cmds.cmdChangelevel(L4D2Cmds.OFFICIAL_MAPS[which][1])
                        });
                    }
                })
                .show();
    }

    private void showManualMap() {
        InputBox.show(this,
                getString(R.string.msg_map_hint),
                getString(R.string.map_manual),
                "",
                InputType.TYPE_CLASS_TEXT,
                new InputBox.IInputBoxHandler() {
                    @Override
                    public void onClose(String text) {
                        if (text == null) return;
                        String m = text.trim();
                        if (m.isEmpty()) return;
                        runCommands(new String[]{L4D2Cmds.cmdChangelevel(m)});
                    }
                });
    }

    /** 从服务器读地图列表：maps * 没输出时退回 maps（与 rcon.ps1 一致） */
    private void loadAllMaps() {
        if (!checkRcon()) return;
        appendLog("> " + L4D2Cmds.CMD_MAPS);
        toast(R.string.msg_loading_maps);
        (new MapsTask()).execute();
    }

    private class MapsTask extends AsyncTask<Void, Void, String> {
        @Override
        protected String doInBackground(Void... v) {
            if (rcon == null) return null;
            ensureLiveConnection();   // 换图后旧连接已失效
            String out = rcon.commandAll(L4D2Cmds.CMD_MAPS);
            if (out == null || out.trim().isEmpty()) {
                appendLog("> " + L4D2Cmds.CMD_MAPS_FALLBACK);
                out = rcon.commandAll(L4D2Cmds.CMD_MAPS_FALLBACK);
            }
            return out;
        }

        @Override
        protected void onPostExecute(String out) {
            if (out == null) {
                appendLog(getString(R.string.rcon_status_command_failed));
                return;
            }
            final List<String> maps = L4D2Cmds.parseMapList(out);
            if (maps.isEmpty()) {
                appendLog(getString(R.string.msg_no_maps));
                appendLog(out);
                return;
            }
            appendLog(getString(R.string.msg_maps_count, maps.size()));
            showMapPicker(maps);
        }
    }

    private void showMapPicker(final List<String> maps) {
        String[] arr = maps.toArray(new String[0]);
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.map_all) + " (" + maps.size() + ")")
                .setItems(arr, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        runCommands(new String[]{L4D2Cmds.cmdChangelevel(maps.get(which))});
                    }
                })
                .show();
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    /// 4 踢出玩家（M_KICK：先 status，再 sm_kick #ID）
    //////////////////////////////////////////////////////////////////////////////////////////////

    private void onKickClick() {
        if (!checkRcon()) return;
        toast(R.string.msg_querying_players);
        (new PlayerTask()).execute();
    }

    private class PlayerTask extends AsyncTask<Void, Void, String> {
        @Override
        protected String doInBackground(Void... v) {
            if (rcon == null) return null;
            ensureLiveConnection();   // 换图后旧连接已失效
            return rcon.command(L4D2Cmds.CMD_STATUS);
        }

        @Override
        protected void onPostExecute(String out) {
            if (out == null) {
                appendLog(getString(R.string.rcon_status_command_failed));
                return;
            }
            final List<Player> players = Player.parseStatus(out);
            if (players.isEmpty()) {
                appendLog(getString(R.string.msg_no_players));
                appendLog(out);
                return;
            }
            String[] labels = new String[players.size()];
            for (int i = 0; i < players.size(); i++) {
                labels[i] = players.get(i).displayLine();
            }
            new AlertDialog.Builder(RconActivity.this)
                    .setTitle(getString(R.string.menu_kick) + " (" + players.size() + ")")
                    .setItems(labels, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface d, int which) {
                            runCommands(new String[]{L4D2Cmds.cmdKick(players.get(which).userId)});
                        }
                    })
                    .show();
        }
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    /// 5 队友伤害（M_FF，每项 4 条命令）
    //////////////////////////////////////////////////////////////////////////////////////////////

    private void onFriendlyFireClick() {
        final String[] items = new String[]{
                getString(R.string.ff_on),
                getString(R.string.ff_off),
                getString(R.string.ff_burn_on),
                getString(R.string.ff_burn_off),
        };
        new AlertDialog.Builder(this)
                .setTitle(R.string.menu_friendlyfire)
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        switch (which) {
                            case 0: runCommands(L4D2Cmds.cmdFriendlyFireOn()); break;
                            case 1: runCommands(L4D2Cmds.cmdFriendlyFireOff()); break;
                            case 2: runCommands(L4D2Cmds.cmdBurnOn()); break;
                            case 3: runCommands(L4D2Cmds.cmdBurnOff()); break;
                        }
                    }
                })
                .show();
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    /// 6 难度更改（M_DIFF）
    //////////////////////////////////////////////////////////////////////////////////////////////

    private void onDifficultyClick() {
        String[] labels = new String[L4D2Cmds.DIFFICULTY.length];
        for (int i = 0; i < labels.length; i++) {
            labels[i] = L4D2Cmds.DIFFICULTY[i][0] + "    " + L4D2Cmds.DIFFICULTY[i][1];
        }
        new AlertDialog.Builder(this)
                .setTitle(R.string.menu_difficulty)
                .setItems(labels, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        runCommands(new String[]{
                                L4D2Cmds.cmdDifficulty(L4D2Cmds.DIFFICULTY[which][1])
                        });
                    }
                })
                .show();
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    /// 7 更换模式（M_MODE，改完提示换图）
    //////////////////////////////////////////////////////////////////////////////////////////////

    private void onModeClick() {
        String[] labels = new String[L4D2Cmds.GAMEMODE.length];
        for (int i = 0; i < labels.length; i++) {
            labels[i] = L4D2Cmds.GAMEMODE[i][0] + "    " + L4D2Cmds.GAMEMODE[i][1];
        }
        new AlertDialog.Builder(this)
                .setTitle(R.string.menu_mode)
                .setItems(labels, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        runCommands(new String[]{
                                L4D2Cmds.cmdGameMode(L4D2Cmds.GAMEMODE[which][1])
                        });
                        new AlertDialog.Builder(RconActivity.this)
                                .setTitle(R.string.menu_mode)
                                .setMessage(R.string.msg_mode_need_changemap)
                                .setNegativeButton(android.R.string.cancel, null)
                                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dd, int w) {
                                        runCommands(new String[]{
                                                L4D2Cmds.cmdChangelevel(L4D2Cmds.DEFAULT_MODE_MAP)
                                        });
                                    }
                                })
                                .show();
                    }
                })
                .show();
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    /// 8 关闭服务（M_QUITSRV，二次确认后发 quit）
    //////////////////////////////////////////////////////////////////////////////////////////////

    private void onQuitClick() {
        if (!checkRcon()) return;
        new AlertDialog.Builder(this)
                .setTitle(R.string.menu_quit)
                .setMessage(R.string.msg_quit_confirm)
                .setNegativeButton(android.R.string.cancel, null)
                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        runCommands(new String[]{L4D2Cmds.CMD_QUIT});
                    }
                })
                .show();
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    /// 9 协议诊断（rcon.ps1 的 -Mode dump）
    //////////////////////////////////////////////////////////////////////////////////////////////

    private void onDiagClick() {
        appendLog(getString(R.string.menu_diag) + " ...");
        (new DiagTask()).execute();
    }

    private class DiagTask extends AsyncTask<Void, Void, L4D2Rcon.DiagResult> {
        @Override
        protected L4D2Rcon.DiagResult doInBackground(Void... v) {
            return L4D2Rcon.diagnose(hostname, port, password);
        }

        @Override
        protected void onPostExecute(L4D2Rcon.DiagResult r) {
            StringBuilder sb = new StringBuilder();
            sb.append("---- ").append(getString(R.string.menu_diag)).append(" ----\n");
            sb.append(getString(R.string.text_server_address)).append(": ")
              .append(hostname).append(":").append(port).append("\n");
            sb.append(getString(R.string.rcon_password)).append(": ")
              .append(getString(R.string.diag_pass_len, password == null ? 0 : password.length())).append("\n");
            if (r.passwordHasSpaces) {
                sb.append(getString(R.string.diag_pass_spaces)).append("\n");
            }

            // [1] TCP
            if (!r.tcpOk) {
                sb.append("[1] ").append(getString(R.string.diag_tcp_failed)).append(": ").append(r.tcpError).append("\n");
                sb.append("\n").append(getString(R.string.diag_tcp_reason)).append("\n");
                appendLog(sb.toString());
                return;
            }
            sb.append("[1] ").append(getString(R.string.diag_tcp_ok)).append("  ").append(r.tcpMs).append(" ms\n");

            // [2] 认证包
            sb.append("[2] ").append(getString(R.string.diag_auth_sent, r.authPacketSize, r.authSizeField)).append("\n");

            // [3] 收到的包
            if (r.packets.isEmpty()) {
                sb.append("[3] ").append(getString(R.string.diag_no_packet)).append("\n");
            } else {
                for (int i = 0; i < r.packets.size(); i++) {
                    L4D2Rcon.DiagPacket p = r.packets.get(i);
                    sb.append("[3] ").append(getString(R.string.diag_packet,
                            i + 1, p.id, p.type, p.typeName(), p.bodyLength)).append("\n");
                }
            }

            sb.append("\n---- ").append(getString(R.string.diag_conclusion)).append(" ----\n");
            if ("OK".equals(r.verdict)) {
                sb.append(getString(R.string.diag_verdict_ok)).append("\n");
                sb.append(getString(r.statusOk ? R.string.diag_cmd_ok : R.string.diag_cmd_noresp)).append("\n");
            } else if ("BADPASS".equals(r.verdict)) {
                sb.append(getString(R.string.diag_verdict_badpass)).append("\n");
                sb.append(getString(R.string.diag_badpass_help)).append("\n");
            } else {
                sb.append(getString(R.string.diag_verdict_noauth)).append("\n");
                sb.append(getString(R.string.diag_noauth_help)).append("\n");
            }
            appendLog(sb.toString());
        }
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    /// 认证（只对 NOAUTH 重试）
    //////////////////////////////////////////////////////////////////////////////////////////////

    private class AuthTask extends AsyncTask<Void, Void, Object[]> {
        @Override
        protected Object[] doInBackground(Void... v) {
            int tried = 1;
            for (int attempt = 1; attempt <= AUTH_RETRY; attempt++) {
                tried = attempt;
                L4D2Rcon r = null;
                try {
                    r = new L4D2Rcon(hostname, port);
                    if (r.authorize(password)) {
                        return new Object[]{Boolean.TRUE, r, tried, L4D2Rcon.ERR_NONE};
                    }
                    int err = r.lastError;
                    try {
                        r.disconnect();
                    } catch (Exception ignored) {
                    }
                    if (err != L4D2Rcon.ERR_NOAUTH) {
                        return new Object[]{Boolean.FALSE, null, tried, err};
                    }
                } catch (Exception e) {
                    return new Object[]{Boolean.FALSE, null, tried, L4D2Rcon.ERR_CONNECT};
                }
                if (attempt < AUTH_RETRY) {
                    try {
                        Thread.sleep(AUTH_RETRY_DELAYS[attempt - 1]);
                    } catch (InterruptedException ignored) {
                    }
                }
            }
            return new Object[]{Boolean.FALSE, null, tried, L4D2Rcon.ERR_NOAUTH};
        }

        @Override
        protected void onPostExecute(Object[] res) {
            boolean ok = (Boolean) res[0];
            if (ok) {
                rcon = (L4D2Rcon) res[1];
                textStatus.setText(hostname + ":" + port + "\n"
                        + getString(R.string.rcon_status_authorize_succeeded));
                btnSend.setEnabled(true);
                setMenuEnabled(true);
                appendLog(getString(R.string.rcon_status_authorize_succeeded));
            } else {
                int err = (Integer) res[3];
                int tried = (Integer) res[2];
                String msg;
                if (err == L4D2Rcon.ERR_BADPASS) {
                    msg = getString(R.string.rcon_error_auth);
                } else if (err == L4D2Rcon.ERR_CONNECT) {
                    msg = getString(R.string.rcon_error_connect);
                } else {
                    msg = getString(R.string.rcon_error_noauth, tried);
                }
                textStatus.setText(hostname + ":" + port + "\n" + msg);
                appendLog(msg);
            }
        }
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    /// 命令执行（带 200ms 节流）
    //////////////////////////////////////////////////////////////////////////////////////////////

    public void sendButtonClicked(View view) {
        String command = editTextRconCommand.getText().toString();
        if (command.trim().length() == 0) return;
        editTextRconCommand.setText("");
        runCommands(new String[]{command.trim()});
    }

    private boolean checkRcon() {
        if (rcon == null) {
            toast(R.string.rcon_error_connect);
            return false;
        }
        return true;
    }

    /** 是否关闭/重启类命令：quit / exit / _restart */
    private static boolean isServerStopCommand(String cmd) {
        if (cmd == null) return false;
        String c = cmd.trim().toLowerCase();
        return c.equals("quit") || c.equals("exit") || c.equals("_restart");
    }

    /** 是否换图类命令：changelevel / sm_map / map */
    private static boolean isMapChangeCommand(String cmd) {
        if (cmd == null) return false;
        String c = cmd.trim().toLowerCase();
        return c.startsWith("changelevel") || c.startsWith("sm_map ") || c.startsWith("map ");
    }

    /**
     * 重新建连并重新认证（必须在后台线程调用）。
     * 换图后服务器要加载新图，期间连不上/认证无回应是正常的，所以重试若干次。
     */
    private boolean reconnectRcon() {
        for (int attempt = 1; attempt <= RECONNECT_TRIES; attempt++) {
            L4D2Rcon r = null;
            try {
                r = new L4D2Rcon(hostname, port);
                if (r.authorize(password)) {
                    // 换掉旧连接
                    L4D2Rcon old = rcon;
                    rcon = r;
                    if (old != null) {
                        try {
                            old.disconnect();
                        } catch (Exception ignored) {
                        }
                    }
                    return true;
                }
                int err = r.lastError;
                try {
                    r.disconnect();
                } catch (Exception ignored) {
                }
                // 密码错不用重试，重试只会累积失败次数触发封禁
                if (err == L4D2Rcon.ERR_BADPASS) {
                    return false;
                }
            } catch (Exception e) {
                // 服务器还在加载新图，连不上，继续重试
            }
            if (attempt < RECONNECT_TRIES) {
                try {
                    Thread.sleep(RECONNECT_DELAY_MS);
                } catch (InterruptedException ignored) {
                }
            }
        }
        return false;
    }

    /** 若已标记为需要重连（换图后），先重连。必须在后台线程调用。 */
    private boolean ensureLiveConnection() {
        if (serverStopped) return false;
        if (!needReconnect) return true;
        boolean ok = reconnectRcon();
        needReconnect = false;
        return ok;
    }

    /** 执行单条命令；maps * 走长超时通道 */
    private String execOne(String cmd) {
        if (rcon == null) return null;
        if (cmd != null && (cmd.startsWith("maps"))) {
            return rcon.commandAll(cmd);
        }
        return rcon.command(cmd);
    }

    private void runCommands(String[] cmds) {
        if (!checkRcon()) return;
        (new CommandTask()).execute(cmds);
    }

    private class CommandTask extends AsyncTask<String, String, Void> {
        @Override
        protected Void doInBackground(String... cmds) {
            for (String cmd : cmds) {
                // 节流：相邻两条命令至少间隔 200ms
                long now = System.currentTimeMillis();
                if (lastCmdMs > 0 && (now - lastCmdMs) < CMD_THROTTLE_MS) {
                    try {
                        Thread.sleep(CMD_THROTTLE_MS - (now - lastCmdMs));
                    } catch (InterruptedException ignored) {
                    }
                }
                lastCmdMs = System.currentTimeMillis();

                // 换图之后旧连接已经失效，先重新建连 + 重新认证
                if (!ensureLiveConnection()) {
                    publishProgress(null, getString(R.string.rcon_reconnect_failed));
                    publishProgress(cmd, null);
                    continue;
                }

                String out = execOne(cmd);

                if (out == null && !serverStopped) {
                    // 命令没有回显，多半是连接被服务器断了（换图后最常见）。
                    // 重新建连后再试一次，与 Windows 版脚本"每条命令新建连接"的效果一致。
                    publishProgress(null, getString(R.string.rcon_reconnecting));
                    if (reconnectRcon()) {
                        publishProgress(null, getString(R.string.rcon_reconnected));
                        out = execOne(cmd);
                    }
                }

                // 换图命令执行完后打标记，下一条命令前会先重连
                if (isMapChangeCommand(cmd)) {
                    needReconnect = true;
                }
                // 关闭/重启命令执行完后打标记，此后不再重连
                if (isServerStopCommand(cmd)) {
                    serverStopped = true;
                }

                publishProgress(cmd, out);
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(String... vals) {
            String cmd = vals[0];
            String out = vals.length > 1 ? vals[1] : null;

            // cmd 为 null 表示这是一条纯提示信息（重连状态等），不是命令回显
            if (cmd == null) {
                appendLog(out == null ? "" : out);
                return;
            }

            appendLog("> " + cmd);
            if (out == null) {
                appendLog(getString(R.string.rcon_status_command_failed));
            } else if (out.trim().isEmpty()) {
                appendLog(getString(R.string.rcon_status_no_output));
            } else {
                appendLog(out);
            }
        }
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    /// 工具
    //////////////////////////////////////////////////////////////////////////////////////////////

    private void appendLog(final String text) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                textViewRconResponce.append(text);
                if (!text.endsWith("\n")) {
                    textViewRconResponce.append("\n");
                }
                scroll.post(new Runnable() {
                    @Override
                    public void run() {
                        scroll.fullScroll(View.FOCUS_DOWN);
                    }
                });
            }
        });
    }

    private void toast(final int resId) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(RconActivity.this, resId, Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void onClearLogClick(MenuItem item) {
        textViewRconResponce.setText("");
    }

    @Override
    protected void onDestroy() {
        if (rcon != null) {
            final L4D2Rcon toClose = rcon;
            rcon = null;
            (new AsyncTask<Void, Void, Void>() {
                @Override
                protected Void doInBackground(Void... v) {
                    try {
                        toClose.disconnect();
                    } catch (Exception ignored) {
                    }
                    return null;
                }
            }).execute();
        }
        super.onDestroy();
    }
}
