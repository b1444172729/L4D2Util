package rikka.srcdsutil.common;

import java.io.DataInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.BufferUnderflowException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

/**
 * Source RCON 协议实现（TCP）
 *
 * 协议参数逐条对齐最新 Windows 版 rcon.ps1 v7：
 *
 *  1) Size = ID(4) + Type(4) + Body(n) + 双NUL(2) = n + 10
 *     v6 修好的关键 bug，v7 保持
 *  2) 认证 ID=1 Type=3，命令 ID=2 Type=2
 *  3) 不发"空 RESPONSE_VALUE 终结包"
 *  4) Id = -1 → BADPASS（服务器明确拒绝，密码不对）
 *  5) 收包动态超时：还没收到内容等 1500ms，收到内容后只再等 400ms
 *  6) 认证总时限 6 秒；命令循环总时限 5 秒
 *  7) 网络收发固定 UTF-8
 *
 * v7 里"输出编码自适应控制台代码页"那条是 Windows 控制台特有的坑，
 * Android 全程 UTF-8，不需要处理。
 *
 * 相比 App 原版修掉的问题：
 *  - 原版 new Socket() 无超时，IP 不通时界面永久卡在"正在获得授权"
 *  - 原版 command() 只读一个包，长输出（status / maps *）被截断
 *  - 原版 stream.read(header) 可能读不满 12 字节 → 改用 readFully
 */
public class L4D2Rcon {
    public static final int SERVERDATA_RESPONSE_VALUE = 0;
    public static final int SERVERDATA_AUTH_RESPONSE = 2;
    public static final int SERVERDATA_EXECCOMMAND = 2;
    public static final int SERVERDATA_AUTH = 3;

    /** 失败原因分类（决定要不要重试） */
    public static final int ERR_NONE = 0;
    /** 密码不对。不可重试 —— 重试会累积失败次数触发 sv_rcon_banpenalty 封 IP */
    public static final int ERR_BADPASS = 1;
    /** 服务器没回认证包。可重试 */
    public static final int ERR_NOAUTH = 2;
    /** 连不上 / 超时 */
    public static final int ERR_CONNECT = 3;
    /** 命令执行失败 */
    public static final int ERR_COMMAND = 4;

    private static final int AUTH_ID = 1;
    private static final int CMD_ID = 2;

    /** 与 rcon.ps1 一致：首包前 1500ms，收到内容后 400ms */
    private static final int WAIT_FIRST_MS = 1500;
    private static final int WAIT_NEXT_MS = 400;
    private static final int AUTH_DEADLINE_MS = 6000;
    private static final int CMD_DEADLINE_MS = 5000;
    /** maps * 输出很长，放宽到 15 秒 */
    private static final int CMD_ALL_DEADLINE_MS = 15000;
    private static final int CONNECT_TIMEOUT_MS = 5000;

    public final String hostname;
    public final int port;
    public final Socket socket;

    private final InputStream inputStream;
    private final OutputStream outputStream;

    public int lastError = ERR_NONE;

    public L4D2Rcon(String hostname, int port) throws IOException {
        if (hostname == null || hostname.trim().isEmpty()) {
            throw new IllegalArgumentException("Host can't be null or empty");
        }
        if (port < 1 || port > 65535) {
            throw new IllegalArgumentException("Port is out of range");
        }

        this.hostname = hostname;
        this.port = port;

        Socket s = new Socket();
        s.connect(new InetSocketAddress(hostname, port), CONNECT_TIMEOUT_MS);
        s.setSoTimeout(WAIT_FIRST_MS);
        s.setTcpNoDelay(true);

        this.socket = s;
        this.inputStream = s.getInputStream();
        this.outputStream = s.getOutputStream();
    }

    public void disconnect() throws IOException {
        this.socket.close();
    }

    /**
     * 认证。结果通过 lastError 区分：
     *   BADPASS —— 服务器明确拒绝（ID=-1），不要重试
     *   NOAUTH  —— 服务器没回应认证包，可换一条连接重试
     */
    public boolean authorize(String password) {
        lastError = ERR_NONE;
        try {
            writeSourcePacket(outputStream, AUTH_ID, SERVERDATA_AUTH,
                    (password == null ? "" : password).getBytes(Charset.forName("UTF-8")));

            long deadline = System.currentTimeMillis() + AUTH_DEADLINE_MS;
            while (System.currentTimeMillis() < deadline) {
                socket.setSoTimeout(WAIT_FIRST_MS);

                SourcePacket packet;
                try {
                    packet = readSourcePacket(inputStream);
                } catch (SocketTimeoutException e) {
                    break;
                }
                if (packet == null) break;

                if (packet.requestId == -1) {
                    lastError = ERR_BADPASS;
                    return false;
                }
                // Type=2 且 Id=1 才算认证通过（rcon.ps1 的判定条件）
                if (packet.type == SERVERDATA_AUTH_RESPONSE && packet.requestId == AUTH_ID) {
                    return true;
                }
            }
            lastError = ERR_NOAUTH;
            return false;
        } catch (Exception e) {
            lastError = ERR_CONNECT;
            return false;
        }
    }

    /** 执行一条命令，自动拼接多包响应 */
    public String command(String cmd) {
        return exec(cmd, CMD_DEADLINE_MS, WAIT_NEXT_MS);
    }

    /** 用于 maps * 这类超长输出 */
    public String commandAll(String cmd) {
        return exec(cmd, CMD_ALL_DEADLINE_MS, 600);
    }

    private String exec(String cmd, int limitMs, int nextWaitMs) {
        lastError = ERR_NONE;
        try {
            writeSourcePacket(outputStream, CMD_ID, SERVERDATA_EXECCOMMAND,
                    cmd.getBytes(Charset.forName("UTF-8")));

            StringBuilder sb = new StringBuilder();
            boolean gotAny = false;
            long deadline = System.currentTimeMillis() + limitMs;

            while (System.currentTimeMillis() < deadline) {
                socket.setSoTimeout(gotAny ? nextWaitMs : WAIT_FIRST_MS);

                SourcePacket packet;
                try {
                    packet = readSourcePacket(inputStream);
                } catch (SocketTimeoutException e) {
                    break;
                }
                if (packet == null) break;

                if (packet.type == SERVERDATA_RESPONSE_VALUE && packet.payload.length > 0) {
                    sb.append(new String(packet.payload, Charset.forName("UTF-8")));
                    gotAny = true;
                }
            }
            return sb.toString();
        } catch (Exception e) {
            lastError = ERR_COMMAND;
            return null;
        }
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    /// 协议诊断（对应 rcon.ps1 的 -Mode dump）
    //////////////////////////////////////////////////////////////////////////////////////////////

    public static class DiagPacket {
        public int id;
        public int type;
        public int bodyLength;

        public String typeName() {
            switch (type) {
                case SERVERDATA_RESPONSE_VALUE: return "RESPONSE_VALUE";
                case SERVERDATA_AUTH_RESPONSE:  return "AUTH_RESPONSE";
                case SERVERDATA_AUTH:           return "AUTH";
                default:                        return "未知";
            }
        }
    }

    public static class DiagResult {
        public boolean tcpOk = false;
        public long tcpMs = 0;
        public String tcpError = "";
        public int authPacketSize = 0;
        public int authSizeField = 0;
        public boolean passwordHasSpaces = false;
        public List<DiagPacket> packets = new ArrayList<DiagPacket>();
        /** OK / BADPASS / NOAUTH / CONNECT */
        public String verdict = "NOAUTH";
        public boolean statusOk = false;
        public String statusPreview = "";
    }

    /**
     * 协议诊断：另开一条 TCP、发一次认证包，把服务器回的每个包原样记录。
     * 与 rcon.ps1 的 dump 模式一致：最多看 8 个包，看完自动关闭。
     */
    public static DiagResult diagnose(String hostname, int port, String password) {
        DiagResult r = new DiagResult();
        Socket s = null;
        try {
            long t0 = System.currentTimeMillis();
            s = new Socket();
            s.connect(new InetSocketAddress(hostname, port), CONNECT_TIMEOUT_MS);
            r.tcpMs = System.currentTimeMillis() - t0;
            r.tcpOk = true;
            s.setSoTimeout(WAIT_FIRST_MS);

            byte[] pwdBytes = (password == null ? "" : password).getBytes(Charset.forName("UTF-8"));
            r.authSizeField = pwdBytes.length + 10;
            r.authPacketSize = r.authSizeField + 4;
            // rcon.ps1 会提醒：密码首尾有空格会导致认证失败
            r.passwordHasSpaces = (password != null) && (password.length() != password.trim().length());

            OutputStream os = s.getOutputStream();
            InputStream is = s.getInputStream();
            writeSourcePacket(os, AUTH_ID, SERVERDATA_AUTH, pwdBytes);

            for (int i = 0; i < 8; i++) {
                SourcePacket p;
                try {
                    p = readSourcePacket(is);
                } catch (SocketTimeoutException e) {
                    break;
                }
                if (p == null) break;

                DiagPacket dp = new DiagPacket();
                dp.id = p.requestId;
                dp.type = p.type;
                dp.bodyLength = p.payload.length;
                r.packets.add(dp);

                if (p.requestId == -1) {
                    r.verdict = "BADPASS";
                    break;
                }
                if (p.type == SERVERDATA_AUTH_RESPONSE && p.requestId == AUTH_ID) {
                    r.verdict = "OK";
                    break;
                }
            }

            // 认证过了就再试一条 status，确认命令通道也是通的
            if ("OK".equals(r.verdict)) {
                try {
                    writeSourcePacket(os, CMD_ID, SERVERDATA_EXECCOMMAND,
                            "status".getBytes(Charset.forName("UTF-8")));
                    StringBuilder sb = new StringBuilder();
                    boolean gotAny = false;
                    long deadline = System.currentTimeMillis() + CMD_DEADLINE_MS;
                    while (System.currentTimeMillis() < deadline) {
                        s.setSoTimeout(gotAny ? WAIT_NEXT_MS : WAIT_FIRST_MS);
                        SourcePacket p;
                        try {
                            p = readSourcePacket(is);
                        } catch (SocketTimeoutException e) {
                            break;
                        }
                        if (p == null) break;
                        if (p.type == SERVERDATA_RESPONSE_VALUE && p.payload.length > 0) {
                            sb.append(new String(p.payload, Charset.forName("UTF-8")));
                            gotAny = true;
                        }
                    }
                    r.statusPreview = sb.toString();
                    r.statusOk = sb.length() > 0;
                } catch (Exception e) {
                    r.statusOk = false;
                }
            }
        } catch (Exception e) {
            r.tcpOk = false;
            r.tcpError = (e.getMessage() == null) ? e.getClass().getSimpleName() : e.getMessage();
            r.verdict = "CONNECT";
        } finally {
            if (s != null) {
                try {
                    s.close();
                } catch (Exception ignored) {
                }
            }
        }
        return r;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    /// 组包 / 收包
    //////////////////////////////////////////////////////////////////////////////////////////////

    private static int getPacketLength(int bodyLength) {
        return 4 + bodyLength;
    }

    /** Size = ID(4) + Type(4) + payload(n) + 双NUL(2) = n + 10 */
    private static int getBodyLength(int payloadLength) {
        return 4 + 4 + payloadLength + 2;
    }

    private static void writeSourcePacket(OutputStream stream, int requestId, int type, byte[] payload)
            throws IOException {
        int bodyLength = getBodyLength(payload.length);
        int packetLength = getPacketLength(bodyLength);

        ByteBuffer buffer = ByteBuffer.allocate(packetLength);
        buffer.order(ByteOrder.LITTLE_ENDIAN);

        buffer.putInt(bodyLength);
        buffer.putInt(requestId);
        buffer.putInt(type);
        buffer.put(payload);
        buffer.put((byte) 0);
        buffer.put((byte) 0);

        stream.write(buffer.array());
        stream.flush();
    }

    private static SourcePacket readSourcePacket(InputStream stream) throws IOException {
        byte[] header = new byte[4 * 3];
        try {
            new DataInputStream(stream).readFully(header);
        } catch (EOFException e) {
            return null;
        }

        try {
            ByteBuffer buffer = ByteBuffer.wrap(header);
            buffer.order(ByteOrder.LITTLE_ENDIAN);

            int length = buffer.getInt();
            int requestId = buffer.getInt();
            int type = buffer.getInt();

            if (length < 10 || length > 8192) {
                throw new MalformedPacketException("Bad packet length: " + length);
            }

            byte[] payload = new byte[length - 4 - 4 - 2];
            DataInputStream dis = new DataInputStream(stream);
            dis.readFully(payload);
            dis.readFully(new byte[2]);

            return new SourcePacket(requestId, type, payload);
        } catch (BufferUnderflowException e) {
            throw new MalformedPacketException("Cannot read the whole packet");
        }
    }

    private static class SourcePacket {
        public final int requestId, type;
        public final byte[] payload;

        SourcePacket(int requestId, int type, byte[] payload) {
            this.requestId = requestId;
            this.type = type;
            this.payload = payload;
        }
    }

    private static class MalformedPacketException extends IOException {
        MalformedPacketException(String message) {
            super(message);
        }
    }
}
