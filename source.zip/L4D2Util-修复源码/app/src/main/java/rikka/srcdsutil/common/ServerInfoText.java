package rikka.srcdsutil.common;

import android.content.Context;

import rikka.srcdsutil.R;

/**
 * 把 A2S 查询结果拼成可直接显示的文本。
 *
 * 抽出来共用，避免"远程"页面的 [1] 信息查询 和 服务器详情页 各写一份、
 * 改一处忘另一处。两个页面现在显示完全一样的内容，都走 buildBrief()。
 *
 * 数据源：A2S_INFO 取服务器信息，A2S_PLAYER 取玩家名单。
 */
public class ServerInfoText {

    /**
     * 完整版（"远程"页面 [1] 信息查询 用）。
     * 字段完整度对齐 rcon.ps1 v7 的 -Mode a2s。
     */
    public static String buildBrief(Context ctx, String hostname, int port,
                                    L4D2Server.Info info, String[] players) {
        if (info == null || !info.a2sOk) {
            return ctx.getString(R.string.a2s_failed) + "\n"
                    + ctx.getString(R.string.a2s_fail_reason);
        }

        StringBuilder sb = new StringBuilder();
        sb.append(ctx.getString(R.string.a2s_addr)).append(": ")
          .append(hostname).append(":").append(port).append("\n");
        sb.append(ctx.getString(R.string.a2s_name)).append(": ").append(nz(info.serverName)).append("\n");
        sb.append(ctx.getString(R.string.a2s_map)).append(": ").append(nz(info.mapName)).append("\n");
        sb.append(ctx.getString(R.string.a2s_game)).append(": ").append(nz(info.gameType)).append("\n");
        if (info.gameVersion != null && !info.gameVersion.isEmpty()) {
            sb.append(ctx.getString(R.string.a2s_version)).append(": ").append(info.gameVersion).append("\n");
        }
        if (info.serverType >= 0) {
            sb.append(ctx.getString(R.string.a2s_type)).append(": ")
              .append(ctx.getString(info.getServerTypeResId())).append("\n");
        }
        if (info.environment >= 0) {
            sb.append(ctx.getString(R.string.a2s_os)).append(": ")
              .append(ctx.getString(info.getEnvironmentResId())).append("\n");
        }
        sb.append(ctx.getString(R.string.a2s_visible)).append(": ")
          .append(ctx.getString(info.visibility == 0 ? R.string.a2s_public : R.string.a2s_private)).append("\n");
        sb.append(ctx.getString(R.string.a2s_secure)).append(": ")
          .append(ctx.getString(info.vac == 1 ? R.string.a2s_on : R.string.a2s_off)).append("\n");
        if (info.protocol >= 0) {
            sb.append(ctx.getString(R.string.a2s_proto)).append(": ").append(info.protocol).append("\n");
        }
        if (info.gamePort > 0) {
            sb.append(ctx.getString(R.string.a2s_port2)).append(": ").append(info.gamePort).append("\n");
        }
        if (info.responseMs >= 0) {
            sb.append(ctx.getString(R.string.a2s_resp)).append(": ").append(info.responseMs).append(" ms\n");
        }

        sb.append("\n").append(ctx.getString(R.string.a2s_player_list_count,
                info.playerCount, info.slotCount)).append("\n");
        if (players == null || players.length == 0) {
            sb.append(ctx.getString(R.string.a2s_no_players));
        } else {
            for (int i = 0; i < players.length; i++) {
                // 中文序号 + 全角逗号，例如 "1，兄弟孟达"
                sb.append(i + 1).append("，").append(players[i]);
                if (i < players.length - 1) {
                    sb.append("\n");
                }
            }
        }
        return sb.toString();
    }

    private static String nz(String s) {
        return s == null ? "" : s;
    }
}
