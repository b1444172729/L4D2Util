package com.srcdsutil.rcon.common;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

import com.srcdsutil.rcon.R;

/**
 * A2S 查询（UDP）。
 *
 * 【保留的修复】"无法识别的服务器" 的真正原因：A2S Challenge
 *
 * Source 引擎（含 L4D2）有一项反 UDP 放大攻击的机制：服务器可以对 A2S_INFO 查询
 * 先返回一个 CHALLENGE 响应，而不是直接返回数据：
 *
 *     FF FF FF FF 41 XX XX XX XX     (9 字节)
 *                   ^^ 0x41 = 'A' = A2S_SERVERQUERY_GETCHALLENGE
 *                      ^^^^^^^^^^^ 4 字节 challenge 值
 *
 * 客户端必须把这 4 个字节原样附在查询包末尾重发一次，才会拿到真正的服务器信息。
 * 原版只认 0x49('I') 和 0x6D('m')，收到 0x41 时两个分支都不匹配 → 判为 UNKNOWN。
 *
 * 【本次升级】按最新 Windows 版 rcon.ps1 v7 的 -Mode a2s 重写解析，
 * 现在能读出完整的 A2S_INFO 字段（AppID / 版本 / 类型 / 系统 / VAC / 端口 / 关键词），
 * 而不是只取服务器名和地图。
 */

public class L4D2Server {
    private final static byte[] requestQueryServerInfo = {
            (byte) 0xff, (byte) 0xff, (byte) 0xff, (byte) 0xff, 0x54, 0x53, 0x6f, 0x75,
            0x72, 0x63, 0x65, 0x20, 0x45, 0x6e, 0x67, 0x69,
            0x6e, 0x65, 0x20, 0x51, 0x75, 0x65, 0x72, 0x79,
            0x00 };

    private final static byte[] requestGetPlayerList = {
            (byte) 0xff, (byte) 0xff, (byte) 0xff, (byte) 0xff, 0x55, 0x00, 0x00, 0x00,
            0x00 };

    /** 响应类型标识 */
    private final static byte A2S_INFO = 0x49;           // 'I' Source 引擎服务器信息
    private final static byte A2S_GOLDSRC_INFO = 0x6D;   // 'm' GoldSrc 引擎服务器信息
    private final static byte A2S_CHALLENGE = 0x41;      // 'A' 服务器要求先换取 challenge
    private final static byte A2S_PLAYER = 0x44;         // 'D' 玩家列表

    /** 接收缓冲大小，A2S 响应最长可达 1400 字节左右 */
    private final static int BUFFER_SIZE = 2048;

    /** A2S_INFO 的 EDF 标志位，与 rcon.ps1 v7 一致 */
    private final static int EDF_PORT = 0x80;
    private final static int EDF_STEAMID = 0x10;
    private final static int EDF_SOURCETV = 0x40;
    private final static int EDF_KEYWORDS = 0x20;

    public enum SrcDsVersion {
        UNKNOWN(0), L4D2(1), CS16(2);

        public final int val;
        SrcDsVersion(int val) {
            this.val = val;
        }
    }

    private final static int gameNameLocateIndex[] = {R.string.game_unknown, R.string.game_l4d2, R.string.game_cs16};

    public static class Info {
        public String serverName;
        public String mapName;
        public String directory;
        public String gameType;
        /** 用 & 0xFF 取值，避免槽位超过 127 时变成负数 */
        public int playerCount;
        public int slotCount;
        public SrcDsVersion version;

        // ---- 以下按 rcon.ps1 v7 的 -Mode a2s 新增 ----
        public int protocol = -1;
        public int appId = -1;
        public int bots = 0;
        /** 'd'=100 专用 'l'=108 监听 'p'=112 代理 */
        public int serverType = -1;
        /** 'l'=108 Linux 'w'=119 Windows 'm'=109 Mac */
        public int environment = -1;
        public int visibility = 0;
        public int vac = 0;
        public String gameVersion = "";
        public int gamePort = -1;
        public String keywords = "";
        /** 查询往返耗时（毫秒），-1 表示没测出来 */
        public long responseMs = -1;
        /** 是否成功解析出 A2S_INFO */
        public boolean a2sOk = false;

        private Info() {
            this.version = SrcDsVersion.UNKNOWN;
        }

        public int getGameVersionLocateIndex() {
            return gameNameLocateIndex[version.val];
        }

        /** 服务器类型文案：专用 / 监听 / 代理 */
        public int getServerTypeResId() {
            if (serverType == 100) return R.string.a2s_type_dedicated;
            if (serverType == 112) return R.string.a2s_type_proxy;
            return R.string.a2s_type_listen;
        }

        /** 操作系统文案：Linux / Windows / Mac */
        public int getEnvironmentResId() {
            if (environment == 108) return R.string.a2s_env_linux;
            if (environment == 119) return R.string.a2s_env_windows;
            return R.string.a2s_env_mac;
        }
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    /// 读取工具
    //////////////////////////////////////////////////////////////////////////////////////////////

    private static int getSegmentLength(byte[] bytes, int offset, int length) {
        int pos = offset;
        for (; pos < length; pos++) {
            if (bytes[pos] == 0)
                break;
        }
        return pos - offset;
    }

    /** 读一个以 0 结尾的字符串（UTF-8），读完后游标前进 */
    private static String readCString(byte[] buf, int[] pos, int len) {
        int start = pos[0];
        int n = getSegmentLength(buf, start, len);
        String s;
        try {
            s = new String(buf, start, n, "UTF-8");
        } catch (IOException e) {
            s = "";
        }
        pos[0] = start + n + 1;
        return s;
    }

    private static boolean hasBytes(byte[] buf, int[] pos, int len, int need) {
        return pos[0] + need <= len;
    }

    private static int readU8(byte[] buf, int[] pos) {
        return buf[pos[0]++] & 0xFF;
    }

    private static int readU16(byte[] buf, int[] pos) {
        int a = buf[pos[0]++] & 0xFF;
        int b = buf[pos[0]++] & 0xFF;
        return a | (b << 8);   // 小端
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    /// A2S_INFO 完整解析（对齐 rcon.ps1 v7）
    //////////////////////////////////////////////////////////////////////////////////////////////

    /**
     * 解析 A2S_INFO 响应体。
     * 布局（跳过 FF FF FF FF 与 0x49 之后）:
     *   protocol(1) name(cstr) map(cstr) folder(cstr) game(cstr)
     *   appid(2) players(1) max(1) bots(1) type(1) env(1) vis(1) vac(1)
     *   version(cstr) edf(1)
     *     edf&0x80 -> port(2)
     *     edf&0x10 -> steamid(8)
     *     edf&0x40 -> tvport(2) + tvname(cstr)
     *     edf&0x20 -> keywords(cstr)
     */
    private static Info parse_l4d2_responce(byte[] buf, int len) {
        Info info = new Info();
        info.version = SrcDsVersion.L4D2;
        info.a2sOk = true;

        // 布局: [0-3] FF FF FF FF  [4] 0x49  [5] protocol  [6...] name
        int[] p = {5};

        try {
            info.protocol = readU8(buf, p);
            info.serverName = readCString(buf, p, len);
            info.mapName = readCString(buf, p, len);
            info.directory = readCString(buf, p, len);
            info.gameType = readCString(buf, p, len);

            if (!hasBytes(buf, p, len, 2)) { info.a2sOk = false; return info; }
            info.appId = readU16(buf, p);

            if (!hasBytes(buf, p, len, 7)) { info.a2sOk = false; return info; }
            info.playerCount = readU8(buf, p);
            info.slotCount = readU8(buf, p);
            info.bots = readU8(buf, p);
            info.serverType = readU8(buf, p);
            info.environment = readU8(buf, p);
            info.visibility = readU8(buf, p);
            info.vac = readU8(buf, p);

            info.gameVersion = readCString(buf, p, len);

            if (!hasBytes(buf, p, len, 1)) return info;
            int edf = readU8(buf, p);

            if ((edf & EDF_PORT) != 0) {
                if (!hasBytes(buf, p, len, 2)) return info;
                info.gamePort = readU16(buf, p);
            }
            if ((edf & EDF_STEAMID) != 0) {
                if (!hasBytes(buf, p, len, 8)) return info;
                p[0] += 8;
            }
            if ((edf & EDF_SOURCETV) != 0) {
                if (!hasBytes(buf, p, len, 2)) return info;
                p[0] += 2;
                readCString(buf, p, len);
            }
            if ((edf & EDF_KEYWORDS) != 0) {
                info.keywords = readCString(buf, p, len);
            }
        } catch (Exception e) {
            // 解析中断：保留已经读到的字段，标记未完整
            info.a2sOk = false;
        }

        // appid 不是 550(L4D2) 时只标 UNKNOWN，不再整条丢弃
        if (info.appId >= 0 && info.appId != 550) {
            info.version = SrcDsVersion.UNKNOWN;
        }
        return info;
    }

    private static Info parse_cs16_responce(byte[] recvBuf, int recvBufLength) {
        Info info = new Info();
        info.version = SrcDsVersion.CS16;

        int segmentStart = 5;
        int segmentLength = getSegmentLength(recvBuf, segmentStart, recvBufLength);
        segmentStart += segmentLength + 1;
        segmentLength = getSegmentLength(recvBuf, segmentStart, recvBufLength);
        try {
            info.serverName = new String(recvBuf, segmentStart, segmentLength, "UTF-8");
        } catch (IOException e) {
            info.serverName = "";
        }
        segmentStart += segmentLength + 1;

        segmentLength = getSegmentLength(recvBuf, segmentStart, recvBufLength);
        try {
            info.mapName = new String(recvBuf, segmentStart, segmentLength, "UTF-8");
        } catch (IOException e) {
            info.mapName = "";
        }
        segmentStart += segmentLength + 1;

        segmentLength = getSegmentLength(recvBuf, segmentStart, recvBufLength);
        try {
            info.directory = new String(recvBuf, segmentStart, segmentLength, "UTF-8");
        } catch (IOException e) {
            info.directory = "";
        }
        segmentStart += segmentLength + 1;

        segmentLength = getSegmentLength(recvBuf, segmentStart, recvBufLength);
        try {
            info.gameType = new String(recvBuf, segmentStart, segmentLength, "UTF-8");
        } catch (IOException e) {
            info.gameType = "";
        }
        segmentStart += segmentLength + 1;

        if (segmentStart + 1 >= recvBufLength) {
            return info;
        }

        info.playerCount = recvBuf[segmentStart] & 0xFF;
        info.slotCount = recvBuf[segmentStart + 1] & 0xFF;
        info.a2sOk = true;
        return info;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    /// 查询
    //////////////////////////////////////////////////////////////////////////////////////////////

    /** 发送 A2S 请求，自动处理 challenge；失败重试 3 次（与 rcon.ps1 的 A2S-Recv 一致） */
    private static byte[] a2sRecv(String hostname, int port, byte[] req) {
        DatagramSocket socket = null;
        for (int k = 0; k < 3; k++) {
            try {
                InetAddress hostAddr = InetAddress.getByName(hostname);
                socket = new DatagramSocket(0);
                socket.setSoTimeout(2500);

                socket.send(new DatagramPacket(req, req.length, hostAddr, port));
                DatagramPacket response = new DatagramPacket(new byte[BUFFER_SIZE], BUFFER_SIZE);
                socket.receive(response);

                byte[] data = new byte[response.getLength()];
                System.arraycopy(response.getData(), 0, data, 0, response.getLength());
                if (data.length >= 5) {
                    return data;
                }
            } catch (Exception e) {
                // 试下一次
            } finally {
                if (socket != null) {
                    try {
                        socket.close();
                    } catch (Exception ignored) {
                    }
                    socket = null;
                }
            }
        }
        return null;
    }

    /**
     * 查询服务器信息。会自动处理服务器要求 challenge 的情况。
     */
    public static Info QueryServerInfo(String hostname, int port) {
        long t0 = System.nanoTime();
        try {
            byte[] resp = a2sRecv(hostname, port, requestQueryServerInfo);
            if (resp == null || !isMagicHeader(resp, resp.length)) {
                return null;
            }

            // 服务器要求 challenge：取出 4 字节，原样附在请求末尾重发
            if (resp.length >= 9 && (resp[4] & 0xff) == (A2S_CHALLENGE & 0xff)) {
                byte[] req2 = new byte[requestQueryServerInfo.length + 4];
                System.arraycopy(requestQueryServerInfo, 0, req2, 0, requestQueryServerInfo.length);
                System.arraycopy(resp, 5, req2, requestQueryServerInfo.length, 4);

                resp = a2sRecv(hostname, port, req2);
                if (resp == null || !isMagicHeader(resp, resp.length) || resp.length < 6) {
                    return null;
                }
            }

            Info info;
            if ((resp[4] & 0xff) == (A2S_INFO & 0xff)) {
                info = parse_l4d2_responce(resp, resp.length);
            } else if ((resp[4] & 0xff) == (A2S_GOLDSRC_INFO & 0xff)) {
                info = parse_cs16_responce(resp, resp.length);
            } else {
                info = new Info();
            }
            info.responseMs = (System.nanoTime() - t0) / 1000000L;
            return info;
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * 只测 A2S 往返延迟（RTT）。
     * 开启 challenge 的服务器第一次只回 challenge，但只要能收到包就说明通，延迟照样有意义。
     * @return 毫秒；失败返回 -1
     */
    public static long QueryPing(String hostname, int port) {
        DatagramSocket socket = null;
        try {
            InetAddress hostAddr = InetAddress.getByName(hostname);
            socket = new DatagramSocket(0);
            socket.setSoTimeout(3000);

            DatagramPacket response = new DatagramPacket(new byte[BUFFER_SIZE], BUFFER_SIZE);
            long t0 = System.nanoTime();
            socket.send(new DatagramPacket(requestQueryServerInfo,
                    requestQueryServerInfo.length, hostAddr, port));
            socket.receive(response);
            return (System.nanoTime() - t0) / 1000000L;
        } catch (Exception e) {
            return -1;
        } finally {
            if (socket != null) {
                try {
                    socket.close();
                } catch (Exception ignored) {
                }
            }
        }
    }

    /** A2S_PLAYER：查在线玩家名（也可能被要求 challenge） */
    public static String[] GetPlayerList(String hostname, int port) {
        try {
            byte[] resp = a2sRecv(hostname, port, requestGetPlayerList);
            if (resp == null || !isMagicHeader(resp, resp.length)) {
                return null;
            }

            // 服务器要 challenge：把 4 字节填进请求包后重发
            if (resp.length >= 9 && (resp[4] & 0xff) == (A2S_CHALLENGE & 0xff)) {
                byte[] req2 = new byte[9];
                System.arraycopy(requestGetPlayerList, 0, req2, 0, 5);   // FF FF FF FF 0x55
                System.arraycopy(resp, 5, req2, 5, 4);
                resp = a2sRecv(hostname, port, req2);
                if (resp == null || !isMagicHeader(resp, resp.length)) {
                    return null;
                }
            }

            if (resp.length < 6 || (resp[4] & 0xff) != (A2S_PLAYER & 0xff)) {
                return null;
            }

            int playerCount = resp[5] & 0xFF;
            String[] players = new String[playerCount];

            int segmentStart = 6;
            for (int i = 0; i < playerCount; i++) {
                if (segmentStart >= resp.length) break;
                segmentStart += 1;   // index 字节
                int segmentLength = getSegmentLength(resp, segmentStart, resp.length);
                try {
                    players[i] = new String(resp, segmentStart, segmentLength, "UTF-8");
                } catch (IOException e) {
                    players[i] = "";
                }
                segmentStart += segmentLength + 1;
                segmentStart += 8;   // score(4) + 在线时长(4)
            }
            return players;
        } catch (Exception e) {
            return null;
        }
    }

    private static boolean isMagicHeader(byte[] buf, int len) {
        return len >= 5 &&
                (buf[0] & 0xff) == 0xff &&
                (buf[1] & 0xff) == 0xff &&
                (buf[2] & 0xff) == 0xff &&
                (buf[3] & 0xff) == 0xff;
    }
}
