package com.srcdsutil.rcon.common;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 解析 RCON 命令 "status" 的输出，对应 rcon.ps1 v7 的 Format-StatusLines。
 *
 * 关键规则与脚本一致：
 *  - 排除特感 BOT：Tank / Spitter / Hunter / Charger / Boomer / Jockey / Smoker
 *  - 玩家 ID 去掉 "#" 后面的空格（"#  2" -> "#2"）
 *  - 名字取引号内文本，并去掉前面的 (数字) 前缀，例如 (8)Tank -> Tank
 *  - ping = STEAM 之后的第 2 个字段（跳过连接时长）
 *
 * L4D2 的 status 输出示例：
 *   hostname: Left 4 Dead 2
 *   map     : c5m1_waterfront
 *   # userid name uniqueid connected ping loss state rate adr
 *   #  2 1 "任我行" STEAM_1:1:757994136 01:16 64 0 active 100000 1.2.3.4:27005
 *   # 43 "Louis" BOT active
 */
public class Player {
    public String userId = "";
    public String name = "";
    public String steamId = "";
    public String ping = "";
    public String address = "";
    public boolean isBot = false;

    /** 踢人列表里显示的那一整行 */
    public String displayLine() {
        StringBuilder sb = new StringBuilder();
        sb.append("#").append(userId).append("  ").append(name);
        if (isBot) {
            sb.append("  BOT");
        } else {
            if (!steamId.isEmpty()) sb.append("  ").append(steamId);
            if (!ping.isEmpty()) sb.append("  ").append(ping).append("ms");
            if (!address.isEmpty()) sb.append("  ").append(address);
        }
        return sb.toString();
    }

    private static final String[] INFECTED = {
            "Tank", "Spitter", "Hunter", "Charger", "Boomer", "Jockey", "Smoker"
    };

    private static boolean isInfected(String name) {
        for (String s : INFECTED) {
            if (s.equalsIgnoreCase(name)) return true;
        }
        return false;
    }

    private static final Pattern RE_HEADER = Pattern.compile("^#\\s*userid\\s");
    private static final Pattern RE_BOT = Pattern.compile("(?i)\\bBOT\\b");
    private static final Pattern RE_QUOTED = Pattern.compile("^\".*\"$");
    private static final Pattern RE_STEAM = Pattern.compile("^STEAM_");
    private static final Pattern RE_STEAM_FULL = Pattern.compile("STEAM_[0-9]:[0-9]:[0-9]+");
    private static final Pattern RE_ADR = Pattern.compile("^\\d+\\.\\d+\\.\\d+\\.\\d+:\\d+$");
    private static final Pattern RE_NUM_PREFIX = Pattern.compile("^\\((\\d+)\\)(.*)$");

    /**
     * 解析 status 输出，返回可踢的玩家列表。
     * 一条都解析不出来时返回空列表，调用方应回退显示原始文本。
     */
    public static List<Player> parseStatus(String output) {
        List<Player> list = new ArrayList<Player>();
        if (output == null) return list;

        for (String raw : output.split("\\r?\\n")) {
            String t = raw.replace("\r", "").trim();
            if (t.isEmpty()) continue;

            // 表头行、结束行跳过
            if (RE_HEADER.matcher(t).find()) continue;
            if (t.equals("#end")) continue;

            // 只处理 # 开头的行
            if (!t.startsWith("#")) continue;

            // 去掉 # 及其后面的空格："#  2 1 ..." -> "2 1 ..."
            String body = t.replaceFirst("^#\\s*", "");
            if (body.isEmpty()) continue;

            String[] parts = body.split("\\s+");
            Player p = new Player();
            p.userId = parts[0];

            // 名字：引号内文本（可能含空格，不能直接用 split 取）
            String quoted = null;
            for (String tk : parts) {
                if (RE_QUOTED.matcher(tk).matches()) { quoted = tk; break; }
            }
            if (quoted != null && quoted.length() >= 2) {
                p.name = quoted.substring(1, quoted.length() - 1);
            } else if (parts.length > 1) {
                p.name = parts[1];
            }

            // 去掉名字前面的 (数字) 前缀
            Matcher mp = RE_NUM_PREFIX.matcher(p.name);
            if (mp.matches()) {
                p.name = mp.group(2);
            }

            // ---- BOT 行 ----
            if (RE_BOT.matcher(body).find()) {
                p.isBot = true;
                if (isInfected(p.name)) continue;    // 特感 BOT 不进列表
                list.add(p);
                continue;
            }

            // ---- 真人行 ----
            if (RE_STEAM_FULL.matcher(body).find()) {
                for (int i = 0; i < parts.length; i++) {
                    if (p.steamId.isEmpty() && RE_STEAM.matcher(parts[i]).find()) {
                        p.steamId = parts[i];
                        // ping = STEAM 之后的第 2 个字段（跳过连接时长）
                        if (i + 2 < parts.length && parts[i + 2].matches("^\\d+$")) {
                            p.ping = parts[i + 2];
                        }
                    }
                    if (p.address.isEmpty() && RE_ADR.matcher(parts[i]).matches()) {
                        p.address = parts[i];
                    }
                }
            }

            if (!p.name.isEmpty()) {
                list.add(p);
            }
        }
        return list;
    }
}
