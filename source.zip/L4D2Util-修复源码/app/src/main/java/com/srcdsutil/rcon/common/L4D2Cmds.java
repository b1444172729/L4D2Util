package com.srcdsutil.rcon.common;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * L4D2 常用操作的预设值与输出解析，全部取自最新 Windows 版 RCON.bat + rcon.ps1 v7。
 *
 * 原理：RCON 传的就是一行明文命令，所以"功能"等价于往同一条 TCP 连接塞不同的字符串。
 * 这个类只负责拼命令 / 解析输出，不碰协议。
 *
 * 注意：sm_cvar 是 SourceMod 提供的命令，服务器没装 SourceMod 时会返回"未知命令"。
 * RCON.bat 里用的就是 sm_cvar 版本，这里保持一致。
 */
public class L4D2Cmds {

    ///////////////////////////////////////////////////////////////////////////////////////////////
    /// 官方战役首图（RCON.bat 的 M_OFFICIAL，14 项）
    //////////////////////////////////////////////////////////////////////////////////////////////

    public static final String[][] OFFICIAL_MAPS = {
            {"死亡中心", "c1m1_hotel"},
            {"黑色狂欢", "c2m1_highway"},
            {"沼泽激战", "c3m1_plankcountry"},
            {"暴风骤雨", "c4m1_milltown_a"},
            {"教区地图", "c5m1_waterfront"},
            {"短暂时刻", "c6m1_riverbank"},
            {"牺牲地图", "c7m1_docks"},
            {"毫不留情", "c8m1_apartment"},
            {"坠机险途", "c9m1_alleys"},
            {"死亡丧钟", "c10m1_caves"},
            {"静寂时分", "c11m1_greenhouse"},
            {"血腥收获", "c12m1_hilltop"},
            {"刺骨寒溪", "c13m1_alpinecreek"},
            {"临死一搏", "c14m1_junkyard"},
    };

    /** 模式切换后脚本默认跳到这张图 */
    public static final String DEFAULT_MODE_MAP = "c1m1_hotel";

    ///////////////////////////////////////////////////////////////////////////////////////////////
    /// 难度（M_DIFF）
    //////////////////////////////////////////////////////////////////////////////////////////////

    public static final String[][] DIFFICULTY = {
            {"简单", "Easy"},
            {"普通", "Normal"},
            {"高级", "Hard"},
            {"专家", "Impossible"},
    };

    public static String cmdDifficulty(String value) {
        return "sm_cvar z_difficulty " + value;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    /// 模式（M_MODE）
    //////////////////////////////////////////////////////////////////////////////////////////////

    public static final String[][] GAMEMODE = {
            {"战役模式", "coop"},
            {"写实模式", "realism"},
            {"绝境求生", "mutation4"},
            {"特感速递", "community1"},
            {"死亡之门", "community5"},
            {"剑客模式", "mutation5"},
            {"爆头模式", "mutation2"},
            {"侏儒治愈", "mutation20"},
            {"生存模式", "survival"},
            {"对抗模式", "versus"},
    };

    public static String cmdGameMode(String value) {
        return "sm_cvar mp_gamemode " + value;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    /// 队友伤害 / 火焰伤害（M_FF，每项 4 条命令）
    //////////////////////////////////////////////////////////////////////////////////////////////

    public static String[] cmdFriendlyFireOn() {
        return new String[]{
                "sm_cvar survivor_friendly_fire_factor_easy 0.0",
                "sm_cvar survivor_friendly_fire_factor_normal 0.1",
                "sm_cvar survivor_friendly_fire_factor_hard 0.3",
                "sm_cvar survivor_friendly_fire_factor_expert 0.5",
        };
    }

    public static String[] cmdFriendlyFireOff() {
        return new String[]{
                "sm_cvar survivor_friendly_fire_factor_easy 0",
                "sm_cvar survivor_friendly_fire_factor_normal 0",
                "sm_cvar survivor_friendly_fire_factor_hard 0",
                "sm_cvar survivor_friendly_fire_factor_expert 0",
        };
    }

    public static String[] cmdBurnOn() {
        return new String[]{
                "sm_cvar survivor_burn_factor_easy 0.2",
                "sm_cvar survivor_burn_factor_normal 0.2",
                "sm_cvar survivor_burn_factor_hard 0.4",
                "sm_cvar survivor_burn_factor_expert 1.0",
        };
    }

    public static String[] cmdBurnOff() {
        return new String[]{
                "sm_cvar survivor_burn_factor_easy 0",
                "sm_cvar survivor_burn_factor_normal 0",
                "sm_cvar survivor_burn_factor_hard 0",
                "sm_cvar survivor_burn_factor_expert 0",
        };
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    /// 人数（M_MAXP，必须两条一起发）
    //////////////////////////////////////////////////////////////////////////////////////////////

    public static String[] cmdMaxPlayers(int n) {
        return new String[]{
                "sm_cvar sv_maxplayers " + n,
                "sm_cvar sv_visiblemaxplayers " + n,
        };
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    /// 其它命令
    //////////////////////////////////////////////////////////////////////////////////////////////

    public static String cmdChangelevel(String map) {
        return "changelevel " + map;
    }

    /** 脚本统一用 sm_kick #ID */
    public static String cmdKick(String userId) {
        return "sm_kick #" + userId;
    }

    public static final String CMD_QUIT = "quit";
    public static final String CMD_STATUS = "status";
    public static final String CMD_MAPS = "maps *";
    /** maps * 没输出时脚本会退回这条 */
    public static final String CMD_MAPS_FALLBACK = "maps";
    /** 取当前地图的兜底命令 */
    public static final String CMD_HOST_MAP = "host_map";

    ///////////////////////////////////////////////////////////////////////////////////////////////
    /// 当前地图解析（对齐 rcon.ps1 的 -Mode curmap）
    //////////////////////////////////////////////////////////////////////////////////////////////

    private static final Pattern RE_MAP_LINE =
            Pattern.compile("(?i)^\\s*map\\s*:\\s*([0-9A-Za-z_.\\-]+)");
    private static final Pattern RE_HOST_MAP_QUOTED =
            Pattern.compile("=\\s*\"([^\"]+)\"");
    private static final Pattern RE_HOST_MAP_PLAIN =
            Pattern.compile("=\\s*([0-9A-Za-z_.\\-]+)");
    private static final Pattern RE_BSP_LINE =
            Pattern.compile("^([0-9A-Za-z_.\\-]+)\\.bsp");
    private static final Pattern RE_NOT_A_MAP =
            Pattern.compile("(?i)^(def|game|server|unknown|map|maps)$");
    private static final Pattern RE_VALID_NAME =
            Pattern.compile("^[0-9A-Za-z_.\\-][0-9A-Za-z_.\\- ]*$");

    /** rcon.ps1 里的 $Norm：去空白 / 去 .bsp / 过滤掉明显不是地图名的词 */
    private static String norm(String v) {
        if (v == null) return "";
        String s = v.replace("\r", "").trim();
        s = s.replaceAll("\\.bsp$", "");
        if (s.isEmpty()) return "";
        if (s.toUpperCase().contains("PENDING")) return "";
        if (RE_NOT_A_MAP.matcher(s).matches()) return "";
        if (!RE_VALID_NAME.matcher(s).matches()) return "";
        return s;
    }

    /**
     * 从 status 输出里取当前地图。
     * 脚本注释：L4D2 的 host_map 在 changelevel 后常常不更新，所以 status 优先。
     */
    public static String parseCurrentMap(String statusOutput) {
        if (statusOutput == null) return null;
        for (String line : statusOutput.split("\\r?\\n")) {
            Matcher m = RE_MAP_LINE.matcher(line);
            if (m.find()) {
                String v = norm(m.group(1));
                if (!v.isEmpty()) return v;
            }
        }
        return null;
    }

    /** 兜底：从 host_map 的输出里取地图名（先找引号里的，再找 = 后面的） */
    public static String parseHostMap(String hostMapOutput) {
        if (hostMapOutput == null) return null;
        for (String line : hostMapOutput.split("\\r?\\n")) {
            String t = line.replace("\r", "").trim();
            if (t.isEmpty() || t.toUpperCase().contains("PENDING")) continue;

            Matcher mq = RE_HOST_MAP_QUOTED.matcher(line);
            if (mq.find()) {
                String v = norm(mq.group(1));
                if (!v.isEmpty()) return v;
            }
            Matcher mp = RE_HOST_MAP_PLAIN.matcher(line);
            if (mp.find()) {
                String v = norm(mp.group(1));
                if (!v.isEmpty()) return v;
            }
        }
        // 最后再找独立的 .bsp 行
        for (String line : hostMapOutput.split("\\r?\\n")) {
            String t = line.replace("\r", "").trim();
            if (t.isEmpty() || t.toUpperCase().contains("PENDING")) continue;
            Matcher mb = RE_BSP_LINE.matcher(t);
            if (mb.find()) {
                String v = norm(mb.group(1));
                if (!v.isEmpty()) return v;
            }
        }
        return null;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    /// 地图列表解析（对齐 rcon.ps1 的 -Mode maps）
    //////////////////////////////////////////////////////////////////////////////////////////////

    /** 排除名单：既不是官方地图，也不是第三方地图（直接取自 rcon.ps1 v7） */
    private static final String[] MAP_EXCLUDE = {
            "c5m1_waterfront_sndscape",
            "credits", "curling_stadium", "motionprimingtest", "motionprimingtest_rev",
            "navigationtest_a", "styleguide_semiurban_01", "styleguide_swamp01",
            "styleguide_swamp_cheapwater01", "styleguide_urban_01", "test_box2",
            "test_macguffin", "test_mall", "test_scavenge", "tutorial_standards",
            "tutorial_standards_vs", "zoo_carnivalgames", "zoo_infected2", "zoo_jukebox",
            "zoo_swamp_foliage_01", "zoo_trafficsigns", "zoo_urban_foliage_01",
    };

    private static final Pattern RE_BSP_NAME =
            Pattern.compile("([0-9A-Za-z_\\-][0-9A-Za-z_\\- ]*)\\.bsp");
    private static final Pattern RE_CAMPAIGN =
            Pattern.compile("^c(\\d+)m(\\d+)");

    private static class OfficialMap {
        int c;
        int m;
        String name;
    }

    /**
     * 解析 maps * / maps 的输出。
     * 分两组：官方图（c数字m数字，按战役号、章节号排序）在前，第三方图（按名称排序）在后。
     */
    public static List<String> parseMapList(String output) {
        List<String> result = new ArrayList<String>();
        if (output == null) return result;

        List<OfficialMap> official = new ArrayList<OfficialMap>();
        List<String> third = new ArrayList<String>();

        for (String line : output.split("\\r?\\n")) {
            if (!line.contains(".bsp")) continue;

            Matcher m = RE_BSP_NAME.matcher(line);
            if (!m.find()) continue;

            String nm = m.group(1);
            if (nm.length() < 2) continue;

            boolean excluded = false;
            for (String e : MAP_EXCLUDE) {
                if (e.equals(nm)) { excluded = true; break; }
            }
            if (excluded) continue;

            Matcher cm = RE_CAMPAIGN.matcher(nm);
            if (cm.find()) {
                boolean dup = false;
                for (OfficialMap o : official) {
                    if (o.name.equals(nm)) { dup = true; break; }
                }
                if (!dup) {
                    OfficialMap o = new OfficialMap();
                    o.c = Integer.parseInt(cm.group(1));
                    o.m = Integer.parseInt(cm.group(2));
                    o.name = nm;
                    official.add(o);
                }
            } else {
                if (!third.contains(nm)) third.add(nm);
            }
        }

        Collections.sort(official, new Comparator<OfficialMap>() {
            @Override
            public int compare(OfficialMap a, OfficialMap b) {
                if (a.c != b.c) return a.c - b.c;
                return a.m - b.m;
            }
        });
        Collections.sort(third);

        for (OfficialMap o : official) result.add(o.name);
        result.addAll(third);
        return result;
    }
}
