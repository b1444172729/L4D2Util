package com.srcdsutil.rcon;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.srcdsutil.rcon.common.L4D2Server;
import com.srcdsutil.rcon.common.ServerInfoText;

/**
 * 服务器详情页。
 *
 * 改动：
 *  原本这里自己拼了一套简略信息（服务器名 / 游戏 / 地图 / 在线人数 / 玩家列表），
 *  现在删掉那套代码，改为直接显示与"远程"页面 [1] 信息查询 完全相同的内容
 *  ——进入页面就自动查一次，没有菜单按钮，右上角刷新图标仍可手动重查。
 *
 * 查询仍是 A2S / UDP：A2S_INFO 取服务器信息，A2S_PLAYER 取玩家名单。
 */
public class ServerDetailActivity extends AppCompatActivity {
    private String hostname;
    private int port;

    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_server_detail);
        textView = (TextView) findViewById(R.id.text_server_detail);

        Intent intent = getIntent();
        this.hostname = intent.getStringExtra("hostname");
        this.port = intent.getIntExtra("port", 27015);

        setTitle(hostname);
        refreshDetail();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_server_detail, menu);
        return true;
    }

    public void onRefreshClick(MenuItem item) {
        refreshDetail();
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////

    private void refreshDetail() {
        textView.setText(R.string.toast_refreshing);
        (new RefreshServerDetailAsyncTask(this, hostname, port)).execute();
    }

    private static class RefreshServerDetailAsyncTask extends AsyncTask<Object, Object, Object[]> {
        private final ServerDetailActivity context;
        private final String hostname;
        private final int port;

        RefreshServerDetailAsyncTask(ServerDetailActivity context, String hostname, int port) {
            this.context = context;
            this.hostname = hostname;
            this.port = port;
        }

        @Override
        protected Object[] doInBackground(Object... useless) {
            return new Object[] {
                    L4D2Server.QueryServerInfo(hostname, port),
                    L4D2Server.GetPlayerList(hostname, port)
            };
        }

        @Override
        protected void onPostExecute(Object[] results) {
            L4D2Server.Info info = (L4D2Server.Info) results[0];
            String[] players = (String[]) results[1];

            if (info != null && info.serverName != null && !info.serverName.isEmpty()) {
                context.setTitle(info.serverName);
            }

            // 服务器详情页用精简版格式
            context.textView.setText(
                    ServerInfoText.buildBrief(context, hostname, port, info, players));
        }
    }
}
