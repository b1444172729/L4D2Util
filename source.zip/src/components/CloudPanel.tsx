import { useEffect, useState, useCallback } from "react";
import { invoke } from "@tauri-apps/api/core";
import {
  X, AlertTriangle, CheckCircle2, Cloud, ArrowRight, ArrowLeft,
  LogOut, Mail, KeyRound, UserPlus, LogIn, Wand2,
} from "lucide-react";
import InvitesSection from "./InvitesSection";
import SyncServerSetting, { CloudConfigView, hostOf } from "./SyncServerSetting";

// Cloud account panel, opened from the profile picker. Owns its own auth state;
// the parent just mounts/unmounts. Signed-out is split into intent-first flows
// (chooser → sign-in / sign-up / forgot / magic-link). Signed-in is now just
// the account identity plus the two things that legitimately live where
// profiles are born: incoming shares to accept, and restoring one of your own
// cloud profiles onto this device. Per-profile sync moved into the app's
// Profile panel; the old whole-vault blob sync is gone entirely.

interface CloudStatus { signed_in: boolean; email: string | null; }

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onLocalProfilesChanged: () => void;
}

type Stage =
  | "chooser"
  | "sign-in"
  | "sign-up-email"
  | "sign-up-verify"
  | "sign-up-password"
  | "forgot-email"
  | "forgot-reset"
  | "link-email"
  | "link-verify"
  | "signed-in";

const CloudPanel = ({ isOpen, onClose, onLocalProfilesChanged }: Props) => {
  const [stage, setStage] = useState<Stage>("chooser");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPw, setConfirmPw] = useState("");
  const [verifyToken, setVerifyToken] = useState("");
  const [claimToken, setClaimToken] = useState<string | null>(null);
  const [resetToken, setResetToken] = useState("");
  const [loginLinkToken, setLoginLinkToken] = useState("");
  const [signedInEmail, setSignedInEmail] = useState<string | null>(null);

  const [serverView, setServerView] = useState<CloudConfigView | null>(null);

  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);

  const resetForms = () => {
    setEmail(""); setPassword(""); setConfirmPw("");
    setVerifyToken(""); setClaimToken(null);
    setResetToken(""); setLoginLinkToken("");
    setError(null); setInfo(null);
  };

  const refreshStatus = useCallback(async () => {
    try {
      const s = await invoke<CloudStatus>("cloud_status");
      if (s.signed_in) {
        setStage("signed-in");
        setSignedInEmail(s.email);
      } else {
        // Only reset to chooser if we're not mid-flow (verify / set-password
        // shouldn't bounce back to chooser when the panel re-opens).
        setStage((prev) =>
          prev === "sign-up-verify" || prev === "sign-up-password" ? prev : "chooser",
        );
      }
    } catch (e: any) {
      setError(String(e));
    }
  }, []);

  useEffect(() => {
    if (!isOpen) return;
    refreshStatus();
    invoke<CloudConfigView>("cloud_get_config").then(setServerView).catch((e) => setError(String(e)));
  }, [isOpen, refreshStatus]);

  // Another server: signed out, and every half-done flow starts over. A claim
  // or reset token from one server means nothing to the next, and a password
  // typed for one must not be sent to the other.
  const onServerChanged = (view: CloudConfigView, serverChanged: boolean) => {
    setServerView(view);
    if (serverChanged) {
      resetForms();
      setSignedInEmail(null);
      setStage("chooser");
      setInfo(`Sync server set to ${hostOf(view.server)}. Sign in or create an account there.`);
    }
    refreshStatus();
  };

  // ---- Auth handlers ---------------------------------------------------

  const handleLogin = async () => {
    setError(null);
    if (!email.trim() || !password) { setError("Email and password required"); return; }
    setBusy(true);
    try {
      const s = await invoke<CloudStatus>("cloud_login", {
        email: email.trim(), password,
      });
      if (s.signed_in) {
        setSignedInEmail(s.email);
        setStage("signed-in");
        resetForms();
      }
    } catch (e: any) {
      setError(String(e));
    } finally {
      setBusy(false);
    }
  };

  const handleSignupEmail = async () => {
    setError(null); setInfo(null);
    if (!email.trim()) { setError("Enter your email"); return; }
    setBusy(true);
    try {
      await invoke("cloud_signup", { email: email.trim() });
      setInfo("Check your inbox for the verification link. Paste the token below.");
      setStage("sign-up-verify");
    } catch (e: any) {
      setError(String(e));
    } finally {
      setBusy(false);
    }
  };

  const handleVerify = async () => {
    setError(null);
    if (!verifyToken.trim()) { setError("Paste the verify token from your email"); return; }
    setBusy(true);
    try {
      const resp = await invoke<{ claim_token: string; email: string }>(
        "cloud_consume_verify_link",
        { verifyToken: verifyToken.trim() },
      );
      setClaimToken(resp.claim_token);
      setEmail(resp.email);
      setStage("sign-up-password");
      setInfo("Email verified. Now set a password for your account.");
    } catch (e: any) {
      setError(String(e));
    } finally {
      setBusy(false);
    }
  };

  const handleSetPassword = async () => {
    setError(null);
    if (!claimToken) { setError("Verify your email first"); return; }
    if (password.length < 8) { setError("密码至少 8 个字符"); return; }
    if (password !== confirmPw) { setError("两次输入的密码不一致"); return; }
    setBusy(true);
    try {
      const s = await invoke<CloudStatus>("cloud_set_password", { claimToken, password });
      if (s.signed_in) {
        setSignedInEmail(s.email);
        setStage("signed-in");
        setInfo("Account created and signed in.");
        resetForms();
      }
    } catch (e: any) {
      setError(String(e));
    } finally {
      setBusy(false);
    }
  };

  const handleRequestReset = async () => {
    setError(null); setInfo(null);
    if (!email.trim()) { setError("Enter your email"); return; }
    setBusy(true);
    try {
      await invoke("cloud_request_password_reset", { email: email.trim() });
      setInfo("If that email is registered, a reset link is on its way. Paste the token below.");
      setStage("forgot-reset");
    } catch (e: any) {
      setError(String(e));
    } finally {
      setBusy(false);
    }
  };

  const handleResetPassword = async () => {
    setError(null);
    if (!resetToken.trim()) { setError("Paste the reset token from your email"); return; }
    if (password.length < 8) { setError("密码至少 8 个字符"); return; }
    if (password !== confirmPw) { setError("两次输入的密码不一致"); return; }
    setBusy(true);
    try {
      const s = await invoke<CloudStatus>("cloud_reset_password", {
        resetToken: resetToken.trim(), password,
      });
      if (s.signed_in) {
        setSignedInEmail(s.email);
        setStage("signed-in");
        setInfo("Password updated and signed in. Other devices have been signed out.");
        resetForms();
      }
    } catch (e: any) {
      setError(String(e));
    } finally {
      setBusy(false);
    }
  };

  const handleRequestLoginLink = async () => {
    setError(null); setInfo(null);
    if (!email.trim()) { setError("Enter your email"); return; }
    setBusy(true);
    try {
      await invoke("cloud_request_login_link", { email: email.trim() });
      setInfo("If that email is registered, a sign-in link is on its way. Paste the token below.");
      setStage("link-verify");
    } catch (e: any) {
      setError(String(e));
    } finally {
      setBusy(false);
    }
  };

  const handleLoginWithLink = async () => {
    setError(null);
    if (!loginLinkToken.trim()) { setError("Paste the sign-in token from your email"); return; }
    setBusy(true);
    try {
      const s = await invoke<CloudStatus>("cloud_login_with_link", {
        loginToken: loginLinkToken.trim(),
      });
      if (s.signed_in) {
        setSignedInEmail(s.email);
        setStage("signed-in");
        resetForms();
      }
    } catch (e: any) {
      setError(String(e));
    } finally {
      setBusy(false);
    }
  };

  const handleLogout = async () => {
    setBusy(true);
    try {
      await invoke("cloud_logout");
      setStage("chooser");
      setSignedInEmail(null);
      resetForms();
    } catch (e: any) {
      setError(String(e));
    } finally {
      setBusy(false);
    }
  };

  // Which server the credentials on a step go to, when it is a self-hosted one.
  const serverLine = serverView?.is_custom && (
    <p className="text-[11px] text-zinc-500 -mt-1">
      on <span className="font-mono text-zinc-300">{hostOf(serverView.server)}</span>
    </p>
  );

  const goBack = () => {
    setError(null); setInfo(null);
    setStage("chooser");
  };

  // ---- Render ----------------------------------------------------------

  if (!isOpen) return null;

  const inputBase =
    "w-full h-10 px-3 bg-zinc-900/60 border border-white/10 rounded-lg text-[13px] text-zinc-50 placeholder:text-zinc-600 outline-none focus:border-primary/50 transition-colors";

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-3" onClick={onClose}>
      <div
        className="w-full max-w-3xl max-h-[90vh] flex flex-col bg-[#121214] border border-white/10 rounded-xl shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="shrink-0 px-4 py-3 border-b border-white/5 flex items-center justify-between">
          <div className="flex items-center gap-2 text-[12px] font-bold uppercase tracking-widest text-white">
            <Cloud size={14} className="text-primary" />
            <span>云端同步</span>
            {signedInEmail && stage === "signed-in" && (
              <span className="text-zinc-500 font-mono normal-case text-[11px] tracking-normal ml-2">
                {signedInEmail}
              </span>
            )}
          </div>
          <button aria-label="Close" onClick={onClose} className="text-zinc-400 hover:text-white"><X size={16} /></button>
        </div>

        <div className="flex-1 overflow-y-auto custom-scrollbar p-5 space-y-3">
          {error && (
            <div className="px-3 py-2 bg-rose-500/15 border border-rose-500/30 rounded text-rose-200 text-[12px] flex items-start gap-2">
              <AlertTriangle size={13} className="mt-0.5 shrink-0" />
              <span className="flex-1 break-words whitespace-pre-line">{error}</span>
              <button aria-label="Dismiss" onClick={() => setError(null)} className="text-rose-300/70 hover:text-white mt-0.5"><X size={12} /></button>
            </div>
          )}
          {info && !error && (
            <div className="px-3 py-2 bg-emerald-500/10 border border-emerald-500/20 rounded text-emerald-100 text-[12px] flex items-center gap-2">
              <CheckCircle2 size={13} /> <span className="flex-1 break-words">{info}</span>
              <button aria-label="Dismiss" onClick={() => setInfo(null)} className="text-emerald-200/70 hover:text-white"><X size={12} /></button>
            </div>
          )}

          {/* ----- Chooser ----- */}
          {stage === "chooser" && (
            <div className="max-w-sm mx-auto py-6 space-y-3">
              <p className="text-center text-[12.5px] text-zinc-400 pb-2">
                跨设备同步加密档案。
              </p>
              <button
                onClick={() => { resetForms(); setStage("sign-in"); }}
                className="w-full h-12 rounded-lg bg-primary text-black text-[13.5px] font-bold flex items-center justify-center gap-2"
              >
                <LogIn size={15} /> 登录
              </button>
              <button
                onClick={() => { resetForms(); setStage("sign-up-email"); }}
                className="w-full h-12 rounded-lg bg-white/5 border border-white/10 text-zinc-100 hover:bg-white/10 text-[13.5px] font-bold flex items-center justify-center gap-2"
              >
                <UserPlus size={15} /> 创建账号
              </button>
              <button
                onClick={() => setStage("sign-up-verify")}
                className="w-full h-9 text-[12px] text-zinc-500 hover:text-primary"
              >
                已有验证令牌？继续验证 →
              </button>
            </div>
          )}

          {/* ----- Sign in ----- */}
          {stage === "sign-in" && (
            <div className="max-w-sm mx-auto py-4 space-y-3">
              <div className="flex items-center gap-2 pb-1">
                <button aria-label="Back" onClick={goBack} className="text-zinc-400 hover:text-white"><ArrowLeft size={14} /></button>
                <span className="text-[12.5px] font-bold uppercase tracking-wider text-zinc-300">登录</span>
              </div>
              {serverLine}
              <input
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className={inputBase}
                autoFocus
              />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleLogin()}
                placeholder="密码"
                className={inputBase}
              />
              <button
                onClick={handleLogin}
                disabled={busy}
                className="w-full h-10 rounded-lg bg-primary text-black text-[13px] font-bold disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {busy ? "…" : (<>登录 <ArrowRight size={14} /></>)}
              </button>
              <div className="flex items-center gap-2 pt-1">
                <button
                  onClick={() => { setError(null); setInfo(null); setPassword(""); setStage("link-email"); }}
                  className="flex-1 h-9 rounded text-[11.5px] text-zinc-300 hover:text-primary hover:bg-white/5 border border-white/10 flex items-center justify-center gap-1.5"
                >
                  <Wand2 size={12} /> 发送登录链接到我的邮箱
                </button>
                <button
                  onClick={() => { setError(null); setInfo(null); setPassword(""); setStage("forgot-email"); }}
                  className="flex-1 h-9 rounded text-[11.5px] text-zinc-300 hover:text-primary hover:bg-white/5 border border-white/10"
                >
                  忘记密码？
                </button>
              </div>
            </div>
          )}

          {/* ----- Forgot password: email ----- */}
          {stage === "forgot-email" && (
            <div className="max-w-sm mx-auto py-4 space-y-3">
              <div className="flex items-center gap-2 pb-1">
                <button aria-label="Back" onClick={goBack} className="text-zinc-400 hover:text-white"><ArrowLeft size={14} /></button>
                <span className="text-[12.5px] font-bold uppercase tracking-wider text-zinc-300">重置密码</span>
              </div>
              {serverLine}
              <p className="text-[11.5px] text-zinc-500 leading-relaxed">
                输入你注册时使用的邮箱。如果该邮箱已注册，我们会发送一个重置令牌。
                你的本地保险库和已保存的服务器不受影响——只有云端同步密码会被更改。
              </p>
              <input
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleRequestReset()}
                placeholder="you@example.com"
                className={inputBase}
                autoFocus
              />
              <button
                onClick={handleRequestReset}
                disabled={busy}
                className="w-full h-10 rounded-lg bg-primary text-black text-[13px] font-bold disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {busy ? "…" : (<><Mail size={13} /> 发送重置密码邮件</>)}
              </button>
              <button
                onClick={() => { setError(null); setInfo(null); setStage("forgot-reset"); }}
                className="w-full h-9 text-[12px] text-zinc-500 hover:text-primary"
              >
                已有重置令牌？继续 →
              </button>
            </div>
          )}

          {/* ----- Forgot password: paste token + new password ----- */}
          {stage === "forgot-reset" && (
            <div className="max-w-sm mx-auto py-4 space-y-3">
              <div className="flex items-center gap-2 pb-1">
                <button aria-label="Back" onClick={goBack} className="text-zinc-400 hover:text-white"><ArrowLeft size={14} /></button>
                <span className="text-[12.5px] font-bold uppercase tracking-wider text-zinc-300">新密码</span>
              </div>
              {serverLine}
              <p className="text-[12px] text-zinc-300">
                粘贴邮件中的重置令牌，然后设置新密码。
              </p>
              <input
                value={resetToken}
                onChange={(e) => setResetToken(e.target.value)}
                placeholder="重置令牌"
                className={inputBase + " font-mono"}
                autoFocus
              />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="新密码（至少 8 个字符）"
                className={inputBase}
              />
              <input
                type="password"
                value={confirmPw}
                onChange={(e) => setConfirmPw(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleResetPassword()}
                placeholder="确认新密码"
                className={inputBase}
              />
              <button
                onClick={handleResetPassword}
                disabled={busy}
                className="w-full h-10 rounded-lg bg-primary text-black text-[13px] font-bold disabled:opacity-50"
              >
                {busy ? "…" : "设置新密码并登录"}
              </button>
              <p className="text-[11px] text-zinc-500 leading-relaxed pt-1">
                注意：修改密码会使当前登录此账号的其他设备退出登录。
              </p>
            </div>
          )}

          {/* ----- Magic link: request ----- */}
          {stage === "link-email" && (
            <div className="max-w-sm mx-auto py-4 space-y-3">
              <div className="flex items-center gap-2 pb-1">
                <button aria-label="Back" onClick={goBack} className="text-zinc-400 hover:text-white"><ArrowLeft size={14} /></button>
                <span className="text-[12.5px] font-bold uppercase tracking-wider text-zinc-300">使用邮箱登录</span>
              </div>
              {serverLine}
              <p className="text-[11.5px] text-zinc-500 leading-relaxed">
                我们会通过邮件发送一个一次性登录验证码。这次无需密码——
                你现有的密码保持不变。
              </p>
              <input
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleRequestLoginLink()}
                placeholder="you@example.com"
                className={inputBase}
                autoFocus
              />
              <button
                onClick={handleRequestLoginLink}
                disabled={busy}
                className="w-full h-10 rounded-lg bg-primary text-black text-[13px] font-bold disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {busy ? "…" : (<><Wand2 size={13} /> 发送登录链接</>)}
              </button>
              <button
                onClick={() => { setError(null); setInfo(null); setStage("link-verify"); }}
                className="w-full h-9 text-[12px] text-zinc-500 hover:text-primary"
              >
                已有登录令牌？继续 →
              </button>
            </div>
          )}

          {/* ----- Magic link: consume ----- */}
          {stage === "link-verify" && (
            <div className="max-w-sm mx-auto py-4 space-y-3">
              <div className="flex items-center gap-2 pb-1">
                <button aria-label="Back" onClick={goBack} className="text-zinc-400 hover:text-white"><ArrowLeft size={14} /></button>
                <span className="text-[12.5px] font-bold uppercase tracking-wider text-zinc-300">使用邮箱登录</span>
              </div>
              {serverLine}
              <p className="text-[12px] text-zinc-300">
                粘贴邮件中的登录令牌。
              </p>
              <input
                value={loginLinkToken}
                onChange={(e) => setLoginLinkToken(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleLoginWithLink()}
                placeholder="sign-in token"
                className={inputBase + " font-mono"}
                autoFocus
              />
              <button
                onClick={handleLoginWithLink}
                disabled={busy}
                className="w-full h-10 rounded-lg bg-primary text-black text-[13px] font-bold disabled:opacity-50"
              >
                {busy ? "…" : "登录"}
              </button>
            </div>
          )}

          {/* ----- Sign up: email ----- */}
          {stage === "sign-up-email" && (
            <div className="max-w-sm mx-auto py-4 space-y-3">
              <div className="flex items-center gap-2 pb-1">
                <button aria-label="Back" onClick={goBack} className="text-zinc-400 hover:text-white"><ArrowLeft size={14} /></button>
                <span className="text-[12.5px] font-bold uppercase tracking-wider text-zinc-300">创建账号</span>
              </div>
              {serverLine}
              <p className="text-[11.5px] text-zinc-500 leading-relaxed">
                我们会通过邮件发送一个验证链接。随后你可以在应用内设置密码。
              </p>
              <input
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSignupEmail()}
                placeholder="you@example.com"
                className={inputBase}
                autoFocus
              />
              <button
                onClick={handleSignupEmail}
                disabled={busy}
                className="w-full h-10 rounded-lg bg-primary text-black text-[13px] font-bold disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {busy ? "…" : (<><Mail size={13} /> 发送验证邮件</>)}
              </button>
            </div>
          )}

          {/* ----- Sign up: verify ----- */}
          {stage === "sign-up-verify" && (
            <div className="max-w-sm mx-auto py-4 space-y-3">
              <div className="flex items-center gap-2 pb-1">
                <button aria-label="Back" onClick={goBack} className="text-zinc-400 hover:text-white"><ArrowLeft size={14} /></button>
                <span className="text-[12.5px] font-bold uppercase tracking-wider text-zinc-300">验证邮箱</span>
              </div>
              {serverLine}
              <p className="text-[12px] text-zinc-300">
                Paste the token from the email{email ? <> 已发送至 <span className="font-mono text-primary">{email}</span></> : null}.
              </p>
              <input
                value={verifyToken}
                onChange={(e) => setVerifyToken(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleVerify()}
                placeholder="验证令牌"
                className={inputBase + " font-mono"}
                autoFocus
              />
              <button
                onClick={handleVerify}
                disabled={busy}
                className="w-full h-10 rounded-lg bg-primary text-black text-[13px] font-bold disabled:opacity-50"
              >
                {busy ? "…" : "验证"}
              </button>
            </div>
          )}

          {/* ----- Sign up: set password ----- */}
          {stage === "sign-up-password" && (
            <div className="max-w-sm mx-auto py-4 space-y-3">
              {serverLine}
              <p className="text-[12px] text-zinc-300 flex items-center gap-1.5">
                <KeyRound size={13} className="text-primary" /> Choose a password for{" "}
                <span className="font-mono text-primary">{email}</span>.
              </p>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="密码（至少 8 个字符）"
                className={inputBase}
                autoFocus
              />
              <input
                type="password"
                value={confirmPw}
                onChange={(e) => setConfirmPw(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSetPassword()}
                placeholder="确认密码"
                className={inputBase}
              />
              <button
                onClick={handleSetPassword}
                disabled={busy}
                className="w-full h-10 rounded-lg bg-primary text-black text-[13px] font-bold disabled:opacity-50"
              >
                {busy ? "…" : "设置密码并登录"}
              </button>
            </div>
          )}

          {/* ----- Signed in (account + shares + restore) ----- */}
          {stage === "signed-in" && (
            <div className="space-y-3">
              <div className="bg-zinc-900/40 border border-white/5 rounded-lg p-3 flex items-center gap-2">
                <Cloud size={14} className="text-primary shrink-0" />
                <span className="text-[12.5px] text-zinc-200 font-mono truncate flex-1">{signedInEmail}</span>
              </div>
              <p className="text-[11.5px] text-zinc-500 leading-relaxed">
                Your profiles sync automatically once open — manage sync and sharing for a profile
                from its <span className="text-zinc-300 font-semibold">档案</span> panel inside the app.
              </p>

              <InvitesSection onLocalProfilesChanged={onLocalProfilesChanged} />

              <div className="pt-2 flex justify-end">
                <button
                  onClick={handleLogout}
                  disabled={busy}
                  className="h-8 px-3 rounded text-[11.5px] font-bold uppercase tracking-wider bg-white/5 border border-white/10 text-zinc-300 hover:text-rose-300 hover:bg-rose-500/10 flex items-center gap-1.5 disabled:opacity-50"
                >
                  <LogOut size={11} /> 退出登录
                </button>
              </div>
            </div>
          )}
          {serverView && (
            <SyncServerSetting view={serverView} signedIn={stage === "signed-in"} onChanged={onServerChanged} />
          )}
        </div>
      </div>
    </div>
  );
};

export default CloudPanel;
