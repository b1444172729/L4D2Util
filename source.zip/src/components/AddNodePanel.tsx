import { useEffect, useState } from "react";
import { createPortal } from "react-dom";
import { invoke } from "@tauri-apps/api/core";
import { Cpu, X, Link2, ArrowLeftRight, Shield, Key, User, FolderPlus, Download, CheckSquare, Square, History, Plus, Copy, Play } from "lucide-react";
import PasswordField from "./PasswordField";
import { useConfirm, useTextPrompt } from "../ui/confirm";
import { useSlideOverFocus } from "../ui/slideOverFocus";

// Compact "2h ago" style relative time for the attribution line.
function relTime(d: Date): string {
  const s = Math.floor((Date.now() - d.getTime()) / 1000);
  if (s < 45) return "刚刚";
  const m = Math.floor(s / 60); if (m < 60) return `${m} 分钟前`;
  const h = Math.floor(m / 60); if (h < 24) return `${h} 小时前`;
  const dd = Math.floor(h / 24); if (dd < 30) return `${dd} 天前`;
  return d.toLocaleDateString();
}

// The HLC stamp is "{phys_ms}:{counter}:{node_id}" — the leading segment is the
// wall-clock millisecond the row was last written.
function hlcTime(stamp?: string | null): Date | null {
  if (!stamp) return null;
  const ms = parseInt(String(stamp).split(":")[0], 10);
  return Number.isFinite(ms) && ms > 0 ? new Date(ms) : null;
}

// Shape returned by the `parse_ssh_config` backend command. One entry per
// non-wildcard alias resolved from the user's OpenSSH config.
type ImportedHost = {
  host_alias: string;
  hostname: string;
  port: number;
  user: string;
  identity_file: string | null;
  proxy_jump: string | null;
};

// What `import_ssh_key_file` hands back after putting a key file in the vault.
type ImportedSshKey = {
  id: number;
  name: string;
  reused: boolean;
  encrypted: boolean;
};

const AddNodePanel = ({ isOpen, onClose, newNode, setNewNode, onSave, credentials, sshKeys, refreshSshKeys, folders, refreshFolders, refreshServers, servers, isEditMode, formError, isMobile }: any) => {
  const [isCreatingFolder, setIsCreatingFolder] = useState(false);
  const [newFolderName, setNewFolderName] = useState("");
  // Set while the native key picker is open so the Browse button can't be
  // fired twice — a second dialog would sit behind the first with no way to
  // tell which one the user is answering.
  const [keyBrowseBusy, setKeyBrowseBusy] = useState(false);
  const [keyBrowseNote, setKeyBrowseNote] = useState<string | null>(null);
  // A key generated from this form: its public half is shown (with a copy
  // button) while it's the selected key, since it has to go into the
  // server's authorized_keys before it can log in.
  const [generatedKey, setGeneratedKey] = useState<{ id: number; name: string; publicKey: string } | null>(null);
  const [publicKeyCopied, setPublicKeyCopied] = useState(false);
  const textPrompt = useTextPrompt();
  const confirm = useConfirm();
  const panelRef = useSlideOverFocus(isOpen);

  // The panel stays mounted and slides off-screen rather than unmounting, so
  // the note from the last key someone loaded would still be sitting there the
  // next time they open it — against a different server.
  useEffect(() => {
    if (!isOpen) {
      setKeyBrowseNote(null);
      setGeneratedKey(null);
    }
  }, [isOpen]);

  // SSH-config import modal state. Lives here so it's colocated with the
  // "Add server" flow — the button that triggers it sits in this panel's
  // header. `hosts` is the raw list returned by parse_ssh_config; `selected`
  // is the subset of aliases the user ticked; `busy` blocks the import
  // button while add_server calls are inflight so the user can't double-fire.
  const [importOpen, setImportOpen] = useState(false);
  const [importLoading, setImportLoading] = useState(false);
  const [importBusy, setImportBusy] = useState(false);
  const [importError, setImportError] = useState<string | null>(null);
  // Separate from importError: the import worked, there's just something the
  // user has to follow up on (a key that still needs its passphrase).
  const [importNotice, setImportNotice] = useState<string | null>(null);
  const [importHosts, setImportHosts] = useState<ImportedHost[]>([]);
  const [importSelected, setImportSelected] = useState<Set<string>>(new Set());
  // Source selector for the import modal. `ssh` = the on-disk OpenSSH
  // config (desktop only); `paste` = a text blob pasted from PuTTY /
  // MobaXterm / a JSON export — parsed by the auto-detecting Rust
  // command so the user doesn't have to say which client it came from.
  const [importSource, setImportSource] = useState<"ssh" | "paste">("ssh");
  const [importPasteText, setImportPasteText] = useState("");

  // Open the picker: fetch fresh from ~/.ssh/config every time so users who
  // edit the file between imports see current contents. We keep the modal
  // open on empty results so the user gets an explicit "nothing to import"
  // message rather than a silent no-op.
  // Open the modal and immediately try the SSH-config path — that's the
  // most common source on desktop. If it errors (Android, no config file,
  // permissions), the user just switches to the "Paste" tab and drops in
  // their PuTTY/MobaXterm/JSON export instead.
  const openImportModal = async () => {
    setImportOpen(true);
    setImportSource("ssh");
    setImportPasteText("");
    setImportError(null);
    setImportNotice(null);
    setImportHosts([]);
    setImportSelected(new Set());
    setImportLoading(true);
    try {
      const hosts = await invoke<ImportedHost[]>("parse_ssh_config", { path: null });
      setImportHosts(hosts);
    } catch (e: any) {
      setImportError(typeof e === "string" ? e : (e?.message || String(e)));
    } finally {
      setImportLoading(false);
    }
  };

  // Parse whatever's in the textarea. Rust auto-detects the format so we
  // don't need three separate importers here.
  const parsePastedImport = async () => {
    setImportLoading(true);
    setImportError(null);
    setImportNotice(null);
    setImportHosts([]);
    setImportSelected(new Set());
    try {
      const hosts = await invoke<ImportedHost[]>("parse_client_import", { text: importPasteText });
      setImportHosts(hosts);
    } catch (e: any) {
      setImportError(typeof e === "string" ? e : (e?.message || String(e)));
    } finally {
      setImportLoading(false);
    }
  };

  const switchImportSource = async (next: "ssh" | "paste") => {
    if (importBusy || importSource === next) return;
    setImportSource(next);
    setImportError(null);
    setImportNotice(null);
    setImportHosts([]);
    setImportSelected(new Set());
    if (next === "ssh") {
      setImportLoading(true);
      try {
        const hosts = await invoke<ImportedHost[]>("parse_ssh_config", { path: null });
        setImportHosts(hosts);
      } catch (e: any) {
        setImportError(typeof e === "string" ? e : (e?.message || String(e)));
      } finally {
        setImportLoading(false);
      }
    }
  };

  const closeImportModal = () => {
    if (importBusy) return;
    setImportOpen(false);
    setImportError(null);
    setImportNotice(null);
    setImportHosts([]);
    setImportSelected(new Set());
    setImportPasteText("");
  };

  const toggleSelectAll = () => {
    if (importSelected.size === importHosts.length) {
      setImportSelected(new Set());
    } else {
      setImportSelected(new Set(importHosts.map((h) => h.host_alias)));
    }
  };

  const toggleOne = (alias: string) => {
    setImportSelected((prev) => {
      const next = new Set(prev);
      if (next.has(alias)) next.delete(alias);
      else next.add(alias);
      return next;
    });
  };

  // Fire one `add_server` per selected host. A host that named an IdentityFile
  // comes in key-authenticated; anything else lands as auth_type "custom_pass"
  // with no password — a valid row that won't connect until the user fills it
  // in. Errors per-host are surfaced but don't abort the batch; the modal
  // shows how many landed and how many failed.
  const importSelectedHosts = async () => {
    if (importSelected.size === 0 || importBusy) return;
    setImportBusy(true);
    setImportError(null);
    setImportNotice(null);
    let ok = 0;
    let failed = 0;
    let lastErr: string | null = null;
    // Several hosts routinely point at the same `~/.ssh/id_ed25519`. The Rust
    // side already dedupes by key content, but caching here means one read and
    // one vault write for the whole batch instead of one per host. `null`
    // records a path we already tried and couldn't use, so we don't retry a
    // missing file once per host that mentions it.
    const keysByPath = new Map<string, ImportedSshKey | null>();
    let keysAttached = 0;
    let keysNeedingPassphrase = 0;
    // Key files from this computer, going into a shared profile, would sync
    // to everyone it's shared with: ask first. The safe answer (Escape, or
    // the focused button) imports the hosts without them.
    const keyFiles = [
      ...new Set(importHosts.filter((h) => importSelected.has(h.host_alias) && h.identity_file).map((h) => h.identity_file as string)),
    ];
    let withKeys = true;
    if (keyFiles.length > 0) {
      const shared = await invoke<{ current: string | null }>("share_key_state")
        .then((s) => !!s.current)
        .catch(() => false);
      if (shared) {
        withKeys = await confirm({
          title: "Add your key files to a shared profile?",
          message:
            `This profile is shared. ${keyFiles.length === 1 ? "This private key" : "These private keys"} from this computer would go to everyone you share it with: ` +
            `${keyFiles.join(", ")}. Import the hosts with ${keyFiles.length === 1 ? "it" : "them"}, or without (you can pick keys for them later)?`,
          okLabel: "Import with keys",
          cancelLabel: "Without keys",
          safeDefault: true,
        });
      }
    }
    for (const host of importHosts) {
      if (!importSelected.has(host.host_alias)) continue;
      let key: ImportedSshKey | null = null;
      if (host.identity_file && withKeys) {
        if (keysByPath.has(host.identity_file)) {
          key = keysByPath.get(host.identity_file) ?? null;
        } else {
          try {
            key = await invoke<ImportedSshKey>("import_ssh_key_file", {
              path: host.identity_file,
              name: null,
            });
          } catch {
            // An unreadable IdentityFile isn't a reason to skip the host —
            // the server row is still worth having. It just imports
            // password-less, exactly as it did before keys were attached.
            key = null;
          }
          keysByPath.set(host.identity_file, key);
          if (key) {
            keysAttached++;
            if (key.encrypted) keysNeedingPassphrase++;
          }
        }
      }
      try {
        await invoke<number>("add_server", {
          name: host.host_alias,
          host: host.hostname || host.host_alias,
          port: host.port || 22,
          // No user in the export (MobaXterm's <default>, an ssh_config
          // entry without User): leave it blank, so connecting asks
          // "Login as" — where empty still means root (#72).
          username: host.user ? host.user.trim() : "",
          password: null,
          credentialId: null,
          folderId: null,
          proxyType: "none",
          proxyHost: "",
          proxyPort: 1080,
          tunnels: [],
          authType: key ? "custom_key" : "custom_pass",
          keyId: key ? key.id : null,
          autostart: false,
          mirrors: [],
          color: null,
        });
        ok++;
      } catch (e: any) {
        failed++;
        lastErr = typeof e === "string" ? e : (e?.message || String(e));
      }
    }
    setImportBusy(false);
    if (failed > 0) {
      setImportError(`${ok} imported, ${failed} failed${lastErr ? `: ${lastErr}` : ""}`);
    }
    if (refreshServers) {
      try { await refreshServers(); } catch { /* refresh failure isn't fatal */ }
    }
    if (keysAttached > 0 && refreshSshKeys) {
      try { await refreshSshKeys(); } catch { /* same — the list refreshes on next open */ }
    }
    // A passphrase-protected key's passphrase isn't anywhere in the config
    // file. The user can add it under Settings › SSH keys, or leave it and be
    // asked at connect time (issue #30) — either way, hold the modal open and
    // point it out so the import isn't silently half-finished.
    if (keysNeedingPassphrase > 0) {
      setImportNotice(
        `${ok} imported, ${keysAttached} SSH key${keysAttached === 1 ? "" : "s"} attached. ` +
        `其中 ${keysNeedingPassphrase} 个需要口令——请在「设置 › SSH 密钥」中填写，或留空以在连接时询问。`,
      );
      return;
    }
    if (failed === 0) {
      closeImportModal();
    }
  };

  // Browse to a key on disk and select it on this server in one step. The key
  // goes into the vault (deduped by content) rather than being referenced by
  // path — the vault is what syncs and what gets exported, so a server that
  // works here has to keep working on a machine where ~/.ssh looks different.
  const browseForKey = async () => {
    if (keyBrowseBusy) return;
    setKeyBrowseBusy(true);
    setKeyBrowseNote(null);
    try {
      const path = await invoke<string | null>("pick_ssh_key_file");
      if (!path) return;
      const key = await invoke<ImportedSshKey>("import_ssh_key_file", { path, name: null });
      if (refreshSshKeys) await refreshSshKeys();
      setNewNode({ ...newNode, keyId: key.id.toString() });
      setKeyBrowseNote(
        key.encrypted
          ? `Loaded "${key.name}" — it's passphrase-protected. Add the passphrase under Settings › SSH keys, or leave it empty to be asked when connecting.`
          : key.reused
            ? `"${key.name}" was already in your vault — selected it.`
            : `Loaded "${key.name}" into your vault.`,
      );
    } catch (e: any) {
      setKeyBrowseNote(typeof e === "string" ? e : (e?.message || String(e)));
    } finally {
      setKeyBrowseBusy(false);
    }
  };

  // Make a new key without leaving the form (#23): the same Ed25519 key the
  // SSH keys page generates, selected on this server straight away.
  const generateKey = async () => {
    if (keyBrowseBusy) return;
    const suggested = `${String(newNode.name || newNode.host || "server").trim()}-key`;
    const name = await textPrompt({
      title: "Generate SSH key",
      message: "Give this key a name — it's just for your reference here in Submarine.",
      initialValue: suggested,
      okLabel: "Generate",
      validate: (v) => v.length === 0 ? "Name is required" : null,
    });
    if (!name) return;
    setKeyBrowseBusy(true);
    setKeyBrowseNote(null);
    setGeneratedKey(null);
    try {
      const key = await invoke<{ id: number; public_key: string }>("generate_ssh_key", { name });
      if (refreshSshKeys) await refreshSshKeys();
      setNewNode({ ...newNode, keyId: key.id.toString() });
      setGeneratedKey({ id: key.id, name, publicKey: key.public_key });
      setPublicKeyCopied(false);
    } catch (e: any) {
      setKeyBrowseNote(typeof e === "string" ? e : (e?.message || String(e)));
    } finally {
      setKeyBrowseBusy(false);
    }
  };

  const copyPublicKey = async () => {
    if (!generatedKey) return;
    try {
      await navigator.clipboard.writeText(generatedKey.publicKey);
      setPublicKeyCopied(true);
    } catch {
      setKeyBrowseNote("Couldn't copy — select the key text and copy it by hand.");
    }
  };

  const handleCreateFolder = async () => {
    if (!newFolderName.trim()) return;
    try {
      await invoke("add_folder", { name: newFolderName, parentId: null });
      setNewFolderName("");
      setIsCreatingFolder(false);
      refreshFolders();
    } catch (e) {
      console.error(e);
    }
  };

  const updateTunnel = (idx: number, field: string, value: string | boolean) => {
    const newT = [...newNode.tunnels];
    newT[idx][field] = value;
    setNewNode({ ...newNode, tunnels: newT });
  };

  return (
    // Mounted while closed too (to slide out): inert then, so Tab can't reach
    // its fields.
    <div inert={isOpen ? undefined : ""} className={`fixed inset-0 z-50 transition-all duration-500 flex justify-end ${isOpen ? 'bg-black/60 backdrop-blur-sm' : 'opacity-0 pointer-events-none'}`} onClick={onClose}>
      <div ref={panelRef} tabIndex={-1} className={`w-full ${isMobile ? 'max-w-full' : 'max-w-[450px]'} bg-background border-l border-white/5 shadow-2xl transition-all duration-500 h-full flex flex-col outline-none ${isOpen ? 'translate-x-0' : 'translate-x-full'}`} onClick={(e) => e.stopPropagation()}>

        {/* Header */}
        <div className="flex justify-between items-center p-6 border-b border-white/5 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center text-primary shadow-inner border border-primary/20">
              <Cpu size={16} />
            </div>
            <h2 className="text-[14px] font-bold text-white tracking-tight">服务器详情</h2>
          </div>
          <div className="flex items-center gap-2">
            {/* Import only makes sense when creating a fresh row — editing an
                existing server is a rename/reconfigure flow, not an import.
                Available on Android now that the modal supports a "Paste
                PuTTY / MobaXterm / JSON" source that doesn't need a local
                ~/.ssh/config. The SSH-config tab still errors gracefully
                there — the user just picks the paste tab. */}
            {!isEditMode && (
              <button
                onClick={openImportModal}
                title="从 ~/.ssh/config 导入"
                className="h-8 px-2.5 flex items-center gap-1.5 text-[11px] font-bold text-primary bg-primary/10 border border-primary/30 hover:bg-primary/20 rounded-xl transition-all"
              >
                <Download size={12} />
                <span className="hidden sm:inline">Import from ~/.ssh/config</span>
                <span className="sm:hidden">导入</span>
              </button>
            )}
            <button aria-label="Close" onClick={onClose} className="w-8 h-8 flex items-center justify-center text-zinc-500 hover:text-white bg-black border border-white/5 hover:bg-white/10 rounded-xl transition-all shadow-inner">
              <X size={16} />
            </button>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="p-6 flex-1 overflow-y-auto custom-scrollbar space-y-6">
          {formError && <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-xl text-red-500 text-[12px] font-bold">{formError}</div>}

          <div className="grid grid-cols-1 gap-4">
            <div className="space-y-1.5">
              <label className="text-[11px] font-bold text-zinc-400 ml-1">名称</label>
              <input type="text" className="w-full h-9 bg-[#1a1a1e] rounded-lg px-3 text-[12px] text-white border border-white/10 outline-none focus:border-primary/50 focus:bg-[#232328] transition-all shadow-inner" placeholder="e.g. Work server" value={newNode.name} onChange={e => setNewNode({ ...newNode, name: e.target.value })} />
            </div>

            <div className="space-y-1.5">
              <label className="text-[11px] font-bold text-zinc-400 ml-1">文件夹</label>
              {!isCreatingFolder ? (
                <div className="flex gap-2">
                  <select className="flex-1 h-9 bg-[#1a1a1e] rounded-lg px-3 text-[12px] text-white border border-white/10 outline-none focus:border-primary/50 focus:bg-[#232328] transition-all shadow-inner" value={newNode.folderId} onChange={e => setNewNode({ ...newNode, folderId: e.target.value })}>
                    <option value="" className="bg-[#1a1a1e] text-zinc-500">-- Root --</option>
                    {folders?.map((f: any) => <option key={f.id} value={f.id.toString()} className="bg-[#1a1a1e] text-white">{f.name}</option>)}
                  </select>
                  <button aria-label="New folder" onClick={() => setIsCreatingFolder(true)} className="w-9 h-9 bg-white/5 border border-white/10 rounded-lg text-primary hover:bg-white/10 transition-all flex items-center justify-center shrink-0">
                    <FolderPlus size={14} />
                  </button>
                </div>
              ) : (
                <div className="flex gap-2 animate-in fade-in">
                  <input type="text" className="flex-1 h-9 bg-[#1a1a1e] rounded-lg px-3 text-[12px] text-white border border-white/10 outline-none focus:border-primary/50 transition-all shadow-inner" placeholder="文件夹名称…" value={newFolderName} onChange={e => setNewFolderName(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleCreateFolder()} />
                  <button onClick={handleCreateFolder} className="h-9 px-3 bg-primary text-black font-bold text-[12px] rounded-lg hover:bg-primary transition-all">添加</button>
                  <button aria-label="Cancel" onClick={() => setIsCreatingFolder(false)} className="w-9 h-9 bg-white/5 text-zinc-400 rounded-lg hover:bg-white/10 transition-all flex justify-center items-center shrink-0"><X size={14} /></button>
                </div>
              )}
            </div>

            <div className="space-y-1.5">
              <label className="text-[11px] font-bold text-zinc-400 ml-1">标签颜色</label>
              <div className="flex items-center gap-2 flex-wrap">
                {[
                  { name: "Default", value: null,      cls: "bg-zinc-500" },
                  { name: "Rose",    value: "#f43f5e", cls: "bg-rose-500" },
                  { name: "Amber",   value: "#f59e0b", cls: "bg-amber-500" },
                  { name: "Emerald", value: "#10b981", cls: "bg-emerald-500" },
                  { name: "Sky",     value: "#0ea5e9", cls: "bg-sky-500" },
                  { name: "Indigo",  value: "#6366f1", cls: "bg-indigo-500" },
                  { name: "Fuchsia", value: "#d946ef", cls: "bg-fuchsia-500" },
                  { name: "Slate",   value: "#64748b", cls: "bg-slate-500" },
                ].map((p) => {
                  const selected = (newNode.color ?? null) === p.value;
                  return (
                    <button
                      key={p.name}
                      type="button"
                      title={p.name}
                      onClick={() => setNewNode({ ...newNode, color: p.value })}
                      className={`w-6 h-6 rounded-full ${p.cls} ring-2 ring-transparent hover:ring-white/30 transition-all ${selected ? "ring-white" : ""}`}
                    />
                  );
                })}
              </div>
            </div>

            <div className="grid grid-cols-4 gap-4">
              <div className="col-span-3 space-y-1.5">
                <label className="text-[11px] font-bold text-zinc-400 ml-1">主机</label>
                <input type="text" className="w-full h-9 bg-[#1a1a1e] rounded-lg px-3 text-[12px] text-white border border-white/10 outline-none focus:border-primary/50 focus:bg-[#232328] transition-all shadow-inner" placeholder="192.168.1.1 or example.com" value={newNode.host} onChange={e => setNewNode({ ...newNode, host: e.target.value })} />
              </div>
              <div className="space-y-1.5">
                <label className="text-[11px] font-bold text-zinc-400 ml-1">端口</label>
                <input type="number" className="w-full h-9 bg-[#1a1a1e] rounded-lg px-3 text-[12px] text-white border border-white/10 outline-none focus:border-primary/50 focus:bg-[#232328] transition-all shadow-inner" value={newNode.port} onChange={e => setNewNode({ ...newNode, port: parseInt(e.target.value) })} />
              </div>
            </div>

          </div>

          <div className="pt-5 border-t border-white/5 space-y-4">
            <div className="flex justify-between items-center">
              <label className="text-[11px] font-bold text-zinc-400">如何登录</label>
              <select
                className="bg-transparent text-[12px] font-bold text-primary outline-none cursor-pointer"
                value={newNode.authType}
                onChange={(e) => setNewNode({ ...newNode, authType: e.target.value })}
              >
                <option value="vault" className="bg-[#121215] text-primary">使用已保存的登录凭据</option>
                <option value="custom_pass" className="bg-[#121215] text-primary">输入密码</option>
                <option value="custom_key" className="bg-[#121215] text-primary">使用 SSH 密钥</option>
              </select>
            </div>

            {newNode.authType === 'vault' && (() => {
              const selectedCred = credentials?.find((c: any) => c.id?.toString() === newNode.credentialId?.toString());
              return (
                <div className="space-y-3 animate-in fade-in slide-in-from-top-1">
                  <div className="space-y-1.5">
                    <label className="text-[11px] font-bold text-zinc-400 ml-1">已保存的登录凭据</label>
                    <select className="w-full h-9 bg-[#1a1a1e] rounded-lg px-3 text-[12px] text-zinc-300 border border-white/10 outline-none focus:border-primary/50 transition-all shadow-inner" value={newNode.credentialId} onChange={e => setNewNode({ ...newNode, credentialId: e.target.value })}>
                      <option value="" className="bg-[#1a1a1e] text-zinc-500">-- Pick one --</option>
                      {credentials?.map((c: any) => <option key={c.id} value={c.id.toString()} className="bg-[#1a1a1e] text-zinc-300">{c.name} ({c.username})</option>)}
                    </select>
                  </div>
                  {selectedCred && (
                    <div className="px-3 py-2 bg-primary/5 border border-primary/20 rounded-lg text-[11px] font-mono text-zinc-300 flex items-center gap-2">
                      <User size={11} className="text-primary shrink-0" />
                      <span className="text-zinc-500">以…身份登录</span>
                      <span className="text-primary font-bold">{selectedCred.username || "—"}</span>
                      <span className="text-zinc-600 ml-auto text-[10px]">{selectedCred.auth_type === 'key' ? '使用密钥' : '使用密码'}</span>
                    </div>
                  )}
                </div>
              );
            })()}

            {newNode.authType === 'custom_pass' && (
              <div className="space-y-3 animate-in fade-in">
                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-zinc-400 ml-1">用户名</label>
                  <input type="text" placeholder="连接时询问" value={newNode.username || ""} onChange={e => setNewNode({ ...newNode, username: e.target.value })} className="w-full h-9 bg-[#1a1a1e] rounded-lg px-3 text-[12px] text-white border border-white/10 outline-none focus:border-primary/50 transition-all shadow-inner" />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-zinc-400 ml-1">密码</label>
                  <PasswordField
                    value={newNode.password || ""}
                    onChange={(v) => setNewNode({ ...newNode, password: v, password_dirty: true })}
                    className="w-full h-9 bg-[#1a1a1e] rounded-lg px-3 text-[12px] text-white border border-white/10 outline-none focus:border-primary/50 transition-all shadow-inner"
                    placeholder="••••••"
                  />
                  <p className="text-[10px] text-zinc-500 ml-1">留空则在连接时询问。</p>
                </div>
              </div>
            )}

            {newNode.authType === 'custom_key' && (
              <div className="space-y-3 animate-in fade-in">
                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-zinc-400 ml-1">用户名</label>
                  <input type="text" placeholder="连接时询问" value={newNode.username || ""} onChange={e => setNewNode({ ...newNode, username: e.target.value })} className="w-full h-9 bg-[#1a1a1e] rounded-lg px-3 text-[12px] text-white border border-white/10 outline-none focus:border-primary/50 transition-all shadow-inner" />
                </div>
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between ml-1">
                    <label className="text-[11px] font-bold text-zinc-400">SSH 密钥</label>
                    {/* Loading a key from disk is the common case for someone
                        moving over from the `ssh` command line — the key is
                        already in ~/.ssh and copy-pasting it out of a terminal
                        is the worst part of setting up a first server. */}
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={generateKey}
                        disabled={keyBrowseBusy}
                        title="新建一个 SSH 密钥并用于此服务器"
                        className="h-6 px-2 flex items-center gap-1 text-[10px] font-bold text-primary bg-primary/10 border border-primary/30 hover:bg-primary/20 disabled:opacity-40 disabled:cursor-not-allowed rounded-lg transition-all"
                      >
                        <Plus size={10} />
                        生成
                      </button>
                      <button
                        type="button"
                        onClick={browseForKey}
                        disabled={keyBrowseBusy}
                        className="h-6 px-2 flex items-center gap-1 text-[10px] font-bold text-primary bg-primary/10 border border-primary/30 hover:bg-primary/20 disabled:opacity-40 disabled:cursor-not-allowed rounded-lg transition-all"
                      >
                        <Key size={10} />
                        {keyBrowseBusy ? "加载中…" : "从文件加载"}
                      </button>
                    </div>
                  </div>
                  <select className="w-full h-9 bg-[#1a1a1e] rounded-lg px-3 text-[12px] text-zinc-300 border border-white/10 outline-none focus:border-primary/50 transition-all shadow-inner" value={newNode.keyId} onChange={e => setNewNode({ ...newNode, keyId: e.target.value })}>
                    <option value="" className="bg-[#1a1a1e] text-zinc-500">-- Pick a key --</option>
                    {sshKeys?.map((k: any) => <option key={k.id} value={k.id.toString()} className="bg-[#1a1a1e] text-zinc-300">{k.name}</option>)}
                  </select>
                  {keyBrowseNote && (
                    <div className="p-2 bg-white/5 border border-white/10 rounded-lg text-[11px] text-zinc-400 break-words">
                      {keyBrowseNote}
                    </div>
                  )}
                  {generatedKey && newNode.keyId === generatedKey.id.toString() && (
                    <div className="p-2 bg-white/5 border border-white/10 rounded-lg text-[11px] text-zinc-400 space-y-1.5">
                      <div>
                        Generated "{generatedKey.name}" and picked it for this server. Add its public key to
                        {" "}<code className="text-zinc-300">~/.ssh/authorized_keys</code> on the server before connecting:
                      </div>
                      <code className="block p-1.5 bg-black/40 rounded text-[10.5px] text-zinc-300 font-mono break-all select-text">
                        {generatedKey.publicKey}
                      </code>
                      <button
                        type="button"
                        onClick={copyPublicKey}
                        className="h-6 px-2 flex items-center gap-1 text-[10px] font-bold text-primary bg-primary/10 border border-primary/30 hover:bg-primary/20 rounded-lg transition-all"
                      >
                        <Copy size={10} />
                        {publicKeyCopied ? "已复制" : "复制公钥"}
                      </button>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          <div className="pt-5 border-t border-white/5 space-y-4">
            <div className="flex justify-between items-center">
              <label className="text-[11px] font-bold text-zinc-400">代理</label>
              <select className="bg-transparent text-[12px] font-bold text-zinc-300 outline-none cursor-pointer" value={newNode.proxyType} onChange={e => setNewNode({ ...newNode, proxyType: e.target.value })}>
                <option value="none" className="bg-[#121215] text-zinc-400">无代理</option>
                <option value="socks5" className="bg-[#121215] text-zinc-400">SOCKS5</option>
                <option value="http" className="bg-[#121215] text-zinc-400">HTTP</option>
              </select>
            </div>

            {newNode.proxyType !== 'none' && (
              <div className="grid grid-cols-4 gap-3 animate-in fade-in">
                <input
                  className="col-span-3 h-9 bg-[#1a1a1e] rounded-lg px-3 text-[12px] text-white border border-white/10 outline-none focus:border-primary/50 transition-all shadow-inner"
                  placeholder="代理主机"
                  value={newNode.proxyHost || ""}
                  onChange={e => setNewNode({ ...newNode, proxyHost: e.target.value })}
                />
                <input
                  type="number"
                  className="h-9 bg-[#1a1a1e] rounded-lg px-3 text-[12px] text-white border border-white/10 outline-none focus:border-primary/50 transition-all shadow-inner"
                  placeholder="端口"
                  value={newNode.proxyPort || ""}
                  onChange={e => setNewNode({ ...newNode, proxyPort: parseInt(e.target.value) || 0 })}
                />
              </div>
            )}

            {/* ProxyJump — bounce through another saved node to reach this one
                (like `ssh -J bastion target`). Distinct from the SOCKS/HTTP
                proxy above: that's a plain TCP proxy, this is a full SSH hop
                that opens a direct-tcpip channel to the target. Self is filtered
                out so a node can't jump through itself. */}
            <div className="flex justify-between items-center gap-3">
              <label className="text-[11px] font-bold text-zinc-400 shrink-0">经由跳板</label>
              <select
                className="flex-1 min-w-0 h-9 bg-[#1a1a1e] rounded-lg px-3 text-[12px] text-zinc-300 border border-white/10 outline-none focus:border-primary/50 focus:bg-[#232328] transition-all shadow-inner"
                value={newNode.jumpHostId || ""}
                onChange={e => setNewNode({ ...newNode, jumpHostId: e.target.value })}
              >
                <option value="" className="bg-[#1a1a1e] text-zinc-500">直连——无跳板机</option>
                {(servers || [])
                  .filter((s: any) => s.id !== newNode.id)
                  .map((s: any) => (
                    <option key={s.id} value={s.id.toString()} className="bg-[#1a1a1e] text-zinc-300">
                      {s.name} ({s.host})
                    </option>
                  ))}
              </select>
            </div>

            <div className="space-y-2.5">
              <div className="flex justify-between items-center">
                <span className="text-[11px] font-bold text-zinc-400">端口转发</span>
                <button onClick={() => setNewNode({ ...newNode, tunnels: [...newNode.tunnels, { rid: `t-${Date.now()}-${Math.random().toString(36).slice(2,7)}`, local: "1080", remote: "", type: "D" }] })} className="text-[11px] font-bold text-primary hover:text-primary transition-colors">+ Add</button>
              </div>

              <div className="space-y-2">
                {newNode.tunnels?.map((t: any, idx: number) => (
                  // `rid` is a stable per-row id added on Add. Falling
                  // back to idx for legacy rows that lack it; new rows
                  // always carry rid so deletions / reorders preserve
                  // each input's focus and cursor state.
                  <div key={t.rid ?? idx} className="p-2 bg-[#1a1a1e] rounded-lg border border-white/5 group transition-all hover:border-primary/30 space-y-1.5">
                    <div className="flex items-center gap-2">
                      <select
                        className="bg-transparent text-[11px] font-black outline-none text-primary uppercase tracking-wider cursor-pointer pl-1"
                        value={t.type}
                        onChange={e => updateTunnel(idx, 'type', e.target.value)}
                      >
                        <option value="D" className="bg-[#1a1a1e] text-primary">动态</option>
                        <option value="L" className="bg-[#1a1a1e] text-primary">本地</option>
                        <option value="R" className="bg-[#1a1a1e] text-primary">远程</option>
                      </select>

                      <div className="h-4 w-px bg-white/10 mx-1" />

                      <input
                        className="flex-1 min-w-0 bg-transparent text-[12px] font-mono outline-none text-zinc-300 placeholder:text-zinc-700"
                        placeholder={
                          t.type === 'D' ? "端口（1080）" :
                          t.type === 'R' ? "服务端监听地址（8080 或 0.0.0.0:8080）" :
                                           "本地（8080 或 0.0.0.0:8080）"
                        }
                        value={t.local}
                        onChange={e => updateTunnel(idx, 'local', e.target.value)}
                      />

                      {t.type !== 'D' && (
                        <>
                          <ArrowLeftRight size={10} className="text-zinc-700 shrink-0 mx-1" />
                          <input
                            className="flex-1 min-w-0 bg-transparent text-[12px] font-mono outline-none text-primary placeholder:text-zinc-700"
                            placeholder="远程（80）"
                            value={t.remote}
                            onChange={e => updateTunnel(idx, 'remote', e.target.value)}
                          />
                        </>
                      )}

                      <button aria-label="Remove this forward" onClick={() => setNewNode({ ...newNode, tunnels: newNode.tunnels.filter((_: any, i: number) => i !== idx) })} className="opacity-100 sm:opacity-0 sm:group-hover:opacity-100 sm:focus-visible:opacity-100 w-6 h-6 flex items-center justify-center text-red-500 hover:bg-red-500/10 rounded transition-all shrink-0">
                        <X size={12} />
                      </button>
                    </div>
                    {/* Its name, and whether it starts with the connection: a
                        forward stopped in the Ports panel stays here, stopped. */}
                    <div className="flex items-center gap-2 pl-1">
                      <input
                        className="flex-1 min-w-0 bg-transparent text-[11px] outline-none text-zinc-300 placeholder:text-zinc-700"
                        placeholder="名称（可选）"
                        aria-label="Forward name"
                        maxLength={64}
                        value={t.name ?? ""}
                        onChange={e => updateTunnel(idx, 'name', e.target.value)}
                      />
                      <button
                        type="button"
                        onClick={() => updateTunnel(idx, 'stopped', !t.stopped)}
                        title={t.stopped
                          ? "已保留，但不会随连接启动。点击以设为随连接启动。"
                          : "已随连接启动。点击可设为保持停止。"}
                        className={`h-5 px-1.5 rounded text-[10px] font-bold uppercase tracking-wider flex items-center gap-1 shrink-0 transition-colors ${
                          t.stopped
                            ? "text-zinc-500 bg-white/5 hover:text-zinc-300"
                            : "text-emerald-400 bg-emerald-500/10 hover:bg-emerald-500/20"
                        }`}
                      >
                        {t.stopped ? <Square size={9} /> : <Play size={9} fill="currentColor" />}
                        {t.stopped ? "已停止" : "连接时"}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Folder mirrors saved on this node — one-way local → remote
                sync. Stored alongside tunnels so they roam with the vault.
                Live management (start / stop / log) lives in the Mirror
                panel inside an open session. */}
            <div className="space-y-2.5">
              <div className="flex justify-between items-center">
                <span className="text-[11px] font-bold text-zinc-400">文件夹镜像</span>
                <button
                  type="button"
                  onClick={() => setNewNode({
                    ...newNode,
                    mirrors: [...(newNode.mirrors || []), { local: "", remote: "", soft_delete: true, excludes: [], conflict_resolution: "local" }],
                  })}
                  className="text-[11px] font-bold text-primary hover:text-primary transition-colors"
                >+ Add</button>
              </div>
              <div className="space-y-2">
                {(newNode.mirrors || []).map((m: any, idx: number) => (
                  <div key={idx} className="p-2.5 bg-[#1a1a1e] rounded-lg border border-white/5 group space-y-1.5">
                    <div className="flex items-center gap-2">
                      <input
                        className="flex-1 min-w-0 h-7 bg-black/40 rounded px-2 text-[11.5px] font-mono text-zinc-200 border border-white/10 outline-none focus:border-primary/50"
                        placeholder="/local/path"
                        value={m.local}
                        onChange={(e) => {
                          const next = [...newNode.mirrors];
                          next[idx] = { ...next[idx], local: e.target.value };
                          setNewNode({ ...newNode, mirrors: next });
                        }}
                      />
                      <ArrowLeftRight size={10} className="text-zinc-700 shrink-0 mx-1" />
                      <input
                        className="flex-1 min-w-0 h-7 bg-black/40 rounded px-2 text-[11.5px] font-mono text-zinc-200 border border-white/10 outline-none focus:border-primary/50"
                        placeholder="/remote/path"
                        value={m.remote}
                        onChange={(e) => {
                          const next = [...newNode.mirrors];
                          next[idx] = { ...next[idx], remote: e.target.value };
                          setNewNode({ ...newNode, mirrors: next });
                        }}
                      />
                      <button aria-label="Remove this mirror"
                        type="button"
                        onClick={() => setNewNode({ ...newNode, mirrors: newNode.mirrors.filter((_: any, i: number) => i !== idx) })}
                        className="opacity-100 sm:opacity-0 sm:group-hover:opacity-100 sm:focus-visible:opacity-100 w-6 h-6 flex items-center justify-center text-red-500 hover:bg-red-500/10 rounded transition-all shrink-0"
                      >
                        <X size={12} />
                      </button>
                    </div>
                    <div className="flex items-center gap-3 pl-1">
                      <label className="flex items-center gap-1.5 text-[10.5px] text-zinc-400 select-none cursor-pointer">
                        <input
                          type="checkbox"
                          checked={m.soft_delete !== false}
                          onChange={(e) => {
                            const next = [...newNode.mirrors];
                            next[idx] = { ...next[idx], soft_delete: e.target.checked };
                            setNewNode({ ...newNode, mirrors: next });
                          }}
                          className="accent-primary"
                        />
                        <span>软删除</span>
                      </label>
                      <select
                        value={m.conflict_resolution || "local"}
                        onChange={(e) => {
                          const next = [...newNode.mirrors];
                          next[idx] = { ...next[idx], conflict_resolution: e.target.value };
                          setNewNode({ ...newNode, mirrors: next });
                        }}
                        title="初始同步的冲突处理：当文件两边都存在且内容不同时，由哪一边覆盖。只在一边存在的文件始终会被复制过去。"
                        className="h-6 px-1.5 bg-black/30 border border-white/10 rounded text-[10.5px] text-zinc-300 outline-none focus:border-primary/40"
                      >
                        <option value="local">本地优先</option>
                        <option value="remote">远程优先</option>
                        <option value="newer">较新者优先</option>
                      </select>
                      <input
                        className="flex-1 min-w-0 h-6 bg-transparent rounded px-1 text-[10.5px] font-mono text-zinc-400 placeholder:text-zinc-700 outline-none"
                        placeholder="排除：.git、node_modules、*.swp"
                        value={(m.excludes || []).join(", ")}
                        onChange={(e) => {
                          const parts = e.target.value.split(",").map((s) => s.trim()).filter(Boolean);
                          const next = [...newNode.mirrors];
                          next[idx] = { ...next[idx], excludes: parts };
                          setNewNode({ ...newNode, mirrors: next });
                        }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Autostart toggle — when on, the node opens a session and
                connects automatically right after the user unlocks the
                profile. Useful for the one or two servers you always have
                a shell on. */}
            <div className="flex items-center justify-between gap-3 pt-1">
              <div className="min-w-0">
                <div className="text-[11px] font-bold text-zinc-300">Autostart</div>
                <div className="text-[10.5px] text-zinc-500 leading-snug">
                  应用启动时自动打开并连接此服务器。
                </div>
              </div>
              <button
                type="button"
                onClick={() => setNewNode({ ...newNode, autostart: !newNode.autostart })}
                role="switch"
                aria-label="Autostart"
                aria-checked={!!newNode.autostart}
                className={`relative shrink-0 w-11 h-6 rounded-full transition-colors ${
                  newNode.autostart ? "bg-primary" : "bg-white/10"
                }`}
              >
                <span
                  className={`absolute top-0.5 left-0.5 w-5 h-5 bg-zinc-100 rounded-full shadow transition-transform ${
                    newNode.autostart ? "translate-x-5" : "translate-x-0"
                  }`}
                />
              </button>
            </div>

            {/* Per-node notes — free-form, plain text. Lives on the server
                row (servers.notes column) and never crosses the network. The
                primary use case is small runbooks: which user owns root,
                where the deploy script lives, contact for the box, etc. */}
            <div className="space-y-1.5 pt-1">
              <label className="text-[11px] font-bold text-zinc-400 ml-1 flex items-center gap-2">
                <span>备注</span>
                <span className="text-[10px] text-zinc-600 font-normal normal-case tracking-normal">
                  描述、运维手册、联系人——仅适用于此服务器。
                </span>
              </label>
              <textarea
                value={newNode.notes || ""}
                onChange={(e) => setNewNode({ ...newNode, notes: e.target.value })}
                placeholder="e.g. Prod web. Reboot windows Sun 04:00 UTC. Deploy via `make ship`. Pager: @ops"
                rows={6}
                className="w-full bg-[#1a1a1e] rounded-lg p-3 text-[12px] text-white border border-white/10 outline-none focus:border-primary/50 focus:bg-[#232328] transition-all shadow-inner font-mono leading-relaxed resize-y"
              />
              {/* Attribution — who last changed this node and when. Populated by
                  the sync layer; most useful on shared / multi-device profiles. */}
              {isEditMode && (newNode.updatedAt || newNode.editedBy) && (() => {
                const when = hlcTime(newNode.updatedAt);
                return (
                  <div className="flex items-center gap-1.5 text-[11px] text-zinc-500 ml-1 pt-0.5">
                    <History size={11} className="text-zinc-600 shrink-0" />
                    <span>
                      Last edited{when ? ` ${relTime(when)}` : ""}
                      {newNode.editedBy ? <> 由 <span className="text-zinc-300 font-medium">{newNode.editedBy}</span></> : ""}
                      {when && <span className="text-zinc-600" title={when.toLocaleString()}> · {when.toLocaleDateString()}</span>}
                    </span>
                  </div>
                );
              })()}
            </div>

            {/* On-connect commands — auto-typed into the FIRST terminal the
                first time you connect to this server (not on reconnects, not
                on extra shells you open later). One command per line. */}
            <div className="space-y-1.5 pt-1">
              <label className="text-[11px] font-bold text-zinc-400 ml-1 flex items-center gap-2">
                <span>连接时运行</span>
                <span className="text-[10px] text-zinc-600 font-normal normal-case tracking-normal">
                  命令会在第一个终端上自动执行一次。每行一条。
                </span>
              </label>
              <textarea
                value={newNode.runOnConnect || ""}
                onChange={(e) => setNewNode({ ...newNode, runOnConnect: e.target.value })}
                placeholder={"e.g.\ncd /var/www\nsource .venv/bin/activate\ntail -f storage/logs/app.log"}
                rows={4}
                spellCheck={false}
                className="w-full bg-[#1a1a1e] rounded-lg p-3 text-[12px] text-white border border-white/10 outline-none focus:border-primary/50 focus:bg-[#232328] transition-all shadow-inner font-mono leading-relaxed resize-y"
              />
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-white/5 shrink-0">
          <button onClick={onSave} className="w-full h-10 bg-primary text-black font-bold rounded-lg text-[13px] tracking-tight hover:bg-primary hover:shadow-[0_0_20px_rgba(var(--primary),0.3)] transition-all active:scale-[0.98] flex items-center justify-center gap-2">
            <Cpu size={14} /> {isEditMode ? "保存更改" : "保存服务器"}
          </button>
        </div>
      </div>

      {/* SSH-config import modal. Portaled to <body> so it overlays the
          Add Server panel cleanly and isn't clipped by the panel's flex
          layout. Click-outside on the backdrop dismisses; the panel itself
          stops propagation so clicks inside don't close it. */}
      {importOpen && createPortal(
        <div
          className="fixed inset-0 z-[10000] bg-black/70 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={closeImportModal}
        >
          <div
            role="dialog"
            aria-modal="true"
            aria-labelledby="ssh-import-title"
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-[520px] max-h-[80vh] flex flex-col bg-[#121214] border border-white/10 rounded-xl shadow-2xl animate-in zoom-in-95 fade-in duration-150"
          >
            {/* Modal header */}
            <div className="flex items-center justify-between p-4 border-b border-white/5 shrink-0">
              <div className="flex items-center gap-2">
                <Download size={14} className="text-primary" />
                <h3 id="ssh-import-title" className="text-[12px] font-black uppercase tracking-widest text-zinc-100">
                  导入 SSH 主机
                </h3>
              </div>
              <button aria-label="Close"
                onClick={closeImportModal}
                disabled={importBusy}
                className="w-7 h-7 flex items-center justify-center text-zinc-500 hover:text-white bg-white/[0.04] border border-white/10 hover:bg-white/10 rounded-lg transition-all disabled:opacity-40 disabled:cursor-not-allowed"
              >
                <X size={12} />
              </button>
            </div>

            {/* Source selector — two ways to feed hosts in:
                    ssh    → parse the local OpenSSH config (desktop only)
                    paste  → drop text from PuTTY, MobaXterm, or a JSON
                             export; Rust auto-detects the format so the
                             user doesn't need to say which client it came
                             from. */}
            <div className="px-4 py-2 border-b border-white/5 flex items-center gap-1 shrink-0">
              <button
                onClick={() => switchImportSource("ssh")}
                disabled={importBusy}
                className={`h-7 px-3 rounded-lg text-[10.5px] font-bold uppercase tracking-wider transition-all ${
                  importSource === "ssh"
                    ? "bg-primary/10 text-primary border border-primary/30"
                    : "text-zinc-400 border border-white/5 hover:text-white hover:bg-white/[0.04]"
                }`}
              >
                从 ~/.ssh/config
              </button>
              <button
                onClick={() => switchImportSource("paste")}
                disabled={importBusy}
                className={`h-7 px-3 rounded-lg text-[10.5px] font-bold uppercase tracking-wider transition-all ${
                  importSource === "paste"
                    ? "bg-primary/10 text-primary border border-primary/30"
                    : "text-zinc-400 border border-white/5 hover:text-white hover:bg-white/[0.04]"
                }`}
              >
                粘贴 PuTTY / MobaXterm / JSON
              </button>
            </div>

            {/* Body — one of loading / error / empty / list. */}
            <div className="flex-1 overflow-y-auto custom-scrollbar p-3">
              {importSource === "paste" && importHosts.length === 0 && !importLoading && (
                <div className="space-y-2 mb-2">
                  <div className="text-[11px] text-zinc-400 leading-relaxed px-1">
                    Paste an export from another SSH client. Recognised sources:
                    <ul className="mt-1.5 ml-4 list-disc space-y-0.5 text-zinc-500 text-[10.5px]">
                      <li><b className="text-zinc-300">PuTTY</b> — export via <code className="text-zinc-300">regedit /e ... HKCU\Software\SimonTatham\PuTTY\Sessions</code>, open the .reg file, paste its contents.</li>
                      <li><b className="text-zinc-300">MobaXterm</b> — Export sessions → open <code className="text-zinc-300">.mxtsessions</code>, paste.</li>
                      <li><b className="text-zinc-300">JSON</b> — an array of <code className="text-zinc-300">{`{name,host,port,user}`}</code> 或 Termius 格式 <code className="text-zinc-300">{`{label,address,port,username}`}</code>.</li>
                    </ul>
                  </div>
                  <textarea
                    value={importPasteText}
                    onChange={(e) => setImportPasteText(e.target.value)}
                    placeholder={`把导出内容粘贴到这里…\n\n示例 JSON：\n[\n  {"name":"prod-web","host":"1.2.3.4","port":22,"user":"root"},\n  {"name":"db","host":"10.0.0.5","user":"admin"}\n]`}
                    rows={10}
                    className="w-full bg-black/40 border border-white/10 rounded-lg p-3 text-[11px] font-mono text-zinc-200 placeholder:text-zinc-600 focus:border-primary/40 focus:outline-none resize-none custom-scrollbar"
                  />
                  <div className="flex justify-end">
                    <button
                      onClick={parsePastedImport}
                      disabled={!importPasteText.trim()}
                      className="h-8 px-3 rounded-lg text-[11px] font-bold uppercase tracking-wider bg-primary/10 text-primary border border-primary/30 hover:bg-primary/20 disabled:opacity-40 disabled:cursor-not-allowed transition-all"
                    >
                      解析粘贴的文本
                    </button>
                  </div>
                </div>
              )}

              {importLoading && (
                <div className="p-6 text-center text-[12px] text-zinc-400">
                  {importSource === "ssh" ? "正在读取 ~/.ssh/config…" : "正在解析粘贴的文本…"}
                </div>
              )}

              {!importLoading && importError && importHosts.length === 0 && (
                <div className="m-2 p-3 bg-red-500/10 border border-red-500/20 rounded-lg text-red-400 text-[12px] font-mono whitespace-pre-wrap break-words">
                  {importError}
                </div>
              )}

              {!importLoading && !importError && importSource === "ssh" && importHosts.length === 0 && (
                <div className="p-6 text-center text-[12px] text-zinc-500">
                  No importable hosts found in ~/.ssh/config.
                </div>
              )}

              {!importLoading && importHosts.length > 0 && (
                <>
                  {/* Sticky select-all row so users can bulk-toggle a long
                      list without scrolling back up. */}
                  <div className="sticky top-0 z-10 -mx-3 -mt-3 mb-2 px-4 py-2 bg-[#121214] border-b border-white/5 flex items-center justify-between">
                    <button
                      onClick={toggleSelectAll}
                      className="flex items-center gap-2 text-[11px] font-bold text-zinc-300 hover:text-white transition-colors"
                    >
                      {importSelected.size === importHosts.length
                        ? <CheckSquare size={13} className="text-primary" />
                        : <Square size={13} className="text-zinc-500" />}
                      <span>Select all ({importHosts.length})</span>
                    </button>
                    <span className="text-[11px] text-zinc-500 font-mono">
                      {importSelected.size} selected
                    </span>
                  </div>

                  <div className="space-y-1.5">
                    {importHosts.map((h) => {
                      const isSel = importSelected.has(h.host_alias);
                      return (
                        <label
                          key={h.host_alias}
                          className={`flex items-start gap-3 p-2.5 rounded-lg border cursor-pointer transition-all ${
                            isSel
                              ? "bg-primary/10 border-primary/40"
                              : "bg-[#1a1a1e] border-white/5 hover:border-white/20"
                          }`}
                        >
                          <input
                            type="checkbox"
                            checked={isSel}
                            onChange={() => toggleOne(h.host_alias)}
                            className="mt-0.5 accent-primary shrink-0"
                          />
                          <div className="flex-1 min-w-0">
                            <div className="text-[12.5px] font-bold text-white truncate">
                              {h.host_alias}
                            </div>
                            <div className="text-[11px] font-mono text-zinc-400 truncate">
                              {h.user ? `${h.user}@` : ""}{h.hostname}:{h.port}
                            </div>
                            {(h.identity_file || h.proxy_jump) && (
                              <div className="mt-0.5 text-[10.5px] text-zinc-600 truncate">
                                {h.identity_file && <span className="mr-2">key: {h.identity_file}</span>}
                                {h.proxy_jump && <span>jump: {h.proxy_jump}</span>}
                              </div>
                            )}
                          </div>
                        </label>
                      );
                    })}
                  </div>

                  {importError && importHosts.length > 0 && (
                    <div className="mt-3 p-2 bg-red-500/10 border border-red-500/20 rounded-lg text-red-400 text-[11px] font-mono">
                      {importError}
                    </div>
                  )}

                  {importNotice && (
                    <div className="mt-3 p-2 bg-amber-500/10 border border-amber-500/20 rounded-lg text-amber-300 text-[11px]">
                      {importNotice}
                    </div>
                  )}
                </>
              )}
            </div>

            {/* Modal footer */}
            <div className="p-3 border-t border-white/5 shrink-0 flex items-center justify-end gap-2">
              <button
                onClick={closeImportModal}
                disabled={importBusy}
                className="px-3 h-8 rounded-lg text-[11px] font-bold uppercase tracking-wider bg-white/[0.04] border border-white/10 text-zinc-300 hover:bg-white/[0.08] hover:text-white disabled:opacity-40 disabled:cursor-not-allowed"
              >
                Cancel
              </button>
              <button
                onClick={importSelectedHosts}
                disabled={importBusy || importSelected.size === 0 || importLoading}
                className="px-3 h-8 rounded-lg text-[11px] font-bold uppercase tracking-wider bg-primary/15 border border-primary/40 text-primary hover:bg-primary/25 disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1.5"
              >
                <Download size={11} />
                {importBusy ? "正在导入…" : `导入选中的 ${importSelected.size} 项`}
              </button>
            </div>
          </div>
        </div>,
        document.body
      )}
    </div>
  );
};

export default AddNodePanel;