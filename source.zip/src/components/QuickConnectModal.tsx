import { useState } from "react";
import { Zap, X, AlertTriangle, KeyRound, Lock } from "lucide-react";
import PasswordField from "./PasswordField";

// Quick Connect: the auth bundle lives in component state, gets passed to
// DesktopApp via onConnect, and the resulting session carries it through to
// `initiate_connection`'s `quick_auth` param on the backend (so the live
// connection uses the inline auth directly). DesktopApp ALSO persists the
// target as a reusable node in the root directory (see save_quick_connect_node)
// so it can be reconnected later without re-typing credentials.

export interface QuickAuth {
  host: string;
  port: number;
  username: string;
  password?: string | null;
  private_key?: string | null;
  passphrase?: string | null;
}

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onConnect: (auth: QuickAuth) => void;
}

const QuickConnectModal = ({ isOpen, onClose, onConnect }: Props) => {
  const [host, setHost] = useState("");
  const [port, setPort] = useState<number>(22);
  const [username, setUsername] = useState("root");
  const [authMode, setAuthMode] = useState<"password" | "key">("password");
  const [password, setPassword] = useState("");
  const [privateKey, setPrivateKey] = useState("");
  const [passphrase, setPassphrase] = useState("");
  const [err, setErr] = useState<string | null>(null);

  if (!isOpen) return null;

  const reset = () => {
    setHost(""); setPort(22); setUsername("root");
    setAuthMode("password"); setPassword(""); setPrivateKey(""); setPassphrase("");
    setErr(null);
  };

  const close = () => { reset(); onClose(); };

  const connect = () => {
    setErr(null);
    if (!host.trim()) { setErr("Host is required"); return; }
    if (!port || port < 1 || port > 65535) { setErr("端口必须在 1–65535 之间"); return; }
    if (authMode === "key" && !privateKey.trim()) { setErr("私钥内容不能为空"); return; }

    // A blank username (issue #54) and an empty password (issue #30) are both
    // asked for when connecting; an empty "Login as" answer means root.
    const auth: QuickAuth = {
      host: host.trim(),
      port,
      username: username.trim(),
      password: authMode === "password" && password ? password : null,
      private_key: authMode === "key" ? privateKey : null,
      passphrase: authMode === "key" && passphrase ? passphrase : null,
    };
    reset();
    onConnect(auth);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-3" onClick={close}>
      <div className="w-full max-w-md max-h-[90vh] flex flex-col bg-[#121214] border border-white/10 rounded-xl shadow-2xl" onClick={(e) => e.stopPropagation()}>
        {/* Header */}
        <div className="shrink-0 px-4 py-3 border-b border-white/5 flex items-center justify-between">
          <span className="text-[12px] font-bold uppercase tracking-widest text-white flex items-center gap-2">
            <Zap size={13} className="text-primary" /> 快速连接
          </span>
          <button aria-label="Close" onClick={close} className="text-zinc-400 hover:text-white"><X size={16} /></button>
        </div>

        <div className="flex-1 overflow-y-auto custom-scrollbar p-5 space-y-3">
          {err && (
            <div className="px-3 py-2 bg-rose-500/15 border border-rose-500/30 rounded text-rose-200 text-[11.5px] font-mono flex items-center gap-2">
              <AlertTriangle size={12} /> {err}
            </div>
          )}

          {/* Host + port */}
          <div className="grid grid-cols-4 gap-2">
            <div className="col-span-3 space-y-1">
              <label className="text-[10px] font-bold text-zinc-300 uppercase tracking-wider ml-0.5">主机</label>
              <input
                value={host}
                onChange={(e) => setHost(e.target.value)}
                placeholder="192.168.1.1 or example.com"
                className="w-full h-9 px-3 bg-zinc-900/60 border border-white/10 rounded-lg text-[12.5px] text-zinc-50 outline-none focus:border-primary/50"
                autoFocus
              />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-zinc-300 uppercase tracking-wider ml-0.5">端口</label>
              <input
                type="number"
                value={port}
                onChange={(e) => setPort(parseInt(e.target.value) || 22)}
                className="w-full h-9 px-3 bg-zinc-900/60 border border-white/10 rounded-lg text-[12.5px] text-zinc-50 outline-none focus:border-primary/50"
              />
            </div>
          </div>

          {/* Username */}
          <div className="space-y-1">
            <label className="text-[10px] font-bold text-zinc-300 uppercase tracking-wider ml-0.5">用户名</label>
            <input
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="连接时询问"
              className="w-full h-9 px-3 bg-zinc-900/60 border border-white/10 rounded-lg text-[12.5px] text-zinc-50 outline-none focus:border-primary/50"
            />
          </div>

          {/* Auth mode toggle */}
          <div className="pt-1">
            <div className="flex items-center gap-1.5 bg-white/[0.03] border border-white/10 rounded-lg p-1">
              <button
                onClick={() => setAuthMode("password")}
                className={`flex-1 h-7 rounded text-[10.5px] font-bold uppercase tracking-wider flex items-center justify-center gap-1.5 transition-colors ${
                  authMode === "password"
                    ? "bg-primary/20 text-primary"
                    : "text-zinc-400 hover:text-zinc-100"
                }`}
              >
                <Lock size={11} /> 密码
              </button>
              <button
                onClick={() => setAuthMode("key")}
                className={`flex-1 h-7 rounded text-[10.5px] font-bold uppercase tracking-wider flex items-center justify-center gap-1.5 transition-colors ${
                  authMode === "key"
                    ? "bg-primary/20 text-primary"
                    : "text-zinc-400 hover:text-zinc-100"
                }`}
              >
                <KeyRound size={11} /> SSH Key
              </button>
            </div>
          </div>

          {authMode === "password" ? (
            <div className="space-y-1 animate-in fade-in">
              <label className="text-[10px] font-bold text-zinc-300 uppercase tracking-wider ml-0.5">密码</label>
              <PasswordField
                value={password}
                onChange={setPassword}
                placeholder="••••••"
                onKeyDown={(e: any) => e.key === "Enter" && connect()}
                className="w-full h-9 px-3 bg-zinc-900/60 border border-white/10 rounded-lg text-[12.5px] text-primary outline-none focus:border-primary/50"
              />
              <p className="text-[10px] text-zinc-500 ml-0.5">留空则在连接时询问。</p>
            </div>
          ) : (
            <div className="space-y-2 animate-in fade-in">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-zinc-300 uppercase tracking-wider ml-0.5">私钥（PEM）</label>
                <textarea
                  value={privateKey}
                  onChange={(e) => setPrivateKey(e.target.value)}
                  rows={5}
                  placeholder="-----BEGIN OPENSSH PRIVATE KEY-----"
                  className="w-full px-3 py-2 bg-black/50 border border-white/10 rounded-lg text-[11.5px] font-mono text-zinc-200 outline-none focus:border-primary/50 resize-y"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-zinc-300 uppercase tracking-wider ml-0.5">口令（如有）</label>
                <PasswordField
                  value={passphrase}
                  onChange={setPassphrase}
                  placeholder="未加密则留空"
                  className="w-full h-9 px-3 bg-zinc-900/60 border border-white/10 rounded-lg text-[12.5px] text-zinc-50 outline-none focus:border-primary/50"
                />
                <p className="text-[10px] text-zinc-500 ml-0.5">若密钥已加密，留空则在连接时询问。</p>
              </div>
            </div>
          )}

          <p className="text-[10.5px] text-zinc-400 leading-snug pt-1">
            This host is saved as a node in your root directory for reuse. Edit or remove it anytime from the node grid.
          </p>
        </div>

        {/* Footer */}
        <div className="shrink-0 px-5 py-3 border-t border-white/5 flex items-center gap-2">
          <button
            onClick={connect}
            className="flex-1 h-10 rounded-lg text-[11.5px] font-bold uppercase tracking-wider bg-primary text-black hover:shadow-[0_0_20px_rgba(var(--primary),0.3)] flex items-center justify-center gap-2"
          >
            <Zap size={14} /> 连接
          </button>
          <button onClick={close} className="h-10 px-4 rounded-lg text-[11.5px] font-bold uppercase tracking-wider bg-white/5 text-zinc-200 border border-white/10 hover:bg-white/10">
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};

export default QuickConnectModal;
