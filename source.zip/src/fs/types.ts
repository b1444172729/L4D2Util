// Abstraction over a filesystem (local or remote SFTP). The same `FilePanel`
// component is mounted twice — once with a LocalProvider and once with a
// RemoteProvider — and dispatches all I/O through this interface.
//
// Cross-pane transfer is handled outside the provider (see `transfer.ts`) so
// each backend can keep its own fast path (e.g. `sftp_download_file` writes
// directly to disk instead of round-tripping through a JS `Uint8Array`).

import type { ArchiveFormat } from "./archive";

export interface FileEntry {
  name: string;
  path: string;
  /** For a symlink this describes the target, so links to folders open like folders. */
  isDir: boolean;
  size: number;
  permissions?: number; // unix mode bits
  uid?: number;
  gid?: number;
  modified?: number; // unix timestamp (seconds)
  /** The entry is a symlink (or Windows junction). Delete/rename act on the link itself. */
  isSymlink?: boolean;
  /** Symlink whose target is missing or not accessible. */
  brokenLink?: boolean;
}

export interface ListResult {
  currentPath: string;
  entries: FileEntry[];
}

export interface FileProvider {
  /** Identity tag used by transfer.ts to pick the right backend command. */
  readonly id: "local" | "remote";
  /** Short label shown in the panel header. */
  readonly label: string;
  /** Native path separator for this provider. */
  readonly pathSep: "/" | "\\";

  // ---- navigation ----------------------------------------------------------
  homePath(): Promise<string>;
  list(path: string): Promise<ListResult>;
  /** Joins a directory and an entry name into a full path. */
  joinPath(dir: string, name: string): string;
  /** Returns the parent directory of the given path. */
  parentPath(path: string): string;

  // ---- mutations -----------------------------------------------------------
  mkdir(path: string): Promise<void>;
  /** `isSymlink` makes the remote side unlink the link instead of rmdir-ing it. */
  remove(path: string, isDir: boolean, isSymlink?: boolean): Promise<void>;
  rename(from: string, to: string): Promise<void>;

  // ---- optional unix-only operations --------------------------------------
  chmod?: (path: string, mode: number) => Promise<void>;
  /** `gid` null keeps the current group. */
  chown?: (path: string, uid: number, gid: number | null) => Promise<void>;
  /** Current mode and owner, following symlinks (what chmod/chown change). */
  stat?: (path: string) => Promise<{ permissions?: number; uid?: number; gid?: number }>;

  // ---- archives ------------------------------------------------------------
  // Both run until done or until `jobId` is cancelled (`cancelArchiveJob`),
  // and reject with "CANCELLED" then. They resolve with a warning when the
  // job got done but the tool had something to say (a file changed or
  // couldn't be read while it was packed).
  /**
   * Packs `names` (entries of `dir`) into the archive `name` in `dir`.
   * Rejects with `EXISTS:<name>` when that is already there and `overwrite`
   * is false.
   */
  archive(dir: string, names: string[], name: string, format: ArchiveFormat, overwrite: boolean, jobId: string): Promise<string | null>;
  /**
   * Unpacks the archive `name` of `dir` into `dir`, or into its subfolder
   * `folder` (created if missing), replacing same-named files. `name` and
   * `folder` are single names; the backend refuses anything else.
   */
  extract(dir: string, name: string, folder: string | null, jobId: string): Promise<string | null>;
}

/** Remote provider carries the SSH session id so transfer.ts can target it. */
export interface RemoteFileProvider extends FileProvider {
  readonly id: "remote";
  readonly sessionId: string;
}

export interface LocalFileProvider extends FileProvider {
  readonly id: "local";
}
