import { invoke } from "@tauri-apps/api/core";
import { FileEntry, ListResult, LocalFileProvider } from "./types";
import { localParent } from "./localPath";

// Local filesystem provider. All paths are OS-native (backslashes on Windows,
// forward slashes elsewhere). Backed by the small set of `local_*` Tauri
// commands declared in main.rs.

type RawLocalEntry = {
  name: string;
  path: string;
  is_dir: boolean;
  size: number;
  modified?: number;
  is_symlink?: boolean;
  broken_link?: boolean;
};

const isWindowsLike = (p: string) => /^[a-zA-Z]:[\\/]/.test(p) || p.includes("\\");

export function createLocalProvider(): LocalFileProvider {
  // Sep is computed lazily from the first real path we see (after `homePath`
  // resolves). Defaulting to `\` on Windows is fine because the renderer is
  // bundled per-OS anyway, but probing keeps it honest if someone runs the
  // binary under WSL etc.
  let cachedSep: "/" | "\\" | null = null;

  const inferSep = (sample: string) => {
    if (cachedSep) return cachedSep;
    cachedSep = isWindowsLike(sample) ? "\\" : "/";
    return cachedSep;
  };

  return {
    id: "local",
    label: "Local",
    get pathSep() {
      return cachedSep ?? "\\";
    },

    async homePath() {
      // On Android there is no Desktop and, under scoped storage, most
      // shared paths (Downloads, DCIM, ...) aren't guaranteed to be
      // writable from a direct filesystem call. `android_default_local_dir`
      // returns the first entry from `android_quick_dirs` that passed a
      // touch-probe, falling back to the app-scoped internal storage. If
      // even that fails, we let it error and the panel just stays empty.
      if (/Android/i.test(navigator.userAgent)) {
        const dir = await invoke<string>("android_default_local_dir");
        if (dir) {
          inferSep(dir);
          return dir;
        }
      }
      // Desktop: default to Desktop — that's where most users keep
      // transient work and is the natural landing zone for drag-out from
      // the remote pane. The Rust side falls back to the home dir if
      // Desktop is unset.
      const dir = await invoke<string>("local_desktop_dir");
      inferSep(dir);
      return dir;
    },

    async list(path: string): Promise<ListResult> {
      // `current_path` is the folder as the backend resolved it (real letter
      // case, one kind of separator, links followed), so the path bar shows
      // where the pane really is, whatever was typed.
      const raw = await invoke<{ current_path: string; entries: RawLocalEntry[] }>("local_list_dir", { path });
      const entries: FileEntry[] = raw.entries.map((r) => ({
        name: r.name,
        path: r.path,
        isDir: r.is_dir,
        size: r.size,
        modified: r.modified,
        isSymlink: !!r.is_symlink,
        brokenLink: !!r.broken_link,
      }));
      inferSep(raw.current_path);
      return { currentPath: raw.current_path, entries };
    },

    joinPath(dir: string, name: string) {
      const sep = inferSep(dir);
      return dir.endsWith(sep) ? `${dir}${name}` : `${dir}${sep}${name}`;
    },

    parentPath(path: string) {
      return localParent(path);
    },

    async mkdir(path: string) {
      await invoke("local_create_dir", { path });
    },

    async remove(path: string, isDir: boolean) {
      // The backend checks the on-disk type itself and only unlinks links.
      await invoke("local_remove", { path, isDir });
    },

    async rename(from: string, to: string) {
      await invoke("local_rename", { from, to });
    },

    async archive(dir, names, name, format, overwrite, jobId) {
      return await invoke<string | null>("local_archive", { dir, names, name, format, overwrite, jobId });
    },

    async extract(dir, name, folder, jobId) {
      return await invoke<string | null>("local_extract", { dir, name, folder, jobId });
    },
  };
}
