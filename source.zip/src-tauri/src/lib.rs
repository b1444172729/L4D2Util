// windows_subsystem is bin-only; the matching attribute lives in main.rs.

use aes_gcm::{aead::{Aead, KeyInit}, Aes256Gcm, Nonce};
use argon2::{Algorithm, Argon2, Params, Version};
use zeroize::{Zeroize, Zeroizing};
use rand::Rng;
use rusqlite::{ffi, Connection, MAIN_DB};
use rusqlite::serialize::OwnedData;
use std::ptr::NonNull;
use std::sync::Mutex as StdMutex;
use std::path::PathBuf;
use std::fs;
use tauri::Manager;
use serde_json::json;
use ssh_key::{private::{Ed25519Keypair, Ed25519PrivateKey}, PrivateKey};
mod ssh_manager;
mod tunnel;
mod monitor;
mod cloud;
mod cloud_config;
mod about;
mod mirror;
mod docker;
mod hlc;
mod identity;
mod portable;
mod fonts;
mod webkit_sandbox;
mod sftp_remove;
mod archive;
mod approvals;
#[cfg(test)]
mod ssh_test_server;
use ssh_manager::SshState;
use monitor::{MonitorMap, SharedSettings};
use mirror::MirrorMap;
use std::sync::Arc;

// On-disk vault layout:
//   bytes 0..3   magic ("OMNV")
//   byte  4      version (1)
//   bytes 5..20  salt (16 bytes, per-profile)
//   bytes 21..32 nonce (12 bytes, per-save)
//   rest         AES-256-GCM(zstd(serialised-sqlite)) + 16-byte tag
const VAULT_MAGIC: &[u8; 4] = b"OMNV";
const VAULT_VERSION: u8 = 1;
/// zstd compression level. 3 is the library default — fast enough that
/// save latency is dominated by sqlite serialisation, with compression
/// ratios within a couple percent of the slower levels for SQL-like data.
const VAULT_COMPRESS_LEVEL: i32 = 3;
const SALT_LEN: usize = 16;
const NONCE_LEN: usize = 12;
const HEADER_LEN: usize = 4 + 1 + SALT_LEN;

pub struct DbState {
    pub conn: std::sync::Arc<StdMutex<Option<Connection>>>,
    /// `Zeroizing` wipes the 32-byte AES-256-GCM key on drop. Without
    /// this, the master key lives on in the heap allocator until the
    /// slot is reused — long enough to land in a crash dump or swap
    /// file. The mutex slot itself is overwritten with None on profile
    /// close which triggers the Zeroize Drop.
    pub master_key: StdMutex<Option<Zeroizing<[u8; 32]>>>,
    pub salt: StdMutex<Option<[u8; SALT_LEN]>>,
    pub db_path: StdMutex<Option<PathBuf>>,
    /// Name of the profile the user picked on the launch screen. Drives the
    /// path of `db_path` (under `<app_data>/profiles/<name>.submarine`) and is
    /// cleared by `close_profile` so the app returns to the picker.
    pub active_profile: StdMutex<Option<String>>,
    /// This profile's Hybrid Logical Clock, shared into the SQLite `hlc_now()`
    /// custom function so every row mutation auto-stamps `updated_at`. `Some`
    /// while a profile is open; `None` on the picker. Held behind an Arc so the
    /// same clock instance backs both the SQL function and any Rust-side sync
    /// code (the merge engine's `observe`).
    pub hlc: StdMutex<Option<std::sync::Arc<hlc::Hlc>>>,
    /// Which opening of a profile `conn` belongs to: bumped, under `conn`'s
    /// lock, every time a profile opens or closes. A command that awaits the
    /// network between reading the open profile and writing back to it
    /// checks this under the lock before the write (`still_open`): when it
    /// moved, the user locked that profile or opened another one meanwhile,
    /// and the write would land in the wrong vault. An Arc so a vault save
    /// on the blocking pool can check it too.
    pub generation: std::sync::Arc<std::sync::atomic::AtomicU64>,
}

impl DbState {
    /// The current generation. Read it while holding `conn`'s lock, so it
    /// names the profile that lock gives access to.
    fn generation_now(&self) -> u64 {
        self.generation.load(std::sync::atomic::Ordering::SeqCst)
    }

    /// For whatever opens or closes a profile, while it holds `conn`'s lock.
    fn bump_generation(&self) -> u64 {
        self.generation.fetch_add(1, std::sync::atomic::Ordering::SeqCst) + 1
    }

    /// Before a write that follows an await: is the profile that was open at
    /// `generation` still the one open? Call it while holding `conn`'s lock.
    fn still_open(&self, generation: u64) -> Result<(), String> {
        if self.generation_now() == generation {
            Ok(())
        } else {
            Err("[STATE] PROFILE_CHANGED: the profile was locked, or another one opened, while this was running. Nothing was written to it; open it and try again.".into())
        }
    }
}

// ---------------------------------------------------------------------------
// Profile path helpers
// ---------------------------------------------------------------------------

/// Where all profile files live. Created on first use. Each profile is an
/// independently encrypted `.submarine` file — no shared salt, no shared key.
pub(crate) fn profiles_dir(app: &tauri::AppHandle) -> Result<PathBuf, String> {
    let data_dir = app.path().app_data_dir()
        .map_err(|e| format!("[SYSTEM] APP_DATA_DIR_NOT_FOUND: {}", e))?;
    Ok(data_dir.join("profiles"))
}

/// Compute the on-disk path for a named profile. Caller has already
/// validated the name with `validate_profile_name`.
pub(crate) fn profile_path(app: &tauri::AppHandle, name: &str) -> Result<PathBuf, String> {
    Ok(profiles_dir(app)?.join(format!("{}.submarine", name)))
}

/// Reject names that would let a user escape the profiles dir or collide
/// with reserved filenames on Windows. Keep the charset narrow on purpose
/// so a profile name is always a safe filename component on every OS.
pub(crate) fn validate_profile_name(name: &str) -> Result<(), String> {
    let n = name.trim();
    if n.is_empty() {
        return Err("档案名称不能为空".into());
    }
    if n.len() > 32 {
        return Err("档案名称过长（最多 32 个字符）".into());
    }
    if !n.chars().all(|c| c.is_ascii_alphanumeric() || c == '-' || c == '_') {
        return Err("Profile name may only contain letters, numbers, '-' and '_'".into());
    }
    // Windows reserved device names — also weird on macOS/Linux as filename roots.
    let upper = n.to_uppercase();
    let reserved = ["CON", "PRN", "AUX", "NUL"];
    // `last_byte` is safe here because we already enforced ASCII-only at
    // the charset check above — but we still use `?`/`.map(...)` rather
    // than `.unwrap()` so a future relaxation can never silently panic.
    let last_ascii_digit = upper.as_bytes().last().is_some_and(|b| b.is_ascii_digit());
    if reserved.contains(&upper.as_str())
        || (upper.starts_with("COM") && upper.len() == 4 && last_ascii_digit)
        || (upper.starts_with("LPT") && upper.len() == 4 && last_ascii_digit)
    {
        return Err(format!("'{}' is a reserved name on Windows", n));
    }
    Ok(())
}

// Argon2id parameters for vault-key derivation:
//   m_cost   64 MiB  — memory hardness; raises cost of GPU/ASIC attacks
//   t_cost   3       — passes over the buffer
//   p_cost   4       — parallelism; up to 4 lanes if available
//   output   32 B    — AES-256-GCM key length
// Tuned higher than OWASP's interactive-login defaults because this protects
// the entire profile vault, not a single-request login. Changing these
// values invalidates every existing vault — bump only on a deliberate
// re-keying migration.
const ARGON2_M_COST: u32 = 64 * 1024;
const ARGON2_T_COST: u32 = 3;
const ARGON2_P_COST: u32 = 4;

fn derive_key(password: &str, salt_bytes: &[u8]) -> Result<[u8; 32], String> {
    let params = Params::new(ARGON2_M_COST, ARGON2_T_COST, ARGON2_P_COST, Some(32))
        .map_err(|e| format!("[CRYPTO] ARGON2_PARAMS: {}", e))?;
    let argon2 = Argon2::new(Algorithm::Argon2id, Version::V0x13, params);
    let mut key = [0u8; 32];
    // Raw API: write derived bytes directly into the key buffer. Avoids
    // the PHC-string round-trip (encode then truncate b64) the previous
    // implementation used, which was fragile and made parameter changes
    // invisible to type-checking.
    argon2
        .hash_password_into(password.as_bytes(), salt_bytes, &mut key)
        .map_err(|e| format!("[CRYPTO] HASH_FAILED: {}", e))?;
    Ok(key)
}

fn encrypt_with_key(plaintext: &[u8], key: &[u8; 32]) -> Result<(Vec<u8>, [u8; NONCE_LEN]), String> {
    let cipher = Aes256Gcm::new(key.into());
    let mut nonce_bytes = [0u8; NONCE_LEN];
    rand::rng().fill_bytes(&mut nonce_bytes);
    let ciphertext = cipher.encrypt(&Nonce::from(nonce_bytes), plaintext)
        .map_err(|e| format!("[CRYPTO] ENCRYPT_FAILED: {}", e))?;
    Ok((ciphertext, nonce_bytes))
}

fn decrypt_with_key(ciphertext: &[u8], nonce_bytes: &[u8], key: &[u8; 32]) -> Result<Vec<u8>, String> {
    let nonce = Nonce::try_from(nonce_bytes).map_err(|_| "[CRYPTO] NONCE_LEN_INVALID".to_string())?;
    let cipher = Aes256Gcm::new(key.into());
    cipher.decrypt(&nonce, ciphertext)
        .map_err(|e| format!("[CRYPTO] DECRYPT_FAILURE: Possible wrong key or corrupted data. Details: {}", e))
}

/// Returns (salt, nonce, ciphertext) parsed out of an on-disk vault blob.
fn parse_vault_blob(data: &[u8]) -> Result<(Vec<u8>, Vec<u8>, Vec<u8>), String> {
    if data.len() < HEADER_LEN + NONCE_LEN {
        return Err("[VAULT] INVALID_FORMAT: Data too short".into());
    }
    if &data[..4] != VAULT_MAGIC {
        return Err("[VAULT] BAD_MAGIC".into());
    }
    if data[4] != VAULT_VERSION {
        return Err(format!("[VAULT] UNSUPPORTED_VERSION: {}", data[4]));
    }
    let salt = data[5..5 + SALT_LEN].to_vec();
    let nonce = data[HEADER_LEN..HEADER_LEN + NONCE_LEN].to_vec();
    let ct = data[HEADER_LEN + NONCE_LEN..].to_vec();
    Ok((salt, nonce, ct))
}

/// Copies `data` into a sqlite-allocated buffer wrapped in `OwnedData`.
/// `Connection::deserialize` requires a buffer allocated by `sqlite3_malloc`
/// because it frees it via `SQLITE_DESERIALIZE_FREEONCLOSE`.
fn to_sqlite_owned(data: &[u8]) -> Result<OwnedData, String> {
    let sz = data.len();
    let raw = unsafe { ffi::sqlite3_malloc64(sz as u64) } as *mut u8;
    let ptr = NonNull::new(raw).ok_or("[DATABASE] SQLITE_MALLOC_FAILED")?;
    unsafe {
        std::ptr::copy_nonoverlapping(data.as_ptr(), ptr.as_ptr(), sz);
        Ok(OwnedData::from_raw_nonnull(ptr, sz))
    }
}

fn write_vault_blob(salt: &[u8; SALT_LEN], nonce: &[u8; NONCE_LEN], ciphertext: &[u8]) -> Vec<u8> {
    let mut out = Vec::with_capacity(HEADER_LEN + NONCE_LEN + ciphertext.len());
    out.extend_from_slice(VAULT_MAGIC);
    out.push(VAULT_VERSION);
    out.extend_from_slice(salt);
    out.extend_from_slice(nonce);
    out.extend_from_slice(ciphertext);
    out
}

/// Compress the plaintext SQLite serialisation for vault v2 writes.
/// Errors here are surfaced as crypto-domain errors because the caller's
/// invariant ("save the DB") is what's broken, not just I/O.
fn vault_compress(plaintext: &[u8]) -> Result<Vec<u8>, String> {
    zstd::stream::encode_all(plaintext, VAULT_COMPRESS_LEVEL)
        .map_err(|e| format!("[VAULT] COMPRESS_FAILED: {}", e))
}

/// The largest vault (its SQLite image, before compression) this app opens,
/// so also the largest it saves: one saved past it could never be opened
/// again. Released builds open up to the same 64 MiB.
const VAULT_MAX_BYTES: usize = 64 * 1024 * 1024;

/// Decompress the post-decrypt body for vault v2 reads. Bounded by a
/// generous max-size guard so a corrupt or hostile file can't make us
/// allocate gigabytes — a real Submarine SQLite snapshot is well under
/// 64 MiB even with thousands of nodes.
fn vault_decompress(compressed: &[u8]) -> Result<Vec<u8>, String> {
    let mut out = Vec::new();
    let mut decoder = zstd::stream::Decoder::new(compressed)
        .map_err(|e| format!("[VAULT] DECOMPRESS_INIT_FAILED: {}", e))?;
    use std::io::Read;
    let mut buf = [0u8; 64 * 1024];
    loop {
        let n = decoder.read(&mut buf)
            .map_err(|e| format!("[VAULT] DECOMPRESS_FAILED: {}", e))?;
        if n == 0 { break; }
        if out.len() + n > VAULT_MAX_BYTES {
            return Err("[VAULT] DECOMPRESS_TOO_LARGE: refusing to inflate past 64 MiB".into());
        }
        out.extend_from_slice(&buf[..n]);
    }
    Ok(out)
}

fn save_vault_internal(state: &DbState) -> Result<(), String> {
    let conn_guard = state.conn.lock().map_err(|_| "[STATE] MUTEX_POISON_CONN")?;
    let key_guard = state.master_key.lock().map_err(|_| "[STATE] MUTEX_POISON_KEY")?;
    let salt_guard = state.salt.lock().map_err(|_| "[STATE] MUTEX_POISON_SALT")?;
    let path_guard = state.db_path.lock().map_err(|_| "[STATE] MUTEX_POISON_PATH")?;

    if let (Some(conn), Some(key), Some(salt), Some(path)) =
        (&*conn_guard, &*key_guard, &*salt_guard, &*path_guard)
    {
        save_vault_blocking(conn, key, salt, path)
    } else {
        Err("[STATE] MISSING_REQUIRED_RESOURCES_FOR_SAVE".into())
    }
}

/// Pure-sync vault serialise + encrypt + atomic write. Pulled out of
/// `save_vault_internal` so the async wrapper below can hand it to
/// `spawn_blocking` with owned snapshots — keeps the SQLite serialise,
/// zstd compression, AES-GCM encrypt, and fsync off the tokio worker
/// pool during hot paths like the post-connect `persist_vault` call.
fn save_vault_blocking(
    conn: &Connection,
    key: &Zeroizing<[u8; 32]>,
    salt: &[u8; SALT_LEN],
    path: &std::path::Path,
) -> Result<(), String> {
    let serialized = conn.serialize(MAIN_DB)
        .map_err(|e| format!("[DATABASE] SERIALIZE_FAILED: {}", e))?;
    // Past this, the next unlock would refuse the file, and everything in it
    // with it. The file on disk stays as it was.
    if serialized.len() > VAULT_MAX_BYTES {
        return Err("[VAULT] TOO_LARGE: this profile has grown past 64 MiB, the most it can be opened at, so it wasn't saved. The copy on disk is unchanged.".into());
    }
    // Compress-then-encrypt. Order matters: compressing AFTER encryption
    // is useless because AES-GCM ciphertext is indistinguishable from
    // random. Doing it before keeps the on-disk file small AND keeps
    // ciphertext semantically secure.
    let compressed = Zeroizing::new(vault_compress(&*serialized)?);
    let (ciphertext, nonce) = encrypt_with_key(&compressed, key)?;
    let blob = write_vault_blob(salt, &nonce, &ciphertext);
    // Atomic write: tmp -> fsync -> rename. A crash / power loss in the
    // middle of a direct fs::write would leave the vault truncated, and
    // every saved credential would be unrecoverable on next launch.
    let tmp_path = path.with_extension("submarine.tmp");
    {
        use std::io::Write as _;
        // Drop any tmp left behind by a crashed save. Without this the
        // OpenOptions below would reopen that file, and `mode` only applies
        // to a file this call actually creates — so a stale tmp written by
        // an older build would keep its umask-derived permissions forever.
        let _ = fs::remove_file(&tmp_path);
        // Mode is set at open time, not with a set_permissions call after
        // creating the file. The gap between those two would be enough for
        // another account on a multi-user host to open the vault while it
        // still carried the process umask (0644 on most distros) — and this
        // is the file every private key and password in the app lives in.
        // Same idiom as the cloud bearer token in cloud.rs; on Windows the
        // user-only ACL is inherited from app_data_dir.
        let mut opts = fs::OpenOptions::new();
        opts.write(true).create_new(true);
        #[cfg(unix)]
        {
            use std::os::unix::fs::OpenOptionsExt as _;
            opts.mode(0o600);
        }
        let mut f = opts.open(&tmp_path)
            .map_err(|e| format!("[FILE] VAULT_TMP_CREATE_FAILED at {:?}: {}", tmp_path, e))?;
        f.write_all(&blob)
            .map_err(|e| format!("[FILE] VAULT_TMP_WRITE_FAILED at {:?}: {}", tmp_path, e))?;
        f.sync_all()
            .map_err(|e| format!("[FILE] VAULT_TMP_SYNC_FAILED at {:?}: {}", tmp_path, e))?;
    }
    fs::rename(&tmp_path, path)
        .map_err(|e| format!("[FILE] VAULT_RENAME_FAILED {:?} -> {:?}: {}", tmp_path, path, e))?;
    Ok(())
}

// ---------------------------------------------------------------------------
// Per-entity sync foundation (uuid + HLC + tombstone)
// ---------------------------------------------------------------------------

/// The vault tables that participate in per-entity Last-Write-Wins sync. Each
/// carries the `uuid` (portable identity) / `updated_at` (HLC) / `deleted`
/// (tombstone) columns. `known_hosts`, `cmd_history`, `monitor_settings`, and
/// `schema_meta` are intentionally device-local and NOT synced.
const SYNCED_TABLES: &[&str] = &[
    "folders", "ssh_keys", "credentials", "servers", "commands", "notes", "monitor_configs",
];

/// Opaque 128-bit hex id for a synced row. Not RFC-4122 formatted — we only
/// need global uniqueness, and this matches the app's existing random-id idiom
/// (see `app_temp_root`).
fn new_entity_uuid() -> String {
    let mut bytes = [0u8; 16];
    rand::rng().fill_bytes(&mut bytes);
    hex::encode(bytes)
}

/// This profile's Data Encryption Key — the 256-bit key that every per-entity
/// sync blob is encrypted under. Stored in `sync_meta` inside the vault (itself
/// encrypted at rest with the vault password), so a solo profile needs no
/// passphrase to sync. When the profile is shared, THIS key is what gets sealed
/// to each member's public key — decoupling "who can read the synced data" from
/// "who knows the vault password". Generated once and reused; rotating it (on a
/// member revoke) is a deliberate, separate action. Returns `(dek, created)`.
fn get_or_create_dek(conn: &Connection) -> Result<([u8; 32], bool), String> {
    let existing: Option<String> = conn
        .query_row("SELECT value FROM sync_meta WHERE key='dek'", [], |r| r.get(0))
        .ok();
    if let Some(hex_s) = existing {
        let raw = hex::decode(&hex_s).map_err(|e| format!("[SHARE] DEK_HEX: {e}"))?;
        if raw.len() == 32 {
            let mut d = [0u8; 32];
            d.copy_from_slice(&raw);
            return Ok((d, false));
        }
        // Malformed row (shouldn't happen) — fall through and mint a fresh one.
    }
    let mut d = [0u8; 32];
    rand::rng().fill_bytes(&mut d);
    conn.execute(
        "INSERT INTO sync_meta(key,value) VALUES('dek',?1)
         ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        [hex::encode(d)],
    )
    .map_err(|e| format!("[SHARE] DEK_STORE: {e}"))?;
    Ok((d, true))
}

/// Load — or generate once — this device's stable sync node id. Stored in a
/// device-local sidecar next to the cloud token, deliberately OUTSIDE the vault
/// so it never travels when a vault is copied/restored to another device (two
/// devices sharing a node id would make HLC tie-breaks collide and corrupt the
/// causal order).
fn sync_device_node_id(app: &tauri::AppHandle) -> String {
    use tauri::Manager as _;
    let fresh = || {
        let mut b = [0u8; 8];
        rand::rng().fill_bytes(&mut b);
        hex::encode(b)
    };
    let Ok(dir) = app.path().app_data_dir() else { return fresh() };
    let path = dir.join("sync_device.json");
    if let Ok(bytes) = std::fs::read(&path) {
        if let Ok(v) = serde_json::from_slice::<serde_json::Value>(&bytes) {
            if let Some(id) = v.get("node_id").and_then(|x| x.as_str()) {
                if !id.is_empty() {
                    return id.to_string();
                }
            }
        }
    }
    let id = fresh();
    let _ = std::fs::create_dir_all(&dir);
    let _ = std::fs::write(&path, serde_json::json!({ "node_id": id }).to_string());
    id
}

/// Stamp given to every backfilled row: the floor of the clock, not `now`.
///
/// A row with `uuid IS NULL` has never taken part in sync, so we know nothing
/// about when it was last edited — only that it predates the sync era. Stamping
/// it `now` (which is what we used to do) told the merge engine the exact
/// opposite: that a vault which had been sitting untouched on a shelf held the
/// freshest copy of every row in it. Opening an old backup on a second device
/// was then enough to have it overwrite current data everywhere.
///
/// The floor is the honest answer: these rows lose every LWW comparison against
/// anything that has actually been synced, and win only against nothing at all
/// (a first-ever sync, where they upload unopposed). One tick above the reserved
/// escrow stamp so the escrow record still sorts first.
const BACKFILL_UAT: &str = "000000000000001:00000:backfill";

/// Columns that identify a row well enough to recognise "the same thing" in a
/// copy of this vault sitting on another device. Used only by the backfill —
/// see `derived_entity_uuid`.
fn backfill_identity_cols(table: &str) -> &'static [&'static str] {
    match table {
        "folders" => &["name"],
        "ssh_keys" => &["name", "public_key"],
        "credentials" => &["name", "username", "auth_type"],
        "servers" => &["name", "host", "port", "username"],
        "commands" => &["title", "content"],
        "notes" => &["title"],
        // monitor_configs hangs off a server; its identity is that server's.
        "monitor_configs" => &[],
        _ => &[],
    }
}

/// Deterministic 128-bit id derived from a row's identifying content.
///
/// Random ids were the second half of the same bug as `BACKFILL_UAT`. Two
/// devices holding copies of the same pre-sync vault would each mint a DIFFERENT
/// uuid for what is plainly the same server, so the merge engine saw two
/// unrelated entities and kept both: every row duplicated, and rows deleted on
/// one device came back from the other because the tombstone was keyed to a uuid
/// the second device had never heard of.
///
/// Hashing the identifying columns instead makes both devices arrive at the same
/// id independently, so the row merges (and its tombstone applies) as intended.
/// A hash collision means two rows agreeing on every identifying field, which is
/// the case where merging them is correct anyway — and the caller still falls
/// back to a random id if two rows in the SAME table derive the same uuid, so a
/// collision can never silently fuse two local rows into one.
fn derived_entity_uuid(table: &str, values: &[Option<String>]) -> Option<String> {
    use sha2::{Digest, Sha256};
    // Nothing identifying to hash (all NULL/empty) → caller uses a random id.
    if values.iter().all(|v| v.as_deref().unwrap_or("").is_empty()) {
        return None;
    }
    let mut h = Sha256::new();
    h.update(b"submarine-backfill-v1\0");
    h.update(table.as_bytes());
    for v in values {
        h.update(b"\0");
        h.update(v.as_deref().unwrap_or("").as_bytes());
    }
    Some(hex::encode(&h.finalize()[..16]))
}

/// One-time backfill: give a uuid + HLC stamp to every existing synced row that
/// predates the sync columns (i.e. `uuid IS NULL`). Idempotent. Returns whether
/// anything changed, so the caller can force a resave to persist the ids.
///
/// Both the id and the stamp are chosen so that adopting an OLD copy of a vault
/// is a safe, boring operation — see `derived_entity_uuid` and `BACKFILL_UAT`.
fn backfill_sync_columns(conn: &Connection, _hlc: &hlc::Hlc) -> Result<bool, String> {
    let mut changed = false;
    for table in SYNCED_TABLES {
        let pk = if *table == "monitor_configs" { "node_id" } else { "id" };
        let idcols = backfill_identity_cols(table);
        // monitor_configs inherits its server's identity; servers are backfilled
        // earlier in SYNCED_TABLES, so that uuid is already in place here.
        let select_ids = if *table == "monitor_configs" {
            "(SELECT s.uuid FROM servers s WHERE s.id = t.node_id)".to_string()
        } else if idcols.is_empty() {
            "NULL".to_string()
        } else {
            idcols.iter().map(|c| format!("t.{c}")).collect::<Vec<_>>().join(", ")
        };
        let ncols = if *table == "monitor_configs" || idcols.is_empty() { 1 } else { idcols.len() };

        // Snapshot the PKs + identity values first — can't hold the SELECT
        // statement open across the per-row UPDATE on the same connection.
        let rows: Vec<(i64, Vec<Option<String>>)> = {
            let mut stmt = conn
                .prepare(&format!(
                    "SELECT t.{pk}, {select_ids} FROM {table} t WHERE t.uuid IS NULL ORDER BY t.{pk}"
                ))
                .map_err(|e| format!("[SYNC] BACKFILL_SELECT {table}: {e}"))?;
            let mapped = stmt
                .query_map([], |r| {
                    let id: i64 = r.get(0)?;
                    let mut vals = Vec::with_capacity(ncols);
                    for i in 0..ncols {
                        // Read as a value first so INTEGER columns (servers.port)
                        // don't fail the String conversion.
                        vals.push(match r.get_ref(i + 1)? {
                            rusqlite::types::ValueRef::Null => None,
                            other => Some(match other {
                                rusqlite::types::ValueRef::Integer(n) => n.to_string(),
                                rusqlite::types::ValueRef::Real(f) => f.to_string(),
                                v => String::from_utf8_lossy(v.as_bytes().unwrap_or(b"")).into_owned(),
                            }),
                        });
                    }
                    Ok((id, vals))
                })
                .map_err(|e| format!("[SYNC] BACKFILL_QUERY {table}: {e}"))?;
            mapped.filter_map(|r| r.ok()).collect()
        };

        let mut used: std::collections::HashSet<String> = std::collections::HashSet::new();
        for (id, vals) in rows {
            // Derived id when the row has identifying content and no other row in
            // this table already claimed it; a random one otherwise. Falling back
            // costs us a duplicate on the next device, which is recoverable —
            // fusing two distinct rows would not be.
            let uuid = derived_entity_uuid(table, &vals)
                .filter(|u| !used.contains(u))
                .unwrap_or_else(new_entity_uuid);
            used.insert(uuid.clone());
            conn.execute(
                &format!("UPDATE {table} SET uuid=?1, updated_at=?2 WHERE {pk}=?3"),
                rusqlite::params![uuid, BACKFILL_UAT, id],
            )
            .map_err(|e| format!("[SYNC] BACKFILL_UPDATE {table}: {e}"))?;
            changed = true;
        }
    }
    Ok(changed)
}

/// Register the SQLite custom functions the auto-stamp triggers call. Must run
/// on every freshly-opened connection — custom functions are per-connection
/// state, not stored in the serialized DB, whereas the triggers (which call
/// them) ARE serialized and survive across opens. `hlc_now()` returns this
/// profile's next monotonic stamp; `sync_new_uuid()` mints a fresh row id.
fn register_sync_functions(conn: &Connection, hlc: &std::sync::Arc<hlc::Hlc>) -> Result<(), String> {
    use rusqlite::functions::FunctionFlags;
    let h = hlc.clone();
    conn.create_scalar_function("hlc_now", 0, FunctionFlags::empty(), move |_| Ok(h.tick()))
        .map_err(|e| format!("[SYNC] FN_HLC: {e}"))?;
    conn.create_scalar_function("sync_new_uuid", 0, FunctionFlags::empty(), move |_| Ok(new_entity_uuid()))
        .map_err(|e| format!("[SYNC] FN_UUID: {e}"))?;
    // Deterministic id for a row whose identity is really its parent's.
    // `monitor_configs` is 1:1 with a server, so two devices that each switch
    // monitoring on for the same server must arrive at the SAME id — otherwise
    // they'd be two unrelated configs fighting over one `node_id` primary key.
    // Hashed with the table name so it can never collide with the server's own
    // uuid in the cloud's record store.
    conn.create_scalar_function("sync_derived_uuid", 2, FunctionFlags::empty(), move |ctx| {
        let table = ctx.get::<String>(0).unwrap_or_default();
        let seed = ctx.get::<Option<String>>(1).ok().flatten();
        // No parent uuid to derive from (a server that predates the backfill) —
        // a random id is the safe fallback, same reasoning as the backfill's.
        Ok(derived_entity_uuid(&table, &[seed]).unwrap_or_else(new_entity_uuid))
    })
    .map_err(|e| format!("[SYNC] FN_DERIVED_UUID: {e}"))?;
    Ok(())
}

/// Create the tombstone side-table + the per-table auto-stamp triggers
/// (idempotent). This is the whole per-entity instrumentation, centralised:
///   - AFTER INSERT  → assign a uuid + HLC stamp (skipped when the row already
///     carries a uuid — i.e. the merge engine applying a remote insert).
///   - AFTER UPDATE  → bump the HLC, UNLESS the caller set `updated_at` itself
///     (again: the merge engine applying a remote change keeps the remote stamp).
///   - AFTER DELETE  → record a tombstone so the deletion propagates. Fires for
///     FK-cascade deletes too (monitor_configs), which the map flagged as the
///     one path that bypassed Rust. Rows are still HARD-deleted, so every
///     existing `SELECT` is untouched — the tombstone lives only in the side
///     table the sync layer reads.
/// `monitor_configs` gets a column-aware UPDATE guard so the per-open `paused`
/// reset (device-local housekeeping) never churns the stamp.
fn create_sync_triggers(conn: &Connection) -> Result<(), String> {
    conn.execute(
        "CREATE TABLE IF NOT EXISTS sync_tombstones (uuid TEXT PRIMARY KEY, entity_type TEXT NOT NULL, updated_at TEXT NOT NULL)",
        [],
    )
    .map_err(|e| format!("[SYNC] TOMBSTONE_TABLE: {e}"))?;
    // Device-local operational flags. `merge` is set to 1 while the sync engine
    // applies remote records, which the auto-stamp triggers check so they don't
    // overwrite the incoming HLC stamps with fresh local ones.
    conn.execute(
        "CREATE TABLE IF NOT EXISTS sync_flags (key TEXT PRIMARY KEY, val INTEGER NOT NULL)",
        [],
    )
    .map_err(|e| format!("[SYNC] FLAGS_TABLE: {e}"))?;
    // Ensure sync_meta exists before the triggers (which read editor_label from
    // it) are created — the convergence path also creates it, but tests call
    // create_sync_triggers directly.
    conn.execute(
        "CREATE TABLE IF NOT EXISTS sync_meta (key TEXT PRIMARY KEY, value TEXT NOT NULL)",
        [],
    )
    .map_err(|e| format!("[SYNC] SYNC_META_TABLE: {e}"))?;
    // Guard shared by the stamp/tombstone triggers: suppress them while merging.
    const GUARD: &str = "COALESCE((SELECT val FROM sync_flags WHERE key='merge'),0)=0";
    // The editor label stamped onto edited_by at mutation time (email when known,
    // else NULL). Kept as a subquery so it always reflects the latest value.
    const EDITOR: &str = "(SELECT value FROM sync_meta WHERE key='editor_label')";
    for t in SYNCED_TABLES {
        let au_extra = if *t == "monitor_configs" {
            " AND (NEW.enabled_metrics IS NOT OLD.enabled_metrics OR NEW.custom_metrics IS NOT OLD.custom_metrics OR NEW.deleted IS NOT OLD.deleted)"
        } else {
            ""
        };
        // A monitor config's identity is its server's, derived — see
        // `sync_derived_uuid`. Everything else mints a fresh random id.
        let new_uuid_expr = if *t == "monitor_configs" {
            "sync_derived_uuid('monitor_configs', (SELECT uuid FROM servers WHERE id = NEW.node_id))"
        } else {
            "sync_new_uuid()"
        };
        // Drop-then-create so the definition is always current across app
        // versions (CREATE IF NOT EXISTS would keep a stale earlier trigger).
        let ddl = format!(
            "DROP TRIGGER IF EXISTS {t}_sync_ai;
             DROP TRIGGER IF EXISTS {t}_sync_au;
             DROP TRIGGER IF EXISTS {t}_sync_ad;
             CREATE TRIGGER {t}_sync_ai AFTER INSERT ON {t} FOR EACH ROW WHEN NEW.uuid IS NULL AND {GUARD}
               BEGIN UPDATE {t} SET uuid = {new_uuid_expr}, updated_at = hlc_now(), edited_by = {EDITOR} WHERE rowid = NEW.rowid; END;
             CREATE TRIGGER {t}_sync_au AFTER UPDATE ON {t} FOR EACH ROW
               WHEN NEW.updated_at IS OLD.updated_at{au_extra} AND {GUARD}
               BEGIN UPDATE {t} SET updated_at = hlc_now(), edited_by = {EDITOR} WHERE rowid = NEW.rowid; END;
             CREATE TRIGGER {t}_sync_ad AFTER DELETE ON {t} FOR EACH ROW WHEN OLD.uuid IS NOT NULL AND {GUARD}
               BEGIN INSERT INTO sync_tombstones(uuid, entity_type, updated_at) VALUES (OLD.uuid, '{t}', hlc_now())
                     ON CONFLICT(uuid) DO UPDATE SET updated_at = excluded.updated_at, entity_type = excluded.entity_type; END;"
        );
        conn.execute_batch(&ddl)
            .map_err(|e| format!("[SYNC] TRIGGER {t}: {e}"))?;
        // Unique index on uuid enables ON CONFLICT(uuid) upserts in the merge
        // engine. NOT partial — SQLite treats NULLs as distinct, so pre-backfill
        // NULL uuids coexist fine, and a plain index (unlike a partial one) is a
        // valid ON CONFLICT target.
        conn.execute(
            &format!("CREATE UNIQUE INDEX IF NOT EXISTS ux_{t}_uuid ON {t}(uuid)"),
            [],
        )
        .map_err(|e| format!("[SYNC] UUID_INDEX {t}: {e}"))?;
    }
    Ok(())
}

#[cfg(test)]
mod sync_trigger_tests {
    use super::*;
    use rusqlite::Connection;

    fn setup() -> Connection {
        let conn = Connection::open_in_memory().unwrap();
        // Minimal stand-ins for the synced tables — only the columns the
        // triggers touch. monitor_configs keeps enabled_metrics/custom_metrics
        // so the column-aware UPDATE guard can be exercised.
        conn.execute_batch(
            "CREATE TABLE folders(id INTEGER PRIMARY KEY, name TEXT, uuid TEXT, updated_at TEXT, deleted INTEGER NOT NULL DEFAULT 0, edited_by TEXT);
             CREATE TABLE ssh_keys(id INTEGER PRIMARY KEY, name TEXT, uuid TEXT, updated_at TEXT, deleted INTEGER NOT NULL DEFAULT 0, edited_by TEXT);
             CREATE TABLE credentials(id INTEGER PRIMARY KEY, name TEXT, uuid TEXT, updated_at TEXT, deleted INTEGER NOT NULL DEFAULT 0, edited_by TEXT);
             CREATE TABLE servers(id INTEGER PRIMARY KEY, name TEXT, uuid TEXT, updated_at TEXT, deleted INTEGER NOT NULL DEFAULT 0, edited_by TEXT);
             CREATE TABLE commands(id INTEGER PRIMARY KEY, title TEXT, uuid TEXT, updated_at TEXT, deleted INTEGER NOT NULL DEFAULT 0, edited_by TEXT);
             CREATE TABLE notes(id INTEGER PRIMARY KEY, title TEXT, uuid TEXT, updated_at TEXT, deleted INTEGER NOT NULL DEFAULT 0, edited_by TEXT);
             CREATE TABLE monitor_configs(node_id INTEGER PRIMARY KEY, enabled_metrics TEXT, custom_metrics TEXT, paused INTEGER NOT NULL DEFAULT 1, uuid TEXT, updated_at TEXT, deleted INTEGER NOT NULL DEFAULT 0, edited_by TEXT);",
        ).unwrap();
        let hlc = std::sync::Arc::new(hlc::Hlc::new("testnode".into(), 0));
        register_sync_functions(&conn, &hlc).unwrap();
        create_sync_triggers(&conn).unwrap();
        conn
    }
    fn ua(conn: &Connection, name: &str) -> String {
        conn.query_row("SELECT updated_at FROM servers WHERE name=?1", [name], |r| r.get(0)).unwrap()
    }

    #[test]
    fn insert_auto_stamps_uuid_and_updated_at() {
        let conn = setup();
        conn.execute("INSERT INTO servers(name) VALUES('a')", []).unwrap();
        let (uuid, at): (Option<String>, Option<String>) = conn
            .query_row("SELECT uuid, updated_at FROM servers WHERE name='a'", [], |r| Ok((r.get(0)?, r.get(1)?)))
            .unwrap();
        assert!(uuid.as_deref().map(|s| !s.is_empty()).unwrap_or(false), "uuid must be stamped");
        assert!(at.as_deref().map(|s| !s.is_empty()).unwrap_or(false), "updated_at must be stamped");
    }

    #[test]
    fn edit_bumps_stamp_but_merge_apply_is_preserved() {
        let conn = setup();
        conn.execute("INSERT INTO servers(name) VALUES('a')", []).unwrap();
        let t1 = ua(&conn, "a");
        conn.execute("UPDATE servers SET name='b' WHERE name='a'", []).unwrap();
        let t2 = ua(&conn, "b");
        assert!(t2 > t1, "a normal edit must bump the stamp");
        // The merge engine applies a remote change by setting updated_at itself;
        // the trigger must NOT overwrite it with a fresh local stamp.
        conn.execute(
            "UPDATE servers SET name='c', updated_at='999999999999999:00000:remote' WHERE name='b'",
            [],
        ).unwrap();
        assert_eq!(ua(&conn, "c"), "999999999999999:00000:remote", "merge-applied stamp must survive");
    }

    #[test]
    fn delete_leaves_a_tombstone_and_hard_deletes() {
        let conn = setup();
        conn.execute("INSERT INTO servers(name) VALUES('a')", []).unwrap();
        let uuid: String = conn.query_row("SELECT uuid FROM servers WHERE name='a'", [], |r| r.get(0)).unwrap();
        conn.execute("DELETE FROM servers WHERE name='a'", []).unwrap();
        let tombs: i64 = conn
            .query_row("SELECT COUNT(*) FROM sync_tombstones WHERE uuid=?1 AND entity_type='servers'", [&uuid], |r| r.get(0))
            .unwrap();
        assert_eq!(tombs, 1, "delete must record a tombstone");
        let rows: i64 = conn.query_row("SELECT COUNT(*) FROM servers WHERE name='a'", [], |r| r.get(0)).unwrap();
        assert_eq!(rows, 0, "row must be hard-deleted so existing SELECTs are unaffected");
    }

    #[test]
    fn monitor_paused_reset_does_not_churn_but_real_change_stamps() {
        let conn = setup();
        conn.execute("INSERT INTO monitor_configs(node_id, enabled_metrics, custom_metrics) VALUES(1,'[]','[]')", []).unwrap();
        let t1: String = conn.query_row("SELECT updated_at FROM monitor_configs WHERE node_id=1", [], |r| r.get(0)).unwrap();
        conn.execute("UPDATE monitor_configs SET paused=1", []).unwrap();
        let t2: String = conn.query_row("SELECT updated_at FROM monitor_configs WHERE node_id=1", [], |r| r.get(0)).unwrap();
        assert_eq!(t1, t2, "device-local paused reset must not churn the sync stamp");
        conn.execute("UPDATE monitor_configs SET enabled_metrics='[\"cpu\"]' WHERE node_id=1", []).unwrap();
        let t3: String = conn.query_row("SELECT updated_at FROM monitor_configs WHERE node_id=1", [], |r| r.get(0)).unwrap();
        assert!(t3 > t2, "a real config change must stamp");
    }
}

// ---------------------------------------------------------------------------
// Sync engine: per-entity serialize (FK int -> uuid) + LWW merge apply
// ---------------------------------------------------------------------------

/// One record as it travels to/from the server: metadata in the clear (so the
/// server can LWW-order without decrypting) + an encrypted payload blob. A
/// tombstone is `deleted: true` with no blob.
#[derive(serde::Serialize, serde::Deserialize, Clone, Debug)]
pub struct SyncRecord {
    pub uuid: String,
    pub entity_type: String,
    pub updated_at: String,
    pub deleted: bool,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub blob: Option<String>,
}

struct Fk {
    key: &'static str,       // payload key holding the referenced row's uuid
    col: &'static str,       // local FK int column
    ref_table: &'static str, // table the FK points at
    /// An optional FK whose referent hasn't arrived yet is written NULL and
    /// repaired by the deferred fixup pass. A REQUIRED one can't be: for
    /// `monitor_configs.node_id` the foreign key IS the primary key, so writing
    /// NULL would have SQLite mint a fresh rowid and silently attach the config
    /// to a different server. The record is skipped instead — a monitor config
    /// without its server means nothing, and it arrives with the next sync once
    /// the server does.
    required: bool,
}
struct EntitySpec {
    table: &'static str,
    cols: &'static [&'static str], // content columns synced verbatim
    fks: &'static [Fk],
}

/// Applied in this order so most FK referents already exist on merge; the two
/// self-referential FKs (folders.parent_id, servers.jump_host_id) are resolved
/// in a deferred fixup pass afterwards.
// `edited_by` rides along as a normal column on every spec: the auto-stamp
// triggers set it to the current editor label at mutation time, so it flows
// through collect + apply for free and records WHO last changed each entity
// (zero-knowledge — it's inside the encrypted blob, never seen by the server).
const ENTITIES: &[EntitySpec] = &[
    EntitySpec { table: "ssh_keys", cols: &["name", "public_key", "private_key", "passphrase", "edited_by"], fks: &[] },
    EntitySpec { table: "folders", cols: &["name", "color", "edited_by"], fks: &[Fk { key: "parent_uuid", col: "parent_id", ref_table: "folders", required: false }] },
    EntitySpec { table: "credentials", cols: &["name", "auth_type", "username", "password", "edited_by"], fks: &[Fk { key: "key_uuid", col: "key_id", ref_table: "ssh_keys", required: false }] },
    EntitySpec {
        table: "servers",
        cols: &["name", "host", "port", "username", "password", "proxy_type", "proxy_host", "proxy_port", "tunnels", "auth_type", "autostart", "mirrors", "color", "notes", "run_on_connect", "position", "edited_by"],
        fks: &[
            Fk { key: "credential_uuid", col: "credential_id", ref_table: "credentials", required: false },
            Fk { key: "folder_uuid", col: "folder_id", ref_table: "folders", required: false },
            Fk { key: "key_uuid", col: "key_id", ref_table: "ssh_keys", required: false },
            Fk { key: "jump_uuid", col: "jump_host_id", ref_table: "servers", required: false },
        ],
    },
    EntitySpec { table: "commands", cols: &["title", "content", "edited_by"], fks: &[] },
    EntitySpec { table: "notes", cols: &["title", "body", "edited_by"], fks: &[] },
    // Must come after `servers`: its node_id is resolved from the server's uuid,
    // so the server has to already be in place when this is applied.
    //
    // `paused` is deliberately NOT synced. It records whether polling is running
    // on THIS device — pausing monitoring on the laptop shouldn't stop it on the
    // desktop — and the profile-open housekeeping resets it, which would
    // otherwise churn. The UPDATE trigger's column guard already limits stamping
    // to exactly the two columns below, so the two agree.
    EntitySpec {
        table: "monitor_configs",
        cols: &["enabled_metrics", "custom_metrics", "edited_by"],
        fks: &[Fk { key: "node_uuid", col: "node_id", ref_table: "servers", required: true }],
    },
];

/// What a synced column may hold, where SQLite won't check it: the list
/// readers (`get_servers` and the rest) take some columns as non-NULL text
/// and a server's port as a number, and one row that doesn't fit fails the
/// whole list, on every device the record reaches. A remote record is
/// checked against this before any of it is written. (A NULL in a NOT NULL
/// column fails the write itself, which skips the record just the same.)
#[derive(Clone, Copy)]
enum ColKind {
    /// Text, or NULL.
    Text,
    /// Text, never NULL: a list reader needs it.
    RequiredText,
    /// A whole number a list reads as 32 bits (a port), never NULL.
    Int32,
    /// The same, or NULL.
    OptionalInt32,
    /// A whole number (true/false count), or NULL.
    OptionalInt,
}

fn col_kind(table: &str, col: &str) -> ColKind {
    match (table, col) {
        ("ssh_keys", "name" | "public_key")
        | ("folders", "name")
        | ("credentials", "name" | "auth_type" | "username")
        | ("servers", "name" | "host")
        | ("commands", "title" | "content")
        | ("notes", "title" | "body") => ColKind::RequiredText,
        ("servers", "port") => ColKind::Int32,
        ("servers", "proxy_port") => ColKind::OptionalInt32,
        ("servers", "autostart" | "position") => ColKind::OptionalInt,
        _ => ColKind::Text,
    }
}

impl ColKind {
    fn accepts(self, v: Option<&serde_json::Value>) -> bool {
        use serde_json::Value;
        let int32 = |v: &Value| v.as_i64().is_some_and(|n| i32::try_from(n).is_ok());
        match (self, v) {
            (ColKind::Text, None | Some(Value::Null | Value::String(_))) => true,
            (ColKind::RequiredText, Some(Value::String(_))) => true,
            (ColKind::Int32, Some(v)) => int32(v),
            (ColKind::OptionalInt32, None | Some(Value::Null)) => true,
            (ColKind::OptionalInt32, Some(v)) => int32(v),
            (ColKind::OptionalInt, None | Some(Value::Null | Value::Bool(_))) => true,
            (ColKind::OptionalInt, Some(v)) => v.is_i64(),
            _ => false,
        }
    }
}

/// The most hex one record's blob may carry: the sync server's own limit
/// (2 MiB of hex, under 1 MiB of payload). Only a broken or hostile server
/// sends more.
const MAX_RECORD_BLOB_HEX: usize = 2 * 1024 * 1024;

/// The most a merge may grow a vault to: three quarters of what it can be
/// saved at, which leaves this device room for its own use. The server holds
/// an account to a few MB, so an honest one never comes near it.
const MERGE_MAX_BYTES: usize = VAULT_MAX_BYTES / 4 * 3;

/// AES-256-GCM a per-entity payload with the profile key; frame is `nonce || ct`
/// hex-encoded. Same key that protects the whole vault, so the server stays
/// zero-knowledge.
fn encrypt_entity(plaintext: &[u8], key: &[u8; 32]) -> Result<String, String> {
    let (ct, nonce) = encrypt_with_key(plaintext, key)?;
    let mut out = Vec::with_capacity(NONCE_LEN + ct.len());
    out.extend_from_slice(&nonce);
    out.extend_from_slice(&ct);
    Ok(hex::encode(out))
}
fn decrypt_entity(blob_hex: &str, key: &[u8; 32]) -> Result<Vec<u8>, String> {
    let raw = hex::decode(blob_hex).map_err(|e| format!("[SYNC] BLOB_HEX: {e}"))?;
    if raw.len() < NONCE_LEN + 16 {
        return Err("[SYNC] BLOB_TOO_SHORT".into());
    }
    decrypt_with_key(&raw[NONCE_LEN..], &raw[..NONCE_LEN], key)
}

fn json_to_sql(v: Option<&serde_json::Value>) -> Box<dyn rusqlite::types::ToSql> {
    use serde_json::Value;
    match v {
        None | Some(Value::Null) => Box::new(rusqlite::types::Null),
        Some(Value::String(s)) => Box::new(s.clone()),
        Some(Value::Bool(b)) => Box::new(*b as i64),
        Some(Value::Number(n)) => {
            if let Some(i) = n.as_i64() {
                Box::new(i)
            } else {
                Box::new(n.as_f64().unwrap_or(0.0))
            }
        }
        // arrays/objects (shouldn't occur — tunnels/mirrors are TEXT) → JSON text
        Some(other) => Box::new(other.to_string()),
    }
}

/// Serialize every synced entity + tombstone changed since `since` (empty = all)
/// into encrypted records. FK ints are translated to the referenced row's uuid
/// via SQL subqueries so the payload is portable across devices.
fn collect_local_records(conn: &Connection, key: &[u8; 32], since: &str) -> Result<Vec<SyncRecord>, String> {
    let mut out = Vec::new();
    for spec in ENTITIES {
        let mut pairs: Vec<String> = spec.cols.iter().map(|c| format!("'{c}', t.{c}")).collect();
        for fk in spec.fks {
            pairs.push(format!("'{}', (SELECT uuid FROM {} WHERE id = t.{})", fk.key, fk.ref_table, fk.col));
        }
        let sql = format!(
            "SELECT t.uuid, t.updated_at, json_object({}) FROM {} t WHERE t.uuid IS NOT NULL AND t.updated_at > ?1",
            pairs.join(", "),
            spec.table
        );
        let mut stmt = conn.prepare(&sql).map_err(|e| format!("[SYNC] SER_PREP {}: {e}", spec.table))?;
        let rows = stmt
            .query_map([since], |r| Ok((r.get::<_, String>(0)?, r.get::<_, String>(1)?, r.get::<_, String>(2)?)))
            .map_err(|e| format!("[SYNC] SER_QUERY {}: {e}", spec.table))?;
        for row in rows {
            let (uuid, updated_at, payload) = row.map_err(|e| format!("[SYNC] SER_ROW {}: {e}", spec.table))?;
            out.push(SyncRecord {
                uuid,
                entity_type: spec.table.to_string(),
                updated_at,
                deleted: false,
                blob: Some(encrypt_entity(payload.as_bytes(), key)?),
            });
        }
    }
    let mut stmt = conn
        .prepare("SELECT uuid, entity_type, updated_at FROM sync_tombstones WHERE updated_at > ?1")
        .map_err(|e| format!("[SYNC] SER_TOMB_PREP: {e}"))?;
    let rows = stmt
        .query_map([since], |r| Ok((r.get::<_, String>(0)?, r.get::<_, String>(1)?, r.get::<_, String>(2)?)))
        .map_err(|e| format!("[SYNC] SER_TOMB_QUERY: {e}"))?;
    for row in rows {
        let (uuid, entity_type, updated_at) = row.map_err(|e| format!("[SYNC] SER_TOMB_ROW: {e}"))?;
        out.push(SyncRecord { uuid, entity_type, updated_at, deleted: true, blob: None });
    }
    Ok(out)
}

/// Merge incoming records into the local vault, Last-Write-Wins per row. Runs
/// with the auto-stamp triggers suppressed so incoming HLC stamps are written
/// verbatim, and advances the local clock past everything seen.
fn apply_remote_records(conn: &Connection, key: &[u8; 32], records: &[SyncRecord], hlc: &hlc::Hlc) -> Result<(), String> {
    conn.execute("INSERT INTO sync_flags(key,val) VALUES('merge',1) ON CONFLICT(key) DO UPDATE SET val=1", [])
        .map_err(|e| format!("[SYNC] MERGE_ON: {e}"))?;
    let r = apply_remote_inner(conn, key, records, hlc, MERGE_MAX_BYTES);
    let _ = conn.execute("UPDATE sync_flags SET val=0 WHERE key='merge'", []);
    r
}

/// The id and stamp a record needs before the merge looks at it, by the
/// rules the sync server applies to everything it stores: an id of 1–64
/// lowercase hex, and a stamp a clock could have issued, not far ahead of
/// now (`Hlc::valid_remote`).
fn sane_record(rec: &SyncRecord) -> bool {
    (1..=64).contains(&rec.uuid.len())
        && rec.uuid.bytes().all(|b| matches!(b, b'0'..=b'9' | b'a'..=b'f'))
        && hlc::Hlc::valid_remote(&rec.updated_at)
}

/// The vault's size as it would be saved: its SQLite image, free pages and all.
fn vault_bytes(conn: &Connection) -> Result<usize, String> {
    let pages: i64 = conn
        .query_row("PRAGMA page_count", [], |r| r.get(0))
        .map_err(|e| format!("[SYNC] PAGE_COUNT: {e}"))?;
    let size: i64 = conn
        .query_row("PRAGMA page_size", [], |r| r.get(0))
        .map_err(|e| format!("[SYNC] PAGE_SIZE: {e}"))?;
    Ok((pages.max(0) as usize).saturating_mul(size.max(0) as usize))
}

/// Run `f` as one unit inside the merge's transaction. If it fails, whatever
/// it wrote is rolled back and the merge goes on without it: the inner
/// result. The outer one fails only when the savepoint itself does.
fn in_savepoint(conn: &Connection, f: impl FnOnce() -> Result<(), String>) -> Result<Result<(), String>, String> {
    conn.execute_batch("SAVEPOINT merge_record").map_err(|e| format!("[SYNC] SAVEPOINT: {e}"))?;
    let r = f();
    let end = if r.is_ok() { "RELEASE merge_record" } else { "ROLLBACK TO merge_record; RELEASE merge_record" };
    conn.execute_batch(end).map_err(|e| format!("[SYNC] SAVEPOINT_END: {e}"))?;
    Ok(r)
}

/// One deferred foreign-key repair: set `table.fk_col` for the row `uuid` to
/// whatever `ref_table.uuid = ref_uuid` resolves to once the batch is complete.
struct FkFixup {
    table: String,
    uuid: String,
    fk_col: String,
    ref_table: String,
    ref_uuid: String,
}

fn apply_remote_inner(
    conn: &Connection,
    key: &[u8; 32],
    records: &[SyncRecord],
    hlc: &hlc::Hlc,
    max_bytes: usize,
) -> Result<(), String> {
    // What the server wouldn't store doesn't get in here either. A stamp that
    // isn't one a clock could have issued, or sits far ahead of now, would win
    // LWW against every later edit and delete of its row; only a broken or
    // hostile server sends one.
    let (records, refused): (Vec<&SyncRecord>, Vec<&SyncRecord>) = records.iter().partition(|r| sane_record(r));
    if !refused.is_empty() {
        eprintln!("[SYNC] refused {} record(s) with a malformed id or stamp", refused.len());
    }
    for rec in &records {
        hlc.observe(hlc::Hlc::phys_of(&rec.updated_at));
    }
    // The whole merge runs inside ONE transaction: either every applicable record
    // lands or none does. A failure partway (an I/O error, a commit that won't go
    // through) can never leave the vault half-merged — on any early return `tx`
    // drops uncommitted and SQLite rolls the batch back. This is what keeps a bad
    // sync from corrupting local data.
    let tx = conn.unchecked_transaction().map_err(|e| format!("[SYNC] TX_BEGIN: {e}"))?;
    let size_before = vault_bytes(&tx)?;
    // FKs to re-resolve once the whole batch has landed. `ref_table` has to ride
    // along: the lookup used to read `SELECT id FROM {table}` — the row's OWN
    // table — which was only ever correct because the sole queued FKs were the
    // self-referential ones (folders.parent_id, servers.jump_host_id), where the
    // two tables happen to be the same. Any cross-table FK looked up the uuid in
    // entirely the wrong table, found nothing, and NULLed a perfectly good link.
    let mut fk_fixups: Vec<FkFixup> = Vec::new();
    // Per-record application is best-effort: a single record that won't decrypt
    // or parse — a corrupt or hostile blob from a broken/compromised server — is
    // logged and skipped, never aborting the merge. One poison record must not be
    // able to block every OTHER record (or every future sync) from applying.
    let mut skipped = refused.len();
    // In a shared profile, whatever a record newly sets running by itself
    // (commands on connect, autostart, forwards, monitor commands) is held
    // until this device's user allows it — see approvals.rs. Holding is part
    // of the merge's transaction: if it can't be recorded, nothing lands.
    let shared = approvals::ready(&tx) && approvals::profile_is_shared(&tx);
    for spec in ENTITIES {
        let watch = shared && approvals::watches(spec.table);
        for rec in records.iter().filter(|r| !r.deleted && r.entity_type == spec.table) {
            let before = if watch { approvals::snapshot(&tx, spec.table, &rec.uuid) } else { None };
            if let Err(e) = apply_entity(&tx, key, spec, rec, &mut fk_fixups) {
                skipped += 1;
                eprintln!("[SYNC] skipped record uuid={} type={}: {}", rec.uuid, rec.entity_type, e);
                continue;
            }
            if watch {
                approvals::hold_changes(&tx, spec.table, &rec.uuid, before.as_ref())?;
            }
        }
    }
    // In a shared profile, a sync that would delete much of it at once, or an
    // SSH key, waits for this device's user (approvals::hold_deletions).
    let tombstones: Vec<&SyncRecord> = records.iter().filter(|r| r.deleted).copied().collect();
    let held = if shared { approvals::hold_deletions(&tx, &tombstones)? } else { Default::default() };
    for rec in tombstones.iter().filter(|r| !held.contains(&r.uuid)) {
        if let Err(e) = in_savepoint(&tx, || apply_tombstone(&tx, rec))? {
            skipped += 1;
            eprintln!("[SYNC] skipped tombstone uuid={} type={}: {}", rec.uuid, rec.entity_type, e);
        }
    }
    // Re-resolve every optional FK against the FINAL state of the batch, now that
    // both the entities and the tombstones have landed.
    for f in fk_fixups {
        let id: Option<i64> = tx
            .query_row(
                &format!("SELECT id FROM {} WHERE uuid=?1", f.ref_table),
                [&f.ref_uuid],
                |r| r.get(0),
            )
            .ok();
        if let Err(e) = tx.execute(
            &format!("UPDATE {} SET {}=?1 WHERE uuid=?2", f.table, f.fk_col),
            rusqlite::params![id, f.uuid],
        ) {
            eprintln!("[SYNC] fk fixup skipped {}.{} uuid={}: {}", f.table, f.fk_col, f.uuid, e);
        }
    }
    // Not toward the size the vault can no longer be saved or opened at. An
    // honest server never sends that much, so none of it lands.
    let size_after = vault_bytes(&tx)?;
    if size_after > max_bytes && size_after > size_before {
        return Err(format!(
            "[SYNC] TOO_LARGE: what the server sent would grow this profile past {} MiB, so none of it was applied.",
            max_bytes / (1024 * 1024)
        ));
    }
    tx.commit().map_err(|e| format!("[SYNC] TX_COMMIT: {e}"))?;
    if skipped > 0 {
        eprintln!("[SYNC] merge committed with {skipped} record(s) skipped");
    }
    Ok(())
}

fn apply_entity(conn: &Connection, key: &[u8; 32], spec: &EntitySpec, rec: &SyncRecord, fk_fixups: &mut Vec<FkFixup>) -> Result<(), String> {
    // LWW: keep local if it's newer-or-equal. A deleted row is hard-deleted, so
    // its tombstone carries its only surviving stamp — it has to count as the
    // local side of the comparison. Without it, a batch collected before a
    // delete (sync drops the lock for the network leg, so the user can delete
    // mid-flight) comes back still carrying the row as live, finds no live row
    // to compare against, and re-inserts it — secrets and all.
    let local_ua: Option<String> = conn
        .query_row(&format!("SELECT updated_at FROM {} WHERE uuid=?1", spec.table), [&rec.uuid], |r| r.get(0))
        .ok();
    let tomb_ua: Option<String> = conn
        .query_row(
            "SELECT updated_at FROM sync_tombstones WHERE uuid=?1 AND entity_type=?2",
            rusqlite::params![&rec.uuid, spec.table],
            |r| r.get(0),
        )
        .ok();
    if [local_ua.as_deref(), tomb_ua.as_deref()]
        .into_iter()
        .flatten()
        .any(|l| l >= rec.updated_at.as_str())
    {
        return Ok(());
    }
    let blob = rec.blob.as_deref().ok_or("[SYNC] ENTITY_NO_BLOB")?;
    if blob.len() > MAX_RECORD_BLOB_HEX {
        return Err("[SYNC] RECORD_TOO_LARGE".into());
    }
    let plain = decrypt_entity(blob, key)?;
    let payload: serde_json::Value = serde_json::from_slice(&plain).map_err(|e| format!("[SYNC] PAYLOAD_JSON: {e}"))?;
    let obj = payload.as_object().ok_or("[SYNC] PAYLOAD_NOT_OBJ")?;
    if let Some(c) = spec.cols.iter().find(|c| !col_kind(spec.table, c).accepts(obj.get(**c))) {
        return Err(format!("[SYNC] BAD_VALUE {}.{c}", spec.table));
    }

    let mut columns: Vec<String> = vec!["uuid".into(), "updated_at".into(), "deleted".into()];
    let mut params: Vec<Box<dyn rusqlite::types::ToSql>> =
        vec![Box::new(rec.uuid.clone()), Box::new(rec.updated_at.clone()), Box::new(rec.deleted as i64)];
    // Set when the incoming record omits `position` (a pre-0.3.5 peer). We then
    // preserve the LOCAL rank on the UPDATE arm below instead of overwriting it
    // with the coerced 0 — otherwise an ordinary field edit synced from an old
    // peer would silently reset a manual drag-order on this device.
    let mut preserve_local_position = false;
    for c in spec.cols {
        columns.push((*c).into());
        let val = obj.get(*c);
        // Backward-compat shim: `position` was added to servers' synced cols in
        // 0.3.5. Records from a pre-0.3.5 peer omit the key entirely, so
        // json_to_sql(None) would bind an explicit SQL NULL — which violates
        // `position INTEGER NOT NULL` and makes the whole upsert fail, silently
        // skipping the server row (its SSH credentials with it). Coerce a
        // missing/null position to its default 0 (so an INSERT lands the row)
        // and remember to keep the local rank on UPDATE. Only needed for
        // NOT-NULL columns added to an already-syncing entity after sync shipped.
        if *c == "position" && matches!(val, None | Some(serde_json::Value::Null)) {
            params.push(Box::new(0i64));
            preserve_local_position = true;
        } else {
            params.push(json_to_sql(val));
        }
    }
    // Queued only once the row itself is written (below): the repair pass
    // runs after the whole batch, so a record that fails here would still
    // have set its links on the row it failed to replace.
    let mut fixups: Vec<FkFixup> = Vec::new();
    for fk in spec.fks {
        let ref_uuid = obj.get(fk.key).and_then(|v| v.as_str());
        let id: Option<i64> = match ref_uuid {
            None => None,
            Some(ru) => {
                let found: Option<i64> = conn
                    .query_row(&format!("SELECT id FROM {} WHERE uuid=?1", fk.ref_table), [ru], |r| r.get(0))
                    .ok();
                if found.is_none() && fk.required {
                    // Can't write this row at all without its referent, and a
                    // later fixup can't rescue it either (the column is the
                    // primary key). Drop the record; it'll come back on the
                    // next sync once the referent lands. Required FKs are also
                    // never queued below — if the referent is deleted later in
                    // this same batch, SQLite's ON DELETE CASCADE removes this
                    // row outright, which is the right answer for a config that
                    // only exists to describe its parent.
                    return Ok(());
                }
                if !fk.required {
                    // Queue EVERY optional FK, not just the ones that failed to
                    // resolve. Tombstones are applied after entities, so a
                    // referent that was still present a moment ago can be gone by
                    // the end of the batch — two devices doing ordinary
                    // independent work (one edits a server, the other deletes
                    // that server's jump host) is enough. Only re-checking the
                    // initially-unresolved ones left the rest pointing at a row
                    // that no longer exists, permanently and silently: the link
                    // surfaced much later as "未找到跳板机", or as a
                    // folder that had quietly lost its parent.
                    fixups.push(FkFixup {
                        table: spec.table.to_string(),
                        uuid: rec.uuid.clone(),
                        fk_col: fk.col.to_string(),
                        ref_table: fk.ref_table.to_string(),
                        ref_uuid: ru.to_string(),
                    });
                }
                found
            }
        };
        // A required FK with no uuid in the payload at all is equally unusable.
        if id.is_none() && fk.required {
            return Ok(());
        }
        columns.push(fk.col.into());
        params.push(Box::new(id));
    }

    let placeholders = std::iter::repeat_n("?", columns.len()).collect::<Vec<_>>().join(",");
    let update_set: Vec<String> = columns
        .iter()
        .filter(|c| c.as_str() != "uuid")
        .map(|c| {
            if c.as_str() == "position" && preserve_local_position {
                // Peer didn't know about `position` — don't clobber our local
                // drag-order with the coerced 0; keep the existing row value.
                format!("position={}.position", spec.table)
            } else {
                format!("{c}=excluded.{c}")
            }
        })
        .collect();
    let sql = format!(
        "INSERT INTO {} ({}) VALUES ({}) ON CONFLICT(uuid) DO UPDATE SET {}",
        spec.table,
        columns.join(","),
        placeholders,
        update_set.join(",")
    );
    let refs: Vec<&dyn rusqlite::types::ToSql> = params.iter().map(|b| b.as_ref()).collect();
    conn.execute(&sql, refs.as_slice()).map_err(|e| format!("[SYNC] UPSERT {}: {e}", spec.table))?;
    fk_fixups.extend(fixups);
    Ok(())
}

/// One remote deletion. It can write three things (unlink, delete, record the
/// tombstone), so the caller runs it in a savepoint: a delete that fails
/// leaves no tombstone claiming it happened.
fn apply_tombstone(conn: &Connection, rec: &SyncRecord) -> Result<(), String> {
    // Only tombstones for known entity types are meaningful here.
    let Some(spec) = ENTITIES.iter().find(|s| s.table == rec.entity_type) else {
        return Ok(());
    };
    let local: Option<(i64, Option<String>)> = conn
        .query_row(
            &format!("SELECT rowid, updated_at FROM {} WHERE uuid=?1", spec.table),
            [&rec.uuid],
            |r| Ok((r.get(0)?, r.get(1)?)),
        )
        .ok();
    match local {
        Some((id, local_ua)) if local_ua.as_deref().unwrap_or("") < rec.updated_at.as_str() => {
            // Unlink what points at it first: those links would block the
            // delete (a folder that still holds a server on this device) or
            // be left dangling. A local repair, like the fixup pass: the merge
            // guard keeps the triggers from stamping it as an edit.
            for s in ENTITIES {
                for fk in s.fks.iter().filter(|fk| fk.ref_table == spec.table && !fk.required) {
                    conn.execute(&format!("UPDATE {} SET {}=NULL WHERE {}=?1", s.table, fk.col, fk.col), [id])
                        .map_err(|e| format!("[SYNC] TOMB_UNLINK {}.{}: {e}", s.table, fk.col))?;
                }
            }
            // Merge guard is on → the AFTER DELETE trigger won't create a
            // competing tombstone; the explicit upsert below stands.
            conn.execute(&format!("DELETE FROM {} WHERE uuid=?1", spec.table), [&rec.uuid])
                .map_err(|e| format!("[SYNC] TOMB_DELETE: {e}"))?;
        }
        Some(_) => {}
        None => {
            // Nothing here to delete. Only a tombstone already here (this
            // device deleted the row too) is kept current: a new one would
            // just be pushed back on every sync, forever, however many a
            // hostile peer sends.
            let known: bool = conn
                .query_row("SELECT 1 FROM sync_tombstones WHERE uuid=?1", [&rec.uuid], |_| Ok(()))
                .is_ok();
            if !known {
                return Ok(());
            }
        }
    }
    conn.execute(
        "INSERT INTO sync_tombstones(uuid, entity_type, updated_at) VALUES (?1,?2,?3)
         ON CONFLICT(uuid) DO UPDATE SET updated_at=excluded.updated_at, entity_type=excluded.entity_type
         WHERE excluded.updated_at > sync_tombstones.updated_at",
        rusqlite::params![rec.uuid, rec.entity_type, rec.updated_at],
    )
    .map_err(|e| format!("[SYNC] TOMB_UPSERT: {e}"))?;
    Ok(())
}

#[derive(serde::Serialize)]
struct SyncReport {
    pushed: usize,
    pulled: usize,
    /// The shared profile has a new key waiting for the user's OK
    /// (`accept_share_key`); until then nothing is pushed.
    key_change: bool,
}

// A personal profile's DEK, sealed under the profile's OWN password, rides the
// normal /sync stream as one reserved record. That's what lets a fresh device
// bootstrap a personal profile with nothing but the profile password: sign in,
// pull, derive the key from the password + the salt carried in this record, and
// unseal the DEK — no whole-vault blob download, no separate recovery secret,
// no server changes (the /sync table accepts any entity_type ≤24 chars). The
// server stores it as an opaque blob like every other record, so zero-knowledge
// still holds — cracking it costs the same Argon2id work as the vault itself.
// It never matches an ENTITIES spec, so apply naturally ignores it; only the
// restore path reads it. The updated_at is a fixed low sentinel so it sorts
// first and never churns the LWW upsert.
//
// Blob layout (hex): version(1) ‖ salt(SALT_LEN) ‖ nonce(NONCE_LEN) ‖
// AES-256-GCM(master_key, dek). `master_key` is Argon2id(password, salt) — the
// exact same derivation as the on-disk vault — so a device that knows the
// password reproduces it from the embedded salt and decrypts the DEK.
const ESCROW_ETYPE: &str = "dek_escrow";
const ESCROW_UUID: &str = "0000000000000000000000000000dead";
const ESCROW_UAT: &str = "000000000000000:00000:0";
// Version byte fronting the escrow blob. `2` = password-sealed (the format
// below). `1` was the retired identity-sealed sealed-box; no such records were
// ever published to any live account, so there is nothing to migrate — but the
// byte lets the reader reject an unknown/legacy shape cleanly instead of
// mis-parsing it.
const PW_ESCROW_VERSION: u8 = 2;

/// Build the reserved DEK-escrow record: the profile DEK sealed under the
/// profile's master key (Argon2id of its password). `salt` is the vault's own
/// KDF salt, embedded so a fresh device can re-derive `master_key` from just the
/// password.
fn build_pw_escrow_record(
    master_key: &[u8; 32],
    salt: &[u8; SALT_LEN],
    dek: &[u8; 32],
) -> Result<SyncRecord, String> {
    let (ct, nonce) = encrypt_with_key(dek, master_key)?;
    let mut blob = Vec::with_capacity(1 + SALT_LEN + NONCE_LEN + ct.len());
    blob.push(PW_ESCROW_VERSION);
    blob.extend_from_slice(salt);
    blob.extend_from_slice(&nonce);
    blob.extend_from_slice(&ct);
    Ok(SyncRecord {
        uuid: ESCROW_UUID.to_string(),
        entity_type: ESCROW_ETYPE.to_string(),
        updated_at: ESCROW_UAT.to_string(),
        deleted: false,
        blob: Some(hex::encode(blob)),
    })
}

/// Recover a profile's DEK from a password-sealed escrow blob. Runs Argon2id, so
/// callers hand it to the blocking pool. Returns `DECRYPT_FAILURE` (via
/// `decrypt_with_key`) when the password is wrong — the GCM tag won't verify.
fn open_pw_escrow(blob_hex: &str, password: &str) -> Result<[u8; 32], String> {
    let raw = hex::decode(blob_hex).map_err(|_| "[SYNC] ESCROW_BAD_HEX")?;
    let head = 1 + SALT_LEN + NONCE_LEN;
    if raw.len() < head + 16 {
        return Err("[SYNC] ESCROW_TOO_SHORT".into());
    }
    if raw[0] != PW_ESCROW_VERSION {
        return Err(format!("[SYNC] ESCROW_BAD_VERSION: {}", raw[0]));
    }
    let salt = &raw[1..1 + SALT_LEN];
    let nonce = &raw[1 + SALT_LEN..head];
    let ct = &raw[head..];
    let mk = Zeroizing::new(derive_key(password, salt)?);
    let dek_vec = Zeroizing::new(decrypt_with_key(ct, nonce, &mk)?);
    if dek_vec.len() != 32 {
        return Err("[SYNC] ESCROW_BAD_DEK_LEN".into());
    }
    let mut dek = [0u8; 32];
    dek.copy_from_slice(&dek_vec);
    Ok(dek)
}

// ---- which server a profile syncs with ---------------------------------------
//
// The sync server can be self-hosted (`cloud_config`), so a profile is tied to
// the server it syncs with, in sync_meta 'cloud_server'. Without that, signing
// in to another server would push every profile there on the next automatic
// sync, password-sealed key escrow included, and a shared profile would take
// whatever key the new server handed back for its share id. A profile from
// before the server could be chosen has no row and syncs with the default
// server; a new profile has an empty one until its first sync links it.

/// The server the open profile syncs with; `None` when it isn't linked yet.
fn profile_server(conn: &Connection) -> Option<String> {
    match conn.query_row("SELECT value FROM sync_meta WHERE key='cloud_server'", [], |r| r.get::<_, String>(0)) {
        Ok(server) if server.is_empty() => None,
        Ok(server) => Some(server),
        Err(_) => Some(cloud::CLOUD_API_BASE.to_string()),
    }
}

/// Refuses to sync the open profile with `base` when it is linked to another
/// server. `Ok(true)`: it isn't linked yet, and the caller links it once the
/// server has taken it (`link_profile_server`).
fn check_profile_server(conn: &Connection, base: &str) -> Result<bool, String> {
    match profile_server(conn) {
        None => Ok(true),
        Some(server) if server == base => Ok(false),
        Some(server) => Err(format!(
            "[SYNC] OTHER_SERVER: this profile syncs with {}, not with {}. Switch the sync server back, or move this profile from its Profile panel.",
            cloud_config::host_of(&server),
            cloud_config::host_of(base)
        )),
    }
}

fn link_profile_server(conn: &Connection, base: &str) -> Result<(), String> {
    conn.execute(
        "INSERT INTO sync_meta(key,value) VALUES('cloud_server',?1) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        [base],
    )
    .map_err(|e| format!("[SYNC] SET_CLOUD_SERVER: {e}"))?;
    Ok(())
}

#[cfg(test)]
mod profile_server_tests {
    use super::*;

    fn meta() -> Connection {
        let conn = Connection::open_in_memory().unwrap();
        conn.execute("CREATE TABLE sync_meta (key TEXT PRIMARY KEY, value TEXT NOT NULL)", []).unwrap();
        conn
    }

    const OWN: &str = "https://sync.example.com";

    // A profile from before the server could be chosen syncs with the default
    // server, and only there.
    #[test]
    fn no_row_means_the_default_server() {
        let conn = meta();
        assert_eq!(profile_server(&conn).as_deref(), Some(cloud::CLOUD_API_BASE));
        assert_eq!(check_profile_server(&conn, cloud::CLOUD_API_BASE), Ok(false));
        let err = check_profile_server(&conn, OWN).unwrap_err();
        assert!(err.starts_with("[SYNC] OTHER_SERVER") && err.contains("submarine.sinaxhpm.com"), "{}", err);
    }

    // A new profile goes with the first server it syncs with, and then stays.
    #[test]
    fn a_new_profile_links_on_its_first_sync() {
        let conn = meta();
        conn.execute("INSERT INTO sync_meta(key,value) VALUES('cloud_server','')", []).unwrap();
        assert_eq!(profile_server(&conn), None);
        assert_eq!(check_profile_server(&conn, OWN), Ok(true));
        link_profile_server(&conn, OWN).unwrap();
        assert_eq!(check_profile_server(&conn, OWN), Ok(false));
        assert!(check_profile_server(&conn, cloud::CLOUD_API_BASE).is_err());
        // Moving it is an explicit step.
        link_profile_server(&conn, cloud::CLOUD_API_BASE).unwrap();
        assert_eq!(check_profile_server(&conn, cloud::CLOUD_API_BASE), Ok(false));
        assert!(check_profile_server(&conn, OWN).is_err());
    }
}

/// One full per-entity sync of the OPEN profile: collect every local record,
/// exchange with the server (which LWW-merges + returns its view), merge the
/// server's records back, and persist. Full-set each call (the dataset is
/// small — a handful of servers/credentials); a `since` watermark is a later
/// optimisation, not needed for correctness.
#[tauri::command]
async fn sync_now(
    app: tauri::AppHandle,
    db_state: tauri::State<'_, DbState>,
    cloud: tauri::State<'_, std::sync::Arc<cloud::CloudState>>,
) -> Result<SyncReport, String> {
    let session = cloud.session().await?;
    sync_with(&app, &db_state, &cloud, &session, None).await
}

/// `sync_now` over a session the caller already holds, so a command that also
/// did other calls first keeps all of them on one server. `pinned` is the
/// generation of the profile the caller means (see `DbState::generation`),
/// when it has one; the sync refuses to run on any other.
async fn sync_with(
    app: &tauri::AppHandle,
    db_state: &DbState,
    cloud: &cloud::CloudState,
    session: &cloud::Session,
    pinned: Option<u64>,
) -> Result<SyncReport, String> {
    // Checked before anything goes out, the shared key refresh below included:
    // a server the profile isn't linked to could hand back a key it knows,
    // and every record pushed after that would be readable to it.
    //
    // `generation` pins the profile this sync is for: everything written
    // back after a network wait checks it first, so a reply that arrives
    // after the user locked this profile (or opened another) is dropped
    // instead of landing in whatever profile is open by then.
    let (profile, unlinked, generation) = {
        let conn_g = db_state.conn.lock().map_err(|_| "[STATE] LOCK_CONN")?;
        let conn = conn_g.as_ref().ok_or("[STATE] DB_NOT_OPEN")?;
        let generation = db_state.generation_now();
        if let Some(pinned) = pinned {
            db_state.still_open(pinned)?;
        }
        let profile = db_state
            .active_profile
            .lock()
            .map_err(|_| "[STATE] LOCK_PROFILE")?
            .clone()
            .ok_or("[SYNC] NO_PROFILE_OPEN")?;
        (profile, check_profile_server(conn, session.base())?, generation)
    };

    // A shared profile's key can change under us: the owner rotates it whenever
    // a member is revoked, so the copy cached at import time goes stale. Fetch
    // it BEFORE serialising anything. A new key isn't used until the user
    // accepts it, though (`note_share_key`): until then this device only
    // pulls. Cheap (a primary-key point lookup) and best-effort — offline or a
    // hiccup just means we sync with what we have, exactly as before this
    // existed.
    let existing_share: Option<String> = {
        let conn_g = db_state.conn.lock().map_err(|_| "[STATE] LOCK_CONN")?;
        let conn = conn_g.as_ref().ok_or("[STATE] DB_NOT_OPEN")?;
        db_state.still_open(generation)?;
        conn.query_row("SELECT value FROM sync_meta WHERE key='share_id'", [], |r| r.get(0)).ok()
    };
    if let Some(sid) = &existing_share {
        if let Some((_, my_secret)) = cloud.identity().await {
            if let Ok(grant) = cloud::share_dek(app, cloud, session, sid).await {
                if let Ok(raw) = hex::decode(&grant.sealed_dek) {
                    if let Ok(opened) = identity::unseal(&my_secret, &raw) {
                        if opened.len() == 32 {
                            let conn_g = db_state.conn.lock().map_err(|_| "[STATE] LOCK_CONN")?;
                            let conn = conn_g.as_ref().ok_or("[STATE] DB_NOT_OPEN")?;
                            db_state.still_open(generation)?;
                            note_share_key(conn, &opened)?;
                        }
                    }
                }
            }
        }
    }

    // Snapshot the profile DEK + clock and serialise local records, then DROP
    // all locks before the network round-trip (never hold a std Mutex across
    // .await). Per-entity blobs are encrypted with the DEK — NOT the vault
    // master key — so the same records can be shared with other members, who
    // hold the DEK via a sealed grant without ever knowing this vault's
    // password. The DEK is created + persisted at profile-open, so it already
    // exists here; get_or_create is a defensive fallback only.
    let (records, dek, hlc, share, cloud_profile, master_key, salt, key_change) = {
        let conn_g = db_state.conn.lock().map_err(|_| "[STATE] LOCK_CONN")?;
        let conn = conn_g.as_ref().ok_or("[STATE] DB_NOT_OPEN")?;
        db_state.still_open(generation)?;
        let hlc_g = db_state.hlc.lock().map_err(|_| "[STATE] LOCK_HLC")?;
        let hlc = hlc_g.as_ref().ok_or("[SYNC] NO_HLC")?.clone();
        // The session master key + salt (retained in DbState for the vault
        // re-save) let us seal the DEK under the profile's own password with no
        // extra KDF work — copied out here so no guard is held across the await.
        let master_key = db_state
            .master_key
            .lock()
            .map_err(|_| "[STATE] LOCK_KEY")?
            .as_ref()
            .map(|k| **k);
        let salt = *db_state.salt.lock().map_err(|_| "[STATE] LOCK_SALT")?;
        let (dek, _created) = get_or_create_dek(conn)?;
        let records = collect_local_records(conn, &dek, "")?;
        // If this profile is shared, sync_meta carries its share_id + my role;
        // that routes the exchange to /shares/sync instead of personal /sync.
        let share_id: Option<String> = conn
            .query_row("SELECT value FROM sync_meta WHERE key='share_id'", [], |r| r.get(0))
            .ok();
        let share_role: Option<String> = conn
            .query_row("SELECT value FROM sync_meta WHERE key='share_role'", [], |r| r.get(0))
            .ok();
        // Personal /sync is keyed by profile name. A restored profile may carry
        // a different LOCAL name than its cloud key, so it records the cloud
        // name in sync_meta; fall back to the local name for everything else.
        let cloud_profile: String = conn
            .query_row("SELECT value FROM sync_meta WHERE key='cloud_profile'", [], |r| r.get(0))
            .unwrap_or_else(|_| profile.clone());
        // Fail CLOSED on a missing role. The push gate below is `role != "user"`,
        // so defaulting to an empty string would have granted write access to a
        // profile whose role row went missing — the least safe reading of "we
        // don't know". A viewer that should have been an editor is a visible,
        // fixable annoyance; an editor that should have been a viewer is not.
        let share = share_id.map(|s| (s, share_role.unwrap_or_else(|| "user".to_string())));
        let key_change = conn
            .query_row("SELECT 1 FROM sync_meta WHERE key='pending_dek'", [], |_| Ok(()))
            .is_ok();
        (records, dek, hlc, share, cloud_profile, master_key, salt, key_change)
    };

    // Shared profile → /shares/sync (role-gated). A viewer ('user') pushes
    // nothing — it can only pull, so sending records would just 403. Neither
    // does a device whose share has a new key waiting for the user's OK: no
    // one else can read a push sealed with the old key, and the new one may
    // not be the owner's.
    let (remote, pushed) = if let Some((share_id, role)) = &share {
        let to_push: &[SyncRecord] = if role == "user" || key_change { &[] } else { &records };
        let remote = cloud::shared_sync_exchange(app, cloud, session, share_id, "", to_push).await?;
        (remote, to_push.len())
    } else {
        // Personal profile: publish (or refresh) the DEK escrow alongside the
        // data so any device that knows this profile's password can bring it
        // down. Sealed under the profile's OWN master key — always-on, no
        // sharing identity or separate recovery secret required.
        let mut to_push = records.clone();
        if let (Some(mk), Some(salt)) = (master_key, salt) {
            to_push.push(build_pw_escrow_record(&mk, &salt, &dek)?);
        }
        // Send the local display name so the server can label this partition —
        // essential once `cloud_profile` is an opaque UUID for new profiles. For
        // legacy `main` the name equals the partition, so it's a harmless echo.
        let remote =
            cloud::sync_exchange(app, cloud, session, &cloud_profile, "", &to_push, Some(profile.as_str())).await?;
        (remote, to_push.len())
    };
    let pulled = remote.len();

    {
        let conn_g = db_state.conn.lock().map_err(|_| "[STATE] LOCK_CONN")?;
        let conn = conn_g.as_ref().ok_or("[STATE] DB_NOT_OPEN")?;
        db_state.still_open(generation)?;
        apply_remote_records(conn, &dek, &remote, &hlc)?;
        if unlinked {
            link_profile_server(conn, session.base())?;
        }
    }
    // Persist the merged vault so the applied changes survive a restart.
    save_vault_async(db_state).await?;
    Ok(SyncReport { pushed, pulled, key_change })
}

#[derive(serde::Serialize)]
struct RecentEdit {
    name: String,
    edited_by: String,
    updated_at: String,
}

#[derive(serde::Serialize)]
struct SyncDiff {
    in_sync: usize,
    needs_push: usize,
    needs_pull: usize,
    /// Names of local nodes whose local copy differs from the cloud (either an
    /// unpushed local edit, or a cloud copy at a different stamp). Capped.
    out_of_sync_nodes: Vec<String>,
}

#[derive(serde::Serialize)]
struct ProfileSyncStats {
    /// Total synced records held locally (live rows + tombstones).
    total_records: usize,
    /// On-disk size of this profile's encrypted vault, for heaviness awareness.
    vault_bytes: u64,
    /// Last few edited nodes with who touched them — read straight from the
    /// local vault, no network. Always present.
    recent_edits: Vec<RecentEdit>,
    /// Live comparison against the cloud. `None` when offline / not signed in /
    /// never synced — the panel then shows recent edits only.
    diff: Option<SyncDiff>,
}

/// Read-only sync + activity snapshot for the Profile panel. The recent-edits
/// list is local and instant; the cloud diff is a best-effort dry run (an empty
/// push that mutates nothing, then a local comparison) and is omitted on any
/// network/auth failure rather than erroring the whole call.
#[tauri::command]
async fn profile_sync_stats(
    app: tauri::AppHandle,
    db_state: tauri::State<'_, DbState>,
    cloud: tauri::State<'_, std::sync::Arc<cloud::CloudState>>,
) -> Result<ProfileSyncStats, String> {
    let profile = db_state
        .active_profile
        .lock()
        .map_err(|_| "[STATE] LOCK_PROFILE")?
        .clone()
        .ok_or("[SYNC] NO_PROFILE_OPEN")?;
    let session = cloud.session().await.ok();

    // Local snapshot under the lock: records, DEK, routing, recent edits, and a
    // uuid→name map for servers so the diff can name what's out of sync.
    let (local, dek, share, cloud_profile, recent_edits, server_names, comparable) = {
        let conn_g = db_state.conn.lock().map_err(|_| "[STATE] LOCK_CONN")?;
        let conn = conn_g.as_ref().ok_or("[STATE] DB_NOT_OPEN")?;
        let (dek, _created) = get_or_create_dek(conn)?;
        // The cloud copy is only compared on the server this profile syncs
        // with; one that hasn't synced yet has nothing there to compare.
        let comparable = session
            .as_ref()
            .is_some_and(|s| matches!(check_profile_server(conn, s.base()), Ok(false)));
        let local = collect_local_records(conn, &dek, "")?;
        let share_id: Option<String> = conn
            .query_row("SELECT value FROM sync_meta WHERE key='share_id'", [], |r| r.get(0))
            .ok();
        let share_role: Option<String> = conn
            .query_row("SELECT value FROM sync_meta WHERE key='share_role'", [], |r| r.get(0))
            .ok();
        let cloud_profile: String = conn
            .query_row("SELECT value FROM sync_meta WHERE key='cloud_profile'", [], |r| r.get(0))
            .unwrap_or_else(|_| profile.clone());

        let mut recent_edits = Vec::new();
        {
            let mut stmt = conn
                .prepare(
                    "SELECT name, COALESCE(edited_by,''), COALESCE(updated_at,'') FROM servers \
                     WHERE deleted=0 AND updated_at IS NOT NULL ORDER BY updated_at DESC LIMIT 5",
                )
                .map_err(|e| format!("[SYNC] RECENT_PREP: {e}"))?;
            let rows = stmt
                .query_map([], |r| {
                    Ok(RecentEdit {
                        name: r.get(0)?,
                        edited_by: r.get(1)?,
                        updated_at: r.get(2)?,
                    })
                })
                .map_err(|e| format!("[SYNC] RECENT_QUERY: {e}"))?;
            for row in rows {
                recent_edits.push(row.map_err(|e| format!("[SYNC] RECENT_ROW: {e}"))?);
            }
        }

        let mut server_names: std::collections::HashMap<String, String> = std::collections::HashMap::new();
        {
            let mut stmt = conn
                .prepare("SELECT uuid, name FROM servers WHERE uuid IS NOT NULL AND deleted=0")
                .map_err(|e| format!("[SYNC] NAMES_PREP: {e}"))?;
            let rows = stmt
                .query_map([], |r| Ok((r.get::<_, String>(0)?, r.get::<_, String>(1)?)))
                .map_err(|e| format!("[SYNC] NAMES_QUERY: {e}"))?;
            for row in rows {
                let (u, n) = row.map_err(|e| format!("[SYNC] NAMES_ROW: {e}"))?;
                server_names.insert(u, n);
            }
        }

        (
            local,
            dek,
            // Fail CLOSED on a missing role. The push gate below is `role != "user"`,
        // so defaulting to an empty string would have granted write access to a
        // profile whose role row went missing — the least safe reading of "we
        // don't know". A viewer that should have been an editor is a visible,
        // fixable annoyance; an editor that should have been a viewer is not.
        share_id.map(|s| (s, share_role.unwrap_or_else(|| "user".to_string()))),
            cloud_profile,
            recent_edits,
            server_names,
            comparable,
        )
    };

    let total_records = local.len();
    let vault_bytes = profile_path(&app, &profile)
        .ok()
        .and_then(|p| std::fs::metadata(&p).ok())
        .map(|m| m.len())
        .unwrap_or(0);
    let _ = &dek; // reserved for future decrypt of incoming node names

    // Best-effort dry run: pure pull (empty push mutates nothing on the server).
    let diff = {
        let pulled = match &session {
            Some(session) if comparable => {
                if let Some((share_id, _role)) = &share {
                    cloud::shared_sync_exchange(&app, &cloud, session, share_id, "", &[]).await
                } else {
                    cloud::sync_exchange(&app, &cloud, session, &cloud_profile, "", &[], None).await
                }
            }
            _ => Err(String::new()),
        };
        match pulled {
            Ok(server) => {
                use std::collections::HashMap;
                let local_map: HashMap<&str, (&str, &str)> = local
                    .iter()
                    .map(|r| (r.uuid.as_str(), (r.updated_at.as_str(), r.entity_type.as_str())))
                    .collect();
                let server_map: HashMap<&str, (&str, &str)> = server
                    .iter()
                    // The reserved escrow record is bookkeeping, not user data.
                    .filter(|r| r.entity_type != ESCROW_ETYPE)
                    .map(|r| (r.uuid.as_str(), (r.updated_at.as_str(), r.entity_type.as_str())))
                    .collect();

                let mut in_sync = 0usize;
                let mut needs_push = 0usize;
                let mut needs_pull = 0usize;
                let mut out: Vec<String> = Vec::new();

                let mut uuids: std::collections::HashSet<&str> = std::collections::HashSet::new();
                uuids.extend(local_map.keys());
                uuids.extend(server_map.keys());
                for u in uuids {
                    let l = local_map.get(u).map(|(ua, _)| *ua).unwrap_or("");
                    let s = server_map.get(u).map(|(ua, _)| *ua).unwrap_or("");
                    let is_server = local_map.get(u).map(|(_, et)| *et == "servers").unwrap_or(false)
                        || server_map.get(u).map(|(_, et)| *et == "servers").unwrap_or(false);
                    if l == s {
                        in_sync += 1;
                    } else {
                        if l > s {
                            needs_push += 1;
                        } else {
                            needs_pull += 1;
                        }
                        if is_server && out.len() < 20 {
                            if let Some(name) = server_names.get(u) {
                                out.push(name.clone());
                            }
                        }
                    }
                }
                Some(SyncDiff { in_sync, needs_push, needs_pull, out_of_sync_nodes: out })
            }
            Err(_) => None,
        }
    };

    Ok(ProfileSyncStats { total_records, vault_bytes, recent_edits, diff })
}

// ===========================================================================
// Profile sharing commands (E2E). Identity lives in the cloud session; the
// per-profile DEK is what actually gets shared, sealed to each member.
// ===========================================================================

fn hex_to_32(s: &str) -> Result<[u8; 32], String> {
    let raw = hex::decode(s).map_err(|_| "[SHARE] BAD_HEX".to_string())?;
    if raw.len() != 32 {
        return Err("[SHARE] BAD_KEY_LEN".into());
    }
    let mut out = [0u8; 32];
    out.copy_from_slice(&raw);
    Ok(out)
}

/// The open profile's share is `share_id`, and this device is its owner.
/// What an owner does to a share (invite, remove a member, replace its key)
/// works on that profile's own key, so it has to be that profile that's open.
fn own_share(conn: &Connection, share_id: &str) -> Result<(), String> {
    let meta = |k: &str| conn.query_row("SELECT value FROM sync_meta WHERE key=?1", [k], |r| r.get::<_, String>(0)).ok();
    if meta("share_id").as_deref() == Some(share_id) && meta("share_role").as_deref() == Some("owner") {
        Ok(())
    } else {
        Err("[SHARE] NOT_OPEN_PROFILE: open the shared profile, as its owner, to do this.".into())
    }
}

/// A key lookup's answer is for the account that was asked about. If the
/// server named another one, the profile key would be sealed to that one.
fn same_account(asked: &str, answered: &str) -> bool {
    asked.trim().eq_ignore_ascii_case(answered.trim())
}

/// What the server says a shared profile's key is now. The key in use changes
/// only when the user accepts a new one (`accept_share_key`); until then it
/// waits as `pending_dek`, and the sync only pulls. The owner replaces the key
/// after removing someone, but a server could just as well send a key of its
/// own, and everything pushed with it would then be readable to the server.
fn note_share_key(conn: &Connection, key: &[u8]) -> Result<(), String> {
    let fresh = hex::encode(key);
    let current: Option<String> =
        conn.query_row("SELECT value FROM sync_meta WHERE key='dek'", [], |r| r.get(0)).ok();
    match current.as_deref() {
        // Nothing to compare it with: the share's first key, as at import.
        None => conn.execute("INSERT INTO sync_meta(key,value) VALUES('dek',?1)", [&fresh]),
        Some(c) if c == fresh => conn.execute("DELETE FROM sync_meta WHERE key='pending_dek'", []),
        Some(_) => conn.execute(
            "INSERT INTO sync_meta(key,value) VALUES('pending_dek',?1) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            [&fresh],
        ),
    }
    .map_err(|e| format!("[SHARE] NOTE_KEY: {e}"))?;
    Ok(())
}

/// A short fingerprint of a share key, for people to compare: the owner's
/// Profile panel shows the key's, a member's prompt shows a new key's. A
/// truncated hash of a random 256-bit key gives nothing of the key away.
fn key_fingerprint(key_hex: &str) -> Option<String> {
    use sha2::Digest as _;
    let key = hex::decode(key_hex).ok()?;
    let mut h = sha2::Sha256::new();
    h.update(b"submarine-share-key-fingerprint-v1\0");
    h.update(&key);
    let d = h.finalize();
    Some(
        d[..8]
            .chunks(2)
            .map(|c| format!("{:02X}{:02X}", c[0], c[1]))
            .collect::<Vec<_>>()
            .join("-"),
    )
}

/// Each member's sharing key as it was when this device invited them, per
/// share. Device-local, never synced. When the share's key is replaced after a
/// removal, a member whose key changed since isn't given the new one: their
/// account may have been taken over, and the owner invites them again if the
/// change is expected.
fn create_share_pins(conn: &Connection) -> Result<(), String> {
    conn.execute(
        "CREATE TABLE IF NOT EXISTS share_member_keys (share_id TEXT NOT NULL, email TEXT NOT NULL, public_key TEXT NOT NULL, PRIMARY KEY(share_id, email))",
        [],
    )
    .map_err(|e| format!("[SHARE] PINS_TABLE: {e}"))?;
    Ok(())
}

fn pin_member_key(conn: &Connection, share_id: &str, email: &str, public_key: &str) -> Result<(), String> {
    conn.execute(
        "INSERT INTO share_member_keys(share_id,email,public_key) VALUES(?1,?2,?3)
         ON CONFLICT(share_id,email) DO UPDATE SET public_key=excluded.public_key",
        rusqlite::params![share_id, email.trim().to_ascii_lowercase(), public_key.to_ascii_lowercase()],
    )
    .map_err(|e| format!("[SHARE] PIN: {e}"))?;
    Ok(())
}

/// A member who didn't get the share's new key, and why: `key_changed` (their
/// sharing key isn't the one they were invited with), `other_account` (the
/// server answered for someone else), `no_key`, `weak_key` or `upload_failed`.
#[derive(serde::Serialize)]
struct LeftOut {
    email: String,
    reason: &'static str,
}

#[derive(serde::Serialize)]
struct ShareKeyState {
    /// The fingerprint of the shared profile's key.
    current: Option<String>,
    /// The fingerprint of a new key waiting for the user's OK.
    pending: Option<String>,
}

/// The open profile's share key, and a new one waiting for the user's OK, as
/// fingerprints. Nothing for a profile that isn't shared.
#[tauri::command]
async fn share_key_state(db_state: tauri::State<'_, DbState>) -> Result<ShareKeyState, String> {
    let conn_g = db_state.conn.lock().map_err(|_| "[STATE] LOCK_CONN")?;
    let conn = conn_g.as_ref().ok_or("[STATE] DB_NOT_OPEN")?;
    let meta = |k: &str| conn.query_row("SELECT value FROM sync_meta WHERE key=?1", [k], |r| r.get::<_, String>(0)).ok();
    if meta("share_id").is_none() {
        return Ok(ShareKeyState { current: None, pending: None });
    }
    Ok(ShareKeyState {
        current: meta("dek").as_deref().and_then(key_fingerprint),
        pending: meta("pending_dek").as_deref().and_then(key_fingerprint),
    })
}

/// Use the new key the server says the open shared profile has (see
/// `note_share_key`): the user's call, made after comparing its fingerprint
/// with the owner's. The next sync uploads again, with it.
#[tauri::command]
async fn accept_share_key(db_state: tauri::State<'_, DbState>) -> Result<(), String> {
    {
        let conn_g = db_state.conn.lock().map_err(|_| "[STATE] LOCK_CONN")?;
        let conn = conn_g.as_ref().ok_or("[STATE] DB_NOT_OPEN")?;
        let pending: String = conn
            .query_row("SELECT value FROM sync_meta WHERE key='pending_dek'", [], |r| r.get(0))
            .map_err(|_| "[SHARE] NO_KEY_CHANGE: there's no new key waiting.")?;
        let tx = conn.unchecked_transaction().map_err(|e| format!("[SHARE] TX: {e}"))?;
        tx.execute(
            "INSERT INTO sync_meta(key,value) VALUES('dek',?1) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            [&pending],
        )
        .map_err(|e| format!("[SHARE] SET_DEK: {e}"))?;
        tx.execute("DELETE FROM sync_meta WHERE key='pending_dek'", [])
            .map_err(|e| format!("[SHARE] CLEAR_PENDING: {e}"))?;
        tx.commit().map_err(|e| format!("[SHARE] TX_COMMIT: {e}"))?;
    }
    save_vault_async(&db_state).await
}

#[cfg(test)]
mod share_binding_tests {
    use super::*;

    // Owner actions work on the open profile's own key: refused for any other
    // share, and for a share this device is only a member of.
    #[test]
    fn owner_actions_need_the_open_profiles_own_share() {
        let conn = Connection::open_in_memory().unwrap();
        conn.execute("CREATE TABLE sync_meta (key TEXT PRIMARY KEY, value TEXT NOT NULL)", []).unwrap();
        assert!(own_share(&conn, "s1").is_err(), "not shared at all");
        conn.execute("INSERT INTO sync_meta VALUES('share_id','s1'),('share_role','editor')", []).unwrap();
        assert!(own_share(&conn, "s1").is_err(), "a member, not the owner");
        conn.execute("UPDATE sync_meta SET value='owner' WHERE key='share_role'", []).unwrap();
        assert!(own_share(&conn, "s2").is_err(), "another share");
        assert!(own_share(&conn, "s1").is_ok());
    }

    // A key from the server other than the one in use waits for the user's OK,
    // and the key in use stays. The same key again ends the wait.
    #[test]
    fn a_new_share_key_waits_for_the_users_ok() {
        let conn = Connection::open_in_memory().unwrap();
        conn.execute("CREATE TABLE sync_meta (key TEXT PRIMARY KEY, value TEXT NOT NULL)", []).unwrap();
        let meta = |k: &str| conn.query_row("SELECT value FROM sync_meta WHERE key=?1", [k], |r| r.get::<_, String>(0)).ok();
        note_share_key(&conn, &[1u8; 32]).unwrap();
        assert_eq!(meta("dek"), Some(hex::encode([1u8; 32])), "the share's first key is taken");
        note_share_key(&conn, &[2u8; 32]).unwrap();
        assert_eq!(meta("dek"), Some(hex::encode([1u8; 32])), "the key in use stays");
        assert_eq!(meta("pending_dek"), Some(hex::encode([2u8; 32])));
        note_share_key(&conn, &[1u8; 32]).unwrap();
        assert_eq!(meta("pending_dek"), None, "the server agrees again");
    }

    #[test]
    fn key_fingerprints_are_short_stable_and_differ() {
        let a = key_fingerprint(&hex::encode([1u8; 32])).unwrap();
        assert_eq!(a.len(), "XXXX-XXXX-XXXX-XXXX".len());
        assert_eq!(Some(a.clone()), key_fingerprint(&hex::encode([1u8; 32])));
        assert_ne!(Some(a), key_fingerprint(&hex::encode([2u8; 32])));
        assert_eq!(key_fingerprint("not hex"), None);
    }

    #[test]
    fn a_lookup_has_to_answer_for_the_account_asked_about() {
        assert!(same_account("Bob@Example.com ", "bob@example.com"));
        assert!(!same_account("bob@example.com", "mallory@example.com"));
        assert!(!same_account("bob@example.com", ""));
    }
}

#[derive(serde::Serialize)]
struct IdentityStatus {
    exists_on_server: bool,
    unlocked: bool,
    public_key: Option<String>,
}

/// Is a sharing identity set up (server) and/or unlocked (this session)?
#[tauri::command]
async fn identity_status(
    app: tauri::AppHandle,
    cloud: tauri::State<'_, std::sync::Arc<cloud::CloudState>>,
) -> Result<IdentityStatus, String> {
    let unlocked = cloud.identity().await;
    if let Some((pubk, _)) = unlocked {
        return Ok(IdentityStatus { exists_on_server: true, unlocked: true, public_key: Some(hex::encode(pubk)) });
    }
    // Not unlocked — ask the server whether a key exists (requires being signed in).
    let Ok(session) = cloud.session().await else {
        return Ok(IdentityStatus { exists_on_server: false, unlocked: false, public_key: None });
    };
    let keys = cloud::fetch_my_keys(&app, &cloud, &session).await?;
    Ok(IdentityStatus { exists_on_server: keys.exists, unlocked: false, public_key: keys.public_key })
}

/// Set up (first time) or unlock (already exists) the sharing identity from the
/// user's encryption passphrase. Never overwrites an existing key — a wrong
/// passphrase errors instead, so a real key with live grants is never orphaned
/// by a typo. Use `reset_identity` to deliberately regenerate.
#[tauri::command]
async fn setup_identity(
    app: tauri::AppHandle,
    cloud: tauri::State<'_, std::sync::Arc<cloud::CloudState>>,
    enc_passphrase: String,
) -> Result<IdentityStatus, String> {
    if enc_passphrase.is_empty() {
        return Err("[SHARE] EMPTY_PASSPHRASE".into());
    }
    let session = cloud.session().await?;
    let existing = cloud::fetch_my_keys(&app, &cloud, &session).await?;
    if existing.exists {
        let salt_hex = existing.enc_salt.ok_or("[SHARE] MISSING_SALT")?;
        let wrapped = existing.wrapped_privkey.ok_or("[SHARE] MISSING_WRAPPED")?;
        let pub_hex = existing.public_key.ok_or("[SHARE] MISSING_PUB")?;
        let salt = hex::decode(&salt_hex).map_err(|_| "[SHARE] BAD_SALT")?;
        let secret = identity::unwrap_secret(&enc_passphrase, &salt, &wrapped).map_err(|_| {
            "[SHARE] WRONG_PASSPHRASE: that passphrase doesn't match your sharing identity. If you forgot it, reset your identity (regenerates keys — you'll need to re-share)."
        })?;
        if hex::encode(identity::public_of(&secret)) != pub_hex {
            return Err("[SHARE] KEY_MISMATCH: stored identity is inconsistent — reset your identity to regenerate.".into());
        }
        cloud.set_identity(identity::public_of(&secret), secret).await;
        return Ok(IdentityStatus { exists_on_server: true, unlocked: true, public_key: Some(pub_hex) });
    }
    // First-time setup — generate, wrap, publish. The strength floor belongs
    // HERE, not at the top of the function: this one command serves both
    // "pick your sharing passphrase" and "unlock with the one you already have",
    // and the caller can't tell which until `fetch_my_keys` answers. Checking
    // length before that branch would mean a raised floor (or any future client
    // that provisioned an identity under different rules) rejecting a passphrase
    // that genuinely unwraps a published key — locking someone out of shares
    // they own over a rule that only ever applied at sign-up.
    if enc_passphrase.chars().count() < 8 {
        return Err("[SHARE] WEAK_PASSPHRASE: use at least 8 characters".into());
    }
    let kp = identity::generate_keypair();
    let mut salt = [0u8; 16];
    rand::rng().fill_bytes(&mut salt);
    let wrapped = identity::wrap_secret(&enc_passphrase, &salt, &kp.secret)?;
    cloud::publish_identity(&app, &cloud, &session, &hex::encode(kp.public), &wrapped, &hex::encode(salt)).await?;
    cloud.set_identity(kp.public, kp.secret).await;
    Ok(IdentityStatus { exists_on_server: true, unlocked: true, public_key: Some(hex::encode(kp.public)) })
}

/// Deliberately regenerate the sharing identity (e.g. forgotten passphrase).
/// Rotates the published key; grants sealed to the OLD key stop working, so the
/// caller must re-share afterwards. Overwrites unconditionally.
#[tauri::command]
async fn reset_identity(
    app: tauri::AppHandle,
    cloud: tauri::State<'_, std::sync::Arc<cloud::CloudState>>,
    enc_passphrase: String,
) -> Result<IdentityStatus, String> {
    if enc_passphrase.chars().count() < 8 {
        return Err("[SHARE] WEAK_PASSPHRASE: use at least 8 characters".into());
    }
    let session = cloud.session().await?;
    let kp = identity::generate_keypair();
    let mut salt = [0u8; 16];
    rand::rng().fill_bytes(&mut salt);
    let wrapped = identity::wrap_secret(&enc_passphrase, &salt, &kp.secret)?;
    cloud::publish_identity(&app, &cloud, &session, &hex::encode(kp.public), &wrapped, &hex::encode(salt)).await?;
    cloud.set_identity(kp.public, kp.secret).await;
    Ok(IdentityStatus { exists_on_server: true, unlocked: true, public_key: Some(hex::encode(kp.public)) })
}

#[derive(serde::Serialize)]
struct ShareResult {
    share_id: String,
}

/// Owner: turn the OPEN profile into a shared profile. Seals the profile DEK to
/// my own public key and records the share_id locally.
#[tauri::command]
async fn share_current_profile(
    app: tauri::AppHandle,
    db_state: tauri::State<'_, DbState>,
    cloud: tauri::State<'_, std::sync::Arc<cloud::CloudState>>,
    name: String,
) -> Result<ShareResult, String> {
    let name = name.trim().to_string();
    if name.is_empty() || name.chars().count() > 64 {
        return Err("[SHARE] BAD_NAME: 1-64 characters".into());
    }
    let (my_pub, _) = cloud.identity().await.ok_or("[SHARE] IDENTITY_LOCKED: set up your sharing identity first")?;
    let session = cloud.session().await?;
    let (dek, unlinked, generation) = {
        let conn_g = db_state.conn.lock().map_err(|_| "[STATE] LOCK_CONN")?;
        let conn = conn_g.as_ref().ok_or("[STATE] DB_NOT_OPEN")?;
        // A profile is shared on the server it syncs with, or on the one in
        // use if it hasn't synced yet.
        let unlinked = check_profile_server(conn, session.base())?;
        // Only the UI's hidden button stopped this from running twice. Called
        // again on an already-shared profile it would mint a SECOND share_id,
        // overwrite the local one, and orphan the first — leaving its members
        // syncing against a share this device no longer knows exists, and which
        // nobody can revoke or delete any more.
        let already: Option<String> = conn
            .query_row("SELECT value FROM sync_meta WHERE key='share_id'", [], |r| r.get(0))
            .ok();
        if already.is_some() {
            return Err("[SHARE] ALREADY_SHARED: this profile is already shared — stop sharing first if you want a new share.".into());
        }
        (get_or_create_dek(conn)?.0, unlinked, db_state.generation_now())
    };
    let sealed_self = hex::encode(identity::seal_to(&my_pub, &dek)?);
    let share_id = new_entity_uuid(); // 32 hex — within the server's {16,64}
    cloud::create_share(&app, &cloud, &session, &share_id, &name, &sealed_self).await?;
    {
        let conn_g = db_state.conn.lock().map_err(|_| "[STATE] LOCK_CONN")?;
        let conn = conn_g.as_ref().ok_or("[STATE] DB_NOT_OPEN")?;
        // The share holds THIS profile's key; recording it in another profile
        // opened meanwhile would mark that one shared under a key it doesn't use.
        db_state.still_open(generation)?;
        if unlinked {
            link_profile_server(conn, session.base())?;
        }
        conn.execute(
            "INSERT INTO sync_meta(key,value) VALUES('share_id',?1) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            [&share_id],
        )
        .map_err(|e| format!("[SHARE] STORE_SHARE_ID: {e}"))?;
        // Remembered so a later key rotation can re-create the share record with
        // its own name — /shares/create upserts the name, so passing a guess
        // would quietly rename the share for every member.
        conn.execute(
            "INSERT INTO sync_meta(key,value) VALUES('share_name',?1) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            [&name],
        )
        .map_err(|e| format!("[SHARE] STORE_SHARE_NAME: {e}"))?;
        conn.execute(
            "INSERT INTO sync_meta(key,value) VALUES('share_role','owner') ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            [],
        )
        .map_err(|e| format!("[SHARE] STORE_ROLE: {e}"))?;
    }
    save_vault_async(&db_state).await?;
    Ok(ShareResult { share_id })
}

#[derive(serde::Serialize)]
struct InviteResult {
    email: String,
}

/// Owner: invite `email` to the open profile's share at `role` (editor|user).
/// Seals this profile's own key to the invitee's public key, never a key the
/// server hands back; the server's copy of my own grant only has to agree.
#[tauri::command]
async fn invite_to_share(
    app: tauri::AppHandle,
    db_state: tauri::State<'_, DbState>,
    cloud: tauri::State<'_, std::sync::Arc<cloud::CloudState>>,
    share_id: String,
    email: String,
    role: String,
) -> Result<InviteResult, String> {
    if role != "editor" && role != "user" {
        return Err("[SHARE] BAD_ROLE: role must be 'editor' or 'user'".into());
    }
    let (_, my_secret) = cloud.identity().await.ok_or("[SHARE] IDENTITY_LOCKED")?;
    let session = cloud.session().await?;
    let (dek, generation) = {
        let conn_g = db_state.conn.lock().map_err(|_| "[STATE] LOCK_CONN")?;
        let conn = conn_g.as_ref().ok_or("[STATE] DB_NOT_OPEN")?;
        own_share(conn, &share_id)?;
        let dek_hex: String = conn
            .query_row("SELECT value FROM sync_meta WHERE key='dek'", [], |r| r.get(0))
            .map_err(|_| "[SHARE] NO_DEK")?;
        (hex_to_32(&dek_hex)?, db_state.generation_now())
    };
    // My own grant on the server has to hold the same key. If it doesn't, the
    // key changed since this device last synced, or the server's copy isn't
    // the one I made: a newcomer given this key couldn't read the share.
    let mine = cloud::share_dek(&app, &cloud, &session, &share_id).await?;
    let on_server = identity::unseal(&my_secret, &hex::decode(&mine.sealed_dek).map_err(|_| "[SHARE] BAD_GRANT")?)
        .map_err(|_| "[SHARE] UNSEAL_SELF: cannot open your own grant — your identity may have changed")?;
    if on_server.as_slice() != dek.as_slice() {
        return Err("[SHARE] KEY_MISMATCH: this profile's key isn't the one on the server. Sync the profile, then invite again.".into());
    }
    let info = cloud::lookup_pubkey(&app, &cloud, &session, &email)
        .await?
        .ok_or("[SHARE] NO_ACCOUNT: that email hasn't set up sharing yet")?;
    if !same_account(&email, &info.email) {
        return Err("[SHARE] WRONG_ACCOUNT: the server answered for another account".into());
    }
    let invitee_pub = hex_to_32(&info.public_key)?;
    let sealed = hex::encode(identity::seal_to(&invitee_pub, &dek)?);
    cloud::invite_member(&app, &cloud, &session, &share_id, &email, &role, &sealed).await?;
    // The key they were invited with (see create_share_pins). The invite has
    // gone through either way, so a failure here is only logged: with no pin,
    // their key is taken as it is the next time the share's key is replaced.
    let pinned = (|| -> Result<(), String> {
        let conn_g = db_state.conn.lock().map_err(|_| "[STATE] LOCK_CONN")?;
        let conn = conn_g.as_ref().ok_or("[STATE] DB_NOT_OPEN")?;
        db_state.still_open(generation)?;
        pin_member_key(conn, &share_id, &email, &info.public_key)
    })();
    match pinned {
        Ok(()) => {
            if let Err(e) = save_vault_async(&db_state).await {
                eprintln!("[SHARE] invite: saving the member's key failed: {e}");
            }
        }
        Err(e) => eprintln!("[SHARE] invite: the member's key wasn't kept: {e}"),
    }
    Ok(InviteResult { email: info.email })
}

/// Every share I'm a member of.
#[tauri::command]
async fn list_shares(
    app: tauri::AppHandle,
    cloud: tauri::State<'_, std::sync::Arc<cloud::CloudState>>,
) -> Result<Vec<cloud::ShareInfo>, String> {
    let session = cloud.session().await?;
    cloud::list_shares(&app, &cloud, &session).await
}

/// The member roster of a share I belong to.
#[tauri::command]
async fn share_member_list(
    app: tauri::AppHandle,
    cloud: tauri::State<'_, std::sync::Arc<cloud::CloudState>>,
    share_id: String,
) -> Result<Vec<cloud::MemberInfo>, String> {
    let session = cloud.session().await?;
    cloud::share_members(&app, &cloud, &session, &share_id).await
}

#[derive(serde::Serialize)]
struct AcceptResult {
    role: String,
}

/// Accept a pending invite. Verifies I can unseal the DEK with my identity, then
/// records the share locally. (Materialising it as a syncable local profile is
/// wired in S3c.)
#[tauri::command]
async fn accept_share(
    app: tauri::AppHandle,
    cloud: tauri::State<'_, std::sync::Arc<cloud::CloudState>>,
    share_id: String,
) -> Result<AcceptResult, String> {
    let (_, my_secret) = cloud.identity().await.ok_or("[SHARE] IDENTITY_LOCKED: unlock your sharing identity first")?;
    let session = cloud.session().await?;
    let resp = cloud::accept_share(&app, &cloud, &session, &share_id).await?;
    let dek = identity::unseal(&my_secret, &hex::decode(&resp.sealed_dek).map_err(|_| "[SHARE] BAD_GRANT")?)
        .map_err(|_| "[SHARE] UNSEAL_FAILED: this invite wasn't sealed to your current identity")?;
    if dek.len() != 32 {
        return Err("[SHARE] BAD_DEK_LEN".into());
    }
    Ok(AcceptResult { role: resp.role })
}

/// Invitee: materialise an accepted share as a local profile and pull its data.
/// Creates a fresh local vault (encrypted at rest with `vault_password`), sets
/// its DEK to the shared data-key unsealed from my grant, records the share,
/// then syncs to populate it. The vault password is local-only and unrelated to
/// the DEK, so each member protects their on-disk copy with their own password.
#[tauri::command]
async fn import_shared_profile(
    app: tauri::AppHandle,
    db_state: tauri::State<'_, DbState>,
    cloud: tauri::State<'_, std::sync::Arc<cloud::CloudState>>,
    share_id: String,
    local_name: String,
    vault_password: String,
) -> Result<SyncReport, String> {
    let (_, my_secret) = cloud.identity().await.ok_or("[SHARE] IDENTITY_LOCKED: unlock your sharing identity first")?;
    let session = cloud.session().await?;
    let mine = cloud::share_dek(&app, &cloud, &session, &share_id).await?;
    let dek_vec = identity::unseal(&my_secret, &hex::decode(&mine.sealed_dek).map_err(|_| "[SHARE] BAD_GRANT")?)
        .map_err(|_| "[SHARE] UNSEAL_FAILED: this share wasn't sealed to your identity")?;
    if dek_vec.len() != 32 {
        return Err("[SHARE] BAD_DEK_LEN".into());
    }
    let dek_hex = hex::encode(&dek_vec);

    // Create the local vault (fresh profile) — same steps as create_profile.
    validate_profile_name(&local_name)?;
    if vault_password.is_empty() {
        return Err("密码不能为空".into());
    }
    let dir = profiles_dir(&app)?;
    fs::create_dir_all(&dir).map_err(|e| format!("[FILE] MKDIR_FAILED: {}", e))?;
    if profile_path(&app, &local_name)?.exists() {
        return Err(format!("档案“{}”已存在", local_name));
    }
    *db_state.active_profile.lock().map_err(|_| "[STATE] LOCK_FAILED")? = Some(local_name.clone());
    // setup_master_db consumes a State handle; hand it a fresh one from `app` so
    // our own `db_state` stays usable for the sync_meta writes + sync below.
    // `opened` pins the new profile: the writes and the sync below go to it
    // and nowhere else.
    let opened = {
        use tauri::Manager as _;
        match setup_master_db_inner(app.clone(), vault_password, app.state::<DbState>(), true).await {
            Ok(generation) => generation,
            Err(e) => {
                discard_half_built_profile(&app, &local_name, None);
                return Err(e);
            }
        }
    };

    // Past this point the vault exists on disk — an import that doesn't finish
    // must leave no trace, or the next attempt hits "already exists" forever.
    // Replace the freshly-minted DEK with the SHARED one + record share meta, so
    // sync_now routes to /shares/sync and decrypts the shared blobs correctly.
    let seeded = (|| -> Result<(), String> {
        let conn_g = db_state.conn.lock().map_err(|_| "[STATE] LOCK_CONN")?;
        let conn = conn_g.as_ref().ok_or("[STATE] DB_NOT_OPEN")?;
        db_state.still_open(opened)?;
        conn.execute(
            "INSERT INTO sync_meta(key,value) VALUES('dek',?1) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            [&dek_hex],
        )
        .map_err(|e| format!("[SHARE] SET_DEK: {e}"))?;
        conn.execute(
            "INSERT INTO sync_meta(key,value) VALUES('share_id',?1) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            [&share_id],
        )
        .map_err(|e| format!("[SHARE] SET_SHARE_ID: {e}"))?;
        conn.execute(
            "INSERT INTO sync_meta(key,value) VALUES('share_role',?1) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            [&mine.role],
        )
        .map_err(|e| format!("[SHARE] SET_ROLE: {e}"))?;
        link_profile_server(conn, session.base())?;
        Ok(())
    })();
    if let Err(e) = seeded {
        discard_half_built_profile(&app, &local_name, Some(opened));
        return Err(e);
    }
    // Pull the shared data into the new profile.
    match sync_with(&app, &db_state, &cloud, &session, Some(opened)).await {
        Ok(report) => Ok(report),
        Err(e) => {
            discard_half_built_profile(&app, &local_name, Some(opened));
            Err(e)
        }
    }
}

/// Undo a profile that was created on disk but never finished being filled.
///
/// Both `restore_personal_profile` and `import_shared_profile` build the local
/// vault BEFORE the network round-trip that populates it, because the vault has
/// to exist for the merge to have somewhere to land. That ordering left a trap:
/// if the pull failed — an expired token on a fresh sign-in, a dropped
/// connection, a 5xx — the command returned an error but the empty vault stayed
/// on disk, sealed under a randomly-minted key that matches nothing in the
/// cloud. Nothing marked it as broken, so the "Profile 'X' already exists" guard
/// treated it as real and every retry bounced off it. The only escape was to
/// spot the phantom in the picker and remove it by hand, which no error message
/// suggested.
///
/// Best-effort by design: we're already returning an error, and the caller's
/// original one is the one worth showing.
///
/// `opened` is the generation the half-built profile was opened at (None when
/// opening it is what failed). If another profile has been opened since, that
/// one stays open; only the half-built file goes.
fn discard_half_built_profile(app: &tauri::AppHandle, name: &str, opened: Option<u64>) {
    use tauri::Manager as _;
    let state = app.state::<DbState>();
    // Under the connection's lock when it can be had, as in close_profile.
    let mut conn = state.conn.lock().ok();
    let ours = opened.is_none_or(|g| state.generation_now() == g);
    if ours {
        if let Some(c) = conn.as_mut() { **c = None; }
        if let Ok(mut g) = state.master_key.lock() { *g = None; }
        if let Ok(mut g) = state.salt.lock() { *g = None; }
        if let Ok(mut g) = state.db_path.lock() { *g = None; }
        if let Ok(mut g) = state.hlc.lock() { *g = None; }
        state.bump_generation();
    }
    drop(conn);
    if ours {
        if let Ok(mut g) = state.active_profile.lock() { *g = None; }
    }
    if let Ok(p) = profile_path(app, name) {
        let _ = fs::remove_file(p);
    }
}

/// New device: restore one of YOUR OWN personal cloud profiles using nothing but
/// its password. Pulls the profile's /sync stream, unseals its DEK from the
/// reserved escrow record by re-deriving the master key from the password + the
/// salt carried in that record, materialises a fresh local vault under that DEK
/// (protected by the same password), and populates it. This is the
/// personal-profile counterpart to `import_shared_profile` — no whole-vault blob
/// download, no sharing identity, no separate recovery secret. The profile must
/// have been synced at least once since it became password-restorable (so the
/// escrow record exists on the server).
#[tauri::command]
async fn restore_personal_profile(
    app: tauri::AppHandle,
    db_state: tauri::State<'_, DbState>,
    cloud: tauri::State<'_, std::sync::Arc<cloud::CloudState>>,
    cloud_profile: String,
    local_name: String,
    vault_password: String,
) -> Result<SyncReport, String> {
    // Validate up front so a bad name/empty password fails before any network.
    let cloud_profile = cloud_profile.trim().to_string();
    if cloud_profile.is_empty() {
        return Err("[SYNC] NO_PROFILE_NAME".into());
    }
    validate_profile_name(&local_name)?;
    if vault_password.is_empty() {
        return Err("密码不能为空".into());
    }

    // Peek at the cloud stream (empty push) and lift the escrow record out.
    let session = cloud.session().await?;
    let peek = cloud::sync_exchange(&app, &cloud, &session, &cloud_profile, "", &[], None).await?;
    let sealed = peek
        .iter()
        .find(|r| r.entity_type == ESCROW_ETYPE && r.uuid == ESCROW_UUID)
        .and_then(|r| r.blob.clone())
        .ok_or("[SYNC] NO_ESCROW: no restorable copy of that profile in your cloud. Open it on the original device and sync once, then try again.")?;

    // Re-derive the master key from the password (Argon2id → blocking pool) and
    // unseal the DEK. A wrong password fails the GCM tag → surfaced as a wrong
    // password below.
    let pw_for_escrow = vault_password.clone();
    let dek = tokio::task::spawn_blocking(move || open_pw_escrow(&sealed, &pw_for_escrow))
        .await
        .map_err(|e| format!("[SYNC] ESCROW_JOIN: {e}"))?
        .map_err(|_| "[SYNC] ESCROW_UNSEAL_FAILED: wrong password for this profile")?;
    let dek_hex = hex::encode(dek);

    // Create the local vault (fresh profile) — same steps as create_profile.
    let dir = profiles_dir(&app)?;
    fs::create_dir_all(&dir).map_err(|e| format!("[FILE] MKDIR_FAILED: {}", e))?;
    if profile_path(&app, &local_name)?.exists() {
        return Err(format!("档案“{}”已存在", local_name));
    }
    *db_state.active_profile.lock().map_err(|_| "[STATE] LOCK_FAILED")? = Some(local_name.clone());
    // `opened` pins the new profile: the writes and the sync below go to it
    // and nowhere else.
    let opened = {
        use tauri::Manager as _;
        // No strength floor here: the escrow above already proved this is the
        // profile's real password. A pre-existing short one must still restore.
        match setup_master_db_inner(app.clone(), vault_password, app.state::<DbState>(), false).await {
            Ok(generation) => generation,
            Err(e) => {
                discard_half_built_profile(&app, &local_name, None);
                return Err(e);
            }
        }
    };

    // Past this point the vault exists on disk, so every remaining step has to
    // clean up after itself — a restore that didn't finish must leave no trace.
    // Swap the freshly-minted random DEK for the escrowed one, and remember the
    // cloud key in case the local name differs, so sync_now targets the right
    // /sync stream and decrypts the pulled blobs.
    let seeded = (|| -> Result<(), String> {
        let conn_g = db_state.conn.lock().map_err(|_| "[STATE] LOCK_CONN")?;
        let conn = conn_g.as_ref().ok_or("[STATE] DB_NOT_OPEN")?;
        db_state.still_open(opened)?;
        conn.execute(
            "INSERT INTO sync_meta(key,value) VALUES('dek',?1) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            [&dek_hex],
        )
        .map_err(|e| format!("[SYNC] SET_DEK: {e}"))?;
        conn.execute(
            "INSERT INTO sync_meta(key,value) VALUES('cloud_profile',?1) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            [&cloud_profile],
        )
        .map_err(|e| format!("[SYNC] SET_CLOUD_PROFILE: {e}"))?;
        link_profile_server(conn, session.base())?;
        Ok(())
    })();
    if let Err(e) = seeded {
        discard_half_built_profile(&app, &local_name, Some(opened));
        return Err(e);
    }
    match sync_with(&app, &db_state, &cloud, &session, Some(opened)).await {
        Ok(report) => Ok(report),
        Err(e) => {
            discard_half_built_profile(&app, &local_name, Some(opened));
            Err(e)
        }
    }
}

/// Owner: change a member's role.
#[tauri::command]
async fn share_set_role(
    app: tauri::AppHandle,
    cloud: tauri::State<'_, std::sync::Arc<cloud::CloudState>>,
    share_id: String,
    member_user_id: i64,
    role: String,
) -> Result<(), String> {
    if role != "editor" && role != "user" {
        return Err("[SHARE] BAD_ROLE".into());
    }
    let session = cloud.session().await?;
    cloud::set_member_role(&app, &cloud, &session, &share_id, member_user_id, &role).await
}

/// Mint a fresh DEK for a share and re-seal it to everyone still on the roster.
///
/// Without this, revocation had no cryptographic backing at all: the removed
/// member kept the only key the share ever had, so the entire guarantee rested
/// on the server's access check never having a gap — no defence in depth, and
/// `get_or_create_dek`'s own doc already called rotation "a deliberate, separate
/// action" that was never actually built.
///
/// Both writes reuse existing endpoints, which upsert: `/shares/invite` replaces
/// an existing member's `sealed_dek` without disturbing their `status`, and
/// `/shares/create` replaces the owner's own grant. The owner's next sync
/// re-uploads every record under the new key (`bump_for_new_key` makes the
/// server take them), and remaining members are offered the new key on their
/// next sync (`note_share_key`). Returns the members who weren't given it.
async fn rotate_share_dek(
    app: &tauri::AppHandle,
    db_state: &tauri::State<'_, DbState>,
    cloud: &tauri::State<'_, std::sync::Arc<cloud::CloudState>>,
    session: &cloud::Session,
    share_id: &str,
    share_name: &str,
    generation: u64,
) -> Result<Vec<LeftOut>, String> {
    let (my_pub, _) = cloud.identity().await.ok_or("[SHARE] IDENTITY_LOCKED")?;
    let mut fresh = [0u8; 32];
    rand::rng().fill_bytes(&mut fresh);
    // The keys members were invited with (see create_share_pins).
    let pins: std::collections::HashMap<String, String> = {
        let conn_g = db_state.conn.lock().map_err(|_| "[STATE] LOCK_CONN")?;
        let conn = conn_g.as_ref().ok_or("[STATE] DB_NOT_OPEN")?;
        db_state.still_open(generation)?;
        let mut stmt = conn
            .prepare("SELECT email, public_key FROM share_member_keys WHERE share_id=?1")
            .map_err(|e| format!("[SHARE] PINS: {e}"))?;
        let rows = stmt
            .query_map([share_id], |r| Ok((r.get::<_, String>(0)?, r.get::<_, String>(1)?)))
            .map_err(|e| format!("[SHARE] PINS: {e}"))?;
        rows.filter_map(Result::ok).collect()
    };

    // Every remaining member's grant is sealed before anything is replaced, so
    // a lookup that fails outright stops the rotation while the old key is
    // still everyone's. A member whose answer doesn't fit (another account, a
    // key other than the one they were invited with, a key nothing can be
    // sealed to) is left out: they can't decrypt until they're invited again,
    // which is the safe direction to fail.
    let roster = cloud::share_members(app, cloud, session, share_id).await?;
    let mut grants = Vec::new();
    let mut left_out = Vec::new();
    let mut first_seen = Vec::new();
    for m in roster.iter().filter(|m| m.role != "owner" && m.status != "revoked") {
        let leave_out = |reason| LeftOut { email: m.email.clone(), reason };
        let Some(info) = cloud::lookup_pubkey(app, cloud, session, &m.email).await? else {
            left_out.push(leave_out("no_key"));
            continue;
        };
        if !same_account(&m.email, &info.email) {
            left_out.push(leave_out("other_account"));
            continue;
        }
        let pin = pins.get(&m.email.trim().to_ascii_lowercase());
        if pin.is_some_and(|p| !p.eq_ignore_ascii_case(&info.public_key)) {
            left_out.push(leave_out("key_changed"));
            continue;
        }
        match hex_to_32(&info.public_key).and_then(|k| identity::seal_to(&k, &fresh)) {
            Ok(sealed) => {
                // Invited before keys were kept: their key as it is now.
                if pin.is_none() {
                    first_seen.push((m.email.clone(), info.public_key.clone()));
                }
                grants.push((m, hex::encode(sealed)));
            }
            Err(_) => left_out.push(leave_out("weak_key")),
        }
    }

    // Re-seal to the owner FIRST. If this is the step that fails, nobody's grant
    // has changed yet and the old key is still universally valid — a clean no-op
    // rather than a share whose members hold a key the owner can't open.
    cloud::create_share(app, cloud, session, share_id, share_name, &hex::encode(identity::seal_to(&my_pub, &fresh)?)).await?;

    for (m, sealed) in grants {
        // Best-effort per member: one member whose upload fails must not abort
        // the rotation and leave the rest on a key the owner has already
        // replaced.
        if let Err(e) = cloud::invite_member(app, cloud, session, share_id, &m.email, &m.role, &sealed).await {
            eprintln!("[SHARE] re-seal failed for {}: {e}", m.email);
            left_out.push(LeftOut { email: m.email.clone(), reason: "upload_failed" });
        }
    }

    {
        let conn_g = db_state.conn.lock().map_err(|_| "[STATE] LOCK_CONN")?;
        let conn = conn_g.as_ref().ok_or("[STATE] DB_NOT_OPEN")?;
        // Only into the profile this was for. If it closed meanwhile, its next
        // sync finds the new key in its own grant and asks for it.
        db_state.still_open(generation)?;
        // The new key, the members' first-seen keys and every row marked to go
        // out again under it, together or not at all.
        let tx = conn.unchecked_transaction().map_err(|e| format!("[SHARE] TX: {e}"))?;
        tx.execute(
            "INSERT INTO sync_meta(key,value) VALUES('dek',?1) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            [&hex::encode(fresh)],
        )
        .map_err(|e| format!("[SHARE] SET_DEK: {e}"))?;
        for (email, key) in &first_seen {
            pin_member_key(&tx, share_id, email, key)?;
        }
        bump_for_new_key(&tx)?;
        tx.commit().map_err(|e| format!("[SHARE] TX_COMMIT: {e}"))?;
    }
    save_vault_async(db_state).await?;
    Ok(left_out)
}

/// Marks every synced row to go out again after its share's key is replaced.
/// The server keeps the copy it has unless a push carries a newer stamp, so
/// otherwise everything nobody edited since would stay sealed with the old
/// key, which no one invited later can open. The newer stamp is the smallest
/// step up (the same moment and device, the counter one higher), so a real
/// edit made since, anywhere, still wins. Runs with the merge flag on, so no
/// trigger takes it for an edit.
fn bump_for_new_key(conn: &Connection) -> Result<usize, String> {
    conn.execute("INSERT INTO sync_flags(key,val) VALUES('merge',1) ON CONFLICT(key) DO UPDATE SET val=1", [])
        .map_err(|e| format!("[SHARE] BUMP_FLAG: {e}"))?;
    let bumped = (|| {
        let mut n = 0;
        for t in SYNCED_TABLES {
            n += conn
                .execute(
                    &format!(
                        "UPDATE {t} SET updated_at = substr(updated_at, 1, 16)
                             || printf('%05d', CAST(substr(updated_at, 17, 5) AS INTEGER) + 1) || substr(updated_at, 22)
                         WHERE uuid IS NOT NULL
                           AND updated_at GLOB '{HLC_GLOB}'
                           AND CAST(substr(updated_at, 17, 5) AS INTEGER) < 99999"
                    ),
                    [],
                )
                .map_err(|e| format!("[SHARE] BUMP {t}: {e}"))?;
        }
        Ok(n)
    })();
    let _ = conn.execute("UPDATE sync_flags SET val=0 WHERE key='merge'", []);
    bumped
}

/// A well-formed stamp, `{phys:015}:{counter:05}:{node}`, as a GLOB pattern.
const HLC_GLOB: &str = "[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]:[0-9][0-9][0-9][0-9][0-9]:?*";

/// Owner: remove a member, then rotate the key they walked away with.
#[tauri::command]
async fn share_revoke(
    app: tauri::AppHandle,
    db_state: tauri::State<'_, DbState>,
    cloud: tauri::State<'_, std::sync::Arc<cloud::CloudState>>,
    share_id: String,
    member_user_id: i64,
) -> Result<RevokeResult, String> {
    // Replacing the key needs the sharing identity. Checked before the member
    // is removed, so a locked one can't leave them out with the key unchanged.
    cloud.identity().await.ok_or("[SHARE] IDENTITY_LOCKED: unlock sharing first")?;
    let session = cloud.session().await?;
    // The rotation below works on THIS profile, so the share has to be its
    // own; `generation` keeps it from reading or writing another one opened
    // while the network calls run.
    let generation = {
        let conn_g = db_state.conn.lock().map_err(|_| "[STATE] LOCK_CONN")?;
        let conn = conn_g.as_ref().ok_or("[STATE] DB_NOT_OPEN")?;
        check_profile_server(conn, session.base())?;
        own_share(conn, &share_id)?;
        db_state.generation_now()
    };
    cloud::revoke_member(&app, &cloud, &session, &share_id, member_user_id).await?;
    // Revocation itself has succeeded by here. If the rotation leg fails we
    // still report success for the removal — the member IS out — but say plainly
    // that the key wasn't replaced, because that's the part with a security
    // consequence and silently swallowing it would misrepresent what happened.
    let not_rotated = |e: String| {
        format!(
            "[SHARE] REVOKED_BUT_KEY_NOT_ROTATED: the member is out of the share, but the shared key could not be replaced ({e}). \
             They can no longer reach the server, but they still hold the old key. Use Replace the key to try again."
        )
    };
    let left_out = replace_share_key(&app, &db_state, &cloud, &session, &share_id, generation)
        .await
        .map_err(not_rotated)?;
    Ok(RevokeResult { left_out })
}

/// Owner: replace the open shared profile's key, as removing a member does.
/// What finishes a removal whose key change failed.
#[tauri::command]
async fn share_replace_key(
    app: tauri::AppHandle,
    db_state: tauri::State<'_, DbState>,
    cloud: tauri::State<'_, std::sync::Arc<cloud::CloudState>>,
) -> Result<RevokeResult, String> {
    cloud.identity().await.ok_or("[SHARE] IDENTITY_LOCKED: unlock sharing first")?;
    let session = cloud.session().await?;
    let (share_id, generation) = {
        let conn_g = db_state.conn.lock().map_err(|_| "[STATE] LOCK_CONN")?;
        let conn = conn_g.as_ref().ok_or("[STATE] DB_NOT_OPEN")?;
        check_profile_server(conn, session.base())?;
        let share_id: String = conn
            .query_row("SELECT value FROM sync_meta WHERE key='share_id'", [], |r| r.get(0))
            .map_err(|_| "[SHARE] NOT_SHARED: this profile isn't shared")?;
        own_share(conn, &share_id)?;
        (share_id, db_state.generation_now())
    };
    let left_out = replace_share_key(&app, &db_state, &cloud, &session, &share_id, generation).await?;
    Ok(RevokeResult { left_out })
}

/// Replace a share's key and put everything on the server under it. A sync
/// first, with the old key, so what members changed lately is here too; then
/// the new key, which marks every row to go out again (`rotate_share_dek`);
/// then a sync that uploads them. Anyone invited later can then read all of
/// it, not only what was edited after the change.
async fn replace_share_key(
    app: &tauri::AppHandle,
    db_state: &tauri::State<'_, DbState>,
    cloud: &tauri::State<'_, std::sync::Arc<cloud::CloudState>>,
    session: &cloud::Session,
    share_id: &str,
    generation: u64,
) -> Result<Vec<LeftOut>, String> {
    sync_with(app, db_state, cloud, session, Some(generation)).await?;
    let name = {
        let conn_g = db_state.conn.lock().map_err(|_| "[STATE] LOCK_CONN")?;
        let conn = conn_g.as_ref().ok_or("[STATE] DB_NOT_OPEN")?;
        db_state.still_open(generation)?;
        conn.query_row("SELECT value FROM sync_meta WHERE key='share_name'", [], |r| r.get::<_, String>(0))
            .ok()
    };
    let name = match name {
        Some(n) => n,
        None => db_state
            .active_profile
            .lock()
            .map_err(|_| "[STATE] LOCK_FAILED")?
            .clone()
            .unwrap_or_else(|| "profile".to_string()),
    };
    let left_out = rotate_share_dek(app, db_state, cloud, session, share_id, &name, generation).await?;
    // The rows are marked by now, so if this upload fails, the next sync does it.
    if let Err(e) = sync_with(app, db_state, cloud, session, Some(generation)).await {
        eprintln!("[SHARE] uploading under the new key failed, the next sync tries again: {e}");
    }
    Ok(left_out)
}

#[derive(serde::Serialize)]
struct RevokeResult {
    /// Members who weren't given the new key, so can't read what changes from
    /// now on until they're invited again.
    left_out: Vec<LeftOut>,
}

/// Non-owner: leave a share.
#[tauri::command]
async fn share_leave(
    app: tauri::AppHandle,
    cloud: tauri::State<'_, std::sync::Arc<cloud::CloudState>>,
    share_id: String,
) -> Result<(), String> {
    let session = cloud.session().await?;
    cloud::leave_share(&app, &cloud, &session, &share_id).await
}

/// Owner: delete the whole shared profile.
#[tauri::command]
async fn share_delete(
    app: tauri::AppHandle,
    cloud: tauri::State<'_, std::sync::Arc<cloud::CloudState>>,
    share_id: String,
) -> Result<(), String> {
    let session = cloud.session().await?;
    cloud::delete_share(&app, &cloud, &session, &share_id).await
}

#[derive(serde::Serialize)]
struct ProfileShareStatus {
    profile: Option<String>,
    share_id: Option<String>,
    role: Option<String>,
    identity_unlocked: bool,
    signed_in: bool,
    email: Option<String>,
    /// The server this profile syncs with; `None` while it isn't linked yet.
    cloud_server: Option<String>,
    /// The sync server in use.
    current_server: String,
    /// Whether that is a self-hosted one, not the default.
    custom_server: bool,
}

/// Everything the in-app Profile panel needs about the OPEN profile, read in one
/// shot with no network call so the panel paints instantly: which profile is
/// open, whether it's shared and at what role, and whether the cloud account and
/// sharing identity are ready. The member roster is fetched separately.
#[tauri::command]
async fn profile_share_status(
    db_state: tauri::State<'_, DbState>,
    cloud: tauri::State<'_, std::sync::Arc<cloud::CloudState>>,
) -> Result<ProfileShareStatus, String> {
    // Scoped so both std MutexGuards drop before the awaits below.
    let (profile, share_id, role, cloud_server) = {
        let profile = db_state
            .active_profile
            .lock()
            .map_err(|_| "[STATE] LOCK_FAILED")?
            .clone();
        let conn_g = db_state.conn.lock().map_err(|_| "[STATE] LOCK_CONN")?;
        match conn_g.as_ref() {
            Some(conn) => {
                let sid: Option<String> = conn
                    .query_row("SELECT value FROM sync_meta WHERE key='share_id'", [], |r| r.get(0))
                    .ok();
                let role: Option<String> = conn
                    .query_row("SELECT value FROM sync_meta WHERE key='share_role'", [], |r| r.get(0))
                    .ok();
                (profile, sid, role, profile_server(conn))
            }
            None => (profile, None, None, None),
        }
    };
    let st = cloud.status().await;
    let current_server = cloud.base().await;
    Ok(ProfileShareStatus {
        profile,
        share_id,
        role,
        identity_unlocked: cloud.identity().await.is_some(),
        signed_in: st.signed_in,
        email: st.email,
        cloud_server,
        custom_server: current_server != cloud::CLOUD_API_BASE,
        current_server,
    })
}

/// Links the OPEN personal profile to the sync server in use, so it syncs
/// there from now on. Nothing is copied or deleted by this: the next sync
/// pushes the profile in full (pushes always are), and its copy on the old
/// server stays where it is. A shared profile can't move: its members are on
/// the server it was shared on.
#[tauri::command]
async fn move_profile_to_current_server(
    db_state: tauri::State<'_, DbState>,
    cloud: tauri::State<'_, std::sync::Arc<cloud::CloudState>>,
) -> Result<(), String> {
    let base = cloud.base().await;
    {
        let conn_g = db_state.conn.lock().map_err(|_| "[STATE] LOCK_CONN")?;
        let conn = conn_g.as_ref().ok_or("[STATE] DB_NOT_OPEN")?;
        let shared = conn
            .query_row("SELECT 1 FROM sync_meta WHERE key='share_id'", [], |_| Ok(()))
            .is_ok();
        if shared {
            return Err("[SYNC] SHARED_PROFILE: a shared profile stays on the server it was shared on.".into());
        }
        link_profile_server(conn, &base)?;
    }
    save_vault_async(&db_state).await
}

/// Stop sharing the OPEN profile. Owner → tears the share down for everyone;
/// member → leaves it. Either way this device keeps its local copy: only the
/// share bookkeeping is cleared, so the profile falls back to syncing on the
/// personal path under the DEK it already holds.
#[tauri::command]
async fn stop_sharing(
    app: tauri::AppHandle,
    db_state: tauri::State<'_, DbState>,
    cloud: tauri::State<'_, std::sync::Arc<cloud::CloudState>>,
) -> Result<(), String> {
    let session = cloud.session().await?;
    let (share_id, role, generation) = {
        let conn_g = db_state.conn.lock().map_err(|_| "[STATE] LOCK_CONN")?;
        let conn = conn_g.as_ref().ok_or("[STATE] DB_NOT_OPEN")?;
        let sid: Option<String> = conn
            .query_row("SELECT value FROM sync_meta WHERE key='share_id'", [], |r| r.get(0))
            .ok();
        let role: Option<String> = conn
            .query_row("SELECT value FROM sync_meta WHERE key='share_role'", [], |r| r.get(0))
            .ok();
        check_profile_server(conn, session.base())?;
        (
            sid.ok_or("[SHARE] NOT_SHARED: this profile isn't shared")?,
            role.unwrap_or_default(),
            db_state.generation_now(),
        )
    };
    if role == "owner" {
        // The owner is the only one who can manage or delete the share, so if
        // the server never got the message we must NOT forget the share_id —
        // dropping it locally would orphan a live share that members keep
        // syncing against, with nobody left able to shut it down.
        cloud::delete_share(&app, &cloud, &session, &share_id).await?;
    } else {
        // Leaving is the member's own decision about their own device, so it has
        // to succeed locally whatever the server says. It used to abort on any
        // error — which meant a member who had ALREADY been revoked could never
        // leave: the server rightly rejects a leave from a non-member, so the
        // one escape hatch the UI offers failed every single time, and their
        // vault stayed pointed at a dead share that errored on every sync
        // forever. Best-effort tell the server, then clear regardless.
        if let Err(e) = cloud::leave_share(&app, &cloud, &session, &share_id).await {
            eprintln!("[SHARE] leave_share failed, clearing locally anyway: {e}");
        }
    }
    {
        let conn_g = db_state.conn.lock().map_err(|_| "[STATE] LOCK_CONN")?;
        let conn = conn_g.as_ref().ok_or("[STATE] DB_NOT_OPEN")?;
        // Only the profile this was asked for: another one opened meanwhile
        // would otherwise lose its own share link.
        db_state.still_open(generation)?;
        conn.execute("DELETE FROM sync_meta WHERE key IN ('share_id','share_role','share_name','pending_dek')", [])
            .map_err(|e| format!("[SHARE] CLEAR_META: {e}"))?;
        conn.execute("DELETE FROM share_member_keys WHERE share_id=?1", [&share_id])
            .map_err(|e| format!("[SHARE] CLEAR_PINS: {e}"))?;
        // Deletions held from the share don't come again once it's left.
        conn.execute("DELETE FROM held_deletions", [])
            .map_err(|e| format!("[SHARE] CLEAR_HELD: {e}"))?;
    }
    save_vault_async(&db_state).await
}

/// The deletions held in the open shared profile (approvals::hold_deletions).
#[tauri::command]
async fn held_deletions_list(db_state: tauri::State<'_, DbState>) -> Result<Vec<approvals::HeldDeletion>, String> {
    let conn_g = db_state.conn.lock().map_err(|_| "[STATE] LOCK_CONN")?;
    let conn = conn_g.as_ref().ok_or("[STATE] DB_NOT_OPEN")?;
    Ok(approvals::held_deletions(conn))
}

/// The user's call on the deletions held in a shared profile: `delete_them`
/// deletes those rows here too. Otherwise they stay, with a stamp newer than
/// the deletion's, so the next sync brings them back for everyone.
#[tauri::command]
async fn resolve_held_deletions(db_state: tauri::State<'_, DbState>, delete_them: bool) -> Result<usize, String> {
    let done = {
        let conn_g = db_state.conn.lock().map_err(|_| "[STATE] LOCK_CONN")?;
        let conn = conn_g.as_ref().ok_or("[STATE] DB_NOT_OPEN")?;
        let hlc = db_state.hlc.lock().map_err(|_| "[STATE] LOCK_HLC")?.as_ref().ok_or("[SYNC] NO_HLC")?.clone();
        resolve_held(conn, &hlc, delete_them)?
    };
    save_vault_async(&db_state).await?;
    Ok(done)
}

fn resolve_held(conn: &Connection, hlc: &hlc::Hlc, delete_them: bool) -> Result<usize, String> {
    let held: Vec<(String, String, String)> = {
        let mut stmt = conn
            .prepare("SELECT uuid, entity_type, updated_at FROM held_deletions")
            .map_err(|e| format!("[SYNC] HELD: {e}"))?;
        let rows = stmt
            .query_map([], |r| Ok((r.get(0)?, r.get(1)?, r.get(2)?)))
            .map_err(|e| format!("[SYNC] HELD: {e}"))?;
        rows.filter_map(Result::ok).collect()
    };
    // Like a merge: the triggers stay out of it (no tombstone of our own for a
    // deletion, no stamp for a kept row but the one set here).
    conn.execute("INSERT INTO sync_flags(key,val) VALUES('merge',1) ON CONFLICT(key) DO UPDATE SET val=1", [])
        .map_err(|e| format!("[SYNC] MERGE_ON: {e}"))?;
    let done = (|| -> Result<usize, String> {
        let tx = conn.unchecked_transaction().map_err(|e| format!("[SYNC] TX_BEGIN: {e}"))?;
        for (uuid, entity_type, stamp) in &held {
            if !SYNCED_TABLES.contains(&entity_type.as_str()) {
                continue;
            }
            if delete_them {
                let rec = SyncRecord {
                    uuid: uuid.clone(),
                    entity_type: entity_type.clone(),
                    updated_at: stamp.clone(),
                    deleted: true,
                    blob: None,
                };
                if let Err(e) = in_savepoint(&tx, || apply_tombstone(&tx, &rec))? {
                    eprintln!("[SYNC] held deletion not applied uuid={uuid}: {e}");
                }
            } else {
                tx.execute(
                    &format!("UPDATE {entity_type} SET updated_at=?1 WHERE uuid=?2"),
                    rusqlite::params![stamp_past(&hlc.tick(), stamp), uuid],
                )
                .map_err(|e| format!("[SYNC] KEEP: {e}"))?;
            }
        }
        tx.execute("DELETE FROM held_deletions", []).map_err(|e| format!("[SYNC] HELD_CLEAR: {e}"))?;
        tx.commit().map_err(|e| format!("[SYNC] TX_COMMIT: {e}"))?;
        Ok(held.len())
    })();
    let _ = conn.execute("UPDATE sync_flags SET val=0 WHERE key='merge'", []);
    done
}

/// `fresh` (this device's next stamp), or, when that doesn't sort after
/// `other`, `other` one counter step on, so a kept row wins against the
/// deletion it's kept from even when the deleter's clock ran ahead.
fn stamp_past(fresh: &str, other: &str) -> String {
    if fresh > other {
        return fresh.to_string();
    }
    let counter = other.get(16..21).and_then(|c| c.parse::<u32>().ok());
    match (other.get(..16), counter, other.get(21..)) {
        (Some(head), Some(c), Some(tail)) if c < 99_999 => format!("{head}{:05}{tail}", c + 1),
        _ => fresh.to_string(),
    }
}

/// Set the label stamped onto future local edits (the `edited_by` column). The
/// frontend calls this on unlock with the signed-in cloud email so changes are
/// attributed to a person across shared/multi-device use. An empty label clears
/// it (edits stay unattributed). Local-only — sync_meta never leaves the vault.
#[tauri::command]
async fn set_editor_label(db_state: tauri::State<'_, DbState>, label: String) -> Result<(), String> {
    let label = label.trim().to_string();
    {
        let conn_g = db_state.conn.lock().map_err(|_| "[STATE] LOCK_CONN")?;
        let conn = conn_g.as_ref().ok_or("[STATE] DB_NOT_OPEN")?;
        if label.is_empty() {
            conn.execute("DELETE FROM sync_meta WHERE key='editor_label'", [])
                .map_err(|e| format!("[SYNC] EDITOR_CLEAR: {e}"))?;
        } else {
            conn.execute(
                "INSERT INTO sync_meta(key,value) VALUES('editor_label',?1) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                [&label],
            )
            .map_err(|e| format!("[SYNC] EDITOR_SET: {e}"))?;
        }
    }
    save_vault_async(&db_state).await
}

#[cfg(test)]
mod sync_engine_tests {
    use super::*;
    use rusqlite::Connection;

    const KEY: [u8; 32] = [7u8; 32];

    // The DEK-escrow record round-trips through the sync stream: sealed under
    // the profile's own password on push, recovered on a fresh device from just
    // that password — and it's inert to the merge engine (never a phantom row).
    #[test]
    fn dek_escrow_round_trips_and_apply_ignores_it() {
        let dek: [u8; 32] = KEY;
        let salt = [3u8; SALT_LEN];
        let password = "correct horse battery staple";
        let master_key = derive_key(password, &salt).unwrap();
        let rec = build_pw_escrow_record(&master_key, &salt, &dek).unwrap();
        assert_eq!(rec.entity_type, ESCROW_ETYPE);
        assert_eq!(rec.uuid, ESCROW_UUID);

        // A fresh device recovers the exact DEK from just the password...
        let recovered = open_pw_escrow(rec.blob.as_ref().unwrap(), password).unwrap();
        assert_eq!(recovered, dek, "escrow must recover the exact DEK");
        // ...and the wrong password must not (GCM tag fails).
        assert!(
            open_pw_escrow(rec.blob.as_ref().unwrap(), "wrong password").is_err(),
            "wrong password must not recover the DEK"
        );

        // Applying an escrow record must not create a phantom row anywhere.
        let (b, hb) = device("B");
        apply_remote_records(&b, &KEY, std::slice::from_ref(&rec), &hb).unwrap();
        for spec in ENTITIES {
            let n: i64 = b
                .query_row(&format!("SELECT COUNT(*) FROM {}", spec.table), [], |r| r.get(0))
                .unwrap();
            assert_eq!(n, 0, "escrow record must not land in table {}", spec.table);
        }
    }

    #[test]
    fn edited_by_is_stamped_and_syncs() {
        let (a, _ha) = device("A");
        a.execute("INSERT INTO sync_meta(key,value) VALUES('editor_label','alice@x.com')", []).unwrap();
        a.execute("INSERT INTO servers(name,host,port) VALUES('web','h',22)", []).unwrap();
        let recs = collect_local_records(&a, &KEY, "").unwrap();
        let srv = recs.iter().find(|r| r.entity_type == "servers").unwrap();
        let plain = decrypt_entity(srv.blob.as_ref().unwrap(), &KEY).unwrap();
        let v: serde_json::Value = serde_json::from_slice(&plain).unwrap();
        assert_eq!(v["edited_by"], "alice@x.com", "trigger must stamp the editor label");

        // Cross-device apply preserves who edited it (not overwritten locally).
        let (b, hb) = device("B");
        apply_remote_records(&b, &KEY, &recs, &hb).unwrap();
        let eb: String = b.query_row("SELECT edited_by FROM servers WHERE name='web'", [], |r| r.get(0)).unwrap();
        assert_eq!(eb, "alice@x.com");
    }

    // A co-member's server that would act by itself on this device (commands
    // on connect, autostart, a forward, a monitor command) arrives held in a
    // shared profile, and arrives as it is in a personal one.
    #[test]
    fn a_shared_profile_holds_what_a_co_member_turns_on() {
        let (a, _ha) = device("A");
        a.execute(
            "INSERT INTO servers(name,host,port,run_on_connect,autostart,tunnels) VALUES('web','h',22,'curl x | sh',1,?1)",
            [r#"[{"type":"R","local":"0.0.0.0:9000","remote":"127.0.0.1:22"}]"#],
        )
        .unwrap();
        let id: i64 = a.query_row("SELECT id FROM servers WHERE name='web'", [], |r| r.get(0)).unwrap();
        a.execute(
            "INSERT INTO monitor_configs(node_id,enabled_metrics,custom_metrics,paused) VALUES(?1,'[]',?2,1)",
            rusqlite::params![id, r#"[{"id":"x","name":"x","command":"id","parse":"text","display":"text"}]"#],
        )
        .unwrap();
        let recs = collect_local_records(&a, &KEY, "").unwrap();

        let (b, hb) = device("B");
        approvals::create_schema(&b).unwrap();
        b.execute("INSERT INTO sync_meta(key,value) VALUES('share_id','s1')", []).unwrap();
        apply_remote_records(&b, &KEY, &recs, &hb).unwrap();
        let uuid: String = b.query_row("SELECT uuid FROM servers WHERE name='web'", [], |r| r.get(0)).unwrap();
        let held: Vec<String> = approvals::held_for(&b, &uuid).into_iter().collect();
        assert_eq!(held, vec!["autostart", "metric:id", "run_on_connect", "tunnel:R|0.0.0.0:9000|127.0.0.1:22"]);

        let (c, hc) = device("C");
        approvals::create_schema(&c).unwrap();
        apply_remote_records(&c, &KEY, &recs, &hc).unwrap();
        assert!(approvals::held_by_server(&c).is_empty(), "a personal profile holds nothing");
    }

    #[test]
    fn dek_is_stable_and_encrypts_blobs() {
        let conn = Connection::open_in_memory().unwrap();
        conn.execute("CREATE TABLE sync_meta (key TEXT PRIMARY KEY, value TEXT NOT NULL)", [])
            .unwrap();
        let (dek1, created1) = get_or_create_dek(&conn).unwrap();
        assert!(created1, "first call must mint the DEK");
        let (dek2, created2) = get_or_create_dek(&conn).unwrap();
        assert!(!created2, "second call must reuse it");
        assert_eq!(dek1, dek2, "DEK must be stable across opens");
        // A per-entity blob encrypted under the DEK round-trips with the reloaded DEK.
        let blob = encrypt_entity(b"{\"host\":\"h\"}", &dek1).unwrap();
        assert_eq!(decrypt_entity(&blob, &dek2).unwrap(), b"{\"host\":\"h\"}");
    }

    fn device(node: &str) -> (Connection, std::sync::Arc<hlc::Hlc>) {
        device_with(node, false)
    }

    /// `fks`: with the foreign keys the app's own schema declares, enforced
    /// as the app enforces them.
    fn device_with(node: &str, fks: bool) -> (Connection, std::sync::Arc<hlc::Hlc>) {
        let conn = Connection::open_in_memory().unwrap();
        let fk = |clause: &str| if fks { format!(", {clause}") } else { String::new() };
        conn.execute_batch(if fks { "PRAGMA foreign_keys = ON" } else { "PRAGMA foreign_keys = OFF" }).unwrap();
        conn.execute_batch(&format!(
            "CREATE TABLE folders(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, parent_id INTEGER, color TEXT, uuid TEXT, updated_at TEXT, deleted INTEGER NOT NULL DEFAULT 0, edited_by TEXT);
             CREATE TABLE ssh_keys(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, public_key TEXT, private_key TEXT, passphrase TEXT, uuid TEXT, updated_at TEXT, deleted INTEGER NOT NULL DEFAULT 0, edited_by TEXT);
             CREATE TABLE credentials(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, auth_type TEXT, username TEXT, password TEXT, key_id INTEGER, uuid TEXT, updated_at TEXT, deleted INTEGER NOT NULL DEFAULT 0, edited_by TEXT{});
             CREATE TABLE servers(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, host TEXT, port INTEGER, username TEXT, password TEXT, credential_id INTEGER, folder_id INTEGER, proxy_type TEXT, proxy_host TEXT, proxy_port INTEGER, tunnels TEXT, auth_type TEXT, key_id INTEGER, autostart INTEGER, mirrors TEXT, color TEXT, notes TEXT, run_on_connect TEXT, jump_host_id INTEGER, position INTEGER NOT NULL DEFAULT 0, uuid TEXT, updated_at TEXT, deleted INTEGER NOT NULL DEFAULT 0, edited_by TEXT{});
             CREATE TABLE commands(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, content TEXT, uuid TEXT, updated_at TEXT, deleted INTEGER NOT NULL DEFAULT 0, edited_by TEXT);
             CREATE TABLE notes(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, body TEXT, uuid TEXT, updated_at TEXT, deleted INTEGER NOT NULL DEFAULT 0, edited_by TEXT);
             CREATE TABLE monitor_configs(node_id INTEGER PRIMARY KEY, enabled_metrics TEXT, custom_metrics TEXT, paused INTEGER, uuid TEXT, updated_at TEXT, deleted INTEGER NOT NULL DEFAULT 0, edited_by TEXT{});",
            fk("FOREIGN KEY(key_id) REFERENCES ssh_keys(id)"),
            fk("FOREIGN KEY(folder_id) REFERENCES folders(id)"),
            fk("FOREIGN KEY(node_id) REFERENCES servers(id) ON DELETE CASCADE"),
        ))
        .unwrap();
        let hlc = std::sync::Arc::new(hlc::Hlc::new(node.into(), 0));
        register_sync_functions(&conn, &hlc).unwrap();
        create_sync_triggers(&conn).unwrap();
        (conn, hlc)
    }

    /// A vault from before the sync era: the same schema, but no triggers have
    /// ever run over it, so every row still has `uuid IS NULL`. Two calls give
    /// two byte-identical copies — i.e. the same vault sitting on two devices.
    fn presync_vault() -> Connection {
        let (conn, _) = device("pre");
        conn.execute_batch(
            "DROP TRIGGER IF EXISTS trg_servers_ai; DROP TRIGGER IF EXISTS trg_servers_au;
             DROP TRIGGER IF EXISTS trg_servers_ad;",
        )
        .unwrap();
        conn.execute("DELETE FROM servers", []).unwrap();
        conn.execute("DELETE FROM sync_tombstones", []).unwrap();
        conn.execute("INSERT INTO servers(id,name,host,port,username) VALUES(1,'web','h1',22,'root')", []).unwrap();
        conn.execute("INSERT INTO servers(id,name,host,port,username) VALUES(2,'old','h9',22,'root')", []).unwrap();
        conn.execute("UPDATE servers SET uuid=NULL, updated_at=NULL", []).unwrap();
        conn
    }

    // The exact incident: an old copy of a vault was opened on a second device.
    // It had never synced, so the backfill had to invent identity for its rows.
    // Inventing a RANDOM uuid + a NOW stamp (what we used to do) meant the stale
    // copy pushed itself as brand-new, freshest-in-the-world entities —
    // duplicating every row and resurrecting everything deleted elsewhere.
    #[test]
    fn an_old_vault_copy_cannot_overwrite_or_resurrect() {
        // Device A: adopted the vault, then did real work — edited one server
        // and deleted the other.
        let a = presync_vault();
        let ha = std::sync::Arc::new(hlc::Hlc::new("A".into(), 0));
        register_sync_functions(&a, &ha).unwrap();
        backfill_sync_columns(&a, &ha).unwrap();
        create_sync_triggers(&a).unwrap();
        a.execute("UPDATE servers SET host='h2' WHERE name='web'", []).unwrap();
        a.execute("DELETE FROM servers WHERE name='old'", []).unwrap();
        let from_a = collect_local_records(&a, &KEY, "").unwrap();

        // Device B: the OLD phone. Same vault, untouched, adopted just now.
        let b = presync_vault();
        let hb = std::sync::Arc::new(hlc::Hlc::new("B".into(), 0));
        register_sync_functions(&b, &hb).unwrap();
        backfill_sync_columns(&b, &hb).unwrap();
        create_sync_triggers(&b).unwrap();
        let from_b = collect_local_records(&b, &KEY, "").unwrap();

        // Both devices independently derived the SAME id for the same row, so
        // the merge sees one entity rather than two unrelated ones.
        let ua: String = a.query_row("SELECT uuid FROM servers WHERE name='web'", [], |r| r.get(0)).unwrap();
        let ub: String = b.query_row("SELECT uuid FROM servers WHERE name='web'", [], |r| r.get(0)).unwrap();
        assert_eq!(ua, ub, "same row on two copies of one vault must derive one uuid");

        // B's untouched rows sit at the clock floor, not at "now".
        let uat: String = b.query_row("SELECT updated_at FROM servers WHERE name='old'", [], |r| r.get(0)).unwrap();
        assert_eq!(uat, BACKFILL_UAT, "a never-synced row must not claim to be fresh");

        // Now the round trip. A's work reaches B...
        apply_remote_records(&b, &KEY, &from_a, &hb).unwrap();
        let host: String = b.query_row("SELECT host FROM servers WHERE name='web'", [], |r| r.get(0)).unwrap();
        assert_eq!(host, "h2", "B must take A's edit");
        let alive: i64 = b
            .query_row("SELECT COUNT(*) FROM servers WHERE name='old' AND deleted=0", [], |r| r.get(0))
            .unwrap();
        assert_eq!(alive, 0, "B must honour A's deletion");

        // ...and B's stale copy reaches A, where it must change nothing.
        apply_remote_records(&a, &KEY, &from_b, &ha).unwrap();
        let host: String = a.query_row("SELECT host FROM servers WHERE name='web'", [], |r| r.get(0)).unwrap();
        assert_eq!(host, "h2", "a stale copy must not overwrite a real edit");
        let alive: i64 = a
            .query_row("SELECT COUNT(*) FROM servers WHERE name='old' AND deleted=0", [], |r| r.get(0))
            .unwrap();
        assert_eq!(alive, 0, "a stale copy must not resurrect a deleted row");
        let total: i64 = a.query_row("SELECT COUNT(*) FROM servers", [], |r| r.get(0)).unwrap();
        assert_eq!(total, 1, "a stale copy must not duplicate rows");
    }

    // Rows with nothing to identify them can't derive a stable id, and two rows
    // that DO collide must not be fused into one — both fall back to random ids.
    #[test]
    fn backfill_falls_back_to_random_ids_rather_than_fusing_rows() {
        assert_eq!(derived_entity_uuid("servers", &[None, Some(String::new())]), None);

        let conn = presync_vault();
        // Two rows identical in every identifying column.
        conn.execute("UPDATE servers SET name='web', host='h1', port=22, username='root' WHERE id=2", []).unwrap();
        let h = std::sync::Arc::new(hlc::Hlc::new("A".into(), 0));
        register_sync_functions(&conn, &h).unwrap();
        backfill_sync_columns(&conn, &h).unwrap();
        let n: i64 = conn
            .query_row("SELECT COUNT(DISTINCT uuid) FROM servers", [], |r| r.get(0))
            .unwrap();
        assert_eq!(n, 2, "two local rows must never share one uuid");
    }

    // Monitoring config used to be instrumented for sync — triggers, backfill,
    // a uuid index — but was missing from ENTITIES, the list that actually
    // drives push/apply. So it silently never crossed devices.
    #[test]
    fn monitor_config_syncs_and_binds_to_the_right_server() {
        let (a, _ha) = device("A");
        a.execute("INSERT INTO servers(name,host,port) VALUES('web','h',22)", []).unwrap();
        a.execute(
            "INSERT INTO monitor_configs(node_id,enabled_metrics,custom_metrics,paused)
             VALUES((SELECT id FROM servers WHERE name='web'),'[\"cpu\",\"mem\"]','[\"nginx\"]',0)",
            [],
        )
        .unwrap();
        let recs = collect_local_records(&a, &KEY, "").unwrap();
        assert!(
            recs.iter().any(|r| r.entity_type == "monitor_configs"),
            "monitor config must be pushed"
        );

        // B has an unrelated server first, so its rowids differ from A's —
        // binding by uuid rather than by raw id is the whole point.
        let (b, hb) = device("B");
        b.execute("INSERT INTO servers(name,host,port) VALUES('other','o',22)", []).unwrap();
        apply_remote_records(&b, &KEY, &recs, &hb).unwrap();

        let bound: String = b
            .query_row(
                "SELECT s.name FROM monitor_configs mc JOIN servers s ON s.id = mc.node_id",
                [],
                |r| r.get(0),
            )
            .unwrap();
        assert_eq!(bound, "web", "config must attach to the SAME server, not a matching rowid");
        let metrics: String = b
            .query_row("SELECT enabled_metrics FROM monitor_configs", [], |r| r.get(0))
            .unwrap();
        assert_eq!(metrics, "[\"cpu\",\"mem\"]");
    }

    // Both devices enabling monitoring on the same server independently must
    // converge on one config row, not collide over its node_id primary key.
    #[test]
    fn independent_monitor_configs_for_one_server_converge() {
        let mk = |node: &str| {
            let (c, h) = device(node);
            c.execute("INSERT INTO servers(uuid,name,host,port) VALUES('fixedserveruuid00000000000000ab','web','h',22)", []).unwrap();
            c.execute(
                "INSERT INTO monitor_configs(node_id,enabled_metrics,custom_metrics,paused)
                 VALUES((SELECT id FROM servers WHERE name='web'),'[\"cpu\"]','[]',1)",
                [],
            )
            .unwrap();
            (c, h)
        };
        let (a, _ha) = mk("A");
        let (b, hb) = mk("B");

        let ua: String = a.query_row("SELECT uuid FROM monitor_configs", [], |r| r.get(0)).unwrap();
        let ub: String = b.query_row("SELECT uuid FROM monitor_configs", [], |r| r.get(0)).unwrap();
        assert_eq!(ua, ub, "same server ⇒ same config id on both devices");
        assert_ne!(ua, "fixedserveruuid00000000000000ab", "must not reuse the server's own id");

        apply_remote_records(&b, &KEY, &collect_local_records(&a, &KEY, "").unwrap(), &hb).unwrap();
        let n: i64 = b.query_row("SELECT COUNT(*) FROM monitor_configs", [], |r| r.get(0)).unwrap();
        assert_eq!(n, 1, "must converge to one config, not two");
    }

    // A config whose server hasn't arrived yet must be skipped, never written
    // with a NULL node_id — that column is the primary key, so SQLite would mint
    // a rowid and silently bind the config to nothing.
    #[test]
    fn monitor_config_without_its_server_is_skipped() {
        let (a, _ha) = device("A");
        a.execute("INSERT INTO servers(name,host,port) VALUES('web','h',22)", []).unwrap();
        a.execute(
            "INSERT INTO monitor_configs(node_id,enabled_metrics,custom_metrics,paused)
             VALUES((SELECT id FROM servers WHERE name='web'),'[\"cpu\"]','[]',1)",
            [],
        )
        .unwrap();
        let only_config: Vec<SyncRecord> = collect_local_records(&a, &KEY, "")
            .unwrap()
            .into_iter()
            .filter(|r| r.entity_type == "monitor_configs")
            .collect();
        assert_eq!(only_config.len(), 1);

        let (b, hb) = device("B"); // no servers at all
        apply_remote_records(&b, &KEY, &only_config, &hb).unwrap();
        let n: i64 = b.query_row("SELECT COUNT(*) FROM monitor_configs", [], |r| r.get(0)).unwrap();
        assert_eq!(n, 0, "orphan config must be skipped, not bound to a phantom node");
    }

    // Two devices doing ordinary independent work: one edits a server, the other
    // deletes that server's jump host. Both changes arrive in ONE batch. The FK
    // resolved fine while the jump host was still present, then the tombstone
    // removed it — and the fixup pass used to skip anything that had resolved, so
    // the link was left pointing at a row that no longer existed.
    #[test]
    fn a_referent_deleted_in_the_same_batch_clears_the_link() {
        let (a, _ha) = device("A");
        a.execute("INSERT INTO servers(name,host,port) VALUES('bastion','b',22)", []).unwrap();
        a.execute(
            "INSERT INTO servers(name,host,port,jump_host_id) VALUES('app','a',22,(SELECT id FROM servers WHERE name='bastion'))",
            [],
        )
        .unwrap();
        let seed = collect_local_records(&a, &KEY, "").unwrap();

        // Device C starts from the same state, so it holds both servers, linked.
        let (c, hc) = device("C");
        apply_remote_records(&c, &KEY, &seed, &hc).unwrap();
        let linked: i64 = c
            .query_row(
                "SELECT COUNT(*) FROM servers s JOIN servers j ON j.id = s.jump_host_id WHERE s.name='app'",
                [],
                |r| r.get(0),
            )
            .unwrap();
        assert_eq!(linked, 1, "precondition: the jump link exists on C");

        // A re-touches 'app' (so it ships as a live record) and deletes the
        // bastion (so a tombstone ships in the SAME batch).
        a.execute("UPDATE servers SET host='a2' WHERE name='app'", []).unwrap();
        a.execute("DELETE FROM servers WHERE name='bastion'", []).unwrap();
        let batch = collect_local_records(&a, &KEY, "").unwrap();
        assert!(batch.iter().any(|r| r.deleted), "batch must carry the tombstone");

        apply_remote_records(&c, &KEY, &batch, &hc).unwrap();
        let dangling: Option<i64> = c
            .query_row("SELECT jump_host_id FROM servers WHERE name='app'", [], |r| r.get(0))
            .unwrap();
        assert_eq!(dangling, None, "the link must be cleared, not left dangling");
    }

    #[test]
    fn round_trip_resolves_fks_across_devices() {
        let (a, _ha) = device("A");
        a.execute("INSERT INTO ssh_keys(name, public_key, private_key) VALUES('k','pub','priv')", []).unwrap();
        a.execute("INSERT INTO credentials(name, auth_type, username, key_id) VALUES('c','key','root',(SELECT id FROM ssh_keys WHERE name='k'))", []).unwrap();
        a.execute("INSERT INTO folders(name) VALUES('f')", []).unwrap();
        a.execute("INSERT INTO servers(name, host, port, credential_id, folder_id) VALUES('s1','h',22,(SELECT id FROM credentials WHERE name='c'),(SELECT id FROM folders WHERE name='f'))", []).unwrap();
        let recs = collect_local_records(&a, &KEY, "").unwrap();

        let (b, hb) = device("B");
        // Unrelated pre-existing row so B's autoincrement ids differ from A's,
        // proving the merge resolves references by uuid, not by raw id.
        b.execute("INSERT INTO folders(name) VALUES('other')", []).unwrap();
        apply_remote_records(&b, &KEY, &recs, &hb).unwrap();

        let (cred, folder): (String, String) = b.query_row(
            "SELECT (SELECT name FROM credentials c WHERE c.id=s.credential_id), (SELECT name FROM folders f WHERE f.id=s.folder_id) FROM servers s WHERE s.name='s1'",
            [], |r| Ok((r.get(0)?, r.get(1)?))).unwrap();
        assert_eq!(cred, "c", "server.credential_id must resolve to the right credential on B");
        assert_eq!(folder, "f", "server.folder_id must resolve to the right folder on B");
        let key_name: String = b.query_row("SELECT (SELECT name FROM ssh_keys k WHERE k.id=c.key_id) FROM credentials c WHERE c.name='c'", [], |r| r.get(0)).unwrap();
        assert_eq!(key_name, "k", "credential.key_id must resolve to the right ssh_key on B");
    }

    // Regression: `position` (NOT NULL) was added to servers' synced cols in
    // 0.3.5. A PRE-0.3.5 peer's payload omits the key, so apply_entity used to
    // bind an explicit SQL NULL, hit "NOT NULL constraint failed:
    // servers.position", and silently skip the whole server row — losing its
    // SSH credentials — with no self-heal. The merge must default a missing
    // position to 0 and land the row.
    #[test]
    fn a_pre_0_3_5_peer_server_without_position_still_merges() {
        let (a, _ha) = device("A");
        a.execute("INSERT INTO servers(name, host, port, password) VALUES('prod','h',22,'SECRET')", []).unwrap();
        let mut recs = collect_local_records(&a, &KEY, "").unwrap();
        // Rewrite the server blob to look like an old peer's: strip `position`.
        for r in recs.iter_mut() {
            if r.entity_type == "servers" {
                let plain = decrypt_entity(r.blob.as_deref().unwrap(), &KEY).unwrap();
                let mut obj: serde_json::Value = serde_json::from_slice(&plain).unwrap();
                obj.as_object_mut().unwrap().remove("position");
                assert!(obj.get("position").is_none(), "test setup: position must be absent");
                let bytes = serde_json::to_vec(&obj).unwrap();
                r.blob = Some(encrypt_entity(&bytes, &KEY).unwrap());
            }
        }

        let (b, hb) = device("B");
        apply_remote_records(&b, &KEY, &recs, &hb).unwrap();

        // Row must exist (not skipped), and the absent position defaults to 0.
        let (host, pos): (String, i64) = b
            .query_row("SELECT host, position FROM servers WHERE name='prod'", [], |r| Ok((r.get(0)?, r.get(1)?)))
            .expect("a server from a pre-0.3.5 peer (no position key) must merge, not be skipped");
        assert_eq!(host, "h");
        assert_eq!(pos, 0, "a missing position must default to 0");
    }

    // Regression for the UPDATE-arm half of the 0.3.5 position shim. The INSERT
    // case above lands a missing position as 0; here the row ALREADY EXISTS with
    // a manual drag-rank when a pre-0.3.5 peer (payload omits `position`) syncs a
    // winning edit to some OTHER field. The merge must apply the edit but KEEP
    // the local rank — binding the coerced 0 into `position=excluded.position`
    // would silently reset a deliberate ordering on every cross-version edit.
    #[test]
    fn a_pre_0_3_5_peer_edit_preserves_local_drag_position() {
        let (a, _ha) = device("A");
        a.execute("INSERT INTO servers(name, host, port, password) VALUES('prod','h1',22,'SECRET')", []).unwrap();

        // B receives the server, then the user drags it to rank 5.
        let (b, hb) = device("B");
        apply_remote_records(&b, &KEY, &collect_local_records(&a, &KEY, "").unwrap(), &hb).unwrap();
        b.execute("UPDATE servers SET position=5 WHERE name='prod'", []).unwrap();
        let pos_before: i64 = b.query_row("SELECT position FROM servers WHERE name='prod'", [], |r| r.get(0)).unwrap();
        assert_eq!(pos_before, 5, "test setup: B's local rank is 5");

        // A (an old peer) edits the host. Strip `position` from the blob and
        // stamp it a minute ahead of now (still a stamp the merge accepts), so
        // the record deterministically WINS LWW on B and reaches the UPDATE
        // arm — the case this fix guards.
        a.execute("UPDATE servers SET host='h2' WHERE name='prod'", []).unwrap();
        let mut recs = collect_local_records(&a, &KEY, "").unwrap();
        let ahead = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_millis() as u64 + 60_000;
        for r in recs.iter_mut() {
            if r.entity_type == "servers" {
                let plain = decrypt_entity(r.blob.as_deref().unwrap(), &KEY).unwrap();
                let mut obj: serde_json::Value = serde_json::from_slice(&plain).unwrap();
                obj.as_object_mut().unwrap().remove("position");
                r.blob = Some(encrypt_entity(&serde_json::to_vec(&obj).unwrap(), &KEY).unwrap());
                r.updated_at = format!("{ahead:015}:00000:zzz");
            }
        }
        apply_remote_records(&b, &KEY, &recs, &hb).unwrap();

        let (host, pos): (String, i64) = b
            .query_row("SELECT host, position FROM servers WHERE name='prod'", [], |r| Ok((r.get(0)?, r.get(1)?)))
            .unwrap();
        assert_eq!(host, "h2", "the newer remote field edit must apply");
        assert_eq!(pos, 5, "a pre-0.3.5 peer edit must NOT reset the local drag position to 0");
    }

    #[test]
    fn lww_older_remote_does_not_clobber_newer_local() {
        let (a, _ha) = device("A");
        a.execute("INSERT INTO servers(name, host, port) VALUES('s','h1',22)", []).unwrap();
        let old = collect_local_records(&a, &KEY, "").unwrap();
        let (b, hb) = device("B");
        apply_remote_records(&b, &KEY, &old, &hb).unwrap();
        b.execute("UPDATE servers SET host='h2-newer' WHERE name='s'", []).unwrap();
        apply_remote_records(&b, &KEY, &old, &hb).unwrap(); // re-apply the STALE version
        let host: String = b.query_row("SELECT host FROM servers WHERE name='s'", [], |r| r.get(0)).unwrap();
        assert_eq!(host, "h2-newer", "an older remote record must not overwrite a newer local edit");
    }

    // `sync_now` snapshots records under the DB lock, then DROPS the lock for
    // the network leg — so the user can delete a node while their own batch is
    // still in flight. The reply is the server's view computed from the
    // PRE-delete push (and `since` is always "", so it echoes everything back),
    // meaning it still carries the deleted node as live. The tombstone is the
    // only thing standing between that reply and a resurrected password.
    #[test]
    fn stale_inflight_batch_does_not_resurrect_a_deleted_row() {
        let (a, ha) = device("A");
        a.execute("INSERT INTO servers(name, host, port, password) VALUES('prod','h',22,'SUPERSECRET')", []).unwrap();

        // T=0 — sync collects the batch and lets go of the lock.
        let inflight = collect_local_records(&a, &KEY, "").unwrap();

        // T=2s — user deletes the node while the POST is still in flight.
        a.execute("DELETE FROM servers WHERE name='prod'", []).unwrap();

        // T=5s — reply lands, still carrying 'prod' as live at its old stamp.
        apply_remote_records(&a, &KEY, &inflight, &ha).unwrap();

        let live: i64 = a
            .query_row("SELECT COUNT(*) FROM servers WHERE name='prod'", [], |r| r.get(0))
            .unwrap();
        assert_eq!(live, 0, "a stale in-flight batch must not resurrect a deleted row");
    }

    // The mirror case: a delete must not shadow a genuine re-creation. If some
    // other device creates a row again AFTER our delete, its stamp is newer than
    // our tombstone and it has to land.
    #[test]
    fn tombstone_does_not_block_a_newer_recreate() {
        let (a, ha) = device("A");
        a.execute("INSERT INTO servers(name, host, port) VALUES('s','h1',22)", []).unwrap();
        let uuid: String = a.query_row("SELECT uuid FROM servers WHERE name='s'", [], |r| r.get(0)).unwrap();
        a.execute("DELETE FROM servers WHERE name='s'", []).unwrap();
        assert_eq!(
            a.query_row("SELECT COUNT(*) FROM sync_tombstones WHERE uuid=?1", [&uuid], |r| r.get::<_, i64>(0)).unwrap(),
            1,
        );

        // Device B re-creates the same uuid later (newer HLC than our tombstone).
        let (b, hb) = device("B");
        b.execute("INSERT INTO servers(name, host, port) VALUES('s','h2-recreated',22)", []).unwrap();
        b.execute("UPDATE servers SET uuid=?1, updated_at=hlc_now() WHERE name='s'", [&uuid]).unwrap();
        let recreate = collect_local_records(&b, &KEY, "").unwrap();
        let _ = hb;

        apply_remote_records(&a, &KEY, &recreate, &ha).unwrap();
        let host: Option<String> = a.query_row("SELECT host FROM servers WHERE uuid=?1", [&uuid], |r| r.get(0)).ok();
        assert_eq!(
            host.as_deref(),
            Some("h2-recreated"),
            "a re-create newer than the tombstone must still apply",
        );
    }

    #[test]
    fn delete_propagates_via_tombstone() {
        let (a, _ha) = device("A");
        a.execute("INSERT INTO servers(name, host, port) VALUES('s','h',22)", []).unwrap();
        let (b, hb) = device("B");
        apply_remote_records(&b, &KEY, &collect_local_records(&a, &KEY, "").unwrap(), &hb).unwrap();
        assert_eq!(b.query_row("SELECT COUNT(*) FROM servers WHERE name='s'", [], |r| r.get::<_, i64>(0)).unwrap(), 1);
        a.execute("DELETE FROM servers WHERE name='s'", []).unwrap();
        let recs = collect_local_records(&a, &KEY, "").unwrap();
        assert!(recs.iter().any(|r| r.deleted), "delete must produce a tombstone record");
        apply_remote_records(&b, &KEY, &recs, &hb).unwrap();
        assert_eq!(b.query_row("SELECT COUNT(*) FROM servers WHERE name='s'", [], |r| r.get::<_, i64>(0)).unwrap(), 0, "delete must propagate to B");
    }

    // One corrupt / hostile record from a broken (or compromised) server must be
    // skipped, never abort the whole merge — every OTHER record in the same batch
    // still lands. This is the "one poison record can't take sync down" guarantee.
    #[test]
    fn corrupt_record_is_skipped_without_aborting_the_batch() {
        let (a, _ha) = device("A");
        a.execute("INSERT INTO servers(name, host, port) VALUES('good','h-good',22)", []).unwrap();
        let mut recs = collect_local_records(&a, &KEY, "").unwrap();

        // A record shaped like a real 'servers' row but whose blob is valid
        // ciphertext under the WRONG key — it can't decrypt under KEY, exactly
        // like a corrupt or tampered blob. Placed FIRST so we prove the good
        // record after it still applies once the poison one is skipped.
        let good = recs.iter().find(|r| r.entity_type == "servers").unwrap().clone();
        let mut poison = good.clone();
        poison.uuid = "ab".repeat(16);
        poison.blob = Some(encrypt_entity(br#"{"host":"h-poison"}"#, &[9u8; 32]).unwrap());
        recs.insert(0, poison);

        let (b, hb) = device("B");
        // Must NOT return Err — the poison record is logged and skipped internally.
        apply_remote_records(&b, &KEY, &recs, &hb).unwrap();

        // The good record landed...
        let host: Option<String> =
            b.query_row("SELECT host FROM servers WHERE name='good'", [], |r| r.get(0)).ok();
        assert_eq!(host.as_deref(), Some("h-good"), "a valid record must apply despite a poison record in the batch");
        // ...and the corrupt record created no row.
        assert_eq!(
            b.query_row("SELECT COUNT(*) FROM servers", [], |r| r.get::<_, i64>(0)).unwrap(),
            1,
            "the corrupt record must be skipped, never inserted",
        );
    }

    // After a share's key is replaced, every row goes out again: its stamp
    // moves up by the smallest step (same moment and device, counter + 1), so
    // the server takes the copy sealed with the new key, while an edit made
    // since, anywhere, still wins. Nothing takes it for an edit.
    #[test]
    fn a_new_share_key_sends_every_row_again() {
        let (a, _ha) = device("A");
        a.execute("INSERT INTO sync_meta(key,value) VALUES('editor_label','alice@x')", []).unwrap();
        a.execute("INSERT INTO servers(name,host,port) VALUES('s','h',22)", []).unwrap();
        a.execute("INSERT INTO notes(title,body) VALUES('n','b')", []).unwrap();
        // A counter that can't go up any further: left as it is.
        a.execute("UPDATE notes SET updated_at='000000000000001:99999:x'", []).unwrap();
        let row = |c: &Connection| -> (String, Option<String>) {
            c.query_row("SELECT updated_at, edited_by FROM servers", [], |r| Ok((r.get(0)?, r.get(1)?))).unwrap()
        };
        let (before, by) = row(&a);

        assert_eq!(bump_for_new_key(&a).unwrap(), 1);
        let (after, by_after) = row(&a);
        assert_eq!((&after[..16], &after[21..]), (&before[..16], &before[21..]), "same moment, same device");
        assert_eq!(after[16..21].parse::<u32>().unwrap(), before[16..21].parse::<u32>().unwrap() + 1);
        assert_eq!(by_after, by, "not taken for an edit");
        let note: String = a.query_row("SELECT updated_at FROM notes", [], |r| r.get(0)).unwrap();
        assert_eq!(note, "000000000000001:99999:x");
        let merging: i64 = a.query_row("SELECT val FROM sync_flags WHERE key='merge'", [], |r| r.get(0)).unwrap();
        assert_eq!(merging, 0, "the merge flag is off again");

        // Newer than the copy under the old key, older than any later edit.
        let later = format!("{:015}:00000:0", hlc::Hlc::phys_of(&before) + 1);
        assert!(before < after && after < later);
    }

    /// `device`, holding a shared profile, so what approvals.rs holds back applies.
    fn shared_device(node: &str) -> (Connection, std::sync::Arc<hlc::Hlc>) {
        let (c, h) = device(node);
        approvals::create_schema(&c).unwrap();
        c.execute("INSERT INTO sync_meta(key,value) VALUES('share_id','s1')", []).unwrap();
        (c, h)
    }

    fn count(c: &Connection, table: &str) -> i64 {
        c.query_row(&format!("SELECT COUNT(*) FROM {table}"), [], |r| r.get(0)).unwrap()
    }

    /// A deletes 12 of its 15 servers; B (shared) holds those deletions.
    fn mass_deleted() -> (Connection, std::sync::Arc<hlc::Hlc>, Connection, std::sync::Arc<hlc::Hlc>, Vec<SyncRecord>) {
        let (a, ha) = device("A");
        for i in 0..15 {
            a.execute("INSERT INTO servers(name,host,port) VALUES(?1,'h',22)", [format!("s{i:02}")]).unwrap();
        }
        let (b, hb) = shared_device("B");
        apply_remote_records(&b, &KEY, &collect_local_records(&a, &KEY, "").unwrap(), &hb).unwrap();
        a.execute("DELETE FROM servers WHERE name >= 's03'", []).unwrap();
        let batch = collect_local_records(&a, &KEY, "").unwrap();
        apply_remote_records(&b, &KEY, &batch, &hb).unwrap();
        assert_eq!((count(&b, "servers"), approvals::held_deletions(&b).len()), (15, 12));
        (a, ha, b, hb, batch)
    }

    // In a shared profile, a sync that would delete much of it at once (more
    // than 10 rows and more than a quarter of it), or any SSH key, waits for
    // this device's user; a smaller one goes through, and a personal profile
    // never holds anything.
    #[test]
    fn a_shared_profiles_mass_deletion_waits() {
        let (a, _ha) = device("A");
        for i in 0..20 {
            a.execute("INSERT INTO servers(name,host,port) VALUES(?1,'h',22)", [format!("s{i:02}")]).unwrap();
        }
        a.execute("INSERT INTO ssh_keys(name,public_key,private_key) VALUES('k','pub','priv')", []).unwrap();
        let seed = collect_local_records(&a, &KEY, "").unwrap();
        let (b, hb) = shared_device("B");
        apply_remote_records(&b, &KEY, &seed, &hb).unwrap();
        let (p, hp) = device("P");
        apply_remote_records(&p, &KEY, &seed, &hp).unwrap();

        a.execute("DELETE FROM servers WHERE name < 's04'", []).unwrap();
        apply_remote_records(&b, &KEY, &collect_local_records(&a, &KEY, "").unwrap(), &hb).unwrap();
        assert_eq!(count(&b, "servers"), 16, "four deletions go through");

        a.execute("DELETE FROM servers WHERE name < 's16'", []).unwrap();
        let batch = collect_local_records(&a, &KEY, "").unwrap();
        apply_remote_records(&b, &KEY, &batch, &hb).unwrap();
        assert_eq!(count(&b, "servers"), 16, "twelve at once wait");
        assert_eq!(approvals::held_deletions(&b).len(), 12);
        apply_remote_records(&b, &KEY, &batch, &hb).unwrap();
        assert_eq!((count(&b, "servers"), approvals::held_deletions(&b).len()), (16, 12), "the next sync changes nothing");
        apply_remote_records(&p, &KEY, &batch, &hp).unwrap();
        assert_eq!(count(&p, "servers"), 4, "a personal profile takes them all");

        a.execute("DELETE FROM ssh_keys", []).unwrap();
        apply_remote_records(&b, &KEY, &collect_local_records(&a, &KEY, "").unwrap(), &hb).unwrap();
        assert_eq!(count(&b, "ssh_keys"), 1, "an SSH key waits");
        assert!(approvals::held_deletions(&b).iter().any(|d| d.entity_type == "ssh_keys" && d.name == "k"));
    }

    // The user's call: delete them here too, or keep them. Kept rows get
    // stamps newer than the deletions, so they win them back on every device
    // and the same deletions coming again don't take them.
    #[test]
    fn held_deletions_are_deleted_or_kept_by_the_user() {
        let (_a, _ha, b, hb, _batch) = mass_deleted();
        assert_eq!(resolve_held(&b, &hb, true).unwrap(), 12);
        assert_eq!((count(&b, "servers"), count(&b, "sync_tombstones")), (3, 12));
        assert!(approvals::held_deletions(&b).is_empty());

        let (a, ha, b, hb, batch) = mass_deleted();
        assert_eq!(resolve_held(&b, &hb, false).unwrap(), 12);
        assert_eq!(count(&b, "servers"), 15);
        assert!(approvals::held_deletions(&b).is_empty());
        apply_remote_records(&a, &KEY, &collect_local_records(&b, &KEY, "").unwrap(), &ha).unwrap();
        assert_eq!(count(&a, "servers"), 15, "kept rows come back where they were deleted");
        apply_remote_records(&b, &KEY, &batch, &hb).unwrap();
        assert_eq!((count(&b, "servers"), approvals::held_deletions(&b).len()), (15, 0), "the old deletions don't take them");
    }

    #[test]
    fn a_kept_rows_stamp_sorts_after_the_deletion() {
        let del = "999999999999990:00007:peer";
        assert_eq!(stamp_past("000000000000005:00000:me", del), "999999999999990:00008:peer");
        assert_eq!(stamp_past("999999999999999:00000:me", del), "999999999999999:00000:me");
        assert_eq!(stamp_past("000000000000005:00000:me", "999999999999990:99999:peer"), "000000000000005:00000:me");
    }

    /// A stamp `ms` ahead of now: newer than anything a test device has
    /// issued, and still one the merge accepts.
    fn ahead(ms: u64) -> String {
        let now = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_millis() as u64;
        format!("{:015}:00000:zzz", now + ms)
    }

    /// `rec` with its payload changed by `edit`, at a newer stamp: what a
    /// peer, or the server, could send in its place.
    fn reworked(rec: &SyncRecord, edit: impl FnOnce(&mut serde_json::Map<String, serde_json::Value>)) -> SyncRecord {
        let plain = decrypt_entity(rec.blob.as_deref().unwrap(), &KEY).unwrap();
        let mut obj: serde_json::Value = serde_json::from_slice(&plain).unwrap();
        edit(obj.as_object_mut().unwrap());
        SyncRecord {
            updated_at: ahead(60_000),
            blob: Some(encrypt_entity(&serde_json::to_vec(&obj).unwrap(), &KEY).unwrap()),
            ..rec.clone()
        }
    }

    fn live<'a>(recs: &'a [SyncRecord], table: &str) -> &'a SyncRecord {
        recs.iter().find(|r| r.entity_type == table && !r.deleted).unwrap()
    }

    // A stamp far ahead of now, or one no clock issues ("~" sorts after them
    // all), would win LWW against every later edit and delete of its row, on
    // every device. Those records are skipped, as are ids that aren't hex;
    // the rest of the batch lands.
    #[test]
    fn records_with_a_bad_stamp_or_id_are_skipped() {
        let (a, _ha) = device("A");
        a.execute("INSERT INTO servers(name,host,port) VALUES('s','h1',22)", []).unwrap();
        a.execute("INSERT INTO notes(title,body) VALUES('n','b1')", []).unwrap();
        let seed = collect_local_records(&a, &KEY, "").unwrap();
        let (b, hb) = device("B");
        apply_remote_records(&b, &KEY, &seed, &hb).unwrap();

        let mut far = reworked(live(&seed, "servers"), |o| {
            o.insert("host".into(), "elsewhere".into());
        });
        far.updated_at = "999999999999999:99999:zzz".into();
        let undeletable = SyncRecord { deleted: true, blob: None, updated_at: "~".into(), ..live(&seed, "notes").clone() };
        let mut not_hex = reworked(live(&seed, "servers"), |o| {
            o.insert("name".into(), "copy".into());
        });
        not_hex.uuid = "not-a-hex-id".into();
        let fine = reworked(live(&seed, "notes"), |o| {
            o.insert("body".into(), "b2".into());
        });
        apply_remote_records(&b, &KEY, &[far, undeletable, not_hex, fine], &hb).unwrap();

        let host: String = b.query_row("SELECT host FROM servers WHERE name='s'", [], |r| r.get(0)).unwrap();
        assert_eq!(host, "h1", "a stamp far ahead must not apply");
        let servers: i64 = b.query_row("SELECT COUNT(*) FROM servers", [], |r| r.get(0)).unwrap();
        assert_eq!(servers, 1, "an id that isn't hex must not land");
        let body: String = b.query_row("SELECT body FROM notes WHERE title='n'", [], |r| r.get(0)).unwrap();
        assert_eq!(body, "b2", "the note outlives the bogus delete, and the valid edit lands");
        let tombs: i64 = b.query_row("SELECT COUNT(*) FROM sync_tombstones", [], |r| r.get(0)).unwrap();
        assert_eq!(tombs, 0);
    }

    // A value a list reader can't take (a NULL name, a port that isn't a
    // number) used to fail the whole list, on every device the record
    // reached. Each of these is skipped, and the row keeps what it had.
    #[test]
    fn values_the_lists_cannot_read_are_skipped() {
        use serde_json::{json, Value};
        let (a, _ha) = device("A");
        a.execute("INSERT INTO servers(name,host,port,autostart) VALUES('s','h',22,0)", []).unwrap();
        a.execute("INSERT INTO credentials(name,auth_type,username) VALUES('c','password','root')", []).unwrap();
        a.execute("INSERT INTO notes(title,body) VALUES('n','b')", []).unwrap();
        let seed = collect_local_records(&a, &KEY, "").unwrap();
        let (server, cred, note) = (live(&seed, "servers"), live(&seed, "credentials"), live(&seed, "notes"));
        let bad = [
            reworked(server, |o| {
                o.insert("name".into(), Value::Null);
            }),
            reworked(server, |o| {
                o.remove("host");
            }),
            reworked(server, |o| {
                o.insert("port".into(), json!("22"));
            }),
            reworked(server, |o| {
                o.insert("port".into(), json!(1u64 << 40));
            }),
            reworked(server, |o| {
                o.insert("port".into(), json!(22.5));
            }),
            reworked(server, |o| {
                o.insert("proxy_port".into(), json!("1080"));
            }),
            reworked(server, |o| {
                o.insert("autostart".into(), json!("yes"));
            }),
            reworked(server, |o| {
                o.insert("tunnels".into(), json!([1]));
            }),
            reworked(cred, |o| {
                o.insert("username".into(), Value::Null);
            }),
            reworked(note, |o| {
                o.insert("body".into(), json!(7));
            }),
        ];
        let (b, hb) = device("B");
        apply_remote_records(&b, &KEY, &seed, &hb).unwrap();
        apply_remote_records(&b, &KEY, &bad, &hb).unwrap();
        type Row = (String, String, i64, Option<i64>, i64, Option<String>, String, String);
        let row: Row = b
            .query_row(
                "SELECT s.name, s.host, s.port, s.proxy_port, s.autostart, s.tunnels, c.username, n.body FROM servers s, credentials c, notes n",
                [],
                |r| Ok((r.get(0)?, r.get(1)?, r.get(2)?, r.get(3)?, r.get(4)?, r.get(5)?, r.get(6)?, r.get(7)?)),
            )
            .unwrap();
        assert_eq!(row, ("s".into(), "h".into(), 22, None, 0, None, "root".into(), "b".into()));

        // What fits still goes through: a proxy port, autostart as true.
        let fits = reworked(server, |o| {
            o.insert("proxy_port".into(), json!(1080));
            o.insert("autostart".into(), json!(true));
        });
        apply_remote_records(&b, &KEY, &[fits], &hb).unwrap();
        let (proxy, auto): (i64, i64) =
            b.query_row("SELECT proxy_port, autostart FROM servers", [], |r| Ok((r.get(0)?, r.get(1)?))).unwrap();
        assert_eq!((proxy, auto), (1080, 1));
    }

    // A record's links are set after the whole batch, so they used to be set
    // even when the record itself failed to write: the row it failed to
    // replace still ended up pointing where the record said (a server routed
    // through someone else's jump host).
    #[test]
    fn a_record_that_fails_to_write_sets_no_links() {
        let (a, _ha) = device("A");
        a.execute("INSERT INTO servers(name,host,port) VALUES('app','a',22)", []).unwrap();
        a.execute("INSERT INTO servers(name,host,port) VALUES('relay','r',22)", []).unwrap();
        let seed = collect_local_records(&a, &KEY, "").unwrap();
        let (b, hb) = device("B");
        apply_remote_records(&b, &KEY, &seed, &hb).unwrap();
        // Something makes the write fail on B: a trigger here, a constraint
        // would do the same.
        b.execute_batch(
            "CREATE TRIGGER refuse BEFORE UPDATE ON servers WHEN NEW.host = 'boom' BEGIN SELECT RAISE(ABORT, 'refused'); END;",
        )
        .unwrap();
        let app_uuid: String = a.query_row("SELECT uuid FROM servers WHERE name='app'", [], |r| r.get(0)).unwrap();
        let relay: String = a.query_row("SELECT uuid FROM servers WHERE name='relay'", [], |r| r.get(0)).unwrap();
        let app = seed.iter().find(|r| r.uuid == app_uuid).unwrap();

        let failing = reworked(app, |o| {
            o.insert("host".into(), "boom".into());
            o.insert("jump_uuid".into(), relay.clone().into());
        });
        apply_remote_records(&b, &KEY, &[failing], &hb).unwrap();
        let (host, jump): (String, Option<i64>) = b
            .query_row("SELECT host, jump_host_id FROM servers WHERE name='app'", [], |r| Ok((r.get(0)?, r.get(1)?)))
            .unwrap();
        assert_eq!((host.as_str(), jump), ("a", None), "a record that didn't land must not relink the row");

        // The same record without the failure lands, link and all.
        let lands = reworked(app, |o| {
            o.insert("jump_uuid".into(), relay.clone().into());
        });
        apply_remote_records(&b, &KEY, &[lands], &hb).unwrap();
        let linked: String = b
            .query_row("SELECT j.name FROM servers s JOIN servers j ON j.id = s.jump_host_id WHERE s.name='app'", [], |r| r.get(0))
            .unwrap();
        assert_eq!(linked, "relay");
    }

    // A folder deleted elsewhere can still hold a server here (one added on
    // this device meanwhile), and a deleted key can still be a login's key.
    // With foreign keys enforced, as the app enforces them, the delete used
    // to fail with its tombstone recorded anyway: the row stayed, while this
    // device told every other one it was gone. Now the links are cleared,
    // the row goes, and then the tombstone is recorded.
    #[test]
    fn a_remote_delete_unlinks_what_still_points_at_it() {
        let (a, _ha) = device_with("A", true);
        a.execute("INSERT INTO folders(name) VALUES('f')", []).unwrap();
        a.execute("INSERT INTO ssh_keys(name,public_key,private_key) VALUES('k','pub','priv')", []).unwrap();
        let (b, hb) = device_with("B", true);
        apply_remote_records(&b, &KEY, &collect_local_records(&a, &KEY, "").unwrap(), &hb).unwrap();
        // Meanwhile on B: a server in that folder, a login using that key.
        b.execute(
            "INSERT INTO servers(name,host,port,folder_id) VALUES('s','h',22,(SELECT id FROM folders WHERE name='f'))",
            [],
        )
        .unwrap();
        b.execute(
            "INSERT INTO credentials(name,auth_type,username,key_id) VALUES('c','key','root',(SELECT id FROM ssh_keys WHERE name='k'))",
            [],
        )
        .unwrap();

        a.execute("DELETE FROM folders WHERE name='f'", []).unwrap();
        a.execute("DELETE FROM ssh_keys WHERE name='k'", []).unwrap();
        apply_remote_records(&b, &KEY, &collect_local_records(&a, &KEY, "").unwrap(), &hb).unwrap();

        let left: i64 = b
            .query_row("SELECT (SELECT COUNT(*) FROM folders) + (SELECT COUNT(*) FROM ssh_keys)", [], |r| r.get(0))
            .unwrap();
        assert_eq!(left, 0, "the folder and the key are deleted");
        let links: (Option<i64>, Option<i64>) = b
            .query_row(
                "SELECT (SELECT folder_id FROM servers WHERE name='s'), (SELECT key_id FROM credentials WHERE name='c')",
                [],
                |r| Ok((r.get(0)?, r.get(1)?)),
            )
            .unwrap();
        assert_eq!(links, (None, None), "what pointed at them stays, unlinked");
        let tombs: i64 = b.query_row("SELECT COUNT(*) FROM sync_tombstones", [], |r| r.get(0)).unwrap();
        assert_eq!(tombs, 2);
    }

    // And a delete that fails all the same leaves nothing of itself: no
    // tombstone saying it happened, no links cleared.
    #[test]
    fn a_remote_delete_that_fails_leaves_no_trace() {
        let (a, _ha) = device("A");
        a.execute("INSERT INTO servers(name,host,port) VALUES('relay','r',22)", []).unwrap();
        a.execute(
            "INSERT INTO servers(name,host,port,jump_host_id) VALUES('app','a',22,(SELECT id FROM servers WHERE name='relay'))",
            [],
        )
        .unwrap();
        let (b, hb) = device("B");
        apply_remote_records(&b, &KEY, &collect_local_records(&a, &KEY, "").unwrap(), &hb).unwrap();
        b.execute_batch("CREATE TRIGGER keep BEFORE DELETE ON servers WHEN OLD.name = 'relay' BEGIN SELECT RAISE(ABORT, 'kept'); END;")
            .unwrap();

        a.execute("DELETE FROM servers WHERE name='relay'", []).unwrap();
        let deletes: Vec<SyncRecord> =
            collect_local_records(&a, &KEY, "").unwrap().into_iter().filter(|r| r.deleted).collect();
        assert_eq!(deletes.len(), 1);
        apply_remote_records(&b, &KEY, &deletes, &hb).unwrap();

        let jump: Option<String> = b
            .query_row("SELECT j.name FROM servers s LEFT JOIN servers j ON j.id = s.jump_host_id WHERE s.name='app'", [], |r| r.get(0))
            .unwrap();
        assert_eq!(jump.as_deref(), Some("relay"), "the link is as it was");
        let tombs: i64 = b.query_row("SELECT COUNT(*) FROM sync_tombstones", [], |r| r.get(0)).unwrap();
        assert_eq!(tombs, 0, "no tombstone for a delete that didn't happen");
    }

    // Tombstones for rows this device never had used to be stored, and pushed
    // back on every sync forever, however many a hostile peer sent. Only a
    // tombstone this device already holds is kept current.
    #[test]
    fn tombstones_for_rows_never_here_are_not_kept() {
        let (b, hb) = device("B");
        let strangers: Vec<SyncRecord> = (0..50)
            .map(|i| SyncRecord {
                uuid: format!("{i:032x}"),
                entity_type: "servers".into(),
                updated_at: ahead(1_000),
                deleted: true,
                blob: None,
            })
            .collect();
        apply_remote_records(&b, &KEY, &strangers, &hb).unwrap();
        let n: i64 = b.query_row("SELECT COUNT(*) FROM sync_tombstones", [], |r| r.get(0)).unwrap();
        assert_eq!(n, 0);

        // B's own delete, coming back newer, still updates B's tombstone.
        b.execute("INSERT INTO servers(name,host,port) VALUES('s','h',22)", []).unwrap();
        let uuid: String = b.query_row("SELECT uuid FROM servers", [], |r| r.get(0)).unwrap();
        b.execute("DELETE FROM servers", []).unwrap();
        let newer = SyncRecord {
            uuid: uuid.clone(),
            entity_type: "servers".into(),
            updated_at: ahead(5_000),
            deleted: true,
            blob: None,
        };
        apply_remote_records(&b, &KEY, std::slice::from_ref(&newer), &hb).unwrap();
        let at: String = b.query_row("SELECT updated_at FROM sync_tombstones WHERE uuid=?1", [&uuid], |r| r.get(0)).unwrap();
        assert_eq!(at, newer.updated_at);
    }

    // Past the server's own per-record limit: only a broken or hostile server
    // sends that, and it's skipped before it's decrypted.
    #[test]
    fn a_record_over_the_size_limit_is_skipped() {
        let (a, _ha) = device("A");
        a.execute("INSERT INTO notes(title,body) VALUES('n','b')", []).unwrap();
        let seed = collect_local_records(&a, &KEY, "").unwrap();
        let (b, hb) = device("B");
        apply_remote_records(&b, &KEY, &seed, &hb).unwrap();
        let big = reworked(live(&seed, "notes"), |o| {
            o.insert("body".into(), "x".repeat(MAX_RECORD_BLOB_HEX / 2).into());
        });
        assert!(big.blob.as_ref().unwrap().len() > MAX_RECORD_BLOB_HEX);
        apply_remote_records(&b, &KEY, &[big], &hb).unwrap();
        let body: String = b.query_row("SELECT body FROM notes", [], |r| r.get(0)).unwrap();
        assert_eq!(body, "b");
    }

    // A merge that would take the vault toward the size it can no longer be
    // saved or opened at lands nothing at all.
    #[test]
    fn a_merge_that_would_outgrow_the_vault_lands_nothing() {
        let (a, _ha) = device("A");
        for i in 0..8 {
            a.execute(
                "INSERT INTO notes(title,body) VALUES(?1,?2)",
                rusqlite::params![format!("n{i}"), "x".repeat(64 * 1024)],
            )
            .unwrap();
        }
        let recs = collect_local_records(&a, &KEY, "").unwrap();
        let (b, hb) = device("B");
        let limit = vault_bytes(&b).unwrap() + 128 * 1024;
        let err = apply_remote_inner(&b, &KEY, &recs, &hb, limit).unwrap_err();
        assert!(err.contains("TOO_LARGE"), "{err}");
        let n: i64 = b.query_row("SELECT COUNT(*) FROM notes", [], |r| r.get(0)).unwrap();
        assert_eq!(n, 0, "none of it lands");

        apply_remote_inner(&b, &KEY, &recs, &hb, limit * 8).unwrap();
        let n: i64 = b.query_row("SELECT COUNT(*) FROM notes", [], |r| r.get(0)).unwrap();
        assert_eq!(n, 8);
    }

    // A vault past what an unlock opens is never written: the file on disk
    // stays as it was, and still opens.
    #[test]
    fn a_vault_too_large_to_open_is_not_saved() {
        let conn = Connection::open_in_memory().unwrap();
        conn.execute_batch("CREATE TABLE t(b BLOB)").unwrap();
        conn.execute("INSERT INTO t VALUES(zeroblob(?1))", [VAULT_MAX_BYTES as i64 + 1]).unwrap();
        let dir = std::env::temp_dir().join(format!("submarine-vault-cap-{}", std::process::id()));
        std::fs::create_dir_all(&dir).unwrap();
        let path = dir.join("p.submarine");
        std::fs::write(&path, b"the old vault").unwrap();
        let err = save_vault_blocking(&conn, &Zeroizing::new([7u8; 32]), &[1u8; SALT_LEN], &path).unwrap_err();
        assert!(err.contains("TOO_LARGE"), "{err}");
        assert_eq!(std::fs::read(&path).unwrap(), b"the old vault");
        let _ = std::fs::remove_dir_all(&dir);
    }
}

/// Async-friendly vault save: the same as `save_vault_internal`, on a
/// blocking-pool thread, so the SQLite serialise + zstd + AES-GCM + fsync
/// chain doesn't stall concurrent terminal output and keystrokes on the
/// tokio worker pool.
///
/// The database, key, salt and path are all read under the connection's
/// lock, which is also what opening or closing a profile holds while it
/// swaps them. Taking the key and path first and the database later (as
/// this used to) could pair one profile's key and file with the next
/// profile's data when the user switched profiles in between.
async fn save_vault_async(state: &DbState) -> Result<(), String> {
    let conn_arc = std::sync::Arc::clone(&state.conn);
    let generation = std::sync::Arc::clone(&state.generation);
    let (key, salt, path, opened) = {
        let cg = state.conn.lock().map_err(|_| "[STATE] MUTEX_POISON_CONN")?;
        let kg = state.master_key.lock().map_err(|_| "[STATE] MUTEX_POISON_KEY")?;
        let sg = state.salt.lock().map_err(|_| "[STATE] MUTEX_POISON_SALT")?;
        let pg = state.db_path.lock().map_err(|_| "[STATE] MUTEX_POISON_PATH")?;
        match (cg.as_ref(), kg.as_ref(), sg.as_ref(), pg.as_ref()) {
            (Some(_), Some(k), Some(s), Some(p)) => (k.clone(), *s, p.clone(), state.generation_now()),
            _ => return Err("[STATE] MISSING_REQUIRED_RESOURCES_FOR_SAVE".into()),
        }
    };
    tokio::task::spawn_blocking(move || {
        let cg = conn_arc.lock().map_err(|_| "[STATE] MUTEX_POISON_CONN")?;
        // The database now under the lock has to be the one the key and path
        // above belong to.
        if generation.load(std::sync::atomic::Ordering::SeqCst) != opened {
            return Err("[STATE] PROFILE_CHANGED: the profile was locked, or another one opened, before it could be saved.".to_string());
        }
        let conn = cg.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;
        save_vault_blocking(conn, &key, &salt, &path)
    })
    .await
    .map_err(|e| format!("[CRYPTO] VAULT_JOIN: {}", e))?
}

/// Returns the list of available profile names (sorted, lowercased not enforced).
#[tauri::command]
async fn list_profiles(app_handle: tauri::AppHandle) -> Result<Vec<String>, String> {
    let dir = profiles_dir(&app_handle)?;
    if !dir.exists() {
        return Ok(Vec::new());
    }
    let mut out = Vec::new();
    for entry in fs::read_dir(&dir).map_err(|e| format!("[FILE] READ_DIR_FAILED: {}", e))? {
        let entry = match entry { Ok(e) => e, Err(_) => continue };
        let path = entry.path();
        if !path.is_file() { continue; }
        if path.extension().and_then(|e| e.to_str()) != Some("submarine") { continue; }
        if let Some(stem) = path.file_stem().and_then(|s| s.to_str()) {
            // Hide anything that wouldn't pass our name validator — likely
            // a manually-placed file or stray artefact. We don't surface it
            // because the user has no way to act on it from the UI.
            if validate_profile_name(stem).is_ok() {
                out.push(stem.to_string());
            }
        }
    }
    out.sort_by(|a, b| a.to_lowercase().cmp(&b.to_lowercase()));
    Ok(out)
}

/// List the caller's CLOUD profiles (from the per-entity sync store) so the
/// picker can surface profiles that exist in the account but not yet on this
/// device — the "sign in and see all your profiles" path. Read-only; requires
/// a signed-in cloud session. The UI merges these with the local
/// `list_profiles`, matching by name: a profile present locally is opened with
/// its password; a cloud-only one is restored (name pre-filled) then opened.
#[tauri::command]
async fn cloud_list_sync_profiles(
    app: tauri::AppHandle,
    cloud: tauri::State<'_, std::sync::Arc<cloud::CloudState>>,
) -> Result<Vec<cloud::SyncProfileInfo>, String> {
    let session = cloud.session().await?;
    cloud::list_sync_profiles(&app, &cloud, &session).await
}

/// Delete one of the caller's OWN personal profiles from the cloud: wipes every
/// synced record (data, tombstones, and the escrow key) for that partition on
/// the server. Owner-scoped by construction — the /sync store is per-user, so a
/// caller can only ever delete their own partition. The local vault (if any) is
/// left alone; the UI offers "remove from this device" as a separate action.
/// Returns the number of records the server removed.
#[tauri::command]
async fn cloud_delete_profile(
    app: tauri::AppHandle,
    cloud: tauri::State<'_, std::sync::Arc<cloud::CloudState>>,
    profile: String,
) -> Result<i64, String> {
    let profile = profile.trim().to_string();
    if profile.is_empty() {
        return Err("[SYNC] NO_PROFILE_NAME".into());
    }
    let session = cloud.session().await?;
    cloud::delete_sync_profile(&app, &cloud, &session, &profile).await
}

/// Replace this profile's entire cloud copy with what's on THIS device.
///
/// The escape hatch for a partition that can no longer converge. Records are
/// encrypted with the profile's DEK, and a vault copy that reached a device
/// without one — an old pre-sync backup, say — mints a brand-new DEK on open and
/// pushes everything under it. Those records are then permanently undecryptable
/// to every other device: the merge skips them on every sync (correctly — they
/// could be corrupt or hostile), so they sit in the cloud forever showing up as
/// "N to receive" that no amount of syncing can clear. Nothing else can remove
/// them, because you can't tombstone a record whose uuid you never learned.
///
/// Wipes the server partition, then pushes the local vault back in full. Local
/// data is never touched. Personal profiles only — on a shared one this would
/// silently destroy other members' contributions, which is not a decision one
/// member gets to make from a "fix my sync" button.
#[tauri::command]
async fn force_push_profile(
    app: tauri::AppHandle,
    db_state: tauri::State<'_, DbState>,
    cloud: tauri::State<'_, std::sync::Arc<cloud::CloudState>>,
) -> Result<SyncReport, String> {
    let profile = db_state
        .active_profile
        .lock()
        .map_err(|_| "[STATE] LOCK_PROFILE")?
        .clone()
        .ok_or("[SYNC] NO_PROFILE_OPEN")?;
    let session = cloud.session().await?;
    let (share_id, cloud_profile, generation) = {
        let conn_g = db_state.conn.lock().map_err(|_| "[STATE] LOCK_CONN")?;
        let conn = conn_g.as_ref().ok_or("[STATE] DB_NOT_OPEN")?;
        check_profile_server(conn, session.base())?;
        let sid: Option<String> = conn
            .query_row("SELECT value FROM sync_meta WHERE key='share_id'", [], |r| r.get(0))
            .ok();
        let cp: String = conn
            .query_row("SELECT value FROM sync_meta WHERE key='cloud_profile'", [], |r| r.get(0))
            .unwrap_or_else(|_| profile.clone());
        (sid, cp, db_state.generation_now())
    };
    if share_id.is_some() {
        return Err("[SYNC] SHARED_PROFILE: this profile is shared with other people, and replacing the cloud copy would delete their changes too. Stop sharing first if you really want to reset it.".into());
    }
    let removed = cloud::delete_sync_profile(&app, &cloud, &session, &cloud_profile).await?;
    eprintln!("[SYNC] force push: server dropped {removed} record(s) for '{cloud_profile}'");
    // Pushes are always a full set, so the very next sync repopulates the
    // partition from this vault — including a fresh DEK escrow record. Only
    // this profile's, though: if another opened meanwhile, the sync refuses,
    // and this profile's next sync fills its partition back up.
    sync_with(&app, &db_state, &cloud, &session, Some(generation)).await
}

/// Mark a profile as the active one. Subsequent `check_db_exists` /
/// `setup_master_db` calls operate against that profile's file. Returns
/// whether the profile's encrypted file already exists (caller uses this
/// to decide between "ask for password" and "this profile is empty / not
/// yet created" flows).
#[tauri::command]
async fn select_profile(
    app_handle: tauri::AppHandle,
    state: tauri::State<'_, DbState>,
    name: String,
) -> Result<bool, String> {
    validate_profile_name(&name)?;
    *state.active_profile.lock().map_err(|_| "[STATE] LOCK_FAILED")? = Some(name.clone());
    Ok(profile_path(&app_handle, &name)?.exists())
}

/// Drop in-memory state so the UI can return to the profile picker without
/// restarting the app. This MUST tear down every piece of per-profile
/// runtime state, not just the DB — otherwise live SSH sessions, tunnels,
/// SFTP channels, terminal PTYs, and fingerprint waiters from the
/// previous profile would survive the switch and (worse) attribute any
/// `known_hosts` writes they triggered to the NEXT profile's DB.
#[tauri::command]
async fn close_profile(
    state: tauri::State<'_, DbState>,
    ssh: tauri::State<'_, SshState>,
    monitor_map: tauri::State<'_, MonitorMap>,
) -> Result<(), String> {
    // 0. Persist any accumulated in-memory changes (chief among them:
    // cmd_history rows written by TerminalView's Enter-key handler, which
    // deliberately skip a per-keystroke fsync). Best-effort: if the vault
    // isn't in a saveable state (partial init, crypto error) just log via
    // the returned Err and continue teardown — losing recent history is
    // preferable to leaking session state.
    let _ = save_vault_async(&state).await;

    // 1. Stop monitor pollers. Flip `paused` first so the next loop iteration
    // releases the SSH handle, then drop the map so the Arc strong_count
    // falls to 1 and the poller exits.
    monitor::pause_all(monitor_map.inner().clone()).await;
    monitor_map.lock().await.clear();

    // 2. Collect every active session id, then run the standard
    // disconnect path for each one. This frees tunnel listener sockets,
    // SFTP channels, and the SSH handle in the right order.
    let session_ids: Vec<String> = ssh.connections.lock().await.keys().cloned().collect();
    for sid in &session_ids {
        tunnel::stop_all_for_session(&ssh.tunnels, sid).await;
        ssh.forwarded_targets.lock().await.remove(sid);
        ssh.sftp_sessions.lock().await.remove(sid);
        ssh.sftp_elevation.lock().await.remove(sid);
        ssh.connections.lock().await.remove(sid);
        for dir in [session_sftp_dir(sid), session_drag_dir(sid)].into_iter().flatten() {
            if dir.exists() {
                let _ = std::fs::remove_dir_all(&dir);
            }
        }
    }

    // 3. Close every terminal channel. The spawned PTY task watches its
    // `rx` end — dropping the senders here lets each task observe `None`
    // and call `channel.close()` cleanly. We do this AFTER connections are
    // gone so the task sees the close before trying another write.
    ssh.terminal_txs.lock().await.clear();
    ssh.resize_txs.lock().await.clear();

    // 4. Abort any pending fingerprint prompts. Sending `false` to the
    // oneshot rejects the prompt; if the rx side is already gone, the
    // send just errors out which is fine.
    let waiters: Vec<tokio::sync::oneshot::Sender<bool>> =
        ssh.fp_txs.lock().await.drain().map(|(_, v)| v).collect();
    for tx in waiters {
        let _ = tx.send(false);
    }
    // Same for any pending keyboard-interactive (2FA) prompt — sending `None`
    // signals cancel so the connect worker aborts the interactive attempt
    // instead of hanging on its 120s timeout after the profile is gone.
    let kbi_waiters: Vec<tokio::sync::oneshot::Sender<Option<Vec<String>>>> =
        ssh.kbi_txs.lock().await.drain().map(|(_, v)| v).collect();
    for tx in kbi_waiters {
        let _ = tx.send(None);
    }

    // 5. Belt-and-suspenders: clear the residual maps in case anything
    // raced in between the steps above.
    ssh.tunnels.lock().await.clear();
    ssh.forwarded_targets.lock().await.clear();
    ssh.sftp_sessions.lock().await.clear();
    ssh.sftp_elevation.lock().await.clear();
    // Wipe every connect-time secret the user typed this profile (issue #30).
    ssh.prompted_secrets.lock().await.clear();
    ssh.connections.lock().await.clear();
    ssh.jump_connections.lock().await.clear();
    ssh.fp_txs.lock().await.clear();
    ssh.kbi_txs.lock().await.clear();

    // 6. Drop DB state last, so any in-flight write triggered by a
    // disconnecting handler above had a valid DB to land in. All of it under
    // the connection's lock, in the order a save takes the locks: nothing can
    // see this profile's key with no database, or the next one's database
    // with this one's key. The new generation tells a command still waiting
    // on the network that the profile it read from is gone.
    let mut conn_guard = state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED_CONN")?;
    *conn_guard = None;
    *state.master_key.lock().map_err(|_| "[STATE] LOCK_FAILED_KEY")? = None;
    *state.salt.lock().map_err(|_| "[STATE] LOCK_FAILED_SALT")? = None;
    *state.db_path.lock().map_err(|_| "[STATE] LOCK_FAILED_PATH")? = None;
    *state.active_profile.lock().map_err(|_| "[STATE] LOCK_FAILED_PROFILE")? = None;
    *state.hlc.lock().map_err(|_| "[STATE] LOCK_FAILED_HLC")? = None;
    state.bump_generation();
    drop(conn_guard);
    Ok(())
}

/// Permanently delete a profile's encrypted file. The caller must NOT be
/// "in" that profile (would orphan in-memory state pointing at a deleted
/// file). UI enforces this by only showing the delete button on the picker
/// screen.
#[tauri::command]
async fn delete_profile(app_handle: tauri::AppHandle, name: String) -> Result<(), String> {
    validate_profile_name(&name)?;
    let path = profile_path(&app_handle, &name)?;
    if path.exists() {
        fs::remove_file(&path)
            .map_err(|e| format!("[FILE] DELETE_PROFILE_FAILED at {:?}: {}", path, e))?;
    }
    // A save that died between writing the tmp and renaming it leaves a
    // `<name>.submarine.tmp` holding a complete vault. `list_profiles` filters
    // on the `.submarine` extension so nothing ever surfaces it, which means
    // deleting the profile would otherwise leave the user's keys on disk
    // indefinitely with no way to see or remove them from the UI. Best-effort:
    // the profile itself is already gone, so a locked tmp shouldn't fail the
    // delete the user asked for.
    let _ = fs::remove_file(path.with_extension("submarine.tmp"));
    Ok(())
}

/// Copy a profile's encrypted file to a user-chosen location so it can be
/// backed up or moved between machines. The file is already encrypted at
/// rest — we just copy bytes; we never decrypt or re-encrypt.
///
/// Returns `Some(path)` on success or `None` if the user cancels the
/// native save dialog. Errors bubble up as `Err`.
#[tauri::command]
async fn export_profile(
    app_handle: tauri::AppHandle,
    name: String,
) -> Result<Option<String>, String> {
    validate_profile_name(&name)?;
    let src = profile_path(&app_handle, &name)?;
    if !src.exists() {
        return Err(format!("Profile '{}' not found on disk", name));
    }

    // Android has no native save dialog: drop the (still encrypted) file into
    // the first shared folder we can write to — Download, then Documents,
    // then app storage — and report the exact path so the user can find it.
    #[cfg(target_os = "android")]
    {
        let dir = android_export_dir(&app_handle)
            .ok_or_else(|| "No writable folder found for the export.".to_string())?;
        let dst = unique_file_path(&dir, &name, "submarine");
        fs::copy(&src, &dst)
            .map_err(|e| format!("[FILE] EXPORT_COPY_FAILED to {:?}: {}", dst, e))?;
        return Ok(Some(dst.to_string_lossy().to_string()));
    }
    #[cfg(not(target_os = "android"))]
    {
        // rfd's blocking dialog must not run on the main thread on macOS — we're
        // already off the UI thread in a tauri async command so a direct call is
        // fine. spawn_blocking would be needed if this was wrapped differently.
        let default_name = format!("{}.submarine", name);
        let chosen = rfd::FileDialog::new()
            .set_title("Export profile")
            .set_file_name(&default_name)
            .add_filter("Submarine profile", &["submarine"])
            .save_file();

        let dst = match chosen {
            Some(p) => p,
            None => return Ok(None),
        };

        fs::copy(&src, &dst)
            .map_err(|e| format!("[FILE] EXPORT_COPY_FAILED to {:?}: {}", dst, e))?;
        Ok(Some(dst.to_string_lossy().to_string()))
    }
}

/// Open a file picker and verify the chosen file looks like a Submarine
/// vault (right header bytes). We do NOT decrypt — that requires the
/// profile password, which the user enters after import via the regular
/// unlock flow.
///
/// Returns `(source_path, suggested_name)` so the UI can confirm or rename
/// before committing the copy.
#[tauri::command]
async fn import_profile_pick() -> Result<Option<(String, String)>, String> {
    #[cfg(target_os = "android")]
    {
        return Err("Android 上不支持导入档案。".into());
    }
    #[cfg(not(target_os = "android"))]
    {
        let picked = rfd::FileDialog::new()
            .set_title("Import profile")
            .add_filter("Submarine profile", &["submarine"])
            .pick_file();

        let path = match picked {
            Some(p) => p,
            None => return Ok(None),
        };

        // Cheap header check (no decryption). If the file isn't a vault we want
        // to fail before the user picks a name and gets a confusing error later.
        let mut header = [0u8; 5];
        let mut f = fs::File::open(&path).map_err(|e| format!("[FILE] IMPORT_OPEN_FAILED: {}", e))?;
        use std::io::Read;
        let n = f.read(&mut header).map_err(|e| format!("[FILE] IMPORT_READ_FAILED: {}", e))?;
        if n < 5 || &header[..4] != VAULT_MAGIC {
            return Err("所选文件不是 Submarine 档案（文件头无效）。".into());
        }
        if header[4] != VAULT_VERSION {
            return Err(format!(
                "该档案使用了不受支持的保险库版本（{}）。请先更新 Submarine。",
                header[4]
            ));
        }

        // Suggest a name from the file stem, sanitized to our profile-name rules
        // so the user can hit Enter without re-typing in the common case.
        let suggested = path
            .file_stem()
            .and_then(|s| s.to_str())
            .map(|s| {
                s.chars()
                    .map(|c| if c.is_ascii_alphanumeric() || c == '-' || c == '_' { c } else { '_' })
                    .take(32)
                    .collect::<String>()
            })
            .unwrap_or_else(|| "imported".to_string());

        Ok(Some((path.to_string_lossy().to_string(), suggested)))
    }
}

/// Header + minimum-size check for an exported vault (no decryption — that
/// needs the profile password, entered later at unlock).
fn validate_vault_bytes(bytes: &[u8]) -> Result<(), String> {
    if bytes.len() < 5 || &bytes[..4] != VAULT_MAGIC {
        return Err("所选文件不是 Submarine 档案。".into());
    }
    if bytes[4] != VAULT_VERSION {
        return Err(format!(
            "该档案使用了不受支持的保险库版本（{}）。请先更新 Submarine。",
            bytes[4]
        ));
    }
    if bytes.len() < HEADER_LEN + NONCE_LEN + 16 {
        return Err("文件已损坏：文件头有效，但内容过短。".into());
    }
    Ok(())
}

/// `<dir>/<stem>.<ext>`, or `<stem> (2).<ext>`, `(3)`… if that name is taken,
/// so an export never overwrites an earlier one.
#[cfg_attr(not(target_os = "android"), allow(dead_code))]
fn unique_file_path(dir: &std::path::Path, stem: &str, ext: &str) -> PathBuf {
    let first = dir.join(format!("{}.{}", stem, ext));
    if !first.exists() {
        return first;
    }
    for n in 2..1000 {
        let candidate = dir.join(format!("{} ({}).{}", stem, n, ext));
        if !candidate.exists() {
            return candidate;
        }
    }
    first
}

/// First shared folder the app can write to, for Android exports.
#[cfg(target_os = "android")]
fn android_export_dir(app: &tauri::AppHandle) -> Option<PathBuf> {
    let mut candidates = vec![
        PathBuf::from("/storage/emulated/0/Download"),
        PathBuf::from("/storage/emulated/0/Documents"),
    ];
    if let Ok(dir) = app.path().app_local_data_dir() {
        candidates.push(dir);
    }
    candidates.into_iter().find(|p| is_dir_writable(p))
}

/// Import from bytes — the Android path: the WebView's system file picker
/// hands the file to the page, which sends it here (base64). Same checks as
/// `import_profile_save`, and it never overwrites an existing profile.
#[tauri::command]
async fn import_profile_bytes(
    app_handle: tauri::AppHandle,
    name: String,
    data: String,
) -> Result<(), String> {
    use base64::Engine as _;
    validate_profile_name(&name)?;
    // Real vaults are a few MB at most; refuse anything absurd before
    // allocating for it.
    const MAX_VAULT_BYTES: usize = 256 * 1024 * 1024;
    if data.len() / 4 * 3 > MAX_VAULT_BYTES {
        return Err("文件过大，不可能是 Submarine 档案。".into());
    }
    let bytes = base64::engine::general_purpose::STANDARD
        .decode(data.as_bytes())
        .map_err(|_| "Couldn't read the selected file.".to_string())?;
    validate_vault_bytes(&bytes)?;

    let dir = profiles_dir(&app_handle)?;
    fs::create_dir_all(&dir).map_err(|e| format!("[FILE] MKDIR_FAILED: {}", e))?;
    let dst = profile_path(&app_handle, &name)?;
    if dst.exists() {
        return Err(format!("档案“{}”已存在", name));
    }
    fs::write(&dst, &bytes).map_err(|e| format!("[FILE] IMPORT_WRITE_FAILED to {:?}: {}", dst, e))?;
    Ok(())
}

#[cfg(test)]
mod profile_import_tests {
    use super::*;

    fn fake_vault(len: usize) -> Vec<u8> {
        let mut v = vec![0u8; len];
        v[..4].copy_from_slice(VAULT_MAGIC);
        v[4] = VAULT_VERSION;
        v
    }

    #[test]
    fn a_well_formed_vault_header_passes() {
        assert!(validate_vault_bytes(&fake_vault(HEADER_LEN + NONCE_LEN + 64)).is_ok());
    }

    #[test]
    fn junk_wrong_version_and_truncated_files_are_rejected() {
        assert!(validate_vault_bytes(b"PK\x03\x04 not a vault").is_err());
        let mut v = fake_vault(HEADER_LEN + NONCE_LEN + 64);
        v[4] = VAULT_VERSION + 1;
        assert!(validate_vault_bytes(&v).is_err());
        assert!(validate_vault_bytes(&fake_vault(HEADER_LEN + 3)).is_err());
    }

    #[test]
    fn exports_never_overwrite() {
        let dir = std::env::temp_dir().join(format!("submarine-export-{}", std::process::id()));
        std::fs::create_dir_all(&dir).unwrap();
        let first = unique_file_path(&dir, "work", "submarine");
        assert_eq!(first.file_name().unwrap(), "work.submarine");
        std::fs::write(&first, b"x").unwrap();
        let second = unique_file_path(&dir, "work", "submarine");
        assert_eq!(second.file_name().unwrap(), "work (2).submarine");
        let _ = std::fs::remove_dir_all(&dir);
    }
}

/// Commit a picked vault file into the profiles dir under `name`. Refuses
/// to overwrite an existing profile — the UI must prompt the user to pick
/// a different name (or delete the existing one) in that case.
#[tauri::command]
async fn import_profile_save(
    app_handle: tauri::AppHandle,
    source_path: String,
    name: String,
) -> Result<(), String> {
    validate_profile_name(&name)?;
    let src = PathBuf::from(&source_path);
    if !src.exists() {
        return Err("源文件已不存在。".into());
    }

    let dir = profiles_dir(&app_handle)?;
    fs::create_dir_all(&dir).map_err(|e| format!("[FILE] MKDIR_FAILED: {}", e))?;
    let dst = profile_path(&app_handle, &name)?;
    if dst.exists() {
        return Err(format!("档案“{}”已存在", name));
    }

    // Single-read import: load the file into memory ONCE, validate the
    // header on the in-memory bytes, then write to the destination. The
    // previous "read 5 bytes to validate, then fs::copy" was TOCTOU —
    // an attacker (or a script running in parallel) could swap the file
    // between the header read and the copy and we'd import garbage.
    let bytes = fs::read(&src).map_err(|e| format!("[FILE] IMPORT_READ_FAILED: {}", e))?;
    if bytes.len() < 5 || &bytes[..4] != VAULT_MAGIC || bytes[4] != VAULT_VERSION {
        return Err("源文件不再是有效的 Submarine 档案。".into());
    }
    if bytes.len() < HEADER_LEN + NONCE_LEN + 16 {
        return Err("源文件已损坏——文件头有效，但内容过短。".into());
    }

    fs::write(&dst, &bytes)
        .map_err(|e| format!("[FILE] IMPORT_WRITE_FAILED to {:?}: {}", dst, e))?;
    Ok(())
}

/// Whether the *currently selected* profile's encrypted file exists on
/// disk. Returns false if no profile is selected — that signals the UI to
/// stay on the picker instead of jumping to the password prompt.
#[tauri::command]
async fn check_db_exists(
    app_handle: tauri::AppHandle,
    state: tauri::State<'_, DbState>,
) -> Result<bool, String> {
    let name = state.active_profile.lock()
        .map_err(|_| "[STATE] LOCK_FAILED_PROFILE")?
        .clone();
    let Some(name) = name else { return Ok(false) };
    Ok(profile_path(&app_handle, &name)?.exists())
}

#[tauri::command]
async fn setup_master_db(app_handle: tauri::AppHandle, password: String, state: tauri::State<'_, DbState>) -> Result<(), String> {
    // Every path that reaches here from the UI is the user CHOOSING a password
    // (create a profile, or unlock an existing one), so the strength floor
    // applies. `restore_personal_profile` is the one caller that doesn't get to
    // choose — see `enforce_strength` below.
    setup_master_db_inner(app_handle, password, state, true).await.map(|_| ())
}

/// `enforce_strength = false` is for restoring a profile that ALREADY exists in
/// the cloud. The password isn't being chosen — it was chosen long ago, and the
/// cloud copy is already sealed under it. Rejecting it as "too weak" wouldn't
/// make anything safer; it would just lock the owner out of their own data on a
/// new device while the old device keeps opening it fine. The floor belongs on
/// creation, where the choice is actually being made.
async fn setup_master_db_inner(
    app_handle: tauri::AppHandle,
    mut password: String,
    state: tauri::State<'_, DbState>,
    enforce_strength: bool,
) -> Result<u64, String> {
    // The active profile must be picked before this command — the UI does
    // it from the picker screen. Refuse early instead of silently writing
    // to a default path.
    let profile_name = state.active_profile.lock()
        .map_err(|_| "[STATE] LOCK_FAILED_PROFILE")?
        .clone()
        .ok_or("[STATE] NO_PROFILE_SELECTED")?;

    let dir = profiles_dir(&app_handle)?;
    if !dir.exists() {
        fs::create_dir_all(&dir).map_err(|e| format!("[FILE] DIR_CREATION_FAILED: {}", e))?;
    }

    let path = profile_path(&app_handle, &profile_name)?;
    let mut conn;
    let salt_bytes: [u8; SALT_LEN];
    // Wrap the derived AES key so it's wiped on every early-return path
    // and at the natural end of this function. Once it lands in DbState
    // the StdMutex<Option<Zeroizing<...>>> takes over the same guarantee.
    let key: Zeroizing<[u8; 32]>;
    let mut needs_resave;

    if path.exists() {
        let encrypted_data = fs::read(&path)
            .map_err(|e| format!("[FILE] VAULT_READ_FAILED: {}", e))?;
        let (parsed_salt, nonce, ciphertext) = parse_vault_blob(&encrypted_data)?;
        // Normalise the Vec<u8> salt into a fixed-size array up front so we
        // can copy it into both the spawn_blocking closure (move-by-Copy) and
        // the salt_bytes slot later, without juggling clones or lifetimes.
        let mut salt_fixed = [0u8; SALT_LEN];
        salt_fixed.copy_from_slice(&parsed_salt);
        // Argon2id with m=64MiB is CPU-heavy (≈0.5–2s depending on hardware).
        // Running it directly on the async runtime thread blocks every other
        // Tauri command for that duration — UI freezes, IPC backs up. Hand
        // it off to the blocking pool so the runtime stays responsive. The
        // closure also zeroizes the password buffer once the derivation is
        // done, preserving the secret-hygiene the original sync path had.
        let mut password_owned = std::mem::take(&mut password);
        let derived = tokio::task::spawn_blocking(move || {
            let res = derive_key(&password_owned, &salt_fixed);
            password_owned.zeroize();
            res
        })
            .await
            .map_err(|e| format!("[CRYPTO] KDF_JOIN: {}", e))??;
        key = Zeroizing::new(derived);
        let raw = Zeroizing::new(decrypt_with_key(&ciphertext, &nonce, &key)?);
        let decrypted_data = Zeroizing::new(vault_decompress(&raw)?);

        salt_bytes = salt_fixed;
        needs_resave = false;

        conn = Connection::open_in_memory()
            .map_err(|e| format!("[DATABASE] MEM_INIT_FAILED: {}", e))?;
        let owned = to_sqlite_owned(&decrypted_data)?;
        conn.deserialize(MAIN_DB, owned, false)
            .map_err(|e| format!("[DATABASE] DESERIALIZE_FAILED: {}", e))?;
        // Schema migration for vaults created before the Notes feature shipped.
        // Existing tables are untouched; only the new ones get materialised.
        // Idempotent — running it on a fresh vault that already has `notes`
        // (from the schema batch below) is a no-op.
        conn.execute(
            "CREATE TABLE IF NOT EXISTS notes (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, body TEXT)",
            [],
        ).map_err(|e| format!("[DATABASE] NOTES_MIGRATION_FAILED: {}", e))?;
        // Schema migration for the autostart-on-launch flag added later. We
        // can't use `IF NOT EXISTS` on ALTER, so swallow the "duplicate
        // column" error specifically — anything else propagates.
        if let Err(e) = conn.execute(
            "ALTER TABLE servers ADD COLUMN autostart INTEGER NOT NULL DEFAULT 0",
            [],
        ) {
            let s = e.to_string();
            if !s.contains("duplicate column name") {
                return Err(format!("[DATABASE] AUTOSTART_MIGRATION_FAILED: {}", s));
            }
        }
        // Schema migration for the mirror-config column.
        if let Err(e) = conn.execute(
            "ALTER TABLE servers ADD COLUMN mirrors TEXT NOT NULL DEFAULT '[]'",
            [],
        ) {
            let s = e.to_string();
            if !s.contains("duplicate column name") {
                return Err(format!("[DATABASE] MIRRORS_MIGRATION_FAILED: {}", s));
            }
        }
        // Schema version metadata. A single-row `schema_meta` table records
        // the highest column-migration the running binary knows about. If a
        // user opens an older binary against a newer vault, we surface a
        // clear warning instead of silently swallowing "duplicate column"
        // errors and risking write-side schema drift. Bump SCHEMA_VERSION
        // here every time a new ALTER lands in this block.
        conn.execute(
            "CREATE TABLE IF NOT EXISTS schema_meta (key TEXT PRIMARY KEY, value TEXT NOT NULL)",
            [],
        ).map_err(|e| format!("[DATABASE] META_TABLE_FAILED: {}", e))?;
        // v5 — command history table for the Ctrl+R overlay. Best-effort
        // captured per-Enter by TerminalView; unencrypted-within-vault since
        // it's not a secret (the vault itself is encrypted at rest).
        conn.execute(
            "CREATE TABLE IF NOT EXISTS cmd_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                server_id INTEGER,
                server_name TEXT,
                command TEXT NOT NULL,
                ts INTEGER NOT NULL,
                exit_code INTEGER
            )",
            [],
        ).map_err(|e| format!("[DATABASE] CMD_HISTORY_TABLE_FAILED: {}", e))?;
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_cmd_history_ts ON cmd_history(ts DESC)",
            [],
        ).map_err(|e| format!("[DATABASE] CMD_HISTORY_INDEX_FAILED: {}", e))?;
        const SCHEMA_VERSION: i64 = 6;
        let stored: i64 = conn.query_row(
            "SELECT CAST(value AS INTEGER) FROM schema_meta WHERE key = 'schema_version'",
            [],
            |row| row.get(0),
        ).unwrap_or(0);
        if stored > SCHEMA_VERSION {
            return Err(format!(
                "[DATABASE] SCHEMA_AHEAD_OF_BINARY: vault was written by a newer build (schema v{}), this binary only understands v{}. Upgrade the app before opening this profile.",
                stored, SCHEMA_VERSION,
            ));
        }
        conn.execute(
            "INSERT INTO schema_meta (key, value) VALUES ('schema_version', ?1)
             ON CONFLICT(key) DO UPDATE SET value = excluded.value",
            rusqlite::params![SCHEMA_VERSION.to_string()],
        ).map_err(|e| format!("[DATABASE] META_WRITE_FAILED: {}", e))?;

        // Schema migrations for the per-node and per-folder colour bar. NULL
        // means "use the default ring" — the UI treats absence as the same
        // visual as before this column existed.
        for stmt in [
            "ALTER TABLE servers ADD COLUMN color TEXT",
            "ALTER TABLE folders ADD COLUMN color TEXT",
            // v4: per-node free-form description / runbook. Defaults to empty
            // so existing rows don't need backfill. NOT NULL keeps the read
            // path branchless.
            "ALTER TABLE servers ADD COLUMN notes TEXT NOT NULL DEFAULT ''",
            // Commands auto-typed into the FIRST terminal on the INITIAL
            // connect (never on reconnect / extra shells). Empty = nothing.
            "ALTER TABLE servers ADD COLUMN run_on_connect TEXT NOT NULL DEFAULT ''",
            // ProxyJump: optional id of another server to bounce through. NULL
            // = connect directly. Nullable + additive so old binaries ignore
            // it (no SCHEMA_VERSION bump, matching run_on_connect above).
            "ALTER TABLE servers ADD COLUMN jump_host_id INTEGER",
            // Per-algorithm host-key tracking. Legacy rows keep key_type NULL
            // (treated conservatively as "same type" so a real key rotation is
            // never downgraded to a benign first-time prompt); rows recorded
            // after this migration store the host-key algorithm so a server
            // ADDING a new algorithm no longer looks like a MITM key change.
            "ALTER TABLE known_hosts ADD COLUMN key_type TEXT",
            // Per-entity sync columns (schema v6). Nullable uuid/updated_at get
            // backfilled row-by-row just below; deleted is a plain constant
            // default so it's a safe single-statement ADD.
            "ALTER TABLE folders ADD COLUMN uuid TEXT",
            "ALTER TABLE folders ADD COLUMN updated_at TEXT",
            "ALTER TABLE folders ADD COLUMN deleted INTEGER NOT NULL DEFAULT 0",
            "ALTER TABLE ssh_keys ADD COLUMN uuid TEXT",
            "ALTER TABLE ssh_keys ADD COLUMN updated_at TEXT",
            "ALTER TABLE ssh_keys ADD COLUMN deleted INTEGER NOT NULL DEFAULT 0",
            "ALTER TABLE credentials ADD COLUMN uuid TEXT",
            "ALTER TABLE credentials ADD COLUMN updated_at TEXT",
            "ALTER TABLE credentials ADD COLUMN deleted INTEGER NOT NULL DEFAULT 0",
            "ALTER TABLE servers ADD COLUMN uuid TEXT",
            "ALTER TABLE servers ADD COLUMN updated_at TEXT",
            "ALTER TABLE servers ADD COLUMN deleted INTEGER NOT NULL DEFAULT 0",
            "ALTER TABLE commands ADD COLUMN uuid TEXT",
            "ALTER TABLE commands ADD COLUMN updated_at TEXT",
            "ALTER TABLE commands ADD COLUMN deleted INTEGER NOT NULL DEFAULT 0",
            "ALTER TABLE notes ADD COLUMN uuid TEXT",
            "ALTER TABLE notes ADD COLUMN updated_at TEXT",
            "ALTER TABLE notes ADD COLUMN deleted INTEGER NOT NULL DEFAULT 0",
            "ALTER TABLE monitor_configs ADD COLUMN uuid TEXT",
            "ALTER TABLE monitor_configs ADD COLUMN updated_at TEXT",
            "ALTER TABLE monitor_configs ADD COLUMN deleted INTEGER NOT NULL DEFAULT 0",
            // Per-person attribution (schema v6+). The auto-stamp triggers set
            // this to the editor label at mutation time; NULL on legacy rows.
            "ALTER TABLE folders ADD COLUMN edited_by TEXT",
            "ALTER TABLE ssh_keys ADD COLUMN edited_by TEXT",
            "ALTER TABLE credentials ADD COLUMN edited_by TEXT",
            "ALTER TABLE servers ADD COLUMN edited_by TEXT",
            "ALTER TABLE commands ADD COLUMN edited_by TEXT",
            "ALTER TABLE notes ADD COLUMN edited_by TEXT",
            "ALTER TABLE monitor_configs ADD COLUMN edited_by TEXT",
            // Manual drag-to-reorder of the node grid. Default 0 keeps the
            // pre-existing implicit rowid order until the user first reorders;
            // `get_servers` sorts by (position, id) so ties fall back to id.
            // Synced (it's in the servers ENTITIES cols), so order LWW-merges.
            "ALTER TABLE servers ADD COLUMN position INTEGER NOT NULL DEFAULT 0",
        ] {
            if let Err(e) = conn.execute(stmt, []) {
                let s = e.to_string();
                if !s.contains("duplicate column name") {
                    return Err(format!("[DATABASE] COLUMN_MIGRATION_FAILED: {}", s));
                }
            }
        }
    } else {
        // Master-password strength floor — enforced ONLY at vault CREATION, not
        // on unlock (an existing vault with a short password must still open).
        // This password is the single cryptographic root protecting every
        // stored credential and private key, so a trivial one is a real risk.
        // Count Unicode scalar values, not bytes, so non-Latin passwords aren't
        // over-counted. 8 is a floor, not a ceiling — the UI should also nudge.
        // Skipped when restoring an existing cloud profile (see the caller doc).
        if enforce_strength && password.chars().count() < 8 {
            password.zeroize();
            return Err("[CRYPTO] WEAK_MASTER_PASSWORD: choose at least 8 characters — this password protects every saved credential.".into());
        }
        let mut fresh = [0u8; SALT_LEN];
        rand::rng().fill_bytes(&mut fresh);
        salt_bytes = fresh;
        // Same reasoning as the unlock path above — keep the async runtime
        // unblocked during the Argon2 derivation on fresh-profile creation.
        let mut password_owned = std::mem::take(&mut password);
        let derived = tokio::task::spawn_blocking(move || {
            let res = derive_key(&password_owned, &salt_bytes);
            password_owned.zeroize();
            res
        })
            .await
            .map_err(|e| format!("[CRYPTO] KDF_JOIN: {}", e))??;
        key = Zeroizing::new(derived);
        needs_resave = true;

        conn = Connection::open_in_memory()
            .map_err(|e| format!("[DATABASE] MEM_INIT_FAILED: {}", e))?;
        conn.execute_batch(
            "CREATE TABLE folders (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, parent_id INTEGER, color TEXT, uuid TEXT, updated_at TEXT, deleted INTEGER NOT NULL DEFAULT 0, edited_by TEXT);
             CREATE TABLE ssh_keys (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, public_key TEXT, private_key TEXT, passphrase TEXT, uuid TEXT, updated_at TEXT, deleted INTEGER NOT NULL DEFAULT 0, edited_by TEXT);
             CREATE TABLE credentials (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, auth_type TEXT, username TEXT, password TEXT, key_id INTEGER, uuid TEXT, updated_at TEXT, deleted INTEGER NOT NULL DEFAULT 0, edited_by TEXT, FOREIGN KEY(key_id) REFERENCES ssh_keys(id));
             CREATE TABLE servers (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, host TEXT, port INTEGER, username TEXT, password TEXT, credential_id INTEGER, folder_id INTEGER, proxy_type TEXT DEFAULT 'none', proxy_host TEXT, proxy_port INTEGER, tunnels TEXT, auth_type TEXT DEFAULT 'vault', key_id INTEGER, autostart INTEGER NOT NULL DEFAULT 0, mirrors TEXT NOT NULL DEFAULT '[]', color TEXT, notes TEXT NOT NULL DEFAULT '', run_on_connect TEXT NOT NULL DEFAULT '', jump_host_id INTEGER, position INTEGER NOT NULL DEFAULT 0, uuid TEXT, updated_at TEXT, deleted INTEGER NOT NULL DEFAULT 0, edited_by TEXT, FOREIGN KEY(folder_id) REFERENCES folders(id));
             CREATE TABLE commands (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, content TEXT, uuid TEXT, updated_at TEXT, deleted INTEGER NOT NULL DEFAULT 0, edited_by TEXT);
             CREATE TABLE notes (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, body TEXT, uuid TEXT, updated_at TEXT, deleted INTEGER NOT NULL DEFAULT 0, edited_by TEXT);
             CREATE TABLE known_hosts (id INTEGER PRIMARY KEY AUTOINCREMENT, host TEXT, port INTEGER, fingerprint TEXT, key_type TEXT);
             CREATE TABLE monitor_configs (node_id INTEGER PRIMARY KEY, enabled_metrics TEXT NOT NULL DEFAULT '[\"cpu\",\"mem\",\"disk\",\"load\"]', custom_metrics TEXT NOT NULL DEFAULT '[]', paused INTEGER NOT NULL DEFAULT 1, uuid TEXT, updated_at TEXT, deleted INTEGER NOT NULL DEFAULT 0, edited_by TEXT, FOREIGN KEY(node_id) REFERENCES servers(id) ON DELETE CASCADE);
             CREATE TABLE monitor_settings (id INTEGER PRIMARY KEY, json TEXT NOT NULL);
             CREATE TABLE schema_meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
             CREATE TABLE cmd_history (id INTEGER PRIMARY KEY AUTOINCREMENT, server_id INTEGER, server_name TEXT, command TEXT NOT NULL, ts INTEGER NOT NULL, exit_code INTEGER);
             CREATE INDEX idx_cmd_history_ts ON cmd_history(ts DESC);
             INSERT INTO schema_meta (key, value) VALUES ('schema_version', '6');"
        ).map_err(|e| format!("[DATABASE] SCHEMA_CREATION_FAILED: {}", e))?;
    }

    conn.execute("PRAGMA foreign_keys = ON", []).map_err(|e| format!("[DATABASE] PRAGMA_FAILED: {}", e))?;

    // Deleting a key or credential frees its SQLite page but leaves the bytes
    // sitting there, and `conn.serialize()` copies free pages too — so the
    // private key the user deleted last month is still inside every vault
    // snapshot written since, and inside every per-entity sync blob derived
    // from one. secure_delete zeroes the vacated bytes at DELETE/UPDATE time
    // instead. `execute_batch` rather than `execute` because assigning this
    // pragma reports the resulting value as a row, which `execute` rejects.
    conn.execute_batch("PRAGMA secure_delete = ON;")
        .map_err(|e| format!("[DATABASE] PRAGMA_FAILED: {}", e))?;

    // secure_delete only governs deletes from here on. A vault that has been
    // in use since before this build still carries whatever its old frees
    // left behind, so purge that history once: VACUUM rebuilds the database
    // with no free pages at all. Marked in schema_meta so it costs one
    // rebuild per vault rather than one per launch. Best-effort — a vault
    // that can't be vacuumed is still perfectly usable, just not scrubbed,
    // and failing to open it over that would be a bad trade.
    let scrubbed: bool = conn
        .query_row(
            "SELECT 1 FROM schema_meta WHERE key = 'free_pages_scrubbed'",
            [],
            |_| Ok(true),
        )
        .unwrap_or(false);
    if !scrubbed {
        match conn.execute_batch("VACUUM;") {
            Ok(()) => {
                let _ = conn.execute(
                    "INSERT OR REPLACE INTO schema_meta (key, value) VALUES ('free_pages_scrubbed', '1')",
                    [],
                );
                needs_resave = true;
            }
            Err(e) => {
                eprintln!("[DATABASE] VACUUM_SKIPPED: {}", e);
            }
        }
    }

    // ---- Per-entity sync instrumentation (schema v6) ----
    // A per-profile Hybrid Logical Clock backs the `hlc_now()` SQL function so
    // every row mutation auto-stamps `updated_at`. Seed the clock past the
    // newest stamp already in the vault so a freshly-started process never
    // issues one that sorts before data it already holds.
    let sync_node_id = sync_device_node_id(&app_handle);
    let seed_ms: u64 = conn
        .query_row(
            "SELECT COALESCE(MAX(updated_at),'') FROM (
               SELECT updated_at FROM servers UNION ALL SELECT updated_at FROM credentials
               UNION ALL SELECT updated_at FROM ssh_keys UNION ALL SELECT updated_at FROM folders
               UNION ALL SELECT updated_at FROM commands UNION ALL SELECT updated_at FROM notes
               UNION ALL SELECT updated_at FROM monitor_configs)",
            [],
            |r| r.get::<_, String>(0),
        )
        .ok()
        .map(|s| hlc::Hlc::phys_of(&s))
        .unwrap_or(0);
    let hlc_arc = std::sync::Arc::new(hlc::Hlc::new(sync_node_id, seed_ms));
    register_sync_functions(&conn, &hlc_arc)?;
    // Backfill rows that predate the sync columns (no-op on a fresh vault, and
    // a no-op on every open after the first). Run it BEFORE creating triggers so
    // the backfill UPDATEs can't fire them.
    if backfill_sync_columns(&conn, &hlc_arc)? {
        needs_resave = true;
    }
    create_sync_triggers(&conn)?;
    // What a shared profile's synced data would run by itself waits here for
    // this device's OK (see approvals.rs).
    approvals::create_schema(&conn)?;
    create_share_pins(&conn)?;

    // Per-profile sync metadata (the DEK, and later the identity/grant state).
    // Created here so an existing vault gains it on first open under a v6 build.
    conn.execute(
        "CREATE TABLE IF NOT EXISTS sync_meta (key TEXT PRIMARY KEY, value TEXT NOT NULL)",
        [],
    )
    .map_err(|e| format!("[SHARE] SYNC_META_TABLE: {e}"))?;
    // Mint the profile's Data Encryption Key eagerly and persist it, so it can
    // never drift from blobs already pushed (which would happen if a sync
    // created it in-memory but crashed before saving). No-op after the first.
    if get_or_create_dek(&conn)?.1 {
        needs_resave = true;
    }

    // Reset every monitor to paused on profile open. Pollers don't survive
    // app restart, so a row with `paused=0` left over from the previous
    // session would advertise itself as "running" in the UI while no actual
    // backend task is spinning. Forcing pause makes the displayed state
    // truthful and matches the user's preference for explicit start.
    let _ = conn.execute("UPDATE monitor_configs SET paused = 1", []);

    // Acquire all four slot locks FIRST, then populate them in one go.
    // The previous "lock-populate, lock-populate, ..." pattern could
    // leave DbState half-initialised on a poisoned-mutex error from any
    // step but the first — later commands would see e.g. db_path set
    // but no master_key and fail in save_vault_internal with a
    // confusing MISSING_REQUIRED_RESOURCES error.
    let mut conn_guard = state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED_CONN")?;
    let mut key_guard = state.master_key.lock().map_err(|_| "[STATE] LOCK_FAILED_KEY")?;
    let mut salt_guard = state.salt.lock().map_err(|_| "[STATE] LOCK_FAILED_SALT")?;
    let mut path_guard = state.db_path.lock().map_err(|_| "[STATE] LOCK_FAILED_PATH")?;
    let mut hlc_guard = state.hlc.lock().map_err(|_| "[STATE] LOCK_FAILED_HLC")?;
    *conn_guard = Some(conn);
    *key_guard = Some(key);
    *salt_guard = Some(salt_bytes);
    *path_guard = Some(path);
    *hlc_guard = Some(hlc_arc);
    // A new opening: anything still running for the profile open before
    // (a sync waiting on the network, say) must not write into this one.
    let generation = state.bump_generation();
    drop(hlc_guard);
    drop(path_guard);
    drop(salt_guard);
    drop(key_guard);
    drop(conn_guard);

    if needs_resave {
        save_vault_internal(&state)?;
    }
    Ok(generation)
}

/// Flush the in-memory vault to disk. Used by the frontend after a successful
/// SSH connection so any `known_hosts` row that `check_server_key` inserted
/// during the handshake survives an app restart — otherwise the user would
/// see the same fingerprint prompt every time they reconnect.
#[tauri::command]
async fn persist_vault(state: tauri::State<'_, DbState>) -> Result<(), String> {
    save_vault_async(&state).await
}

/// Create a brand-new profile, encrypted with `password`, and select it as
/// the active profile so the app can proceed directly into the main view
/// without bouncing back through `select_profile + setup_master_db`.
/// Rejected if a profile with the same name already exists — the picker
/// surfaces existing names so a clobber would be the user's mistake to
/// recover from, not something we should silently do.
#[tauri::command]
async fn create_profile(
    app_handle: tauri::AppHandle,
    state: tauri::State<'_, DbState>,
    name: String,
    password: String,
) -> Result<(), String> {
    validate_profile_name(&name)?;
    if password.is_empty() {
        return Err("密码不能为空".into());
    }
    let dir = profiles_dir(&app_handle)?;
    fs::create_dir_all(&dir).map_err(|e| format!("[FILE] MKDIR_FAILED: {}", e))?;
    let path = profile_path(&app_handle, &name)?;
    if path.exists() {
        return Err(format!("档案“{}”已存在", name));
    }
    *state.active_profile.lock().map_err(|_| "[STATE] LOCK_FAILED")? = Some(name);
    // Reuse setup_master_db's fresh-schema branch by deferring to it. Empty
    // profile starts with the same migrations the legacy path would do.
    let opened = setup_master_db_inner(app_handle.clone(), password, state, true).await?;

    // New profile: mint a stable UUID and partition its cloud sync by that UUID
    // rather than its name. Two vaults that happen to share a display name then
    // land in SEPARATE server partitions with separate keys — no cross-decrypt
    // failures, no silently merged records. Legacy `main` predates this and
    // keeps its name partition (untouched); only profiles born here get a UUID.
    // The human-readable name still reaches the server via sync_now's `name`.
    let db_state = app_handle.state::<DbState>();
    {
        let conn_g = db_state.conn.lock().map_err(|_| "[STATE] LOCK_CONN")?;
        let conn = conn_g.as_ref().ok_or("[STATE] DB_NOT_OPEN")?;
        // The ids below belong to the profile just created, not to one opened
        // since.
        db_state.still_open(opened)?;
        let mut pid = [0u8; 16];
        rand::rng().fill_bytes(&mut pid);
        let pid_hex = hex::encode(pid); // 32 hex chars — fits the server's 32-char partition column
        // DO NOTHING (never overwrite): a fresh vault has neither key, but this
        // must never repartition a profile if it somehow re-runs.
        conn.execute(
            "INSERT INTO sync_meta(key,value) VALUES('profile_id',?1) ON CONFLICT(key) DO NOTHING",
            [&pid_hex],
        )
        .map_err(|e| format!("[STATE] PROFILE_ID_STORE: {e}"))?;
        conn.execute(
            "INSERT INTO sync_meta(key,value) VALUES('cloud_profile',?1) ON CONFLICT(key) DO NOTHING",
            [&pid_hex],
        )
        .map_err(|e| format!("[STATE] CLOUD_PROFILE_STORE: {e}"))?;
        // Not linked to any sync server yet: its first sync links it to the
        // one in use (see `check_profile_server`).
        conn.execute(
            "INSERT INTO sync_meta(key,value) VALUES('cloud_server','') ON CONFLICT(key) DO NOTHING",
            [],
        )
        .map_err(|e| format!("[STATE] CLOUD_SERVER_STORE: {e}"))?;
    }
    save_vault_internal(&db_state)?;
    Ok(())
}

/// What `generate_ssh_key` made: its row id (so the server form can select
/// it) and the public half to put in the server's authorized_keys.
#[derive(serde::Serialize)]
struct GeneratedSshKey {
    id: i64,
    public_key: String,
}

#[tauri::command]
async fn generate_ssh_key(state: tauri::State<'_, DbState>, name: String) -> Result<GeneratedSshKey, String> {
    let mut seed = [0u8; 32];
    rand::rng().fill_bytes(&mut seed);
    let keypair = Ed25519Keypair::from(Ed25519PrivateKey::from_bytes(&seed));
    let priv_key = PrivateKey::from(keypair);
    let pub_ssh = priv_key.public_key().to_openssh()
        .map_err(|e| format!("[SSH] PUB_EXPORT_FAILED: {}", e))?;
    let priv_ssh = priv_key.to_openssh(ssh_key::LineEnding::LF)
        .map_err(|e| format!("[SSH] PRIV_EXPORT_FAILED: {}", e))?.to_string();

    let conn_guard = state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
    let conn = conn_guard.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;
    
    conn.execute("INSERT INTO ssh_keys (name, public_key, private_key) VALUES (?1, ?2, ?3)", rusqlite::params![name, pub_ssh, priv_ssh])
        .map_err(|e| format!("[DATABASE] KEY_INSERT_FAILED: {}", e))?;
    let id = conn.last_insert_rowid();

    drop(conn_guard);
    save_vault_internal(&state)?;
    Ok(GeneratedSshKey { id, public_key: pub_ssh })
}

/// The `-----BEGIN … PRIVATE KEY-----` line of a PEM key, skipping anything
/// before it (`openssl ecparam -genkey` writes an `EC PARAMETERS` block first).
/// Empty when there is none.
fn pem_private_key_header(text: &str) -> &str {
    text.lines()
        .map(str::trim)
        .find(|l| l.starts_with("-----BEGIN ") && l.ends_with(" PRIVATE KEY-----"))
        .unwrap_or("")
}

/// An ECDSA key in SEC1 PEM encrypted the legacy way (`Proc-Type:
/// 4,ENCRYPTED`). russh decrypts that encryption only for RSA keys, so no
/// passphrase can unlock it here.
fn is_legacy_encrypted_ec_pem(text: &str) -> bool {
    pem_private_key_header(text) == "-----BEGIN EC PRIVATE KEY-----"
        && text.contains("Proc-Type: 4,ENCRYPTED")
}

/// Whether a private key is passphrase-protected, judged from the key text
/// alone: an OpenSSH key whose header says so, a legacy PEM key encrypted the
/// PKCS#5 way (`Proc-Type: 4,ENCRYPTED`), or an encrypted PKCS#8 key.
fn private_key_is_encrypted(text: &str) -> bool {
    text.contains("Proc-Type: 4,ENCRYPTED")
        || pem_private_key_header(text) == "-----BEGIN ENCRYPTED PRIVATE KEY-----"
        || ssh_key::PrivateKey::from_openssh(text.trim())
            .map(|k| k.is_encrypted())
            .unwrap_or(false)
}

/// Key types the connect path can sign with.
fn check_key_algorithm(algorithm: &ssh_key::Algorithm) -> Result<(), String> {
    match algorithm {
        ssh_key::Algorithm::Ed25519 | ssh_key::Algorithm::Rsa { .. } | ssh_key::Algorithm::Ecdsa { .. } => Ok(()),
        other => Err(format!("[SSH] UNSUPPORTED_KEY_TYPE: {} keys are not supported.", other.as_str())),
    }
}

/// Reject key formats the SSH client cannot use, so failures surface when the
/// user enters the key rather than when they try to connect.
fn validate_ssh_private_key(private_key: &str) -> Result<(), String> {
    let trimmed = private_key.trim();

    match pem_private_key_header(trimmed) {
        // PKCS#1 RSA PEM is decoded by russh's pure-Rust backend in every build.
        "-----BEGIN RSA PRIVATE KEY-----" => Ok(()),
        "-----BEGIN DSA PRIVATE KEY-----" => Err(
            "[SSH] UNSUPPORTED_KEY_TYPE: DSA keys aren't supported. Generate a new key, e.g. with `ssh-keygen -t ed25519`.".into(),
        ),
        "-----BEGIN EC PRIVATE KEY-----" if is_legacy_encrypted_ec_pem(trimmed) => Err(
            "[SSH] UNSUPPORTED_KEY_FORMAT: This ECDSA key uses the legacy PEM encryption, which Submarine can only read for RSA keys. Re-save it in OpenSSH format with `ssh-keygen -p -f <file>` and import it again.".into(),
        ),
        // ECDSA in SEC1 PEM (any curve russh signs with: P-256, P-384, P-521)
        // and PKCS#8 (ECDSA, Ed25519 or RSA). Unencrypted, so read it now.
        "-----BEGIN EC PRIVATE KEY-----" | "-----BEGIN PRIVATE KEY-----" => {
            match russh::keys::decode_secret_key(trimmed, None) {
                Ok(key) => check_key_algorithm(&key.algorithm()),
                Err(e) => Err(format!("[SSH] UNREADABLE_KEY: This key couldn't be read: {}", e)),
            }
        }
        // Encrypted PKCS#8 can't be opened without its passphrase, which is
        // saved with the key or asked for when connecting.
        "-----BEGIN ENCRYPTED PRIVATE KEY-----" => Ok(()),
        "-----BEGIN OPENSSH PRIVATE KEY-----" => {
            // Inspect the algorithm without requiring the passphrase — the
            // algorithm header is unencrypted even when the body is encrypted.
            // If parsing fails entirely (unexpected header layout), let it
            // through; the connect path will surface a clearer error.
            match ssh_key::PrivateKey::from_openssh(trimmed) {
                Ok(parsed) => check_key_algorithm(&parsed.algorithm()),
                Err(_) => Ok(()),
            }
        }
        _ => Err("[SSH] UNRECOGNIZED_KEY_FORMAT: Expected a private key in OpenSSH format (begins with -----BEGIN OPENSSH PRIVATE KEY-----) or PEM / PKCS#8 (-----BEGIN RSA PRIVATE KEY-----, -----BEGIN EC PRIVATE KEY-----, -----BEGIN PRIVATE KEY-----).".into()),
    }
}

#[tauri::command]
async fn add_ssh_key(state: tauri::State<'_, DbState>, name: String, public_key: String, private_key: String, passphrase: Option<String>) -> Result<(), String> {
    validate_ssh_private_key(&private_key)?;

    let conn_guard = state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
    let conn = conn_guard.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;

    conn.execute("INSERT INTO ssh_keys (name, public_key, private_key, passphrase) VALUES (?1, ?2, ?3, ?4)", rusqlite::params![name, public_key, private_key, passphrase])
        .map_err(|e| format!("[DATABASE] KEY_INSERT_FAILED: {}", e))?;

    drop(conn_guard);
    save_vault_internal(&state)?;
    Ok(())
}

#[tauri::command]
async fn edit_ssh_key(state: tauri::State<'_, DbState>, id: i32, name: String, public_key: String, private_key: String, passphrase: Option<String>) -> Result<(), String> {
    validate_ssh_private_key(&private_key)?;

    let conn_guard = state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
    let conn = conn_guard.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;

    conn.execute("UPDATE ssh_keys SET name=?1, public_key=?2, private_key=?3, passphrase=?4 WHERE id=?5", rusqlite::params![name, public_key, private_key, passphrase, id])
        .map_err(|e| format!("[DATABASE] KEY_UPDATE_FAILED: {}", e))?;

    drop(conn_guard);
    save_vault_internal(&state)?;
    Ok(())
}

#[tauri::command]
async fn delete_ssh_key(state: tauri::State<'_, DbState>, id: i32) -> Result<(), String> {
    let conn_guard = state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
    let conn = conn_guard.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;
    
    conn.execute("DELETE FROM ssh_keys WHERE id=?1", rusqlite::params![id])
        .map_err(|e| format!("[DATABASE] KEY_DELETE_FAILED: {}", e))?;

    drop(conn_guard);
    save_vault_internal(&state)?;
    Ok(())
}

// ---------------------------------------------------------------------------
// Loading an SSH key off the filesystem
// ---------------------------------------------------------------------------
//
// Keys reach the vault two ways here: the user browsing to one by hand, and
// `IdentityFile` picked up while importing an OpenSSH config. Both land on
// `load_key_from_disk`, so a key sourced either way is validated identically
// and the file is read exactly once.

/// Ceiling on how much of a chosen file we'll read. A private key is a couple
/// of kilobytes; past this it isn't one, and reading the whole thing only to
/// reject it would let a mis-click pull an ISO into memory.
const SSH_KEY_MAX_BYTES: u64 = 512 * 1024;

/// Expand a leading `~` the way OpenSSH does when it resolves `IdentityFile`.
/// `~user/…` is left alone: it needs a passwd lookup, and a personal config
/// pointing at another account's key isn't a case worth supporting.
fn expand_home(raw: &str) -> PathBuf {
    let trimmed = raw.trim().trim_matches('"');
    let rest = match trimmed.strip_prefix("~/").or_else(|| trimmed.strip_prefix("~\\")) {
        Some(r) => r,
        None => return PathBuf::from(trimmed),
    };
    match directories::UserDirs::new() {
        Some(dirs) => dirs.home_dir().join(rest),
        // No home directory to expand against — hand back the literal path so
        // the caller reports "not found" on something the user can recognise,
        // rather than a path with a silently-dropped tilde.
        None => PathBuf::from(trimmed),
    }
}

/// A key file read from disk, with everything we can determine without asking
/// the user for a passphrase.
#[derive(serde::Serialize)]
struct LoadedSshKey {
    /// Absolute path we actually read, after `~` expansion. Echoed back so the
    /// UI can show what it picked up and pass it to `import_ssh_key_file`
    /// without re-deriving it.
    path: String,
    /// Name to pre-fill, taken from the file stem (`id_ed25519`).
    suggested_name: String,
    private_key: String,
    /// OpenSSH stores the public half in cleartext even in an encrypted key
    /// file, and an unencrypted PEM / PKCS#8 key can be decoded for it, so this
    /// is usually derivable from the private key alone. For an encrypted PEM /
    /// PKCS#8 key we fall back to a sibling `<file>.pub` and, failing that,
    /// leave it empty — nothing in the connect path needs it, it's here so the
    /// user can copy it into an `authorized_keys`.
    public_key: String,
    /// Whether the key is passphrase-protected. The passphrase itself is never
    /// on disk, so the UI has to ask for it separately before the key will
    /// connect.
    encrypted: bool,
}

/// Only a file on this computer: a network share (`\\host\share\…`, also
/// spelled with `/`), a device or a `\\?\` path is refused before anything
/// touches it. Just looking up a share makes Windows sign in to that host,
/// which a key path in a pasted host list shouldn't be able to cause.
fn local_file_path(path: &std::path::Path) -> Result<(), String> {
    use std::path::{Component, Prefix};
    match path.components().next() {
        Some(Component::Prefix(p)) if !matches!(p.kind(), Prefix::Disk(_)) => {
            Err(format!("[SSH] KEY_FILE_NOT_LOCAL: {} isn't a file on this computer.", path.display()))
        }
        _ => Ok(()),
    }
}

/// A short text file's contents, or nothing: only a regular file of at most
/// `max` bytes is read. A `.pub` next to a key is one line; a FIFO there
/// would hang the read, and a huge file would fill memory.
fn small_text_file(path: &std::path::Path, max: u64) -> Option<String> {
    let meta = fs::metadata(path).ok()?;
    if !meta.is_file() || meta.len() > max {
        return None;
    }
    fs::read_to_string(path).ok()
}

/// Read and validate a private key file. Shared by the browse flow and the
/// SSH-config import.
fn load_key_from_disk(path: &std::path::Path) -> Result<LoadedSshKey, String> {
    local_file_path(path)?;
    let meta = fs::metadata(path)
        .map_err(|e| format!("[SSH] KEY_FILE_UNREADABLE at {}: {}", path.display(), e))?;
    if !meta.is_file() {
        return Err(format!("[SSH] KEY_FILE_NOT_A_FILE: {}", path.display()));
    }
    if meta.len() > SSH_KEY_MAX_BYTES {
        return Err(format!(
            "[SSH] KEY_FILE_TOO_LARGE: {} is {} bytes — that isn't a private key.",
            path.display(),
            meta.len()
        ));
    }

    // A key file is text; a binary one (say, a PuTTY .ppk mistaken for an
    // OpenSSH key) fails here with a clearer message than the validator's.
    let private_key = fs::read_to_string(path).map_err(|e| {
        format!("[SSH] KEY_FILE_NOT_TEXT at {}: {}", path.display(), e)
    })?;
    validate_ssh_private_key(&private_key)?;

    let encrypted = private_key_is_encrypted(&private_key);
    // The public half: an OpenSSH key carries it in cleartext even when
    // encrypted, and an unencrypted PEM / PKCS#8 key yields it once decoded.
    let normalized = private_key.replace("\r\n", "\n");
    let readable = ssh_key::PrivateKey::from_openssh(normalized.trim()).ok().or_else(|| {
        if encrypted {
            None
        } else {
            russh::keys::decode_secret_key(&normalized, None).ok()
        }
    });
    // `with_extension` would turn `key.pem` into `key.pub`; the convention is
    // to append, so `id_ed25519` → `id_ed25519.pub` and `key.pem` → `key.pem.pub`.
    let sibling_pub = {
        let mut s = path.as_os_str().to_os_string();
        s.push(".pub");
        PathBuf::from(s)
    };
    let public_key = readable
        .as_ref()
        .and_then(|p| p.public_key().to_openssh().ok())
        .or_else(|| small_text_file(&sibling_pub, 16 * 1024))
        .unwrap_or_default()
        .trim()
        .to_string();

    let suggested_name = path
        .file_stem()
        .and_then(|s| s.to_str())
        .filter(|s| !s.is_empty())
        .unwrap_or("Imported key")
        .to_string();

    Ok(LoadedSshKey {
        path: path.to_string_lossy().into_owned(),
        suggested_name,
        private_key,
        public_key,
        encrypted,
    })
}

/// Open a native picker for a private key file and return the chosen path, or
/// `None` if the user cancelled. Only the path crosses IPC — the file isn't
/// read until the caller asks for it by name, so cancelling costs nothing and
/// the key never travels for a dialog the user backed out of.
///
/// `async` for the same reason `export_profile` is: rfd's blocking dialog must
/// not run on the main thread on macOS, and a sync Tauri command does.
#[tauri::command]
async fn pick_ssh_key_file() -> Result<Option<String>, String> {
    // Native dialogs are desktop-only, same as profile export/import above.
    #[cfg(target_os = "android")]
    {
        Err("Android 上不支持浏览密钥文件——请改为粘贴密钥。".into())
    }
    #[cfg(not(target_os = "android"))]
    {
        let mut dialog = rfd::FileDialog::new().set_title("Choose an SSH private key");
        // Start where the keys almost always are. Key files are conventionally
        // extensionless (`id_ed25519`), which no filter can express, so the
        // picker stays unfiltered and `load_key_from_disk` does the rejecting.
        if let Some(dirs) = directories::UserDirs::new() {
            let ssh_dir = dirs.home_dir().join(".ssh");
            if ssh_dir.is_dir() {
                dialog = dialog.set_directory(&ssh_dir);
            }
        }
        Ok(dialog.pick_file().map(|p| p.to_string_lossy().into_owned()))
    }
}

/// Read a key file the user already chose, for the "fill in the new-key form"
/// flow. Nothing is written to the vault — the user still reviews the name and
/// supplies a passphrase before saving.
#[tauri::command]
async fn read_ssh_key_file(path: String) -> Result<LoadedSshKey, String> {
    // Off the main thread (where a sync command runs) and off the async
    // workers: a slow or stuck file read mustn't freeze the window.
    tokio::task::spawn_blocking(move || load_key_from_disk(&expand_home(&path)))
        .await
        .map_err(|e| format!("[SSH] KEY_FILE_READ: {e}"))?
}

/// A key that `import_ssh_key_file` put in the vault (or found already there).
#[derive(serde::Serialize)]
struct ImportedSshKey {
    id: i64,
    name: String,
    /// True when we matched an existing row instead of inserting one. Lets the
    /// importer tell the user "attached your existing key" rather than
    /// implying it created a duplicate.
    reused: bool,
    /// Carried through from the file so the caller can warn that this key
    /// won't connect until its passphrase is filled in.
    encrypted: bool,
}

/// Read a key file straight into the vault and hand back the row to link a
/// server against. Used by the SSH-config import (one call per distinct
/// `IdentityFile`) and by the browse button on the server sheet.
///
/// Re-importing the same file is idempotent: identity is the private key's
/// own bytes, so a second run over an unchanged `~/.ssh/config` attaches the
/// keys already in the vault instead of piling up copies of them.
#[tauri::command]
async fn import_ssh_key_file(
    state: tauri::State<'_, DbState>,
    path: String,
    name: Option<String>,
) -> Result<ImportedSshKey, String> {
    // A blocking read, so not on an async worker (see read_ssh_key_file).
    let loaded = tokio::task::spawn_blocking(move || load_key_from_disk(&expand_home(&path)))
        .await
        .map_err(|e| format!("[SSH] KEY_FILE_READ: {e}"))??;
    let encrypted = loaded.encrypted;
    // The key content only ever lives in this function, so keep it wiped on
    // the way out rather than leaving it in a heap block for the allocator to
    // hand to something else.
    let private_key = Zeroizing::new(loaded.private_key);
    let requested = name
        .map(|n| n.trim().to_string())
        .filter(|n| !n.is_empty())
        .unwrap_or(loaded.suggested_name);

    let conn_guard = state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
    let conn = conn_guard.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;

    if let Ok((id, existing_name)) = conn.query_row(
        "SELECT id, name FROM ssh_keys WHERE private_key = ?1 LIMIT 1",
        rusqlite::params![private_key.as_str()],
        |row| Ok((row.get::<_, i64>(0)?, row.get::<_, String>(1)?)),
    ) {
        return Ok(ImportedSshKey { id, name: existing_name, reused: true, encrypted });
    }

    // Names aren't unique in the schema, but two rows called `id_ed25519` are
    // indistinguishable in the key dropdown, so suffix a fresh import whose
    // name some other key already holds.
    let mut final_name = requested.clone();
    for suffix in 2..100 {
        let taken: bool = conn
            .query_row(
                "SELECT 1 FROM ssh_keys WHERE name = ?1",
                rusqlite::params![final_name],
                |_| Ok(true),
            )
            .unwrap_or(false);
        if !taken {
            break;
        }
        final_name = format!("{} ({})", requested, suffix);
    }

    conn.execute(
        "INSERT INTO ssh_keys (name, public_key, private_key) VALUES (?1, ?2, ?3)",
        rusqlite::params![final_name, loaded.public_key, private_key.as_str()],
    )
    .map_err(|e| format!("[DATABASE] KEY_INSERT_FAILED: {}", e))?;
    let id = conn.last_insert_rowid();

    drop(conn_guard);
    save_vault_internal(&state)?;
    Ok(ImportedSshKey { id, name: final_name, reused: false, encrypted })
}

/// Canonicalize a node row's identity fields based on the chosen auth_type.
/// The principle: a node either authenticates via a vault credential OR via
/// inline node-level fields — never a hybrid. Storing only the relevant
/// fields makes the connection-time resolution unambiguous and keeps the DB
/// honest about which mode a node really uses.
fn normalize_server_identity(
    auth_type: &str,
    username: Option<String>,
    password: Option<String>,
    key_id: Option<i32>,
    credential_id: Option<i32>,
) -> (Option<String>, Option<String>, Option<i32>, Option<i32>) {
    // Treat empty / whitespace-only usernames as absent so the DB stays clean.
    let username = username.and_then(|s| {
        let t = s.trim();
        if t.is_empty() { None } else { Some(t.to_string()) }
    });
    match auth_type {
        "vault" => {
            // Credential carries everything; the node row stores only the link.
            (None, None, None, credential_id)
        }
        "custom_key" => {
            // No password, no credential link — node owns username + key.
            (username, None, key_id, None)
        }
        // "custom_pass" and any unknown fallback: node owns username + password.
        _ => (username, password, None, None),
    }
}

#[tauri::command]
async fn add_server(
    state: tauri::State<'_, DbState>,
    name: String,
    host: String,
    port: i32,
    username: Option<String>,
    password: Option<String>,
    credential_id: Option<i32>,
    folder_id: Option<i32>,
    proxy_type: String,
    proxy_host: String,
    proxy_port: i32,
    tunnels: Vec<serde_json::Value>,
    auth_type: String,
    key_id: Option<i32>,
    autostart: Option<bool>,
    mirrors: Option<Vec<serde_json::Value>>,
    color: Option<String>,
) -> Result<i64, String> {
    let conn_guard = state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
    let conn = conn_guard.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;

    let tunnels_json = serde_json::to_string(&tunnels).unwrap_or_else(|_| "[]".to_string());
    let mirrors_json = mirrors.as_ref()
        .map(|m| serde_json::to_string(m).unwrap_or_else(|_| "[]".into()))
        .unwrap_or_else(|| "[]".into());

    // Enforce the "one source of truth" rule at write time: in vault mode the
    // node row carries no identity at all; in custom_* mode the credential
    // link is dropped. This keeps the DB self-consistent even if a future
    // caller forgets to nil out the fields.
    let (db_username, db_password, db_key_id, db_credential_id) = normalize_server_identity(
        &auth_type, username, password, key_id, credential_id,
    );

    let autostart_i: i32 = if autostart.unwrap_or(false) { 1 } else { 0 };
    let res = conn.execute(
        "INSERT INTO servers (name, host, port, username, password, credential_id, folder_id, proxy_type, proxy_host, proxy_port, tunnels, auth_type, key_id, autostart, mirrors, color) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10, ?11, ?12, ?13, ?14, ?15, ?16)",
        rusqlite::params![name, host, port, db_username, db_password, db_credential_id, folder_id, proxy_type, proxy_host, proxy_port, tunnels_json, auth_type, db_key_id, autostart_i, mirrors_json, color],
    ).map_err(|e| format!("[DATABASE] SERVER_INSERT_FAILED: SQL_ERROR={}", e))?;

    if res == 0 {
        return Err("[DATABASE] SERVER_INSERT_FAILED: No rows affected".into());
    }

    let new_id = conn.last_insert_rowid();
    // Append to the bottom of its folder's manual order: one past the current
    // max position among the folder's other rows (`IS ?2` is NULL-safe so the
    // root folder groups correctly). Without this a new node would inherit the
    // default position 0 and jump to the TOP of a folder the user reordered.
    let _ = conn.execute(
        "UPDATE servers SET position = COALESCE((SELECT MAX(position) FROM servers WHERE id != ?1 AND folder_id IS ?2), -1) + 1 WHERE id = ?1",
        rusqlite::params![new_id, folder_id],
    );
    drop(conn_guard);
    save_vault_internal(&state)?;
    Ok(new_id)
}

/// Persist a Quick Connect target as a reusable node in the ROOT directory
/// (folder_id NULL). Quick Connect is otherwise ephemeral; this leaves behind a
/// saved profile the user can reconnect to later without re-typing credentials.
/// Deduplicates by (host, port, username) among root nodes so repeatedly
/// quick-connecting to the same host doesn't pile up identical rows — the
/// existing node's id is returned instead. Password targets are stored as
/// `custom_pass` (inline username + password); key targets save the private key
/// into `ssh_keys` (public_key left empty — the connect path derives everything
/// it needs from the private key via decode_secret_key, see the custom_key
/// branch in initiate_connection) and reference it as `custom_key`.
#[tauri::command]
async fn save_quick_connect_node(
    state: tauri::State<'_, DbState>,
    auth: QuickAuth,
) -> Result<i64, String> {
    let conn_guard = state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
    let conn = conn_guard.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;

    // A blank username stays blank: the saved node then asks for it at
    // connect time too (issue #54), exactly like the live session does.
    let username = auth.username.trim().to_string();

    // Dedup against existing, non-deleted ROOT nodes with the same identity so
    // the grid doesn't fill with duplicates on repeated quick connects.
    let existing = conn.query_row(
        "SELECT id FROM servers WHERE deleted = 0 AND folder_id IS NULL AND host = ?1 AND port = ?2 AND COALESCE(username,'') = ?3 LIMIT 1",
        rusqlite::params![auth.host, auth.port, username],
        |r| r.get::<_, i64>(0),
    );
    match existing {
        Ok(id) => return Ok(id),
        Err(rusqlite::Error::QueryReturnedNoRows) => {}
        Err(e) => return Err(format!("[DATABASE] QUICK_NODE_LOOKUP_FAILED: {}", e)),
    }

    let name = if username.is_empty() {
        auth.host.clone()
    } else {
        format!("{}@{}", username, auth.host)
    };

    // A private key wins over a password if both somehow arrived.
    let (auth_type, db_password, db_key_id): (&str, Option<String>, Option<i64>) =
        if let Some(pem) = auth.private_key.as_ref().filter(|s| !s.trim().is_empty()) {
            validate_ssh_private_key(pem)?;
            conn.execute(
                "INSERT INTO ssh_keys (name, public_key, private_key, passphrase) VALUES (?1, ?2, ?3, ?4)",
                rusqlite::params![name, "", pem, auth.passphrase],
            ).map_err(|e| format!("[DATABASE] QUICK_KEY_INSERT_FAILED: {}", e))?;
            ("custom_key", None, Some(conn.last_insert_rowid()))
        } else {
            ("custom_pass", auth.password.clone(), None)
        };

    conn.execute(
        "INSERT INTO servers (name, host, port, username, password, credential_id, folder_id, proxy_type, proxy_host, proxy_port, tunnels, auth_type, key_id, autostart, mirrors, color) \
         VALUES (?1, ?2, ?3, ?4, ?5, NULL, NULL, 'none', '', 1080, '[]', ?6, ?7, 0, '[]', NULL)",
        rusqlite::params![name, auth.host, auth.port, username, db_password, auth_type, db_key_id],
    ).map_err(|e| format!("[DATABASE] QUICK_NODE_INSERT_FAILED: {}", e))?;

    let new_id = conn.last_insert_rowid();
    // Append to the bottom of the root order (mirrors add_server's position calc).
    let _ = conn.execute(
        "UPDATE servers SET position = COALESCE((SELECT MAX(position) FROM servers WHERE id != ?1 AND folder_id IS NULL), -1) + 1 WHERE id = ?1",
        rusqlite::params![new_id],
    );

    drop(conn_guard);
    save_vault_internal(&state)?;
    Ok(new_id)
}

#[tauri::command]
async fn edit_server(
    state: tauri::State<'_, DbState>,
    ssh_state: tauri::State<'_, SshState>,
    id: i32,
    name: String,
    host: String,
    port: i32,
    username: Option<String>,
    password: Option<String>,
    credential_id: Option<i32>,
    folder_id: Option<i32>,
    proxy_type: String,
    proxy_host: String,
    proxy_port: i32,
    tunnels: Vec<serde_json::Value>,
    auth_type: String,
    key_id: Option<i32>,
    autostart: Option<bool>,
    mirrors: Option<Vec<serde_json::Value>>,
    color: Option<String>,
    // Frontend opt-out for password persistence. When the user opens the
    // edit sheet, we call `reveal_server_password` to populate the form;
    // if that call ever fails (transient DB error / migration mid-flight)
    // the form would have a blank password and a naive save would wipe
    // the stored secret. The frontend sends `preserve_password=true`
    // whenever the password field wasn't touched, and the SQL below uses
    // COALESCE(?, password) so the existing column survives.
    preserve_password: Option<bool>,
) -> Result<(), String> {
    let tunnels_json = serde_json::to_string(&tunnels).unwrap_or_else(|_| "[]".to_string());
    let mirrors_json = mirrors.as_ref()
        .map(|m| serde_json::to_string(m).unwrap_or_else(|_| "[]".into()))
        .unwrap_or_else(|| "[]".into());

    let (db_username, db_password, db_key_id, db_credential_id) = normalize_server_identity(
        &auth_type, username, password, key_id, credential_id,
    );
    let autostart_i: i32 = if autostart.unwrap_or(false) { 1 } else { 0 };

    // All SQLite work is scoped so the non-Send connection guard is fully
    // dropped before the async cache-invalidation await below — Tauri requires
    // the command future to be Send. Returns whether the forwarding rules
    // changed: if they did, the node's saved rules become the new source of
    // truth and the live session's cached replay list must be dropped (below).
    // Otherwise a session that already seeded its specs, or had them stripped
    // to an empty list by a failed bind, keeps using the stale set and never
    // re-reads the edited rules — the "changed the port but the forward never
    // comes up" bug.
    let tunnels_changed = {
        let conn_guard = state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
        let conn = conn_guard.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;

        let old_tunnels_json: String = conn
            .query_row("SELECT COALESCE(tunnels,'[]') FROM servers WHERE id=?1", [id], |r| r.get(0))
            .unwrap_or_else(|_| "[]".to_string());

        // Capture the current folder so we can detect a move below and re-rank.
        let old_folder_id: Option<i32> = conn
            .query_row("SELECT folder_id FROM servers WHERE id=?1", [id], |r| r.get::<_, Option<i32>>(0))
            .ok()
            .flatten();

        // Two-flavour UPDATE: with `preserve_password`, the password column is
        // wrapped in COALESCE(?, password) so a NULL bind keeps the existing
        // value. Without it, the password column is overwritten the usual way.
        // The behaviour difference matters only when the auth path is custom_pass
        // because normalize_server_identity zeros password for the other modes.
        if preserve_password.unwrap_or(false) && auth_type == "custom_pass" {
            conn.execute(
                "UPDATE servers SET name=?1, host=?2, port=?3, username=?4, password=COALESCE(?5, password), credential_id=?6, folder_id=?7, proxy_type=?8, proxy_host=?9, proxy_port=?10, tunnels=?11, auth_type=?12, key_id=?13, autostart=?14, mirrors=?15, color=?16 WHERE id=?17",
                rusqlite::params![name, host, port, db_username, db_password, db_credential_id, folder_id, proxy_type, proxy_host, proxy_port, tunnels_json, auth_type, db_key_id, autostart_i, mirrors_json, color, id],
            ).map_err(|e| format!("[DATABASE] SERVER_UPDATE_FAILED: SQL_ERROR={}", e))?;
        } else {
            conn.execute(
                "UPDATE servers SET name=?1, host=?2, port=?3, username=?4, password=?5, credential_id=?6, folder_id=?7, proxy_type=?8, proxy_host=?9, proxy_port=?10, tunnels=?11, auth_type=?12, key_id=?13, autostart=?14, mirrors=?15, color=?16 WHERE id=?17",
                rusqlite::params![name, host, port, db_username, db_password, db_credential_id, folder_id, proxy_type, proxy_host, proxy_port, tunnels_json, auth_type, db_key_id, autostart_i, mirrors_json, color, id],
            ).map_err(|e| format!("[DATABASE] SERVER_UPDATE_FAILED: SQL_ERROR={}", e))?;
        }

        // Folder changed → re-append to the bottom of the destination folder's
        // manual order (mirrors add_server). Otherwise the row keeps its stale
        // rank from the old folder and can collide at the top of the new one.
        if old_folder_id != folder_id {
            let _ = conn.execute(
                "UPDATE servers SET position = COALESCE((SELECT MAX(position) FROM servers WHERE id != ?1 AND folder_id IS ?2), -1) + 1 WHERE id = ?1",
                rusqlite::params![id, folder_id],
            );
        }

        old_tunnels_json != tunnels_json
    };

    save_vault_internal(&state)?;

    // Forwarding rules changed → drop this server's live tunnel replay cache so
    // every (re)connect / restore path re-seeds from the freshly-saved DB rules
    // instead of clinging to a stale (or failure-emptied) in-memory list. All
    // those paths seed from the node's `tunnels` JSON precisely when the key is
    // ABSENT, so removing it is what lets the edit take effect. Session ids are
    // `session-{server_id}` (see openServer in the frontend).
    if tunnels_changed {
        ssh_state
            .session_tunnel_specs
            .lock()
            .await
            .remove(&format!("session-{}", id));
    }
    Ok(())
}

/// Append a single mirror spec to a saved server's mirrors column.
///
/// Exists so the live MirrorsPanel's "new mirror" flow can persist the
/// mirror it just started without round-tripping the whole edit_server
/// payload (which would force the panel to know about every other
/// node field — username, tunnels, auth_type, etc.). Pairs with
/// re-encrypting the vault on the way out, the same as the full edit
/// path does. Duplicate (local, remote) entries are coalesced so
/// hitting "Start mirror" twice on the same pair doesn't bloat the row.
#[tauri::command]
async fn add_mirror_to_server(
    state: tauri::State<'_, DbState>,
    server_id: i32,
    mirror: serde_json::Value,
) -> Result<(), String> {
    let conn_guard = state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
    let conn = conn_guard.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;

    let existing: String = conn.query_row(
        "SELECT mirrors FROM servers WHERE id = ?1",
        rusqlite::params![server_id],
        |row| row.get::<_, Option<String>>(0).map(|v| v.unwrap_or_else(|| "[]".into())),
    ).map_err(|e| format!("[DATABASE] SERVER_LOOKUP_FAILED: {}", e))?;

    let mut list: Vec<serde_json::Value> = serde_json::from_str(&existing).unwrap_or_default();
    let local  = mirror.get("local").and_then(|v| v.as_str()).unwrap_or("").to_string();
    let remote = mirror.get("remote").and_then(|v| v.as_str()).unwrap_or("").to_string();
    if local.is_empty() || remote.is_empty() {
        return Err("镜像同步需要同时指定本地路径和远程路径".into());
    }
    // Replace any prior entry for the same (local, remote) pair so the
    // latest spec (e.g. updated excludes / conflict mode) wins instead of
    // piling a duplicate row beside it.
    list.retain(|m| {
        m.get("local").and_then(|v| v.as_str()) != Some(&local)
            || m.get("remote").and_then(|v| v.as_str()) != Some(&remote)
    });
    list.push(mirror);

    let next = serde_json::to_string(&list).map_err(|e| format!("[DATABASE] SERIALIZE_FAILED: {}", e))?;
    conn.execute(
        "UPDATE servers SET mirrors = ?1 WHERE id = ?2",
        rusqlite::params![next, server_id],
    ).map_err(|e| format!("[DATABASE] MIRROR_SAVE_FAILED: {}", e))?;

    drop(conn_guard);
    save_vault_internal(&state)?;
    Ok(())
}

/// Reveal the plaintext password for a single server row. Used by the edit
/// panel — only the row the user is editing has its secret crossing IPC.
/// Returns `Ok(None)` if the server uses a vault credential (no inline
/// password) or the password column is empty.
#[tauri::command]
async fn reveal_server_password(state: tauri::State<'_, DbState>, id: i32) -> Result<Option<String>, String> {
    let conn_guard = state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
    let conn = conn_guard.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;
    conn.query_row(
        "SELECT password FROM servers WHERE id = ?1",
        rusqlite::params![id],
        |row| row.get::<_, Option<String>>(0),
    ).map_err(|e| format!("[DATABASE] REVEAL_FAILED: {}", e))
}

/// Reveal the plaintext password for a single saved credential. Same shape
/// and rationale as `reveal_server_password`.
#[tauri::command]
async fn reveal_credential_password(state: tauri::State<'_, DbState>, id: i32) -> Result<Option<String>, String> {
    let conn_guard = state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
    let conn = conn_guard.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;
    conn.query_row(
        "SELECT password FROM credentials WHERE id = ?1",
        rusqlite::params![id],
        |row| row.get::<_, Option<String>>(0),
    ).map_err(|e| format!("[DATABASE] REVEAL_FAILED: {}", e))
}

/// Reveal the stored private key + passphrase for an SSH key entry. Used
/// by the key editor and by any future "show key" affordance. The list
/// view never sees these fields.
#[tauri::command]
async fn reveal_ssh_key(state: tauri::State<'_, DbState>, id: i32) -> Result<serde_json::Value, String> {
    let conn_guard = state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
    let conn = conn_guard.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;
    conn.query_row(
        "SELECT private_key, passphrase FROM ssh_keys WHERE id = ?1",
        rusqlite::params![id],
        |row| {
            Ok(json!({
                "private_key": row.get::<_, Option<String>>(0)?,
                "passphrase": row.get::<_, Option<String>>(1)?,
            }))
        },
    ).map_err(|e| format!("[DATABASE] REVEAL_FAILED: {}", e))
}

/// Light-weight colour write — used by the NodeGrid swatch picker so the
/// caller doesn't have to round-trip the whole edit_server payload just to
/// change one tag. Pass `None` to clear back to the default ring.
#[tauri::command]
async fn set_server_color(state: tauri::State<'_, DbState>, id: i32, color: Option<String>) -> Result<(), String> {
    let conn_guard = state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
    let conn = conn_guard.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;
    conn.execute(
        "UPDATE servers SET color=?1 WHERE id=?2",
        rusqlite::params![color, id],
    ).map_err(|e| format!("[DATABASE] SERVER_COLOR_FAILED: {}", e))?;
    drop(conn_guard);
    save_vault_internal(&state)?;
    Ok(())
}

/// Persist a manual drag-to-reorder of the node grid. `ids` is the full list
/// of server ids in their new visual order (typically the servers of one
/// folder); we write each id's index as its `position`, so `get_servers`'
/// `ORDER BY position, id` reproduces the arrangement. The AFTER-UPDATE trigger
/// stamps updated_at/edited_by, so the new order LWW-syncs to other devices
/// like any other edited field. Writing 0..n only for the passed ids is safe:
/// positions are compared within a folder after `get_servers` filters, and id
/// breaks any cross-folder ties.
#[tauri::command]
async fn reorder_servers(state: tauri::State<'_, DbState>, ids: Vec<i32>) -> Result<(), String> {
    {
        let conn_guard = state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
        let conn = conn_guard.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;
        for (idx, id) in ids.iter().enumerate() {
            // Only touch rows whose position actually changes. The AFTER-UPDATE
            // trigger stamps updated_at unconditionally on any matched row, and
            // sync is whole-row LWW — so updating every folder member on each
            // reorder would bump their updated_at and could clobber a field
            // (password/host) edited concurrently on another device. Guarding on
            // a real change limits that blast radius to the genuinely-moved rows.
            conn.execute(
                "UPDATE servers SET position=?1 WHERE id=?2 AND (position IS NULL OR position<>?1)",
                rusqlite::params![idx as i64, id],
            ).map_err(|e| format!("[DATABASE] SERVER_REORDER_FAILED: {}", e))?;
        }
    }
    save_vault_internal(&state)?;
    Ok(())
}

#[tauri::command]
async fn set_folder_color(state: tauri::State<'_, DbState>, id: i32, color: Option<String>) -> Result<(), String> {
    let conn_guard = state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
    let conn = conn_guard.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;
    conn.execute(
        "UPDATE folders SET color=?1 WHERE id=?2",
        rusqlite::params![color, id],
    ).map_err(|e| format!("[DATABASE] FOLDER_COLOR_FAILED: {}", e))?;
    drop(conn_guard);
    save_vault_internal(&state)?;
    Ok(())
}

/// Update the free-form notes / description blob attached to a node. Stored
/// as plain text in the `notes` column; the UI renders it monospace and lets
/// the user dump runbook snippets, contact info, alerts to remember, etc.
#[tauri::command]
async fn set_server_notes(state: tauri::State<'_, DbState>, id: i32, notes: String) -> Result<(), String> {
    let conn_guard = state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
    let conn = conn_guard.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;
    conn.execute(
        "UPDATE servers SET notes=?1 WHERE id=?2",
        rusqlite::params![notes, id],
    ).map_err(|e| format!("[DATABASE] SERVER_NOTES_FAILED: {}", e))?;
    drop(conn_guard);
    save_vault_internal(&state)?;
    Ok(())
}

/// Per-server commands auto-typed into the first terminal on initial connect.
/// Stored as a single blob (newline-separated lines); the frontend sends them
/// only for `-term-0` and only on the first open, never on reconnect. Written
/// through its own command (like set_server_notes) so it doesn't have to be
/// threaded through add_server / edit_server's positional parameter lists.
#[tauri::command]
async fn set_server_run_on_connect(state: tauri::State<'_, DbState>, id: i32, value: String) -> Result<(), String> {
    let conn_guard = state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
    let conn = conn_guard.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;
    conn.execute(
        "UPDATE servers SET run_on_connect=?1 WHERE id=?2",
        rusqlite::params![value, id],
    ).map_err(|e| format!("[DATABASE] SERVER_RUN_ON_CONNECT_FAILED: {}", e))?;
    drop(conn_guard);
    save_vault_internal(&state)?;
    Ok(())
}

/// ProxyJump target for a node: `Some(other_server_id)` to bounce through that
/// server, or `None` to connect directly. Written through its own command
/// (like set_server_notes / set_server_run_on_connect) so it stays out of
/// add_server / edit_server's positional parameter lists.
#[tauri::command]
async fn set_server_jump_host(state: tauri::State<'_, DbState>, id: i32, value: Option<i32>) -> Result<(), String> {
    let conn_guard = state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
    let conn = conn_guard.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;
    conn.execute(
        "UPDATE servers SET jump_host_id=?1 WHERE id=?2",
        rusqlite::params![value, id],
    ).map_err(|e| format!("[DATABASE] SERVER_JUMP_HOST_FAILED: {}", e))?;
    drop(conn_guard);
    save_vault_internal(&state)?;
    Ok(())
}

/// Duplicate a server row verbatim — including credentials linkage, tunnels,
/// mirrors, proxy config, colour. The clone gets a "{name} (copy)" suffix so
/// it shows up beside the original in the grid; everything else is identical
/// so the user can connect to the same target with a different label or
/// tweak one field without retyping the rest.
#[tauri::command]
async fn clone_server(state: tauri::State<'_, DbState>, id: i32) -> Result<i64, String> {
    let conn_guard = state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
    let conn = conn_guard.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;
    let affected = conn.execute(
        "INSERT INTO servers (name, host, port, username, password, credential_id, folder_id, proxy_type, proxy_host, proxy_port, tunnels, auth_type, key_id, autostart, mirrors, color, notes, run_on_connect, jump_host_id)
         SELECT name || ' (copy)', host, port, username, password, credential_id, folder_id, proxy_type, proxy_host, proxy_port, tunnels, auth_type, key_id, 0, mirrors, color, notes, run_on_connect, jump_host_id
         FROM servers WHERE id = ?1",
        rusqlite::params![id],
    ).map_err(|e| format!("[DATABASE] SERVER_CLONE_FAILED: {}", e))?;
    if affected == 0 {
        return Err(format!("[DATABASE] SERVER_CLONE_FAILED: no row with id {}", id));
    }
    let new_id = conn.last_insert_rowid();
    // Place the clone at the bottom of its folder's manual order (the INSERT
    // above doesn't copy `position`, so without this it would default to 0 and
    // jump to the top). Same append logic as add_server, folder taken from the
    // clone's own row.
    let _ = conn.execute(
        "UPDATE servers SET position = COALESCE((SELECT MAX(position) FROM servers s2 WHERE s2.id != servers.id AND s2.folder_id IS servers.folder_id), -1) + 1 WHERE id = ?1",
        rusqlite::params![new_id],
    );
    drop(conn_guard);
    save_vault_internal(&state)?;
    Ok(new_id)
}

#[tauri::command]
async fn delete_server(
    state: tauri::State<'_, DbState>,
    map: tauri::State<'_, MonitorMap>,
    id: i32,
) -> Result<(), String> {
    // Stop the poller BEFORE the row goes away. The monitor_configs row does
    // cascade-delete with the server, but that only removes the config — the
    // spawned poller lives in MonitorMap and would keep opening SSH connections
    // to the host on its interval, using credentials the user just deleted.
    // Worse, it becomes unreachable: monitor_list JOINs servers, so the node
    // vanishes from the UI and monitor_remove (the only other caller of
    // stop_monitor) can no longer be invoked for it. Only an app restart
    // stopped it.
    monitor::stop_monitor(map.inner().clone(), id).await;

    let conn_guard = state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
    let conn = conn_guard.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;

    conn.execute("DELETE FROM servers WHERE id=?1", rusqlite::params![id])
        .map_err(|e| format!("[DATABASE] SERVER_DELETE_FAILED: {}", e))?;

    drop(conn_guard);
    save_vault_internal(&state)?;
    Ok(())
}

#[tauri::command]
async fn get_servers(state: tauri::State<'_, DbState>) -> Result<Vec<serde_json::Value>, String> {
    let conn_guard = state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
    let conn = conn_guard.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;
    // Secrets stay server-side: this listing returns `has_password` instead
    // of the plaintext column, so the password never crosses the IPC bridge
    // unless someone explicitly invokes `reveal_server_password`. The edit
    // panel calls reveal on open, but the cards / sidebar / quick-connect
    // grid never see the plaintext.
    // ORDER BY (position, id): `position` is the manual drag-to-reorder rank
    // (default 0 for never-reordered rows), and id breaks ties so the order is
    // stable and, before any reorder, identical to the old rowid order.
    let mut stmt = conn.prepare("SELECT id, name, host, port, username, password, credential_id, folder_id, proxy_type, proxy_host, proxy_port, tunnels, auth_type, key_id, autostart, mirrors, color, notes, run_on_connect, jump_host_id, updated_at, edited_by, position, uuid FROM servers ORDER BY position, id")
        .map_err(|e| format!("[DATABASE] PREPARE_FAILED: {}", e))?;

    let rows = stmt.query_map([], |row| {
        let pw: Option<String> = row.get::<_, Option<String>>(5)?;
        Ok(json!({
            "id": row.get::<_, i32>(0)?,
            "name": row.get::<_, String>(1)?,
            "host": row.get::<_, String>(2)?,
            "port": row.get::<_, i32>(3)?,
            "username": row.get::<_, Option<String>>(4)?.unwrap_or_default(),
            "has_password": pw.as_deref().map(|s| !s.is_empty()).unwrap_or(false),
            "credential_id": row.get::<_, Option<i32>>(6)?,
            "folder_id": row.get::<_, Option<i32>>(7)?,
            "proxy_type": row.get::<_, Option<String>>(8)?.unwrap_or_else(|| "none".to_string()),
            "proxy_host": row.get::<_, Option<String>>(9)?.unwrap_or_default(),
            "proxy_port": row.get::<_, Option<i32>>(10)?.unwrap_or(1080),
            "tunnels": row.get::<_, Option<String>>(11)?.unwrap_or_else(|| "[]".to_string()),
            "auth_type": row.get::<_, Option<String>>(12)?.unwrap_or_else(|| "vault".to_string()),
            "key_id": row.get::<_, Option<i32>>(13)?,
            "autostart": row.get::<_, i32>(14).unwrap_or(0) != 0,
            "mirrors": row.get::<_, Option<String>>(15)?.unwrap_or_else(|| "[]".to_string()),
            "color": row.get::<_, Option<String>>(16)?,
            "notes": row.get::<_, Option<String>>(17)?.unwrap_or_default(),
            "run_on_connect": row.get::<_, Option<String>>(18)?.unwrap_or_default(),
            "jump_host_id": row.get::<_, Option<i32>>(19)?,
            // Attribution: HLC stamp (encodes last-edit time) + who last edited.
            "updated_at": row.get::<_, Option<String>>(20)?,
            "edited_by": row.get::<_, Option<String>>(21)?,
            // Manual drag-to-reorder rank (see ORDER BY above).
            "position": row.get::<_, i64>(22).unwrap_or(0),
            // The sync id: the same on every device, and unlike `id` never
            // reused by another profile's server. Keys this device's own
            // per-server settings (see src/util/shellSync.ts).
            "uuid": row.get::<_, Option<String>>(23)?,
        }))
    }).map_err(|e| format!("[DATABASE] QUERY_MAPPING_FAILED: {}", e))?;

    // What this device holds back for each server until the user allows it:
    // a change someone else made in a shared profile (see approvals.rs).
    // Empty for every server of a personal profile.
    let mut held = approvals::held_by_server(conn);
    let mut list = Vec::new();
    for r in rows {
        let mut row = r.map_err(|e| format!("[DATABASE] ROW_FETCH_FAILED: {}", e))?;
        let items = row
            .get("uuid")
            .and_then(|u| u.as_str())
            .and_then(|u| held.remove(u))
            .unwrap_or_default();
        row["held"] = json!(items);
        list.push(row);
    }
    Ok(list)
}

/// Allow what this device held back for one server (see approvals.rs): the
/// given items, or all of its items when `items` is empty. A monitor already
/// polling that server picks up allowed commands at once, and allowed
/// forwards are no longer stopped in the server's session, so the next
/// connect starts them (as does the Start button now). Autostart counts from
/// the next unlock; the frontend types allowed on-connect commands itself.
#[tauri::command]
async fn allow_held(
    db_state: tauri::State<'_, DbState>,
    ssh: tauri::State<'_, SshState>,
    map: tauri::State<'_, MonitorMap>,
    server_id: i32,
    items: Vec<String>,
) -> Result<usize, String> {
    let (allowed, customs) = {
        let guard = db_state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
        let conn = guard.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;
        let uuid = approvals::server_uuid(conn, server_id as i64).ok_or("[SYNC] NO_SUCH_SERVER")?;
        let held = approvals::held_for(conn, &uuid);
        let allowed: Vec<String> = if items.is_empty() {
            held.into_iter().collect()
        } else {
            items.into_iter().filter(|i| held.contains(i)).collect()
        };
        if allowed.is_empty() {
            return Ok(0);
        }
        approvals::allow(conn, &uuid, &allowed)?;
        let customs = if allowed.iter().any(|i| i.starts_with("metric:")) {
            load_monitor_config(conn, server_id)
                .map(|(_, customs, _)| approvals::without_held_metrics(conn, Some(&uuid), customs))
        } else {
            None
        };
        (allowed, customs)
    };
    if let Some(customs) = customs {
        // Only a running poller takes the list; a stopped one reads it from
        // the database when it starts.
        let _ = monitor::set_custom_metrics(map.inner().clone(), server_id, customs).await;
    }
    if allowed.iter().any(|i| i.starts_with("tunnel:")) {
        let mut rules_by_session = ssh.session_tunnel_specs.lock().await;
        if let Some(rules) = rules_by_session.get_mut(&format!("session-{server_id}")) {
            for rule in rules.iter_mut().filter(|r| allowed.contains(&approvals::tunnel_item(r))) {
                rule.stopped = false;
            }
        }
    }
    save_vault_internal(&db_state)?;
    Ok(allowed.len())
}

#[tauri::command]
async fn get_ssh_keys(state: tauri::State<'_, DbState>) -> Result<Vec<serde_json::Value>, String> {
    let conn_guard = state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
    let conn = conn_guard.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;
    // Private key + passphrase do NOT cross IPC in the listing — only the
    // public key (which is safe by definition) and presence flags. The edit
    // sheet calls `reveal_ssh_key` when it needs the secrets to display.
    let mut stmt = conn.prepare("SELECT id, name, public_key, private_key, passphrase FROM ssh_keys").map_err(|e| e.to_string())?;
    let rows = stmt.query_map([], |row| {
        let priv_present: Option<String> = row.get::<_, Option<String>>(3)?;
        let pp_present: Option<String> = row.get::<_, Option<String>>(4)?;
        Ok(json!({
            "id": row.get::<_, i32>(0)?,
            "name": row.get::<_, String>(1)?,
            "public_key": row.get::<_, String>(2)?,
            "has_private_key": priv_present.as_deref().map(|s| !s.is_empty()).unwrap_or(false),
            "has_passphrase": pp_present.as_deref().map(|s| !s.is_empty()).unwrap_or(false),
        }))
    }).map_err(|e| e.to_string())?;
    
    let mut list = Vec::new();
    for r in rows {
        list.push(r.map_err(|e| format!("[DATABASE] ROW_FETCH_FAILED: {}", e))?);
    }
    Ok(list)
}

#[tauri::command]
async fn get_credentials(state: tauri::State<'_, DbState>) -> Result<Vec<serde_json::Value>, String> {
    let conn_guard = state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
    let conn = conn_guard.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;
    // Same pattern as get_servers / get_ssh_keys: only `has_password` is
    // listed. The credential edit panel reveals on open via the dedicated
    // command.
    let mut stmt = conn.prepare("SELECT id, name, auth_type, username, password, key_id FROM credentials").map_err(|e| e.to_string())?;
    let rows = stmt.query_map([], |row| {
        let pw: Option<String> = row.get::<_, Option<String>>(4)?;
        Ok(json!({
            "id": row.get::<_, i32>(0)?,
            "name": row.get::<_, String>(1)?,
            "auth_type": row.get::<_, String>(2)?,
            "username": row.get::<_, String>(3)?,
            "has_password": pw.as_deref().map(|s| !s.is_empty()).unwrap_or(false),
            "key_id": row.get::<_, Option<i32>>(5)?
        }))
    }).map_err(|e| e.to_string())?;
    
    let mut list = Vec::new();
    for r in rows {
        list.push(r.map_err(|e| format!("[DATABASE] ROW_FETCH_FAILED: {}", e))?);
    }
    Ok(list)
}

#[tauri::command]
async fn add_credential(state: tauri::State<'_, DbState>, name: String, auth_type: String, username: String, password: Option<String>, key_id: Option<i32>) -> Result<(), String> {
    let conn_guard = state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
    let conn = conn_guard.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;
    
    conn.execute("INSERT INTO credentials (name, auth_type, username, password, key_id) VALUES (?1, ?2, ?3, ?4, ?5)", rusqlite::params![name, auth_type, username, password, key_id])
        .map_err(|e| format!("[DATABASE] CREDENTIAL_INSERT_FAILED: {}", e))?;
    
    drop(conn_guard);
    save_vault_internal(&state)?;
    Ok(())
}

#[tauri::command]
async fn edit_credential(state: tauri::State<'_, DbState>, id: i32, name: String, auth_type: String, username: String, password: Option<String>, key_id: Option<i32>) -> Result<(), String> {
    let conn_guard = state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
    let conn = conn_guard.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;
    
    conn.execute("UPDATE credentials SET name=?1, auth_type=?2, username=?3, password=?4, key_id=?5 WHERE id=?6", rusqlite::params![name, auth_type, username, password, key_id, id])
        .map_err(|e| format!("[DATABASE] CREDENTIAL_UPDATE_FAILED: {}", e))?;
    
    drop(conn_guard);
    save_vault_internal(&state)?;
    Ok(())
}

#[tauri::command]
async fn delete_credential(state: tauri::State<'_, DbState>, id: i32) -> Result<(), String> {
    let conn_guard = state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
    let conn = conn_guard.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;
    
    conn.execute("DELETE FROM credentials WHERE id=?1", rusqlite::params![id])
        .map_err(|e| format!("[DATABASE] CREDENTIAL_DELETE_FAILED: {}", e))?;
    
    drop(conn_guard);
    save_vault_internal(&state)?;
    Ok(())
}

#[tauri::command]
async fn add_folder(state: tauri::State<'_, DbState>, name: String, parent_id: Option<i32>) -> Result<(), String> {
    let conn_guard = state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
    let conn = conn_guard.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;
    
    conn.execute(
        "INSERT INTO folders (name, parent_id) VALUES (?1, ?2)",
        rusqlite::params![name, parent_id],
    ).map_err(|e| format!("[DATABASE] FOLDER_INSERT_FAILED: {}", e))?;
    
    drop(conn_guard);
    save_vault_internal(&state)?;
    Ok(())
}

#[tauri::command]
async fn rename_folder(state: tauri::State<'_, DbState>, id: i32, name: String) -> Result<(), String> {
    let trimmed = name.trim();
    if trimmed.is_empty() {
        return Err("[VALIDATION] FOLDER_NAME_EMPTY".into());
    }
    let conn_guard = state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
    let conn = conn_guard.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;
    let affected = conn.execute(
        "UPDATE folders SET name=?1 WHERE id=?2",
        rusqlite::params![trimmed, id],
    ).map_err(|e| format!("[DATABASE] FOLDER_RENAME_FAILED: {}", e))?;
    if affected == 0 {
        return Err(format!("[DATABASE] FOLDER_RENAME_FAILED: no folder with id {}", id));
    }
    drop(conn_guard);
    save_vault_internal(&state)?;
    Ok(())
}

#[tauri::command]
async fn delete_folder(
    state: tauri::State<'_, DbState>,
    map: tauri::State<'_, MonitorMap>,
    id: i32,
) -> Result<(), String> {
    // Same orphaned-poller problem as delete_server, one level up: this deletes
    // every server in the folder, so every one of their monitors has to be
    // stopped first. Collect the ids while the rows still exist.
    let doomed: Vec<i32> = {
        let conn_guard = state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
        let conn = conn_guard.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;
        let mut stmt = conn
            .prepare("SELECT id FROM servers WHERE folder_id=?1")
            .map_err(|e| format!("[DATABASE] FOLDER_SERVERS_QUERY_FAILED: {}", e))?;
        let rows = stmt
            .query_map(rusqlite::params![id], |r| r.get::<_, i32>(0))
            .map_err(|e| format!("[DATABASE] FOLDER_SERVERS_QUERY_FAILED: {}", e))?;
        rows.filter_map(|r| r.ok()).collect()
    };
    for node_id in doomed {
        monitor::stop_monitor(map.inner().clone(), node_id).await;
    }

    let conn_guard = state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
    let conn = conn_guard.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;

    // First, delete all servers in this folder
    conn.execute("DELETE FROM servers WHERE folder_id=?1", rusqlite::params![id])
        .map_err(|e| format!("[DATABASE] FOLDER_SERVERS_DELETE_FAILED: {}", e))?;

    // Then delete the folder
    conn.execute("DELETE FROM folders WHERE id=?1", rusqlite::params![id])
        .map_err(|e| format!("[DATABASE] FOLDER_DELETE_FAILED: {}", e))?;

    drop(conn_guard);
    save_vault_internal(&state)?;
    Ok(())
}

#[tauri::command]
async fn get_folders(state: tauri::State<'_, DbState>) -> Result<Vec<serde_json::Value>, String> {
    let conn_guard = state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
    let conn = conn_guard.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;
    let mut stmt = conn.prepare("SELECT id, name, parent_id, color FROM folders").map_err(|e| e.to_string())?;

    let rows = stmt.query_map([], |row| {
        Ok(json!({
            "id": row.get::<_, i32>(0)?,
            "name": row.get::<_, String>(1)?,
            "parent_id": row.get::<_, Option<i32>>(2)?,
            "color": row.get::<_, Option<String>>(3)?,
        }))
    }).map_err(|e| e.to_string())?;
    
    let mut list = Vec::new();
    for r in rows {
        list.push(r.map_err(|e| format!("[DATABASE] ROW_FETCH_FAILED: {}", e))?);
    }
    Ok(list)
}

#[tauri::command]
async fn add_command(state: tauri::State<'_, DbState>, title: String, content: String) -> Result<(), String> {
    let conn_guard = state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
    let conn = conn_guard.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;
    
    conn.execute(
        "INSERT INTO commands (title, content) VALUES (?1, ?2)",
        rusqlite::params![title, content],
    ).map_err(|e| format!("[DATABASE] COMMAND_INSERT_FAILED: {}", e))?;
    
    drop(conn_guard);
    save_vault_internal(&state)?;
    Ok(())
}

#[tauri::command]
async fn edit_command(state: tauri::State<'_, DbState>, id: i32, title: String, content: String) -> Result<(), String> {
    let conn_guard = state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
    let conn = conn_guard.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;
    
    conn.execute(
        "UPDATE commands SET title=?1, content=?2 WHERE id=?3",
        rusqlite::params![title, content, id],
    ).map_err(|e| format!("[DATABASE] COMMAND_UPDATE_FAILED: {}", e))?;
    
    drop(conn_guard);
    save_vault_internal(&state)?;
    Ok(())
}

#[tauri::command]
async fn delete_command(state: tauri::State<'_, DbState>, id: i32) -> Result<(), String> {
    let conn_guard = state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
    let conn = conn_guard.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;
    
    conn.execute(
        "DELETE FROM commands WHERE id=?1",
        rusqlite::params![id],
    ).map_err(|e| format!("[DATABASE] COMMAND_DELETE_FAILED: {}", e))?;
    
    drop(conn_guard);
    save_vault_internal(&state)?;
    Ok(())
}

#[tauri::command]
async fn get_commands(state: tauri::State<'_, DbState>) -> Result<Vec<serde_json::Value>, String> {
    let conn_guard = state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
    let conn = conn_guard.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;
    let mut stmt = conn.prepare("SELECT id, title, content FROM commands").map_err(|e| e.to_string())?;
    
    let rows = stmt.query_map([], |row| {
        Ok(json!({
            "id": row.get::<_, i32>(0)?, 
            "title": row.get::<_, String>(1)?, 
            "content": row.get::<_, String>(2)?
        }))
    }).map_err(|e| e.to_string())?;
    
    let mut list = Vec::new();
    for r in rows {
        list.push(r.map_err(|e| format!("[DATABASE] ROW_FETCH_FAILED: {}", e))?);
    }
    Ok(list)
}

// ───────────────────────── Command History ─────────────────────────
// Ctrl+R-style rolling log of commands the user typed into any terminal.
// Populated best-effort by TerminalView (buffered keystrokes → Enter →
// insert). Read by HistorySearchOverlay through the three commands below.
// Capped at 1000 rows — dropping the oldest — so a chatty user can't blow
// the vault size up over months of use.

const CMD_HISTORY_CAP: i64 = 1000;

#[tauri::command]
async fn cmd_history_add(
    state: tauri::State<'_, DbState>,
    server_id: Option<i32>,
    server_name: String,
    command: String,
) -> Result<i64, String> {
    let trimmed = command.trim().to_string();
    if trimmed.is_empty() {
        return Err("[HISTORY] EMPTY_COMMAND".into());
    }
    let ts: i64 = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_millis() as i64)
        .unwrap_or(0);

    let conn_guard = state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
    let conn = conn_guard.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;

    // De-dupe against the immediately-previous row for the same server so a
    // user re-running `ls` five times in a row doesn't fill five slots. Match
    // by (server_id, command); leave older reruns alone so search still finds
    // "ran this yesterday morning too".
    let last: Option<(i64, String, Option<i32>)> = conn.query_row(
        "SELECT id, command, server_id FROM cmd_history ORDER BY ts DESC LIMIT 1",
        [],
        |row| Ok((row.get::<_, i64>(0)?, row.get::<_, String>(1)?, row.get::<_, Option<i32>>(2)?)),
    ).ok();
    if let Some((id, prev_cmd, prev_sid)) = last {
        if prev_cmd == trimmed && prev_sid == server_id {
            // Refresh the timestamp on the existing row instead of writing a
            // duplicate — keeps the "most recent first" ordering honest.
            let _ = conn.execute(
                "UPDATE cmd_history SET ts = ?1 WHERE id = ?2",
                rusqlite::params![ts, id],
            );
            return Ok(id);
        }
    }

    conn.execute(
        "INSERT INTO cmd_history (server_id, server_name, command, ts) VALUES (?1, ?2, ?3, ?4)",
        rusqlite::params![server_id, server_name, trimmed, ts],
    ).map_err(|e| format!("[DATABASE] CMD_HISTORY_INSERT_FAILED: {}", e))?;

    let new_id = conn.last_insert_rowid();

    // Prune the tail so the table stays bounded. LIMIT/OFFSET in a subquery
    // gives us "keep the newest N, drop everything older".
    let _ = conn.execute(
        "DELETE FROM cmd_history WHERE id IN (
            SELECT id FROM cmd_history ORDER BY ts DESC LIMIT -1 OFFSET ?1
        )",
        rusqlite::params![CMD_HISTORY_CAP],
    );

    // History isn't secret but the encrypted vault is the only place it can
    // land; we DO NOT call save_vault_internal on every keystroke — that'd
    // fsync per command and thrash disk. The next save_vault_* call (any
    // node edit, key add, etc., or profile-close teardown) picks it up.
    Ok(new_id)
}

#[tauri::command]
async fn cmd_history_list(
    state: tauri::State<'_, DbState>,
    query: Option<String>,
    limit: Option<u32>,
) -> Result<Vec<serde_json::Value>, String> {
    let conn_guard = state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
    let conn = conn_guard.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;

    let lim = limit.unwrap_or(200).min(1000) as i64;
    let q = query.unwrap_or_default();
    let q_trimmed = q.trim();

    let rows: Vec<serde_json::Value> = if q_trimmed.is_empty() {
        let mut stmt = conn.prepare(
            "SELECT id, server_id, server_name, command, ts, exit_code
             FROM cmd_history
             ORDER BY ts DESC LIMIT ?1"
        ).map_err(|e| format!("[DATABASE] CMD_HISTORY_PREP_FAILED: {}", e))?;
        let mapped = stmt.query_map(rusqlite::params![lim], |row| {
            Ok(json!({
                "id": row.get::<_, i64>(0)?,
                "server_id": row.get::<_, Option<i32>>(1)?,
                "server_name": row.get::<_, Option<String>>(2)?,
                "command": row.get::<_, String>(3)?,
                "ts": row.get::<_, i64>(4)?,
                "exit_code": row.get::<_, Option<i32>>(5)?,
            }))
        }).map_err(|e| format!("[DATABASE] CMD_HISTORY_QUERY_FAILED: {}", e))?;
        let mut out = Vec::new();
        for r in mapped {
            out.push(r.map_err(|e| format!("[DATABASE] CMD_HISTORY_ROW_FAILED: {}", e))?);
        }
        out
    } else {
        // Escape LIKE metacharacters (%, _, backslash) so the user's raw
        // input matches literally. Uses `\` as the escape character.
        let escaped = q_trimmed
            .replace('\\', "\\\\")
            .replace('%', "\\%")
            .replace('_', "\\_");
        let like = format!("%{}%", escaped);
        let mut stmt = conn.prepare(
            "SELECT id, server_id, server_name, command, ts, exit_code
             FROM cmd_history
             WHERE command LIKE ?1 ESCAPE '\\'
             ORDER BY ts DESC LIMIT ?2"
        ).map_err(|e| format!("[DATABASE] CMD_HISTORY_PREP_FAILED: {}", e))?;
        let mapped = stmt.query_map(rusqlite::params![like, lim], |row| {
            Ok(json!({
                "id": row.get::<_, i64>(0)?,
                "server_id": row.get::<_, Option<i32>>(1)?,
                "server_name": row.get::<_, Option<String>>(2)?,
                "command": row.get::<_, String>(3)?,
                "ts": row.get::<_, i64>(4)?,
                "exit_code": row.get::<_, Option<i32>>(5)?,
            }))
        }).map_err(|e| format!("[DATABASE] CMD_HISTORY_QUERY_FAILED: {}", e))?;
        let mut out = Vec::new();
        for r in mapped {
            out.push(r.map_err(|e| format!("[DATABASE] CMD_HISTORY_ROW_FAILED: {}", e))?);
        }
        out
    };
    Ok(rows)
}

#[tauri::command]
async fn cmd_history_clear(state: tauri::State<'_, DbState>) -> Result<(), String> {
    let conn_guard = state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
    let conn = conn_guard.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;
    conn.execute("DELETE FROM cmd_history", [])
        .map_err(|e| format!("[DATABASE] CMD_HISTORY_CLEAR_FAILED: {}", e))?;
    drop(conn_guard);
    save_vault_internal(&state)?;
    Ok(())
}

// ───────────────────────── Notes ─────────────────────────
// Free-form text notes stored alongside the rest of the profile. Mirrors the
// commands CRUD shape exactly — title + body, no FK, no timestamps. Search
// is done client-side over the returned list so the user can match against
// title and body in one go without us pushing a LIKE query through SQLite.

#[tauri::command]
async fn add_note(state: tauri::State<'_, DbState>, title: String, body: String) -> Result<(), String> {
    let conn_guard = state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
    let conn = conn_guard.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;

    conn.execute(
        "INSERT INTO notes (title, body) VALUES (?1, ?2)",
        rusqlite::params![title, body],
    ).map_err(|e| format!("[DATABASE] NOTE_INSERT_FAILED: {}", e))?;

    drop(conn_guard);
    save_vault_internal(&state)?;
    Ok(())
}

#[tauri::command]
async fn edit_note(state: tauri::State<'_, DbState>, id: i32, title: String, body: String) -> Result<(), String> {
    let conn_guard = state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
    let conn = conn_guard.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;

    conn.execute(
        "UPDATE notes SET title=?1, body=?2 WHERE id=?3",
        rusqlite::params![title, body, id],
    ).map_err(|e| format!("[DATABASE] NOTE_UPDATE_FAILED: {}", e))?;

    drop(conn_guard);
    save_vault_internal(&state)?;
    Ok(())
}

#[tauri::command]
async fn delete_note(state: tauri::State<'_, DbState>, id: i32) -> Result<(), String> {
    let conn_guard = state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
    let conn = conn_guard.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;

    conn.execute(
        "DELETE FROM notes WHERE id=?1",
        rusqlite::params![id],
    ).map_err(|e| format!("[DATABASE] NOTE_DELETE_FAILED: {}", e))?;

    drop(conn_guard);
    save_vault_internal(&state)?;
    Ok(())
}

#[tauri::command]
async fn get_notes(state: tauri::State<'_, DbState>) -> Result<Vec<serde_json::Value>, String> {
    let conn_guard = state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
    let conn = conn_guard.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;
    // Newest first — matches how users think about notes (last-touched up top).
    let mut stmt = conn.prepare("SELECT id, title, body FROM notes ORDER BY id DESC").map_err(|e| e.to_string())?;

    let rows = stmt.query_map([], |row| {
        Ok(json!({
            "id": row.get::<_, i32>(0)?,
            "title": row.get::<_, String>(1)?,
            "body": row.get::<_, String>(2)?
        }))
    }).map_err(|e| e.to_string())?;

    let mut list = Vec::new();
    for r in rows {
        list.push(r.map_err(|e| format!("[DATABASE] ROW_FETCH_FAILED: {}", e))?);
    }
    Ok(list)
}

/// One-shot inline auth bundle for "quick connect" — connecting to a host
/// without saving anything in the vault. Mirrors the subset of node fields
/// that the connection flow actually needs: address, identity, and either
/// a password or a PEM key body. Proxy + tunnel auto-start are deliberately
/// omitted; the user can save a real node if they need those.
#[derive(Debug, Clone, serde::Deserialize)]
struct QuickAuth {
    host: String,
    port: i32,
    username: String,
    #[serde(default)]
    password: Option<String>,
    #[serde(default)]
    private_key: Option<String>,
    #[serde(default)]
    passphrase: Option<String>,
}

/// Largest number of connect-time secret prompts (a missing password or key
/// passphrase) shown before giving up on an auth method, per issue #30.
const MAX_SECRET_PROMPTS: u32 = 3;

/// Which field of the per-tab `ssh_manager::PromptedSecrets` cache a prompting
/// auth call reads and writes.
#[derive(Clone, Copy)]
enum SecretSlot {
    Password,
    Passphrase,
    JumpPassword,
    JumpPassphrase,
    Username,
    JumpUsername,
}

/// The tab a connection belongs to. A dedicated `::sftp` / `::fwd` secondary
/// shares its parent tab's prompted-secret cache, so the suffix is stripped to
/// key the cache by the base session id. A plain primary id is returned as-is.
fn base_session_id(session_id: &str) -> &str {
    session_id
        .strip_suffix("::sftp")
        .or_else(|| session_id.strip_suffix("::fwd"))
        .unwrap_or(session_id)
}

/// Why turning a stored private key into a usable keypair failed, split so the
/// connect path can tell a key that merely needs a passphrase we don't have
/// (worth asking the user for) from one that is broken regardless (no prompt
/// will fix it).
pub(crate) enum KeyDecodeError {
    /// Encrypted key whose supplied passphrase was missing, empty or wrong.
    NeedsPassphrase,
    /// Unparseable or unsupported key — the wrapped string is a human message.
    Malformed(String),
}

/// Decode `private_key` with `passphrase`, classifying any failure. `\r\n` is
/// normalised first (keys pasted on Windows) and an empty passphrase is treated
/// as none. "Is the key encrypted?" is answered from the key itself (the
/// OpenSSH header's `is_encrypted()`, a legacy `Proc-Type: 4,ENCRYPTED` PEM, or
/// an encrypted PKCS#8 one) — the same checks `load_key_from_disk` uses — so a
/// wrong passphrase is reported as `NeedsPassphrase` rather than `Malformed`.
/// The most bcrypt rounds an OpenSSH private key may ask for. `ssh-keygen`
/// defaults to 16 and never writes more than a few hundred even when told to;
/// 1024 leaves generous headroom while keeping a decode bounded to a fraction
/// of a second, so a key can't make decoding hang.
const MAX_KEY_KDF_ROUNDS: u32 = 1024;

/// Refuse an OpenSSH private key whose bcrypt KDF asks for more rounds than a
/// real key ever would, before the expensive derivation runs. The round count
/// is in the key's cleartext envelope, read here without the passphrase. Keys
/// in other formats (PEM, PKCS#8) parse past this untouched — their cost is
/// bounded elsewhere.
fn guard_key_kdf_cost(pem: &str) -> Result<(), KeyDecodeError> {
    if let Ok(key) = ssh_key::PrivateKey::from_openssh(pem.trim()) {
        if let ssh_key::Kdf::Bcrypt { rounds, .. } = key.kdf() {
            if *rounds > MAX_KEY_KDF_ROUNDS {
                return Err(KeyDecodeError::Malformed(format!(
                    "this key asks for {rounds} key-derivation rounds — far more than a real key needs (limit {MAX_KEY_KDF_ROUNDS}); re-save it with `ssh-keygen -p -f <keyfile>`"
                )));
            }
        }
    }
    Ok(())
}

pub(crate) fn decode_private_key(
    private_key: &str,
    passphrase: Option<&str>,
) -> Result<russh::keys::PrivateKey, KeyDecodeError> {
    let normalized = private_key.replace("\r\n", "\n");
    // Refuse an absurd KDF cost BEFORE running it. An OpenSSH key names its
    // bcrypt round count in the clear, and decoding runs that many rounds; a
    // key synced by another member of a shared profile (or handed over by a
    // broken server) could set it to billions and pin a thread for ages on
    // every unlock. A real key uses tens of rounds — thousands is already far
    // past anything `ssh-keygen` makes.
    guard_key_kdf_cost(&normalized)?;
    let passphrase = passphrase.filter(|p| !p.is_empty());
    // russh decrypts the legacy PEM encryption only for RSA keys: an ECDSA key
    // encrypted that way decrypts and then fails the RSA decode whatever the
    // passphrase, so say so instead of asking for one three times.
    if is_legacy_encrypted_ec_pem(&normalized) {
        return Err(KeyDecodeError::Malformed(
            "this ECDSA key uses the legacy PEM encryption, which Submarine can only read for RSA keys; \
             re-save it in OpenSSH format with `ssh-keygen -p -f <keyfile>`"
                .into(),
        ));
    }
    // russh decrypts a legacy PKCS#1 PEM key encrypted the PKCS#5 way only with
    // AES-128-CBC. Another cipher — DES-EDE3 (PuTTYgen's OpenSSH export,
    // `openssl -des3`) or AES-256 — can't be read whatever the passphrase, so
    // say so instead of asking for one three times.
    if normalized.contains("Proc-Type: 4,ENCRYPTED") && !normalized.contains("DEK-Info: AES-128-CBC,") {
        return Err(KeyDecodeError::Malformed(
            "this key uses a legacy PEM encryption Submarine can't read (only AES-128-CBC); \
             re-save it in OpenSSH format with `ssh-keygen -p -f <keyfile>`"
                .into(),
        ));
    }
    // An unencrypted SEC1 / PKCS#8 key is read without the passphrase: russh's
    // PKCS#8 reader takes any passphrase it is handed to mean "this key is
    // encrypted" and fails, so one saved with such a key would break it.
    let header = pem_private_key_header(&normalized);
    let plain_pem = header == "-----BEGIN PRIVATE KEY-----" || header == "-----BEGIN EC PRIVATE KEY-----";
    let passphrase = if plain_pem { None } else { passphrase };
    match russh::keys::decode_secret_key(&normalized, passphrase) {
        Ok(key) => Ok(key),
        // The OpenSSH decoder reports this when an encrypted key is handed no
        // password at all.
        Err(russh::keys::Error::KeyIsEncrypted) => Err(KeyDecodeError::NeedsPassphrase),
        Err(e) => {
            // Decode failed with a passphrase in hand. If the key is an
            // encrypted one, the passphrase was wrong; otherwise it is a
            // genuinely unusable key. Encrypted means an OpenSSH key whose
            // header says so, a legacy PKCS#1 PEM key encrypted the PKCS#5 way
            // (`Proc-Type: 4,ENCRYPTED`, which russh decrypts) — a wrong
            // passphrase there fails deep in the RSA decode, not with
            // KeyIsEncrypted, so without this check a typo ended the attempt
            // as "failed to parse" instead of asking again — or an encrypted
            // PKCS#8 key, which fails the same way with no passphrase at all.
            if private_key_is_encrypted(&normalized) {
                Err(KeyDecodeError::NeedsPassphrase)
            } else {
                Err(KeyDecodeError::Malformed(e.to_string()))
            }
        }
    }
}

/// `&mut` accessor for one slot of a `PromptedSecrets`, so the cache get/set/
/// clear helpers don't each repeat the match.
fn prompted_secret_slot(
    secrets: &mut ssh_manager::PromptedSecrets,
    slot: SecretSlot,
) -> &mut Option<zeroize::Zeroizing<String>> {
    match slot {
        SecretSlot::Password => &mut secrets.password,
        SecretSlot::Passphrase => &mut secrets.passphrase,
        SecretSlot::JumpPassword => &mut secrets.jump_password,
        SecretSlot::JumpPassphrase => &mut secrets.jump_passphrase,
        SecretSlot::Username => &mut secrets.username,
        SecretSlot::JumpUsername => &mut secrets.jump_username,
    }
}

type PromptedSecretsMap =
    std::sync::Arc<tokio::sync::Mutex<std::collections::HashMap<String, ssh_manager::PromptedSecrets>>>;
type KbiTxs = std::sync::Arc<
    tokio::sync::Mutex<
        std::collections::HashMap<String, tokio::sync::oneshot::Sender<Option<Vec<String>>>>,
    >,
>;

/// A copy of one cached secret for `base`, or `None` when absent.
async fn cache_get_secret(
    cache: &PromptedSecretsMap,
    base: &str,
    slot: SecretSlot,
) -> Option<zeroize::Zeroizing<String>> {
    let mut map = cache.lock().await;
    map.get_mut(base).and_then(|s| prompted_secret_slot(s, slot).clone())
}

/// Remember an accepted secret for `base` so reconnects / secondaries reuse it.
async fn cache_store_secret(
    cache: &PromptedSecretsMap,
    base: &str,
    slot: SecretSlot,
    value: zeroize::Zeroizing<String>,
) {
    let mut map = cache.lock().await;
    let entry = map.entry(base.to_string()).or_default();
    *prompted_secret_slot(entry, slot) = Some(value);
}

/// Forget one cached secret for `base` (e.g. the server just rejected it).
async fn cache_clear_secret(cache: &PromptedSecretsMap, base: &str, slot: SecretSlot) {
    let mut map = cache.lock().await;
    if let Some(entry) = map.get_mut(base) {
        *prompted_secret_slot(entry, slot) = None;
    }
}

/// Where a connect-time secret came from, which decides what happens to it once
/// the server answers: a `Given` one (the saved value) is never cached; a
/// `Cache` one is stored again on success and dropped on rejection; a `Prompt`
/// one — or the failed-screen `Override` — is stored once accepted. Caching an
/// accepted override is what lets the screen forget it after a successful
/// connect, so a mistyped one isn't sent first on every later attempt.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum SecretSource {
    Given,
    Override,
    Cache,
    Prompt,
}

/// The secrets already in hand for one auth method, in the order they are
/// tried: the per-connect override (failed-screen box), then what the user
/// typed earlier this tab (cache), then the saved value. A cached value beats
/// the saved one: it only exists because the saved one was missing or rejected
/// earlier this tab. Empty values are dropped — an empty saved secret means
/// "ask when connecting".
fn secret_candidates(
    override_secret: Option<zeroize::Zeroizing<String>>,
    cached: Option<zeroize::Zeroizing<String>>,
    saved: Option<zeroize::Zeroizing<String>>,
) -> Vec<(zeroize::Zeroizing<String>, SecretSource)> {
    [
        (override_secret, SecretSource::Override),
        (cached, SecretSource::Cache),
        (saved, SecretSource::Given),
    ]
    .into_iter()
    .filter_map(|(secret, source)| secret.filter(|s| !s.is_empty()).map(|s| (s, source)))
    .collect()
}

/// Everything a connect-time secret prompt needs besides the SSH session: where
/// to show it (the keyboard-interactive modal of `session_id`, answered under
/// `nonce`) and where accepted secrets live (`cache`, under the tab's `base`
/// id). `allow_prompt` is false for the dedicated `::sftp` / `::fwd`
/// secondaries, which only ever reuse what the primary cached.
struct SecretPromptCtx<'a> {
    app: &'a tauri::AppHandle,
    session_id: &'a str,
    nonce: &'a str,
    kbi_txs: &'a KbiTxs,
    cache: &'a PromptedSecretsMap,
    base: &'a str,
    allow_prompt: bool,
    /// The connect attempt asking. A prompt is only shown while it's current
    /// (see ssh_manager::ConnectAttempt).
    attempt: &'a ssh_manager::ConnectAttempt,
    /// Set when the user cancels one of our prompts (or lets it time out).
    /// The caller then skips the keyboard-interactive fallback: on a typical
    /// OpenSSH + PAM server that fallback would immediately show the server's
    /// own "Password:" box, i.e. ask again for what the user just declined.
    /// Atomic because the context is borrowed across awaits in a spawned task.
    cancelled: std::sync::atomic::AtomicBool,
}

impl SecretPromptCtx<'_> {
    /// Activity-log line for this connection. Never given a secret. A
    /// superseded attempt stays out of the tab's log (it would read as the
    /// newer attempt's).
    fn log(&self, msg: &str, ty: &str) {
        use tauri::Emitter;
        println!("[LOG-{}] {}", self.session_id, msg);
        if !self.attempt.is_current_now() {
            return;
        }
        let _ = self.app.emit(
            &format!("session-log-{}", self.session_id),
            serde_json::json!({"msg": msg, "type": ty}),
        );
    }
}

/// Ask the user for ONE value at connect time — a password or key passphrase
/// (`echo` false: masked), or a login name (`echo` true) — reusing the
/// keyboard-interactive prompt channel + modal. Emits a single prompt under
/// `kbi-prompt-{session_id}`, waits on `kbi_txs` keyed by `nonce` (the same
/// 120s budget as a real 2FA prompt), dismisses the modal, and returns the
/// typed value (zeroised) or `None` on cancel / timeout / dropped channel. The
/// value is never logged or persisted.
async fn prompt_for_secret(
    ctx: &SecretPromptCtx<'_>,
    label: &str,
    instructions: &str,
    echo: bool,
) -> Option<zeroize::Zeroizing<String>> {
    use tauri::Emitter;
    // Superseded or abandoned attempt: never show its prompt over a newer
    // one. It ends the same way a cancelled prompt does.
    if !ctx.attempt.may_prompt().await {
        ctx.cancelled.store(true, std::sync::atomic::Ordering::Relaxed);
        return None;
    }
    let (tx, rx) = tokio::sync::oneshot::channel::<Option<Vec<String>>>();
    ctx.kbi_txs.lock().await.insert(ctx.nonce.to_string(), tx);
    let _ = ctx.app.emit(
        &format!("kbi-prompt-{}", ctx.session_id),
        serde_json::json!({
            "nonce": ctx.nonce,
            // Blank name keeps the modal's generic heading; the label carries
            // the meaning. Instructions only explain a retry.
            "name": "",
            "instructions": instructions,
            "prompts": [{ "prompt": label, "echo": echo }],
        }),
    );
    let answer = match tokio::time::timeout(std::time::Duration::from_secs(120), rx).await {
        Ok(Ok(Some(mut answers))) => {
            // One prompt → one answer; ignore extras, treat a missing one as "".
            let first = if answers.is_empty() { String::new() } else { answers.swap_remove(0) };
            Some(zeroize::Zeroizing::new(first))
        }
        // Cancelled (None), timed out, or the sender was dropped.
        _ => {
            ctx.cancelled.store(true, std::sync::atomic::Ordering::Relaxed);
            None
        }
    };
    ctx.kbi_txs.lock().await.remove(ctx.nonce);
    // The nonce lets the tab ignore this if a newer prompt is already showing.
    let _ = ctx.app.emit(
        &format!("kbi-prompt-dismiss-{}", ctx.session_id),
        serde_json::json!({ "nonce": ctx.nonce }),
    );
    answer
}

/// The login name for a typed "Login as" answer: trimmed, and empty means
/// `root` — the long-standing default for a node saved without a username, so
/// pressing Enter logs in exactly as before.
fn login_user_from_answer(answer: &str) -> zeroize::Zeroizing<String> {
    let name = answer.trim();
    zeroize::Zeroizing::new(if name.is_empty() { "root".to_string() } else { name.to_string() })
}

/// The login name for a connection whose saved username may be blank (issue
/// #54). A saved name is used as-is. A blank one is taken from what the user
/// typed earlier in this tab, else asked for — "Login as", visible like
/// PuTTY's — on a primary connection. A dedicated `::sftp` / `::fwd`
/// connection never asks; with nothing cached it keeps the old `root` default.
///
/// Returns the name and whether it was typed just now (the caller caches a
/// typed name only once the login succeeds), or `None` when the prompt was
/// cancelled or timed out (`ctx.cancelled` is then set, so the attempt ends as
/// "Login cancelled"). The name is held in `Zeroizing` memory throughout.
async fn resolve_login_user(
    saved: &str,
    host: &str,
    slot: SecretSlot,
    ctx: &SecretPromptCtx<'_>,
) -> Option<(zeroize::Zeroizing<String>, bool)> {
    let saved = saved.trim();
    if !saved.is_empty() {
        return Some((zeroize::Zeroizing::new(saved.to_string()), false));
    }
    if let Some(cached) = cache_get_secret(ctx.cache, ctx.base, slot).await.filter(|u| !u.is_empty()) {
        return Some((cached, false));
    }
    if !ctx.allow_prompt {
        return Some((zeroize::Zeroizing::new("root".to_string()), false));
    }
    ctx.log("No saved username — asking for it.", "info");
    let typed = prompt_for_secret(
        ctx,
        &format!("Login as (on {})", host),
        "Leave it empty to log in as root.",
        true,
    )
    .await;
    match typed {
        Some(answer) => Some((login_user_from_answer(&answer), true)),
        None => {
            ctx.log("Username prompt cancelled or timed out.", "error");
            None
        }
    }
}

/// Password authentication for a login whose password may not be saved (issue
/// #30). Tries the passwords already in hand (`secret_candidates`), then — on a
/// primary connection, while the server still offers password auth — asks the
/// user, re-asking on rejection for up to `MAX_SECRET_PROMPTS` prompts. A typed
/// or cached password that is accepted is kept in the tab's cache under `slot`;
/// a cached one that is rejected is dropped.
///
/// With nothing in hand, a `none` probe first checks that the server offers
/// password auth at all, so a keyboard-interactive-only (2FA) server shows no
/// password box. `Ok(false)` — password not offered, prompt cancelled or timed
/// out, or prompts used up — leaves the caller's keyboard-interactive fallback
/// to run exactly as before.
async fn authenticate_password_prompting<H: russh::client::Handler>(
    session: &mut russh::client::Handle<H>,
    user: &str,
    host: &str,
    override_password: Option<zeroize::Zeroizing<String>>,
    saved_password: Option<zeroize::Zeroizing<String>>,
    slot: SecretSlot,
    ctx: &SecretPromptCtx<'_>,
) -> Result<bool, russh::Error> {
    let cached = cache_get_secret(ctx.cache, ctx.base, slot).await;
    let candidates = secret_candidates(override_password, cached, saved_password);
    let nothing_in_hand = candidates.is_empty();
    let mut candidates = candidates.into_iter();
    let mut password_offered = true;
    let mut rejected = false;
    let mut prompts_used: u32 = 0;

    if nothing_in_hand {
        if !ctx.allow_prompt {
            return Ok(false);
        }
        match session.authenticate_none(user).await? {
            russh::client::AuthResult::Success => return Ok(true),
            // russh also reports a dropped connection as a Failure (with no
            // methods left): that's a transport error, not "no passwords".
            russh::client::AuthResult::Failure { .. } if session.is_closed() => {
                return Err(russh::Error::Disconnect);
            }
            russh::client::AuthResult::Failure { remaining_methods, .. } => {
                password_offered = remaining_methods.contains(&russh::MethodKind::Password);
            }
        }
    }

    loop {
        let (password, source) = match candidates.next() {
            Some(candidate) => candidate,
            None => {
                if !ctx.allow_prompt || !password_offered || prompts_used >= MAX_SECRET_PROMPTS {
                    return Ok(false);
                }
                if prompts_used == 0 {
                    ctx.log(
                        if rejected { "Password rejected — asking for it." } else { "No saved password — asking for it." },
                        "info",
                    );
                }
                let instructions = if rejected { "The password was rejected. Please try again." } else { "" };
                match prompt_for_secret(ctx, &format!("Password for {}@{}", user, host), instructions, false).await {
                    Some(typed) => {
                        prompts_used += 1;
                        (typed, SecretSource::Prompt)
                    }
                    None => {
                        ctx.log("Password prompt cancelled or timed out.", "error");
                        return Ok(false);
                    }
                }
            }
        };
        match session.authenticate_password(user, password.as_str()).await? {
            russh::client::AuthResult::Success => {
                if source != SecretSource::Given {
                    cache_store_secret(ctx.cache, ctx.base, slot, password).await;
                }
                return Ok(true);
            }
            // The connection dropped while the password was in flight — russh
            // reports that as a Failure too. Not a rejection: keep the cached
            // password and let the caller treat it as a transport error.
            russh::client::AuthResult::Failure { .. } if session.is_closed() => {
                return Err(russh::Error::Disconnect);
            }
            russh::client::AuthResult::Failure { remaining_methods, partial_success } => {
                if partial_success {
                    // Password accepted, but the server wants another factor
                    // (keyboard-interactive): keep it for reconnects and let the
                    // caller's 2FA fallback finish the login.
                    if source != SecretSource::Given {
                        cache_store_secret(ctx.cache, ctx.base, slot, password).await;
                    }
                    return Ok(false);
                }
                if source == SecretSource::Cache {
                    cache_clear_secret(ctx.cache, ctx.base, slot).await;
                }
                password_offered = remaining_methods.contains(&russh::MethodKind::Password);
                rejected = true;
            }
        }
    }
}

/// Private-key authentication for a key whose passphrase may not be saved
/// (issue #30). Decodes with the passphrases already in hand
/// (`secret_candidates`) — or with none, when there are none, since a plain
/// key needs none — then, on a primary connection, asks the user, re-asking
/// for up to `MAX_SECRET_PROMPTS` prompts while the passphrase doesn't decrypt
/// the key. Decrypting the key is the acceptance: a typed or cached passphrase
/// that does is kept in the tab's cache under `slot`; a cached one that
/// doesn't is dropped.
///
/// Without a usable passphrase (prompt cancelled or timed out, prompts used up,
/// or prompting not allowed) it returns `keys::Error::KeyIsEncrypted`, which
/// `classify_russh_error` buckets as an auth failure — so an auto-reconnect
/// stops instead of looping straight back into the prompt. A malformed or
/// unsupported key keeps the error shape the old inline decode produced. Either
/// way the caller's keyboard-interactive fallback still runs.
async fn authenticate_key_prompting<H: russh::client::Handler>(
    session: &mut russh::client::Handle<H>,
    user: &str,
    private_key: &str,
    key_label: &str,
    saved_passphrase: Option<zeroize::Zeroizing<String>>,
    slot: SecretSlot,
    ctx: &SecretPromptCtx<'_>,
) -> Result<bool, russh::Error> {
    let cached = cache_get_secret(ctx.cache, ctx.base, slot).await;
    let mut candidates = secret_candidates(None, cached, saved_passphrase).into_iter();
    let mut attempt = candidates.next();
    let mut rejected = false;
    let mut prompts_used: u32 = 0;

    loop {
        match decode_private_key(private_key, attempt.as_ref().map(|(p, _)| p.as_str())) {
            Ok(keypair) => {
                if let Some((passphrase, source)) = attempt {
                    if source != SecretSource::Given {
                        cache_store_secret(ctx.cache, ctx.base, slot, passphrase).await;
                    }
                }
                return ssh_manager::authenticate_with_key(session, user, keypair).await;
            }
            Err(KeyDecodeError::NeedsPassphrase) => {
                if let Some((_, source)) = &attempt {
                    if *source == SecretSource::Cache {
                        cache_clear_secret(ctx.cache, ctx.base, slot).await;
                    }
                    rejected = true;
                }
                if let Some(next) = candidates.next() {
                    attempt = Some(next);
                    continue;
                }
                if !ctx.allow_prompt || prompts_used >= MAX_SECRET_PROMPTS {
                    ctx.log("Key is passphrase-protected and no correct passphrase was supplied.", "error");
                    return Err(russh::Error::from(russh::keys::Error::KeyIsEncrypted));
                }
                if prompts_used == 0 {
                    ctx.log(
                        if rejected {
                            "Passphrase didn't unlock the key — asking for it."
                        } else {
                            "Key is passphrase-protected — asking for the passphrase."
                        },
                        "info",
                    );
                }
                let instructions = if rejected { "The passphrase didn't unlock the key. Please try again." } else { "" };
                match prompt_for_secret(ctx, &format!("Passphrase for key '{}'", key_label), instructions, false).await {
                    Some(typed) => {
                        prompts_used += 1;
                        attempt = Some((typed, SecretSource::Prompt));
                    }
                    None => {
                        ctx.log("Passphrase prompt cancelled or timed out.", "error");
                        return Err(russh::Error::from(russh::keys::Error::KeyIsEncrypted));
                    }
                }
            }
            Err(KeyDecodeError::Malformed(msg)) => {
                ctx.log(&format!("Failed to parse private key: {}", msg), "error");
                return Err(russh::Error::from(std::io::Error::new(
                    std::io::ErrorKind::InvalidData,
                    msg,
                )));
            }
        }
    }
}

#[cfg(test)]
mod key_format_tests {
    use super::*;

    // Throwaway ECDSA P-521 key (`openssl ecparam -name secp521r1 -genkey
    // -noout`) in SEC1 PEM; the same key as PKCS#8 (`openssl pkcs8 -topk8
    // -nocrypt`), as PKCS#8 encrypted with P521_PKCS8_PASSPHRASE (`-v2
    // aes-256-cbc`) and as SEC1 under the legacy PEM encryption (`openssl ec
    // -aes128`). P521_PUBLIC is its public half from `ssh-keygen -y`.
    const P521_SEC1: &str = concat!(
        "-----BEGIN EC PRIVATE KEY-----", "\n",
        "MIHcAgEBBEIAdufERUG0oeJ10N+Bv+X90N7yFqYVBx/b1zxWDFy7IenBbH3m19ZI", "\n",
        "eS7CX304BsDAg7qsfA297eVCJbgAs2PHHMqgBwYFK4EEACOhgYkDgYYABAFcBODy", "\n",
        "J0wHcbjtkyXarPWtaIpAw2TeU3I1KUpgQGmyg3oUjWPtf9E9a9dGSJUhRGmE9ipw", "\n",
        "cQMWhP7kybfpf7a8kwCeXAhkPVAU++V1ZNvb3j/WADXg/1XQUgPGoxTAANxrTVJx", "\n",
        "WQiIlFyELpoRIRG7ScgSAxUfuh7o0yXfIi47DpIEoA==", "\n",
        "-----END EC PRIVATE KEY-----", "\n",
    );
    const P521_PKCS8: &str = concat!(
        "-----BEGIN PRIVATE KEY-----", "\n",
        "MIHuAgEAMBAGByqGSM49AgEGBSuBBAAjBIHWMIHTAgEBBEIAdufERUG0oeJ10N+B", "\n",
        "v+X90N7yFqYVBx/b1zxWDFy7IenBbH3m19ZIeS7CX304BsDAg7qsfA297eVCJbgA", "\n",
        "s2PHHMqhgYkDgYYABAFcBODyJ0wHcbjtkyXarPWtaIpAw2TeU3I1KUpgQGmyg3oU", "\n",
        "jWPtf9E9a9dGSJUhRGmE9ipwcQMWhP7kybfpf7a8kwCeXAhkPVAU++V1ZNvb3j/W", "\n",
        "ADXg/1XQUgPGoxTAANxrTVJxWQiIlFyELpoRIRG7ScgSAxUfuh7o0yXfIi47DpIE", "\n",
        "oA==", "\n",
        "-----END PRIVATE KEY-----", "\n",
    );
    const P521_PKCS8_PASSPHRASE: &str = "pkcs8-pass";
    const P521_PKCS8_ENC: &str = concat!(
        "-----BEGIN ENCRYPTED PRIVATE KEY-----", "\n",
        "MIIBZTBfBgkqhkiG9w0BBQ0wUjAxBgkqhkiG9w0BBQwwJAQQUb69XfifBahYHZCi", "\n",
        "T3/dNQICCAAwDAYIKoZIhvcNAgkFADAdBglghkgBZQMEASoEEFEFBT5lelHs0Ikf", "\n",
        "rOQHsd8EggEA72Iuk/XfL+B1ztGKnuwSUuHkDIfqrugpnnipFX3uqnNfrKCq4cgV", "\n",
        "CLa8mxag99CaeUNLeRf1q51qSCkJDXlp72Iln78pGFV2KfcOtkJyg2J2H7/YyS0J", "\n",
        "l5F7FthjQFe5oAMAy7J+ZvccAPOjxRkq4+UUvSD0L5CZ8Ana1lt47zU5T+F+ChqU", "\n",
        "qucZoyUozaRbnLX1HwwFaGj1GWezN1Tb4+m7HgBq9efhf9sBlXAaoaOmOGpzPYr9", "\n",
        "xVTuTZ4D9tEvOHv/RFOZsZ6jSGan2JFHPttjCuDdYAUv7td4QDL2+WpsoGPYYlNt", "\n",
        "zVtMBi0HWOfN/g1USthtX64Rt7YupWd+jQ==", "\n",
        "-----END ENCRYPTED PRIVATE KEY-----", "\n",
    );
    const P521_SEC1_LEGACY_ENC: &str = concat!(
        "-----BEGIN EC PRIVATE KEY-----", "\n",
        "Proc-Type: 4,ENCRYPTED", "\n",
        "DEK-Info: AES-128-CBC,6AAE92543490CD1C0CC1379C8F41D8BC", "\n",
        "", "\n",
        "QdVrrcbttQm+FA+zAVdBsg8P27+fvItEE21uI1EcL3+iYzuvPdG3UxPCV7XvqA0H", "\n",
        "QYw4rpmVz4t31gokcOYQHCtaOcNpQ5j4f8gC29w2E4uObL+Rj0IlmwAvNjKI84fb", "\n",
        "t30+KLuzm+yzcgQIJhU5lv87q0qVpGTOYL3RFs0DdJIBUxXmX187CXzuhEeuG1uz", "\n",
        "IIlyvlGWsUpld6yYnn6pdKFpW2YjsiUSPtCUtZj/C5vxJKz68NftkstD2UWzqx5f", "\n",
        "lYt7UrW77+lzY3DWKcb3aoXlvDljQdFEfm/+bkVwjOE=", "\n",
        "-----END EC PRIVATE KEY-----", "\n",
    );
    const P521_PUBLIC: &str = concat!(
        "ecdsa-sha2-nistp521 AAAAE2VjZHNhLXNoYTItbmlzdHA1MjEAAAAIbmlzdHA1MjEAAACFBAFcBODyJ0wHcbjtkyXarPWtaIpAw2T",
        "eU3I1KUpgQGmyg3oUjWPtf9E9a9dGSJUhRGmE9ipwcQMWhP7kybfpf7a8kwCeXAhkPVAU++V1ZNvb3j/WADXg/1XQUgPGoxTAANxrT",
        "VJxWQiIlFyELpoRIRG7ScgSAxUfuh7o0yXfIi47DpIEoA==",
    );
    // Throwaway P-521 key in OpenSSH format (`ssh-keygen -t ecdsa -b 521`),
    // the format of the key in issue #77, and its public half.
    const P521_OPENSSH: &str = concat!(
        "-----BEGIN OPENSSH PRIVATE KEY-----", "\n",
        "b3BlbnNzaC1rZXktdjEAAAAABG5vbmUAAAAEbm9uZQAAAAAAAAABAAAArAAAABNlY2RzYS", "\n",
        "1zaGEyLW5pc3RwNTIxAAAACG5pc3RwNTIxAAAAhQQAvtzl7GYNWH8JocIhNsPAHacrittx", "\n",
        "6PEMIxtc239ZfSlHcSfbZXr3lRhCEfbPmKzdEEVTnCFS/9e7AlkCWdgXGMwAyEi97CdaDJ", "\n",
        "pAod7gqwA2MkzZmKtmsG+EV3aFXQlpvTPu8UJMqWRMhUHMDypin+Z02TIOkengiNIKTdfy", "\n",
        "Q6c9UpwAAAEI3dqG893ahvMAAAATZWNkc2Etc2hhMi1uaXN0cDUyMQAAAAhuaXN0cDUyMQ", "\n",
        "AAAIUEAL7c5exmDVh/CaHCITbDwB2nK4rbcejxDCMbXNt/WX0pR3En22V695UYQhH2z5is", "\n",
        "3RBFU5whUv/XuwJZAlnYFxjMAMhIvewnWgyaQKHe4KsANjJM2ZirZrBvhFd2hV0Jab0z7v", "\n",
        "FCTKlkTIVBzA8qYp/mdNkyDpHp4IjSCk3X8kOnPVKcAAAAQgDJNX554jkZlm78+fi0Gj3p", "\n",
        "FJjvZRUBqKF8RgsIq5C3kB/7QMbH/r2IDidtUmNjCVGCkodiUt5QS5H3pWfZHX9aBwAAAA", "\n",
        "dmaXh0dXJlAQID", "\n",
        "-----END OPENSSH PRIVATE KEY-----", "\n",
    );
    const P521_OPENSSH_PUBLIC: &str = concat!(
        "ecdsa-sha2-nistp521 AAAAE2VjZHNhLXNoYTItbmlzdHA1MjEAAAAIbmlzdHA1MjEAAACFBAC+3OXsZg1YfwmhwiE2w8AdpyuK23H",
        "o8QwjG1zbf1l9KUdxJ9tleveVGEIR9s+YrN0QRVOcIVL/17sCWQJZ2BcYzADISL3sJ1oMmkCh3uCrADYyTNmYq2awb4RXdoVdCWm9M+",
        "7xQkypZEyFQcwPKmKf5nTZMg6R6eCI0gpN1/JDpz1SnA==",
    );
    // Throwaway Ed25519 key in PKCS#8 (`openssl genpkey -algorithm ed25519`).
    const ED25519_PKCS8: &str = concat!(
        "-----BEGIN PRIVATE KEY-----", "\n",
        "MC4CAQAwBQYDK2VwBCIEIBXcUxGTvHbBFb3vzUra7Hz27fwFi5UPhlO4bFnIYHCr", "\n",
        "-----END PRIVATE KEY-----", "\n",
    );
    const ED25519_PKCS8_PUBLIC: &str =
        "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIHPgjDe6mnhOGK+sb3jOSE1cI6AyAn+uDTumwl5/xBEG";

    /// `<algorithm> <base64>` of a key's public half, comment dropped.
    fn public_of(key: &russh::keys::PrivateKey) -> String {
        let line = key.public_key().to_openssh().expect("encodes");
        line.split_whitespace().take(2).collect::<Vec<_>>().join(" ")
    }

    fn decoded(pem: &str, passphrase: Option<&str>) -> russh::keys::PrivateKey {
        match decode_private_key(pem, passphrase) {
            Ok(key) => key,
            Err(KeyDecodeError::NeedsPassphrase) => panic!("asked for a passphrase"),
            Err(KeyDecodeError::Malformed(m)) => panic!("refused: {m}"),
        }
    }

    #[test]
    fn p521_keys_decode_in_every_format_russh_reads() {
        assert_eq!(public_of(&decoded(P521_OPENSSH, None)), P521_OPENSSH_PUBLIC);
        assert_eq!(public_of(&decoded(P521_SEC1, None)), P521_PUBLIC);
        assert_eq!(public_of(&decoded(P521_PKCS8, None)), P521_PUBLIC);
        assert_eq!(public_of(&decoded(P521_PKCS8_ENC, Some(P521_PKCS8_PASSPHRASE))), P521_PUBLIC);
        assert_eq!(public_of(&decoded(ED25519_PKCS8, None)), ED25519_PKCS8_PUBLIC);
    }

    #[test]
    fn a_p521_key_signs_and_its_public_half_verifies() {
        for key in [decoded(P521_OPENSSH, None), decoded(P521_SEC1, None)] {
            let sig = key.sign("submarine-test", ssh_key::HashAlg::Sha512, b"hello").expect("signs");
            key.public_key().verify("submarine-test", b"hello", &sig).expect("verifies");
        }
    }

    // Set the bcrypt round count in an OpenSSH key's cleartext envelope (its
    // last-4-bytes field) without touching anything else, so a key that asks
    // for an absurd cost can be built without running that cost.
    fn patch_bcrypt_rounds(pem: &str, rounds: u32) -> String {
        use base64::{engine::general_purpose::STANDARD, Engine as _};
        let body: String = pem.lines().filter(|l| !l.starts_with("-----")).collect();
        let mut bytes = STANDARD.decode(body.trim()).unwrap();
        let str_len = |b: &[u8], p: usize| u32::from_be_bytes([b[p], b[p + 1], b[p + 2], b[p + 3]]) as usize;
        let mut p = 15; // past "openssh-key-v1\0"
        p += 4 + str_len(&bytes, p); // ciphername
        p += 4 + str_len(&bytes, p); // kdfname
        let opts_end = p + 4 + str_len(&bytes, p); // end of kdfoptions (= rounds, last 4 bytes)
        bytes[opts_end - 4..opts_end].copy_from_slice(&rounds.to_be_bytes());
        let b64 = STANDARD.encode(&bytes);
        let mut out = String::from("-----BEGIN OPENSSH PRIVATE KEY-----\n");
        for chunk in b64.as_bytes().chunks(70) {
            out.push_str(std::str::from_utf8(chunk).unwrap());
            out.push('\n');
        }
        out.push_str("-----END OPENSSH PRIVATE KEY-----\n");
        out
    }

    // A key whose bcrypt KDF asks for billions of rounds is refused before any
    // derivation runs, so it can't pin a thread; a normal one still decodes.
    #[test]
    fn a_key_with_an_absurd_kdf_cost_is_refused() {
        use ssh_key::private::{Ed25519Keypair, Ed25519PrivateKey};
        let kp = ssh_key::PrivateKey::from(Ed25519Keypair::from(Ed25519PrivateKey::from_bytes(&[7u8; 32])));
        let enc = kp.encrypt(&mut rand::rng(), "pw").expect("encrypt with default rounds");
        let pem = enc.to_openssh(ssh_key::LineEnding::LF).unwrap().to_string();
        // The normal key (default rounds) passes the guard and decodes.
        assert!(guard_key_kdf_cost(&pem).is_ok());
        assert!(decode_private_key(&pem, Some("pw")).is_ok());
        // With the rounds bumped past the limit, both the guard and the decode
        // refuse it — the test would hang here if decoding ran the KDF.
        let huge = patch_bcrypt_rounds(&pem, u32::MAX);
        assert!(matches!(guard_key_kdf_cost(&huge), Err(KeyDecodeError::Malformed(_))));
        assert!(decode_private_key(&huge, Some("pw")).is_err());
        // Just over the limit is refused; the limit itself is allowed.
        assert!(guard_key_kdf_cost(&patch_bcrypt_rounds(&pem, MAX_KEY_KDF_ROUNDS + 1)).is_err());
        assert!(guard_key_kdf_cost(&patch_bcrypt_rounds(&pem, MAX_KEY_KDF_ROUNDS)).is_ok());
        // An unencrypted key (no KDF) is untouched.
        let plain = kp.to_openssh(ssh_key::LineEnding::LF).unwrap().to_string();
        assert!(guard_key_kdf_cost(&plain).is_ok());
    }

    #[test]
    fn an_encrypted_pkcs8_key_asks_for_its_passphrase() {
        assert!(matches!(decode_private_key(P521_PKCS8_ENC, None), Err(KeyDecodeError::NeedsPassphrase)));
        assert!(matches!(
            decode_private_key(P521_PKCS8_ENC, Some("not the passphrase")),
            Err(KeyDecodeError::NeedsPassphrase)
        ));
    }

    #[test]
    fn a_passphrase_saved_with_an_unencrypted_pem_key_is_ignored() {
        assert_eq!(public_of(&decoded(P521_PKCS8, Some("stray"))), P521_PUBLIC);
        assert_eq!(public_of(&decoded(P521_SEC1, Some("stray"))), P521_PUBLIC);
    }

    #[test]
    fn a_legacy_encrypted_ecdsa_pem_key_is_refused_with_a_way_out() {
        for passphrase in [None, Some("pem-pass")] {
            match decode_private_key(P521_SEC1_LEGACY_ENC, passphrase) {
                Err(KeyDecodeError::Malformed(msg)) => assert!(msg.contains("ssh-keygen -p -f"), "{msg}"),
                _ => panic!("expected a refusal, not a passphrase prompt"),
            }
        }
        let err = validate_ssh_private_key(P521_SEC1_LEGACY_ENC).unwrap_err();
        assert!(err.contains("ssh-keygen -p -f"), "{err}");
    }

    #[test]
    fn validation_accepts_every_format_the_connect_path_reads() {
        for pem in [P521_OPENSSH, P521_SEC1, P521_PKCS8, P521_PKCS8_ENC, ED25519_PKCS8] {
            assert_eq!(validate_ssh_private_key(pem), Ok(()), "{}", pem_private_key_header(pem));
        }
        // `openssl ecparam -genkey` without -noout writes the curve first.
        let with_params =
            format!("-----BEGIN EC PARAMETERS-----\nBgUrgQQAIw==\n-----END EC PARAMETERS-----\n{P521_SEC1}");
        assert_eq!(validate_ssh_private_key(&with_params), Ok(()));
        assert_eq!(public_of(&decoded(&with_params, None)), P521_PUBLIC);
    }

    #[test]
    fn validation_still_refuses_what_cannot_connect() {
        let dsa = "-----BEGIN DSA PRIVATE KEY-----\nAAAA\n-----END DSA PRIVATE KEY-----\n";
        assert!(validate_ssh_private_key(dsa).unwrap_err().contains("DSA keys aren't supported"));
        assert!(validate_ssh_private_key("not a key").unwrap_err().contains("UNRECOGNIZED_KEY_FORMAT"));
        // A damaged PKCS#8 body is caught when the key is entered, not later.
        let damaged = P521_PKCS8.replace("MIHuAgEAMBAG", "MIHuAgEAMBAA");
        assert!(validate_ssh_private_key(&damaged).unwrap_err().contains("UNREADABLE_KEY"));
    }

    #[test]
    fn encrypted_keys_are_recognised_from_the_text_alone() {
        assert!(private_key_is_encrypted(P521_PKCS8_ENC));
        assert!(private_key_is_encrypted(P521_SEC1_LEGACY_ENC));
        for plain in [P521_OPENSSH, P521_SEC1, P521_PKCS8, ED25519_PKCS8] {
            assert!(!private_key_is_encrypted(plain));
        }
    }
}

#[cfg(test)]
mod secret_prompt_tests {
    use super::*;

    // Ed25519 OpenSSH keys made with `ssh-keygen -t ed25519`. ENC_KEY is
    // encrypted (aes256-ctr / bcrypt) with ENC_PASSPHRASE; PLAIN_KEY has none.
    const ENC_PASSPHRASE: &str = "correct horse";
    const ENC_KEY: &str = concat!(
        "-----BEGIN OPENSSH PRIVATE KEY-----", "\n",
        "b3BlbnNzaC1rZXktdjEAAAAACmFlczI1Ni1jdHIAAAAGYmNyeXB0AAAAGAAAABDE7RDhqs", "\n",
        "hjetAzLiugxZpKAAAAGAAAAAEAAAAzAAAAC3NzaC1lZDI1NTE5AAAAIMcnclCWDFavhUYR", "\n",
        "5zNFTSffQrWc+YsqM4sKKcQpomAWAAAAkAKhRIln427oNRf0UR+Gx0Ph0KbwN8eqNn+GYI", "\n",
        "dcWUkBqq0x5hOwGasu4h9L4gMjUC/vbAjFFF6fmMidUq2w93yvf+ksagU3bR0RBkJZY2L6", "\n",
        "mviz2RgokhaQVhtuT2nh7/54QtQLd3Y6zhn1oqW1XXWzzUMA/diArEO6mGB+mQq33rziRS", "\n",
        "cPG9v4ahpJmDDpkw==", "\n",
        "-----END OPENSSH PRIVATE KEY-----", "\n",
    );
    const PLAIN_KEY: &str = concat!(
        "-----BEGIN OPENSSH PRIVATE KEY-----", "\n",
        "b3BlbnNzaC1rZXktdjEAAAAABG5vbmUAAAAEbm9uZQAAAAAAAAABAAAAMwAAAAtzc2gtZW", "\n",
        "QyNTUxOQAAACA/EA8yXS689fAo/F6QVpxLRJG8HiBKbnEvWz/YZ2lMZgAAAJCg+R4QoPke", "\n",
        "EAAAAAtzc2gtZWQyNTUxOQAAACA/EA8yXS689fAo/F6QVpxLRJG8HiBKbnEvWz/YZ2lMZg", "\n",
        "AAAEDHfBKInOfdnPFdnNPKorc16nvh3XNwnPYBxUAlKR4dkj8QDzJdLrz18Cj8XpBWnEtE", "\n",
        "kbweIEpucS9bP9hnaUxmAAAADXBsYWluLWZpeHR1cmU=", "\n",
        "-----END OPENSSH PRIVATE KEY-----", "\n",
    );

    // --- decode_private_key error classification (issue #30) ----------------

    #[test]
    fn decode_flags_encrypted_key_without_passphrase_as_needing_one() {
        assert!(matches!(decode_private_key(ENC_KEY, None), Err(KeyDecodeError::NeedsPassphrase)));
        // An empty passphrase is treated as "none", not an attempt.
        assert!(matches!(decode_private_key(ENC_KEY, Some("")), Err(KeyDecodeError::NeedsPassphrase)));
    }

    #[test]
    fn decode_flags_wrong_passphrase_as_needing_one_not_malformed() {
        assert!(matches!(
            decode_private_key(ENC_KEY, Some("not the passphrase")),
            Err(KeyDecodeError::NeedsPassphrase)
        ));
    }

    // Throwaway 1024-bit RSA key in legacy PKCS#1 PEM, encrypted the PKCS#5
    // way (`openssl genrsa -traditional -aes128`) with PEM_PASSPHRASE.
    const PEM_PASSPHRASE: &str = "right-pass";
    const PEM_ENC_KEY: &str = concat!(
        "-----BEGIN RSA PRIVATE KEY-----", "\n",
        "Proc-Type: 4,ENCRYPTED", "\n",
        "DEK-Info: AES-128-CBC,BB76307096C12231EAB52A979EA86901", "\n",
        "", "\n",
        "KoULx8jVcG6IX1pGQ6dLYH3/cpMG27IecsxDmCbGVQkdhbqwF2pBIxa/Tx07bmSs", "\n",
        "q1OKYTf9NScezY9Lhe10EOEtOmZ186rGQxDfxnv5crWfrMey+eMCeOLlFtRLP8J1", "\n",
        "flCs6oR1NAlvnlPW6rbv9XxjoZplnylu9GtHOkCb0cAYZQbwVO0v/FVJ73D2b1p+", "\n",
        "eg8ijRh67Oji0gADWKFf7baYUnMRrW5UaabsMUjYXgPnYbE9wabd53MM5yRMqr+H", "\n",
        "A3lMNPXnh1erNfRTZswYZgg4fO1rtpuHKw3EJROqHjqAeXxbd5YUOgHEOhot2kn4", "\n",
        "HhNCEBWe+1JTUo594kiVx0lu+wp2BINq2ak+sFogrqevW/2F28qtJ5fM57YHhL/5", "\n",
        "blErH52LsivGMCh2UGEUBpDPNIRyDAMOuA/f2UviXGCjv88Qkf38JV+sZY84zZ0+", "\n",
        "7OFWs2alsVv7J/3kmR/Zmh34YBG31Pw447HZUqvD9Ve75bjO2/lDV6m9xnHyzQir", "\n",
        "s6K11+R54cr92HzwlIP1W0cjczrJ/UIVDYnl5y3rkNYSkvW0vY0bVk20Ul4iD6va", "\n",
        "tOsQ7TH09QumYeLsU1mts//BeS+CoiWTiFm5CwX+IEgkm/nXqCAuLzj6Bz7dr6/r", "\n",
        "vexWuNnpuWIJ3z9ZEX0EtFNeqECakxw1jJrL7fx8LXeD75Lb1rpscOphN1t9NYrO", "\n",
        "TAxHSbEkODA6JJcG6WNotvmMHKOM+kIGd7u5dzHwKN1ndWGsLpcMowhsTZxhfwdb", "\n",
        "LboMbHudt2MWS9BFU1yG95YGUoUFg25hwKPd4xxXvV+0OJj9g1u55KtzezWbAmc/", "\n",
        "-----END RSA PRIVATE KEY-----", "\n",
    );

    #[test]
    fn decode_handles_a_legacy_encrypted_pem_key() {
        // No passphrase: russh says KeyIsEncrypted.
        assert!(matches!(decode_private_key(PEM_ENC_KEY, None), Err(KeyDecodeError::NeedsPassphrase)));
        // Wrong passphrase: the PKCS#5 decrypt yields garbage and the RSA
        // decode fails — still "needs a passphrase", so the user is re-asked
        // instead of the attempt ending as a malformed key.
        assert!(matches!(
            decode_private_key(PEM_ENC_KEY, Some("not the passphrase")),
            Err(KeyDecodeError::NeedsPassphrase)
        ));
        assert!(decode_private_key(PEM_ENC_KEY, Some(PEM_PASSPHRASE)).is_ok());
    }

    #[test]
    fn decode_refuses_a_legacy_pem_cipher_russh_cannot_read() {
        // DES-EDE3 (PuTTYgen's OpenSSH export, `openssl -des3`): no passphrase
        // could ever unlock it here, so it's reported, not asked for.
        let des3 = PEM_ENC_KEY.replace(
            "DEK-Info: AES-128-CBC,BB76307096C12231EAB52A979EA86901",
            "DEK-Info: DES-EDE3-CBC,BB76307096C12231",
        );
        for passphrase in [None, Some(PEM_PASSPHRASE)] {
            match decode_private_key(&des3, passphrase) {
                Err(KeyDecodeError::Malformed(msg)) => assert!(msg.contains("AES-128-CBC"), "{msg}"),
                _ => panic!("expected an unsupported-cipher error"),
            }
        }
    }

    #[test]
    fn decode_accepts_the_right_passphrase_and_any_plain_key() {
        assert!(decode_private_key(ENC_KEY, Some(ENC_PASSPHRASE)).is_ok());
        assert!(decode_private_key(PLAIN_KEY, None).is_ok());
        // A passphrase is ignored for an unencrypted key.
        assert!(decode_private_key(PLAIN_KEY, Some("ignored")).is_ok());
    }

    #[test]
    fn decode_reports_unparseable_input_as_malformed() {
        assert!(matches!(
            decode_private_key("definitely not a key", None),
            Err(KeyDecodeError::Malformed(_))
        ));
    }

    #[test]
    fn decode_normalizes_windows_line_endings() {
        let crlf = PLAIN_KEY.replace('\n', "\r\n");
        assert!(decode_private_key(&crlf, None).is_ok());
    }

    /// The key path's "no usable passphrase" outcome (cancel / timeout / out of
    /// attempts) must classify as an AUTH failure, so an auto-reconnect stops
    /// instead of looping straight back into the passphrase prompt.
    #[test]
    fn missing_passphrase_error_is_auth_shaped() {
        let e = russh::Error::from(russh::keys::Error::KeyIsEncrypted);
        assert!(classify_russh_error(&e).is_auth());
    }

    // --- base session id (cache key) ----------------------------------------

    #[test]
    fn base_session_id_strips_dedicated_transport_suffixes() {
        assert_eq!(base_session_id("tab-1"), "tab-1");
        assert_eq!(base_session_id("tab-1::sftp"), "tab-1");
        assert_eq!(base_session_id("tab-1::fwd"), "tab-1");
        // Anything else is left intact.
        assert_eq!(base_session_id("tab-1::other"), "tab-1::other");
    }

    // --- candidate order --------------------------------------------------

    /// The per-connect override goes first, then what the user typed earlier
    /// this tab, then the saved value — so a stale saved password can't shadow
    /// the cached one on reconnect. Empty values mean "ask", so they're dropped.
    #[test]
    fn candidates_try_override_then_cache_then_saved_skipping_empties() {
        let z = |s: &str| Some(zeroize::Zeroizing::new(s.to_string()));
        let plain_order = |c: Vec<(zeroize::Zeroizing<String>, SecretSource)>| {
            c.into_iter().map(|(s, src)| (s.to_string(), src)).collect::<Vec<_>>()
        };
        assert_eq!(
            plain_order(secret_candidates(z("typed"), z("cached"), z("saved"))),
            vec![
                ("typed".to_string(), SecretSource::Override),
                ("cached".to_string(), SecretSource::Cache),
                ("saved".to_string(), SecretSource::Given),
            ]
        );
        assert_eq!(
            plain_order(secret_candidates(None, z("cached"), z(""))),
            vec![("cached".to_string(), SecretSource::Cache)]
        );
        assert!(secret_candidates(z(""), None, z("")).is_empty());
    }

    // --- prompted-secret cache: round-trip + clear-on-reject ----------------

    fn empty_cache() -> PromptedSecretsMap {
        std::sync::Arc::new(tokio::sync::Mutex::new(std::collections::HashMap::new()))
    }
    fn plain(o: Option<zeroize::Zeroizing<String>>) -> Option<String> {
        o.map(|z| z.to_string())
    }

    #[tokio::test]
    async fn cache_round_trips_per_slot_and_is_shared_by_secondaries() {
        let cache = empty_cache();
        assert!(cache_get_secret(&cache, "tab", SecretSlot::Password).await.is_none());

        cache_store_secret(&cache, "tab", SecretSlot::Password, zeroize::Zeroizing::new("pw".into())).await;
        cache_store_secret(&cache, "tab", SecretSlot::Passphrase, zeroize::Zeroizing::new("pp".into())).await;

        assert_eq!(plain(cache_get_secret(&cache, "tab", SecretSlot::Password).await), Some("pw".into()));
        assert_eq!(plain(cache_get_secret(&cache, "tab", SecretSlot::Passphrase).await), Some("pp".into()));
        // A dedicated `::sftp` / `::fwd` secondary reads the base tab's entry.
        let base = base_session_id("tab::sftp");
        assert_eq!(plain(cache_get_secret(&cache, base, SecretSlot::Password).await), Some("pw".into()));
        // A different tab is isolated.
        assert!(cache_get_secret(&cache, "other", SecretSlot::Password).await.is_none());
    }

    #[tokio::test]
    async fn username_slots_are_separate_from_the_secrets() {
        let cache = empty_cache();
        cache_store_secret(&cache, "tab", SecretSlot::Username, zeroize::Zeroizing::new("alice".into())).await;
        cache_store_secret(&cache, "tab", SecretSlot::JumpUsername, zeroize::Zeroizing::new("jump".into())).await;
        assert_eq!(plain(cache_get_secret(&cache, "tab", SecretSlot::Username).await), Some("alice".into()));
        assert_eq!(plain(cache_get_secret(&cache, "tab", SecretSlot::JumpUsername).await), Some("jump".into()));
        assert!(cache_get_secret(&cache, "tab", SecretSlot::Password).await.is_none());
        // Secondaries reuse the tab's typed name.
        let base = base_session_id("tab::fwd");
        assert_eq!(plain(cache_get_secret(&cache, base, SecretSlot::Username).await), Some("alice".into()));
    }

    #[test]
    fn login_answer_is_trimmed_and_empty_means_root() {
        assert_eq!(login_user_from_answer("alice").as_str(), "alice");
        assert_eq!(login_user_from_answer("  bob \t").as_str(), "bob");
        assert_eq!(login_user_from_answer("").as_str(), "root");
        assert_eq!(login_user_from_answer("   ").as_str(), "root");
    }

    #[tokio::test]
    async fn cache_clear_on_reject_removes_only_that_slot() {
        let cache = empty_cache();
        cache_store_secret(&cache, "tab", SecretSlot::Password, zeroize::Zeroizing::new("pw".into())).await;
        cache_store_secret(&cache, "tab", SecretSlot::JumpPassword, zeroize::Zeroizing::new("jpw".into())).await;

        cache_clear_secret(&cache, "tab", SecretSlot::Password).await;

        assert!(cache_get_secret(&cache, "tab", SecretSlot::Password).await.is_none());
        // Other slots on the same tab are untouched.
        assert_eq!(plain(cache_get_secret(&cache, "tab", SecretSlot::JumpPassword).await), Some("jpw".into()));
        // Clearing an unknown tab is a no-op.
        cache_clear_secret(&cache, "nope", SecretSlot::Password).await;
    }
}

/// Drive keyboard-interactive (RFC 4256) authentication — the method behind
/// most SSH "verification code" / 2FA / OTP setups. The server sends a
/// sequence of `InfoRequest`s (each a set of prompts like "Verification
/// code:"); we relay every prompt to the UI via `kbi-prompt-{session_id}`,
/// wait for the user's answers on a per-nonce oneshot, and send them back.
///
/// Return contract:
///   * `Some(Ok(true))`  — authenticated.
///   * `Some(Ok(false))` — the user answered but the server rejected, OR the
///                         user cancelled / timed out.
///   * `Some(Err(e))`    — transport error talking to the server.
///   * `None`            — the server never actually prompted us (it doesn't
///                         offer keyboard-interactive). The caller keeps its
///                         original, more meaningful auth result instead of
///                         masking it with a generic interactive failure.
///
/// Report a failed connect attempt to its tab — unless a newer attempt has
/// started or the tab disconnected since. A late report from an attempt the
/// user already replaced (Reconnect, or closing and reopening the tab) would
/// flip the tab that has moved on back to "连接失败".
async fn emit_connection_failed(
    app: &tauri::AppHandle,
    attempt: &ssh_manager::ConnectAttempt,
    session_id: &str,
    payload: serde_json::Value,
) {
    use tauri::Emitter;
    if attempt.is_current().await {
        let _ = app.emit(&format!("connection-failed-{}", session_id), payload);
    } else {
        println!("[BACKEND] {}: dropped the failure report of a superseded connect attempt", session_id);
    }
}

/// Generic over the handler so both the primary connection (`ClientHandler`)
/// and a ProxyJump intermediate hop can reuse it.
async fn run_keyboard_interactive<H: russh::client::Handler>(
    session: &mut russh::client::Handle<H>,
    user: &str,
    app: &tauri::AppHandle,
    session_id: &str,
    nonce: &str,
    kbi_txs: &std::sync::Arc<
        tokio::sync::Mutex<
            std::collections::HashMap<String, tokio::sync::oneshot::Sender<Option<Vec<String>>>>,
        >,
    >,
    // The connect attempt asking — its prompts are only shown while it's
    // current (see ssh_manager::ConnectAttempt).
    attempt: &ssh_manager::ConnectAttempt,
) -> Option<Result<bool, russh::Error>> {
    use russh::client::KeyboardInteractiveAuthResponse;
    use tauri::Emitter;

    let log = |msg: &str, ty: &str| {
        println!("[LOG-{}] {}", session_id, msg);
        // A superseded attempt stays out of the tab's log.
        if !attempt.is_current_now() {
            return;
        }
        let _ = app.emit(
            &format!("session-log-{}", session_id),
            serde_json::json!({"msg": msg, "type": ty}),
        );
    };

    log("Attempting Keyboard-Interactive (verification code) authentication...", "info");

    let mut resp = match session
        .authenticate_keyboard_interactive_start(user.to_string(), None)
        .await
    {
        Ok(r) => r,
        Err(e) => return Some(Err(e)),
    };

    // Guards against masking the primary error: only report a definitive
    // result once the server has actually asked us something.
    let mut asked_anything = false;

    loop {
        match resp {
            KeyboardInteractiveAuthResponse::Success => return Some(Ok(true)),
            KeyboardInteractiveAuthResponse::Failure { .. } => {
                if !asked_anything {
                    // Server declined the method outright — not really offered.
                    return None;
                }
                log("Verification code rejected by server.", "error");
                return Some(Ok(false));
            }
            KeyboardInteractiveAuthResponse::InfoRequest {
                name,
                instructions,
                prompts,
            } => {
                // A banner-only InfoRequest (zero prompts) needs an empty
                // response set to advance — nothing to ask the user.
                if prompts.is_empty() {
                    resp = match session
                        .authenticate_keyboard_interactive_respond(Vec::new())
                        .await
                    {
                        Ok(r) => r,
                        Err(e) => return Some(Err(e)),
                    };
                    continue;
                }
                asked_anything = true;

                // A superseded or abandoned attempt doesn't put its prompt over
                // a newer one; it ends like a cancelled prompt.
                if !attempt.may_prompt().await {
                    return Some(Ok(false));
                }

                // Fresh oneshot each round — a server may issue several
                // sequential InfoRequests within one auth exchange.
                let (tx, rx) = tokio::sync::oneshot::channel::<Option<Vec<String>>>();
                kbi_txs.lock().await.insert(nonce.to_string(), tx);

                let prompt_payload: Vec<serde_json::Value> = prompts
                    .iter()
                    .map(|p| serde_json::json!({ "prompt": p.prompt, "echo": p.echo }))
                    .collect();
                let _ = app.emit(
                    &format!("kbi-prompt-{}", session_id),
                    serde_json::json!({
                        "nonce": nonce,
                        "name": name,
                        "instructions": instructions,
                        "prompts": prompt_payload,
                    }),
                );

                // 120s: 2FA codes often mean reaching for a phone / authenticator.
                let answers = match tokio::time::timeout(
                    std::time::Duration::from_secs(120),
                    rx,
                )
                .await
                {
                    Ok(Ok(Some(a))) => a,
                    _ => {
                        // Timed out, cancelled, or the channel was dropped.
                        kbi_txs.lock().await.remove(nonce);
                        let _ = app.emit(
                            &format!("kbi-prompt-dismiss-{}", session_id),
                            serde_json::json!({ "nonce": nonce }),
                        );
                        log("Verification prompt cancelled or timed out.", "error");
                        return Some(Ok(false));
                    }
                };
                let _ = app.emit(
                    &format!("kbi-prompt-dismiss-{}", session_id),
                    serde_json::json!({ "nonce": nonce }),
                );

                // The protocol requires exactly one response per prompt.
                // Pad/truncate so a UI/prompt-count mismatch can never desync
                // the SSH auth state machine.
                let mut answers = answers;
                answers.resize(prompts.len(), String::new());

                resp = match session
                    .authenticate_keyboard_interactive_respond(answers)
                    .await
                {
                    Ok(r) => r,
                    Err(e) => return Some(Err(e)),
                };
            }
        }
    }
}

/// OS-level TCP keepalive on an SSH transport socket. Complements the session
/// watcher's keepalive pings (russh's own protocol keepalive is off — see
/// build_ssh_client_config): no unanswered SSH-level keepalive ever tears the
/// connection down — but with TCP keepalive the kernel itself probes an idle
/// peer (30s idle, then every 10s) and errors the socket when the peer is
/// truly gone, which russh's run loop surfaces as `is_closed()`. That gives
/// dead-link detection during long-idle periods without any SSH traffic, and
/// keeps NAT/firewall mappings warm on flaky consumer networks. Best-effort:
/// failure to set it is never a reason to abort a connect. (`with_retries`
/// is deliberately not used — socket2 doesn't support it on Windows.)
fn apply_tcp_keepalive(stream: &tokio::net::TcpStream) {
    use socket2::{SockRef, TcpKeepalive};
    let ka = TcpKeepalive::new()
        .with_time(std::time::Duration::from_secs(30))
        .with_interval(std::time::Duration::from_secs(10));
    let _ = SockRef::from(stream).set_tcp_keepalive(&ka);
}

/// Algorithm negotiation lists shared by EVERY SSH connection the app makes —
/// the primary session, its `::sftp` / `::fwd` secondaries and ProxyJump hops
/// (all via `build_ssh_client_config`) and the resource monitor
/// (`monitor::monitor_client_config`) — so they all negotiate the same
/// host-key type. The monitor depends on that: it only trusts a fingerprint
/// the interactive session already stored.
///
/// Everything here is pure Rust in russh 0.63, so the set is identical in
/// debug, release and Android builds (the old OpenSSL-backed `full-ssh-algos`
/// feature is gone). Order = preference: modern first; the legacy entries
/// (ssh-rsa/SHA-1 host keys, DH group14/group1 SHA-1 KEX, HMAC-SHA1) stay
/// last, purely for old/embedded servers that offer nothing better.
pub(crate) fn ssh_preferred_algorithms() -> russh::Preferred {
    use russh::keys::{Algorithm, EcdsaCurve, HashAlg};
    use russh::{cipher, compression, kex, mac};
    use std::borrow::Cow;

    const KEX: &[kex::Name] = &[
        kex::MLKEM768X25519_SHA256, // hybrid post-quantum (OpenSSH 9.9+; its default since 10.0)
        kex::CURVE25519,
        kex::CURVE25519_PRE_RFC_8731,
        // Group exchange (issue #33): the only KEX some hardened / appliance
        // servers enable. Bounds in ssh_gex_params.
        kex::DH_GEX_SHA256,
        kex::DH_G18_SHA512,
        kex::DH_G17_SHA512,
        kex::DH_G16_SHA512,
        kex::DH_G15_SHA512,
        kex::DH_G14_SHA256,
        // Legacy, last resort for old servers.
        kex::DH_G14_SHA1,
        kex::DH_G1_SHA1,
        // Pseudo-algorithms, never selected as the KEX: RFC 8308 ext-info
        // (server-sig-algs → RSA SHA-2 user auth) and OpenSSH strict KEX
        // (Terrapin mitigation).
        kex::EXTENSION_SUPPORT_AS_CLIENT,
        kex::EXTENSION_OPENSSH_STRICT_KEX_AS_CLIENT,
    ];
    // The first five are exactly the pre-0.63 release order, so every server
    // that build could reach negotiates the same host-key type — and its
    // pinned fingerprint keeps matching. ECDSA P-384 / P-521 are appended
    // AFTER them for the same reason: they only come into play on servers
    // whose sole host keys use those curves (which could not connect before).
    const KEY: &[Algorithm] = &[
        Algorithm::Ed25519,
        Algorithm::Ecdsa { curve: EcdsaCurve::NistP256 },
        Algorithm::Rsa { hash: Some(HashAlg::Sha512) }, // rsa-sha2-512
        Algorithm::Rsa { hash: Some(HashAlg::Sha256) }, // rsa-sha2-256
        Algorithm::Rsa { hash: None },                  // ssh-rsa (SHA-1), legacy
        Algorithm::Ecdsa { curve: EcdsaCurve::NistP384 },
        Algorithm::Ecdsa { curve: EcdsaCurve::NistP521 },
    ];
    const CIPHER: &[cipher::Name] = &[
        cipher::CHACHA20_POLY1305,
        cipher::AES_256_GCM,
        cipher::AES_256_CTR,
        cipher::AES_192_CTR,
        cipher::AES_128_CTR,
    ];
    const MAC: &[mac::Name] = &[
        mac::HMAC_SHA512_ETM,
        mac::HMAC_SHA256_ETM,
        mac::HMAC_SHA512,
        mac::HMAC_SHA256,
        // Legacy, last resort for old servers.
        mac::HMAC_SHA1_ETM,
        mac::HMAC_SHA1,
    ];
    // No compression preferred (issue #34 — SFTP uploads dropped the session
    // under russh 0.40's zlib; fixed upstream, but compression still only
    // costs CPU on fast links and on already-compressed payloads). zlib stays
    // negotiable for a server that insists on it.
    const COMPRESSION: &[compression::Name] = &[
        compression::NONE,
        compression::ZLIB_LEGACY, // zlib@openssh.com
        compression::ZLIB,
    ];

    russh::Preferred {
        kex: Cow::Borrowed(KEX),
        key: Cow::Borrowed(KEY),
        // Never advertise `*-cert-v01@openssh.com` host-key algorithms: there
        // is no CA trust store, so servers must present their plain host key
        // (TOFU via known_hosts). See ssh_manager::plain_host_key.
        host_key_certificates: Cow::Borrowed(&[]),
        cipher: Cow::Borrowed(CIPHER),
        mac: Cow::Borrowed(MAC),
        compression: Cow::Borrowed(COMPRESSION),
    }
}

/// Bounds for `diffie-hellman-group-exchange-sha256` (issue #33), shared like
/// `ssh_preferred_algorithms`. russh's default minimum is 3072 bits, which
/// aborts the handshake with servers whose moduli (or appliance firmware)
/// only offer 2048-bit groups — typical for DH-GEX-only boxes. OpenSSH's own
/// client accepts 2048 (its DH_GRP_MIN), so we do too, while still asking for
/// 8192 so a server with bigger groups uses one.
pub(crate) fn ssh_gex_params() -> russh::client::GexParams {
    // `new` only rejects min < 2048 or an unordered triple — neither applies
    // (pinned by a unit test); fall back to russh's default rather than panic
    // in the connect path.
    russh::client::GexParams::new(2048, 8192, 8192).unwrap_or_default()
}

/// The health watcher's fallback liveness check, for servers that don't answer
/// keepalive@openssh.com: open a session channel and close it again. Any answer
/// counts as alive — a refusal too, since a MaxSessions-limited server refuses
/// (#29); only a timeout or a dead connection doesn't.
async fn probe_with_channel<H: russh::client::Handler>(h: &russh::client::Handle<H>) -> bool {
    match tokio::time::timeout(std::time::Duration::from_secs(10), h.channel_open_session()).await {
        Ok(Ok(ch)) => {
            // Close cleanly so the server doesn't log a stuck session.
            let _ = ch.close().await;
            true
        }
        Ok(Err(russh::Error::ChannelOpenFailure(_))) => true,
        _ => false,
    }
}

/// The russh client config shared by the primary connection and any ProxyJump
/// hop, so both negotiate an identical algorithm set. Extracted verbatim from
/// the inline block `initiate_connection` used to carry.
fn build_ssh_client_config() -> russh::client::Config {
    let mut config = russh::client::Config::default();
    // No russh protocol keepalive. Its timer is only re-armed once something
    // is sent or received, and before login completes it sends nothing — so
    // ~20s into a host-key / password / 2FA prompt the session task spun a CPU
    // core until the prompt was answered. Idle traffic is covered without it:
    // the session watcher pings every 30s (60s on the dedicated `::sftp` /
    // `::fwd` connections) end to end — well inside the ~2-minute idle limit of
    // consumer NAT and most firewalls — and OS TCP keepalive (see
    // apply_tcp_keepalive) probes the first hop after 30s of silence.
    config.keepalive_interval = None;
    // russh closes the connection after `keepalive_max` unanswered keepalives
    // (default 3, i.e. ~80s of server silence). Kept OFF: liveness is decided
    // by the session watcher (`is_closed()` + its two-strike active probe) and
    // OS TCP keepalive (apply_tcp_keepalive), which are deliberately tolerant
    // of the long latency spikes of poor links.
    config.keepalive_max = 0;
    // Bigger receive window + max-allowed packet size: lets SFTP/tunnel
    // streams keep the BDP full on high-latency links.
    config.window_size = 8 * 1024 * 1024;
    config.maximum_packet_size = 65535;
    // Full algorithm set + DH group-exchange bounds, shared with the monitor.
    config.preferred = ssh_preferred_algorithms();
    config.gex = ssh_gex_params();
    config
}

/// `build_ssh_client_config`, asking `host:port` for the kinds of host key
/// already on file for it first (`prefer_known_host_keys`).
fn build_ssh_client_config_for(
    db: &std::sync::Arc<StdMutex<Option<Connection>>>,
    host: &str,
    port: u16,
) -> russh::client::Config {
    let mut config = build_ssh_client_config();
    if let Ok(guard) = db.lock() {
        if let Some(conn) = guard.as_ref() {
            prefer_known_host_keys(&mut config.preferred, &ssh_manager::known_host_families(conn, host, port));
        }
    }
    config
}

/// Moves the host-key algorithms for kinds of key already on file for a host
/// ahead of the others, each group in its usual order. A server with several
/// host keys then shows the one this device trusts: a host first saved with
/// its RSA key keeps showing that one after it gains an Ed25519 key, instead
/// of an unknown key that would now get the "changed" warning
/// (ssh_manager::judge_host_key).
pub(crate) fn prefer_known_host_keys(preferred: &mut russh::Preferred, families: &[String]) {
    if families.is_empty() {
        return;
    }
    let (known, other): (Vec<_>, Vec<_>) = preferred
        .key
        .iter()
        .cloned()
        .partition(|a| families.contains(&ssh_manager::key_type_family(a.as_str())));
    preferred.key = std::borrow::Cow::Owned(known.into_iter().chain(other).collect());
}

/// Timing caps for the connect driver's prompt-aware handshake timeout.
#[derive(Clone, Copy)]
struct ConnectTimeoutCaps {
    /// The transport + key-exchange handshake must reach a host-key prompt
    /// (or finish outright) within this window. A server that never completes
    /// kex and never prompts is a genuine stall once it elapses.
    handshake: std::time::Duration,
    /// Absolute backstop once a fingerprint prompt is pending. Covers
    /// `ClientHandler::check_server_key`'s own 90s human window (which starts
    /// up to `handshake` seconds into the connect) plus a small teardown
    /// margin, so that 90s wait — not this cap — normally governs a prompt.
    hard: std::time::Duration,
}

/// Production caps: 15s of handshake before a prompt, then the 90s human
/// window plus a 5s teardown margin (15 + 90 + 5 = 110s) as the hard cap.
const CONNECT_TIMEOUT_CAPS: ConnectTimeoutCaps = ConnectTimeoutCaps {
    handshake: std::time::Duration::from_secs(15),
    hard: std::time::Duration::from_secs(15 + 90 + 5),
};

/// Which way the connect driver's deadline falls at a given elapsed time.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ConnectDeadline {
    /// Keep awaiting the handshake.
    Continue,
    /// Past the handshake cap with no prompt shown — a genuine stall.
    HandshakeStall,
    /// A prompt was pending but even the hard cap elapsed — a wedged prompt.
    PromptHardCap,
}

/// Pure timeout decision for the connect driver, factored out so it can be
/// unit-tested without a runtime. `prompt_pending` means a host-key prompt has
/// been shown for this attempt (latched by the caller — see `ClientHandler::
/// prompt_pending`): before any prompt the handshake is held to `caps.handshake`
/// and a stall is reported once it elapses; once a prompt is pending the wait
/// extends to `caps.hard` so the human approval window governs instead.
fn connect_deadline_elapsed(
    prompt_pending: bool,
    elapsed: std::time::Duration,
    caps: ConnectTimeoutCaps,
) -> ConnectDeadline {
    if !prompt_pending {
        if elapsed >= caps.handshake {
            ConnectDeadline::HandshakeStall
        } else {
            ConnectDeadline::Continue
        }
    } else if elapsed >= caps.hard {
        ConnectDeadline::PromptHardCap
    } else {
        ConnectDeadline::Continue
    }
}

/// Why the connect driver stopped awaiting the handshake without a result.
enum ConnectTimeout {
    /// Handshake never reached a host-key prompt within the handshake cap.
    HandshakeStall,
    /// A prompt was pending but the hard cap elapsed before it resolved.
    PromptHardCap,
}

/// Drive `connect_stream` under a prompt-aware deadline. The `handshake` cap
/// bounds only the transport+kex phase BEFORE a host-key fingerprint prompt is
/// shown; the moment `prompt_pending` goes true the wait extends to the hard
/// cap so `check_server_key`'s 90s human window — not a 15s handshake timer —
/// decides a first-time key approval. Returns `Ok(output)` when the handshake
/// future resolves (success OR a russh error), or `Err` on a timeout.
///
/// `prompt_pending` is re-read on a coarse ticker (no busy-spin) and latched:
/// once a prompt has been seen the handshake cap no longer applies for the rest
/// of the attempt, so a user who answers just after the 15s mark — briefly
/// clearing the flag while the handshake finishes — is never mistaken for a
/// stall that would tear down their just-approved connection.
async fn drive_connect_with_prompt_timeout<F, T>(
    connect_future: F,
    prompt_pending: &std::sync::atomic::AtomicBool,
    caps: ConnectTimeoutCaps,
) -> Result<T, ConnectTimeout>
where
    F: std::future::Future<Output = T>,
{
    use std::sync::atomic::Ordering;
    tokio::pin!(connect_future);
    let start = tokio::time::Instant::now();
    // 250ms is far finer than any cap, yet idle between ticks.
    let mut ticker = tokio::time::interval(std::time::Duration::from_millis(250));
    ticker.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Delay);
    ticker.tick().await; // the first tick is immediate — consume it
    let mut prompt_seen = false;
    loop {
        tokio::select! {
            // Biased: always prefer a resolved handshake over a tick, so a
            // connection that completes at the same instant a deadline tick
            // fires is never discarded in favour of a timeout.
            biased;
            out = &mut connect_future => return Ok(out),
            _ = ticker.tick() => {
                prompt_seen |= prompt_pending.load(Ordering::SeqCst);
                match connect_deadline_elapsed(prompt_seen, start.elapsed(), caps) {
                    ConnectDeadline::Continue => {}
                    ConnectDeadline::HandshakeStall => return Err(ConnectTimeout::HandshakeStall),
                    ConnectDeadline::PromptHardCap => return Err(ConnectTimeout::PromptHardCap),
                }
            }
        }
    }
}

#[cfg(test)]
mod connect_timeout_tests {
    use super::{connect_deadline_elapsed, ConnectDeadline, ConnectTimeoutCaps};
    use std::time::Duration;

    // 15s handshake cap, 15 + 90 + 5 = 110s hard cap — the production values.
    const CAPS: ConnectTimeoutCaps = ConnectTimeoutCaps {
        handshake: Duration::from_secs(15),
        hard: Duration::from_secs(110),
    };

    #[test]
    fn no_prompt_holds_the_handshake_cap() {
        // Before 15s: keep waiting when no prompt has shown.
        assert_eq!(
            connect_deadline_elapsed(false, Duration::from_secs(14), CAPS),
            ConnectDeadline::Continue
        );
        // At/after 15s with no prompt → genuine handshake stall.
        assert_eq!(
            connect_deadline_elapsed(false, Duration::from_secs(15), CAPS),
            ConnectDeadline::HandshakeStall
        );
        assert_eq!(
            connect_deadline_elapsed(false, Duration::from_secs(60), CAPS),
            ConnectDeadline::HandshakeStall
        );
    }

    #[test]
    fn pending_prompt_extends_past_the_handshake_cap() {
        // A pending prompt is NOT a stall at the 15s mark — the 90s human
        // window runs on.
        assert_eq!(
            connect_deadline_elapsed(true, Duration::from_secs(15), CAPS),
            ConnectDeadline::Continue
        );
        assert_eq!(
            connect_deadline_elapsed(true, Duration::from_secs(109), CAPS),
            ConnectDeadline::Continue
        );
        // A prompt shown early (fast kex) is likewise well within the hard cap.
        assert_eq!(
            connect_deadline_elapsed(true, Duration::from_secs(2), CAPS),
            ConnectDeadline::Continue
        );
    }

    #[test]
    fn pending_prompt_trips_only_the_hard_cap() {
        // Only once the hard cap elapses does a pending prompt time out — and
        // as PromptHardCap (host-key message), never HandshakeStall.
        assert_eq!(
            connect_deadline_elapsed(true, Duration::from_secs(110), CAPS),
            ConnectDeadline::PromptHardCap
        );
        assert_eq!(
            connect_deadline_elapsed(true, Duration::from_secs(200), CAPS),
            ConnectDeadline::PromptHardCap
        );
    }
}

#[cfg(test)]
mod ssh_config_tests {
    use super::{build_ssh_client_config, prefer_known_host_keys, ssh_preferred_algorithms};
    use crate::ssh_test_server::{connect, connect_with_client, TestClient, TestServer};
    use std::borrow::Cow;
    use std::sync::Arc;

    fn names<T: AsRef<str>>(list: &[T]) -> Vec<String> {
        list.iter().map(|n| n.as_ref().to_string()).collect()
    }

    fn host_key_order(p: &russh::Preferred) -> Vec<String> {
        p.key.iter().map(|a| a.to_string()).collect()
    }

    // The kinds of host key on file for a host are asked for first, each group
    // in its usual order; with nothing on file the list stays as it is.
    #[test]
    fn the_kinds_of_host_key_on_file_are_asked_for_first() {
        let usual = host_key_order(&ssh_preferred_algorithms());
        let mut p = ssh_preferred_algorithms();
        prefer_known_host_keys(&mut p, &[]);
        assert_eq!(host_key_order(&p), usual);

        let mut p = ssh_preferred_algorithms();
        prefer_known_host_keys(&mut p, &["ssh-rsa".to_string()]);
        let order = host_key_order(&p);
        assert_eq!(&order[..4], ["rsa-sha2-512", "rsa-sha2-256", "ssh-rsa", "ssh-ed25519"]);
        assert_eq!(order.len(), usual.len());

        let mut p = ssh_preferred_algorithms();
        prefer_known_host_keys(&mut p, &["ecdsa-sha2-nistp384".to_string(), "ssh-ed25519".to_string()]);
        assert_eq!(&host_key_order(&p)[..3], ["ssh-ed25519", "ecdsa-sha2-nistp384", "ecdsa-sha2-nistp256"]);
    }

    /// Against a real (in-process) server with an Ed25519 and an ECDSA host
    /// key: the usual order gets the Ed25519 one, and with the ECDSA kind on
    /// file for the host, the ECDSA one, which is the key this device trusts.
    #[tokio::test]
    async fn a_server_with_two_host_keys_shows_the_kind_on_file() {
        let ecdsa = russh::keys::PrivateKey::random(
            &mut rand::rng(),
            russh::keys::Algorithm::Ecdsa { curve: russh::keys::EcdsaCurve::NistP256 },
        )
        .unwrap();
        for (on_file, shown) in [(vec![], "ssh-ed25519"), (vec!["ecdsa-sha2-nistp256".to_string()], "ecdsa-sha2-nistp256")] {
            let mut config = build_ssh_client_config();
            prefer_known_host_keys(&mut config.preferred, &on_file);
            let client = TestClient::default();
            let negotiated = Arc::clone(&client.negotiated);
            let ecdsa = ecdsa.clone();
            let _session = connect_with_client(TestServer::default(), move |c| c.keys.push(ecdsa), config, client)
                .await
                .expect("in-process SSH connection");
            let names = negotiated.lock().unwrap().clone().expect("kex done");
            assert_eq!(names.key.to_string(), shown);
        }
    }

    #[test]
    fn client_config_policy() {
        let config = build_ssh_client_config();
        // S1: no keepalive-count disconnect.
        assert_eq!(config.keepalive_max, 0);
        // No russh keepalive timer: before login it spins a CPU core while a
        // prompt waits (see build_ssh_client_config).
        assert!(config.keepalive_interval.is_none());
        // #33: 2048-bit DH-GEX groups accepted, 8192 preferred.
        assert_eq!(config.gex.min_group_size(), 2048);
        assert_eq!(config.gex.preferred_group_size(), 8192);
        assert_eq!(config.gex.max_group_size(), 8192);
        // #34: no compression preferred.
        assert_eq!(names(&config.preferred.compression), ["none", "zlib@openssh.com", "zlib"]);
    }

    #[test]
    fn algorithm_preferences() {
        let p = ssh_preferred_algorithms();
        let kex = names(&p.kex);
        let pos = |n: &str| kex.iter().position(|k| k == n).unwrap_or_else(|| panic!("{n} missing"));
        let gex = pos("diffie-hellman-group-exchange-sha256");
        assert!(pos("mlkem768x25519-sha256") < gex && pos("curve25519-sha256") < gex);
        assert!(gex < pos("diffie-hellman-group14-sha256"));
        // Host keys: the pre-0.63 release order first, so already-pinned hosts
        // keep negotiating the key type whose fingerprint is on file.
        let keys: Vec<String> = p.key.iter().map(|a| a.to_string()).collect();
        assert_eq!(
            keys[..5],
            ["ssh-ed25519", "ecdsa-sha2-nistp256", "rsa-sha2-512", "rsa-sha2-256", "ssh-rsa"]
        );
        // No host certificates advertised (no CA trust store).
        assert!(p.host_key_certificates.is_empty());
    }

    /// Against a real (in-process) server that PREFERS zlib: the client's
    /// order decides, so the connection runs uncompressed (#34); the modern
    /// hybrid KEX is picked when both sides have it.
    #[tokio::test]
    async fn negotiates_no_compression_even_when_the_server_prefers_zlib() {
        use russh::compression::{NONE, ZLIB, ZLIB_LEGACY};
        let client = TestClient::default();
        let negotiated = Arc::clone(&client.negotiated);
        let _session = connect_with_client(
            TestServer::default(),
            |c| {
                c.preferred = russh::Preferred {
                    compression: Cow::Borrowed(&[ZLIB_LEGACY, ZLIB, NONE]),
                    ..russh::Preferred::default()
                };
            },
            build_ssh_client_config(),
            client,
        )
        .await
        .expect("in-process SSH connection");
        let names = negotiated.lock().unwrap().clone().expect("kex done");
        assert_eq!(format!("{:?}", names.client_compression), "None");
        assert_eq!(format!("{:?}", names.server_compression), "None");
        assert_eq!(names.kex.as_ref(), "mlkem768x25519-sha256");
    }

    /// #33: a server that ONLY does diffie-hellman-group-exchange-sha256 and
    /// only has 2048-bit groups. russh's stock bounds (min 3072) refuse it;
    /// ours connect.
    #[tokio::test]
    async fn dh_gex_only_server_with_2048_bit_groups_connects() {
        let dh_gex_only = |c: &mut russh::server::Config| {
            c.preferred = russh::Preferred {
                kex: Cow::Borrowed(&[russh::kex::DH_GEX_SHA256]),
                ..russh::Preferred::default()
            };
        };
        let server = TestServer::with_gex_group(russh::kex::dh::groups::DH_GROUP14);
        let client = TestClient::default();
        let negotiated = Arc::clone(&client.negotiated);
        tokio::time::timeout(
            std::time::Duration::from_secs(60),
            connect_with_client(server.clone(), dh_gex_only, build_ssh_client_config(), client),
        )
        .await
        .expect("handshake must finish")
        .expect("DH-GEX with a 2048-bit group must be accepted");
        let names = negotiated.lock().unwrap().clone().expect("kex done");
        assert_eq!(names.kex.as_ref(), "diffie-hellman-group-exchange-sha256");

        let mut stock = build_ssh_client_config();
        stock.gex = russh::client::GexParams::default();
        let refused = tokio::time::timeout(
            std::time::Duration::from_secs(60),
            connect(server, dh_gex_only, stock),
        )
        .await
        .expect("handshake must finish");
        assert!(refused.is_err(), "control: russh's default 3072-bit minimum refuses this server");
    }
}

/// Minimal auth/identity resolver for a ProxyJump bastion. Mirrors the
/// vault-vs-custom / credential-join / key-loading rules of the main connect
/// path but returns only what a jump hop needs (host, port, user, password,
/// optional key). Deliberately kept separate from `initiate_connection`'s
/// inline resolver so the primary connection path is byte-for-byte untouched.
/// It never reads `jump_host_id`, which makes ProxyJump strictly single-hop —
/// there is no way for it to recurse.
///
/// Runs fully synchronously (no `.await`) so the non-`Send` rusqlite
/// `Connection` never has to be held across a suspension point.
fn resolve_jump_auth(
    conn: &rusqlite::Connection,
    server_id: i32,
) -> Result<
    // host, port, user, password, (private_key, passphrase, key_name)
    Option<(String, i32, String, Option<String>, Option<(String, Option<String>, Option<String>)>)>,
    String,
> {
    let mut stmt = conn
        .prepare(
            "
            SELECT s.host, s.port,
                   s.username as s_user, c.username as c_user,
                   s.password as s_pass, c.password as c_pass,
                   s.key_id   as s_key,  c.key_id   as c_key,
                   s.auth_type, c.auth_type as cred_auth_type
            FROM servers s
            LEFT JOIN credentials c ON s.credential_id = c.id
            WHERE s.id=?1
        ",
        )
        .map_err(|e| e.to_string())?;
    let mut rows = stmt.query([server_id]).map_err(|e| e.to_string())?;
    let row = match rows.next().map_err(|e| e.to_string())? {
        Some(r) => r,
        None => return Ok(None),
    };
    let host: String = row.get::<_, String>(0).map_err(|e| format!("[DB] jump host: {}", e))?;
    let port: i32 = row.get::<_, i32>(1).map_err(|e| format!("[DB] jump port: {}", e))?;
    let s_user: Option<String> = row.get::<_, Option<String>>(2).unwrap_or_default();
    let c_user: Option<String> = row.get::<_, Option<String>>(3).unwrap_or_default();
    let s_pass: Option<String> = row.get::<_, Option<String>>(4).unwrap_or_default();
    let c_pass: Option<String> = row.get::<_, Option<String>>(5).unwrap_or_default();
    let s_key: Option<i32> = row.get::<_, Option<i32>>(6).unwrap_or_default();
    let c_key: Option<i32> = row.get::<_, Option<i32>>(7).unwrap_or_default();
    let server_auth_type: String = row
        .get::<_, Option<String>>(8)
        .unwrap_or_default()
        .unwrap_or_else(|| "vault".to_string());
    let cred_auth_type: Option<String> = row.get::<_, Option<String>>(9).unwrap_or_default();

    let (username, password, key_id) = if server_auth_type == "vault" {
        (c_user.unwrap_or_default(), c_pass, c_key)
    } else {
        (s_user.unwrap_or_default(), s_pass, s_key)
    };
    let effective_key_id = if server_auth_type == "vault" {
        if cred_auth_type.as_deref() == Some("key") { key_id } else { None }
    } else if server_auth_type == "custom_key" {
        key_id
    } else {
        None
    };
    let key_data = if let Some(kid) = effective_key_id {
        let mut key_stmt = conn
            .prepare("SELECT private_key, passphrase, name FROM ssh_keys WHERE id = ?1")
            .map_err(|e| e.to_string())?;
        let mut key_rows = key_stmt.query([kid]).map_err(|e| e.to_string())?;
        if let Some(key_row) = key_rows.next().map_err(|e| e.to_string())? {
            let private_key: String = key_row.get::<_, String>(0).map_err(|e| e.to_string())?;
            let passphrase: Option<String> = key_row.get::<_, Option<String>>(1).map_err(|e| e.to_string())?;
            let key_name: Option<String> = key_row.get::<_, Option<String>>(2).unwrap_or_default();
            Some((private_key, passphrase, key_name))
        } else {
            None
        }
    } else {
        None
    };

    Ok(Some((host, port, username, password, key_data)))
}

/// Establish + authenticate an SSH connection to a ProxyJump intermediate
/// ("bastion") host and return its live `Handle`. The caller opens a
/// `direct-tcpip` channel over this handle to reach the real target, then keeps
/// the handle alive for the target session's lifetime (see
/// `SshState::jump_connections`).
///
/// The bastion is reached by a DIRECT TCP connection — its own proxy config, if
/// any, is not honored (bastions are normally directly reachable). Its host key
/// is verified through the SAME frontend prompt as the target (events emitted
/// under the target's `session_id`, keyed by a distinct nonce), and it supports
/// the full key → password → keyboard-interactive auth ladder.
#[allow(clippy::too_many_arguments)]
async fn connect_jump_host(
    app: &tauri::AppHandle,
    db: &std::sync::Arc<std::sync::Mutex<Option<rusqlite::Connection>>>,
    fp_txs: &std::sync::Arc<
        tokio::sync::Mutex<std::collections::HashMap<String, tokio::sync::oneshot::Sender<bool>>>,
    >,
    kbi_txs: &std::sync::Arc<
        tokio::sync::Mutex<
            std::collections::HashMap<String, tokio::sync::oneshot::Sender<Option<Vec<String>>>>,
        >,
    >,
    // Per-tab prompted-secret cache + whether this connection may prompt at all
    // (true only for a primary target; secondaries reuse the cache). Issue #30.
    cache: &PromptedSecretsMap,
    allow_prompt: bool,
    // Set when the bastion login itself failed (rejected or cancelled), so the
    // caller reports an auth error — auto-reconnect then stops instead of
    // re-prompting every few seconds.
    auth_failed: &std::sync::atomic::AtomicBool,
    // The target session's connect attempt; the bastion's prompts belong to it.
    attempt: &ssh_manager::ConnectAttempt,
    session_id: &str,
    jump_server_id: i32,
) -> Result<russh::client::Handle<ssh_manager::ClientHandler>, String> {
    use tokio::time::Duration;
    use tauri::Emitter;

    let log = |msg: &str, ty: &str| {
        println!("[LOG-{}] [jump] {}", session_id, msg);
        // A superseded attempt stays out of the tab's log.
        if !attempt.is_current_now() {
            return;
        }
        let _ = app.emit(
            &format!("session-log-{}", session_id),
            serde_json::json!({"msg": msg, "type": ty}),
        );
    };

    // 1. Resolve the bastion's config synchronously and drop the DB guard
    //    before any await (rusqlite Connection is not Send).
    let (host, port, user, password, key_data) = {
        let guard = db.lock().map_err(|_| "[STATE] LOCK_FAILED".to_string())?;
        let conn = guard
            .as_ref()
            .ok_or_else(|| "[STATE] DATABASE_NOT_INITIALIZED".to_string())?;
        match resolve_jump_auth(conn, jump_server_id)? {
            Some(v) => v,
            None => return Err("未找到跳板机".into()),
        }
    };
    // A blank bastion username is resolved after the handshake (issue #54).
    let saved_user = user.trim().to_string();

    // 2. Direct TCP to the bastion.
    log(&format!("Connecting to jump host {}:{}...", host, port), "info");
    let tcp = match tokio::time::timeout(
        Duration::from_secs(10),
        tokio::net::TcpStream::connect((host.as_str(), port as u16)),
    )
    .await
    {
        Ok(Ok(s)) => {
            let _ = s.set_nodelay(true);
            apply_tcp_keepalive(&s);
            s
        }
        Ok(Err(e)) => return Err(humanize_network_err(&e.to_string(), &host, port, "Jump host connection")),
        Err(_) => return Err(format!("jump host {}:{} did not respond within 10 seconds", host, port)),
    };

    // 3. Host-key round-trip: own nonce, shared fp_txs map + frontend session.
    let (fp_tx, fp_rx) = tokio::sync::oneshot::channel();
    let jump_nonce: String = {
        let mut bytes = [0u8; 16];
        rand::rng().fill_bytes(&mut bytes);
        hex::encode(bytes)
    };
    fp_txs.lock().await.insert(jump_nonce.clone(), fp_tx);
    let fp_outcome = std::sync::Arc::new(std::sync::atomic::AtomicI8::new(-1));
    // Shared with the connect driver so the 15s handshake cap doesn't kill a
    // first-time key prompt on the bastion — see the direct path's rationale.
    let prompt_pending = std::sync::Arc::new(std::sync::atomic::AtomicBool::new(false));
    let prompt_pending_for_driver = std::sync::Arc::clone(&prompt_pending);

    let handler = ssh_manager::ClientHandler {
        app: app.clone(),
        session_id: session_id.to_string(),
        connect_nonce: jump_nonce.clone(),
        server_host: host.clone(),
        server_port: port as u16,
        db: std::sync::Arc::clone(db),
        fp_rx: Some(fp_rx),
        forwarded_targets: std::sync::Arc::new(tokio::sync::Mutex::new(std::collections::HashMap::new())),
        fp_outcome,
        prompt_pending,
        // Dedicated `::sftp` / `::fwd` connections carry a `::` suffix and
        // have no prompt of their own (see ClientHandler::prompt_allowed).
        prompt_allowed: !session_id.contains("::"),
        attempt: attempt.clone(),
        // The watcher probes the session, not the bastion hop.
        last_heard: ssh_manager::LastHeard::default(),
    };

    // 4. Handshake.
    let config = std::sync::Arc::new(build_ssh_client_config_for(db, &host, port as u16));
    log("Jump host: SSH handshake...", "info");
    // The 15s handshake cap bounds only the pre-prompt transport+kex phase;
    // once check_server_key shows a first-time fingerprint prompt the wait
    // extends to the hard cap so the 90s human window — not this timer — rules.
    let connect_res = drive_connect_with_prompt_timeout(
        russh::client::connect_stream(config, tcp, handler),
        &prompt_pending_for_driver,
        CONNECT_TIMEOUT_CAPS,
    )
    .await;
    // Given up on: russh's handshake task may still reach the host-key check
    // later, and must not prompt for an attempt nobody is waiting on.
    if connect_res.is_err() {
        attempt.abandon();
    }
    // The host-key prompt (if any) is resolved by now — drop the sender.
    fp_txs.lock().await.remove(&jump_nonce);

    let mut session = match connect_res {
        Ok(Ok(s)) => s,
        Ok(Err(e)) => return Err(format!("jump host handshake failed: {}", e)),
        Err(ConnectTimeout::HandshakeStall) => return Err("跳板机握手超时".into()),
        Err(ConnectTimeout::PromptHardCap) => {
            return Err("跳板机主机密钥提示超时——请重新连接并在 90 秒内确认指纹".into())
        }
    };

    // 5. Auth ladder: key → password → keyboard-interactive. A bastion saved
    //    with no secret is prompted for here too (primary target only), cached
    //    under the target tab's JumpPassword / JumpPassphrase slot (issue #30),
    //    keyed by this bastion so its secrets never reach another host.
    let base_id = format!(
        "{}|jump{}|{}:{}|{}",
        base_session_id(session_id),
        jump_server_id,
        host,
        port,
        user.trim()
    );
    let prompt_ctx = SecretPromptCtx {
        app,
        session_id,
        nonce: &jump_nonce,
        kbi_txs,
        cache,
        base: &base_id,
        allow_prompt,
        attempt,
        cancelled: std::sync::atomic::AtomicBool::new(false),
    };
    let (effective_user, user_prompted, login_cancelled) =
        match resolve_login_user(&saved_user, &host, SecretSlot::JumpUsername, &prompt_ctx).await {
            Some((name, typed)) => (name, typed, false),
            None => (Zeroizing::new(String::new()), false, true),
        };
    let mut auth_res = if login_cancelled {
        Ok(false)
    } else if let Some((private_key, passphrase, key_name)) = key_data {
        log("Jump host: private key authentication...", "info");
        let key_label = key_name
            .filter(|n| !n.trim().is_empty())
            .unwrap_or_else(|| format!("{}@{}", effective_user.as_str(), host));
        authenticate_key_prompting(
            &mut session,
            &effective_user,
            &private_key,
            &key_label,
            passphrase.map(Zeroizing::new),
            SecretSlot::JumpPassphrase,
            &prompt_ctx,
        )
        .await
    } else {
        log("Jump host: password authentication...", "info");
        authenticate_password_prompting(
            &mut session,
            &effective_user,
            &host,
            None,
            password.map(Zeroizing::new),
            SecretSlot::JumpPassword,
            &prompt_ctx,
        )
        .await
    };

    // A declined prompt ends the hop — don't fall back to asking again.
    if !matches!(auth_res, Ok(true)) && !prompt_ctx.cancelled.load(std::sync::atomic::Ordering::Relaxed) {
        if let Some(kbi_res) =
            run_keyboard_interactive(&mut session, &effective_user, app, session_id, &jump_nonce, kbi_txs, attempt).await
        {
            auth_res = kbi_res;
        }
    }
    // Belt-and-suspenders: no dangling interactive sender for this hop.
    kbi_txs.lock().await.remove(&jump_nonce);

    if user_prompted && matches!(auth_res, Ok(true)) {
        cache_store_secret(cache, &base_id, SecretSlot::JumpUsername, effective_user.clone()).await;
    }

    match auth_res {
        Ok(true) => {
            log("Jump host authenticated.", "success");
            Ok(session)
        }
        Ok(false) if prompt_ctx.cancelled.load(std::sync::atomic::Ordering::Relaxed) => {
            auth_failed.store(true, std::sync::atomic::Ordering::Relaxed);
            Err("跳板机登录已取消".into())
        }
        Ok(false) => {
            auth_failed.store(true, std::sync::atomic::Ordering::Relaxed);
            Err("跳板机认证失败".into())
        }
        Err(e) => {
            if classify_russh_error(&e).is_auth() {
                auth_failed.store(true, std::sync::atomic::Ordering::Relaxed);
            }
            Err(format!("jump host auth error: {}", e))
        }
    }
}

/// Fully tear down ONE connection map-entry by its exact key. Used to reap the
/// dedicated `::sftp` / `::fwd` secondary connections the separate-sessions
/// feature spins up, so disconnecting or reconnecting the PRIMARY never orphans
/// them (a leaked secondary would hold a live TCP + SSH session forever). Safe
/// to call on a key that doesn't exist — every step is then a no-op. Bumps the
/// key's generation so the secondary's own health watcher observes the change on
/// its next tick and bows out WITHOUT emitting a `session-disconnected-{key}`.
async fn teardown_connection_key(state: &SshState, mirrors: &MirrorMap, key: &str) {
    // Bump the generation FIRST — before removing the connection — so a connect
    // worker for this key that's still handshaking observes the newer value at
    // its "still wanted?" registration guard and bails instead of registering a
    // zombie. (Worker holds the generation lock across its check+insert, and we
    // bump-then-remove here, so the two orderings can't leave a stray entry.)
    {
        let mut g = state.session_generation.lock().await;
        let next = g.get(key).copied().unwrap_or(0).wrapping_add(1);
        g.insert(key.to_string(), next);
    }
    // Stop forwarders first so their listener sockets release before the SSH
    // handle drops — same ordering rationale as disconnect_session.
    tunnel::stop_all_for_session(&state.tunnels, key).await;
    state.forwarded_targets.lock().await.remove(key);
    state.session_tunnel_specs.lock().await.remove(key);
    mirror::stop_all_for_session(mirrors, key).await;
    state.sftp_sessions.lock().await.remove(key);
    // The base session's cached SFTP subsystem may be riding this dedicated
    // `::sftp` transport — drop it so the next file op re-opens on whatever
    // transport remains instead of erroring on a closed channel.
    if let Some(base) = key.strip_suffix("::sftp") {
        state.sftp_sessions.lock().await.remove(base);
    }
    state.connections.lock().await.remove(key);
    state.jump_connections.lock().await.remove(key);
    // Wipe temp files the secondary's SFTP downloads / drags left behind.
    for dir in [session_sftp_dir(key), session_drag_dir(key)].into_iter().flatten() {
        if dir.exists() {
            let _ = std::fs::remove_dir_all(&dir);
        }
    }
}

#[tauri::command]
async fn initiate_connection(
    app: tauri::AppHandle,
    state: tauri::State<'_, SshState>,
    db_state: tauri::State<'_, DbState>,
    mirrors: tauri::State<'_, MirrorMap>,
    session_id: String,
    server_id: i32,
    custom_password: Option<String>,
    quick_auth: Option<QuickAuth>,
    // Separate-sessions feature (default OFF). `session_role` marks whether this
    // is the primary terminal connection ("primary", the default) or a dedicated
    // secondary connection carved off for SFTP ("sftp") or port-forwarding
    // ("forward"). `separate_sessions` is only meaningful on the PRIMARY call: it
    // tells the primary to NOT auto-start the saved tunnels itself, because the
    // dedicated "forward" connection (opened by the frontend right after) will.
    // See the connection topology notes near the auth block below.
    session_role: Option<String>,
    separate_sessions: Option<bool>,
) -> Result<(), String> {
    use tauri::Emitter;
    use tokio::time::Duration;
    use russh::client;
    use std::sync::Arc;
    use tokio::sync::Mutex;

    // Connection role + topology flags. Kept as plain locals so the whole
    // function (worker included) can branch on them without re-parsing.
    let role: String = session_role
        .as_deref()
        .map(str::to_string)
        .unwrap_or_else(|| "primary".to_string());
    let is_secondary = role != "primary";
    let separate = separate_sessions.unwrap_or(false);
    // Only the PRIMARY drives interactive keyboard-interactive (2FA) auth. A
    // secondary connection that hit a 2FA challenge would emit a `kbi-prompt`
    // the UI isn't wired to answer for the suffixed session id, so it would just
    // hang. Instead we let the secondary fail its auth and the frontend falls
    // back to routing SFTP / forwarding over the primary connection.
    let allow_kbi = !is_secondary;
    // Which connection auto-starts this server's saved tunnels inline:
    //   - primary + shared mode    → yes (unchanged legacy behaviour)
    //   - primary + separate mode  → no  (the "forward" connection takes over)
    //   - "forward" secondary      → never inline; it runs the MIGRATION block
    //     instead (stop anything running under the base tag, then restart the
    //     full replay list on itself, still tagged under the base session id)
    //   - "sftp" secondary         → no
    let start_tunnels_inline = role == "primary" && !separate;

    println!("[BACKEND] initiate_connection invoked for session_id: {} (role: {}, separate: {}), server_id: {}", session_id, role, separate, server_id);

    // Reconnect path: if a previous session under this id is still registered,
    // tear it down before starting the fresh handshake. Without this, the
    // duplicate-detection early-return below would silently drop every
    // reconnect attempt and the UI would just sit on "connecting…" forever.
    // Tunnels + forwarded_targets get the same treatment further down via the
    // stop_all_for_session call, so we don't duplicate that here.
    {
        let mut conns = state.connections.lock().await;
        if conns.remove(&session_id).is_some() {
            println!("[BACKEND] Tearing down stale session for reconnect: {}", session_id);
        }
    }
    // Drop any ProxyJump bastion handle from a prior attempt — dropping it
    // closes the old jump connection so the reconnect opens a fresh one.
    state.jump_connections.lock().await.remove(&session_id);
    state.sftp_sessions.lock().await.remove(&session_id);
    // Terminal IDs are `${session_id}-term-N` (see SessionView.tsx), so we
    // sweep every PTY task tied to the old handle. Match by the exact
    // `${session_id}-term-` prefix so id `session-1` doesn't sweep the
    // terminals of `session-10`, `session-11`, ... — a `contains`-based
    // match here silently tore down unrelated live sessions once server
    // IDs (which are SQLite autoincrement ints) crossed 10.
    let term_prefix = format!("{}-term-", session_id);
    state.terminal_txs.lock().await.retain(|k, _| !k.starts_with(&term_prefix));
    state.resize_txs.lock().await.retain(|k, _| !k.starts_with(&term_prefix));
    // Bump the generation so any watcher task still alive from the prior
    // attempt sees a newer value next tick and bails silently instead of
    // racing the new connect to emit `session-disconnected-{id}`.
    let connect_generation: u64 = {
        let mut g = state.session_generation.lock().await;
        let next = g.get(&session_id).copied().unwrap_or(0).wrapping_add(1);
        g.insert(session_id.clone(), next);
        next
    };
    // This attempt, as its prompts and failure report see it: once a newer
    // attempt starts (or the tab disconnects) they stay quiet.
    let attempt = ssh_manager::ConnectAttempt::new(
        Arc::clone(&state.session_generation),
        session_id.clone(),
        connect_generation,
    );

    println!("[BACKEND] No duplicates found. Registering oneshot channel and spawning connection worker...");
    let (fp_tx, fp_rx) = tokio::sync::oneshot::channel();
    // Random per-connect nonce — keys the fp_txs map so a stale `accept`
    // for one attempt (frontend bug, malicious IPC call, retry race)
    // cannot satisfy the prompt of a fresh connection. Hex over 16 bytes
    // = 128 bits of entropy, plenty for a single-use guard.
    let connect_nonce: String = {
        let mut bytes = [0u8; 16];
        rand::rng().fill_bytes(&mut bytes);
        hex::encode(bytes)
    };
    // NB: the fp_txs insert is deliberately deferred until AFTER the DB
    // resolution below. The resolution block has several `?` early-returns; if
    // we inserted here, any of them would return before the worker (which owns
    // the FpCleanupGuard) is spawned, orphaning the sender in the map forever.

    let session_id_clone = session_id.clone();
    let state_connections = Arc::clone(&state.connections);
    let state_sftp_sessions = Arc::clone(&state.sftp_sessions);
    let state_tunnels = Arc::clone(&state.tunnels);
    let state_session_tunnel_specs = Arc::clone(&state.session_tunnel_specs);
    let state_session_generation = Arc::clone(&state.session_generation);
    let fp_txs_clone = Arc::clone(&state.fp_txs);
    let kbi_txs_clone = Arc::clone(&state.kbi_txs);
    // Per-tab cache of secrets the user types at connect time (issue #30), so a
    // reconnect / dedicated secondary reuses them without re-prompting.
    let prompted_secrets_clone = Arc::clone(&state.prompted_secrets);
    let state_jump_connections = Arc::clone(&state.jump_connections);
    // Second Arc into the DB for the ProxyJump hop — the handler below moves
    // the primary `db_conn_shared`, and the spawned worker needs its own owned
    // handle to resolve the bastion's credentials.
    let db_for_jump = Arc::clone(&db_state.conn);
    let db_conn_shared = Arc::clone(&db_state.conn);

    // Reconnect path: tear down any stale listeners + R-tunnel registrations
    // bound to this session_id. Without this, the old TCP listener stays bound
    // to the local port, the new start_tunnel below hits a bind conflict, and
    // every existing tunnel silently routes traffic into a dead SSH handle.
    // First-connect is a no-op (no entries to remove).
    tunnel::stop_all_for_session(&state.tunnels, &session_id).await;
    state.forwarded_targets.lock().await.remove(&session_id);
    // Same story for mirrors — a reconnect must not inherit a mirror worker
    // that still holds an Arc<SftpSession> pointing at the DEAD handle from
    // the previous attempt. Without this the reconnected session appears
    // fine but the mirror keeps writing upload-fail logs against the old
    // socket forever, and manual Stop is the only way to clear it.
    mirror::stop_all_for_session(&mirrors, &session_id).await;

    // Separate-sessions: a PRIMARY (re)connect must reap any stale dedicated
    // `::sftp` / `::fwd` connections from a previous attempt, so the frontend can
    // re-open fresh ones after this success. Gated to the primary so a secondary
    // connect doesn't try to sweep its own (non-existent) grandchildren. Skipped
    // entirely for keys that already carry a `::` suffix (i.e. this IS a
    // secondary), and a plain no-op on first connect / shared mode.
    if !is_secondary {
        teardown_connection_key(state.inner(), mirrors.inner(), &format!("{}::sftp", session_id)).await;
        teardown_connection_key(state.inner(), mirrors.inner(), &format!("{}::fwd", session_id)).await;
    } else {
        // Dedicated-transport reconnect (manual button / auto-retry) OVER a
        // still-live old handle: the base-tagged tunnels ride this transport and
        // the base SFTP cache points at it, so release them before the new
        // handshake. Otherwise, if the fresh attempt fails, the old tunnels keep
        // running on a connection nobody watches (zombie) and file ops hit a
        // dead subsystem. Mirrors disconnect_session's dedicated-transport hooks.
        if let Some(base) = session_id.strip_suffix("::fwd") {
            tunnel::stop_all_for_session(&state.tunnels, base).await;
        }
        if let Some(base) = session_id.strip_suffix("::sftp") {
            state.sftp_sessions.lock().await.remove(base);
        }
    }

    // Per-session map for R-tunnel target lookups. Created here so the same
    // Arc can be handed to both the ClientHandler (consulted on incoming
    // forwarded-tcpip channels) and to tunnel::start_tunnel (which writes the
    // mapping when a remote tunnel is set up).
    let session_forwarded_targets: tunnel::ForwardedTargets =
        Arc::new(tokio::sync::Mutex::new(std::collections::HashMap::new()));
    state.forwarded_targets.lock().await.insert(
        session_id.clone(),
        Arc::clone(&session_forwarded_targets),
    );

    // Quick connect bypasses the DB lookup entirely — we fabricate the
    // same tuple shape from the inline values so all downstream code
    // (auth, tunnel-start, handler setup) doesn't need to branch.
    let db_res = if let Some(q) = quick_auth.as_ref() {
        let key_data = q.private_key
            .clone()
            .filter(|s| !s.trim().is_empty())
            // Third element is the key name for the passphrase prompt label —
            // Quick Connect keys are nameless, so None.
            .map(|pk| (pk, q.passphrase.clone(), None::<String>));
        let auth_type = if key_data.is_some() { "custom_key" } else { "custom_pass" };
        Some((
            q.host.clone(),
            q.port,
            q.username.clone(),
            q.password.clone(),
            key_data,
            "none".to_string(),         // proxy_type — no proxy in quick mode
            None,                       // proxy_host
            None,                       // proxy_port
            auth_type.to_string(),      // server_auth_type
            None,                       // cred_auth_type (unused for custom_*)
            None,                       // db_key_id (debug-log only)
            None,                       // effective_key_id (auth code branches on key_data, not this)
            "[]".to_string(),           // tunnels_json — no auto-start tunnels
            None,                       // jump_host_id — quick connect never bounces through a bastion
        ))
    } else {
    // Fetch DB record inside a nested block to drop non-Send Rows/Statement before any await
    {
        let conn_guard = db_state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
        let conn = conn_guard.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;
        
        // Pull both server-side and credential-side identity fields separately
        // and resolve in Rust. The previous COALESCE was order-of-precedence
        // magic that hid the actual rule from anyone reading the SQL — now the
        // rule is "vault mode → credential fields; custom_* mode → node fields"
        // and nothing else can mix the two.
        let mut stmt = conn.prepare("
            SELECT s.host, s.port,
                   s.username as s_user, c.username as c_user,
                   s.password as s_pass, c.password as c_pass,
                   s.key_id   as s_key,  c.key_id   as c_key,
                   s.proxy_type, s.proxy_host, s.proxy_port,
                   s.auth_type, c.auth_type as cred_auth_type, s.tunnels,
                   s.jump_host_id
            FROM servers s
            LEFT JOIN credentials c ON s.credential_id = c.id
            WHERE s.id=?1
        ").map_err(|e| e.to_string())?;

        let mut rows = stmt.query([server_id]).map_err(|e| e.to_string())?;
        if let Some(row) = rows.next().map_err(|e| e.to_string())? {
            // host/port are NOT NULL in the schema, but propagating
            // errors instead of `.unwrap()` means a manual DB edit or a
            // future schema relaxation can never silently panic the
            // spawned connection worker — the user gets a clean error.
            let host: String = row.get::<_, String>(0).map_err(|e| format!("[DB] host: {}", e))?;
            let port: i32 = row.get::<_, i32>(1).map_err(|e| format!("[DB] port: {}", e))?;
            let s_user: Option<String> = row.get::<_, Option<String>>(2).unwrap_or_default();
            let c_user: Option<String> = row.get::<_, Option<String>>(3).unwrap_or_default();
            let s_pass: Option<String> = row.get::<_, Option<String>>(4).unwrap_or_default();
            let c_pass: Option<String> = row.get::<_, Option<String>>(5).unwrap_or_default();
            let s_key:  Option<i32>    = row.get::<_, Option<i32>>(6).unwrap_or_default();
            let c_key:  Option<i32>    = row.get::<_, Option<i32>>(7).unwrap_or_default();
            let proxy_type: String = row.get::<_, Option<String>>(8).unwrap_or_default().unwrap_or_else(|| "none".to_string());
            let proxy_host: Option<String> = row.get::<_, Option<String>>(9).unwrap_or_default();
            let proxy_port: Option<i32> = row.get::<_, Option<i32>>(10).unwrap_or_default();
            let server_auth_type: String = row.get::<_, Option<String>>(11).unwrap_or_default().unwrap_or_else(|| "vault".to_string());
            let cred_auth_type: Option<String> = row.get::<_, Option<String>>(12).unwrap_or_default();
            let tunnels_json: String = row.get::<_, Option<String>>(13).unwrap_or_default().unwrap_or_else(|| "[]".to_string());
            // Forwards someone else added in a shared profile, not yet allowed
            // on this device, come in stopped (see approvals.rs).
            let tunnels_json = approvals::hold_tunnels_json(conn, server_id as i64, tunnels_json);
            let jump_host_id: Option<i32> = row.get::<_, Option<i32>>(14).unwrap_or_default();

            // Single source of truth per auth_type — no field mixing.
            // - vault: identity comes ENTIRELY from the credential row. Any
            //   stale username/password/key on the node row is ignored.
            // - custom_pass / custom_key: identity comes ENTIRELY from the
            //   node row.
            let (username, password, key_id) = if server_auth_type == "vault" {
                (c_user.unwrap_or_default(), c_pass, c_key)
            } else {
                (s_user.unwrap_or_default(), s_pass, s_key)
            };

            // Whether to actually load a key file:
            // - vault: only if the chosen credential is itself key-typed
            // - custom_key: yes, use the node's selected key
            // - custom_pass: no
            let effective_key_id = if server_auth_type == "vault" {
                if cred_auth_type.as_deref() == Some("key") { key_id } else { None }
            } else if server_auth_type == "custom_key" {
                key_id
            } else {
                None
            };

            // Fetch key details if a key is needed
            let key_data = if let Some(kid) = effective_key_id {
                let mut key_stmt = conn.prepare("SELECT private_key, passphrase, name FROM ssh_keys WHERE id = ?1").map_err(|e| e.to_string())?;
                let mut key_rows = key_stmt.query([kid]).map_err(|e| e.to_string())?;
                if let Some(key_row) = key_rows.next().map_err(|e| e.to_string())? {
                    let private_key: String = key_row.get::<_, String>(0).map_err(|e| e.to_string())?;
                    let passphrase: Option<String> = key_row.get::<_, Option<String>>(1).map_err(|e| e.to_string())?;
                    // Name is for the "Passphrase for key '<name>'" prompt label.
                    let key_name: Option<String> = key_row.get::<_, Option<String>>(2).unwrap_or_default();
                    Some((private_key, passphrase, key_name))
                } else {
                    None
                }
            } else {
                None
            };

            Some((host, port, username, password, key_data, proxy_type, proxy_host, proxy_port, server_auth_type, cred_auth_type, key_id, effective_key_id, tunnels_json, jump_host_id))
        } else {
            None
        }
    }
    };

    let (host, port, user, password, key_data, proxy_type, proxy_host, proxy_port, server_auth_type, cred_auth_type, db_key_id, effective_key_id, tunnels_json, jump_host_id) = match db_res {
        Some(val) => val,
        None => {
            return Err("未找到服务器".into());
        }
    };

    // DB resolution succeeded — now register the fingerprint sender. From here
    // on the worker is always spawned, so its FpCleanupGuard guarantees this
    // entry is removed even on the failure paths.
    state.fp_txs.lock().await.insert(connect_nonce.clone(), fp_tx);

    // What this connection logs in to, as part of its prompted-secret cache
    // key (issue #30): a password or passphrase typed for one target is never
    // offered to another. Editing an open tab's host, user, key or bastion — or
    // another profile reusing the same tab id — starts from an empty entry.
    let secrets_target = format!(
        "{}:{}|{}|{}|{:?}|{:?}",
        host, port, user.trim(), server_auth_type, effective_key_id, jump_host_id
    );

    // Shared between the handler and the connect driver so we can tell host-
    // key timeouts apart from real auth errors on the failure path. See
    // ClientHandler::fp_outcome for the meaning of the values.
    let fp_outcome = std::sync::Arc::new(std::sync::atomic::AtomicI8::new(-1));
    let fp_outcome_for_driver = std::sync::Arc::clone(&fp_outcome);
    // Shared the same way as fp_outcome: the handler flips it while a host-key
    // prompt is pending so the connect driver can extend its 15s handshake cap
    // to cover the human approval window instead of killing the prompt.
    let prompt_pending = std::sync::Arc::new(std::sync::atomic::AtomicBool::new(false));
    let prompt_pending_for_driver = std::sync::Arc::clone(&prompt_pending);
    // Stamped by the handler whenever the server sends something; read by the
    // session watcher below.
    let last_heard = ssh_manager::LastHeard::default();

    // Built here, while the database handle is still ours: the handshake
    // asks this host for the kinds of host key on file for it first.
    let client_config = Arc::new(build_ssh_client_config_for(&db_conn_shared, &host, port as u16));
    let handler = ssh_manager::ClientHandler {
        app: app.clone(),
        session_id: session_id.clone(),
        connect_nonce: connect_nonce.clone(),
        server_host: host.clone(),
        server_port: port as u16,
        db: db_conn_shared,
        fp_rx: Some(fp_rx),
        forwarded_targets: Arc::clone(&session_forwarded_targets),
        fp_outcome: std::sync::Arc::clone(&fp_outcome),
        prompt_pending: std::sync::Arc::clone(&prompt_pending),
        prompt_allowed: !is_secondary,
        attempt: attempt.clone(),
        last_heard: last_heard.clone(),
    };

    let cleanup_nonce = connect_nonce.clone();
    // Own an Arc into MirrorMap so the outer spawn (which requires 'static)
    // doesn't try to borrow the caller's `mirrors: State<'_, MirrorMap>`.
    // The Arc is 'static; the State reference is not.
    let mirrors_owned: MirrorMap = mirrors.inner().clone();

    tauri::async_runtime::spawn(async move {
        println!("[BACKEND WORKER] Started connection worker thread for session: {}", session_id_clone);

        struct FpCleanupGuard {
            fp_txs: Arc<Mutex<std::collections::HashMap<String, tokio::sync::oneshot::Sender<bool>>>>,
            kbi_txs: Arc<Mutex<std::collections::HashMap<String, tokio::sync::oneshot::Sender<Option<Vec<String>>>>>>,
            nonce: String,
        }
        impl Drop for FpCleanupGuard {
            fn drop(&mut self) {
                let fp_txs = Arc::clone(&self.fp_txs);
                let kbi_txs = Arc::clone(&self.kbi_txs);
                let nonce = self.nonce.clone();
                tauri::async_runtime::spawn(async move {
                    fp_txs.lock().await.remove(&nonce);
                    // Worker died mid keyboard-interactive prompt — drop any
                    // dangling sender so a late frontend response is a no-op.
                    kbi_txs.lock().await.remove(&nonce);
                });
            }
        }
        let _guard = FpCleanupGuard {
            fp_txs: Arc::clone(&fp_txs_clone),
            kbi_txs: Arc::clone(&kbi_txs_clone),
            nonce: cleanup_nonce.clone(),
        };

        let emit_log = |msg: &str, log_type: &str| {
            println!("[LOG-{}] {}", session_id_clone, msg);
            // Once a newer attempt (or a disconnect) has replaced this one,
            // its lines would read as the newer attempt's — keep them out.
            if !attempt.is_current_now() {
                return;
            }
            let _ = app.emit(&format!("session-log-{}", session_id_clone), serde_json::json!({"msg": msg, "type": log_type}));
        };

        let cleanup = || async {
            // Already handled by Drop Guard, but keeping for immediate eviction if needed
            fp_txs_clone.lock().await.remove(&cleanup_nonce);
        };

        emit_log("Initializing SSH connection process...", "info");
        // A blank username is resolved after the handshake (issue #54): from
        // this tab's cache, or asked for — see resolve_login_user.
        let saved_user = user.trim().to_string();
        emit_log(
            &format!(
                "Server Details -> Host: {}, Port: {}, User: {}",
                host,
                port,
                if saved_user.is_empty() { "(asked when connecting)" } else { saved_user.as_str() },
            ),
            "info",
        );
        emit_log(&format!("[DEBUG] Server Auth Method: {}", server_auth_type), "info");
        if server_auth_type == "vault" {
            emit_log(&format!("[DEBUG] Vault Identity Auth Type: {:?}", cred_auth_type), "info");
        }
        emit_log(&format!("[DEBUG] SQLite DB key_id: {:?}", db_key_id), "info");
        emit_log(&format!("[DEBUG] effective_key_id determined: {:?}", effective_key_id), "info");
        if let Some((ref priv_key, ref passphrase, _)) = key_data {
            emit_log(&format!("[DEBUG] SSH Key loaded from DB. Private Key length: {} chars, Has Passphrase: {}", priv_key.len(), passphrase.is_some()), "info");
            if priv_key.trim().is_empty() {
                emit_log("[DEBUG] WARNING: SSH Key content is EMPTY!", "error");
            } else {
                let first_line = priv_key.lines().next().unwrap_or("");
                emit_log(&format!("[DEBUG] SSH Key Header: {}", first_line), "info");
            }
        } else {
            emit_log("[DEBUG] No SSH Key was loaded from database for this session.", "info");
        }

        // Set up generic stream based on proxy configuration
        trait AsyncStream: tokio::io::AsyncRead + tokio::io::AsyncWrite + Unpin + Send + 'static {}
        impl<T: tokio::io::AsyncRead + tokio::io::AsyncWrite + Unpin + Send + 'static> AsyncStream for T {}

        struct StreamWrapper(Box<dyn AsyncStream>);
        impl tokio::io::AsyncRead for StreamWrapper {
            fn poll_read(mut self: std::pin::Pin<&mut Self>, cx: &mut std::task::Context<'_>, buf: &mut tokio::io::ReadBuf<'_>) -> std::task::Poll<std::io::Result<()>> {
                std::pin::Pin::new(&mut *self.0).poll_read(cx, buf)
            }
        }
        impl tokio::io::AsyncWrite for StreamWrapper {
            fn poll_write(mut self: std::pin::Pin<&mut Self>, cx: &mut std::task::Context<'_>, buf: &[u8]) -> std::task::Poll<std::io::Result<usize>> {
                std::pin::Pin::new(&mut *self.0).poll_write(cx, buf)
            }
            fn poll_flush(mut self: std::pin::Pin<&mut Self>, cx: &mut std::task::Context<'_>) -> std::task::Poll<std::io::Result<()>> {
                std::pin::Pin::new(&mut *self.0).poll_flush(cx)
            }
            fn poll_shutdown(mut self: std::pin::Pin<&mut Self>, cx: &mut std::task::Context<'_>) -> std::task::Poll<std::io::Result<()>> {
                std::pin::Pin::new(&mut *self.0).poll_shutdown(cx)
            }
        }

        // ProxyJump takes precedence over a direct / proxied transport. When a
        // bastion is configured we connect+auth to it first, then open a
        // `direct-tcpip` channel to the REAL target over that connection and
        // use the channel as the transport for the primary handshake — exactly
        // what `ssh -J bastion target` does. The bastion's own Handle is parked
        // in `jump_handle_holder` so it lives through the target handshake; on
        // success it moves into `state_jump_connections` for the session's life.
        let mut jump_handle_holder: Option<russh::client::Handle<ssh_manager::ClientHandler>> = None;
        // Set by connect_jump_host when the bastion login itself failed.
        let jump_auth_failed = std::sync::atomic::AtomicBool::new(false);
        let stream_res: Result<Box<dyn AsyncStream>, String> = if let Some(jid) = jump_host_id {
            emit_log(&format!("ProxyJump: routing through jump host (server id {})...", jid), "info");
            match connect_jump_host(&app, &db_for_jump, &fp_txs_clone, &kbi_txs_clone, &prompted_secrets_clone, allow_kbi, &jump_auth_failed, &attempt, &session_id_clone, jid).await {
                Ok(jump_handle) => {
                    // Originator address is cosmetic (logged by the bastion); the
                    // pair below is what OpenSSH sends for a -J hop.
                    match jump_handle
                        .channel_open_direct_tcpip(host.clone(), port as u32, "127.0.0.1", 0)
                        .await
                    {
                        Ok(channel) => {
                            emit_log(&format!("ProxyJump: opened tunnel to {}:{} through the jump host.", host, port), "success");
                            // Always-drained (see tunnel::DrainedChannelStream):
                            // the target session's protocol task stops reading its
                            // transport while a write waits for the bastion's
                            // window. A plain ChannelStream would then fill this
                            // channel's queue, block the bastion connection's
                            // protocol task — which is what delivers that window
                            // adjust — and deadlock the whole ProxyJump session.
                            let boxed: Box<dyn AsyncStream> = Box::new(crate::tunnel::drained_stream(channel));
                            jump_handle_holder = Some(jump_handle);
                            Ok(boxed)
                        }
                        Err(e) => Err(format!(
                            "ProxyJump: could not open a channel to {}:{} through the jump host: {}",
                            host, port, e
                        )),
                    }
                }
                Err(e) => Err(format!("ProxyJump: {}", e)),
            }
        } else {
        match proxy_type.as_str() {
            "socks5" => {
                let p_host = match proxy_host.as_ref().filter(|h| !h.is_empty()) {
                    Some(h) => h,
                    None => {
                        let err_msg = "SOCKS5 Proxy Host is empty";
                        emit_log(&format!("Error: {}", err_msg), "error");
                        cleanup().await;
                        emit_connection_failed(&app, &attempt, &session_id_clone, serde_json::json!({"reason": err_msg})).await;
                        return;
                    }
                };
                let p_port = proxy_port.unwrap_or(1080) as u16;
                emit_log(&format!("Connecting via SOCKS5 Proxy {}:{}...", p_host, p_port), "info");
                
                let proxy_addr = format!("{}:{}", p_host, p_port);
                match tokio::time::timeout(
                    Duration::from_secs(10),
                    tokio_socks::tcp::Socks5Stream::connect(proxy_addr.as_str(), (host.as_str(), port as u16))
                ).await {
                    Ok(Ok(stream)) => {
                        emit_log("SOCKS5 Proxy tunnel established successfully.", "success");
                        // Socks5Stream derefs to the inner TcpStream, so the
                        // kernel keepalive applies to the real proxy socket.
                        apply_tcp_keepalive(&stream);
                        Ok(Box::new(stream))
                    }
                    Ok(Err(e)) => {
                        Err(humanize_network_err(&e.to_string(), &host, port, "SOCKS5 proxy"))
                    }
                    Err(_) => {
                        Err(format!("SOCKS5 proxy {}:{} did not respond in time", p_host, p_port))
                    }
                }
            }
            "http" => {
                let p_host = match proxy_host.as_ref().filter(|h| !h.is_empty()) {
                    Some(h) => h,
                    None => {
                        let err_msg = "HTTP Proxy Host is empty";
                        emit_log(&format!("Error: {}", err_msg), "error");
                        cleanup().await;
                        emit_connection_failed(&app, &attempt, &session_id_clone, serde_json::json!({"reason": err_msg})).await;
                        return;
                    }
                };
                let p_port = proxy_port.unwrap_or(8080) as u16;
                emit_log(&format!("Connecting via HTTP Proxy {}:{}...", p_host, p_port), "info");

                let proxy_addr = format!("{}:{}", p_host, p_port);
                match tokio::time::timeout(
                    Duration::from_secs(10),
                    tokio::net::TcpStream::connect(proxy_addr)
                ).await {
                    Ok(Ok(mut tcp_stream)) => {
                        // Disable Nagle: SSH is heavily interactive (keystrokes,
                        // small control packets) and batching adds noticeable
                        // round-trip latency. Ignore failures — set_nodelay is
                        // best-effort; some platforms / virtual NICs reject it.
                        let _ = tcp_stream.set_nodelay(true);
                        apply_tcp_keepalive(&tcp_stream);
                        emit_log(&format!("Requesting HTTP CONNECT tunnel to {}:{}...", host, port), "info");
                        match tokio::time::timeout(
                            Duration::from_secs(10),
                            async_http_proxy::http_connect_tokio(&mut tcp_stream, &host, port as u16)
                        ).await {
                            Ok(Ok(_)) => {
                                emit_log("HTTP Proxy tunnel established successfully.", "success");
                                Ok(Box::new(tcp_stream))
                            }
                            Ok(Err(e)) => {
                                Err(humanize_network_err(&e.to_string(), &host, port, "HTTP CONNECT tunnel"))
                            }
                            Err(_) => {
                                Err(format!("HTTP CONNECT tunnel to {}:{} timed out", host, port))
                            }
                        }
                    }
                    Ok(Err(e)) => {
                        Err(humanize_network_err(&e.to_string(), p_host, p_port as i32, "HTTP proxy"))
                    }
                    Err(_) => {
                        Err(format!("HTTP proxy {}:{} did not respond in time", p_host, p_port))
                    }
                }
            }
            _ => {
                emit_log(&format!("Connecting directly to {}:{}...", host, port), "info");
                match tokio::time::timeout(
                    Duration::from_secs(10),
                    tokio::net::TcpStream::connect((host.as_str(), port as u16))
                ).await {
                    Ok(Ok(stream)) => {
                        // See HTTP-proxy branch — SSH wants every packet on the
                        // wire immediately, no Nagle batching.
                        let _ = stream.set_nodelay(true);
                        apply_tcp_keepalive(&stream);
                        emit_log("Direct TCP Connection established successfully.", "success");
                        Ok(Box::new(stream))
                    }
                    Ok(Err(e)) => {
                        Err(humanize_network_err(&e.to_string(), &host, port, "Connection"))
                    }
                    Err(_) => {
                        Err(format!("{}:{} did not respond within 10 seconds", host, port))
                    }
                }
            }
        }
        };

        let stream = match stream_res {
            Ok(s) => s,
            Err(e) => {
                emit_log(&e, "error");
                cleanup().await;
                // A failed (or cancelled) bastion login is an auth error like
                // the target's own, so auto-reconnect stops instead of asking
                // again every few seconds.
                emit_connection_failed(
                    &app,
                    &attempt,
                    &session_id_clone,
                    serde_json::json!({
                        "reason": e,
                        "is_auth_error": jump_auth_failed.load(std::sync::atomic::Ordering::Relaxed),
                    }),
                )
                .await;
                return;
            }
        };

        emit_log("Starting SSH Handshake and establishing secure session...", "info");
        // Config (keepalive, windows, algorithm negotiation) is shared with the
        // ProxyJump hop — see build_ssh_client_config for the full rationale.
        let config = client_config;

        let connect_future = client::connect_stream(config, StreamWrapper(stream), handler);

        // 15s bounds only the pre-prompt handshake; a pending first-time
        // fingerprint prompt extends the wait to the hard cap (see
        // drive_connect_with_prompt_timeout) so the 90s human window governs.
        match drive_connect_with_prompt_timeout(connect_future, &prompt_pending_for_driver, CONNECT_TIMEOUT_CAPS).await {
            Ok(Ok(mut session)) => {
                emit_log("SSH Handshake complete. Authenticating user...", "info");
                
                // Connect-time prompting for a secret the node / login / key
                // doesn't save (issue #30). It uses this tab's keyboard-
                // interactive modal, and accepted secrets are cached under the
                // base tab id so reconnects and `::sftp` / `::fwd` secondaries
                // reuse them; only the primary ever prompts. The key also names
                // the target (see secrets_target).
                let base_id = format!("{}|{}", base_session_id(&session_id_clone), secrets_target);
                let prompt_ctx = SecretPromptCtx {
                    app: &app,
                    session_id: &session_id_clone,
                    nonce: &connect_nonce,
                    kbi_txs: &kbi_txs_clone,
                    cache: &prompted_secrets_clone,
                    base: &base_id,
                    allow_prompt: allow_kbi,
                    attempt: &attempt,
                    cancelled: std::sync::atomic::AtomicBool::new(false),
                };

                let (effective_user, user_prompted, login_cancelled) =
                    match resolve_login_user(&saved_user, &host, SecretSlot::Username, &prompt_ctx).await {
                        Some((name, typed)) => (name, typed, false),
                        None => (Zeroizing::new(String::new()), false, true),
                    };
                if user_prompted {
                    emit_log(&format!("Logging in as {}.", effective_user.as_str()), "info");
                }

                let mut auth_res = if login_cancelled {
                    // "Login as" was cancelled — nothing to try. The prompt set
                    // prompt_ctx.cancelled, so this ends as "Login cancelled"
                    // and skips the keyboard-interactive fallback.
                    Ok(false)
                } else if let Some((private_key, passphrase, key_name)) = key_data {
                    emit_log("Attempting Private Key Authentication...", "info");
                    let key_label = key_name
                        .filter(|n| !n.trim().is_empty())
                        .unwrap_or_else(|| format!("{}@{}", effective_user.as_str(), host));
                    authenticate_key_prompting(
                        &mut session,
                        &effective_user,
                        &private_key,
                        &key_label,
                        passphrase.map(Zeroizing::new),
                        SecretSlot::Passphrase,
                        &prompt_ctx,
                    )
                    .await
                } else {
                    emit_log("Attempting Password Authentication...", "info");
                    // The failed-screen override (if any) is tried first, then
                    // the cache, then the saved password; with none of them the
                    // user is asked — unless the server doesn't take passwords,
                    // in which case keyboard-interactive below runs as before.
                    authenticate_password_prompting(
                        &mut session,
                        &effective_user,
                        &host,
                        custom_password.map(Zeroizing::new),
                        password.map(Zeroizing::new),
                        SecretSlot::Password,
                        &prompt_ctx,
                    )
                    .await
                };

                // Keyboard-interactive (2FA / verification-code) fallback. Many
                // hardened servers gate login behind an interactive one-time
                // code AFTER — or INSTEAD of — a password. If the primary
                // attempt above didn't already authenticate us and the server
                // offers keyboard-interactive, drive it: relay each prompt to
                // the UI, collect the user's answers, and send them back. If
                // the server doesn't offer it, `run_keyboard_interactive`
                // returns None and we keep the original auth result untouched.
                // If the user just cancelled our password / passphrase prompt,
                // stop here: the fallback would only ask again (the server's own
                // "Password:" box on a typical PAM setup).
                if allow_kbi
                    && !matches!(auth_res, Ok(true))
                    && !prompt_ctx.cancelled.load(std::sync::atomic::Ordering::Relaxed)
                {
                    if let Some(kbi_res) = run_keyboard_interactive(
                        &mut session,
                        &effective_user,
                        &app,
                        &session_id_clone,
                        &connect_nonce,
                        &kbi_txs_clone,
                        &attempt,
                    )
                    .await
                    {
                        auth_res = kbi_res;
                    }
                }

                // A typed "Login as" name is kept for this tab only once it has
                // logged in, so a typo isn't silently reused on reconnect.
                if user_prompted && matches!(auth_res, Ok(true)) {
                    cache_store_secret(&prompted_secrets_clone, &base_id, SecretSlot::Username, effective_user.clone()).await;
                }

                match auth_res {
                    Ok(true) => {
                        let session_arc = Arc::new(Mutex::new(session));
                        // "Still wanted?" registration guard. The handshake can
                        // take up to ~15s (longer via proxy/jump). If, meanwhile,
                        // a reconnect for this key bumped the generation or a
                        // disconnect/teardown swept it (both of which bump the
                        // generation BEFORE removing the connection), registering
                        // now would create a ZOMBIE: a live SSH connection with a
                        // watcher that immediately exits on the generation
                        // mismatch, plus — for ::fwd — tunnels migrated onto a
                        // connection nobody tracks. Do the check and the insert
                        // TOGETHER under the generation lock so a concurrent
                        // teardown can't interleave: we either observe the newer
                        // generation and bail, or insert first and the teardown's
                        // later connection-remove reaps us.
                        let registered = {
                            let g = state_session_generation.lock().await;
                            if g.get(&session_id_clone).copied().unwrap_or(0) == connect_generation {
                                state_connections
                                    .lock()
                                    .await
                                    .insert(session_id_clone.clone(), Arc::clone(&session_arc));
                                true
                            } else {
                                false
                            }
                        };
                        if !registered {
                            emit_log("Connection superseded before it was ready — dropping it.", "info");
                            // `session_arc` drops here, closing the transport.
                            // The FpCleanupGuard's Drop still clears the nonce.
                            return;
                        }
                        emit_log("Authentication successful. Session ready.", "success");
                        // A dedicated `::sftp` transport just came up — drop the
                        // base session's cached SFTP subsystem (it rides the
                        // primary). The next file operation re-opens on this
                        // dedicated connection via get_sftp_session's
                        // transport preference. Live migration, no re-keying.
                        if let Some(base) = session_id_clone.strip_suffix("::sftp") {
                            state_sftp_sessions.lock().await.remove(base);
                        }
                        // ProxyJump: now that the target session is live, park
                        // the bastion's Handle so it stays alive for the whole
                        // session (its direct-tcpip channel carries our
                        // transport). Dropped on reconnect / disconnect / close.
                        if let Some(jh) = jump_handle_holder.take() {
                            state_jump_connections.lock().await.insert(session_id_clone.clone(), jh);
                        }
                        let _ = app.emit(
                            &format!("connection-success-{}", session_id_clone),
                            serde_json::json!({}),
                        );

                        // Separate-sessions topology: in shared mode the primary
                        // owns the saved tunnels; in separate mode the dedicated
                        // `::fwd` connection owns them (it re-enters this same
                        // block under its own suffixed session id, so the tunnels
                        // are tagged/keyed against `::fwd` and ride that handle).
                        // `start_tunnels_inline` is false for the `::sftp`
                        // connection and for the primary when `separate` is on.
                        if start_tunnels_inline {
                        // Auto-start every tunnel attached to this session.
                        // Source of truth is the in-memory `session_tunnel_specs`
                        // map, which carries both the DB-saved rules AND any
                        // ad-hoc tunnels the user opened during the previous
                        // session lifetime. On first connect it's empty, so
                        // we seed it from the DB row's `tunnels` JSON.
                        let specs_to_start: Vec<tunnel::TunnelSpec> = {
                            let mut map = state_session_tunnel_specs.lock().await;
                            // A PRESENT replay list — even an empty one — is
                            // authoritative, exactly as in the ::fwd branch below
                            // and in restart_session_tunnels. An empty list means
                            // the user stopped every tunnel; only an ABSENT key is
                            // a genuine first engagement worth seeding from the
                            // node's saved rules. Treating empty as "unset" here
                            // meant every reconnect — including the health
                            // watcher's automatic one — silently reopened local
                            // listeners the user had deliberately closed.
                            match map.get(&session_id_clone).cloned() {
                                Some(existing) => existing,
                                None => match serde_json::from_str::<Vec<tunnel::TunnelSpec>>(&tunnels_json) {
                                    Ok(db_specs) => {
                                        map.insert(session_id_clone.clone(), db_specs.clone());
                                        db_specs
                                    }
                                    Err(e) => {
                                        emit_log(&format!("转发配置 JSON 解析错误：{}", e), "error");
                                        Vec::new()
                                    }
                                }
                            }
                        };
                        // A rule the user stopped stays down until they start
                        // it again.
                        for spec in specs_to_start.iter().filter(|spec| !spec.stopped) {
                            let started = tunnel::start_tunnel(
                                app.clone(),
                                session_id_clone.clone(),
                                Arc::clone(&session_arc),
                                Arc::clone(&state_tunnels),
                                Arc::clone(&session_forwarded_targets),
                                spec.clone(),
                            ).await;
                            match started {
                                Ok(id) => emit_log(
                                    &format!("Tunnel started [{}]: {} {}", id, spec.kind, spec.local),
                                    "info",
                                ),
                                Err(e) => {
                                    // KEEP the spec in the replay list on failure
                                    // so the NEXT reconnect retries it. Stripping
                                    // it here (the old behaviour) turned a
                                    // transient rebind race on a flaky network —
                                    // a momentary AddrInUse while the previous
                                    // listener finished releasing the port — into
                                    // permanent loss of the tunnel until the user
                                    // manually restarted it. bind_with_retry now
                                    // absorbs that race; anything still failing is
                                    // logged and retried on the next reconnect
                                    // rather than silently dropped.
                                    emit_log(
                                        &format!("Tunnel start failed ({} {}): {} — will retry on next reconnect", spec.kind, spec.local, e),
                                        "error",
                                    );
                                }
                            }
                        }
                        } // end if start_tunnels_inline

                        // Dedicated `::fwd` transport: MIGRATE the session's
                        // tunnels onto this fresh connection. Stop whatever is
                        // running under the base tag (riding the primary, or a
                        // previous dead `::fwd`) so re-binding the same local
                        // ports can't conflict, then start the full replay
                        // list — seeded from the node's saved tunnels on first
                        // engagement — on this handle, still tagged under the
                        // BASE session id so the Tunnels panel / list / events
                        // never re-key. This runs on fresh connects, live
                        // toggle-on, the reconnect button, and auto-retry.
                        if role == "forward" {
                            let base = session_id_clone
                                .strip_suffix("::fwd")
                                .unwrap_or(&session_id_clone)
                                .to_string();
                            tunnel::stop_all_for_session(&state_tunnels, &base).await;
                            let specs: Vec<tunnel::TunnelSpec> = {
                                let mut map = state_session_tunnel_specs.lock().await;
                                // A PRESENT replay list — even an empty one — is
                                // authoritative: the session is already engaged
                                // and an empty list means the user stopped every
                                // tunnel. Only seed from the node's saved tunnels
                                // when the key is ABSENT (genuine first
                                // engagement) — otherwise stopped tunnels would
                                // resurrect on every ::fwd reconnect / toggle.
                                match map.get(&base).cloned() {
                                    Some(existing) => existing,
                                    None => match serde_json::from_str::<Vec<tunnel::TunnelSpec>>(&tunnels_json) {
                                        Ok(db_specs) => {
                                            if !db_specs.is_empty() {
                                                map.insert(base.clone(), db_specs.clone());
                                            }
                                            db_specs
                                        }
                                        Err(e) => {
                                            emit_log(&format!("转发配置 JSON 解析错误：{}", e), "error");
                                            Vec::new()
                                        }
                                    },
                                }
                            };
                            if specs.iter().any(|spec| !spec.stopped) {
                                emit_log("Dedicated forwarding connection ready — moving tunnels onto it.", "info");
                                start_tunnel_specs_on(
                                    &app,
                                    &base,
                                    &session_arc,
                                    &session_forwarded_targets,
                                    &state_tunnels,
                                    &state_session_tunnel_specs,
                                    specs,
                                )
                                .await;
                            }
                        }

                        // Health watcher: polls the SSH handle every 5s. If
                        // `is_closed()` flips to true while the session is
                        // still registered (i.e. the user did NOT call
                        // disconnect_session explicitly), we fire a
                        // `session-disconnected-{id}` event so the UI can lock
                        // down the terminal/SFTP and show a reconnect prompt.
                        // An explicit disconnect removes the map entry, which
                        // the watcher detects and exits silently — no event.
                        let app_w = app.clone();
                        let sid_w = session_id_clone.clone();
                        let state_w = Arc::clone(&state_connections);
                        let state_sftp_w = Arc::clone(&state_sftp_sessions);
                        let state_gen_w = Arc::clone(&state_session_generation);
                        let state_tunnels_w = Arc::clone(&state_tunnels);
                        let state_mirrors_w: MirrorMap = mirrors_owned.clone();
                        // Captured so the watcher can periodically re-attempt a
                        // configured tunnel that failed to bind while the session
                        // stays alive (see the retry block in the loop below).
                        let state_specs_w = Arc::clone(&state_session_tunnel_specs);
                        let targets_w = Arc::clone(&session_forwarded_targets);
                        let last_heard_w = last_heard.clone();
                        let my_gen = connect_generation;
                        tauri::async_runtime::spawn(async move {
                            // Two-tier liveness check:
                            //   - Every 2s: cheap is_closed() poll. Catches TCP
                            //     RST / FIN, russh's own teardown, AND — now that
                            //     the transport socket carries OS TCP keepalive
                            //     (see apply_tcp_keepalive) — kernel-detected
                            //     dead peers during long idle.
                            //   - Slow active probe: a `keepalive@openssh.com`
                            //     global request with want-reply, forcing a real
                            //     round-trip to catch black-holes the kernel
                            //     hasn't flagged yet (what OpenSSH's
                            //     ServerAliveInterval sends). Primary every
                            //     ~30s, dedicated `::sftp`/`::fwd` secondaries
                            //     every ~60s (they matter less urgently and the
                            //     probes multiply per-session overhead).
                            //     It must NOT be a channel open: that takes one
                            //     of the server's MaxSessions slots, so on a
                            //     hardened server (MaxSessions 1-4) or a busy
                            //     connection (tabs + SFTP + logs at the default
                            //     10) the server refused the probe — and a
                            //     refusal was counted as a dead connection, so
                            //     a healthy session was torn down every ~30s
                            //     (#29). A global request uses no slot, and any
                            //     reply, success or failure, proves the server
                            //     and the transport are alive.
                            //     TWO consecutive probe failures are required
                            //     before declaring death: on poor networks a
                            //     single 10s latency spike is common, and the
                            //     old one-strike/5s-timeout probe tore down
                            //     perfectly recoverable sessions — the exact
                            //     opposite of what a flaky link needs.
                            //     And a probe left unanswered while the server
                            //     kept sending (LastHeard) isn't a failure: on
                            //     a slow uplink an SFTP upload queues the
                            //     keepalive behind its own data for longer
                            //     than the probe waits.
                            let probe_every: u32 = if sid_w.contains("::") { 30 } else { 15 };
                            let mut tick: u32 = 0;
                            let mut probe_strikes: u8 = 0;
                            // Set once this server has left a keepalive unanswered but answered
                            // a channel open: probe it that way from then on.
                            let mut ping_unanswered = false;
                            loop {
                                tokio::time::sleep(Duration::from_secs(2)).await;
                                tick = tick.wrapping_add(1);

                                // Generation guard: a reconnect under the same
                                // session_id bumps the counter. If we observe a
                                // newer value here, a fresh watcher has already
                                // taken over — bow out silently so we don't
                                // double-emit `session-disconnected-{id}`.
                                {
                                    let g = state_gen_w.lock().await;
                                    if g.get(&sid_w).copied().unwrap_or(0) != my_gen {
                                        break;
                                    }
                                }

                                let handle_opt = {
                                    let conns = state_w.lock().await;
                                    conns.get(&sid_w).cloned()
                                };
                                let handle_arc = match handle_opt {
                                    Some(h) => h,
                                    None => break, // explicit disconnect — quiet
                                };

                                let is_closed = {
                                    let h = handle_arc.lock().await;
                                    h.is_closed()
                                };

                                let mut dead = is_closed;

                                if !dead && tick.is_multiple_of(probe_every) {
                                    // Active probe: hold the handle lock long
                                    // enough to start AND finish the round
                                    // trip — concurrent commands wait, but
                                    // that's fine, they would block on the
                                    // same lock to open their own channel
                                    // anyway. 10s timeout: generous enough
                                    // that a congested-but-alive link doesn't
                                    // strike out spuriously.
                                    let asked_at = ssh_manager::LastHeard::now();
                                    let alive = {
                                        let h = handle_arc.lock().await;
                                        let answered = if ping_unanswered {
                                            probe_with_channel(&h).await
                                        } else {
                                            match tokio::time::timeout(
                                                Duration::from_secs(10),
                                                h.send_ping(),
                                            ).await {
                                                // send_ping resolves on the
                                                // server's reply — and also
                                                // when the session dies
                                                // mid-ping (the reply channel
                                                // is dropped), so confirm the
                                                // handle is still open.
                                                Ok(Ok(())) => !h.is_closed(),
                                                Ok(Err(_)) => false,
                                                Err(_) if h.is_closed() => false,
                                                // No reply in time, but the
                                                // server kept sending: the
                                                // reply is queued behind a
                                                // busy channel's data (an
                                                // upload on a slow uplink).
                                                // Not a server that ignores
                                                // keepalives, so no fallback.
                                                Err(_) if last_heard_w.heard_since(asked_at) => true,
                                                // No reply in time. A few
                                                // servers never answer
                                                // keepalive@openssh.com (or
                                                // answer UNIMPLEMENTED, which
                                                // russh drops), so ask the old
                                                // way. If that gets an answer,
                                                // keep probing this server that
                                                // way rather than waiting out
                                                // the ping on every probe.
                                                Err(_) => {
                                                    let up = probe_with_channel(&h).await;
                                                    if up {
                                                        ping_unanswered = true;
                                                    }
                                                    up
                                                }
                                            }
                                        };
                                        // Same for a channel-open probe that
                                        // timed out: anything the server sent
                                        // while we waited proves it's alive,
                                        // as long as the connection is open.
                                        answered || (last_heard_w.heard_since(asked_at) && !h.is_closed())
                                    };
                                    if alive {
                                        probe_strikes = 0;
                                    } else {
                                        probe_strikes += 1;
                                        if probe_strikes >= 2 {
                                            dead = true;
                                        } else {
                                            // One strike: re-probe on the
                                            // next 2s tick instead of a
                                            // full interval away, so a
                                            // real death still surfaces
                                            // promptly.
                                            tick = probe_every.wrapping_sub(1);
                                        }
                                    }
                                }

                                // While the session is ALIVE, periodically re-attempt
                                // any configured tunnel that isn't currently running.
                                // A listener that failed to bind (its local port was
                                // briefly taken) otherwise stays dead until the user
                                // closes and reopens the tab — nothing retries it
                                // without a full reconnect. `start_tunnel_specs_on`
                                // skips specs already running (anywhere under this
                                // session), so this is a no-op once everything is up
                                // and can't create duplicates. Gated to the primary
                                // session id: the dedicated `::fwd`/`::sftp`
                                // transports have their own migration/restore paths,
                                // and the primary handle is the correct transport for
                                // the default (shared) topology. Spawned so a slow
                                // bind retry never delays death detection.
                                if !dead && tick.is_multiple_of(30) && !sid_w.contains("::") {
                                    let specs = state_specs_w.lock().await.get(&sid_w).cloned().unwrap_or_default();
                                    if specs.iter().any(|spec| !spec.stopped) {
                                        let app_r = app_w.clone();
                                        let sid_r = sid_w.clone();
                                        let handle_r = Arc::clone(&handle_arc);
                                        let targets_r = Arc::clone(&targets_w);
                                        let tunnels_r = Arc::clone(&state_tunnels_w);
                                        let specs_r = Arc::clone(&state_specs_w);
                                        tauri::async_runtime::spawn(async move {
                                            start_tunnel_specs_on(&app_r, &sid_r, &handle_r, &targets_r, &tunnels_r, &specs_r, specs).await;
                                        });
                                    }
                                }

                                if dead {
                                    // Re-check generation + verify OUR handle is
                                    // still the registered one before tearing
                                    // anything down. A slow probe holds the handle
                                    // lock up to 10s; during that window a manual
                                    // reconnect / auto-retry can bump the
                                    // generation and register a fresh, healthy
                                    // connection. Without this guard we'd remove
                                    // that NEW connection and kill its just-
                                    // migrated tunnels. Bail silently on mismatch.
                                    {
                                        let g = state_gen_w.lock().await;
                                        if g.get(&sid_w).copied().unwrap_or(0) != my_gen {
                                            break;
                                        }
                                    }
                                    // Compare-and-remove: only drop the map entry
                                    // if it's still OUR handle (Arc identity).
                                    {
                                        let mut conns = state_w.lock().await;
                                        match conns.get(&sid_w) {
                                            Some(cur) if Arc::ptr_eq(cur, &handle_arc) => { conns.remove(&sid_w); }
                                            _ => break, // superseded by a fresh connection — leave it be
                                        }
                                    }
                                    // Close the SFTP session too, not just
                                    // drop it from the cache: a transfer holds
                                    // its own Arc to it, and its pending
                                    // requests would otherwise wait out their
                                    // 240s deadline (sftp_client_config) on a
                                    // link that is gone. close() only signals
                                    // russh-sftp's own task; nothing is sent.
                                    let dead_sftp = state_sftp_w.lock().await.remove(&sid_w);
                                    if let Some(sftp) = dead_sftp {
                                        let _ = sftp.close().await;
                                    }
                                    // Tear down all tunnels bound to this
                                    // session so their listeners release the
                                    // local ports + bridge tasks exit. Without
                                    // this, the listeners stayed up holding
                                    // the now-dead Arc<Handle>, and stop_tunnel
                                    // calls during reconnect raced with the
                                    // replay logic. This is the single
                                    // authoritative SSH-death tunnel-teardown
                                    // path; the listener tasks themselves no
                                    // longer probe the handle.
                                    tunnel::stop_all_for_session(&state_tunnels_w, &sid_w).await;
                                    // Dedicated-transport death: tunnels are
                                    // tagged under the BASE session id but ride
                                    // this `::fwd` connection — stop them so
                                    // their listeners release; the frontend's
                                    // auto-retry either brings the transport
                                    // back (migration restarts them on it) or
                                    // falls back to the primary. Same for the
                                    // base SFTP cache riding a dead `::sftp`.
                                    if let Some(base) = sid_w.strip_suffix("::fwd") {
                                        tunnel::stop_all_for_session(&state_tunnels_w, base).await;
                                    }
                                    if let Some(base) = sid_w.strip_suffix("::sftp") {
                                        let dead_sftp = state_sftp_w.lock().await.remove(base);
                                        if let Some(sftp) = dead_sftp {
                                            let _ = sftp.close().await;
                                        }
                                    }
                                    // Stop any mirrors bound to this session too — otherwise the
                                    // mirror worker keeps its own Arc<SftpSession> pointing at
                                    // this dead handle and hammers upload-fail on every future
                                    // FS event until the app is quit.
                                    mirror::stop_all_for_session(&state_mirrors_w, &sid_w).await;
                                    let _ = app_w.emit(
                                        &format!("session-disconnected-{}", sid_w),
                                        serde_json::json!({
                                            "reason": "Connection lost"
                                        }),
                                    );
                                    break;
                                }
                            }
                        });
                    },
                    Ok(false) => {
                        // Server reached the auth phase and explicitly told
                        // us "no". This is the only branch that maps to a
                        // real auth failure — everything else gets routed
                        // through `classify_russh_error` so a network drop
                        // or host-key timeout never gets relabelled as one.
                        // A cancelled (or timed-out) connect-time prompt is the
                        // user's choice, not a rejection — say so. Still an
                        // auth error so auto-reconnect stays off.
                        let (log_msg, reason) = if prompt_ctx.cancelled.load(std::sync::atomic::Ordering::Relaxed) {
                            ("Login cancelled.", "Login cancelled. Reconnect to try again.")
                        } else {
                            (
                                "Authentication rejected by server.",
                                "Authentication rejected by server (wrong password, missing key, or account locked).",
                            )
                        };
                        emit_log(log_msg, "error");
                        emit_connection_failed(
                            &app,
                            &attempt,
                            &session_id_clone,
                            serde_json::json!({
                                "reason": reason,
                                "is_auth_error": true,
                            }),
                        )
                        .await;
                    },
                    Err(e) => {
                        let kind = classify_russh_error(&e);
                        let target = format!("{}:{}", host, port);
                        // A cancelled passphrase prompt surfaces here as
                        // KeyIsEncrypted (an auth-kind error); name it plainly.
                        let reason = if prompt_ctx.cancelled.load(std::sync::atomic::Ordering::Relaxed) {
                            "Login cancelled. Reconnect to try again.".to_string()
                        } else {
                            describe_error_kind(kind, &target)
                        };
                        emit_log(&format!("{} (raw: {})", reason, e), "error");
                        emit_connection_failed(
                            &app,
                            &attempt,
                            &session_id_clone,
                            serde_json::json!({
                                "reason": reason,
                                "is_auth_error": kind.is_auth(),
                            }),
                        )
                        .await;
                    }
                }
            },
            Ok(Err(e)) => {
                // Connect-stream failed AFTER the TCP socket opened — most
                // commonly this is the host-key flow ending in either a
                // declined fingerprint or a timed-out prompt. Read the
                // outcome the handler stashed and surface a precise reason
                // instead of letting it ride the generic transport bucket.
                use std::sync::atomic::Ordering;
                let fp = fp_outcome_for_driver.load(Ordering::SeqCst);
                let (reason, kind) = match fp {
                    2 => (
                        "Host key prompt timed out — Reconnect and approve the fingerprint within 90 seconds.".to_string(),
                        ConnectErrorKind::HostKey,
                    ),
                    0 => (
                        "Host key was not approved. Reconnect to see the fingerprint prompt again.".to_string(),
                        ConnectErrorKind::HostKey,
                    ),
                    _ => {
                        let kind = classify_russh_error(&e);
                        let target = format!("{}:{}", host, port);
                        (describe_error_kind(kind, &target), kind)
                    }
                };
                emit_log(&format!("{} (raw: {})", reason, e), "error");
                emit_connection_failed(
                    &app,
                    &attempt,
                    &session_id_clone,
                    serde_json::json!({
                        "reason": reason,
                        "is_auth_error": kind.is_auth(),
                    }),
                )
                .await;
            },
            Err(ConnectTimeout::HandshakeStall) => {
                // russh's handshake task may still reach the host-key check
                // later; nobody is waiting, so it mustn't prompt.
                attempt.abandon();
                // 15s wall-clock on connect_stream with NO host-key prompt
                // pending — the TCP socket is up but the SSH handshake never
                // completed. Distinct enough from the auth path to deserve its
                // own message.
                let msg = format!(
                    "{}:{} did not finish SSH handshake within 15 seconds — host may be filtering SSH or running a non-SSH service on this port.",
                    host, port
                );
                emit_log(&msg, "error");
                emit_connection_failed(
                    &app,
                    &attempt,
                    &session_id_clone,
                    serde_json::json!({
                        "reason": msg,
                        "is_auth_error": false,
                    }),
                )
                .await;
            },
            Err(ConnectTimeout::PromptHardCap) => {
                attempt.abandon();
                // A fingerprint prompt was still pending when even the hard cap
                // (handshake + the 90s human window + margin) elapsed — the
                // prompt is wedged. Surface the same host-key message as a
                // check_server_key prompt-timeout (fp_outcome == 2) instead of
                // the misleading "handshake stalled" one.
                let reason =
                    "Host key prompt timed out — Reconnect and approve the fingerprint within 90 seconds.".to_string();
                emit_log(&reason, "error");
                emit_connection_failed(
                    &app,
                    &attempt,
                    &session_id_clone,
                    serde_json::json!({
                        "reason": reason,
                        "is_auth_error": ConnectErrorKind::HostKey.is_auth(),
                    }),
                )
                .await;
            }
        }

        cleanup().await;
    });
    
    Ok(())
}

/// Frontend acknowledgement of the SSH host-key prompt. The `nonce` must
/// match the value the matching `fingerprint-prompt-{session_id}` event
/// carried — without that match the response is dropped on the floor. Any
/// stale "accept" from a previous attempt cannot satisfy a fresh prompt.
#[tauri::command]
async fn verify_fingerprint_response(
    state: tauri::State<'_, SshState>,
    nonce: String,
    accepted: bool,
) -> Result<(), String> {
    if let Some(tx) = state.fp_txs.lock().await.remove(&nonce) {
        let _ = tx.send(accepted);
    }
    Ok(())
}

/// Frontend callback for a keyboard-interactive (2FA / verification-code)
/// prompt. `responses` is `Some(answers)` when the user submits, or `None`
/// when they cancel. Mirrors `verify_fingerprint_response`: the nonce binds
/// the answer 1:1 to the connect attempt that emitted the prompt, and a nonce
/// with no in-flight entry is silently a no-op (stale / forged responses can't
/// satisfy a fresh prompt).
#[tauri::command]
async fn submit_kbi_response(
    state: tauri::State<'_, SshState>,
    nonce: String,
    responses: Option<Vec<String>>,
) -> Result<(), String> {
    if let Some(tx) = state.kbi_txs.lock().await.remove(&nonce) {
        let _ = tx.send(responses);
    }
    Ok(())
}

// ---- Port forwarding (tunnels) ---------------------------------------------

/// Resolve the SSH transport a session's tunnels should ride: the dedicated
/// `::fwd` connection when the per-tab toggle has one up, else the primary.
/// The forwarded-targets map MUST belong to the same connection as the handle
/// — for R tunnels the server pushes `forwarded-tcpip` channels back on the
/// connection that sent `tcpip_forward`, and its ClientHandler consults only
/// its own map (ssh_manager.rs::server_channel_open_forwarded_tcpip).
async fn resolve_tunnel_transport(
    state: &SshState,
    session_id: &str,
) -> Result<(Arc<tokio::sync::Mutex<russh::client::Handle<ssh_manager::ClientHandler>>>, tunnel::ForwardedTargets), String> {
    let fwd_key = format!("{}::fwd", session_id);
    let (primary, dedicated) = {
        let conns = state.connections.lock().await;
        (conns.get(session_id).cloned(), if session_id.contains("::") { None } else { conns.get(&fwd_key).cloned() })
    };
    let targets_map = state.forwarded_targets.lock().await;
    if let Some(h) = dedicated {
        // The `::fwd` entry's forwarded-targets map is created by its own
        // initiate_connection; if it's somehow missing, fall through to the
        // primary rather than starting an R tunnel whose inbound channels
        // would never resolve.
        if let Some(t) = targets_map.get(&fwd_key) {
            return Ok((h, Arc::clone(t)));
        }
    }
    let h = primary.ok_or_else(|| "Session not connected".to_string())?;
    let t = targets_map
        .get(session_id)
        .cloned()
        .ok_or_else(|| "Session forwarded-targets map missing — reconnect first".to_string())?;
    Ok((h, t))
}

/// Start every spec in `specs` that isn't already running under `sid`'s tag,
/// on the given transport. Successes are recorded into the session's replay
/// list; failures are logged to the session log and the poison spec is
/// stripped from the replay list so auto-retry cycles don't error-loop on it.
/// Used by the `::fwd` migration (connect success), the fallback/restore
/// command, and shares its semantics with the primary's auto-start.
async fn start_tunnel_specs_on(
    app: &tauri::AppHandle,
    sid: &str,
    handle: &Arc<tokio::sync::Mutex<russh::client::Handle<ssh_manager::ClientHandler>>>,
    targets: &tunnel::ForwardedTargets,
    tunnels: &Arc<tokio::sync::Mutex<std::collections::HashMap<String, tunnel::ActiveTunnel>>>,
    specs_map: &Arc<tokio::sync::Mutex<std::collections::HashMap<String, Vec<tunnel::TunnelSpec>>>>,
    specs: Vec<tunnel::TunnelSpec>,
) {
    use tauri::Emitter;
    let emit_log = |msg: &str, log_type: &str| {
        let _ = app.emit(
            &format!("session-log-{}", sid),
            serde_json::json!({ "msg": msg, "type": log_type }),
        );
    };
    // Snapshot running specs for this tag. Two-phase (ids under the map lock,
    // status after releasing it) to respect the same lock-ordering rule as
    // tunnel::stop_all_for_session.
    let candidates: Vec<(tunnel::TunnelSpec, Arc<tokio::sync::Mutex<tunnel::TunnelStatus>>)> = {
        let map = tunnels.lock().await;
        map.values().map(|t| (t.spec.clone(), Arc::clone(&t.status))).collect()
    };
    let mut running: Vec<tunnel::TunnelSpec> = Vec::new();
    for (spec, status) in candidates {
        if status.lock().await.session_id == sid {
            running.push(spec);
        }
    }
    for spec in specs {
        // A rule the user stopped stays down until they start it again.
        if spec.stopped || running.contains(&spec) {
            continue;
        }
        match tunnel::start_tunnel(
            app.clone(),
            sid.to_string(),
            Arc::clone(handle),
            Arc::clone(tunnels),
            Arc::clone(targets),
            spec.clone(),
        )
        .await
        {
            Ok(id) => {
                emit_log(&format!("Tunnel started [{}]: {} {}", id, spec.kind, spec.local), "info");
                let mut map = specs_map.lock().await;
                let entry = map.entry(sid.to_string()).or_insert_with(Vec::new);
                if !entry.contains(&spec) {
                    entry.push(spec);
                }
            }
            Err(e) => {
                // KEEP the spec so the next reconnect retries it — never strip a
                // user's tunnel on a transient restore failure (see the matching
                // inline-restore comment; the old strip caused permanent loss of
                // forwards on flaky networks). Ensure it's present in the replay
                // list so a spec seeded from the DB (not yet recorded) survives.
                emit_log(&format!("Tunnel start failed ({} {}): {} — will retry on next reconnect", spec.kind, spec.local, e), "error");
                let mut map = specs_map.lock().await;
                let entry = map.entry(sid.to_string()).or_insert_with(Vec::new);
                if !entry.contains(&spec) {
                    entry.push(spec);
                }
            }
        }
    }
}

/// The forwarding rules saved on a node (its `tunnels` column).
fn saved_tunnel_rules(db_state: &DbState, server_id: i32) -> Result<Vec<tunnel::TunnelSpec>, String> {
    let conn_guard = db_state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
    let conn = conn_guard.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;
    let mut stmt = conn
        .prepare("SELECT tunnels FROM servers WHERE id=?1")
        .map_err(|e| e.to_string())?;
    let mut rows = stmt.query([server_id]).map_err(|e| e.to_string())?;
    let json = match rows.next().map_err(|e| e.to_string())? {
        Some(row) => row
            .get::<_, Option<String>>(0)
            .unwrap_or_default()
            .unwrap_or_else(|| "[]".to_string()),
        None => "[]".to_string(),
    };
    // Forwards held for this device's OK come back stopped (see approvals.rs).
    let json = approvals::hold_tunnels_json(conn, server_id as i64, json);
    Ok(serde_json::from_str(&json).unwrap_or_default())
}

/// Make sure the session has its rule list before the user changes it. A
/// session that hasn't engaged its tunnels yet has none (the dedicated
/// connection is still coming up, or the node was just edited): it starts
/// from the node's saved rules, the way connecting would. Starting from an
/// empty list instead would save just the changed rule over all the others.
async fn ensure_session_rules(
    state: &SshState,
    db_state: &DbState,
    session_id: &str,
    server_id: Option<i32>,
) -> Result<(), String> {
    let server_id = server_id.unwrap_or(0);
    if server_id <= 0 || state.session_tunnel_specs.lock().await.contains_key(session_id) {
        return Ok(());
    }
    let saved = saved_tunnel_rules(db_state, server_id)?;
    // Whatever got there in the meantime (a connect) wins: it read the same rules.
    state
        .session_tunnel_specs
        .lock()
        .await
        .entry(session_id.to_string())
        .or_insert(saved);
    Ok(())
}

#[tauri::command]
async fn start_tunnel(
    app: tauri::AppHandle,
    state: tauri::State<'_, SshState>,
    db_state: tauri::State<'_, DbState>,
    session_id: String,
    server_id: Option<i32>,
    spec: tunnel::TunnelSpec,
) -> Result<String, String> {
    // A new forward, or a stopped rule started again: it runs from now on.
    let spec = tunnel::TunnelSpec {
        name: tunnel::clean_name(spec.name.as_deref()),
        stopped: false,
        ..spec
    };
    ensure_session_rules(state.inner(), db_state.inner(), &session_id, server_id).await?;
    // Dedicated-transport aware: rides the `::fwd` connection when one is up,
    // the primary otherwise. The tunnel is TAGGED under the plain session id
    // either way, so the Tunnels panel / list / teardown never re-key.
    let (handle, forwarded) = resolve_tunnel_transport(state.inner(), &session_id).await?;
    let id = tunnel::start_tunnel(app, session_id.clone(), handle, Arc::clone(&state.tunnels), forwarded, spec.clone()).await?;
    // Record the rule against the session so a future reconnect re-opens it
    // and the panel can save it to the node. One rule per forward, so
    // starting the same one again doesn't add a duplicate.
    {
        let mut map = state.session_tunnel_specs.lock().await;
        tunnel::rule_started(map.entry(session_id).or_default(), &spec);
    }
    // The user started it: a forward held for their OK (see approvals.rs)
    // has it now.
    if let Some(server_id) = server_id.filter(|id| *id > 0) {
        let allowed = {
            let conn_guard = db_state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
            match conn_guard.as_ref().and_then(|conn| approvals::server_uuid(conn, server_id as i64).map(|u| (conn, u))) {
                Some((conn, uuid)) => approvals::allow(conn, &uuid, &[approvals::tunnel_item(&spec)])?,
                None => 0,
            }
        };
        if allowed > 0 {
            save_vault_internal(&db_state)?;
        }
    }
    Ok(id)
}

/// Stop a running tunnel. Its rule stays, marked stopped: the panel still
/// lists it, nothing starts it again until the user does, and saving keeps it
/// on the node. `remove_tunnel_rule` is what deletes a rule.
#[tauri::command]
async fn stop_tunnel(
    state: tauri::State<'_, SshState>,
    db_state: tauri::State<'_, DbState>,
    tunnel_id: String,
    server_id: Option<i32>,
) -> Result<(), String> {
    // Snapshot spec + session BEFORE stop — the listener task removes itself
    // from the tunnels map on exit, racing this lookup.
    let snapshot = {
        let map = state.tunnels.lock().await;
        match map.get(&tunnel_id) {
            Some(t) => {
                let status = t.status.lock().await;
                Some((t.spec.clone(), status.session_id.clone()))
            }
            None => None,
        }
    };
    if let Some((_, sid)) = &snapshot {
        ensure_session_rules(state.inner(), db_state.inner(), sid, server_id).await?;
    }
    tunnel::stop_tunnel(&state.tunnels, &tunnel_id).await?;
    if let Some((spec, sid)) = snapshot {
        let mut map = state.session_tunnel_specs.lock().await;
        if let Some(rules) = map.get_mut(&sid) {
            tunnel::rule_stopped(rules, &spec);
        }
    }
    Ok(())
}

/// The session's forwarding rules: running and stopped ones alike. Before the
/// session has engaged its tunnels, the node's saved rules.
#[tauri::command]
async fn list_tunnel_rules(
    state: tauri::State<'_, SshState>,
    db_state: tauri::State<'_, DbState>,
    session_id: String,
    server_id: Option<i32>,
) -> Result<Vec<tunnel::TunnelSpec>, String> {
    if let Some(rules) = state.session_tunnel_specs.lock().await.get(&session_id) {
        return Ok(rules.clone());
    }
    match server_id {
        Some(id) if id > 0 => saved_tunnel_rules(db_state.inner(), id),
        _ => Ok(Vec::new()),
    }
}

/// Delete a forwarding rule from the session, stopping it first if it runs.
#[tauri::command]
async fn remove_tunnel_rule(
    state: tauri::State<'_, SshState>,
    db_state: tauri::State<'_, DbState>,
    session_id: String,
    server_id: Option<i32>,
    spec: tunnel::TunnelSpec,
) -> Result<(), String> {
    ensure_session_rules(state.inner(), db_state.inner(), &session_id, server_id).await?;
    // Two-phase, as in tunnel::stop_all_for_session: ids under the map lock,
    // the session check after releasing it.
    let candidates: Vec<(String, Arc<tokio::sync::Mutex<tunnel::TunnelStatus>>)> = {
        let map = state.tunnels.lock().await;
        map.iter()
            .filter(|(_, t)| t.spec == spec)
            .map(|(id, t)| (id.clone(), Arc::clone(&t.status)))
            .collect()
    };
    for (id, status) in candidates {
        if status.lock().await.session_id == session_id {
            // Already gone is fine: the point is that it isn't running.
            let _ = tunnel::stop_tunnel(&state.tunnels, &id).await;
        }
    }
    if let Some(rules) = state.session_tunnel_specs.lock().await.get_mut(&session_id) {
        tunnel::rule_removed(rules, &spec);
    }
    Ok(())
}

/// Give a forwarding rule a name, or take it away (an empty name).
#[tauri::command]
async fn rename_tunnel_rule(
    state: tauri::State<'_, SshState>,
    db_state: tauri::State<'_, DbState>,
    session_id: String,
    server_id: Option<i32>,
    spec: tunnel::TunnelSpec,
    name: Option<String>,
) -> Result<(), String> {
    ensure_session_rules(state.inner(), db_state.inner(), &session_id, server_id).await?;
    let mut map = state.session_tunnel_specs.lock().await;
    let renamed = map
        .get_mut(&session_id)
        .map(|rules| tunnel::rule_renamed(rules, &spec, name.as_deref()))
        .unwrap_or(false);
    if renamed {
        Ok(())
    } else {
        Err("此转发已不在列表中。".into())
    }
}

#[tauri::command]
async fn list_tunnels(
    state: tauri::State<'_, SshState>,
    session_id: Option<String>,
) -> Result<Vec<tunnel::TunnelStatus>, String> {
    Ok(tunnel::list_tunnels(&state.tunnels, session_id.as_deref()).await)
}

/// Persist the session's forwarding rules (running and stopped, with their
/// names) to the node's saved `tunnels` column so changes a user makes during
/// a session survive to the next time the node is opened. The Tunnels panel
/// calls this after each change. A quick-connect session (server_id <= 0) has
/// no node to save to, so it's a no-op.
#[tauri::command]
async fn persist_session_tunnels(
    state: tauri::State<'_, SshState>,
    db_state: tauri::State<'_, DbState>,
    session_id: String,
    server_id: i32,
) -> Result<(), String> {
    if server_id <= 0 {
        return Ok(());
    }
    // No list means the session never engaged its rules (or the node was just
    // edited, which drops it): the node's rules are already what there is,
    // and writing an empty list would erase them.
    let Some(mut specs) = state.session_tunnel_specs.lock().await.get(&session_id).cloned() else {
        return Ok(());
    };
    {
        // Scoped so the non-Send rusqlite guard drops before save_vault_internal.
        let conn_guard = db_state.conn.lock().map_err(|_| "[STATE] LOCK_FAILED")?;
        let conn = conn_guard.as_ref().ok_or("[STATE] DATABASE_NOT_INITIALIZED")?;
        // A forward held for this device's OK sits stopped in the session only
        // on this device. What is saved keeps the node's own stopped flag for
        // it, so the hold never reaches the people the profile is shared with.
        if let Some(uuid) = approvals::server_uuid(conn, server_id as i64) {
            let held = approvals::held_for(conn, &uuid);
            if held.iter().any(|i| i.starts_with("tunnel:")) {
                let saved: Vec<tunnel::TunnelSpec> = conn
                    .query_row("SELECT tunnels FROM servers WHERE id=?1", [server_id], |r| r.get::<_, Option<String>>(0))
                    .ok()
                    .flatten()
                    .and_then(|j| serde_json::from_str(&j).ok())
                    .unwrap_or_default();
                for spec in specs.iter_mut().filter(|s| held.contains(&approvals::tunnel_item(s))) {
                    if let Some(s) = saved.iter().find(|s| *s == &*spec) {
                        spec.stopped = s.stopped;
                    }
                }
            }
        }
        let json = serde_json::to_string(&specs).unwrap_or_else(|_| "[]".to_string());
        conn.execute(
            "UPDATE servers SET tunnels=?1 WHERE id=?2",
            rusqlite::params![json, server_id],
        )
        .map_err(|e| format!("[DATABASE] TUNNELS_SAVE_FAILED: SQL_ERROR={}", e))?;
    }
    save_vault_internal(&db_state)?;
    Ok(())
}

/// (Re)start every tunnel the session should have — the in-memory replay list
/// when it's non-empty, else the node's saved tunnels JSON — on the best
/// available transport (`::fwd` when the dedicated connection is up, primary
/// otherwise). Idempotent: specs already running under the session's tag are
/// skipped. The frontend calls this to restore forwarding after the dedicated
/// connection fails or is toggled off, so tunnels always land somewhere.
#[tauri::command]
async fn restart_session_tunnels(
    app: tauri::AppHandle,
    state: tauri::State<'_, SshState>,
    db_state: tauri::State<'_, DbState>,
    session_id: String,
    server_id: i32,
) -> Result<(), String> {
    // In-memory replay list first — it carries ad-hoc tunnels too. A PRESENT
    // list (even empty) is authoritative (user stopped everything); only seed
    // from the node's saved tunnels when the key is ABSENT (first engagement),
    // so explicitly-stopped tunnels don't resurrect on a restore.
    let existing: Option<Vec<tunnel::TunnelSpec>> =
        state.session_tunnel_specs.lock().await.get(&session_id).cloned();
    let mut specs: Vec<tunnel::TunnelSpec> = existing.clone().unwrap_or_default();
    if existing.is_none() && server_id > 0 {
        specs = saved_tunnel_rules(db_state.inner(), server_id)?;
        if !specs.is_empty() {
            state
                .session_tunnel_specs
                .lock()
                .await
                .insert(session_id.clone(), specs.clone());
        }
    }
    // Nothing to start: no rules, or only ones the user stopped.
    if !specs.iter().any(|spec| !spec.stopped) {
        return Ok(());
    }

    let (handle, targets) = resolve_tunnel_transport(state.inner(), &session_id).await?;
    start_tunnel_specs_on(
        &app,
        &session_id,
        &handle,
        &targets,
        &state.tunnels,
        &state.session_tunnel_specs,
        specs,
    )
    .await;
    Ok(())
}

// ----- Mirror commands -----------------------------------------------------

#[tauri::command]
async fn mirror_dry_run(
    ssh: tauri::State<'_, SshState>,
    session_id: String,
    spec: mirror::MirrorSpec,
) -> Result<mirror::DryRunReport, String> {
    let handle = {
        let conns = ssh.connections.lock().await;
        conns.get(&session_id).cloned()
            .ok_or_else(|| "Session not connected".to_string())?
    };
    mirror::dry_run(handle, spec).await
}

#[tauri::command]
async fn start_mirror(
    app: tauri::AppHandle,
    ssh: tauri::State<'_, SshState>,
    mirrors: tauri::State<'_, MirrorMap>,
    session_id: String,
    spec: mirror::MirrorSpec,
) -> Result<String, String> {
    let handle = {
        let conns = ssh.connections.lock().await;
        conns.get(&session_id).cloned()
            .ok_or_else(|| "Session not connected".to_string())?
    };
    mirror::start(app, session_id, handle, Arc::clone(&mirrors), spec).await
}

#[tauri::command]
async fn stop_mirror(
    mirrors: tauri::State<'_, MirrorMap>,
    mirror_id: String,
) -> Result<(), String> {
    mirror::stop(&mirrors, &mirror_id).await
}

#[tauri::command]
async fn list_mirrors(
    mirrors: tauri::State<'_, MirrorMap>,
    session_id: Option<String>,
) -> Result<Vec<mirror::MirrorStatus>, String> {
    Ok(mirror::list(&mirrors, session_id.as_deref()).await)
}

/// Native OS folder picker. Used by MirrorsPanel to fill in `local`.
#[tauri::command]
async fn pick_local_directory() -> Result<Option<String>, String> {
    #[cfg(target_os = "android")]
    {
        return Err("Android 上不支持选择文件夹。".into());
    }
    #[cfg(not(target_os = "android"))]
    {
        let path = rfd::AsyncFileDialog::new().pick_folder().await;
        Ok(path.map(|p| p.path().to_string_lossy().into_owned()))
    }
}

// ----- Shell config sync commands -------------------------------------------
// "Push my shell config": a one-shot push of this device's dotfiles to the
// server of an open session (see mirror.rs' shell_sync_* functions). Which
// files go where, and which servers offer the button, are this device's own
// settings (src/util/shellSync.ts): nothing about it is in the vault or
// synced. Never automatic on connect.

/// Prints the account's login shell between markers, so that whatever its
/// startup files print can't be taken for it.
const SHELL_SYNC_PROBE_SCRIPT: &str = "printf '__SUB_SHELL__%s__SUB_SHELL__\\n' \"$SHELL\"\n";

#[derive(serde::Serialize)]
struct ShellSyncProbe {
    remote_shell: String,
    // Empty when this device has no login shell to compare (Windows).
    local_shell: String,
    shell_mismatch: bool,
}

fn shell_basename(path: &str) -> String {
    std::path::Path::new(path.trim())
        .file_name()
        .map(|n| n.to_string_lossy().into_owned())
        .unwrap_or_default()
}

/// The account's login shell next to this device's, for a note in the push
/// dialog: the files of one shell do nothing for another. Nothing is run on
/// the server when this device has no login shell to compare.
#[tauri::command]
async fn shell_sync_probe(
    state: tauri::State<'_, SshState>,
    session_id: String,
) -> Result<ShellSyncProbe, String> {
    let local_shell = shell_basename(&std::env::var("SHELL").unwrap_or_default());
    if local_shell.is_empty() {
        return Ok(ShellSyncProbe { remote_shell: String::new(), local_shell, shell_mismatch: false });
    }
    let result = run_info_script(&state, &session_id, SHELL_SYNC_PROBE_SCRIPT, 10).await?;
    let remote_shell = result.data.split("__SUB_SHELL__").nth(1).unwrap_or("").trim().to_string();
    let remote_name = shell_basename(&remote_shell);
    let shell_mismatch = !remote_name.is_empty() && local_shell != remote_name;
    Ok(ShellSyncProbe { remote_shell, local_shell, shell_mismatch })
}

/// The pairs as typed, checked before anything is opened on the server. A
/// local path is a full path or starts with `~`, exists, isn't the whole home
/// folder, and passes the policy an upload's source does; the remote side is
/// a place below the home folder there. Every problem is reported, one per
/// line.
fn shell_sync_targets(pairs: &[mirror::ShellSyncPair]) -> Result<Vec<mirror::ShellSyncTarget>, String> {
    if pairs.is_empty() {
        return Err("暂无可推送的内容：请在「设置 → Shell 配置同步」中添加文件。".into());
    }
    let home = directories::UserDirs::new().and_then(|d| d.home_dir().canonicalize().ok());
    let mut targets = Vec::new();
    let mut problems = Vec::new();
    for pair in pairs {
        let local = pair.local.trim();
        let remote = pair.remote.trim();
        let remote_shown = if remote.is_empty() { "~" } else { remote };
        if local.is_empty() {
            problems.push(format!("→ {}: no local file or folder", remote_shown));
            continue;
        }
        let expanded = expand_home(local);
        if local == "~" || local == "~/" || local == "~\\" {
            problems.push(format!("{}: pick files or folders in the home folder, not all of it", local));
            continue;
        }
        if !expanded.is_absolute() {
            problems.push(format!("{}: give a full path, or one that starts with ~", local));
            continue;
        }
        let resolved = match guard_local_path(&expanded.to_string_lossy(), false) {
            Ok(p) => p,
            Err(e) => {
                problems.push(format!("{}: {}", local, e));
                continue;
            }
        };
        if home.as_deref() == Some(resolved.as_path()) {
            problems.push(format!("{}: pick files or folders in the home folder, not all of it", local));
            continue;
        }
        let rel = match mirror::shell_sync_remote_rel(remote) {
            Ok(r) => r,
            Err(e) => {
                problems.push(format!("{} → {}: {}", local, remote_shown, e));
                continue;
            }
        };
        if rel.is_empty() && !resolved.is_dir() {
            problems.push(format!("{} → {}: give the file a name on the server", local, remote_shown));
            continue;
        }
        targets.push(mirror::ShellSyncTarget { local: resolved, rel });
    }
    if problems.is_empty() { Ok(targets) } else { Err(problems.join("\n")) }
}

#[tauri::command]
async fn shell_sync_preview(
    ssh: tauri::State<'_, SshState>,
    session_id: String,
    pairs: Vec<mirror::ShellSyncPair>,
) -> Result<mirror::ShellSyncReport, String> {
    let targets = shell_sync_targets(&pairs)?;
    let handle = {
        let conns = ssh.connections.lock().await;
        conns.get(&session_id).cloned()
            .ok_or_else(|| "Session not connected".to_string())?
    };
    mirror::shell_sync_preview(handle, targets).await
}

#[tauri::command]
async fn shell_sync_push(
    ssh: tauri::State<'_, SshState>,
    session_id: String,
    pairs: Vec<mirror::ShellSyncPair>,
) -> Result<mirror::ShellSyncPushReport, String> {
    let targets = shell_sync_targets(&pairs)?;
    let handle = {
        let conns = ssh.connections.lock().await;
        conns.get(&session_id).cloned()
            .ok_or_else(|| "Session not connected".to_string())?
    };
    mirror::shell_sync_push(handle, targets).await
}

#[cfg(test)]
mod shell_sync_tests {
    use super::*;

    fn pair(local: &str, remote: &str) -> mirror::ShellSyncPair {
        mirror::ShellSyncPair { local: local.into(), remote: remote.into() }
    }

    #[test]
    fn shell_basename_takes_the_last_path_component() {
        assert_eq!(shell_basename("/usr/bin/zsh"), "zsh");
        assert_eq!(shell_basename("/bin/bash\n"), "bash"); // trailing newline from `echo $SHELL`
        assert_eq!(shell_basename(""), "");
    }

    #[test]
    fn shell_sync_targets_takes_existing_full_paths_and_places_below_home() {
        let dir = std::env::temp_dir().join(format!("sub-shellsync-t-{}", std::process::id()));
        std::fs::create_dir_all(&dir).unwrap();
        let file = dir.join("rc");
        std::fs::write(&file, b"x").unwrap();
        let file_s = file.to_string_lossy().into_owned();
        let dir_s = dir.to_string_lossy().into_owned();

        let ok = shell_sync_targets(&[pair(&file_s, "~/.zshrc"), pair(&dir_s, "~")]).unwrap();
        assert_eq!(ok.iter().map(|t| t.rel.as_str()).collect::<Vec<_>>(), [".zshrc", ""]);

        assert!(shell_sync_targets(&[]).is_err());
        for (local, remote) in [
            ("rc", ".zshrc"),           // relative
            ("~", "x"),                 // the whole home folder
            ("", ".zshrc"),             // nothing
            (file_s.as_str(), "~"),     // a file in the home folder's place
            (file_s.as_str(), "../x"),  // out of the home folder
            (file_s.as_str(), "/etc/x"),
        ] {
            assert!(shell_sync_targets(&[pair(local, remote)]).is_err(), "{local} -> {remote}");
        }
        let missing = dir.join("missing").to_string_lossy().into_owned();
        assert!(shell_sync_targets(&[pair(&missing, ".x")]).is_err());
        // Every problem is reported, not just the first.
        let both = shell_sync_targets(&[pair("rc", ".a"), pair(&missing, ".b")]).unwrap_err();
        assert_eq!(both.lines().count(), 2, "{both}");

        std::fs::remove_dir_all(&dir).unwrap();
    }
}

#[tauri::command]
async fn disconnect_session(
    app: tauri::AppHandle,
    state: tauri::State<'_, SshState>,
    mirrors: tauri::State<'_, MirrorMap>,
    session_id: String,
) -> Result<(), String> {
    // Invalidate any connect worker still handshaking for THIS key: bump the
    // generation before removing anything, so a late auth-success hits its
    // "still wanted?" guard and drops instead of re-registering a transport the
    // user just turned off (which would then steal / strand tunnels). Done for
    // every key, including secondaries — this is the toggle-off / reconnect-
    // button invalidation path.
    {
        let mut g = state.session_generation.lock().await;
        let next = g.get(&session_id).copied().unwrap_or(0).wrapping_add(1);
        g.insert(session_id.clone(), next);
    }
    // Disconnecting a dedicated transport directly (toggle-off / reconnect
    // button): tunnels are tagged under the BASE session id but ride this
    // `::fwd` connection. Stop them ONLY when the dedicated connection actually
    // exists — i.e. the tunnels really are riding it. If it's absent (a failed
    // `::fwd` that never registered, so the tunnels fell back to the primary),
    // stopping base-tagged tunnels here would needlessly bounce every live
    // primary tunnel. The caller restarts them on the best transport via
    // restart_session_tunnels afterwards.
    if let Some(base) = session_id.strip_suffix("::fwd") {
        if state.connections.lock().await.contains_key(&session_id) {
            tunnel::stop_all_for_session(&state.tunnels, base).await;
        }
    }
    // `::sftp`: remove the dedicated transport FIRST, then purge the base SFTP
    // cache — so an SFTP op racing this teardown can't re-cache a subsystem on
    // the dying transport after the purge (get_sftp_session's still-current
    // check would then see the transport gone and refuse to cache).
    if session_id.ends_with("::sftp") {
        state.connections.lock().await.remove(&session_id);
        if let Some(base) = session_id.strip_suffix("::sftp") {
            state.sftp_sessions.lock().await.remove(base);
        }
    }
    // Stop all forwarders so their listener sockets are released before the
    // SSH handle is dropped (otherwise newly-incoming connections would just
    // bounce off a dead channel).
    tunnel::stop_all_for_session(&state.tunnels, &session_id).await;
    state.forwarded_targets.lock().await.remove(&session_id);
    // Explicit user disconnect — drop the replay list too. (Auto-reconnect
    // calls `initiate_connection` directly and never hits this path, so
    // those tunnels survive the cycle.)
    state.session_tunnel_specs.lock().await.remove(&session_id);
    // Same idea for any mirror that's still running — its watcher would
    // try to push uploads through a dead SSH handle otherwise.
    mirror::stop_all_for_session(&mirrors, &session_id).await;
    // Drop SFTP first so the channel it holds is freed before we tear down the
    // underlying SSH handle. The tab is gone, so is its root (sudo) mode and
    // the in-memory sudo password.
    state.sftp_sessions.lock().await.remove(&session_id);
    state.sftp_elevation.lock().await.remove(&session_id);
    state.connections.lock().await.remove(&session_id);
    // Drop any ProxyJump bastion handle for this session — closes the jump
    // connection once the target it was carrying is gone.
    state.jump_connections.lock().await.remove(&session_id);
    // Drop terminal tx/resize entries so a subsequent reconnect doesn't try
    // to write into a dead PTY task. Match by the exact `${session_id}-term-`
    // prefix — a `contains` here silently tears down session-10's terminals
    // when the user disconnects session-1.
    let term_prefix = format!("{}-term-", session_id);
    state.terminal_txs.lock().await.retain(|k, _| !k.starts_with(&term_prefix));
    state.resize_txs.lock().await.retain(|k, _| !k.starts_with(&term_prefix));
    // Wipe any temp files this session left behind (live-edit downloads + drag
    // staging). Best-effort: failures are usually because an editor still holds
    // a lock on a file, in which case the file persists until the OS cleans temp.
    for dir in [session_sftp_dir(&session_id), session_drag_dir(&session_id)].into_iter().flatten() {
        if dir.exists() {
            let _ = std::fs::remove_dir_all(&dir);
        }
    }
    // Separate-sessions: reap the dedicated `::sftp` / `::fwd` secondaries so an
    // explicit primary disconnect doesn't leak their SSH sessions. Only when
    // this IS a primary id (no `::` suffix) — a direct disconnect of a secondary
    // must not recurse into non-existent grandchildren.
    if !session_id.contains("::") {
        teardown_connection_key(state.inner(), mirrors.inner(), &format!("{}::sftp", session_id)).await;
        teardown_connection_key(state.inner(), mirrors.inner(), &format!("{}::fwd", session_id)).await;
        // Explicitly disconnecting a whole tab also forgets any connect-time
        // secret the user typed for it (issue #30) — a fresh connect re-asks.
        // Gated to a base id so toggling a `::sftp` / `::fwd` secondary off
        // keeps the still-live primary's cache intact. Entries are keyed
        // `<tab>|<target>` (see secrets_target), so drop every one of the tab's.
        let tab_prefix = format!("{}|", session_id);
        state
            .prompted_secrets
            .lock()
            .await
            .retain(|key, _| key != &session_id && !key.starts_with(&tab_prefix));
    }
    // Tell the UI so the tab status dot flips to red. `user_initiated` keeps
    // SessionView from kicking off an auto-reconnect cycle for an intentional
    // disconnect — distinct from the watcher path which has no such flag.
    use tauri::Emitter;
    let _ = app.emit(
        &format!("session-disconnected-{}", session_id),
        serde_json::json!({
            "reason": "User disconnected",
            "user_initiated": true,
        }),
    );
    Ok(())
}

// The shell this computer's own terminals start, for Settings → Terminal →
// "Use my default shell": `$SHELL`, which the login session sets on Linux and
// macOS desktops (and launchd for an app started from Finder). Windows and
// Android have no such shell, so the setting does nothing there and the
// settings page doesn't offer it (see `local_shell`). The path is sent to the
// server, so only a plain absolute one is taken (`is_safe_remote_exec_path`).
#[cfg(all(unix, not(target_os = "android")))]
fn local_default_shell() -> Option<String> {
    let shell = std::env::var("SHELL").ok()?;
    let shell = shell.trim();
    is_safe_remote_exec_path(shell).then(|| shell.to_string())
}

#[cfg(not(all(unix, not(target_os = "android"))))]
fn local_default_shell() -> Option<String> {
    None
}

/// The shell "Use my default shell" starts; none where the setting does
/// nothing.
#[tauri::command]
fn local_shell() -> Option<String> {
    local_default_shell()
}

// Starts `$1` as a login shell, with $SHELL naming it for the programs that
// start a shell of their own (tmux, vim's :sh). If it has gone since
// `server_runs_login_shell` looked, the account's own shell starts instead
// (sshd sets $SHELL to it). Sent as `sh -c '<script>' sh <shell>`: the
// account's shell, whatever it is (fish and csh included), only runs a plain
// command, and the path arrives as an argument, never inside the script.
const LOGIN_SHELL_SCRIPT: &str =
    r#"if [ -x "$1" ]; then SHELL=$1; export SHELL; exec "$1" -l; fi; exec "${SHELL:-/bin/sh}" -l"#;

fn login_shell_command(shell: &str) -> String {
    format!("sh -c '{}' sh {}", LOGIN_SHELL_SCRIPT, crate::docker::shq(shell))
}

// Whether the server can start `shell` that way: it takes exec requests, it
// has a POSIX sh, and the shell is there. A Windows server, an appliance that
// only offers a plain shell, or a server without that shell fails this and
// gets the plain shell request, as with the setting off: a terminal opens in
// any case. Asked on a channel of its own, before the terminal's.
async fn server_runs_login_shell(session_arc: &SessionHandleArc, shell: &str) -> bool {
    let cmd = format!("sh -c '[ -x \"$1\" ] && echo __SUB_SHELL:OK' sh {}", crate::docker::shq(shell));
    matches!(
        exec_with_stdin_capture(session_arc, &cmd, None, 4).await,
        Ok(out) if out.lines().any(|line| line.trim() == "__SUB_SHELL:OK")
    )
}

#[tauri::command]
async fn open_terminal(app: tauri::AppHandle, state: tauri::State<'_, SshState>, session_id: String, terminal_id: String, cols: u32, rows: u32, use_local_shell: bool) -> Result<(), String> {
    use std::sync::Arc;
    use crate::ssh_manager::TerminalCommand;

    let session_arc = {
        let mut connections = state.connections.lock().await;
        if let Some(sess) = connections.get_mut(&session_id) {
            Arc::clone(sess)
        } else {
            return Err("Session not connected".into());
        }
    };

    // Settings → Terminal → "Use my default shell": this computer's shell,
    // started on the server as a login shell in place of the account's own
    // (LOGIN_SHELL_SCRIPT), where the server can (server_runs_login_shell);
    // otherwise, and with the setting off, the account's own shell. Asked
    // before the session is locked for the terminal's channel.
    let login_shell = match use_local_shell.then(local_default_shell).flatten() {
        Some(shell) if server_runs_login_shell(&session_arc, &shell).await => Some(shell),
        _ => None,
    };

    let session = session_arc.lock().await;
    let channel = session.channel_open_session().await.map_err(|e| e.to_string())?;

    // Request PTY
    channel.request_pty(false, "xterm-256color", cols, rows, 0, 0, &[]).await.map_err(|e| e.to_string())?;
    match login_shell {
        Some(shell) => channel.exec(true, login_shell_command(&shell).as_bytes()).await,
        None => channel.request_shell(true).await,
    }
    .map_err(|e| e.to_string())?;

    let (tx, rx) = tokio::sync::mpsc::channel::<TerminalCommand>(32);
    // Last-wins watch channel for PTY resizes. The PTY task selects on
    // changes; bursty resize events (e.g. window drag) collapse to the
    // final value rather than competing with keystrokes on the data
    // mpsc. Seed with the initial size so the watch is always populated.
    let (resize_tx, resize_rx) = tokio::sync::watch::channel(
        crate::ssh_manager::PtySize { cols, rows },
    );
    state.terminal_txs.lock().await.insert(terminal_id.clone(), tx);
    state.resize_txs.lock().await.insert(terminal_id.clone(), resize_tx);

    // Output coalescing, keystroke / resize forwarding and the split,
    // always-draining read/write pump (required by russh's channel
    // backpressure) live in ssh_manager::run_pty_pump — shared with the
    // docker exec terminal.
    tauri::async_runtime::spawn(crate::ssh_manager::run_pty_pump(
        app.clone(),
        terminal_id.clone(),
        channel,
        rx,
        resize_rx,
    ));

    Ok(())
}

#[tauri::command]
async fn write_terminal_data(state: tauri::State<'_, SshState>, terminal_id: String, data: Vec<u8>) -> Result<(), String> {
    use crate::ssh_manager::TerminalCommand;
    // Clone the Sender OUT of the map, then release the map lock before we
    // await on send(). If we held the guard across the send, a saturated
    // 32-slot mpsc on a slow SSH link would block every other terminal's
    // write path — one slow terminal freezes the entire app-wide typing
    // experience because the shared map guard is a global gate.
    // mpsc::Sender is cheap to clone.
    let tx = state.terminal_txs.lock().await.get(&terminal_id).cloned();
    if let Some(tx) = tx {
        let _ = tx.send(TerminalCommand::Data(data)).await;
    }
    Ok(())
}

#[tauri::command]
async fn resize_terminal(state: tauri::State<'_, SshState>, terminal_id: String, cols: u32, rows: u32) -> Result<(), String> {
    if let Some(tx) = state.resize_txs.lock().await.get(&terminal_id) {
        // send_replace overwrites the current value unconditionally —
        // perfect for a coalescing last-wins channel.
        let _ = tx.send(crate::ssh_manager::PtySize { cols, rows });
    }
    Ok(())
}

#[tauri::command]
async fn close_terminal(state: tauri::State<'_, SshState>, terminal_id: String) -> Result<(), String> {
    state.terminal_txs.lock().await.remove(&terminal_id);
    state.resize_txs.lock().await.remove(&terminal_id);
    Ok(())
}

// Read-only Info-panel probes. Each tab fetches its own section on first
// click — the user explicitly wanted lazy per-tab fetch instead of one
// upfront mega-probe. Splitting the scripts keeps each round-trip small
// (≤200 ms typical) and lets a failing section never block the others.
const INFO_SCRIPT_OVERVIEW: &str = r#"echo __SUB_INFO_OV_SEP__
hostname 2>/dev/null
echo __SUB_INFO_OV_SEP__
( . /etc/os-release 2>/dev/null && printf "%s" "$PRETTY_NAME" ) || cat /etc/issue 2>/dev/null
printf "\n"
echo __SUB_INFO_OV_SEP__
uname -srm 2>/dev/null
echo __SUB_INFO_OV_SEP__
uptime 2>/dev/null
echo __SUB_INFO_OV_SEP__
# Memory. procps `free -b` gives bytes + an `available` column; busybox `free`
# ignores `-b` (prints KiB) and has no `available`, so fall back to the
# universal /proc/meminfo (kB) with a format tag the frontend switches on.
if F=$(free -b 2>/dev/null) && printf '%s' "$F" | grep -q '^Mem:'; then
  printf 'MEMFMT:free-b\n'; printf '%s\n' "$F"
else
  printf 'MEMFMT:meminfo\n'; cat /proc/meminfo 2>/dev/null
fi
echo __SUB_INFO_OV_SEP__
# Disks. `-T` (fs-type column) + `-k` (1 KiB blocks) is GNU coreutils; busybox
# df lacks `-T`, so fall back to the no-type layout. `-k` pins the block size
# so the frontend's *1024 is always correct.
if D=$(df -PTk 2>/dev/null) && [ -n "$D" ]; then
  printf 'DFFMT:pt\n'; printf '%s\n' "$D"
else
  printf 'DFFMT:p\n'; df -Pk 2>/dev/null
fi
echo __SUB_INFO_OV_SEP__
# CPU count: coreutils nproc -> POSIX getconf -> /proc/cpuinfo (universal floor).
nproc 2>/dev/null || getconf _NPROCESSORS_ONLN 2>/dev/null || grep -c '^processor' /proc/cpuinfo 2>/dev/null
echo __SUB_INFO_OV_SEP__
cat /proc/loadavg 2>/dev/null
echo __SUB_INFO_OV_SEP__
"#;

// Network probe layout (sections delimited by SEP):
//   [0] empty (printed before first SEP)
//   [1] NIC list   — first line `ADDRFMT:<ip-json|ip-oneline|ifconfig|none>`
//   [2] route table — first line `ROUTEFMT:<ip-json|ip-oneline|route|netstat|none>`
//   [3] firewall summary:
//         line 1: 'FW:<engine>' where engine is one of
//                 firewalld | firewalld-sudo |
//                 ufw       | ufw-sudo       |
//                 iptables  | iptables-sudo  | iptables-denied |
//                 nft       | nft-sudo       | nft-denied       | none
//         A high-level manager (firewalld on RHEL/Fedora, ufw on Ubuntu) is
//         detected FIRST and, when running, shown instead of the raw tables
//         it auto-generates. Body rows depend on the engine:
//                 firewalld: 'DEFAULT|<zone>' then per active zone
//                            'ZONE|<zone>|<interfaces>',
//                            'SVC|<zone>|<services>', 'PORT|<zone>|<ports>'
//                 ufw:       'UFW|active' then the raw `ufw status verbose`
//                            lines, shown verbatim (already human-readable)
//                 iptables:  'table|chain|policy|count'
//                 nft:       'family|table|chain|type|count'
//         For iptables/nft the rows are per-chain summaries, not the full
//         ruleset — the ruleset for a specific chain is fetched lazily on
//         expand via ssh_iptables_chain / ssh_nft_chain — the wire cost
//         of first paint drops from ~50-500 KB to ~1-2 KB, which is the
//         single biggest bandwidth win for low-bandwidth SSH users.
//         firewalld/ufw summaries are already compact, so they ship inline.
//   [4] DNS resolvers — first line `DNSFMT:list`, then raw lines from
//         resolvectl / systemd-resolve / resolv.conf; the frontend extracts
//         IPs, dedupes, and flags the systemd-resolved 127.0.0.53 stub.
// The firewall block tries the user's own credentials first, falls back to
// non-interactive sudo (`sudo -n`) so we never hang waiting for a password,
// and prefers iptables over nft because iptables-nft on modern Debian-family
// systems still reports both — picking iptables gives a consistent first
// hit even on hybrid hosts.
const INFO_SCRIPT_NETWORK: &str = r#"echo __SUB_INFO_NET_SEP__
# NIC addresses. First line is a format tag the frontend switches on. `ip -j`
# (JSON) needs iproute2 >= 4.13, so RHEL/CentOS 7 (4.11) falls back to the
# text `ip -o` layout, then net-tools ifconfig for hosts without `ip` at all.
if J=$(ip -j addr 2>/dev/null) && [ -n "$J" ]; then
  printf 'ADDRFMT:ip-json\n'; printf '%s\n' "$J"
elif command -v ip >/dev/null 2>&1; then
  printf 'ADDRFMT:ip-oneline\n'
  ip -o link show 2>/dev/null
  echo __SUB_INFO_NET_SUB__
  ip -o addr show 2>/dev/null
elif command -v ifconfig >/dev/null 2>&1; then
  printf 'ADDRFMT:ifconfig\n'; ifconfig -a 2>/dev/null
else
  printf 'ADDRFMT:none\n'
fi
echo __SUB_INFO_NET_SEP__
# Routes, same tag+fallback idea.
if J=$(ip -j route 2>/dev/null) && [ -n "$J" ]; then
  printf 'ROUTEFMT:ip-json\n'; printf '%s\n' "$J"
elif command -v ip >/dev/null 2>&1; then
  printf 'ROUTEFMT:ip-oneline\n'; ip -o route show 2>/dev/null
elif command -v route >/dev/null 2>&1; then
  printf 'ROUTEFMT:route\n'; route -n 2>/dev/null
elif command -v netstat >/dev/null 2>&1; then
  printf 'ROUTEFMT:netstat\n'; netstat -rn 2>/dev/null
else
  printf 'ROUTEFMT:none\n'
fi
echo __SUB_INFO_NET_SEP__
# High-level firewall managers FIRST. On RHEL/Fedora/Rocky/Alma (firewalld) and
# Ubuntu (ufw) the raw iptables/nft ruleset is auto-generated boilerplate the
# manager owns — showing it is confusing and doesn't reflect the operator's
# actual zones/rules. So when a manager is actually RUNNING we surface ITS view
# and skip the raw tables; only if no manager is active do we fall through to
# iptables -> nft -> none below. `FW_DONE` gates that fall-through.
FW_DONE=""
# firewalld (RHEL family default). `--state` and the list queries work over
# D-Bus and are usually readable without root; sudo -n is a fallback.
if command -v firewall-cmd >/dev/null 2>&1; then
  FC=""
  # `firewall-cmd --state` exits 0 only when the daemon is RUNNING (252 when
  # not). Rely on the exit code, not a grep — "not running" contains the
  # substring "running", so grepping would false-positive on a stopped daemon.
  if firewall-cmd --state >/dev/null 2>&1; then
    FC="firewall-cmd"; printf 'FW:firewalld\n'
  elif sudo -n firewall-cmd --state >/dev/null 2>&1; then
    FC="sudo -n firewall-cmd"; printf 'FW:firewalld-sudo\n'
  fi
  if [ -n "$FC" ]; then
    FW_DONE=1
    printf 'DEFAULT|%s\n' "$($FC --get-default-zone 2>/dev/null)"
    for Z in $($FC --get-active-zones 2>/dev/null | awk '/^[^ \t]/{print $1}'); do
      printf 'ZONE|%s|%s\n' "$Z" "$($FC --zone="$Z" --list-interfaces 2>/dev/null)"
      printf 'SVC|%s|%s\n'  "$Z" "$($FC --zone="$Z" --list-services 2>/dev/null)"
      printf 'PORT|%s|%s\n' "$Z" "$($FC --zone="$Z" --list-ports 2>/dev/null)"
    done
  fi
fi
# ufw (Debian/Ubuntu). Only surface it when ACTIVE — an installed-but-inactive
# ufw means the host is really using the raw tables, so fall through instead.
# `ufw status` needs root, so try direct then sudo -n.
if [ -z "$FW_DONE" ] && command -v ufw >/dev/null 2>&1; then
  US=""; SUF=""
  if ufw status verbose 2>/dev/null | grep -qi 'Status:'; then
    US=$(ufw status verbose 2>/dev/null)
  elif sudo -n ufw status verbose 2>/dev/null | grep -qi 'Status:'; then
    US=$(sudo -n ufw status verbose 2>/dev/null); SUF="-sudo"
  fi
  if printf '%s\n' "$US" | grep -qiE 'Status:[[:space:]]*active'; then
    printf 'FW:ufw%s\n' "$SUF"
    printf 'UFW|active\n'
    printf '%s\n' "$US"
    FW_DONE=1
  fi
fi
if [ -z "$FW_DONE" ] && command -v iptables >/dev/null 2>&1; then
  IPT=""
  # `-S` (rule-spec dump) is lighter than `-L`: no formatted table, no counter
  # columns, no reverse-DNS, no header rows — just the rules, which is all the
  # per-chain summary needs. The full ruleset for one chain is still fetched
  # lazily on expand via ssh_iptables_chain.
  if iptables -t filter -S >/dev/null 2>&1; then
    IPT="iptables"; printf 'FW:iptables\n'
  elif sudo -n iptables -t filter -S >/dev/null 2>&1; then
    IPT="sudo -n iptables"; printf 'FW:iptables-sudo\n'
  else
    printf 'FW:iptables-denied\n'
  fi
  if [ -n "$IPT" ]; then
    for T in filter nat mangle raw; do
      # -P <chain> <policy> = built-in chain + policy; -N <chain> = custom chain
      # (policy '-'); -A <chain> ... = one rule. Emit 'table|chain|policy|count'.
      $IPT -t $T -S 2>/dev/null | awk -v t="$T" '
        /^-P / { pol[$2]=$3; if(!($2 in seen)){seen[$2]=1; order[++n]=$2} next }
        /^-N / { if(!($2 in seen)){seen[$2]=1; order[++n]=$2; pol[$2]="-"} next }
        /^-A / { c=$2; cnt[c]++; if(!(c in seen)){seen[c]=1; order[++n]=c; pol[c]="-"} next }
        END { for(i=1;i<=n;i++){ ch=order[i]; print t "|" ch "|" (ch in pol?pol[ch]:"-") "|" (cnt[ch]+0) } }
      '
    done
  fi
elif [ -z "$FW_DONE" ] && command -v nft >/dev/null 2>&1; then
  NFT=""
  if nft list ruleset >/dev/null 2>&1; then
    NFT="nft"; printf 'FW:nft\n'
  elif sudo -n nft list ruleset >/dev/null 2>&1; then
    NFT="sudo -n nft"; printf 'FW:nft-sudo\n'
  else
    printf 'FW:nft-denied\n'
  fi
  if [ -n "$NFT" ]; then
    $NFT list ruleset 2>/dev/null | awk '
      /^table / { fam=$2; tbl=$3; chain=""; next }
      /^\tchain / { chain=$2; type=""; count=0; next }
      /^\tset / || /^\tmap / || /^\tflowtable / || /^\tct / {
        if (chain != "") { print fam "|" tbl "|" chain "|" type "|" count; chain="" }
        chain=""; next
      }
      /^\t}/ {
        if (chain != "") { print fam "|" tbl "|" chain "|" type "|" count; chain="" }
        next
      }
      chain == "" { next }
      $1 == "type" { type=$2; next }
      $1 == "hook" || $1 == "policy" || $1 == "priority" || $1 == "flags" || $1 == "device" { next }
      NF > 0 { count++ }
    '
  fi
elif [ -z "$FW_DONE" ]; then
  printf 'FW:none\n'
fi
echo __SUB_INFO_NET_SEP__
# DNS resolvers. systemd-resolved stubs /etc/resolv.conf at 127.0.0.53 and hides
# the real upstreams behind resolvectl, so we gather from BOTH sources and let
# the frontend extract IPs, dedupe, and flag the local stub. `systemd-resolve`
# is the pre-239 name for resolvectl. Always emits the DNSFMT tag so the
# frontend can tell "no resolvers found" from "section missing".
printf 'DNSFMT:list\n'
if command -v resolvectl >/dev/null 2>&1; then
  resolvectl dns 2>/dev/null
elif command -v systemd-resolve >/dev/null 2>&1; then
  systemd-resolve --status 2>/dev/null | grep -iE 'DNS Servers|Current DNS Server'
fi
if [ -r /etc/resolv.conf ]; then
  grep -E '^[[:space:]]*nameserver[[:space:]]' /etc/resolv.conf 2>/dev/null
fi
"#;

// Ports: ss is preferred (parseable, modern). Falls back to netstat. The -p
// flag returns process info for sockets the user owns; non-root users see
// blank process columns for foreign sockets — that's a permission limit, not
// an error. We surface it gracefully on the UI.
const INFO_SCRIPT_PORTS: &str = r#"if command -v ss >/dev/null 2>&1; then
  printf 'ENGINE:ss\n'
  ss -tuln -p 2>/dev/null
elif command -v netstat >/dev/null 2>&1; then
  printf 'ENGINE:netstat\n'
  netstat -tulnp 2>/dev/null
else
  printf 'ENGINE:none\n'
fi
"#;

// Process list for the Processes tab. First line is a format tag the frontend
// switches on. Prefer the procps `-eo` custom format (Linux); fall back to
// BSD-style `ps aux` for busybox / minimal userlands. Sorting + capping happen
// client-side so the probe stays a single cheap snapshot suitable for a ~1s
// auto-refresh.
const INFO_SCRIPT_PROCESSES: &str = r#"if ps -eo pid,user,pcpu,pmem,rss,comm >/dev/null 2>&1; then
  printf 'PSFMT:full\n'
  ps -eo pid,user,pcpu,pmem,rss,comm 2>/dev/null
elif ps aux >/dev/null 2>&1; then
  printf 'PSFMT:aux\n'
  ps aux 2>/dev/null
else
  printf 'PSFMT:none\n'
  ps 2>/dev/null
fi
"#;

const INFO_SCRIPT_SERVICES: &str = r#"if command -v systemctl >/dev/null 2>&1; then
  printf 'ENGINE:systemd\n'
  systemctl list-units --type=service --no-legend --plain --no-pager --state=running,failed,activating 2>/dev/null
else
  printf 'ENGINE:none\n'
fi
"#;

const INFO_SCRIPT_DOCKER: &str = r#"if ! command -v docker >/dev/null 2>&1; then
  printf 'DOCKER:missing\n'
  exit 0
fi
if ! docker info >/dev/null 2>&1; then
  printf 'DOCKER:denied\n'
  exit 0
fi
printf 'DOCKER:ok\n'
echo __SUB_INFO_DOCK_SEP__
docker ps -a --format '{{json .}}' 2>/dev/null
echo __SUB_INFO_DOCK_SEP__
docker volume ls --format '{{json .}}' 2>/dev/null
echo __SUB_INFO_DOCK_SEP__
docker images --format '{{json .}}' 2>/dev/null
echo __SUB_INFO_DOCK_SEP__
docker system df 2>/dev/null
"#;

#[derive(serde::Serialize, Default)]
struct InfoSectionResult {
    data: String,
    truncated: bool,
    exec_ms: u64,
}

// Run a script through a fresh exec channel on the live SSH session and
// return everything it printed (up to a 1 MB cap). Stays read-only — the
// callers in this module only invoke shell built-ins and inspection tools.
async fn run_info_script(
    state: &SshState,
    session_id: &str,
    script: &str,
    timeout_secs: u64,
) -> Result<InfoSectionResult, String> {
    use tokio::io::AsyncReadExt;
    use std::sync::Arc;

    let session_arc = {
        let connections = state.connections.lock().await;
        connections.get(session_id).map(Arc::clone)
            .ok_or_else(|| "Session not connected".to_string())?
    };

    let start = std::time::Instant::now();
    let channel = {
        let session = session_arc.lock().await;
        session.channel_open_session().await.map_err(|e| e.to_string())?
    };
    channel.exec(true, script.as_bytes()).await.map_err(|e| e.to_string())?;
    let mut stream = channel.into_stream();

    // 1 MB cap — defends the UI against pathological output (e.g. a server
    // with thousands of veth interfaces or hundreds of stopped containers).
    const MAX_BYTES: usize = 1024 * 1024;
    let mut buf: Vec<u8> = Vec::with_capacity(64 * 1024);
    let mut truncated = false;
    let read_fut = async {
        let mut tmp = [0u8; 8192];
        loop {
            match stream.read(&mut tmp).await {
                Ok(0) => break,
                Ok(n) => {
                    if buf.len() + n > MAX_BYTES {
                        let remaining = MAX_BYTES.saturating_sub(buf.len());
                        if remaining > 0 {
                            buf.extend_from_slice(&tmp[..remaining]);
                        }
                        truncated = true;
                        let mut sink = [0u8; 8192];
                        while stream.read(&mut sink).await.unwrap_or(0) > 0 {}
                        break;
                    }
                    buf.extend_from_slice(&tmp[..n]);
                }
                Err(_) => break,
            }
        }
    };
    tokio::time::timeout(std::time::Duration::from_secs(timeout_secs), read_fut)
        .await
        .map_err(|_| format!("probe timed out after {}s", timeout_secs))?;

    Ok(InfoSectionResult {
        data: String::from_utf8_lossy(&buf).into_owned(),
        truncated,
        exec_ms: start.elapsed().as_millis() as u64,
    })
}

#[tauri::command]
async fn ssh_info_probe_section(
    state: tauri::State<'_, SshState>,
    session_id: String,
    section: String,
) -> Result<InfoSectionResult, String> {
    let (script, timeout) = match section.as_str() {
        "overview" => (INFO_SCRIPT_OVERVIEW, 10u64),
        "network"  => (INFO_SCRIPT_NETWORK, 10u64),
        "ports"    => (INFO_SCRIPT_PORTS, 10u64),
        "processes" => (INFO_SCRIPT_PROCESSES, 10u64),
        "services" => (INFO_SCRIPT_SERVICES, 15u64),
        "docker"   => (INFO_SCRIPT_DOCKER, 20u64),
        other => return Err(format!("unknown info section: {}", other)),
    };
    run_info_script(&state, &session_id, script, timeout).await
}

// Validate an iptables/nft table/chain identifier — strict allow-list.
// Chain names on real hosts are alphanumeric plus `-` `_` `.` and occasional
// `@`; anything else would risk shell injection when we splice into the
// command string. This function is the *only* thing keeping the below
// commands from executing arbitrary shell.
fn is_safe_fw_ident(s: &str) -> bool {
    if s.is_empty() || s.len() > 128 { return false; }
    // A leading '-' would be read as a flag, not a name: a chain of `-Z`
    // turns `iptables -L -Z` into "zero the counters" (as root, via the sudo
    // fallback). No real table or chain name starts with one.
    if s.starts_with('-') { return false; }
    s.chars().all(|c| c.is_ascii_alphanumeric() || matches!(c, '.' | '-' | '_' | '@'))
}

// Validate a systemd unit name before splicing it into `systemctl <action> <unit>`.
// systemd units are `[A-Za-z0-9:_.\@-]+` plus a suffix; a leading '-' would be
// read as an option (`-H host`, `-M machine`) that redirects the action elsewhere.
fn is_safe_systemctl_unit(unit: &str) -> bool {
    if unit.is_empty() || unit.len() > 256 { return false; }
    if unit.starts_with('-') { return false; }
    unit.chars().all(|c| c.is_ascii_alphanumeric() || matches!(c, '.' | '-' | '_' | '@' | ':' | '\\'))
}

// Two-stage firewall probe (lazy detail fetch). The network section returns
// a per-chain summary only; this command pulls the raw rules for one chain
// on user expand. Wire cost stays proportional to what the user actually
// looks at, not the size of the whole ruleset.
#[tauri::command]
async fn ssh_iptables_chain(
    state: tauri::State<'_, SshState>,
    session_id: String,
    table: String,
    chain: String,
) -> Result<String, String> {
    // Locked table allow-list; anything not here is rejected. Matches what
    // the probe script iterates over, plus `security` which some hardened
    // distros expose.
    if !matches!(table.as_str(), "filter" | "nat" | "mangle" | "raw" | "security") {
        return Err("无效的表".to_string());
    }
    if !is_safe_fw_ident(&chain) {
        return Err("invalid chain name".to_string());
    }
    // Retry with `sudo -n` when the direct call comes back empty — mirrors
    // the semantics of the summary probe so the expand behaves consistently
    // on hosts where only root can read the ruleset. `-v` adds the per-rule
    // `pkts`/`bytes` match-counter columns (human-readable K/M/G suffixes) so
    // the operator can see how much traffic each rule has actually handled.
    let cmd = format!(
        "OUT=$(iptables -t {t} -n -v -L {c} --line-numbers 2>/dev/null); \
if [ -z \"$OUT\" ]; then OUT=$(sudo -n iptables -t {t} -n -v -L {c} --line-numbers 2>/dev/null); fi; \
printf '%s' \"$OUT\"",
        t = table, c = chain
    );
    run_exec_capture(&state, &session_id, &cmd, 15).await
}

#[tauri::command]
async fn ssh_nft_chain(
    state: tauri::State<'_, SshState>,
    session_id: String,
    family: String,
    table: String,
    chain: String,
) -> Result<String, String> {
    if !matches!(family.as_str(), "ip" | "ip6" | "inet" | "arp" | "bridge" | "netdev") {
        return Err("invalid family".to_string());
    }
    if !is_safe_fw_ident(&table) || !is_safe_fw_ident(&chain) {
        return Err("invalid table or chain name".to_string());
    }
    let cmd = format!(
        "OUT=$(nft list chain {f} {t} {c} 2>/dev/null); \
if [ -z \"$OUT\" ]; then OUT=$(sudo -n nft list chain {f} {t} {c} 2>/dev/null); fi; \
printf '%s' \"$OUT\"",
        f = family, t = table, c = chain
    );
    run_exec_capture(&state, &session_id, &cmd, 15).await
}

#[cfg(test)]
mod remote_ident_tests {
    use super::{is_safe_fw_ident, is_safe_systemctl_unit};

    #[test]
    fn fw_ident_rejects_leading_dash_flags() {
        // These splice unquoted into `iptables -L <chain>` / `nft list chain
        // … <chain>`; a leading '-' would become a flag, not a name.
        for bad in ["-Z", "-F", "--flush", "-", "-n", "-t"] {
            assert!(!is_safe_fw_ident(bad), "{bad:?} must be rejected");
        }
    }

    #[test]
    fn fw_ident_accepts_real_chain_names() {
        for ok in ["INPUT", "FORWARD", "f2b-sshd", "DOCKER-USER", "cali_fw.1", "user@host"] {
            assert!(is_safe_fw_ident(ok), "{ok:?} must be accepted");
        }
    }

    #[test]
    fn fw_ident_rejects_empty_oversize_and_metachars() {
        assert!(!is_safe_fw_ident(""));
        assert!(!is_safe_fw_ident(&"a".repeat(129)));
        assert!(is_safe_fw_ident(&"a".repeat(128)));
        for bad in ["a;b", "a b", "a|b", "a$b", "a`b", "a/b"] {
            assert!(!is_safe_fw_ident(bad), "{bad:?} must be rejected");
        }
    }

    #[test]
    fn systemctl_unit_rejects_leading_dash_flags() {
        // Splices into `systemctl <action> <unit>`; `-H`/`-M` would retarget
        // the action at a remote host or container.
        for bad in ["-H", "-Mevil", "--host=evil", "-", "-.mount"] {
            assert!(!is_safe_systemctl_unit(bad), "{bad:?} must be rejected");
        }
    }

    #[test]
    fn systemctl_unit_accepts_real_units() {
        for ok in ["nginx.service", "ssh.service", "docker.socket", "getty@tty1.service",
                   "dev-sda1.device", "my.slice", "run-media.mount"] {
            assert!(is_safe_systemctl_unit(ok), "{ok:?} must be accepted");
        }
    }

    #[test]
    fn systemctl_unit_rejects_empty_oversize_and_metachars() {
        assert!(!is_safe_systemctl_unit(""));
        assert!(!is_safe_systemctl_unit(&"a".repeat(257)));
        for bad in ["a;b", "a b", "a|b", "a$(id)"] {
            assert!(!is_safe_systemctl_unit(bad), "{bad:?} must be rejected");
        }
    }
}

#[derive(serde::Serialize)]
struct SystemctlActionResult {
    success: bool,
    exit_code: i32,
    stdout: String,
    stderr: String,
    used_sudo: bool,
}

async fn run_exec_capture(
    state: &SshState,
    session_id: &str,
    cmd: &str,
    timeout_secs: u64,
) -> Result<String, String> {
    use tokio::io::AsyncReadExt;
    use std::sync::Arc;

    let session_arc = {
        let connections = state.connections.lock().await;
        connections.get(session_id).map(Arc::clone)
            .ok_or_else(|| "Session not connected".to_string())?
    };
    let channel = {
        let session = session_arc.lock().await;
        session.channel_open_session().await.map_err(|e| e.to_string())?
    };
    channel.exec(true, cmd.as_bytes()).await.map_err(|e| e.to_string())?;
    let mut stream = channel.into_stream();
    let mut buf: Vec<u8> = Vec::with_capacity(4096);
    let read_fut = async {
        let mut tmp = [0u8; 4096];
        loop {
            match stream.read(&mut tmp).await {
                Ok(0) | Err(_) => break,
                Ok(n) => {
                    if buf.len() + n > 64 * 1024 { break; }
                    buf.extend_from_slice(&tmp[..n]);
                }
            }
        }
    };
    tokio::time::timeout(std::time::Duration::from_secs(timeout_secs), read_fut)
        .await
        .map_err(|_| format!("执行超时（{} 秒）", timeout_secs))?;
    Ok(String::from_utf8_lossy(&buf).into_owned())
}

fn parse_exit_marker(raw: &str) -> (i32, String) {
    if let Some(idx) = raw.rfind("__SUB_EXITCODE:") {
        let after = &raw[idx + "__SUB_EXITCODE:".len()..];
        let code = after.trim().split_whitespace().next().unwrap_or("1").parse().unwrap_or(1);
        let out = raw[..idx].trim_end_matches('\n').to_string();
        (code, out)
    } else {
        (1, raw.trim_end_matches('\n').to_string())
    }
}

#[tauri::command]
async fn ssh_systemctl_action(
    state: tauri::State<'_, SshState>,
    session_id: String,
    unit: String,
    action: String,
) -> Result<SystemctlActionResult, String> {
    // Locked allow-list. Anything not in this list is rejected outright
    // — we never want to dispatch arbitrary subcommands from the UI.
    let valid_action = matches!(action.as_str(), "start" | "stop" | "restart" | "reload" | "status");
    if !valid_action {
        return Err(format!("无效的操作：{}", action));
    }
    // Reject hostile unit names. systemd unit names are restricted to
    // `[A-Za-z0-9:_.\\@-]+\.<suffix>` — adding any shell metachar here would
    // otherwise let the caller smuggle in a command.
    if !is_safe_systemctl_unit(&unit) {
        return Err("invalid unit name".to_string());
    }

    // Try plain systemctl first (works if user is root or has polkit rules).
    // If that fails with permission-denied semantics, retry with `sudo -n` —
    // works on hosts that gave this user NOPASSWD sudo. The `-n` ensures we
    // never block on a tty password prompt that nobody can answer.
    let plain_cmd = format!("systemctl {} {} 2>&1; echo __SUB_EXITCODE:$?", action, unit);
    let raw1 = run_exec_capture(&state, &session_id, &plain_cmd, 30).await?;
    let (code1, out1) = parse_exit_marker(&raw1);
    let needs_sudo = code1 != 0 && (
        out1.contains("Interactive authentication required")
        || out1.contains("not authorized")
        || out1.contains("polkit")
        || out1.to_lowercase().contains("permission denied")
        || out1.to_lowercase().contains("access denied")
    );

    if code1 == 0 || !needs_sudo {
        return Ok(SystemctlActionResult {
            success: code1 == 0,
            exit_code: code1,
            stdout: out1,
            stderr: String::new(),
            used_sudo: false,
        });
    }

    let sudo_cmd = format!("sudo -n systemctl {} {} 2>&1; echo __SUB_EXITCODE:$?", action, unit);
    let raw2 = run_exec_capture(&state, &session_id, &sudo_cmd, 30).await?;
    let (code2, out2) = parse_exit_marker(&raw2);
    Ok(SystemctlActionResult {
        success: code2 == 0,
        exit_code: code2,
        stdout: out2,
        stderr: String::new(),
        used_sudo: true,
    })
}

/// Signal a process by PID (Ports / Processes tab "kill" action). Tries the
/// user's own `kill` first, then `sudo -n kill` on a permission error — same
/// non-interactive sudo pattern as ssh_systemctl_action. Both the PID (a
/// validated i32) and the signal (an allow-listed name) are interpolated into
/// the shell command, so neither is attacker-controlled free text.
#[tauri::command]
async fn ssh_kill_process(
    state: tauri::State<'_, SshState>,
    session_id: String,
    pid: i32,
    signal: Option<String>,
) -> Result<SystemctlActionResult, String> {
    // Never signal PID <= 1 — that's init / the kernel and would be catastrophic.
    if pid <= 1 {
        return Err("refusing to signal PID <= 1".to_string());
    }
    let sig = signal.unwrap_or_else(|| "TERM".to_string());
    if !matches!(sig.as_str(), "TERM" | "KILL" | "HUP" | "INT") {
        return Err(format!("invalid signal: {}", sig));
    }

    let plain = format!("kill -{} {} 2>&1; echo __SUB_EXITCODE:$?", sig, pid);
    let raw1 = run_exec_capture(&state, &session_id, &plain, 15).await?;
    let (code1, out1) = parse_exit_marker(&raw1);
    let low = out1.to_lowercase();
    let needs_sudo = code1 != 0
        && (low.contains("not permitted")
            || low.contains("permission denied")
            || low.contains("operation not permitted"));

    if code1 == 0 || !needs_sudo {
        return Ok(SystemctlActionResult {
            success: code1 == 0,
            exit_code: code1,
            stdout: out1,
            stderr: String::new(),
            used_sudo: false,
        });
    }

    let sudo_cmd = format!("sudo -n kill -{} {} 2>&1; echo __SUB_EXITCODE:$?", sig, pid);
    let raw2 = run_exec_capture(&state, &session_id, &sudo_cmd, 15).await?;
    let (code2, out2) = parse_exit_marker(&raw2);
    Ok(SystemctlActionResult {
        success: code2 == 0,
        exit_code: code2,
        stdout: out2,
        stderr: String::new(),
        used_sudo: true,
    })
}

#[derive(serde::Serialize)]
struct SftpFileEntry {
    name: String,
    path: String,
    /// For a symlink this describes the TARGET, so links to folders open like
    /// folders. `is_symlink` is what delete/rename must look at.
    is_dir: bool,
    size: u64,
    permissions: Option<u32>,
    uid: Option<u32>,
    gid: Option<u32>,
    modified: Option<u64>,
    is_symlink: bool,
    /// Symlink whose target is missing or not accessible.
    broken_link: bool,
}

#[derive(serde::Serialize)]
struct SftpListResult {
    current_path: String,
    entries: Vec<SftpFileEntry>,
}

// ---------------------------------------------------------------------------
// Elevated SFTP ("run file operations as root" via sudo)
// ---------------------------------------------------------------------------
//
// Instead of the plain `sftp` subsystem, the channel runs `sudo <sftp-server>`
// and russh-sftp speaks the protocol over its stdin/stdout. Two modes:
//   - passwordless: `sudo -n` (NOPASSWD rule, possibly scoped to sftp-server)
//   - password:     `sudo -S -k`, the password written as the first stdin line
// A probe runs first (as the login user) to find sftp-server and check that
// sudo will allow exactly that command, so failures come back as precise
// errors instead of a broken SFTP stream.

type SessionHandleArc = Arc<tokio::sync::Mutex<russh::client::Handle<ssh_manager::ClientHandler>>>;

const SUDO_NEED_PASSWORD: &str = "[SUDO] NEED_PASSWORD";
const SUDO_WRONG_PASSWORD: &str = "[SUDO] WRONG_PASSWORD";
const SUDO_NOT_ALLOWED: &str = "[SUDO] NOT_ALLOWED";
const SUDO_REQUIRETTY: &str = "[SUDO] REQUIRETTY";
const SUDO_NO_SUDO: &str = "[SUDO] NO_SUDO";
const SUDO_NO_SFTP_SERVER: &str = "[SUDO] NO_SFTP_SERVER";
const SUDO_FAILED: &str = "[SUDO] FAILED";
const ELEVATED_SFTP_READY: &str = "__SUB_SUDO_READY__";

// POSIX sh, run as `sh -c '<script>'`: no single quotes inside, and no `!`
// (tcsh history expansion) so it survives any login shell. `SUB_MODE=pw`
// makes sudo read the password from stdin; `-k` ignores a cached ticket so
// the password is really checked. `sudo -l <cmd>` tests the exact command
// we will run, which also works for sudoers rules scoped to sftp-server.
const SUDO_SFTP_PROBE: &str = r#"S=
for p in /usr/lib/openssh/sftp-server /usr/libexec/openssh/sftp-server /usr/lib/ssh/sftp-server /usr/libexec/sftp-server /usr/lib/sftp-server /usr/local/libexec/sftp-server /usr/local/lib/sftp-server /usr/lib64/misc/sftp-server; do
  if [ -x "$p" ]; then S=$p; break; fi
done
if [ -z "$S" ] && [ -r /etc/ssh/sshd_config ]; then
  while read -r k n v rest; do
    case "$k" in [Ss]ubsystem) if [ "$n" = sftp ]; then case "$v" in /*) if [ -x "$v" ]; then S=$v; fi;; esac; fi;; esac
  done < /etc/ssh/sshd_config
fi
if [ -z "$S" ]; then echo __SUB_SUDO:NO_SFTP_SERVER; exit 0; fi
echo "__SUB_SUDO:PATH:$S"
if command -v sudo >/dev/null 2>&1; then :; else echo __SUB_SUDO:NO_SUDO; exit 0; fi
if [ "$SUB_MODE" = pw ]; then OUT=$(sudo -S -k -p "" -l "$S" 2>&1); else OUT=$(sudo -n -l "$S" 2>&1); fi
if [ $? -eq 0 ]; then echo __SUB_SUDO:OK; else echo "__SUB_SUDO:FAIL:$(printf %s "$OUT" | tr "\n" " ")"; fi"#;

/// Only plain absolute paths are ever interpolated into a remote command.
fn is_safe_remote_exec_path(p: &str) -> bool {
    p.starts_with('/')
        && p.len() < 256
        && p.chars().all(|c| c.is_ascii_alphanumeric() || "/._+-".contains(c))
}

/// Map sudo's stderr to a stable code the UI can explain. Two programs go by
/// the name `sudo`, each with its own wording: the original, and sudo-rs,
/// which is what Ubuntu installs from 25.10 on. Each group below has both.
fn classify_sudo_failure(msg: &str) -> String {
    let m = msg.to_ascii_lowercase();
    if m.contains("password is required") || m.contains("interactive authentication is required") {
        SUDO_NEED_PASSWORD.into()
    } else if m.contains("incorrect password")
        || m.contains("sorry, try again")
        || m.contains("authentication failure")
        || m.contains("no password was provided")
        || m.contains("authentication failed")
        || m.contains("incorrect authentication attempt")
        || m.contains("authentication required but not attempted")
    {
        SUDO_WRONG_PASSWORD.into()
    } else if m.contains("must have a tty") || m.contains("no tty present") {
        SUDO_REQUIRETTY.into()
    } else if m.trim().is_empty()
        || m.contains("not in the sudoers")
        || m.contains("not allowed")
        || m.contains("may not run sudo")
    {
        SUDO_NOT_ALLOWED.into()
    } else {
        format!("{}: {}", SUDO_FAILED, msg.trim())
    }
}

/// Run a command on its own exec channel, optionally feeding stdin, and
/// collect stdout+stderr until the channel closes.
async fn exec_with_stdin_capture(
    session_arc: &SessionHandleArc,
    cmd: &str,
    stdin: Option<&[u8]>,
    timeout_secs: u64,
) -> Result<String, String> {
    use russh::ChannelMsg;
    let mut channel = {
        let session = session_arc.lock().await;
        session.channel_open_session().await.map_err(|e| e.to_string())?
    };
    channel.exec(true, cmd.as_bytes()).await.map_err(|e| e.to_string())?;
    if let Some(input) = stdin {
        channel.data(input).await.map_err(|e| e.to_string())?;
    }
    channel.eof().await.map_err(|e| e.to_string())?;
    let mut out: Vec<u8> = Vec::new();
    let collect = async {
        while let Some(msg) = channel.wait().await {
            match msg {
                ChannelMsg::Data { ref data } | ChannelMsg::ExtendedData { ref data, .. } => {
                    if out.len() < 64 * 1024 {
                        out.extend_from_slice(data);
                    }
                }
                ChannelMsg::Close => break,
                _ => {}
            }
        }
    };
    tokio::time::timeout(std::time::Duration::from_secs(timeout_secs), collect)
        .await
        .map_err(|_| format!("执行超时（{} 秒）", timeout_secs))?;
    Ok(String::from_utf8_lossy(&out).into_owned())
}

/// Find sftp-server and check sudo for it. Returns the sftp-server path.
async fn probe_sudo_sftp(session_arc: &SessionHandleArc, password: Option<&str>) -> Result<String, String> {
    let mode = if password.is_some() { "pw" } else { "n" };
    let cmd = format!("env SUB_MODE={} sh -c '{}'", mode, SUDO_SFTP_PROBE);
    let stdin = password.map(|p| zeroize::Zeroizing::new(format!("{}\n", p)));
    let out = exec_with_stdin_capture(session_arc, &cmd, stdin.as_ref().map(|s| s.as_bytes()), 25).await?;
    let mut path: Option<String> = None;
    for line in out.lines() {
        let Some(rest) = line.trim().strip_prefix("__SUB_SUDO:") else { continue };
        if let Some(p) = rest.strip_prefix("PATH:") {
            path = Some(p.trim().to_string());
            continue;
        }
        if let Some(msg) = rest.strip_prefix("FAIL:") {
            return Err(classify_sudo_failure(msg));
        }
        match rest {
            "NO_SFTP_SERVER" => return Err(SUDO_NO_SFTP_SERVER.into()),
            "NO_SUDO" => return Err(SUDO_NO_SUDO.into()),
            "OK" => {
                let p = path.ok_or_else(|| format!("{}: sftp-server path missing", SUDO_FAILED))?;
                if !is_safe_remote_exec_path(&p) {
                    return Err(format!("{}: unusual sftp-server path", SUDO_FAILED));
                }
                return Ok(p);
            }
            _ => {}
        }
    }
    Err(format!("{}: unexpected reply from the server", SUDO_FAILED))
}

/// Settings for every SFTP session the app opens: file browser, transfers,
/// sudo sessions and mirrors.
///
/// russh-sftp gives each request a deadline that starts when it's sent, and
/// keeps several requests in flight, so on a slow link the last one queued
/// waits for the others and can run out of time while the transfer is still
/// moving. With the default 10 s, a download (16 reads of up to 255 KiB = 4 MiB
/// in flight) failed with "Timeout" on anything under ~3 Mbit/s, and an upload
/// (16 writes of 32 KiB) under ~420 kbit/s. The same goes for a directory
/// listing queued behind a running transfer.
///
/// 240 s per request carries downloads down to ~140 kbit/s and uploads down to
/// ~17 kbit/s, and keeps the 16 reads in flight that fast high-latency links
/// need. It doesn't make a dead connection hang: the session watcher closes
/// the SFTP session when it gives up on the connection, and the requests still
/// pending fail with it. The deadline is only for a server that stops
/// answering on a connection that is still up.
pub(crate) fn sftp_client_config() -> russh_sftp::client::Config {
    russh_sftp::client::Config {
        request_timeout_secs: 240,
        ..Default::default()
    }
}

#[cfg(test)]
mod sftp_config_tests {
    use super::sftp_client_config;

    /// What OpenSSH's sftp-server reports in limits@openssh.com as its
    /// maximum read length (256 KiB message minus 1 KiB of headroom).
    const OPENSSH_READ_LEN: u64 = 256 * 1024 - 1024;

    #[test]
    fn the_last_request_in_flight_beats_its_deadline_on_slow_links() {
        let cfg = sftp_client_config();
        let reads_in_flight = cfg.max_concurrent_reads as u64 * OPENSSH_READ_LEN;
        let writes_in_flight = cfg.max_concurrent_writes as u64 * cfg.max_write_packet_len as u64;
        // Bytes per second the link needs so the request queued behind all
        // the others still gets its reply in time.
        let download_floor = reads_in_flight / cfg.request_timeout_secs;
        let upload_floor = writes_in_flight / cfg.request_timeout_secs;
        assert!(download_floor <= 150_000 / 8, "downloads need {download_floor} B/s");
        assert!(upload_floor <= 40_000 / 8, "uploads need {upload_floor} B/s");
    }
}

/// Start `sudo <sftp-server>` on a fresh exec channel and hand the stream to
/// russh-sftp. The shell echoes a ready marker first; anything a noisy shell
/// rc prints before it is skipped. In password mode sudo always prompts
/// (`-k`), so it consumes exactly the password line and the SFTP bytes that
/// follow go to sftp-server.
async fn open_elevated_sftp(
    session_arc: &SessionHandleArc,
    elevation: &ssh_manager::SftpElevation,
) -> Result<russh_sftp::client::SftpSession, String> {
    use tokio::io::{AsyncReadExt, AsyncWriteExt};
    if !is_safe_remote_exec_path(&elevation.server_path) {
        return Err(format!("{}: unusual sftp-server path", SUDO_FAILED));
    }
    let sudo = if elevation.password.is_some() { "sudo -S -k -p ''" } else { "sudo -n" };
    let cmd = format!("echo {}; exec {} {}", ELEVATED_SFTP_READY, sudo, elevation.server_path);
    let channel = {
        let session = session_arc.lock().await;
        session.channel_open_session().await.map_err(|e| e.to_string())?
    };
    channel.exec(true, cmd.as_bytes()).await.map_err(|e| e.to_string())?;
    let mut stream = channel.into_stream();
    if let Some(pw) = &elevation.password {
        let mut line = zeroize::Zeroizing::new(Vec::with_capacity(pw.len() + 1));
        line.extend_from_slice(pw.as_bytes());
        line.push(b'\n');
        stream.write_all(&line).await.map_err(|e| e.to_string())?;
        stream.flush().await.map_err(|e| e.to_string())?;
    }
    let wait_ready = async {
        let mut line: Vec<u8> = Vec::new();
        let mut byte = [0u8; 1];
        let mut seen = 0usize;
        loop {
            let n = stream.read(&mut byte).await.map_err(|e| e.to_string())?;
            if n == 0 {
                return Err(format!("{}: sudo closed the channel", SUDO_FAILED));
            }
            seen += 1;
            if seen > 64 * 1024 {
                return Err(format!("{}: no ready marker from the server", SUDO_FAILED));
            }
            if byte[0] == b'\n' {
                let l = line.strip_suffix(b"\r").unwrap_or(&line);
                if l == ELEVATED_SFTP_READY.as_bytes() {
                    return Ok(());
                }
                line.clear();
            } else {
                line.push(byte[0]);
            }
        }
    };
    tokio::time::timeout(std::time::Duration::from_secs(20), wait_ready)
        .await
        .map_err(|_| format!("{}: timed out starting sftp-server via sudo", SUDO_FAILED))??;
    russh_sftp::client::SftpSession::new_with_config(stream, sftp_client_config())
        .await
        .map_err(|e| format!("{}: {}", SUDO_FAILED, e))
}

#[cfg(test)]
mod elevated_sftp_tests {
    use super::*;

    #[test]
    fn sudo_errors_map_to_stable_codes() {
        assert_eq!(classify_sudo_failure("sudo: a password is required"), SUDO_NEED_PASSWORD);
        assert_eq!(classify_sudo_failure("Sorry, try again. sudo: no password was provided"), SUDO_WRONG_PASSWORD);
        assert_eq!(classify_sudo_failure("sudo: 1 incorrect password attempt"), SUDO_WRONG_PASSWORD);
        assert_eq!(classify_sudo_failure("sudo: sorry, you must have a tty to run sudo"), SUDO_REQUIRETTY);
        assert_eq!(classify_sudo_failure("bob is not in the sudoers file."), SUDO_NOT_ALLOWED);
        assert_eq!(classify_sudo_failure(""), SUDO_NOT_ALLOWED);
        assert!(classify_sudo_failure("sudo: something odd").starts_with(SUDO_FAILED));
    }

    /// What sudo-rs 0.2.13 prints (Ubuntu 26.04) for the probe's two commands.
    #[test]
    fn sudo_rs_errors_map_to_the_same_codes() {
        // `sudo -n -l <server>`, where a password is needed.
        assert_eq!(classify_sudo_failure("sudo: interactive authentication is required"), SUDO_NEED_PASSWORD);
        // `sudo -S -k -p "" -l <server>`: a wrong password, three of them, none at all.
        assert_eq!(
            classify_sudo_failure(" sudo: Authentication failed, try again.  sudo: Authentication required but not attempted"),
            SUDO_WRONG_PASSWORD
        );
        assert_eq!(
            classify_sudo_failure(" sudo: Authentication failed, try again.  sudo: Authentication failed, try again.  sudo: maximum 3 incorrect authentication attempts"),
            SUDO_WRONG_PASSWORD
        );
        assert_eq!(classify_sudo_failure(" sudo: Authentication required but not attempted"), SUDO_WRONG_PASSWORD);
        // A user with no sudo rule at all (the original says the same for `-l`).
        assert_eq!(classify_sudo_failure("sudo: Sorry, user bob may not run sudo on web1."), SUDO_NOT_ALLOWED);
    }

    #[test]
    fn only_plain_absolute_paths_reach_the_remote_shell() {
        assert!(is_safe_remote_exec_path("/usr/lib/openssh/sftp-server"));
        assert!(is_safe_remote_exec_path("/usr/libexec/openssh/sftp-server"));
        assert!(!is_safe_remote_exec_path("sftp-server"));
        assert!(!is_safe_remote_exec_path("/usr/lib/sftp-server; rm -rf /"));
        assert!(!is_safe_remote_exec_path("/opt/my sftp/sftp-server"));
        assert!(!is_safe_remote_exec_path("/usr/lib/$(id)/sftp-server"));
    }

    #[test]
    fn probe_script_survives_single_quote_wrapping_in_any_shell() {
        // It is sent as `sh -c '<script>'`: a single quote would end the
        // argument early, and `!` triggers history expansion in tcsh.
        assert!(!SUDO_SFTP_PROBE.contains('\''));
        assert!(!SUDO_SFTP_PROBE.contains('!'));
    }
}

#[cfg(test)]
mod owner_lookup_tests {
    use super::*;

    #[test]
    fn only_asked_uids_with_a_plain_name_are_taken() {
        let out = "0\troot\n1003\tdeploy\n1004\tother\nbad line\n7\t\n8\tx\u{1b}[31m\n__SUB_OWNERS:OK\n";
        let owners = parse_owners(out, &[0, 1003, 7, 8]);
        let got: Vec<(u32, &str)> = owners.iter().map(|o| (o.uid, o.name.as_str())).collect();
        assert_eq!(got, vec![(0, "root"), (1003, "deploy")]);
    }

    #[test]
    fn the_script_survives_single_quote_wrapping_in_any_shell() {
        assert!(!OWNER_LOOKUP_SCRIPT.contains('\''));
        assert!(!OWNER_LOOKUP_SCRIPT.contains('!'));
    }

    // The script itself, run by this machine's sh: uid 0 is root everywhere.
    #[cfg(unix)]
    #[test]
    fn the_script_names_root_and_ends_with_its_marker() {
        let out = std::process::Command::new("sh")
            .args(["-c", OWNER_LOOKUP_SCRIPT, "sh", "0", "3999999999"])
            .output()
            .unwrap();
        let out = String::from_utf8_lossy(&out.stdout);
        assert!(out.lines().any(|l| l == "0\troot"), "{out}");
        assert!(out.lines().any(|l| l == "__SUB_OWNERS:OK"), "{out}");
        assert_eq!(parse_owners(&out, &[0, 3999999999]).len(), 1, "{out}");
    }
}

#[cfg(test)]
mod login_shell_tests {
    use super::*;

    #[test]
    fn the_shell_path_goes_in_as_an_argument() {
        assert_eq!(
            login_shell_command("/usr/bin/zsh"),
            format!("sh -c '{}' sh '/usr/bin/zsh'", LOGIN_SHELL_SCRIPT)
        );
    }

    #[test]
    fn the_script_survives_single_quote_wrapping_in_any_shell() {
        // Sent as `sh -c '<script>'` through the account's own shell: a single
        // quote would end the argument early, and `!` triggers history
        // expansion in tcsh.
        assert!(!LOGIN_SHELL_SCRIPT.contains('\''));
        assert!(!LOGIN_SHELL_SCRIPT.contains('!'));
    }

    // What the script does, run by this machine's own sh, with a stand-in
    // shell that says how it was started.
    #[cfg(unix)]
    #[test]
    fn the_script_starts_the_shell_as_a_login_shell_or_else_the_accounts_own() {
        use std::os::unix::fs::PermissionsExt;
        let dir = std::env::temp_dir().join(format!("sub-login-shell-{}", std::process::id()));
        std::fs::create_dir_all(&dir).unwrap();
        let fake = dir.join("fake-shell");
        std::fs::write(&fake, "#!/bin/sh\necho \"started $0 $* SHELL=$SHELL\"\n").unwrap();
        std::fs::set_permissions(&fake, std::fs::Permissions::from_mode(0o755)).unwrap();
        let fake = fake.to_str().unwrap().to_string();
        let run = |shell: &str, account_shell: &str| {
            let out = std::process::Command::new("sh")
                .args(["-c", LOGIN_SHELL_SCRIPT, "sh", shell])
                .env("SHELL", account_shell)
                .output()
                .unwrap();
            String::from_utf8_lossy(&out.stdout).trim().to_string()
        };
        // The shell is there: it starts as a login shell, and is $SHELL.
        assert_eq!(run(&fake, "/bin/false"), format!("started {fake} -l SHELL={fake}"));
        // It isn't: the account's own shell starts, as a login shell.
        let missing = dir.join("no-such-shell");
        assert_eq!(run(missing.to_str().unwrap(), &fake), format!("started {fake} -l SHELL={fake}"));
        std::fs::remove_dir_all(&dir).unwrap();
    }
}

/// Which connection SFTP rides for a session: the dedicated `::sftp` one when
/// the tab has it, otherwise the primary.
async fn sftp_transport(state: &SshState, session_id: &str) -> Result<(String, SessionHandleArc), String> {
    let connections = state.connections.lock().await;
    let dedicated_key = format!("{}::sftp", session_id);
    if !session_id.contains("::") && connections.contains_key(&dedicated_key) {
        Ok((dedicated_key.clone(), Arc::clone(connections.get(&dedicated_key).unwrap())))
    } else if let Some(sess) = connections.get(session_id) {
        Ok((session_id.to_string(), Arc::clone(sess)))
    } else {
        Err("Session not connected".into())
    }
}

#[derive(serde::Serialize)]
struct SftpElevationStatus {
    elevated: bool,
    /// True when sudo let us in without a password (NOPASSWD rule).
    passwordless: bool,
}

/// The user file operations run as when NOT elevated (`id -un` on the SFTP
/// transport) — lets the pane flag a direct root login too.
#[tauri::command]
async fn sftp_login_user(
    state: tauri::State<'_, SshState>,
    session_id: String,
) -> Result<String, String> {
    let (_, session_arc) = sftp_transport(&state, &session_id).await?;
    let out = exec_with_stdin_capture(&session_arc, "id -un", None, 10).await?;
    Ok(out.lines().next().unwrap_or("").trim().to_string())
}

#[derive(serde::Serialize)]
struct SftpOwner {
    uid: u32,
    name: String,
}

#[derive(serde::Serialize)]
struct SftpOwners {
    owners: Vec<SftpOwner>,
    /// "complete": every uid asked was looked up; one without a name has
    /// none on the server. "unsupported": the server can't run the lookup
    /// (no POSIX sh: a Windows server). An exec that fails or hangs is Err.
    status: &'static str,
}

// The names behind the uids of an SFTP listing, which carries numbers only:
// each uid through `id -un`, else the passwd database. The uids come as
// arguments (numbers); the script is fixed and has no single quote, as it is
// sent as `sh -c '<script>' sh <uid>...`.
const OWNER_LOOKUP_SCRIPT: &str = r#"for uid; do name=$(id -un "$uid" 2>/dev/null) || name=$(getent passwd "$uid" 2>/dev/null | cut -d: -f1 | head -n 1); [ -n "$name" ] && printf "%s\t%s\n" "$uid" "$name"; done; echo __SUB_OWNERS:OK"#;

// One lookup takes this many uids at most; a listing rarely has a handful.
const OWNER_LOOKUP_MAX: usize = 256;

/// The `uid<TAB>name` lines of OWNER_LOOKUP_SCRIPT's output, for uids that
/// were asked about. A name is at most 64 characters, with no control
/// characters.
fn parse_owners(out: &str, asked: &[u32]) -> Vec<SftpOwner> {
    out.lines()
        .filter_map(|line| {
            let (uid, name) = line.split_once('\t')?;
            let uid: u32 = uid.trim().parse().ok()?;
            let name = name.trim();
            let ok = asked.contains(&uid)
                && !name.is_empty()
                && name.chars().count() <= 64
                && !name.chars().any(char::is_control);
            ok.then(|| SftpOwner { uid, name: name.to_string() })
        })
        .collect()
}

/// Names for the uids of the remote pane's listing, for its OWNER column.
#[tauri::command]
async fn sftp_resolve_owners(
    state: tauri::State<'_, SshState>,
    session_id: String,
    uids: Vec<u32>,
) -> Result<SftpOwners, String> {
    let mut uids = uids;
    uids.sort_unstable();
    uids.dedup();
    uids.truncate(OWNER_LOOKUP_MAX);
    if uids.is_empty() {
        return Ok(SftpOwners { owners: Vec::new(), status: "complete" });
    }
    let (_, session_arc) = sftp_transport(&state, &session_id).await?;
    let args = uids.iter().map(u32::to_string).collect::<Vec<_>>().join(" ");
    let cmd = format!("sh -c '{}' sh {}", OWNER_LOOKUP_SCRIPT, args);
    let out = exec_with_stdin_capture(&session_arc, &cmd, None, 5).await?;
    let complete = out.lines().any(|line| line.trim() == "__SUB_OWNERS:OK");
    Ok(SftpOwners {
        owners: parse_owners(&out, &uids),
        status: if complete { "complete" } else { "unsupported" },
    })
}

#[tauri::command]
async fn sftp_elevation_status(
    state: tauri::State<'_, SshState>,
    session_id: String,
) -> Result<SftpElevationStatus, String> {
    Ok(match state.sftp_elevation.lock().await.get(&session_id) {
        Some(e) => SftpElevationStatus { elevated: true, passwordless: e.password.is_none() },
        None => SftpElevationStatus { elevated: false, passwordless: false },
    })
}

/// Switch this tab's file operations to root (sudo) or back. Tries
/// passwordless sudo first and only uses `password` when sudo asks for one;
/// returns `[SUDO] NEED_PASSWORD` so the UI can prompt.
#[tauri::command]
async fn sftp_set_elevated(
    state: tauri::State<'_, SshState>,
    session_id: String,
    enabled: bool,
    password: Option<String>,
) -> Result<SftpElevationStatus, String> {
    if !enabled {
        set_sftp_mode(&state, &session_id, None).await;
        return Ok(SftpElevationStatus { elevated: false, passwordless: false });
    }
    let password = password.map(zeroize::Zeroizing::new).filter(|p| !p.is_empty());
    if let Some(p) = &password {
        if p.contains(['\n', '\r', '\0']) {
            return Err(format!("{}: the password contains a line break", SUDO_FAILED));
        }
    }
    let (_, session_arc) = sftp_transport(&state, &session_id).await?;
    let (server_path, used_password) = match probe_sudo_sftp(&session_arc, None).await {
        Ok(path) => (path, None),
        Err(e) if e == SUDO_NEED_PASSWORD => {
            let Some(pw) = password else { return Err(e) };
            let path = probe_sudo_sftp(&session_arc, Some(pw.as_str())).await?;
            (path, Some(pw))
        }
        Err(e) => return Err(e),
    };
    let passwordless = used_password.is_none();
    set_sftp_mode(
        &state,
        &session_id,
        Some(ssh_manager::SftpElevation { server_path, password: used_password }),
    )
    .await;
    // Open it right away so a failure shows up here, not on the next click.
    if let Err(e) = get_sftp_session(&state, &session_id).await {
        set_sftp_mode(&state, &session_id, None).await;
        return Err(e);
    }
    Ok(SftpElevationStatus { elevated: true, passwordless })
}

/// Switch a tab's SFTP privilege mode and drop its cached session in one
/// step. Lock order is sftp_sessions, then sftp_elevation — the same order
/// get_sftp_session checks the mode in before caching — so a session opened
/// in the old mode can never be cached after the switch.
async fn set_sftp_mode(state: &SshState, session_id: &str, elevation: Option<ssh_manager::SftpElevation>) {
    let mut cache = state.sftp_sessions.lock().await;
    let mut modes = state.sftp_elevation.lock().await;
    match elevation {
        Some(e) => {
            modes.insert(session_id.to_string(), e);
        }
        None => {
            modes.remove(session_id);
        }
    }
    cache.remove(session_id);
}

pub async fn get_sftp_session(
    state: &SshState,
    session_id: &str,
) -> Result<Arc<russh_sftp::client::SftpSession>, String> {
    // Reuse one SFTP subsystem per SSH session to avoid leaking server-side
    // channels.
    if let Some(s) = state.sftp_sessions.lock().await.get(session_id) {
        return Ok(Arc::clone(s));
    }

    // Transport preference: when a dedicated `::sftp` connection exists for
    // this session (the per-tab "Dedicated session" toggle), the SFTP
    // subsystem rides IT — but the cache stays keyed by the plain session id,
    // so the frontend never has to re-key anything. The dedicated connection
    // is a pure transport: it appearing/disappearing just invalidates this
    // cache (see the `::sftp` lifecycle hooks) and the next file operation
    // re-opens the subsystem on whatever transport is available.
    let (transport_key, session_arc) = sftp_transport(state, session_id).await?;

    // Elevated tabs get `sudo <sftp-server>` instead of the plain subsystem.
    let elevation = state.sftp_elevation.lock().await.get(session_id).cloned();
    let was_elevated = elevation.is_some();
    let sftp = match elevation {
        Some(elev) => open_elevated_sftp(&session_arc, &elev).await?,
        None => {
            let session = session_arc.lock().await;
            let channel = session.channel_open_session().await.map_err(|e| e.to_string())?;
            channel.request_subsystem(true, "sftp").await.map_err(|e| e.to_string())?;
            russh_sftp::client::SftpSession::new_with_config(channel.into_stream(), sftp_client_config())
                .await
                .map_err(|e| e.to_string())?
        }
    };
    let arc = Arc::new(sftp);

    let mut cache = state.sftp_sessions.lock().await;
    // The privilege mode flipped while we were opening: never cache a session
    // of the wrong level. Checked under the cache lock, which set_sftp_mode
    // also holds while it switches, so the two can't interleave.
    if state.sftp_elevation.lock().await.contains_key(session_id) != was_elevated {
        return Err("File access mode changed while opening SFTP — try again".into());
    }
    if let Some(existing) = cache.get(session_id) {
        // Another caller raced us; keep the existing one and drop ours.
        return Ok(Arc::clone(existing));
    }
    // Guard against two races before caching: (a) a reconnect replaced/removed
    // the transport handle while we were opening the subsystem (stale handle),
    // and (b) a dedicated `::sftp` transport APPEARED meanwhile — which changes
    // the preferred transport, so caching this primary-backed subsystem would
    // permanently bypass the dedicated connection. Require both the recomputed
    // preference AND the handle identity to still match the key we opened on.
    let still_current = {
        let connections = state.connections.lock().await;
        let dedicated_key = format!("{}::sftp", session_id);
        let preferred: &str = if !session_id.contains("::") && connections.contains_key(&dedicated_key) {
            dedicated_key.as_str()
        } else {
            session_id
        };
        transport_key.as_str() == preferred
            && connections.get(&transport_key)
                .map(|c| Arc::ptr_eq(c, &session_arc))
                .unwrap_or(false)
    };
    if !still_current {
        return Err("Session reconnected while opening SFTP — try again".into());
    }
    cache.insert(session_id.to_string(), Arc::clone(&arc));
    Ok(arc)
}

#[tauri::command]
async fn sftp_list_dir(
    state: tauri::State<'_, SshState>,
    session_id: String,
    path: String,
) -> Result<SftpListResult, String> {
    let sftp = get_sftp_session(&state, &session_id).await?;
    let target_path = if path.is_empty() { ".".to_string() } else { path.clone() };
    let canonical_path = sftp.canonicalize(&target_path).await.map_err(|e| e.to_string())?;
    
    let mut read_dir = sftp.read_dir(&canonical_path).await.map_err(|e| e.to_string())?;
    let mut entries = Vec::new();
    while let Some(entry) = read_dir.next() {
        let name = entry.file_name();
        if name == "." || name == ".." {
            continue;
        }
        // Every other name is listed as-is, even one this OS can't store
        // (`a:b` on Windows): the remote file is still there to open, rename
        // or delete. The download commands check the name before writing.
        let is_dir = entry.file_type().is_dir();
        let metadata = entry.metadata();
        let is_symlink = metadata.is_symlink();
        let size = metadata.size.unwrap_or(0);
        let permissions = metadata.permissions;
        let uid = metadata.uid;
        let gid = metadata.gid;
        let modified = metadata.mtime.map(|t| t as u64);
        
        let entry_path = if canonical_path.ends_with('/') {
            format!("{}{}", canonical_path, name)
        } else {
            format!("{}/{}", canonical_path, name)
        };
        
        entries.push(SftpFileEntry {
            name,
            path: entry_path,
            is_dir,
            size,
            permissions,
            uid,
            gid,
            modified,
            is_symlink,
            broken_link: false,
        });
    }

    // READDIR describes a symlink itself (lstat), so a link to a folder would
    // list as a file. STAT each link (follows it) so links to folders show and
    // open as folders, and dangling ones are flagged. Pipelined with a cap; a
    // folder with an extreme number of links (thousands of .so links in
    // /usr/lib) keeps plain link rows instead of stalling the listing.
    const MAX_LINKS_TO_RESOLVE: usize = 2000;
    const RESOLVE_CONCURRENCY: usize = 32;
    let link_rows: Vec<usize> = entries
        .iter()
        .enumerate()
        .filter(|(_, e)| e.is_symlink)
        .map(|(i, _)| i)
        .collect();
    if !link_rows.is_empty() && link_rows.len() <= MAX_LINKS_TO_RESOLVE {
        let permits = Arc::new(tokio::sync::Semaphore::new(RESOLVE_CONCURRENCY));
        let mut lookups = tokio::task::JoinSet::new();
        for idx in link_rows {
            let sftp = Arc::clone(&sftp);
            let permits = Arc::clone(&permits);
            let link_path = entries[idx].path.clone();
            lookups.spawn(async move {
                let _permit = permits.acquire_owned().await;
                let target = tokio::time::timeout(
                    std::time::Duration::from_secs(10),
                    sftp.metadata(link_path),
                )
                .await;
                (idx, target)
            });
        }
        while let Some(joined) = lookups.join_next().await {
            let Ok((idx, target)) = joined else { continue };
            let row = &mut entries[idx];
            match target {
                Ok(Ok(meta)) => {
                    row.is_dir = meta.is_dir();
                    if !row.is_dir {
                        row.size = meta.size.unwrap_or(row.size);
                    }
                }
                Ok(Err(_)) => row.broken_link = true,
                // Slow server: leave it as a plain link row.
                Err(_) => {}
            }
        }
    }

    // Sort: directories first, then alphabetically
    entries.sort_by(|a, b| {
        if a.is_dir != b.is_dir {
            b.is_dir.cmp(&a.is_dir)
        } else {
            a.name.to_lowercase().cmp(&b.name.to_lowercase())
        }
    });
    
    Ok(SftpListResult {
        current_path: canonical_path,
        entries,
    })
}

#[tauri::command]
async fn sftp_create_dir(
    state: tauri::State<'_, SshState>,
    session_id: String,
    path: String,
) -> Result<(), String> {
    let sftp = get_sftp_session(&state, &session_id).await?;
    sftp.create_dir(path).await.map_err(|e| e.to_string())?;
    Ok(())
}

#[tauri::command]
async fn sftp_remove_file(
    state: tauri::State<'_, SshState>,
    session_id: String,
    path: String,
) -> Result<(), String> {
    let sftp = get_sftp_session(&state, &session_id).await?;
    sftp.remove_file(path).await.map_err(|e| e.to_string())?;
    Ok(())
}

/// Delete a remote folder and everything in it (see `sftp_remove`).
///
/// A delete that takes a while shows up like a transfer: it emits on the same
/// `sftp-transfer-{session}` channel with kind "delete" and the number of
/// entries removed so far, and the card's Cancel (`sftp_cancel_transfer`)
/// stops it between two requests. It then ends with the error "cancelled".
/// A delete that is over within a moment emits nothing.
#[tauri::command]
async fn sftp_remove_dir(
    app: tauri::AppHandle,
    state: tauri::State<'_, SshState>,
    session_id: String,
    path: String,
) -> Result<(), String> {
    use std::sync::atomic::AtomicBool;
    use std::time::{Duration, Instant};
    use tauri::Emitter;

    let root = sftp_remove::tree_root(&path)?;
    let sftp = get_sftp_session(&state, &session_id).await?;
    let Some(root) = root else {
        // Not a path that starts with "/": removed the way folders always
        // were, only when empty. A link to a folder lists as a folder, and
        // deleting it must only unlink the link itself.
        if sftp
            .symlink_metadata(path.clone())
            .await
            .map(|m| m.is_symlink())
            .unwrap_or(false)
        {
            return sftp.remove_file(path).await.map_err(|e| e.to_string());
        }
        return sftp.remove_dir(path).await.map_err(|e| e.to_string());
    };

    let id = transfer_id();
    let cancel = Arc::new(AtomicBool::new(false));
    let cancels_map = Arc::clone(&state.transfer_cancels);
    cancels_map.lock().await.insert(id.clone(), Arc::clone(&cancel));
    struct CancelGuard {
        map: Arc<tokio::sync::Mutex<std::collections::HashMap<String, Arc<AtomicBool>>>>,
        id: String,
    }
    impl Drop for CancelGuard {
        fn drop(&mut self) {
            if let Ok(mut g) = self.map.try_lock() {
                g.remove(&self.id);
            }
        }
    }
    let _guard = CancelGuard { map: Arc::clone(&cancels_map), id: id.clone() };

    let name = root.rsplit('/').next().unwrap_or(root).to_string();
    let event_name = format!("sftp-transfer-{}", session_id);
    let emit = |removed: u64, status: &str, error: Option<String>| {
        let _ = app.emit(
            &event_name,
            serde_json::json!({
                "id": id, "name": name, "kind": "delete",
                "bytes": removed, "total": 0,
                "status": status, "error": error,
            }),
        );
    };

    // The card comes up only once the delete has run for a moment, and is
    // then updated a few times a second.
    const CARD_AFTER: Duration = Duration::from_millis(400);
    const CARD_EVERY: Duration = Duration::from_millis(200);
    let started = Instant::now();
    let mut last_shown: Option<Instant> = None;
    let mut removed_so_far = 0u64;
    let result = {
        let mut report = |removed: u64| {
            removed_so_far = removed;
            let due = match last_shown {
                None => started.elapsed() >= CARD_AFTER,
                Some(at) => at.elapsed() >= CARD_EVERY,
            };
            if due {
                last_shown = Some(Instant::now());
                emit(removed, "progress", None);
            }
        };
        sftp_remove::remove_tree(sftp, root, &cancel, &mut report).await
    };
    // The card, if there is one, gets its ending. The pane reports the
    // result either way.
    if last_shown.is_some() {
        match &result {
            Ok(()) => emit(removed_so_far, "done", None),
            Err(e) if e == sftp_remove::CANCELLED => emit(removed_so_far, "cancelled", None),
            Err(e) => emit(removed_so_far, "error", Some(e.clone())),
        }
    }
    result
}

#[tauri::command]
async fn sftp_rename(
    state: tauri::State<'_, SshState>,
    session_id: String,
    oldpath: String,
    newpath: String,
) -> Result<(), String> {
    let sftp = get_sftp_session(&state, &session_id).await?;

    // First try the rename as-is — the common case is the target's parent
    // already exists.
    if let Err(first_err) = sftp.rename(&oldpath, &newpath).await {
        // SSH_FX_FAILURE on rename is most commonly "destination parent
        // directory doesn't exist" — user types a path into a subfolder
        // they haven't created yet. Pre-check the parent explicitly so
        // we don't paper over real errors (permission denied, destination
        // already exists, cross-filesystem) with a silent retry that
        // would just swap one confusing message for another.
        let parent_str = std::path::Path::new(&newpath)
            .parent()
            .map(|p| p.to_string_lossy().replace('\\', "/"))
            .filter(|s| !s.is_empty() && s != "/");
        let needs_mkdir = match &parent_str {
            Some(p) => sftp.metadata(p.as_str()).await.is_err(),
            None => false,
        };
        if !needs_mkdir {
            return Err(format!("rename '{}' -> '{}': {}", oldpath, newpath, first_err));
        }
        // mkdir -p the missing chain. AlreadyExists is treated as success
        // so a parallel rename racing into the same tree doesn't break us.
        let p = parent_str.unwrap();
        let parts: Vec<&str> = p.trim_start_matches('/').split('/').filter(|s| !s.is_empty()).collect();
        let mut cur = String::from("/");
        for part in parts {
            if cur != "/" { cur.push('/'); }
            cur.push_str(part);
            if sftp.metadata(cur.as_str()).await.is_ok() { continue; }
            if let Err(e) = sftp.create_dir(&cur).await {
                let msg = e.to_string().to_lowercase();
                if msg.contains("exist") { continue; }
                return Err(format!("create destination parent '{}': {}", cur, e));
            }
        }
        sftp.rename(&oldpath, &newpath).await
            .map_err(|e| format!("rename '{}' -> '{}' (after creating parent): {}", oldpath, newpath, e))?;
    }
    Ok(())
}

#[tauri::command]
async fn sftp_set_permissions(
    state: tauri::State<'_, SshState>,
    session_id: String,
    path: String,
    permissions: u32,
) -> Result<(), String> {
    let sftp = get_sftp_session(&state, &session_id).await?;
    // Send ONLY the permissions attribute. Echoing back the full stat result
    // makes the server apply every field in it, and the size one turns into
    // truncate(2) — which fails with EISDIR on a directory, surfacing as a
    // bare SSH_FX_FAILURE. Omitted fields are left untouched by the server,
    // so ownership and timestamps can't be clobbered either.
    let metadata = russh_sftp::protocol::FileAttributes {
        permissions: Some(permissions),
        ..Default::default()
    };
    sftp.set_metadata(path, metadata).await.map_err(|e| e.to_string())?;
    Ok(())
}

#[tauri::command]
async fn sftp_set_owner(
    state: tauri::State<'_, SshState>,
    session_id: String,
    path: String,
    uid: Option<u32>,
    gid: Option<u32>,
) -> Result<(), String> {
    let sftp = get_sftp_session(&state, &session_id).await?;
    // uid and gid travel as a pair on the wire, so a missing half has to be
    // filled from the current owner rather than defaulting to 0 (root).
    // Propagate the stat error for the same reason.
    let (uid, gid) = match (uid, gid) {
        (Some(u), Some(g)) => (u, g),
        _ => {
            let current = sftp.metadata(&path).await
                .map_err(|e| format!("[SFTP] METADATA_READ_FAILED: {}", e))?;
            match (uid.or(current.uid), gid.or(current.gid)) {
                (Some(u), Some(g)) => (u, g),
                _ => return Err("[SFTP] METADATA_READ_FAILED: server did not report owner".into()),
            }
        }
    };
    // Only the owner fields — see sftp_set_permissions for why size must
    // not be sent (truncate on a directory fails).
    let metadata = russh_sftp::protocol::FileAttributes {
        uid: Some(uid),
        gid: Some(gid),
        ..Default::default()
    };
    sftp.set_metadata(path, metadata).await.map_err(|e| e.to_string())?;
    Ok(())
}

#[derive(serde::Serialize)]
struct SftpModeOwner {
    permissions: Option<u32>,
    uid: Option<u32>,
    gid: Option<u32>,
}

/// Current mode and owner of a remote path, following symlinks — what
/// chmod/chown on that path change. The listing has a link's own mode
/// (lrwxrwxrwx), which says nothing about its target.
#[tauri::command]
async fn sftp_stat(
    state: tauri::State<'_, SshState>,
    session_id: String,
    path: String,
) -> Result<SftpModeOwner, String> {
    let sftp = get_sftp_session(&state, &session_id).await?;
    let meta = sftp.metadata(&path).await.map_err(|e| e.to_string())?;
    Ok(SftpModeOwner { permissions: meta.permissions, uid: meta.uid, gid: meta.gid })
}

#[tauri::command]
async fn sftp_download_file(
    app: tauri::AppHandle,
    state: tauri::State<'_, SshState>,
    session_id: String,
    remote_path: String,
    local_path: String,
    overwrite: Option<bool>,
) -> Result<(), String> {
    use tauri::Emitter;
    use tokio::io::AsyncReadExt;
    use std::sync::atomic::{AtomicBool, Ordering};

    // The file name is the one part of the destination the server controls
    // (the frontend joins `<chosen folder><sep><remote name>`), so check it
    // before anything touches the path — see validate_download_target.
    validate_download_target(&local_path, &remote_path)?;

    // Overwrite protection: when the caller has NOT explicitly opted in
    // (overwrite==Some(true)), refuse to clobber an existing local file.
    // The sentinel error string `EXISTS:<path>` lets the frontend tell
    // the difference between "real failure" and "you would have replaced
    // something" and surface the apply-to-all confirmation modal.
    if overwrite != Some(true) && std::path::Path::new(&local_path).exists() {
        return Err(format!("EXISTS:{}", local_path));
    }

    // Validate the destination BEFORE touching the network. A compromised
    // renderer could otherwise request a download into a system directory
    // like `/etc` or `C:\Windows\System32\…`. allow_nonexistent=true because
    // the destination file is being created right now.
    let _guarded_local = guard_local_path(&local_path, true)?;

    let sftp = get_sftp_session(&state, &session_id).await?;

    // Stat first so we can report a progress percentage. If the server doesn't
    // know the size (some edge SFTP servers omit it), we still report bytes
    // transferred so the UI can show throughput at least.
    let total = match sftp.metadata(&remote_path).await {
        Ok(m) => m.size.unwrap_or(0),
        Err(_) => 0,
    };
    let name = std::path::Path::new(&remote_path)
        .file_name()
        .and_then(|n| n.to_str())
        .unwrap_or("file")
        .to_string();
    let id = transfer_id();
    let event_name = format!("sftp-transfer-{}", session_id);
    let emit_progress = |bytes: u64, status: &str, error: Option<String>| {
        let _ = app.emit(
            &event_name,
            serde_json::json!({
                "id": id, "name": name, "kind": "download",
                "bytes": bytes, "total": total,
                "status": status, "error": error,
            }),
        );
    };

    // Register a cancel flag the user can flip via `sftp_cancel_transfer`.
    // RAII-removed at the end so the map doesn't pile up across many
    // sequential transfers.
    let cancel = Arc::new(AtomicBool::new(false));
    let cancels_map = Arc::clone(&state.transfer_cancels);
    cancels_map.lock().await.insert(id.clone(), Arc::clone(&cancel));
    struct CancelGuard {
        map: Arc<tokio::sync::Mutex<std::collections::HashMap<String, Arc<AtomicBool>>>>,
        id: String,
    }
    impl Drop for CancelGuard {
        fn drop(&mut self) {
            // Best-effort cleanup; if the lock is contended we'd rather leak
            // a slot than block the drop, but in practice this never blocks.
            if let Ok(mut g) = self.map.try_lock() {
                g.remove(&self.id);
            }
        }
    }
    let _guard = CancelGuard { map: Arc::clone(&cancels_map), id: id.clone() };

    emit_progress(0, "progress", None);

    let mut remote_file = sftp
        .open(&remote_path)
        .await
        .map_err(|e| { emit_progress(0, "error", Some(e.to_string())); format!("打开远程文件失败：{}", e) })?;
    // Download to a sibling temp, then rename over the destination at the end.
    // A failure or cancel mid-download then costs nothing: the file already at
    // `local_path` (an overwrite) is untouched until the rename, and only the
    // temp is removed. Same filesystem, so the rename is atomic.
    let temp_path = download_temp_path(std::path::Path::new(&local_path));
    let mut local_file = tokio::fs::File::create(&temp_path)
        .await
        .map_err(|e| { emit_progress(0, "error", Some(e.to_string())); format!("Failed to create local file: {}", e) })?;
    let scrap_temp = |tmp: &std::path::Path| { let tmp = tmp.to_path_buf(); async move { let _ = tokio::fs::remove_file(&tmp).await; } };

    // 256 KiB chunks: large enough to keep the SSH window pipelined on
    // high-latency links (with window_size=8 MiB we want ~16+ chunks in
    // flight), small enough to keep per-iteration latency low for the
    // progress meter (and the cancel poll).
    let mut buf = vec![0u8; 256 * 1024];
    let mut transferred: u64 = 0;
    let mut last_report = std::time::Instant::now();
    use tokio::io::AsyncWriteExt;
    loop {
        if cancel.load(Ordering::Relaxed) {
            drop(local_file);
            scrap_temp(&temp_path).await;
            emit_progress(transferred, "cancelled", None);
            return Err("cancelled".into());
        }
        let n = match remote_file.read(&mut buf).await {
            Ok(n) => n,
            Err(e) => { drop(local_file); scrap_temp(&temp_path).await; emit_progress(transferred, "error", Some(e.to_string())); return Err(format!("read: {e}")); }
        };
        if n == 0 { break; }
        if let Err(e) = local_file.write_all(&buf[..n]).await {
            drop(local_file); scrap_temp(&temp_path).await; emit_progress(transferred, "error", Some(e.to_string())); return Err(format!("write: {e}"));
        }
        transferred += n as u64;
        // Throttle progress events: each one crosses the IPC boundary, and
        // 10 Hz is more than enough for a smooth progress bar.
        if last_report.elapsed() >= std::time::Duration::from_millis(100) {
            emit_progress(transferred, "progress", None);
            last_report = std::time::Instant::now();
        }
    }
    // tokio's File hands writes to a background thread, so the last chunk's
    // failure (a full disk, say) only shows up here. Without the event the
    // transfer card would stay on "progress" for good.
    if let Err(e) = local_file.flush().await {
        drop(local_file); scrap_temp(&temp_path).await; emit_progress(transferred, "error", Some(e.to_string())); return Err(format!("flush: {e}"));
    }
    drop(local_file);
    // The one touch of the destination: the full download replaces it atomically.
    if let Err(e) = tokio::fs::rename(&temp_path, &local_path).await {
        scrap_temp(&temp_path).await;
        emit_progress(transferred, "error", Some(e.to_string()));
        return Err(format!("finalize: {e}"));
    }
    emit_progress(transferred, "done", None);
    Ok(())
}

/// Recursive remote directory download. Walks the remote tree under
/// `remote_path`, mirrors its structure into `local_path/{basename}`, and
/// streams every file across with progress events aggregated under a SINGLE
/// transfer id — so the UI shows one "folder of N files" card instead of one
/// card per file. Cancellation uses the same `transfer_cancels` map as
/// single-file downloads, so the user's Cancel button works identically.
#[tauri::command]
async fn sftp_download_dir(
    app: tauri::AppHandle,
    state: tauri::State<'_, SshState>,
    session_id: String,
    remote_path: String,
    local_path: String,
    overwrite: Option<bool>,
) -> Result<(), String> {
    use tauri::Emitter;
    use tokio::io::{AsyncReadExt, AsyncWriteExt};
    use std::sync::atomic::{AtomicBool, Ordering};

    // Destination is the PARENT directory. We'll create remote_path's
    // basename underneath it so the user gets `local/{folder}/...`,
    // matching scp -r and rsync semantics. That parent is the user's own
    // folder (picker or pane); everything the server names below it is
    // checked one component at a time.

    // The folder name is the basename of a server-controlled remote path, and
    // it's the first path component we join onto local_path. On a Windows
    // client a basename like `C:` is drive-relative (join discards local_path);
    // `..` would climb out. Reject anything that isn't a single safe component
    // up front so the whole tree stays under the chosen destination.
    {
        let folder_name = remote_path
            .trim_end_matches('/')
            .rsplit('/')
            .next()
            .unwrap_or("");
        if !folder_name.is_empty() && !is_safe_dir_entry_name(folder_name) {
            return Err(format!(
                "Refusing to download a folder whose name isn't a safe local filename: {:?}",
                folder_name
            ));
        }
        check_download_dir_target(
            &local_path,
            if folder_name.is_empty() { "folder" } else { folder_name },
        )?;
    }

    // Overwrite protection for the destination folder: if the target
    // `local_path/{folder}` already exists, refuse unless explicitly
    // allowed. Per-file confirmation inside the tree would be unworkable
    // for the bulk path — the user picks once at the directory level.
    {
        let folder_name = remote_path
            .trim_end_matches('/')
            .rsplit('/')
            .next()
            .unwrap_or("folder");
        let dst_root = std::path::PathBuf::from(&local_path).join(folder_name);
        if overwrite != Some(true) && dst_root.exists() {
            return Err(format!("EXISTS:{}", dst_root.to_string_lossy()));
        }
    }

    let sftp = get_sftp_session(&state, &session_id).await?;

    // Compute the folder name from the remote path. Strip trailing slashes
    // first so `/home/user/data/` still yields `data`, not "".
    let folder_name = remote_path
        .trim_end_matches('/')
        .rsplit('/')
        .next()
        .unwrap_or("folder")
        .to_string();
    let folder_name = if folder_name.is_empty() { "folder".to_string() } else { folder_name };

    let id = transfer_id();
    let event_name = format!("sftp-transfer-{}", session_id);

    // Register cancel flag early so the user can abort even during the
    // enumeration phase (which can be slow on a deep tree with many dirs).
    let cancel = Arc::new(AtomicBool::new(false));
    let cancels_map = Arc::clone(&state.transfer_cancels);
    cancels_map.lock().await.insert(id.clone(), Arc::clone(&cancel));
    struct CancelGuard {
        map: Arc<tokio::sync::Mutex<std::collections::HashMap<String, Arc<AtomicBool>>>>,
        id: String,
    }
    impl Drop for CancelGuard {
        fn drop(&mut self) {
            if let Ok(mut g) = self.map.try_lock() {
                g.remove(&self.id);
            }
        }
    }
    let _guard = CancelGuard { map: Arc::clone(&cancels_map), id: id.clone() };

    let id_for_emit = id.clone();
    let name_for_emit = folder_name.clone();
    let app_for_emit = app.clone();
    let event_for_emit = event_name.clone();
    let emit_progress = move |bytes: u64, total: u64, status: &str, error: Option<String>| {
        let _ = app_for_emit.emit(
            &event_for_emit,
            serde_json::json!({
                "id": id_for_emit, "name": name_for_emit, "kind": "download",
                "bytes": bytes, "total": total,
                "status": status, "error": error,
            }),
        );
    };

    emit_progress(0, 0, "progress", None);

    // Phase 1: enumerate. Collect every file under remote_path along with
    // its relative path (so we can preserve the tree on the local side) and
    // its size (so the progress bar has a meaningful total). Tracked
    // iteratively with an explicit stack so we don't blow the async-recursion
    // budget on pathological trees.
    let remote_root = remote_path.trim_end_matches('/').to_string();
    let mut files: Vec<(String, String, u64)> = Vec::new(); // (remote, rel, size)
    let mut total_bytes: u64 = 0;
    let mut skipped_names: u64 = 0;
    // (dir, depth). Depth bounds how deep a hostile server can send us, and
    // the file/byte caps bound how much the list below can grow — so a broken
    // or endless tree is refused instead of growing memory without bound.
    let mut stack: Vec<(String, usize)> = vec![(remote_root.clone(), 0)];
    let too_big = |files: usize, bytes: u64| {
        if files > DOWNLOAD_DIR_MAX_FILES {
            Some(format!("this folder has more than {} files — too many to download at once.", DOWNLOAD_DIR_MAX_FILES))
        } else if bytes > DOWNLOAD_DIR_MAX_BYTES {
            Some(format!("this folder is over {} GB — too large to download at once.", DOWNLOAD_DIR_MAX_BYTES / (1024 * 1024 * 1024)))
        } else {
            None
        }
    };

    while let Some((dir, depth)) = stack.pop() {
        if cancel.load(Ordering::Relaxed) {
            emit_progress(0, total_bytes, "cancelled", None);
            return Err("cancelled".into());
        }
        if depth > DOWNLOAD_DIR_MAX_DEPTH {
            let msg = format!("folder nesting is deeper than {} levels — refusing to download.", DOWNLOAD_DIR_MAX_DEPTH);
            emit_progress(0, total_bytes, "error", Some(msg.clone()));
            return Err(msg);
        }
        let read = match sftp.read_dir(&dir).await {
            Ok(r) => r,
            Err(e) => {
                emit_progress(0, total_bytes, "error", Some(format!("读取目录 {} 失败：{}", dir, e)));
                return Err(format!("读取目录 {} 失败：{}", dir, e));
            }
        };
        for entry in read {
            // A single directory can hold millions of entries; a Cancel (and
            // the caps) must take effect inside the walk, not only between
            // directories.
            if cancel.load(Ordering::Relaxed) {
                emit_progress(0, total_bytes, "cancelled", None);
                return Err("cancelled".into());
            }
            if let Some(msg) = too_big(files.len(), total_bytes) {
                emit_progress(0, total_bytes, "error", Some(msg.clone()));
                return Err(msg);
            }
            let name = entry.file_name();
            if name == "." || name == ".." { continue; }
            // Skip any entry whose name isn't a single plain component this OS
            // can store. A hostile SFTP server can return `../../x` or `..\x`
            // here; joining that onto local_root below would escape the chosen
            // folder. Ordinary names Windows can't store (`a:b`) are skipped
            // too — counted, so the user hears about them instead of a quietly
            // incomplete copy. See is_safe_dir_entry_name.
            if !is_safe_dir_entry_name(&name) {
                skipped_names = skipped_names.saturating_add(1);
                continue;
            }
            let full = format!("{}/{}", dir.trim_end_matches('/'), name);
            if entry.file_type().is_dir() {
                stack.push((full, depth + 1));
            } else if entry.file_type().is_file() {
                let size = entry.metadata().size.unwrap_or(0);
                let rel = full.strip_prefix(&remote_root)
                    .map(|s| s.trim_start_matches('/').to_string())
                    .unwrap_or_else(|| name.clone());
                total_bytes = total_bytes.saturating_add(size);
                files.push((full, rel, size));
            }
            // Symlinks and other types skipped — same conservative policy
            // as the mirror module.
        }
    }

    // Shown on the finished transfer card when the walk skipped names.
    let skipped_note = skipped_names_note(skipped_names);

    if files.is_empty() {
        // Still create the (empty) destination folder so the UI sees the
        // shape — otherwise the user sees "done" with nothing to show for it.
        let local_root = std::path::PathBuf::from(&local_path).join(&folder_name);
        let _ = tokio::fs::create_dir_all(&local_root).await;
        emit_progress(0, 0, "done", skipped_note);
        return Ok(());
    }

    // Phase 2: download. The local destination tree is rooted at
    // {local_path}/{folder_name}/... so multi-level files preserve their
    // structure. Create each parent directory lazily right before we open
    // the file.
    let local_root = std::path::PathBuf::from(&local_path).join(&folder_name);
    if let Err(e) = tokio::fs::create_dir_all(&local_root).await {
        emit_progress(0, total_bytes, "error", Some(format!("创建 {} 失败：{}", local_root.display(), e)));
        return Err(format!("create root: {}", e));
    }

    let mut transferred: u64 = 0;
    let mut last_report = std::time::Instant::now();
    let mut buf = vec![0u8; 256 * 1024];

    for (remote_file_path, rel, _size) in &files {
        if cancel.load(Ordering::Relaxed) {
            emit_progress(transferred, total_bytes, "cancelled", None);
            return Err("cancelled".into());
        }

        // Normalise the relative path's separators for the local OS. On
        // Unix this is a no-op; on Windows we replace `/` so create_dir_all
        // produces real nested directories instead of one literal name
        // containing slashes.
        let rel_local = if cfg!(windows) { rel.replace('/', "\\") } else { rel.clone() };
        let dest = local_root.join(&rel_local);
        // Defense in depth: every component of `rel` was checked with
        // is_safe_dir_entry_name during the walk, so this can't fail for a
        // well-behaved tree — but check before we create or open anything
        // that the relative part is plain names only (no root, prefix or
        // `..`), so the join can only land under the destination root.
        let rel_is_plain = std::path::Path::new(&rel_local)
            .components()
            .all(|c| matches!(c, std::path::Component::Normal(_)));
        if !rel_is_plain || !dest.starts_with(&local_root) {
            emit_progress(transferred, total_bytes, "error",
                Some(format!("不安全的路径越过了目标目录：{}", dest.display())));
            return Err(format!("不安全的路径越过了目标目录：{}", dest.display()));
        }
        if let Some(parent) = dest.parent() {
            if let Err(e) = tokio::fs::create_dir_all(parent).await {
                emit_progress(transferred, total_bytes, "error",
                    Some(format!("创建目录 {} 失败：{}", parent.display(), e)));
                return Err(format!("创建目录 {} 失败：{}", parent.display(), e));
            }
        }

        let mut remote_file = match sftp.open(remote_file_path).await {
            Ok(f) => f,
            Err(e) => {
                emit_progress(transferred, total_bytes, "error",
                    Some(format!("打开 {} 失败：{}", remote_file_path, e)));
                return Err(format!("打开 {} 失败：{}", remote_file_path, e));
            }
        };
        // Each file goes to a sibling temp and is renamed over its final name
        // at the end (see sftp_download_file), so a failure or cancel part way
        // through a tree doesn't truncate a file already there.
        let temp = download_temp_path(&dest);
        let mut local_file = match tokio::fs::File::create(&temp).await {
            Ok(f) => f,
            Err(e) => {
                emit_progress(transferred, total_bytes, "error",
                    Some(format!("创建 {} 失败：{}", dest.display(), e)));
                return Err(format!("创建 {} 失败：{}", dest.display(), e));
            }
        };
        let scrap = |tmp: &std::path::Path| { let tmp = tmp.to_path_buf(); async move { let _ = tokio::fs::remove_file(&tmp).await; } };

        loop {
            if cancel.load(Ordering::Relaxed) {
                drop(local_file);
                scrap(&temp).await;
                emit_progress(transferred, total_bytes, "cancelled", None);
                return Err("cancelled".into());
            }
            let n = match remote_file.read(&mut buf).await {
                Ok(n) => n,
                Err(e) => { drop(local_file); scrap(&temp).await; emit_progress(transferred, total_bytes, "error", Some(format!("读取 {} 失败：{}", remote_file_path, e))); return Err(format!("读取 {} 失败：{}", remote_file_path, e)); }
            };
            if n == 0 { break; }
            if let Err(e) = local_file.write_all(&buf[..n]).await {
                drop(local_file); scrap(&temp).await; emit_progress(transferred, total_bytes, "error", Some(format!("写入 {} 失败：{}", dest.display(), e))); return Err(format!("写入 {} 失败：{}", dest.display(), e));
            }
            transferred = transferred.saturating_add(n as u64);
            if last_report.elapsed() >= std::time::Duration::from_millis(100) {
                emit_progress(transferred, total_bytes, "progress", None);
                last_report = std::time::Instant::now();
            }
        }
        // See sftp_download_file: a failed last write surfaces here.
        if let Err(e) = local_file.flush().await {
            drop(local_file); scrap(&temp).await; emit_progress(transferred, total_bytes, "error", Some(format!("刷新 {} 失败：{}", dest.display(), e))); return Err(format!("刷新 {} 失败：{}", dest.display(), e));
        }
        drop(local_file);
        if let Err(e) = tokio::fs::rename(&temp, &dest).await {
            scrap(&temp).await;
            emit_progress(transferred, total_bytes, "error", Some(format!("完成 {} 失败：{}", dest.display(), e)));
            return Err(format!("完成 {} 失败：{}", dest.display(), e));
        }
    }

    emit_progress(transferred, total_bytes, "done", skipped_note);
    Ok(())
}

#[tauri::command]
async fn sftp_upload_file(
    app: tauri::AppHandle,
    state: tauri::State<'_, SshState>,
    session_id: String,
    local_path: String,
    remote_path: String,
    overwrite: Option<bool>,
) -> Result<(), String> {
    use tauri::Emitter;
    use tokio::io::AsyncWriteExt;
    use std::sync::atomic::{AtomicBool, Ordering};

    // Overwrite protection: stat the remote target first; refuse if it
    // exists and the caller hasn't explicitly opted in. Same `EXISTS:<path>`
    // sentinel as the download path. What it finds also tells a cancel
    // whether the file was there before (see open_upload_target).
    let sftp = get_sftp_session(&state, &session_id).await?;
    let existed = sftp.metadata(&remote_path).await.is_ok();
    if existed && overwrite != Some(true) {
        return Err(format!("EXISTS:{}", remote_path));
    }

    // Source must exist and live in a path the user could plausibly own —
    // refuses an SFTP push that would exfiltrate /etc/shadow or the SAM
    // hive if the renderer ever gets coerced.
    let _guarded_local = guard_local_path(&local_path, false)?;

    let total = std::fs::metadata(&local_path)
        .map(|m| m.len())
        .unwrap_or(0);
    let name = std::path::Path::new(&local_path)
        .file_name()
        .and_then(|n| n.to_str())
        .unwrap_or("file")
        .to_string();
    let id = transfer_id();
    let event_name = format!("sftp-transfer-{}", session_id);
    let emit_progress = |bytes: u64, status: &str, error: Option<String>| {
        let _ = app.emit(
            &event_name,
            serde_json::json!({
                "id": id, "name": name, "kind": "upload",
                "bytes": bytes, "total": total,
                "status": status, "error": error,
            }),
        );
    };

    // Symmetric to sftp_download_file: register a cancel flag and clean it
    // up via RAII so a long-running upload can be stopped from the UI.
    let cancel = Arc::new(AtomicBool::new(false));
    let cancels_map = Arc::clone(&state.transfer_cancels);
    cancels_map.lock().await.insert(id.clone(), Arc::clone(&cancel));
    struct CancelGuard {
        map: Arc<tokio::sync::Mutex<std::collections::HashMap<String, Arc<AtomicBool>>>>,
        id: String,
    }
    impl Drop for CancelGuard {
        fn drop(&mut self) {
            if let Ok(mut g) = self.map.try_lock() {
                g.remove(&self.id);
            }
        }
    }
    let _guard = CancelGuard { map: Arc::clone(&cancels_map), id: id.clone() };

    emit_progress(0, "progress", None);

    // Stream the file from disk in chunks rather than slurping the whole thing
    // into a Vec — keeps memory bounded for multi-GB transfers and lets us
    // emit progress along the way.
    let mut local_file = tokio::fs::File::open(&local_path)
        .await
        .map_err(|e| { emit_progress(0, "error", Some(e.to_string())); format!("Failed to read local file: {}", e) })?;
    // The open below truncates a file that is there: a cancel that came in
    // before it must not cost that file its content.
    if cancel.load(Ordering::Relaxed) {
        emit_progress(0, "cancelled", None);
        return Err("cancelled".into());
    }
    let (mut remote_file, created) = open_upload_target(&sftp, &remote_path, existed)
        .await
        .map_err(|e| { emit_progress(0, "error", Some(e.to_string())); format!("打开远程文件失败：{}", e) })?;

    // See sftp_download_file — 256 KiB matches the bigger SSH window.
    let mut buf = vec![0u8; 256 * 1024];
    let mut transferred: u64 = 0;
    let mut last_report = std::time::Instant::now();
    use tokio::io::AsyncReadExt;
    loop {
        if cancel.load(Ordering::Relaxed) {
            let note = finish_cancelled_upload(&sftp, remote_file, &remote_path, &name, created).await;
            emit_progress(transferred, "cancelled", note);
            return Err("cancelled".into());
        }
        let n = local_file
            .read(&mut buf)
            .await
            .map_err(|e| { emit_progress(transferred, "error", Some(e.to_string())); format!("read: {}", e) })?;
        if n == 0 { break; }
        remote_file
            .write_all(&buf[..n])
            .await
            .map_err(|e| { emit_progress(transferred, "error", Some(e.to_string())); format!("write: {}", e) })?;
        transferred += n as u64;
        if last_report.elapsed() >= std::time::Duration::from_millis(100) {
            emit_progress(transferred, "progress", None);
            last_report = std::time::Instant::now();
        }
    }
    // The close can fail after every write went through (the connection
    // drops, the server reports a late write error). The card needs to hear
    // about it like any other failure, or it stays on "progress" for good.
    remote_file
        .shutdown()
        .await
        .map_err(|e| { emit_progress(transferred, "error", Some(e.to_string())); format!("关闭远程文件失败：{}", e) })?;
    emit_progress(transferred, "done", None);
    Ok(())
}

/// Open an upload's remote file for writing, and tell whether this upload
/// created it: then a cancel may delete it. EXCL decides that in the same
/// request, as it opens only a path that has nothing there. Anything else (a
/// file, a link, even a dangling one, or any error) is opened again with
/// TRUNCATE alone and counts as existing, so a cancel leaves it, with its
/// owner, mode and links. `existed` is what a check just before found: a
/// server that ignores EXCL would otherwise let a file that was there pass
/// for a new one.
async fn open_upload_target(
    sftp: &russh_sftp::client::SftpSession,
    remote_path: &str,
    existed: bool,
) -> Result<(russh_sftp::client::fs::File, bool), russh_sftp::client::error::Error> {
    use russh_sftp::protocol::OpenFlags;
    let truncate = OpenFlags::WRITE | OpenFlags::CREATE | OpenFlags::TRUNCATE;
    if let Ok(file) = sftp.open_with_flags(remote_path, truncate | OpenFlags::EXCLUDE).await {
        return Ok((file, !existed));
    }
    Ok((sftp.open_with_flags(remote_path, truncate).await?, false))
}

/// Close the remote file of an upload cancelled mid-write and, when this
/// upload created it, delete it, so no half-written copy stays on the
/// server. Awaited (for up to 10 s) before the upload reports its cancel, so
/// an upload of the same file started right after can't lose its file to
/// this delete. Returns the card's note: what the cancel left on the server.
/// `name` is how the note names the file.
async fn finish_cancelled_upload(
    sftp: &russh_sftp::client::SftpSession,
    mut remote_file: russh_sftp::client::fs::File,
    remote_path: &str,
    name: &str,
    created: bool,
) -> Option<String> {
    use tokio::io::AsyncWriteExt;
    let cleanup = async {
        let _ = remote_file.shutdown().await;
        if created { sftp.remove_file(remote_path).await.err() } else { None }
    };
    let outcome = tokio::time::timeout(std::time::Duration::from_secs(10), cleanup).await;
    if !created {
        return Some(format!("{name} on the server holds only the part sent before the cancel."));
    }
    match outcome {
        Ok(None) => None,
        Ok(Some(e)) => Some(format!("The partly sent {name} is still on the server: {e}")),
        Err(_) => Some(format!("The partly sent {name} may still be on the server: the server took too long to remove it.")),
    }
}

/// Recursive directory upload — mirror of sftp_download_dir. Walks the local
/// tree, mkdirs each subdirectory on the remote, then streams every file
/// through the same flags+chunk logic as sftp_upload_file. Cancel flag and
/// EXISTS sentinel match the download path so the UI can reuse its prompt /
/// progress / abort hooks unchanged.
#[tauri::command]
async fn sftp_upload_dir(
    app: tauri::AppHandle,
    state: tauri::State<'_, SshState>,
    session_id: String,
    local_path: String,
    remote_path: String,
    overwrite: Option<bool>,
) -> Result<(), String> {
    use tauri::Emitter;
    use tokio::io::AsyncWriteExt;
    use std::sync::atomic::{AtomicBool, Ordering};

    // remote_path is the PARENT directory; we hang the basename of
    // local_path underneath it. Matches scp -r / sftp_download_dir.
    let _guarded_local = guard_local_path(&local_path, false)?;

    let local_root = std::path::PathBuf::from(&local_path);
    let folder_name = local_root
        .file_name()
        .and_then(|n| n.to_str())
        .unwrap_or("folder")
        .to_string();
    let folder_name = if folder_name.is_empty() { "folder".to_string() } else { folder_name };

    let sftp = get_sftp_session(&state, &session_id).await?;

    // Overwrite gate on the destination folder. Refuse unless the caller
    // explicitly opted in — symmetric with sftp_download_dir.
    let remote_root = format!("{}/{}",
        remote_path.trim_end_matches('/'),
        folder_name);
    if overwrite != Some(true) {
        if sftp.metadata(&remote_root).await.is_ok() {
            return Err(format!("EXISTS:{}", remote_root));
        }
    }

    let id = transfer_id();
    let event_name = format!("sftp-transfer-{}", session_id);

    // Cancel flag registered before the slow enumeration so the user can
    // abort even while we're walking a deep tree.
    let cancel = Arc::new(AtomicBool::new(false));
    let cancels_map = Arc::clone(&state.transfer_cancels);
    cancels_map.lock().await.insert(id.clone(), Arc::clone(&cancel));
    struct CancelGuard {
        map: Arc<tokio::sync::Mutex<std::collections::HashMap<String, Arc<AtomicBool>>>>,
        id: String,
    }
    impl Drop for CancelGuard {
        fn drop(&mut self) {
            if let Ok(mut g) = self.map.try_lock() {
                g.remove(&self.id);
            }
        }
    }
    let _guard = CancelGuard { map: Arc::clone(&cancels_map), id: id.clone() };

    let id_for_emit = id.clone();
    let name_for_emit = folder_name.clone();
    let app_for_emit = app.clone();
    let event_for_emit = event_name.clone();
    let emit_progress = move |bytes: u64, total: u64, status: &str, error: Option<String>| {
        let _ = app_for_emit.emit(
            &event_for_emit,
            serde_json::json!({
                "id": id_for_emit, "name": name_for_emit, "kind": "upload",
                "bytes": bytes, "total": total,
                "status": status, "error": error,
            }),
        );
    };

    emit_progress(0, 0, "progress", None);

    // Phase 1: enumerate. Collect every local file under local_root along
    // with its relative path (POSIX-style for the remote side) and size.
    // Iterative walk with an explicit stack so we never overflow async
    // recursion on pathological trees.
    let mut files: Vec<(std::path::PathBuf, String, u64)> = Vec::new();
    let mut dirs: Vec<String> = Vec::new(); // relative dir paths (POSIX) to mkdir on remote
    let mut total_bytes: u64 = 0;
    let mut stack: Vec<std::path::PathBuf> = vec![local_root.clone()];

    while let Some(dir) = stack.pop() {
        if cancel.load(Ordering::Relaxed) {
            emit_progress(0, total_bytes, "cancelled", None);
            return Err("cancelled".into());
        }
        let read = match std::fs::read_dir(&dir) {
            Ok(r) => r,
            Err(e) => {
                emit_progress(0, total_bytes, "error", Some(format!("读取目录 {:?} 失败：{}", dir, e)));
                return Err(format!("读取目录 {:?} 失败：{}", dir, e));
            }
        };
        for entry in read {
            let entry = match entry {
                Ok(e) => e,
                Err(_) => continue,
            };
            let path = entry.path();
            let ft = match entry.file_type() {
                Ok(ft) => ft,
                Err(_) => continue,
            };
            let rel = path
                .strip_prefix(&local_root)
                .map(|p| p.to_string_lossy().replace('\\', "/"))
                .unwrap_or_default();
            if ft.is_dir() {
                dirs.push(rel);
                stack.push(path);
            } else if ft.is_file() {
                let size = path.metadata().map(|m| m.len()).unwrap_or(0);
                total_bytes = total_bytes.saturating_add(size);
                files.push((path, rel, size));
            }
            // Symlinks and other types skipped — same as sftp_download_dir.
        }
    }

    // Phase 2: mkdir the destination folder, then each enumerated subdir.
    // SFTP's mkdir is per-level; we already collected them in pre-order from
    // the stack walk but order isn't guaranteed shallow-first, so re-sort
    // by path depth to make sure parents are created before children.
    let _ = sftp.create_dir(&remote_root).await;
    dirs.sort_by_key(|d| d.matches('/').count());
    for rel in &dirs {
        if cancel.load(Ordering::Relaxed) {
            emit_progress(0, total_bytes, "cancelled", None);
            return Err("cancelled".into());
        }
        let full = format!("{}/{}", remote_root.trim_end_matches('/'), rel);
        // Tolerate already-exists — a parallel mkdir or an earlier partial
        // run shouldn't abort the whole upload.
        if sftp.metadata(&full).await.is_err() {
            if let Err(e) = sftp.create_dir(&full).await {
                emit_progress(0, total_bytes, "error", Some(format!("创建目录 {} 失败：{}", full, e)));
                return Err(format!("创建目录 {} 失败：{}", full, e));
            }
        }
    }

    if files.is_empty() {
        emit_progress(0, 0, "done", None);
        return Ok(());
    }

    // Phase 3: stream each file up. Same chunked loop as sftp_upload_file,
    // looped over the file list with a shared progress counter.
    let mut transferred: u64 = 0;
    let mut last_report = std::time::Instant::now();
    let mut buf = vec![0u8; 256 * 1024];
    use tokio::io::AsyncReadExt;

    for (local_file_path, rel, _size) in &files {
        if cancel.load(Ordering::Relaxed) {
            emit_progress(transferred, total_bytes, "cancelled", None);
            return Err("cancelled".into());
        }
        let remote_full = format!("{}/{}", remote_root.trim_end_matches('/'), rel);

        let mut local_file = match tokio::fs::File::open(local_file_path).await {
            Ok(f) => f,
            Err(e) => {
                emit_progress(transferred, total_bytes, "error",
                    Some(format!("打开 {:?} 失败：{}", local_file_path, e)));
                return Err(format!("打开 {:?} 失败：{}", local_file_path, e));
            }
        };
        // See sftp_upload_file: no truncating open after a cancel.
        if cancel.load(Ordering::Relaxed) {
            emit_progress(transferred, total_bytes, "cancelled", None);
            return Err("cancelled".into());
        }
        // Whether each file was there isn't asked (a round trip per file):
        // EXCL alone tells a file this upload created. A cancel deletes only
        // the file it was writing; files already sent and the folders made
        // for them stay.
        let (mut remote_file, created) = match open_upload_target(&sftp, &remote_full, false).await {
            Ok(opened) => opened,
            Err(e) => {
                emit_progress(transferred, total_bytes, "error",
                    Some(format!("打开远程 {} 失败：{}", remote_full, e)));
                return Err(format!("打开远程 {} 失败：{}", remote_full, e));
            }
        };

        loop {
            if cancel.load(Ordering::Relaxed) {
                let shown = format!("{}/{}", folder_name, rel);
                let note = finish_cancelled_upload(&sftp, remote_file, &remote_full, &shown, created).await;
                emit_progress(transferred, total_bytes, "cancelled", note);
                return Err("cancelled".into());
            }
            let n = local_file.read(&mut buf).await
                .map_err(|e| {
                    emit_progress(transferred, total_bytes, "error",
                        Some(format!("读取 {:?} 失败：{}", local_file_path, e)));
                    format!("读取 {:?} 失败：{}", local_file_path, e)
                })?;
            if n == 0 { break; }
            remote_file.write_all(&buf[..n]).await
                .map_err(|e| {
                    emit_progress(transferred, total_bytes, "error",
                        Some(format!("写入 {} 失败：{}", remote_full, e)));
                    format!("写入 {} 失败：{}", remote_full, e)
                })?;
            transferred = transferred.saturating_add(n as u64);
            if last_report.elapsed() >= std::time::Duration::from_millis(100) {
                emit_progress(transferred, total_bytes, "progress", None);
                last_report = std::time::Instant::now();
            }
        }
        // See sftp_upload_file: a failed close must end the card too.
        remote_file.shutdown().await
            .map_err(|e| {
                emit_progress(transferred, total_bytes, "error",
                    Some(format!("close {}: {}", remote_full, e)));
                format!("shutdown {}: {}", remote_full, e)
            })?;
    }

    emit_progress(transferred, total_bytes, "done", None);
    Ok(())
}

/// Flip the cancel flag for an in-flight SFTP transfer. The download / upload
/// loop polls the flag every chunk (every ~256 KiB) and exits with a
/// "cancelled" status event as soon as it sees true. Unknown ids are a no-op
/// — by the time the UI's stop button click reaches us the transfer may have
/// already finished on its own.
#[tauri::command]
async fn sftp_cancel_transfer(
    state: tauri::State<'_, SshState>,
    transfer_id: String,
) -> Result<(), String> {
    if let Some(flag) = state.transfer_cancels.lock().await.get(&transfer_id) {
        flag.store(true, std::sync::atomic::Ordering::Relaxed);
    }
    Ok(())
}

/// Bucket the failure modes that can come out of an SSH connect / auth round.
/// Drives both the UI's `is_auth_error` flag (so auto-reconnect only stops
/// on real credential rejection) and the wording of the error message.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ConnectErrorKind {
    /// Server refused the credentials we presented.
    Auth,
    /// Couldn't agree on KEX / cipher / MAC / host-key algorithm with the
    /// peer. Server is reachable, our crypto preference set doesn't overlap.
    Algorithm,
    /// Host key issue — mismatched, declined by the user, or the prompt
    /// timed out. Distinct from auth: credentials never even got tried.
    HostKey,
    /// Transport-level drop: TCP reset, EOF, peer disconnect, IO error.
    Transport,
    /// Server didn't respond inside our window (handshake / auth / probe).
    Timeout,
    /// We couldn't even reach the box: DNS lookup failed, route missing,
    /// connection refused.
    Unreachable,
    /// Anything russh surfaced that we don't have a categorical bucket for.
    /// Treated as non-auth so the UI keeps trying — a real credential
    /// rejection has a specific variant for it.
    Unknown,
}

impl ConnectErrorKind {
    fn is_auth(self) -> bool {
        matches!(self, Self::Auth)
    }
}

/// Map a russh error onto a `ConnectErrorKind`. Uses enum variants when the
/// information is available (russh 0.40 exposes them all), falling back to
/// a string sniff only for the catch-all `_ =>` branch — so a russh upgrade
/// that adds new variants degrades gracefully instead of misreporting them
/// as auth failures.
fn classify_russh_error(e: &russh::Error) -> ConnectErrorKind {
    use russh::Error::*;
    match e {
        // Real credential rejection — the only path that should set
        // is_auth_error so the UI stops auto-retrying.
        NotAuthenticated | NoAuthMethod => ConnectErrorKind::Auth,

        // Algorithm negotiation — server's reachable, we just don't share
        // the cipher / KEX / etc. it asked for.
        NoCommonAlgo { .. } | UnknownAlgo | UnknownKey => ConnectErrorKind::Algorithm,

        // Host-key flow: the server's signature didn't verify. KeyChanged
        // carries data so it falls through to the catch-all branch which
        // sniffs the string.
        WrongServerSig => ConnectErrorKind::HostKey,

        // Transport-level: connection died mid-protocol.
        IO(_) | HUP | Disconnect | SendError => ConnectErrorKind::Transport,

        // Explicit timeouts from russh.
        ConnectionTimeout | KeepaliveTimeout | InactivityTimeout | Elapsed(_) => ConnectErrorKind::Timeout,

        // Protocol disagreements that aren't algorithm- or auth-shaped:
        // version skew, packet integrity, decryption — surface as transport
        // so the user is told "connection broke" not "password wrong".
        // `StrictKeyExchangeViolation` / `ChannelOpenFailure` carry data;
        // the `_ =>` fallthrough handles those via the string sniff below.
        Version | Kex | PacketAuth | Inconsistent | IndexOutOfBounds
        | DecryptionError | KexInit
        | WrongChannel | Pending => ConnectErrorKind::Transport,

        // Key-file problems (local cert can't be parsed). Tag as Auth-shaped
        // so the UI doesn't auto-retry a key that will keep failing.
        CouldNotReadKey | Keys(_) | SshKey(_) | UnsupportedAuthMethod => ConnectErrorKind::Auth,

        // Last-resort string sniff for anything russh adds in future
        // versions or for io::Error subtypes the explicit arms above
        // missed. Default to Unknown which the driver treats as non-auth.
        _ => {
            let lc = e.to_string().to_lowercase();
            if lc.contains("connection refused")
                || lc.contains("no route")
                || lc.contains("network is unreachable")
                || lc.contains("dns")
            {
                ConnectErrorKind::Unreachable
            } else if lc.contains("timed out") || lc.contains("timeout") {
                ConnectErrorKind::Timeout
            } else if lc.contains("io error") || lc.contains("eof")
                || lc.contains("disconnect") || lc.contains("reset")
                || lc.contains("broken pipe") || lc.contains("aborted")
            {
                ConnectErrorKind::Transport
            } else if lc.contains("not authenticated") || lc.contains("auth method") {
                ConnectErrorKind::Auth
            } else {
                ConnectErrorKind::Unknown
            }
        }
    }
}

/// Human-readable phrase for an error bucket. Combined with `target` to
/// build the reason string the UI shows next to a failed connection.
fn describe_error_kind(kind: ConnectErrorKind, target: &str) -> String {
    match kind {
        ConnectErrorKind::Auth =>
            "Authentication rejected by server (wrong password, missing key, or account locked).".into(),
        ConnectErrorKind::Algorithm =>
            format!("Negotiation with {} failed: no SSH algorithm in common (the server only offers key-exchange, host-key, cipher or MAC algorithms Submarine doesn't support).", target),
        ConnectErrorKind::HostKey =>
            "Host key was not approved (wrong key, declined, or the fingerprint prompt timed out).".into(),
        ConnectErrorKind::Transport =>
            format!("Connection to {} dropped mid-handshake.", target),
        ConnectErrorKind::Timeout =>
            format!("{} did not respond in time.", target),
        ConnectErrorKind::Unreachable =>
            format!("Could not reach {} (DNS lookup, route, or port refusal).", target),
        ConnectErrorKind::Unknown =>
            format!("Connection to {} failed for an unrecognised reason.", target),
    }
}

/// Translate raw socket / SSH error messages into something a human can act
/// on. Most russh / tokio errors come out as "tcp: io error: ..." with the
/// useful detail buried — this lifts the common cases up to a clear sentence
/// while still falling back to the original text for anything unfamiliar.
fn humanize_network_err(raw: &str, host: &str, port: i32, label: &str) -> String {
    let lower = raw.to_lowercase();
    let target = if port > 0 { format!("{}:{}", host, port) } else { host.to_string() };

    if lower.contains("connection refused") {
        return format!("{}: {} refused the connection (is the SSH server running on this port?)", label, target);
    }
    if lower.contains("network is unreachable") || lower.contains("network unreachable") {
        return format!("{}: network is unreachable — check VPN / firewall / internet", label);
    }
    if lower.contains("no route to host") {
        return format!("{}: no route to {} — host is down or blocked", label, target);
    }
    if lower.contains("name or service not known")
        || lower.contains("nodename nor servname")
        || lower.contains("failed to lookup address")
        || lower.contains("no such host")
        || lower.contains("dns")
    {
        return format!("{}: could not resolve hostname {}", label, host);
    }
    if lower.contains("timed out") || lower.contains("timeout") {
        return format!("{}: {} did not respond in time", label, target);
    }
    if lower.contains("connection reset") || lower.contains("broken pipe") {
        return format!("{}: {} closed the connection", label, target);
    }
    if lower.contains("permission denied") {
        return format!("{}: permission denied (check key file readability)", label);
    }
    // Fallback — keep the raw detail so power users can still see it.
    format!("{}: {}", label, raw)
}

// Monotonically-increasing per-transfer id. The frontend uses it to group
// progress events into one updatable card per transfer.
fn transfer_id() -> String {
    use std::sync::atomic::{AtomicU64, Ordering};
    static COUNTER: AtomicU64 = AtomicU64::new(0);
    let seq = COUNTER.fetch_add(1, Ordering::Relaxed);
    let ts = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_millis())
        .unwrap_or(0);
    format!("{}-{}", ts, seq)
}

/// Remove this run's temp root (live-edit / drag staging), and any left by a
/// run that didn't get to. Called on exit, and on startup for the old ones.
/// Only `submarine-<hex>` dirs older than a day are swept on startup: a newer
/// one may belong to another copy of the app running right now (the user's
/// installed app beside a test build, say), whose live files must not go.
fn sweep_app_temp(include_own: bool) {
    if include_own {
        let _ = std::fs::remove_dir_all(app_temp_root());
    }
    let Ok(entries) = std::fs::read_dir(std::env::temp_dir()) else { return };
    let day = std::time::Duration::from_secs(24 * 60 * 60);
    for e in entries.flatten() {
        let name = e.file_name();
        let Some(name) = name.to_str() else { continue };
        // `submarine-<32 hex>`, the shape app_temp_root mints.
        let is_ours = name.strip_prefix("submarine-").is_some_and(|h| h.len() == 32 && h.bytes().all(|b| b.is_ascii_hexdigit()));
        if !is_ours {
            continue;
        }
        let old = e
            .metadata()
            .and_then(|m| m.modified())
            .map(|t| t.elapsed().map(|age| age > day).unwrap_or(false))
            .unwrap_or(false);
        if old {
            let _ = std::fs::remove_dir_all(e.path());
        }
    }
}

/// The most a remote file read whole into memory may be: live-edit opens the
/// file in an editor and drag stages it, both for ordinary files a person
/// edits or drags, so a huge or endless one (a 6 GB image, a broken server's
/// unbounded read) is refused rather than exhausting memory.
const SFTP_INLINE_MAX_BYTES: u64 = 50 * 1024 * 1024;

/// Caps on one recursive directory download, against a broken or hostile
/// server: a tree deeper than this, or with more files or bytes, is refused
/// before it can grow the in-memory file list without bound.
const DOWNLOAD_DIR_MAX_DEPTH: usize = 64;
const DOWNLOAD_DIR_MAX_FILES: usize = 200_000;
const DOWNLOAD_DIR_MAX_BYTES: u64 = 100 * 1024 * 1024 * 1024;

/// A sibling temp name for `dest`, e.g. `foo.txt` → `foo.txt.sub-tmp-<id>`.
/// A download writes here, then renames over `dest`, so a transfer that fails
/// or is cancelled never truncates a file that was already there (the rename
/// is the only thing that touches `dest`, and only once the bytes are in).
fn download_temp_path(dest: &std::path::Path) -> std::path::PathBuf {
    let mut name = dest.as_os_str().to_os_string();
    name.push(format!(".sub-tmp-{}", transfer_id()));
    std::path::PathBuf::from(name)
}

/// The remote file's size, or `None` if the server doesn't report it. For a
/// read-whole-into-memory path (live-edit, drag): over `SFTP_INLINE_MAX_BYTES`
/// is refused; an unknown size is allowed (and the read itself is bounded by
/// the cap, below).
async fn refuse_if_too_big_to_inline(
    sftp: &russh_sftp::client::SftpSession,
    remote_path: &str,
) -> Result<(), String> {
    if let Ok(meta) = sftp.metadata(remote_path).await {
        if let Some(size) = meta.size {
            if size > SFTP_INLINE_MAX_BYTES {
                return Err(format!(
                    "[SFTP] FILE_TOO_LARGE: {} is {:.0} MB — too large to open or drag here (limit {} MB). Download it instead.",
                    remote_path,
                    size as f64 / (1024.0 * 1024.0),
                    SFTP_INLINE_MAX_BYTES / (1024 * 1024)
                ));
            }
        }
    }
    Ok(())
}

/// Read a remote file whole, up to `SFTP_INLINE_MAX_BYTES`. A server that
/// under-reported its size (or streams endlessly) is still stopped at the cap
/// rather than filling memory.
async fn read_remote_capped(
    sftp: &russh_sftp::client::SftpSession,
    remote_path: &str,
) -> Result<Vec<u8>, String> {
    use tokio::io::AsyncReadExt;
    let mut file = sftp.open(remote_path).await.map_err(|e| format!("Failed to read remote file: {e}"))?;
    let mut data = Vec::new();
    let mut buf = vec![0u8; 256 * 1024];
    loop {
        let n = file.read(&mut buf).await.map_err(|e| e.to_string())?;
        if n == 0 {
            break;
        }
        if data.len() as u64 + n as u64 > SFTP_INLINE_MAX_BYTES {
            return Err(format!(
                "[SFTP] FILE_TOO_LARGE: {} is over {} MB — too large to open or drag here. Download it instead.",
                remote_path,
                SFTP_INLINE_MAX_BYTES / (1024 * 1024)
            ));
        }
        data.extend_from_slice(&buf[..n]);
    }
    Ok(data)
}

/// Process-global, UNPREDICTABLE temp root for SFTP live-edit / drag staging,
/// created once with a random name (and 0700 on Unix). The old code used a
/// fully predictable `submarine_sftp_<session_id>` directory directly in the
/// world-writable, sticky-bit /tmp — on a shared host a local attacker could
/// pre-create it (owning it) before the victim opened a remote file, capturing
/// the downloaded (possibly sensitive) contents or redirecting the write via a
/// planted symlink. A random, non-guessable root the attacker cannot pre-create
/// closes that; per-session subdirs live under it and are removed by name.
fn app_temp_root() -> &'static std::path::PathBuf {
    static ROOT: std::sync::OnceLock<std::path::PathBuf> = std::sync::OnceLock::new();
    ROOT.get_or_init(|| {
        let mut bytes = [0u8; 12];
        rand::rng().fill_bytes(&mut bytes);
        let root = std::env::temp_dir().join(format!("submarine-{}", hex::encode(bytes)));
        let _ = std::fs::create_dir_all(&root);
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            let _ = std::fs::set_permissions(&root, std::fs::Permissions::from_mode(0o700));
        }
        root
    })
}

/// Per-session live-edit staging dir, under the unpredictable root.
fn session_sftp_dir(session_id: &str) -> Result<std::path::PathBuf, String> {
    Ok(app_temp_root().join(format!("sftp_{}", session_temp_name(session_id)?)))
}

/// Per-session drag staging dir, under the unpredictable root.
fn session_drag_dir(session_id: &str) -> Result<std::path::PathBuf, String> {
    Ok(app_temp_root().join(format!("drag_{}", session_temp_name(session_id)?)))
}

/// A session's part of its temp dirs' names: the session id as the frontend
/// makes it (`session-<id>`, `session-quick-<ms>`, plus `::sftp` / `::fwd`
/// for the dedicated connections), `::` spelled `__` since `:` can't be in a
/// Windows file name. Any other id is refused: it comes over IPC, and a
/// separator or `..` in it would put the directory, and the cleanup that
/// deletes it whole, outside the app's temp root.
fn session_temp_name(session_id: &str) -> Result<String, String> {
    let (base, suffix) = match session_id.split_once("::") {
        Some((base, suffix @ ("sftp" | "fwd"))) => (base, Some(suffix)),
        Some(_) => return Err("[SESSION] BAD_ID".into()),
        None => (session_id, None),
    };
    let fine = |b: u8| b.is_ascii_alphanumeric() || b == b'-' || b == b'_';
    if base.is_empty() || base.len() > 128 || !base.bytes().all(fine) {
        return Err("[SESSION] BAD_ID".into());
    }
    Ok(match suffix {
        Some(s) => format!("{base}__{s}"),
        None => base.to_string(),
    })
}

#[cfg(test)]
mod ipc_path_tests {
    use super::*;
    use std::path::Path;

    // A session's temp dirs are named after its id only when the id is one
    // the frontend makes; anything else (a separator, `..`, another suffix)
    // is refused, so a dir and the cleanup that deletes it stay in the root.
    #[test]
    fn session_ids_name_temp_dirs_only_in_the_frontends_shape() {
        assert_eq!(session_temp_name("session-5").unwrap(), "session-5");
        assert_eq!(session_temp_name("session-quick-1700000000000").unwrap(), "session-quick-1700000000000");
        assert_eq!(session_temp_name("session-5::sftp").unwrap(), "session-5__sftp");
        assert_eq!(session_temp_name("session-5::fwd").unwrap(), "session-5__fwd");
        for bad in ["", "..", "../x", "a/b", "a\\b", "C:", "a b", "x::other", "x::sftp::sftp", "x\0"] {
            assert!(session_temp_name(bad).is_err(), "{bad:?}");
        }
        assert!(session_drag_dir("../../outside").is_err());
        assert!(session_sftp_dir("session-5").unwrap().starts_with(app_temp_root()));
    }

    // A key file has to be on this computer's drives: network-share, device
    // and `\\?\` paths are refused before anything is looked up.
    #[test]
    fn key_files_have_to_be_on_this_computer() {
        assert!(local_file_path(Path::new("id_ed25519")).is_ok());
        #[cfg(windows)]
        {
            assert!(local_file_path(Path::new(r"C:\Users\me\.ssh\id_ed25519")).is_ok());
            for bad in [
                r"\\attacker\share\id",
                "//attacker/share/id",
                r"\\?\UNC\attacker\share\id",
                r"\\?\C:\Users\me\.ssh\id",
                r"\\.\pipe\id",
            ] {
                assert!(local_file_path(Path::new(bad)).is_err(), "{bad}");
            }
        }
    }

    #[test]
    fn a_pub_file_is_read_only_when_small() {
        let dir = std::env::temp_dir().join(format!("submarine-pubcap-{}", std::process::id()));
        std::fs::create_dir_all(&dir).unwrap();
        std::fs::write(dir.join("small.pub"), "ssh-ed25519 AAAA test").unwrap();
        std::fs::write(dir.join("big.pub"), vec![b'a'; 20 * 1024]).unwrap();
        assert_eq!(small_text_file(&dir.join("small.pub"), 16 * 1024).as_deref(), Some("ssh-ed25519 AAAA test"));
        assert_eq!(small_text_file(&dir.join("big.pub"), 16 * 1024), None);
        assert_eq!(small_text_file(&dir, 16 * 1024), None, "a directory isn't read");
        assert_eq!(small_text_file(&dir.join("missing.pub"), 16 * 1024), None);
        let _ = std::fs::remove_dir_all(&dir);
    }
}

/// Reduce a server-controlled remote path to a safe LOCAL leaf filename for
/// temp staging. Rejects empty / "." / ".." and any name containing a path
/// separator, a drive marker (`:`), or NUL — the exact set that would let a
/// hostile/compromised SFTP server escape the per-session temp dir. On Windows
/// a leaf like "C:evil.txt" is drive-relative: `PathBuf::join` discards the
/// base and resolves it against the process CWD, writing (and auto-opening)
/// attacker bytes outside the sandbox. One gate for both live-edit and drag.
fn safe_temp_leaf_name(remote_path: &str) -> Result<String, String> {
    let raw = std::path::Path::new(remote_path)
        .file_name()
        .and_then(|n| n.to_str())
        .unwrap_or("");
    let bad = |c: char| matches!(c, '/' | '\\' | ':' | '\0');
    if raw.is_empty() || raw == "." || raw == ".." || raw.contains(bad) {
        return Err(format!("refusing file with unsafe name: {:?}", raw));
    }
    Ok(raw.to_string())
}

/// The folder, inside a session's temp dir, that holds the live-edit copy of
/// one remote file: 16 hex digits of the SHA-256 of its path. The copy keeps
/// the file's own name (editors go by it), so without a folder per path two
/// remote files with the same name would share one local copy.
fn live_edit_dir_name(remote_path: &str) -> String {
    use sha2::{Digest, Sha256};
    hex::encode(&Sha256::digest(remote_path.as_bytes())[..8])
}

#[cfg(test)]
mod live_edit_tests {
    use super::live_edit_dir_name;

    #[test]
    fn same_named_files_in_different_folders_get_different_copies() {
        let a = live_edit_dir_name("/var/www/site1/index.php");
        let b = live_edit_dir_name("/var/www/site2/index.php");
        assert_ne!(a, b);
        assert_eq!(a, live_edit_dir_name("/var/www/site1/index.php"), "stable for one path");
        for name in [&a, &b] {
            assert_eq!(name.len(), 16);
            assert!(name.chars().all(|c| c.is_ascii_hexdigit()), "a plain folder name: {name}");
        }
    }
}

#[tauri::command]
async fn sftp_open_remote_file(
    app_handle: tauri::AppHandle,
    state: tauri::State<'_, SshState>,
    session_id: String,
    remote_path: String,
) -> Result<(), String> {
    use tauri::Emitter;

    let sftp = get_sftp_session(&state, &session_id).await?;
    let filename = safe_temp_leaf_name(&remote_path)?;

    // Live-edit opens the copy in an editor, so refuse a file too large to
    // hold in memory (a huge binary, or a broken server's endless read) —
    // see refuse_if_too_big_to_inline / read_remote_capped.
    refuse_if_too_big_to_inline(&sftp, &remote_path).await?;
    let data = read_remote_capped(&sftp, &remote_path).await?;

    // Per-session subdirectory so we can sweep everything cleanly on
    // disconnect rather than leaving loose `submarine_sftp_*` files in the global
    // temp dir. The directory is also a smaller blast radius for any path-
    // related shenanigans (each editor sees only files from one session).
    // Inside it, one folder per remote file (live_edit_dir_name). Copies used
    // to sit side by side under their bare names: opening /a/index.php and
    // then /b/index.php wrote b's content over a's copy, and a's watcher
    // uploaded it to /a/index.php without any edit.
    let copy_dir = session_sftp_dir(&session_id)?.join(live_edit_dir_name(&remote_path));
    std::fs::create_dir_all(&copy_dir)
        .map_err(|e| format!("Failed to create temp dir: {}", e))?;
    let temp_file_path = copy_dir.join(&filename);
    std::fs::write(&temp_file_path, &data).map_err(|e| format!("写入临时文件失败：{}", e))?;
    // What the server holds as far as we know — upload only when the copy
    // differs from it, not on every write event (an editor touching the file,
    // the same file opened a second time).
    let synced_hash = {
        use sha2::{Digest, Sha256};
        Sha256::digest(&data).to_vec()
    };

    // Open local temp file in system default application. The whole
    // live-edit-in-default-editor feature is desktop-only — Android's
    // intent-based "open with" model would need a Tauri plugin instead,
    // and saving back through SAF doesn't fit the temp-file pattern we
    // depend on. Refuse cleanly so the UI can surface a polite message.
    #[cfg(target_os = "android")]
    {
        let _ = &temp_file_path;
        return Err("Live edit in system editor is not available on Android.".into());
    }
    #[cfg(not(target_os = "android"))]
    {
        let open_res = open::that(&temp_file_path);
        if let Err(e) = open_res {
            return Err(format!("Failed to open file: {}", e));
        }
    }

    // Spawn modification watcher task in background
    let connections_clone = Arc::clone(&state.connections);
    let elevation_clone = Arc::clone(&state.sftp_elevation);
    let app_handle_clone = app_handle.clone();
    let session_id_clone = session_id.clone();
    let remote_path_clone = remote_path.clone();
    let filename_clone = filename.clone();
    let temp_file_path_clone = temp_file_path.clone();

    tokio::spawn(async move {
        // Notify-driven save detection instead of the old 1.5s poll. Wires
        // the same `notify-debouncer-mini` crate the mirror module uses:
        //   - std::mpsc::Sender feeds the debouncer (a blocking pool task
        //     forwards into a tokio mpsc so this async loop can await it)
        //   - 750ms debounce coalesces an editor's swap-then-rename
        //     save pattern (vim, vscode) into one upload instead of
        //     several. The previous polling burned a syscall every
        //     1.5s for up to 4800 iterations per open file.
        use notify_debouncer_mini::{new_debouncer, notify::RecursiveMode, DebouncedEventKind};
        let (raw_tx, raw_rx) = std::sync::mpsc::channel();
        let (tok_tx, mut tok_rx) = tokio::sync::mpsc::channel::<()>(8);
        let mut debouncer = match new_debouncer(std::time::Duration::from_millis(750), raw_tx) {
            Ok(d) => d,
            Err(e) => {
                eprintln!("[sftp-live-edit] debouncer init failed: {} — falling back to no autosync", e);
                let _ = std::fs::remove_file(&temp_file_path_clone);
                return;
            }
        };
        if let Err(e) = debouncer.watcher().watch(&temp_file_path_clone, RecursiveMode::NonRecursive) {
            eprintln!("[sftp-live-edit] watch failed: {} — falling back to no autosync", e);
            let _ = std::fs::remove_file(&temp_file_path_clone);
            return;
        }
        // Forward bridge: std::mpsc::recv blocks, so it has to live on the
        // blocking pool.
        tokio::task::spawn_blocking(move || {
            while let Ok(res) = raw_rx.recv() {
                if let Ok(events) = res {
                    if events.iter().any(|ev| matches!(ev.kind, DebouncedEventKind::Any | DebouncedEventKind::AnyContinuous)) {
                        if tok_tx.blocking_send(()).is_err() { break; }
                    }
                }
            }
        });

        // Overall 2-hour ceiling so an editor left open forever doesn't
        // keep the watcher alive past any reasonable session.
        let deadline = tokio::time::Instant::now() + std::time::Duration::from_secs(2 * 60 * 60);
        let mut synced_hash = synced_hash;
        loop {
            let wait = tokio::time::sleep_until(deadline);
            tokio::select! {
                _ = wait => break,
                maybe = tok_rx.recv() => {
                    if maybe.is_none() { break; }
                    if !temp_file_path_clone.exists() { break; }
                    let content = match std::fs::read(&temp_file_path_clone) {
                        Ok(c) => c,
                        Err(e) => {
                            let _ = app_handle_clone.emit(
                                &format!("sftp-sync-status-{}", session_id_clone),
                                serde_json::json!({ "status": "error", "message": format!("Auto-sync failed: Failed to read file: {}", e) })
                            );
                            continue;
                        }
                    };
                    let content_hash = {
                        use sha2::{Digest, Sha256};
                        Sha256::digest(&content).to_vec()
                    };
                    if content_hash == synced_hash { continue; }
                    // Cheap pre-check: if the session is gone we exit the
                    // watcher entirely instead of looping and spamming
                    // "Auto-sync failed" toasts on every subsequent save.
                    {
                        let connections = connections_clone.lock().await;
                        if !connections.contains_key(&session_id_clone) {
                            let _ = app_handle_clone.emit(
                                &format!("sftp-sync-status-{}", session_id_clone),
                                serde_json::json!({
                                    "status": "error",
                                    "message": format!("Auto-sync stopped — session for {} is gone", filename_clone),
                                }),
                            );
                            break;
                        }
                    }
                    let upload_res = async {
                    let session_arc = {
                        let connections = connections_clone.lock().await;
                        connections.get(&session_id_clone).map(|sess| Arc::clone(sess))
                    };

                    let session_arc = match session_arc {
                        Some(sess) => sess,
                        None => return Err("SSH session disconnected".to_string()),
                    };

                    // Open the SFTP subsystem, then IMMEDIATELY drop the
                    // session mutex. Holding it across the whole write serialises
                    // every open_terminal / cold-cache SFTP-bootstrap request on
                    // the same session behind this one save — visible as a UI
                    // freeze whenever the user Ctrl-S's a large remote file.
                    // An elevated tab (file ops as root via sudo) must save
                    // back the same way, or root-owned files can't be written.
                    let elevation = elevation_clone.lock().await.get(&session_id_clone).cloned();
                    let sftp = if let Some(elev) = elevation {
                        open_elevated_sftp(&session_arc, &elev).await?
                    } else {
                        let session = session_arc.lock().await;
                        let channel = session.channel_open_session().await.map_err(|e| e.to_string())?;
                        channel.request_subsystem(true, "sftp").await.map_err(|e| e.to_string())?;
                        let s = russh_sftp::client::SftpSession::new_with_config(channel.into_stream(), sftp_client_config())
                            .await
                            .map_err(|e| e.to_string())?;
                        drop(session);
                        s
                    };

                    use russh_sftp::protocol::OpenFlags;
                    use tokio::io::AsyncWriteExt;
                    // Truncate so shortening the file doesn't leave the old
                    // tail behind on the server.
                    let mut remote_file = sftp
                        .open_with_flags(
                            &remote_path_clone,
                            OpenFlags::WRITE | OpenFlags::CREATE | OpenFlags::TRUNCATE,
                        )
                        .await
                        .map_err(|e| format!("打开远程文件失败：{}", e))?;
                    remote_file
                        .write_all(&content)
                        .await
                        .map_err(|e| format!("Failed to write to remote: {}", e))?;
                    remote_file
                        .shutdown()
                        .await
                        .map_err(|e| format!("关闭远程文件失败：{}", e))?;
                    Ok::<(), String>(())
                    }.await;

                    if let Err(e) = upload_res {
                        let _ = app_handle_clone.emit(
                            &format!("sftp-sync-status-{}", session_id_clone),
                            serde_json::json!({ "status": "error", "message": format!("Auto-sync failed: {}", e) })
                        );
                    } else {
                        synced_hash = content_hash;
                        let _ = app_handle_clone.emit(
                            &format!("sftp-sync-status-{}", session_id_clone),
                            serde_json::json!({ "status": "success", "message": format!("Auto-synced {}", filename_clone) })
                        );
                    }
                }
            }
        }
        // The watcher exited (timeout, file disappeared, or session gone).
        // Wipe the temp file so the remote contents aren't left lying around
        // in OS temp once editing is done. Errors are intentionally ignored
        // — on Windows the editor may still hold a lock on the file, and the
        // worst case is the file persists until the OS cleans temp.
        drop(debouncer);
        let _ = std::fs::remove_file(&temp_file_path_clone);
        if let Some(dir) = temp_file_path_clone.parent() {
            let _ = std::fs::remove_dir(dir); // the file's own folder, if now empty
        }
    });

    Ok(())
}

#[tauri::command]
async fn sftp_prepare_drag(
    state: tauri::State<'_, SshState>,
    session_id: String,
    remote_path: String,
) -> Result<String, String> {
    let sftp = get_sftp_session(&state, &session_id).await?;
    // A drag stages the file in a temp dir; refuse one too large to hold in
    // memory, as live-edit does (read_remote_capped also stops an endless read).
    refuse_if_too_big_to_inline(&sftp, &remote_path).await?;
    let data = read_remote_capped(&sftp, &remote_path).await?;

    // Sanitize the filename: a hostile (or compromised) SFTP server picks
    // remote_path, and we used to drop the basename straight into the OS
    // temp dir. safe_temp_leaf_name restricts to a safe leaf (no separators,
    // no `..`, no drive markers) and we scope to a per-session subdir so
    // parallel drags don't clobber each other.
    let raw_name = safe_temp_leaf_name(&remote_path)?;
    let session_dir = session_drag_dir(&session_id)?;
    std::fs::create_dir_all(&session_dir)
        .map_err(|e| format!("Failed to create drag staging dir: {}", e))?;
    let temp_file_path = session_dir.join(&raw_name);
    std::fs::write(&temp_file_path, &data).map_err(|e| format!("写入临时文件失败：{}", e))?;

    Ok(temp_file_path.to_string_lossy().to_string())
}

#[tauri::command]
async fn local_open_file(local_path: String) -> Result<(), String> {
    #[cfg(target_os = "android")]
    {
        let _ = local_path;
        return Err("Open-with is not available on Android.".into());
    }
    #[cfg(not(target_os = "android"))]
    {
        let safe = guard_local_path(&local_path, false)?;
        open::that(&safe).map_err(|e| format!("Failed to open local file: {}", e))?;
        Ok(())
    }
}

#[tauri::command]
async fn local_open_in_explorer(local_path: String) -> Result<(), String> {
    #[cfg(target_os = "android")]
    {
        let _ = local_path;
        return Err("Open-in-Explorer is not available on Android.".into());
    }
    #[cfg(not(target_os = "android"))]
    {
        let safe = guard_local_path(&local_path, false)?;
        if safe.is_dir() {
            open::that(&safe).map_err(|e| format!("打开文件夹失败：{}", e))?;
        } else if let Some(parent) = safe.parent() {
            open::that(parent).map_err(|e| format!("打开文件夹失败：{}", e))?;
        }
        Ok(())
    }
}

#[derive(serde::Serialize)]
struct LocalFileEntry {
    name: String,
    path: String,
    /// For a symlink / junction this describes the TARGET (see SftpFileEntry).
    is_dir: bool,
    size: u64,
    modified: Option<u64>,
    is_symlink: bool,
    broken_link: bool,
}

#[tauri::command]
async fn local_home_dir(app: tauri::AppHandle) -> Result<String, String> {
    #[cfg(target_os = "android")]
    {
        // Android has no "home directory" in the desktop sense — the
        // `directories` crate returns nothing meaningful here. Fall back to
        // whatever the quick-dirs probe picked (Downloads if writable, else
        // app-scoped external storage) so the callers that want *some*
        // starting point still get one instead of an error.
        let dir = android_default_local_dir(app).await?;
        if !dir.is_empty() { return Ok(dir); }
        return Err("Could not resolve home directory".into());
    }
    #[cfg(not(target_os = "android"))]
    {
        let _ = app;
        directories::UserDirs::new()
            .and_then(|d| d.home_dir().to_str().map(String::from))
            .ok_or_else(|| "Could not resolve home directory".into())
    }
}

#[tauri::command]
async fn local_desktop_dir(app: tauri::AppHandle) -> Result<String, String> {
    #[cfg(target_os = "android")]
    {
        // No Desktop concept on Android — reuse the writable-probe default
        // instead of erroring, so `FilePanel.homePath()` lands somewhere
        // useful on first load.
        let dir = android_default_local_dir(app).await?;
        if !dir.is_empty() { return Ok(dir); }
        return Err("Could not resolve default directory".into());
    }
    #[cfg(not(target_os = "android"))]
    {
        let _ = app;
        // Falls back to the home directory if a Desktop folder isn't configured
        // for the user (rare on desktop OSes but possible on Linux without XDG).
        if let Some(dirs) = directories::UserDirs::new() {
            if let Some(d) = dirs.desktop_dir().and_then(|p| p.to_str()) {
                return Ok(d.to_string());
            }
            if let Some(h) = dirs.home_dir().to_str() {
                return Ok(h.to_string());
            }
        }
        Err("Could not resolve Desktop directory".into())
    }
}

/// Test whether a directory is actually writable by the current process.
/// On Android, scoped storage means many paths appear readable via
/// `Path::exists()` but writes fail with EACCES — so we probe with a real
/// touch + delete. The probe filename is a random UUID-style token so
/// concurrent runs don't collide, and we tolerate `AlreadyExists` because
/// that still proves the parent is writable. Only called from the Android
/// quick-dirs picker today; the `#[allow]` keeps the desktop build quiet.
#[allow(dead_code)]
fn is_dir_writable(p: &std::path::Path) -> bool {
    if !p.is_dir() { return false; }
    let seq = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_nanos())
        .unwrap_or(0);
    let probe = p.join(format!(".submarine-probe-{}", seq));
    match std::fs::write(&probe, b"") {
        Ok(_) => {
            let _ = std::fs::remove_file(&probe);
            true
        }
        Err(_) => false,
    }
}

/// Labeled quick-pick entries for the local file picker on Android.
/// Only writable paths are returned — the frontend uses this to populate a
/// small popover instead of the native rfd picker (which doesn't exist on
/// Android). Order is by preference: user-visible storage first (Downloads,
/// Documents), then app-scoped fallbacks that always work under scoped
/// storage. All returned paths are already canonical, so they pass
/// `guard_local_path` without further massaging.
#[derive(serde::Serialize)]
pub struct AndroidQuickDir {
    pub label: String,
    pub path: String,
}

#[tauri::command]
async fn android_quick_dirs(app: tauri::AppHandle) -> Result<Vec<AndroidQuickDir>, String> {
    #[cfg(not(target_os = "android"))]
    {
        let _ = app;
        return Ok(Vec::new());
    }
    #[cfg(target_os = "android")]
    {
        // Build the candidate list up front (label + path pairs), then run
        // the writability probe + dedupe in a plain loop. The earlier
        // closure-based version couldn't coexist with the later
        // `out.is_empty()` re-borrow because the closure held a mutable
        // borrow of `out` for the whole function scope.
        let mut candidates: Vec<(String, std::path::PathBuf)> = vec![
            ("Downloads".into(),  std::path::PathBuf::from("/storage/emulated/0/Download")),
            ("Documents".into(),  std::path::PathBuf::from("/storage/emulated/0/Documents")),
            ("DCIM".into(),       std::path::PathBuf::from("/storage/emulated/0/DCIM")),
            ("Pictures".into(),   std::path::PathBuf::from("/storage/emulated/0/Pictures")),
            ("Movies".into(),     std::path::PathBuf::from("/storage/emulated/0/Movies")),
            ("Music".into(),      std::path::PathBuf::from("/storage/emulated/0/Music")),
            ("SD card".into(),    std::path::PathBuf::from("/storage/emulated/0")),
        ];
        // App-scoped external files dir — always writable, survives reboots,
        // and visible to the user through any file manager under
        // Android/data/com.submarine.app/files. This is the fallback default
        // when everything shared is locked down.
        if let Ok(dir) = app.path().app_local_data_dir() {
            candidates.push(("App storage".into(), dir));
        }
        let mut out: Vec<AndroidQuickDir> = Vec::new();
        let mut seen = std::collections::HashSet::<String>::new();
        for (label, path) in candidates {
            if !is_dir_writable(&path) { continue; }
            let s = path.to_string_lossy().into_owned();
            if seen.insert(s.clone()) {
                out.push(AndroidQuickDir { label, path: s });
            }
        }
        // Internal cache — last-resort, still writable but hidden from the
        // user in most stock file managers. We only add it when nothing else
        // survived the writability probe above.
        if out.is_empty() {
            if let Ok(dir) = app.path().app_cache_dir() {
                if is_dir_writable(&dir) {
                    let s = dir.to_string_lossy().into_owned();
                    out.push(AndroidQuickDir { label: "App cache".into(), path: s });
                }
            }
        }
        Ok(out)
    }
}

/// Preferred default working directory on Android — first writable entry
/// from `android_quick_dirs`. FilePanel calls this on mount so the local
/// pane opens somewhere useful instead of `/` (which lists nothing under
/// scoped storage). Empty string means "leave the current path alone" and
/// is treated as a no-op by the frontend.
#[tauri::command]
async fn android_default_local_dir(app: tauri::AppHandle) -> Result<String, String> {
    let dirs = android_quick_dirs(app).await?;
    Ok(dirs.into_iter().next().map(|d| d.path).unwrap_or_default())
}

/// One resolved entry from an OpenSSH client config `Host` block. The
/// frontend picks a subset of these and turns each into a fresh server row
/// via the existing `add_server` command. A host that named an `IdentityFile`
/// gets that key registered and linked; everything else lands password-less
/// for the user to finish.
#[derive(serde::Serialize)]
struct ImportedHost {
    /// The alias the user actually types (`ssh <alias>`) — becomes the
    /// server's display name after import.
    host_alias: String,
    /// Resolved `HostName`, or the alias itself if the block didn't set one
    /// (matches OpenSSH's own behaviour when HostName is omitted).
    hostname: String,
    /// Resolved `Port`, defaulting to the standard SSH port.
    port: u16,
    /// Resolved `User`. Empty string when unset — the frontend can fall
    /// back to whatever it uses elsewhere.
    user: String,
    /// Resolved `IdentityFile`, still in the config's own spelling (`~` and
    /// all). The importer feeds it to `import_ssh_key_file`, which expands and
    /// reads it, so a host that names a key comes in as a key-authenticated
    /// row rather than one the user has to go back and finish.
    identity_file: Option<String>,
    /// Resolved `ProxyJump`. Informational only; live proxy config still
    /// happens in the Server details panel.
    proxy_jump: Option<String>,
}

/// Read the user's OpenSSH client config (default `~/.ssh/config`) and
/// return one `ImportedHost` per non-wildcard alias so the UI can offer a
/// checkbox picker. We deliberately keep the parser dumb: no macro
/// expansion, no `Include` recursion, no token substitution (`%h`/`%u`),
/// no `Match` blocks. Anything we don't understand is skipped silently
/// rather than surfaced as an error — a user's config often has many
/// directives (ForwardAgent, LogLevel, etc.) that are irrelevant to
/// picking a host to import.
///
/// Desktop-only. Android has no meaningful `~/.ssh/config` path and its
/// import story goes through profile export/import instead — we return a
/// clear message rather than pretending to look somewhere.
#[tauri::command]
async fn parse_ssh_config(path: Option<String>) -> Result<Vec<ImportedHost>, String> {
    #[cfg(target_os = "android")]
    {
        let _ = path;
        Err("Not available on Android — use export/import instead".into())
    }
    #[cfg(not(target_os = "android"))]
    {
        // One in-progress Host block. We accumulate resolved fields as we
        // walk the file and emit one ImportedHost per alias when the block
        // ends (either the next `Host` line or EOF).
        struct Block {
            aliases: Vec<String>,
            hostname: Option<String>,
            port: Option<u16>,
            user: Option<String>,
            identity_file: Option<String>,
            proxy_jump: Option<String>,
        }

        // Split `Directive value...` into (directive, rest). OpenSSH treats
        // `=` and whitespace as equivalent separators between the directive
        // name and its argument, so both `Port 2222` and `Port=2222` parse
        // the same way.
        fn split_directive(line: &str) -> (&str, &str) {
            match line.find(|c: char| c.is_whitespace() || c == '=') {
                Some(i) => {
                    let key = &line[..i];
                    let rest = line[i..]
                        .trim_start_matches(|c: char| c.is_whitespace() || c == '=');
                    (key, rest)
                }
                None => (line, ""),
            }
        }

        // Emit one ImportedHost per non-wildcard alias in the block. Wildcard
        // (`*` / `?`) and negation (`!prefix`) aliases are OpenSSH's template
        // mechanism — they don't correspond to a single server the user
        // would want as a row, so we skip them silently.
        fn flush_block(b: &Block, out: &mut Vec<ImportedHost>) {
            for alias in &b.aliases {
                if alias.contains('*') || alias.contains('?') || alias.starts_with('!') {
                    continue;
                }
                out.push(ImportedHost {
                    host_alias: alias.clone(),
                    hostname: b.hostname.clone().unwrap_or_else(|| alias.clone()),
                    port: b.port.unwrap_or(22),
                    user: b.user.clone().unwrap_or_default(),
                    identity_file: b.identity_file.clone(),
                    proxy_jump: b.proxy_jump.clone(),
                });
            }
        }

        let config_path: PathBuf = match path {
            Some(p) if !p.trim().is_empty() => PathBuf::from(p),
            _ => directories::UserDirs::new()
                .map(|u| u.home_dir().join(".ssh").join("config"))
                .ok_or_else(|| "Could not resolve home directory".to_string())?,
        };

        // Read on a blocking thread, not the UI one (a config on a stuck NFS
        // mount would otherwise freeze the window). Only a regular file up to
        // 1 MiB — a FIFO planted at ~/.ssh/config would hang the read forever,
        // and a real config is a few KB.
        let read_path = config_path.clone();
        let contents = tokio::task::spawn_blocking(move || -> Result<String, String> {
            let meta = fs::metadata(&read_path)
                .map_err(|e| format!("SSH config file not found at {}: {}", read_path.display(), e))?;
            if !meta.is_file() {
                return Err(format!("{} isn't a regular file.", read_path.display()));
            }
            if meta.len() > 1024 * 1024 {
                return Err(format!("{} is too large to be an SSH config.", read_path.display()));
            }
            fs::read_to_string(&read_path).map_err(|e| format!("Failed to read {}: {}", read_path.display(), e))
        })
        .await
        .map_err(|e| format!("Failed to read SSH config: {e}"))??;

        let mut out: Vec<ImportedHost> = Vec::new();
        let mut cur: Option<Block> = None;

        for raw_line in contents.lines() {
            let line = raw_line.trim();
            if line.is_empty() || line.starts_with('#') {
                continue;
            }
            let (key, rest) = split_directive(line);
            let key_lc = key.to_ascii_lowercase();
            match key_lc.as_str() {
                "host" => {
                    // Close out the previous block before starting a new one.
                    if let Some(prev) = cur.take() {
                        flush_block(&prev, &mut out);
                    }
                    let mut b = Block {
                        aliases: Vec::new(),
                        hostname: None,
                        port: None,
                        user: None,
                        identity_file: None,
                        proxy_jump: None,
                    };
                    for a in rest.split_whitespace() {
                        b.aliases.push(a.trim_matches('"').to_string());
                    }
                    cur = Some(b);
                }
                "hostname" | "port" | "user" | "identityfile" | "proxyjump" => {
                    if let Some(b) = cur.as_mut() {
                        let val = rest.trim().trim_matches('"');
                        if val.is_empty() {
                            continue;
                        }
                        match key_lc.as_str() {
                            "hostname" => b.hostname = Some(val.to_string()),
                            "port" => {
                                if let Ok(p) = val.parse::<u16>() {
                                    b.port = Some(p);
                                }
                            }
                            "user" => b.user = Some(val.to_string()),
                            "identityfile" => b.identity_file = Some(val.to_string()),
                            "proxyjump" => b.proxy_jump = Some(val.to_string()),
                            _ => {}
                        }
                    }
                }
                // Include chains, Match blocks, and every other directive
                // are v1-out-of-scope. Ignoring them keeps the parser
                // predictable for the "flat list of hosts" use case.
                _ => {}
            }
        }
        if let Some(last) = cur.take() {
            flush_block(&last, &mut out);
        }

        Ok(out)
    }
}

/// Parse a blob of text pasted from another SSH client's export and return
/// the same `ImportedHost` shape as `parse_ssh_config`. Auto-detects the
/// format so the frontend only needs one "Paste your export" text area
/// instead of a picker-per-format:
///
///   • Windows Regedit `.reg` export of PuTTY sessions
///     (`HKEY_CURRENT_USER\Software\SimonTatham\PuTTY\Sessions\...`) —
///     detected by the file's `Windows Registry Editor` header. Each
///     `[HKEY_...\Sessions\<name>]` block becomes one host; HostName,
///     PortNumber, and UserName are decoded from the `"key"=dword:` /
///     `"key"="value"` entries. Percent-decoded so aliases with spaces
///     ("My Prod Box") round-trip.
///
///   • JSON array — either
///     `[{"name":"foo","host":"1.2.3.4","port":22,"user":"root"}, …]`
///     or the Termius-style
///     `[{"label":"foo","address":"1.2.3.4","port":22,"username":"root"}, …]`.
///     Any missing field defaults to the OpenSSH convention.
///
///   • MobaXterm `.mxtsessions` export — an INI file with one session per
///     line under `[Bookmarks]`, `[Bookmarks_1]`, … sections (see
///     `parse_mobaxterm_sessions`). SSH sessions only.
///
/// Anything the parser can't recognise is a soft-fail: the returned
/// `Vec` is what we DID find, the message describes what got skipped.
/// The command is desktop+Android — no filesystem access, just text.
#[tauri::command]
fn parse_client_import(text: String) -> Result<Vec<ImportedHost>, String> {
    let trimmed = text.trim();
    if trimmed.is_empty() {
        return Err("Paste an exported session block first.".into());
    }

    // ── MobaXterm .mxtsessions. Checked before JSON: the file starts with
    //    its `[Bookmarks]` section header, which starts with `[` like a JSON
    //    array does, so it used to fail as broken JSON (#25).
    if trimmed.lines().any(|l| l.trim_start().starts_with("[Bookmarks")) {
        return parse_mobaxterm_sessions(trimmed);
    }

    // ── JSON array — the most permissive path. Two
    //    supported field-name variants (see doc comment). We accept a
    //    generic `serde_json::Value` array rather than a strict struct
    //    so a stray extra field doesn't kill the whole import.
    if trimmed.starts_with('[') {
        let arr: Vec<serde_json::Value> = serde_json::from_str(trimmed)
            .map_err(|e| format!("JSON parse failed: {}", e))?;
        let mut out = Vec::with_capacity(arr.len());
        for (i, v) in arr.iter().enumerate() {
            let obj = v.as_object().ok_or_else(|| {
                format!("Entry #{} is not an object", i + 1)
            })?;
            let get_str = |keys: &[&str]| -> Option<String> {
                for k in keys {
                    if let Some(s) = obj.get(*k).and_then(|x| x.as_str()) {
                        if !s.is_empty() { return Some(s.to_string()); }
                    }
                }
                None
            };
            let get_u16 = |keys: &[&str]| -> Option<u16> {
                for k in keys {
                    if let Some(n) = obj.get(*k).and_then(|x| x.as_u64()) {
                        return u16::try_from(n).ok();
                    }
                    if let Some(s) = obj.get(*k).and_then(|x| x.as_str()) {
                        if let Ok(p) = s.parse::<u16>() { return Some(p); }
                    }
                }
                None
            };
            let alias = get_str(&["name", "label", "title", "alias", "host_alias"])
                .or_else(|| get_str(&["host", "hostname", "address"]))
                .unwrap_or_else(|| format!("imported-{}", i + 1));
            let hostname = get_str(&["host", "hostname", "address"]).unwrap_or_else(|| alias.clone());
            let port = get_u16(&["port"]).unwrap_or(22);
            let user = get_str(&["user", "username"]).unwrap_or_default();
            let identity_file = get_str(&["identity_file", "identityFile", "key", "privateKey"]);
            let proxy_jump = get_str(&["proxy_jump", "proxyJump", "jump"]);
            out.push(ImportedHost {
                host_alias: alias,
                hostname,
                port,
                user,
                identity_file,
                proxy_jump,
            });
        }
        if out.is_empty() {
            return Err("JSON array was valid but contained no entries.".into());
        }
        return Ok(out);
    }

    // ── PuTTY .reg export
    if trimmed.to_ascii_lowercase().contains("windows registry editor")
        || trimmed.contains("[HKEY_CURRENT_USER\\Software\\SimonTatham\\PuTTY\\Sessions")
        || trimmed.contains("[HKEY_USERS\\") && trimmed.contains("SimonTatham\\PuTTY\\Sessions")
    {
        return parse_putty_reg(trimmed);
    }

    Err("Unrecognised format — paste a JSON array, a PuTTY .reg export, or a MobaXterm .mxtsessions block.".into())
}

/// Parse `regedit /e` output of PuTTY's session key. The format is
/// deterministic (one `[...]` header line per session, then `"key"=type:val`
/// lines) so a line-oriented walk covers it. We only pull the three fields
/// that translate to a Submarine row: HostName, PortNumber, UserName.
/// Session-name percent-escapes (%20 for space, etc.) are undone so the
/// alias reads naturally.
fn parse_putty_reg(text: &str) -> Result<Vec<ImportedHost>, String> {
    let mut out: Vec<ImportedHost> = Vec::new();
    let mut current: Option<(String, String, u16, String)> = None; // (alias, host, port, user)
    let close = |cur: &mut Option<(String, String, u16, String)>, out: &mut Vec<ImportedHost>| {
        if let Some((alias, host, port, user)) = cur.take() {
            if !host.is_empty() || !alias.is_empty() {
                out.push(ImportedHost {
                    host_alias: alias.clone(),
                    hostname: if host.is_empty() { alias } else { host },
                    port: if port == 0 { 22 } else { port },
                    user,
                    identity_file: None,
                    proxy_jump: None,
                });
            }
        }
    };
    for raw in text.lines() {
        let line = raw.trim();
        if line.is_empty() { continue; }
        if line.starts_with('[') && line.ends_with(']') {
            close(&mut current, &mut out);
            // Only sessions — skip other PuTTY keys (SshHostKeys, Jumplist).
            let inner = &line[1..line.len() - 1];
            let Some(idx) = inner.rfind("\\Sessions\\") else { continue; };
            let name_raw = &inner[idx + "\\Sessions\\".len()..];
            let name = putty_unescape(name_raw);
            if name.is_empty() { continue; }
            current = Some((name, String::new(), 0, String::new()));
            continue;
        }
        let Some((key, val_raw)) = line.split_once('=') else { continue; };
        let Some(cur) = current.as_mut() else { continue; };
        let key = key.trim().trim_matches('"');
        let val = val_raw.trim();
        match key {
            "HostName" => {
                if let Some(v) = strip_reg_string(val) { cur.1 = v; }
            }
            "PortNumber" => {
                if let Some(n) = strip_reg_dword(val) {
                    if let Ok(p) = u16::try_from(n) { cur.2 = p; }
                }
            }
            "UserName" => {
                if let Some(v) = strip_reg_string(val) { cur.3 = v; }
            }
            _ => {}
        }
    }
    close(&mut current, &mut out);
    if out.is_empty() {
        return Err("No PuTTY sessions found in the pasted text.".into());
    }
    Ok(out)
}

/// PuTTY registry keys with special characters (space, backslash, non-
/// ASCII) are percent-escaped in the exported name. `%20` → space,
/// `%25` → `%`. Anything else is passed through as-is. Not a full URL
/// decoder — PuTTY's escape table is narrower.
fn putty_unescape(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    let bytes = s.as_bytes();
    let mut i = 0;
    while i < bytes.len() {
        // Only treat `%HH` as an escape when both following bytes are ASCII
        // hex digits. The is_ascii_hexdigit guard also keeps the `&s[..]`
        // slice on char boundaries — without it, a `%` before a multi-byte
        // UTF-8 char (e.g. `%€`) would slice mid-codepoint and panic.
        if bytes[i] == b'%'
            && i + 2 < bytes.len()
            && bytes[i + 1].is_ascii_hexdigit()
            && bytes[i + 2].is_ascii_hexdigit()
        {
            let hex = &s[i + 1..i + 3];
            if let Ok(n) = u8::from_str_radix(hex, 16) {
                out.push(n as char);
                i += 3;
                continue;
            }
        }
        out.push(bytes[i] as char);
        i += 1;
    }
    out
}

/// `.reg` string entries look like `"HostName"="1.2.3.4"`. Strip the
/// surrounding quotes and unescape the two sequences .reg uses (`\\` and
/// `\"`). Returns None if the value isn't a quoted string.
fn strip_reg_string(val: &str) -> Option<String> {
    let s = val.trim();
    if !s.starts_with('"') || !s.ends_with('"') || s.len() < 2 { return None; }
    let inner = &s[1..s.len() - 1];
    let mut out = String::with_capacity(inner.len());
    let mut chars = inner.chars();
    while let Some(c) = chars.next() {
        if c == '\\' {
            if let Some(next) = chars.next() { out.push(next); }
        } else {
            out.push(c);
        }
    }
    Some(out)
}

/// `.reg` DWORD entries look like `"PortNumber"=dword:00000016`. The
/// `dword:` prefix is followed by exactly 8 hex chars. Anything else
/// (missing prefix, non-hex, wrong length) returns None so the caller
/// can leave the field at its default rather than propagating an error.
fn strip_reg_dword(val: &str) -> Option<u32> {
    let s = val.trim();
    let stripped = s.strip_prefix("dword:")?;
    u32::from_str_radix(stripped, 16).ok()
}

/// Parse a MobaXterm `.mxtsessions` export. It's an INI file: each section
/// (`[Bookmarks]`, `[Bookmarks_1]`, …) is a folder, with `SubRep=` its path
/// and `ImgNum=` its icon, and every other line is one session:
///
/// `<name>= #<icon>#<settings>#<terminal settings>#…`
///
/// `<settings>` is `%`-separated and starts with the session type (0 = SSH,
/// 4 = RDP, 5 = VNC, 7 = SFTP, …). For SSH, field 1 is the host, 2 the port,
/// 3 the user (`<default>` = none set), 8/9/10 the jump hosts' names, ports
/// and users (`__PIPE__` between hops) and 14 the key file, with its drive
/// written as `_CurrentDrive_`. The icon is the user's pick, so it says
/// nothing about the type. Only SSH sessions are imported.
fn parse_mobaxterm_sessions(text: &str) -> Result<Vec<ImportedHost>, String> {
    const SSH: &str = "0";
    let mut out: Vec<ImportedHost> = Vec::new();
    // Session names repeat across folders; the import list keys rows by name.
    let mut names: std::collections::HashSet<String> = std::collections::HashSet::new();
    let mut in_bookmarks = false;
    for raw in text.lines() {
        let line = raw.trim();
        if line.is_empty() || line.starts_with(';') { continue; }
        if line.starts_with('[') {
            in_bookmarks = line.starts_with("[Bookmarks");
            continue;
        }
        if !in_bookmarks { continue; }
        let Some((name, value)) = line.split_once('=') else { continue; };
        let name = name.trim();
        if name == "SubRep" || name == "ImgNum" { continue; }
        let mut blocks = value.trim().split('#');
        let (Some(_reconnect), Some(_icon), Some(settings)) = (blocks.next(), blocks.next(), blocks.next()) else {
            continue;
        };
        let fields: Vec<&str> = settings.split('%').map(str::trim).collect();
        let field = |i: usize| fields.get(i).copied().unwrap_or("");
        if field(0) != SSH { continue; }
        let hostname = field(1);
        if hostname.is_empty() { continue; }
        let port = field(2).parse::<u16>().ok().filter(|p| *p != 0).unwrap_or(22);
        let user = match field(3) {
            "<default>" => "",
            u => u,
        };
        // `_CurrentDrive_` is the drive MobaXterm ran from — nearly always C.
        // A key file that isn't there is skipped by the import, not fatal.
        let identity_file = Some(field(14))
            .filter(|p| !p.is_empty())
            .map(|p| p.replace("_CurrentDrive_", "C"));
        let mut alias = name.to_string();
        let mut n = 2;
        while !names.insert(alias.clone()) {
            alias = format!("{} ({})", name, n);
            n += 1;
        }
        out.push(ImportedHost {
            host_alias: alias,
            hostname: hostname.to_string(),
            port,
            user: user.to_string(),
            identity_file,
            proxy_jump: mobaxterm_jump_hosts(field(8), field(9), field(10)),
        });
    }
    if out.is_empty() {
        return Err("No MobaXterm SSH sessions found in the pasted text.".into());
    }
    Ok(out)
}

/// MobaXterm's jump hosts (one `__PIPE__`-separated list each for names,
/// ports and users) as an OpenSSH ProxyJump value: `user@host:port,…`.
fn mobaxterm_jump_hosts(hosts: &str, ports: &str, users: &str) -> Option<String> {
    let list = |s: &str| s.split("__PIPE__").map(str::trim).map(String::from).collect::<Vec<_>>();
    let (ports, users) = (list(ports), list(users));
    let hops: Vec<String> = list(hosts)
        .iter()
        .enumerate()
        .filter(|(_, host)| !host.is_empty())
        .map(|(i, host)| {
            let user = users.get(i).filter(|u| !u.is_empty() && u.as_str() != "<default>");
            let port = ports.get(i).and_then(|p| p.parse::<u16>().ok()).filter(|p| *p != 0 && *p != 22);
            let mut hop = String::new();
            if let Some(u) = user {
                hop.push_str(u);
                hop.push('@');
            }
            hop.push_str(host);
            if let Some(p) = port {
                hop.push_str(&format!(":{}", p));
            }
            hop
        })
        .collect();
    (!hops.is_empty()).then(|| hops.join(","))
}

#[cfg(test)]
mod client_import_tests {
    use super::parse_client_import;

    /// Lines as MobaXterm writes them: a blank before the first `#`, the
    /// icon, the `%`-separated settings, then the terminal settings.
    const TERMINAL: &str = "#MobaFont%10%0%0%-1%15%236,236,236%30,30,30%180,180,192%0%-1%0%%xterm%-1%-1%_Std_Colors_0_%80%24%0%1%-1%<none>%%0%0%-1%-1#0# #-1";

    fn session(name: &str, icon: u32, settings: &str) -> String {
        format!("{}= #{}#{}{}", name, icon, settings, TERMINAL)
    }

    fn export(lines: &[String]) -> String {
        let mut text = String::from("[Bookmarks]\r\nSubRep=\r\nImgNum=42\r\n");
        for l in lines {
            text.push_str(l);
            text.push_str("\r\n");
        }
        text
    }

    #[test]
    fn a_mobaxterm_export_is_not_taken_for_broken_json() {
        let text = export(&[session("web01", 109, "0%10.0.0.5%22%admin%%-1%-1%%%%%0%0%0%%%-1%0%0%0%%1080%%0%0%1")]);
        let hosts = parse_client_import(text).expect("the #25 export must import");
        assert_eq!(hosts.len(), 1);
        assert_eq!((hosts[0].host_alias.as_str(), hosts[0].hostname.as_str(), hosts[0].port, hosts[0].user.as_str()), ("web01", "10.0.0.5", 22, "admin"));
    }

    #[test]
    fn ssh_sessions_import_whatever_their_icon_and_other_types_are_skipped() {
        let text = export(&[
            session("default icon", 109, "0%a.example%2222%alice%%-1%-1%%%%%0%0%0%%%-1"),
            session("debian icon", 149, "0%b.example%22%bob%%0%-1%%%%%0%0%0%%%-1"),
            session("desktop", 91, "4%c.example%3389%carol%%-1%0%0"),
            session("files", 140, "7%d.example%22%dave%-1%0%%0%0%%0"),
            session("vnc", 128, "5%e.example%5900%%-1%0"),
            "web02=#109#0%f.example%22%frank%%-1%-1%%%%%0%0%0%%%-1".to_string(),
        ]);
        let hosts = parse_client_import(text).unwrap();
        let got: Vec<(&str, &str, u16)> = hosts.iter().map(|h| (h.host_alias.as_str(), h.hostname.as_str(), h.port)).collect();
        assert_eq!(got, vec![("default icon", "a.example", 2222), ("debian icon", "b.example", 22), ("web02", "f.example", 22)]);
    }

    #[test]
    fn default_user_key_file_and_jump_hosts_carry_over() {
        let text = export(&[
            session("no user", 109, "0%g.example%22%<default>%%-1%-1%%%%%0%0%0%%%-1"),
            session("with key", 109, r"0%h.example%22%root%%-1%-1%%%%%0%0%0%_CurrentDrive_:\keys\id_ed25519%%-1"),
            session("behind bastion", 109, "0%i.example%22%ops%%-1%-1%%bastion.example__PIPE__inner.example%2222__PIPE__22%jump__PIPE__<default>%0%0%0%%%-1"),
        ]);
        let hosts = parse_client_import(text).unwrap();
        assert_eq!(hosts[0].user, "");
        assert_eq!(hosts[0].identity_file, None);
        assert_eq!(hosts[1].identity_file.as_deref(), Some(r"C:\keys\id_ed25519"));
        assert_eq!(hosts[1].proxy_jump, None);
        assert_eq!(hosts[2].proxy_jump.as_deref(), Some("jump@bastion.example:2222,inner.example"));
    }

    #[test]
    fn a_name_used_in_two_folders_stays_two_rows() {
        let mut text = export(&[session("web", 109, "0%a.example%22%u%%-1%-1%%%%%0%0%0%%%-1")]);
        text.push_str("[Bookmarks_1]\r\nSubRep=Prod\r\nImgNum=41\r\n");
        text.push_str(&session("web", 109, "0%b.example%22%u%%-1%-1%%%%%0%0%0%%%-1"));
        let hosts = parse_client_import(text).unwrap();
        let names: Vec<&str> = hosts.iter().map(|h| h.host_alias.as_str()).collect();
        assert_eq!(names, vec!["web", "web (2)"]);
    }

    #[test]
    fn an_export_with_no_ssh_session_says_so() {
        let text = export(&[session("desktop", 91, "4%c.example%3389%carol%%-1%0%0")]);
        let err = parse_client_import(text).err().expect("an RDP-only export must be refused");
        assert!(err.contains("No MobaXterm SSH sessions"), "{err}");
    }

    #[test]
    fn json_arrays_still_import() {
        let hosts = parse_client_import("\n  [ {\"name\": \"box\", \"host\": \"j.example\", \"port\": 2200, \"user\": \"u\"} ]".into()).unwrap();
        assert_eq!((hosts[0].host_alias.as_str(), hosts[0].hostname.as_str(), hosts[0].port), ("box", "j.example", 2200));
        let err = parse_client_import("[ {\"name\": ".into()).err().expect("broken JSON must be refused");
        assert!(err.starts_with("JSON parse failed"), "{err}");
    }
}

/// True when a single SFTP directory-entry name is a plain, safe filename —
/// i.e. one that can be joined onto a local root without escaping it.
///
/// `read_dir` entry names come straight off the SFTP wire, so a malicious or
/// compromised server can return a name that contains path separators or `..`
/// (e.g. `../../../.config/autostart/x.desktop`, or `..\..\Startup\x.bat`).
/// Joining such a name onto the download root resolves OUTSIDE it — a zip-slip
/// arbitrary-write primitive. A genuine filesystem entry name is always a
/// single component: it never contains `/` (the POSIX/SFTP separator) or a
/// NUL, and is never `.`/`..`. Callers skip (or refuse) a rejected entry.
///
/// On a WINDOWS client more names escape or misbehave, because Win32
/// reinterprets them:
///   * `\` is a path separator there (a POSIX name may legally contain it).
///   * a drive marker — `C:evil` is drive-RELATIVE, so `root.join("C:evil")`
///     discards `root` and resolves against the process CWD; `a:b` likewise.
///     (A `:` elsewhere also opens an NTFS alternate data stream.)
///   * reserved device names (`CON`, `NUL`, `COM1`, `LPT1`, `CONIN$`, …, with
///     or without an extension) open a device, not a file under `root`.
///   * a trailing `.` or space is silently stripped, aliasing one name to
///     another and defeating an exact-name overwrite check.
///
/// These are all legal in a POSIX filename, so they are only barred when this
/// build is the Windows client that would misinterpret them — a POSIX client
/// downloading a file literally named `a:b` or `a\b` is fine.
pub(crate) fn is_safe_dir_entry_name(name: &str) -> bool {
    if name.is_empty()
        || name == "."
        || name == ".."
        || name.contains('/')
        || name.contains('\0')
    {
        return false;
    }
    #[cfg(windows)]
    {
        if name.contains('\\') || name.contains(':') {
            return false;
        }
        if matches!(name.chars().last(), Some('.') | Some(' ')) {
            return false;
        }
        // Compare the part before the first dot (spaces before the dot are
        // dropped too) against the reserved set, case-insensitively: `NUL`,
        // `nul.txt`, `COM1.log` and `AUX .c` are all devices.
        let stem = name.split('.').next().unwrap_or(name).trim_end_matches(' ');
        const RESERVED: &[&str] = &[
            "CON", "PRN", "AUX", "NUL", "CONIN$", "CONOUT$",
            "COM0", "COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9",
            "COM¹", "COM²", "COM³",
            "LPT0", "LPT1", "LPT2", "LPT3", "LPT4", "LPT5", "LPT6", "LPT7", "LPT8", "LPT9",
            "LPT¹", "LPT²", "LPT³",
        ];
        if RESERVED.iter().any(|r| stem.eq_ignore_ascii_case(r)) {
            return false;
        }
    }
    true
}

/// Check a single-file download destination before anything touches it. The
/// frontend builds `local_path` as `<chosen folder><sep><remote name>`, and the
/// remote name is the only part the server controls: it must be one plain
/// component this OS can store, and really be the last component of
/// `local_path`. Everything before it is the user's own folder, so a `..` they
/// typed there is fine — guard_local_path resolves it.
fn validate_download_target(local_path: &str, remote_path: &str) -> Result<(), String> {
    let name = remote_path.rsplit('/').next().unwrap_or("");
    if !is_safe_dir_entry_name(name) {
        return Err(format!(
            "\"{}\" can't be saved here: its name isn't a valid file name on this computer.",
            name
        ));
    }
    let last = std::path::Path::new(local_path).file_name().and_then(|n| n.to_str());
    if last != Some(name) {
        return Err(format!(
            "Refusing a download destination that doesn't end in the file's name: {}",
            local_path
        ));
    }
    Ok(())
}

/// Check where a folder download goes, `{parent}/{name}`, before anything is
/// created there. `parent` is the folder the user is in and has to be a full
/// path: joined onto anything else (`C:` without a separator, an empty
/// string), the folder would be created under wherever the app was started
/// from. What gets written is `parent/name`, so that is the path the policy
/// is asked about (in `/var`, a folder named `log` lands on a system path).
/// The parent may be a drive's root: a root is refused as something to write
/// over or remove, not as the place a folder is put in.
fn check_download_dir_target(parent: &str, name: &str) -> Result<(), String> {
    let parent_dir = std::path::Path::new(parent);
    if !parent_dir.is_absolute() {
        return Err(format!("The folder to download into isn't a full path: {}", parent));
    }
    guard_local_path(&parent_dir.join(name).to_string_lossy(), true)?;
    Ok(())
}

/// The note on a finished folder-download card when the walk skipped names
/// this computer can't store (see is_safe_dir_entry_name).
fn skipped_names_note(skipped: u64) -> Option<String> {
    match skipped {
        0 => None,
        1 => Some("1 item skipped: its name isn't a valid file name on this computer".into()),
        n => Some(format!(
            "{} items skipped: their names aren't valid file names on this computer",
            n
        )),
    }
}

/// A local path the way it is shown and handed back to us. On Windows,
/// `canonicalize` answers in the verbatim form (`\\?\C:\Users\me`), which is
/// not what anyone types or expects to read in the path bar. The prefix is
/// dropped when the plain form names the same thing. It is kept when only the
/// verbatim form can: a component Win32 would read differently (a reserved
/// name such as `nul`, a trailing dot or space), a path too long for the
/// plain form, or anything that is not a drive or a share.
fn display_path(path: &std::path::Path) -> String {
    let full = path.to_string_lossy();
    #[cfg(windows)]
    {
        let (plain, below_root) = if let Some(rest) = full.strip_prefix(r"\\?\UNC\") {
            (format!(r"\\{}", rest), rest)
        } else if let Some(rest) = full.strip_prefix(r"\\?\") {
            let b = rest.as_bytes();
            if b.len() < 3 || !b[0].is_ascii_alphabetic() || b[1] != b':' || b[2] != b'\\' {
                return full.into_owned();
            }
            (rest.to_string(), &rest[3..])
        } else {
            return full.into_owned();
        };
        let ordinary = below_root.split('\\').filter(|c| !c.is_empty()).all(is_safe_dir_entry_name);
        // Windows counts a path's length in UTF-16 units.
        if ordinary && plain.encode_utf16().count() < 248 {
            return plain;
        }
    }
    full.into_owned()
}

/// The local paths the app writes to are full paths: from a listing, the
/// folder picker or the user's own folder. A relative one (`name`, or on
/// Windows `G:name` and `\name`) would be resolved against whatever folder the
/// app happens to run in, so it is refused.
fn require_full_path(p: &std::path::Path) -> Result<(), String> {
    if p.is_absolute() {
        Ok(())
    } else {
        Err(format!("不是完整路径：{}", p.display()))
    }
}

/// Defense-in-depth guard for the local-FS commands the frontend can invoke.
/// We can't lock everything down to a sandbox (the local file browser
/// legitimately needs to roam the user's disk to pick uploads), but we CAN
/// refuse the obviously destructive cases: the filesystem root, OS system
/// directories, and unresolvable paths. If the renderer is ever compromised
/// (XSS via terminal output, a future feature, etc.) this stops
/// `local_remove("C:\\")` cold.
///
/// It guards what changes things. Looking at a folder goes through
/// `readable_local_dir`, which has no such limits.
fn guard_local_path(path: &str, allow_nonexistent: bool) -> Result<std::path::PathBuf, String> {
    let p = std::path::Path::new(path);
    require_full_path(p)?;
    let canonical = match p.canonicalize() {
        Ok(c) => c,
        Err(e) => {
            if allow_nonexistent {
                let parent = p.parent()
                    .ok_or_else(|| format!("无效路径：{}", path))?;
                let canon_parent = parent.canonicalize()
                    .map_err(|e| format!("无效的父目录：{}", e))?;
                let file = p.file_name()
                    .ok_or_else(|| format!("无效路径：{}", path))?;
                canon_parent.join(file)
            } else {
                return Err(format!("无效路径：{}", e));
            }
        }
    };
    check_local_path_policy(canonical)
}

/// Like `guard_local_path`, but the LAST component is not resolved — for
/// operations on the directory entry itself (delete, rename). Canonicalising
/// a symlink or junction resolves it to its target, so deleting or renaming a
/// link would hit the file/folder it points to (and a dangling link couldn't
/// be removed at all). The parent is still canonicalised and the same
/// system-path policy applies.
fn guard_local_path_nofollow(path: &str, must_exist: bool) -> Result<std::path::PathBuf, String> {
    let p = std::path::Path::new(path);
    require_full_path(p)?;
    let file = p.file_name().ok_or_else(|| format!("无效路径：{}", path))?;
    let parent = p
        .parent()
        .filter(|d| !d.as_os_str().is_empty())
        .ok_or_else(|| format!("无效路径：{}", path))?;
    let canon_parent = parent
        .canonicalize()
        .map_err(|e| format!("无效的父目录：{}", e))?;
    let full = canon_parent.join(file);
    if must_exist {
        std::fs::symlink_metadata(&full).map_err(|e| format!("无效路径：{}", e))?;
    }
    check_local_path_policy(full)
}

/// The system folders `check_local_path_policy` refuses, as lowercase paths
/// with `/`. On Windows they are also read from the environment (`var` looks
/// one up): Windows and its program folders aren't always on drive C. On
/// macOS `/etc` and `/var` are links into `/private`, and a checked path is
/// already resolved, so the folders are listed there too.
fn system_dirs(var: impl Fn(&str) -> Option<String>) -> Vec<String> {
    let fixed: &[&str] = if cfg!(windows) {
        &["c:/windows", "c:/program files", "c:/program files (x86)", "c:/programdata"]
    } else {
        &[
            "/etc", "/usr", "/bin", "/sbin", "/lib", "/lib64", "/boot",
            "/sys", "/proc", "/dev", "/var/log", "/var/run", "/root",
            "/private/etc", "/private/var/log", "/private/var/run", "/system",
        ]
    };
    let mut dirs: Vec<String> = fixed.iter().map(|dir| dir.to_string()).collect();
    if cfg!(windows) {
        for name in ["SystemRoot", "windir", "ProgramFiles", "ProgramFiles(x86)", "ProgramW6432", "ProgramData"] {
            let Some(value) = var(name) else { continue };
            let dir = value.trim().to_lowercase().replace('\\', "/");
            let dir = dir.trim_end_matches('/');
            // Only a folder below a drive's root: `x:/…`. Anything else (a
            // blank, a relative path, the root itself) would refuse too much.
            let b = dir.as_bytes();
            if b.len() > 3 && b[0].is_ascii_alphabetic() && b[1] == b':' && b[2] == b'/' && !dirs.iter().any(|d| d == dir) {
                dirs.push(dir.to_string());
            }
        }
    }
    dirs
}

fn check_local_path_policy(canonical: std::path::PathBuf) -> Result<std::path::PathBuf, String> {
    // Refuse the filesystem root itself (`/`, `C:\`, etc.).
    if canonical.parent().is_none() {
        return Err(format!("Refusing to operate on filesystem root: {}", display_path(&canonical)));
    }

    let mut canon_norm = canonical.to_string_lossy().to_lowercase().replace('\\', "/");
    // On Windows, std::fs::canonicalize returns a `\\?\`-prefixed *verbatim*
    // path, e.g. `\\?\C:\Windows\System32`. After the `\` -> `/` normalization
    // above that becomes `//?/c:/windows/system32`, which never matches the
    // blocklist entries `c:/windows`, `c:/program files`, etc. — silently
    // defeating this guard for every Windows system directory. Strip the
    // verbatim prefix (and its `\\?\UNC\` variant for UNC paths) so the
    // subsequent prefix match sees a normal drive-letter path. Also strip the
    // NT-device `\\.\` prefix on the off chance a caller hands us one.
    if let Some(rest) = canon_norm.strip_prefix("//?/unc/") {
        canon_norm = format!("//{}", rest);
    } else if let Some(rest) = canon_norm.strip_prefix("//?/") {
        canon_norm = rest.to_string();
    } else if let Some(rest) = canon_norm.strip_prefix("//./") {
        canon_norm = rest.to_string();
    }
    // Trim trailing slash for clean prefix matches.
    let canon_norm = canon_norm.trim_end_matches('/').to_string();

    let under = |dir: &str| canon_norm == dir || canon_norm.starts_with(&format!("{}/", dir));
    if system_dirs(|var| std::env::var(var).ok()).iter().any(|dir| under(dir)) {
        return Err(format!("拒绝对系统路径执行操作：{}", display_path(&canonical)));
    }
    // Every drive has these two, not just drive C.
    if cfg!(windows) && canon_norm.as_bytes().get(1) == Some(&b':') {
        let below_drive = &canon_norm[2..];
        if ["/system volume information", "/$recycle.bin"]
            .iter()
            .any(|dir| below_drive == *dir || below_drive.starts_with(&format!("{}/", dir)))
        {
            return Err(format!("拒绝对系统路径执行操作：{}", display_path(&canonical)));
        }
    }

    // Auto-run / login-persistence locations. Unlike the fixed system-dir
    // prefixes above, these sit inside the per-user profile
    // (C:\Users\<name>\AppData\..., ~/Library/..., ~/.config/...) so no static
    // prefix catches them — match on a path tail instead. Blocking them stops
    // a download destination (or any local op) from dropping an executable
    // into a folder the OS auto-runs at next login. The markers are
    // platform-specific strings that simply never match on the wrong OS, so a
    // single unconditional loop is fine.
    const PERSIST_MARKERS: &[&str] = &[
        "/start menu/programs/startup",        // Windows Startup (per-user & all-users)
        "/appdata/roaming/microsoft/windows",  // Windows autorun / machine-managed
        "/appdata/local/microsoft/windows",
        "/library/launchagents",               // macOS per-user launch agents
        "/library/launchdaemons",              // macOS launch daemons
        "/.config/autostart",                  // Linux XDG autostart
    ];
    for marker in PERSIST_MARKERS {
        if canon_norm.contains(marker) {
            return Err(format!("Refusing operation on auto-run / persistence path: {}", display_path(&canonical)));
        }
    }

    Ok(canonical)
}

#[tauri::command]
async fn local_create_dir(path: String) -> Result<(), String> {
    let safe = guard_local_path(&path, true)?;
    std::fs::create_dir_all(&safe).map_err(|e| format!("Failed to create directory: {}", e))
}

/// Remove a symlink / junction itself, never what it points to. Windows
/// directory links and junctions go through RemoveDirectory; everything else
/// (all links on Unix) is a plain unlink.
fn remove_link_itself(p: &std::path::Path, ft: &std::fs::FileType) -> std::io::Result<()> {
    #[cfg(windows)]
    {
        use std::os::windows::fs::FileTypeExt;
        if ft.is_symlink_dir() {
            return std::fs::remove_dir(p);
        }
    }
    let _ = ft;
    std::fs::remove_file(p)
}

#[tauri::command]
async fn local_remove(path: String, is_dir: bool) -> Result<(), String> {
    // What's on disk decides, not the caller's hint: a link must only ever be
    // unlinked, whatever the UI thought the row was.
    let _ = is_dir;
    let safe = guard_local_path_nofollow(&path, true)?;
    let ft = std::fs::symlink_metadata(&safe)
        .map_err(|e| format!("Failed to remove: {}", e))?
        .file_type();
    if ft.is_symlink() {
        remove_link_itself(&safe, &ft).map_err(|e| format!("Failed to remove link: {}", e))
    } else if ft.is_dir() {
        // std's remove_dir_all doesn't follow links found inside the tree.
        std::fs::remove_dir_all(&safe).map_err(|e| format!("Failed to remove directory: {}", e))
    } else {
        std::fs::remove_file(&safe).map_err(|e| format!("Failed to remove file: {}", e))
    }
}

#[cfg(test)]
mod symlink_fs_tests {
    use super::*;
    use std::path::{Path, PathBuf};

    fn scratch(tag: &str) -> PathBuf {
        let nanos = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_nanos();
        let dir = std::env::temp_dir().join(format!("submarine-{}-{}-{}", tag, std::process::id(), nanos));
        std::fs::create_dir_all(&dir).unwrap();
        dir
    }

    /// Creating symlinks on Windows needs Developer Mode or admin; when the
    /// OS refuses, the test skips instead of failing.
    fn link_dir(target: &Path, link: &Path) -> bool {
        #[cfg(windows)]
        let r = std::os::windows::fs::symlink_dir(target, link);
        #[cfg(unix)]
        let r = std::os::unix::fs::symlink(target, link);
        r.is_ok()
    }

    fn link_file(target: &Path, link: &Path) -> bool {
        #[cfg(windows)]
        let r = std::os::windows::fs::symlink_file(target, link);
        #[cfg(unix)]
        let r = std::os::unix::fs::symlink(target, link);
        r.is_ok()
    }

    #[tokio::test]
    async fn deleting_a_folder_link_keeps_the_folder_and_its_contents() {
        let root = scratch("rmdirlink");
        let target = root.join("real");
        std::fs::create_dir_all(&target).unwrap();
        std::fs::write(target.join("keep.txt"), b"data").unwrap();
        let link = root.join("link");
        if !link_dir(&target, &link) {
            eprintln!("skipped: no symlink permission");
            return;
        }
        // Even with the UI claiming it's a directory, only the link goes.
        local_remove(link.to_string_lossy().to_string(), true).await.unwrap();
        assert!(std::fs::symlink_metadata(&link).is_err(), "link must be gone");
        assert!(target.join("keep.txt").exists(), "target contents must survive");
        let _ = std::fs::remove_dir_all(&root);
    }

    #[tokio::test]
    async fn deleting_a_file_link_keeps_the_file() {
        let root = scratch("rmfilelink");
        let target = root.join("real.txt");
        std::fs::write(&target, b"data").unwrap();
        let link = root.join("link.txt");
        if !link_file(&target, &link) {
            eprintln!("skipped: no symlink permission");
            return;
        }
        local_remove(link.to_string_lossy().to_string(), false).await.unwrap();
        assert!(std::fs::symlink_metadata(&link).is_err());
        assert_eq!(std::fs::read(&target).unwrap(), b"data");
        let _ = std::fs::remove_dir_all(&root);
    }

    #[tokio::test]
    async fn a_dangling_link_can_be_deleted() {
        let root = scratch("dangling");
        let link = root.join("gone");
        if !link_file(&root.join("missing.txt"), &link) {
            eprintln!("skipped: no symlink permission");
            return;
        }
        local_remove(link.to_string_lossy().to_string(), false).await.unwrap();
        assert!(std::fs::symlink_metadata(&link).is_err());
        let _ = std::fs::remove_dir_all(&root);
    }

    #[tokio::test]
    async fn renaming_a_link_moves_the_link_not_the_target() {
        let root = scratch("mvlink");
        let target = root.join("real.txt");
        std::fs::write(&target, b"data").unwrap();
        let link = root.join("link.txt");
        if !link_file(&target, &link) {
            eprintln!("skipped: no symlink permission");
            return;
        }
        let renamed = root.join("renamed.txt");
        local_rename(link.to_string_lossy().to_string(), renamed.to_string_lossy().to_string())
            .await
            .unwrap();
        assert!(target.exists(), "target must stay where it was");
        assert!(std::fs::symlink_metadata(&renamed).unwrap().file_type().is_symlink());
        let _ = std::fs::remove_dir_all(&root);
    }

    #[tokio::test]
    async fn listing_reports_folder_links_as_folders() {
        let root = scratch("list");
        let target = root.join("real");
        std::fs::create_dir_all(&target).unwrap();
        let link = root.join("link");
        if !link_dir(&target, &link) {
            eprintln!("skipped: no symlink permission");
            return;
        }
        let listed = local_list_dir(root.to_string_lossy().to_string()).await.unwrap().entries;
        let row = listed.iter().find(|e| e.name == "link").unwrap();
        assert!(row.is_dir && row.is_symlink && !row.broken_link);
        let real = listed.iter().find(|e| e.name == "real").unwrap();
        assert!(real.is_dir && !real.is_symlink);
        let _ = std::fs::remove_dir_all(&root);
    }

    #[test]
    fn nofollow_guard_keeps_the_link_name() {
        let root = scratch("guard");
        let target = root.join("real");
        std::fs::create_dir_all(&target).unwrap();
        let link = root.join("link");
        if !link_dir(&target, &link) {
            eprintln!("skipped: no symlink permission");
            return;
        }
        let guarded = guard_local_path_nofollow(&link.to_string_lossy(), true).unwrap();
        assert_eq!(guarded.file_name().unwrap(), "link");
        // The following guard still resolves to the target, for listing/opening.
        let followed = guard_local_path(&link.to_string_lossy(), false).unwrap();
        assert_eq!(followed.file_name().unwrap(), "real");
        let _ = std::fs::remove_dir_all(&root);
    }
}

#[tauri::command]
async fn local_rename(from: String, to: String) -> Result<(), String> {
    // No-follow on both ends: renaming a link must move the link, and an
    // existing link at the destination must not redirect the rename onto its
    // target.
    let safe_from = guard_local_path_nofollow(&from, true)?;
    let safe_to = guard_local_path_nofollow(&to, false)?;
    // Same auto-mkdir-parent UX as sftp_rename: moving a file into a
    // subfolder that doesn't exist yet would otherwise fail with a
    // confusing "system cannot find the path specified" / ENOENT.
    if let Some(parent) = safe_to.parent() {
        if !parent.as_os_str().is_empty() && !parent.exists() {
            std::fs::create_dir_all(parent)
                .map_err(|e| format!("create destination parent {:?}: {}", parent, e))?;
        }
    }
    std::fs::rename(&safe_from, &safe_to)
        .map_err(|e| format!("rename {:?} -> {:?}: {}", safe_from, safe_to, e))
}

#[tauri::command]
async fn select_local_folder() -> Result<Option<String>, String> {
    #[cfg(target_os = "android")]
    {
        return Err("Android 上不支持选择文件夹。".into());
    }
    #[cfg(not(target_os = "android"))]
    {
        let folder = rfd::FileDialog::new()
            .set_title("Choose Local Directory")
            .pick_folder();
        Ok(folder.map(|p| p.to_string_lossy().to_string()))
    }
}

#[derive(serde::Serialize)]
struct LocalListResult {
    /// The folder that was listed: resolved, and in the form the path bar
    /// shows (see `display_path`).
    current_path: String,
    entries: Vec<LocalFileEntry>,
}

/// Resolve a folder the user wants to look at. Looking changes nothing, so
/// none of `guard_local_path`'s limits apply here: a drive's root and the
/// system folders can be browsed. The commands that write still refuse them.
fn readable_local_dir(path: &str) -> Result<std::path::PathBuf, String> {
    // Taken as it is given, spaces at the ends included: they can be part of
    // a folder's name (the path box does its own trimming of what is typed).
    let typed = std::borrow::Cow::Borrowed(path);
    // `C:` alone means "the current folder on drive C" to Windows, which for
    // this app is wherever it was started from. Whoever types it means the
    // drive.
    #[cfg(windows)]
    let typed = match typed.as_bytes() {
        [letter, b':'] if letter.is_ascii_alphabetic() => std::borrow::Cow::Owned(format!("{}\\", typed)),
        _ => typed,
    };
    let p = std::path::Path::new(typed.as_ref());
    if !p.is_absolute() {
        return Err(format!("不是完整路径：{}", path));
    }
    let canonical = p.canonicalize().map_err(|e| format!("无效路径：{}", e))?;
    if !canonical.is_dir() {
        return Err("Path is not a directory".into());
    }
    Ok(canonical)
}

#[tauri::command]
async fn local_list_dir(path: String) -> Result<LocalListResult, String> {
    let safe = readable_local_dir(&path)?;

    let mut entries = Vec::new();
    let read_dir = std::fs::read_dir(&safe).map_err(|e| format!("Failed to read directory: {}", e))?;

    for entry in read_dir {
        if let Ok(entry) = entry {
            // DirEntry::metadata doesn't follow links, so for a symlink or a
            // Windows junction it describes the link. Follow it so links to
            // folders list as folders; a dangling link keeps its own metadata.
            let link_meta = entry.metadata().ok();
            let is_symlink = link_meta.as_ref().map(|m| m.file_type().is_symlink()).unwrap_or(false);
            let target_meta = if is_symlink { std::fs::metadata(entry.path()).ok() } else { None };
            let broken_link = is_symlink && target_meta.is_none();
            let metadata = target_meta.or(link_meta);
            let is_dir = metadata.as_ref().map(|m| m.is_dir()).unwrap_or(false);
            let size = metadata.as_ref().map(|m| m.len()).unwrap_or(0);
            let name = entry.file_name().to_string_lossy().to_string();
            let full_path = display_path(&entry.path());

            let modified = metadata.as_ref()
                .and_then(|m| m.modified().ok())
                .and_then(|t| t.duration_since(std::time::SystemTime::UNIX_EPOCH).ok())
                .map(|d| d.as_secs());

            entries.push(LocalFileEntry {
                name,
                path: full_path,
                is_dir,
                size,
                modified,
                is_symlink,
                broken_link,
            });
        }
    }

    // Sort: directories first, then alphabetically
    entries.sort_by(|a, b| {
        if a.is_dir != b.is_dir {
            b.is_dir.cmp(&a.is_dir)
        } else {
            a.name.to_lowercase().cmp(&b.name.to_lowercase())
        }
    });

    Ok(LocalListResult { current_path: display_path(&safe), entries })
}

#[cfg(test)]
mod local_browse_tests {
    use super::*;
    use std::path::Path;

    /// A root that is there on this machine, the way the path bar shows it.
    fn a_root() -> String {
        let here = std::env::temp_dir().canonicalize().unwrap();
        display_path(here.ancestors().last().unwrap())
    }

    /// A folder the write policy refuses, as the root it is in and its name.
    fn a_system_folder() -> Option<(&'static str, &'static str)> {
        let (root, name) = if cfg!(windows) { (r"C:\", "Windows") } else { ("/", "usr") };
        Path::new(root).join(name).is_dir().then_some((root, name))
    }

    #[test]
    fn the_root_and_system_folders_can_be_listed_but_not_written() {
        let root = a_root();
        let listed = readable_local_dir(&root).expect("the root can be looked at");
        assert!(listed.parent().is_none());
        assert!(guard_local_path(&root, false).is_err(), "and is still refused to anything that writes");
        if let Some((root, name)) = a_system_folder() {
            let system = Path::new(root).join(name).to_string_lossy().to_string();
            assert!(readable_local_dir(&system).is_ok());
            assert!(guard_local_path(&system, false).is_err());
        }
    }

    #[test]
    fn a_folder_is_only_downloaded_into_a_full_path() {
        // Joined onto any of these, the folder would be created under
        // wherever the app was started from.
        let mut not_full = vec!["", ".", "relative", "relative/dir"];
        if cfg!(windows) {
            not_full.extend(["C:", r"\no-drive", "/no-drive"]);
        }
        for parent in not_full {
            assert!(check_download_dir_target(parent, "data").is_err(), "{:?}", parent);
        }
        let dir = std::env::temp_dir().to_string_lossy().to_string();
        assert!(check_download_dir_target(&dir, "submarine-no-such-folder").is_ok());
    }

    #[test]
    fn system_folders_are_found_wherever_windows_put_them() {
        let env = |var: &str| match var {
            "SystemRoot" => Some(r"D:\Windows".to_string()),
            "ProgramFiles" => Some(r"E:\Apps\".to_string()),
            "ProgramData" => Some(String::new()),
            "windir" => Some(r"relative\path".to_string()),
            "ProgramW6432" => Some(r"F:\".to_string()),
            _ => None,
        };
        let dirs = system_dirs(env);
        if cfg!(windows) {
            assert!(dirs.iter().any(|d| d == "d:/windows"), "{:?}", dirs);
            assert!(dirs.iter().any(|d| d == "e:/apps"), "{:?}", dirs);
            assert!(dirs.iter().any(|d| d == "c:/windows"), "the usual place stays: {:?}", dirs);
            // A blank, a relative path or a whole drive refuses nothing.
            assert!(dirs.iter().all(|d| d.len() > 3 && d.as_bytes()[1] == b':'), "{:?}", dirs);
            assert!(check_local_path_policy(std::path::PathBuf::from(r"\\?\C:\Windows\System32\x")).is_err());
        } else {
            for dir in ["/etc", "/private/etc", "/private/var/log", "/system"] {
                assert!(dirs.iter().any(|d| d == dir), "{} in {:?}", dir, dirs);
            }
        }
    }

    #[test]
    fn only_full_paths_are_written_to() {
        // Each would land in whatever folder the app runs in.
        let mut relative = vec!["name", "sub/name", "./name", "../name"];
        if cfg!(windows) {
            relative.extend([r"G:name", r"\name", "C:"]);
        }
        for path in relative {
            assert!(guard_local_path(path, true).unwrap_err().starts_with("Not a full path"), "{}", path);
            assert!(guard_local_path_nofollow(path, false).unwrap_err().starts_with("Not a full path"), "{}", path);
        }
        let here = std::env::temp_dir().join("submarine-no-such-file");
        assert!(guard_local_path(&here.to_string_lossy(), true).is_ok());
    }

    #[cfg(windows)]
    #[test]
    fn a_drives_own_system_folders_are_refused_on_every_drive() {
        for path in [r"\\?\D:\System Volume Information\x", r"E:\$Recycle.Bin", r"\\?\Z:\$RECYCLE.BIN\S-1-5\f"] {
            assert!(check_local_path_policy(std::path::PathBuf::from(path)).is_err(), "{}", path);
        }
        // Only at the top of a drive.
        assert!(check_local_path_policy(std::path::PathBuf::from(r"D:\data\System Volume Information")).is_ok());
        assert!(check_local_path_policy(std::path::PathBuf::from(r"D:\data\$Recycle.Bin.txt")).is_ok());
    }

    #[cfg(not(windows))]
    #[test]
    fn system_folders_are_refused_where_macos_really_keeps_them() {
        // A checked path is already resolved: macOS's /etc arrives as /private/etc.
        for path in ["/private/etc/hosts", "/private/var/log/x", "/System/Library/x", "/etc/x"] {
            assert!(check_local_path_policy(std::path::PathBuf::from(path)).is_err(), "{}", path);
        }
        assert!(check_local_path_policy(std::path::PathBuf::from("/private/tmp/x")).is_ok());
        assert!(check_local_path_policy(std::path::PathBuf::from("/home/me/systemd.txt")).is_ok());
    }

    #[test]
    fn a_folder_can_be_downloaded_into_a_root_but_not_over_a_system_folder() {
        // The check creates nothing, so the name only has to be a free one.
        assert!(check_download_dir_target(&a_root(), "submarine-no-such-folder").is_ok());
        if let Some((root, name)) = a_system_folder() {
            assert!(check_download_dir_target(root, name).is_err());
        }
    }

    #[test]
    fn only_a_full_path_to_a_folder_is_listed() {
        assert!(readable_local_dir("").is_err());
        assert!(readable_local_dir("relative/dir").is_err());
        assert!(readable_local_dir("..").is_err());
        let a_file = std::env::current_exe().unwrap();
        assert_eq!(readable_local_dir(&a_file.to_string_lossy()).unwrap_err(), "Path is not a directory");
    }

    #[cfg(windows)]
    #[test]
    fn a_bare_drive_letter_means_the_drive() {
        let root = a_root();
        // A share has no letter to type.
        let Some(drive) = root.strip_suffix('\\').filter(|d| d.len() == 2) else { return };
        let listed = readable_local_dir(drive).unwrap();
        assert!(listed.parent().is_none(), "{:?}: the drive's root, not the folder the tests run in", listed);
    }

    #[cfg(windows)]
    #[test]
    fn the_verbatim_prefix_is_shown_only_when_it_is_needed() {
        let shown = |p: &str| display_path(Path::new(p));
        assert_eq!(shown(r"\\?\C:\Users\me\Desktop"), r"C:\Users\me\Desktop");
        assert_eq!(shown(r"\\?\C:\"), r"C:\");
        assert_eq!(shown(r"\\?\UNC\server\share\dir"), r"\\server\share\dir");
        assert_eq!(shown(r"C:\already\plain"), r"C:\already\plain");
        // Only the verbatim form names these.
        for needed in [
            r"\\?\C:\data\nul",
            r"\\?\C:\data\trailing.",
            r"\\?\C:\data\trailing ",
            r"\\?\C:\data\aux.txt\x",
            r"\\?\Volume{b75e2c83-0000-0000-0000-602f00000000}\x",
        ] {
            assert_eq!(shown(needed), needed);
        }
        let long = format!(r"\\?\C:\{}", "a".repeat(260));
        assert_eq!(shown(&long), long);
        // Long in bytes, not in the units Windows counts.
        let wide = "پوشه".repeat(40);
        assert_eq!(shown(&format!(r"\\?\C:\{}", wide)), format!(r"C:\{}", wide));
    }

    #[cfg(not(windows))]
    #[test]
    fn a_path_is_shown_as_it_is() {
        assert_eq!(display_path(Path::new("/var/www")), "/var/www");
    }

    #[tokio::test]
    async fn a_listing_names_its_folder_and_entries_the_way_they_are_shown() {
        let dir = std::env::temp_dir().join(format!("submarine-list-test-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(dir.join("sub")).unwrap();
        std::fs::write(dir.join("f.txt"), b"x").unwrap();

        let listed = local_list_dir(dir.to_string_lossy().to_string()).await.unwrap();
        assert!(!listed.current_path.starts_with(r"\\?\"), "{}", listed.current_path);
        assert_eq!(listed.entries.len(), 2);
        for entry in &listed.entries {
            assert!(entry.path.starts_with(&listed.current_path), "{} is in {}", entry.path, listed.current_path);
        }
        // What a listing hands out can be handed back, for another listing
        // and to the commands that change things.
        let sub = listed.entries.iter().find(|e| e.is_dir).unwrap().path.clone();
        assert_eq!(local_list_dir(sub.clone()).await.unwrap().current_path, sub);
        assert!(guard_local_path_nofollow(&sub, true).is_ok());

        let _ = std::fs::remove_dir_all(&dir);
    }

    #[tokio::test]
    async fn a_folder_whose_name_ends_in_a_space_is_listed_as_itself() {
        // (Canonical first: on Windows only that form of a path can name it.)
        let dir = std::env::temp_dir()
            .canonicalize()
            .unwrap()
            .join(format!("submarine-space-test-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(dir.join("ends in a space ").join("inside")).unwrap();
        // A neighbour without the space, which must not be taken for it.
        std::fs::create_dir_all(dir.join("ends in a space")).unwrap();

        let listed = local_list_dir(display_path(&dir)).await.unwrap();
        let odd = listed.entries.iter().find(|e| e.name.ends_with(' ')).expect("listed with its space");
        let inside = local_list_dir(odd.path.clone()).await.unwrap();
        assert_eq!(inside.entries.iter().map(|e| e.name.as_str()).collect::<Vec<_>>(), ["inside"]);

        let _ = std::fs::remove_dir_all(&dir);
    }
}

// ---------------------------------------------------------------------------
// Monitoring commands
// ---------------------------------------------------------------------------

/// Pulls the auth bundle needed to open a monitor session for a node. Returns
/// the resolved (username, password, key_pem, passphrase) following the same
/// "vault vs custom_*" rule the interactive connect path uses — so monitor
/// auth never silently diverges from what the user sees in the form.
fn resolve_node_auth_for_monitor(
    conn: &rusqlite::Connection,
    node_id: i32,
) -> Result<monitor::NodeAuth, String> {
    let mut stmt = conn.prepare("
        SELECT s.host, s.port,
               s.username, c.username,
               s.password, c.password,
               s.key_id,   c.key_id,
               s.auth_type, c.auth_type as cred_auth_type,
               s.proxy_type, s.proxy_host, s.proxy_port
        FROM servers s
        LEFT JOIN credentials c ON s.credential_id = c.id
        WHERE s.id = ?1
    ").map_err(|e| e.to_string())?;
    let mut rows = stmt.query([node_id]).map_err(|e| e.to_string())?;
    let row = rows.next().map_err(|e| e.to_string())?.ok_or("node not found")?;

    let host: String = row.get::<_, String>(0).map_err(|e| e.to_string())?;
    let port: i32 = row.get::<_, i32>(1).map_err(|e| e.to_string())?;
    let s_user: Option<String> = row.get(2).ok().flatten();
    let c_user: Option<String> = row.get(3).ok().flatten();
    let s_pass: Option<String> = row.get(4).ok().flatten();
    let c_pass: Option<String> = row.get(5).ok().flatten();
    let s_key:  Option<i32>    = row.get(6).ok().flatten();
    let c_key:  Option<i32>    = row.get(7).ok().flatten();
    let auth_type: String = row.get::<_, Option<String>>(8).ok().flatten().unwrap_or_else(|| "vault".into());
    let cred_auth_type: Option<String> = row.get(9).ok().flatten();
    let proxy_type: String = row.get::<_, Option<String>>(10).ok().flatten().unwrap_or_else(|| "none".into());
    let proxy_host: Option<String> = row.get(11).ok().flatten();
    let proxy_port: Option<i32> = row.get(12).ok().flatten();

    let (username, password, key_id) = if auth_type == "vault" {
        (c_user.unwrap_or_default(), c_pass, c_key)
    } else {
        (s_user.unwrap_or_default(), s_pass, s_key)
    };
    let effective_key_id = if auth_type == "vault" {
        if cred_auth_type.as_deref() == Some("key") { key_id } else { None }
    } else if auth_type == "custom_key" {
        key_id
    } else {
        None
    };

    let (private_key, passphrase) = if let Some(kid) = effective_key_id {
        let mut key_stmt = conn.prepare("SELECT private_key, passphrase FROM ssh_keys WHERE id = ?1")
            .map_err(|e| e.to_string())?;
        let mut krows = key_stmt.query([kid]).map_err(|e| e.to_string())?;
        if let Some(r) = krows.next().map_err(|e| e.to_string())? {
            let pk: String = r.get(0).map_err(|e| e.to_string())?;
            let pp: Option<String> = r.get(1).ok().flatten();
            (Some(pk), pp)
        } else {
            (None, None)
        }
    } else {
        (None, None)
    };

    Ok(monitor::NodeAuth {
        host,
        port: port as u16,
        // Blank stays blank: connect_for_monitor reports it instead of
        // guessing root (#54).
        username,
        password,
        private_key,
        passphrase,
        proxy_type,
        proxy_host: proxy_host.filter(|s| !s.is_empty()),
        proxy_port: proxy_port.map(|p| p as u16),
    })
}

fn default_metrics() -> Vec<String> {
    vec!["cpu".into(), "mem".into(), "disk".into(), "load".into()]
}

/// Look up just the display name for a node. Used by the monitor's
/// outage/recovered event payloads so the frontend can show a meaningful
/// toast ("web-01 is offline") without doing another round-trip.
fn fetch_node_name(conn: &rusqlite::Connection, node_id: i32) -> String {
    conn.query_row("SELECT name FROM servers WHERE id = ?1", [node_id], |r| r.get::<_, String>(0))
        .unwrap_or_else(|_| format!("node-{}", node_id))
}

fn load_monitor_config(
    conn: &rusqlite::Connection,
    node_id: i32,
) -> Option<(Vec<String>, Vec<monitor::CustomMetric>, bool)> {
    let mut stmt = conn.prepare("SELECT enabled_metrics, custom_metrics, paused FROM monitor_configs WHERE node_id = ?1").ok()?;
    let mut rows = stmt.query([node_id]).ok()?;
    let row = rows.next().ok()??;
    let json_metrics: String = row.get(0).ok()?;
    let json_customs: String = row.get(1).ok().unwrap_or_else(|| "[]".into());
    let paused: i32 = row.get(2).ok()?;
    let metrics: Vec<String> = serde_json::from_str(&json_metrics).unwrap_or_else(|_| default_metrics());
    let customs: Vec<monitor::CustomMetric> = serde_json::from_str(&json_customs).unwrap_or_default();
    Some((metrics, customs, paused != 0))
}

fn upsert_monitor_config(
    conn: &rusqlite::Connection,
    node_id: i32,
    metrics: &[String],
    customs: &[monitor::CustomMetric],
    paused: bool,
) -> Result<(), String> {
    let json_metrics = serde_json::to_string(metrics).map_err(|e| e.to_string())?;
    let json_customs = serde_json::to_string(customs).map_err(|e| e.to_string())?;
    conn.execute(
        "INSERT INTO monitor_configs (node_id, enabled_metrics, custom_metrics, paused) VALUES (?1, ?2, ?3, ?4)
         ON CONFLICT(node_id) DO UPDATE SET enabled_metrics=excluded.enabled_metrics, custom_metrics=excluded.custom_metrics, paused=excluded.paused",
        rusqlite::params![node_id, json_metrics, json_customs, if paused { 1 } else { 0 }],
    ).map_err(|e| e.to_string())?;
    Ok(())
}

/// Frontend shape: monitor_list returns this for each known monitor (whether
/// it's been started in the live MonitorMap yet or not). UI uses it to
/// render the sidebar even before the first sample arrives.
#[derive(serde::Serialize)]
struct MonitorRow {
    node_id: i32,
    name: String,
    host: String,
    port: i32,
    enabled_metrics: Vec<String>,
    custom_metrics: Vec<monitor::CustomMetric>,
    /// Custom metrics whose command is held for this device's OK (a shared
    /// profile's synced change, see approvals.rs): listed, but not run.
    held_metric_ids: Vec<String>,
    paused: bool,
    connected: bool,
    last_error: Option<String>,
    last_sample_ts: Option<u64>,
}

fn load_settings_from_db(conn: &rusqlite::Connection) -> monitor::MonitorSettings {
    let mut stmt = match conn.prepare("SELECT json FROM monitor_settings WHERE id = 1") {
        Ok(s) => s,
        Err(_) => return monitor::MonitorSettings::default(),
    };
    let mut rows = match stmt.query([]) {
        Ok(r) => r,
        Err(_) => return monitor::MonitorSettings::default(),
    };
    if let Ok(Some(row)) = rows.next() {
        if let Ok(json) = row.get::<_, String>(0) {
            if let Ok(s) = serde_json::from_str::<monitor::MonitorSettings>(&json) {
                return s.sanitized();
            }
        }
    }
    monitor::MonitorSettings::default()
}

#[tauri::command]
async fn monitor_get_settings(
    db_state: tauri::State<'_, DbState>,
    settings: tauri::State<'_, SharedSettings>,
) -> Result<monitor::MonitorSettings, String> {
    // First-call lazy-load: if the in-memory copy is still at defaults but
    // the DB has saved values, hydrate the in-memory copy so all pollers
    // pick them up immediately. We can't tell "default vs default-saved"
    // perfectly but the worst case is idempotent.
    // Compute the DB-saved value first, then drop the std::sync::Mutex
    // guard *before* awaiting on the tokio Mutex — otherwise the future
    // captures a non-Send guard and won't compile.
    let from_db_opt: Option<monitor::MonitorSettings> = {
        let guard = db_state.conn.lock().map_err(|_| "lock")?;
        guard.as_ref().map(|conn| load_settings_from_db(conn))
    };
    if let Some(from_db) = from_db_opt {
        let mut cur = settings.lock().await;
        if *cur == monitor::MonitorSettings::default() {
            *cur = from_db;
        }
    }
    Ok(settings.lock().await.clone())
}

#[tauri::command]
async fn monitor_set_settings(
    db_state: tauri::State<'_, DbState>,
    settings: tauri::State<'_, SharedSettings>,
    new_settings: monitor::MonitorSettings,
) -> Result<monitor::MonitorSettings, String> {
    let sane = new_settings.sanitized();
    {
        let guard = db_state.conn.lock().map_err(|_| "lock")?;
        let conn = guard.as_ref().ok_or("db not ready")?;
        let json = serde_json::to_string(&sane).map_err(|e| e.to_string())?;
        conn.execute(
            "INSERT INTO monitor_settings (id, json) VALUES (1, ?1)
             ON CONFLICT(id) DO UPDATE SET json = excluded.json",
            rusqlite::params![json],
        ).map_err(|e| e.to_string())?;
    }
    save_vault_internal(&db_state)?;
    *settings.lock().await = sane.clone();
    Ok(sane)
}

#[tauri::command]
async fn monitor_list(
    db_state: tauri::State<'_, DbState>,
    map: tauri::State<'_, MonitorMap>,
) -> Result<Vec<MonitorRow>, String> {
    // Pull DB rows first so we always include configured-but-paused entries
    // even if they have no live MonitorEntry yet.
    let configs: Vec<(i32, String, String, i32, Vec<String>, Vec<monitor::CustomMetric>, bool)> = {
        let guard = db_state.conn.lock().map_err(|_| "lock")?;
        let conn = guard.as_ref().ok_or("db not ready")?;
        let mut stmt = conn.prepare("
            SELECT mc.node_id, s.name, s.host, s.port, mc.enabled_metrics, mc.custom_metrics, mc.paused
            FROM monitor_configs mc
            JOIN servers s ON s.id = mc.node_id
            ORDER BY s.name COLLATE NOCASE
        ").map_err(|e| e.to_string())?;
        let rows = stmt.query_map([], |r| {
            let metrics_json: String = r.get(4)?;
            let metrics: Vec<String> = serde_json::from_str(&metrics_json).unwrap_or_else(|_| default_metrics());
            let customs_json: String = r.get(5).unwrap_or_else(|_| "[]".into());
            let customs: Vec<monitor::CustomMetric> = serde_json::from_str(&customs_json).unwrap_or_default();
            let paused: i32 = r.get(6)?;
            Ok((r.get::<_, i32>(0)?, r.get::<_, String>(1)?, r.get::<_, String>(2)?, r.get::<_, i32>(3)?, metrics, customs, paused != 0))
        }).map_err(|e| e.to_string())?;
        let mut out = Vec::new();
        for row in rows { if let Ok(v) = row { out.push(v); } }
        out
    };
    // Which custom commands are held for this device's OK, per node.
    let held_by_node: std::collections::HashMap<i32, Vec<String>> = {
        let guard = db_state.conn.lock().map_err(|_| "lock")?;
        let conn = guard.as_ref().ok_or("db not ready")?;
        configs
            .iter()
            .filter_map(|(node_id, _, _, _, _, customs, _)| {
                let uuid = approvals::server_uuid(conn, *node_id as i64)?;
                let held = approvals::held_for(conn, &uuid);
                let ids: Vec<String> = customs
                    .iter()
                    .filter(|m| held.contains(&approvals::metric_item(&m.command)))
                    .map(|m| m.id.clone())
                    .collect();
                (!ids.is_empty()).then_some((*node_id, ids))
            })
            .collect()
    };

    // Merge live state from MonitorMap on top.
    let live = monitor::list(map.inner().clone()).await;
    let live_by_id: std::collections::HashMap<i32, monitor::MonitorInfo> =
        live.into_iter().map(|m| (m.node_id, m)).collect();

    Ok(configs.into_iter().map(|(node_id, name, host, port, metrics, customs, paused)| {
        let live = live_by_id.get(&node_id);
        MonitorRow {
            node_id,
            name, host, port,
            enabled_metrics: metrics,
            custom_metrics: customs,
            held_metric_ids: held_by_node.get(&node_id).cloned().unwrap_or_default(),
            paused,
            connected: live.map(|l| l.connected).unwrap_or(false),
            last_error: live.and_then(|l| l.last_error.clone()),
            last_sample_ts: live.and_then(|l| l.last_sample_ts),
        }
    }).collect())
}

#[tauri::command]
async fn monitor_add(
    db_state: tauri::State<'_, DbState>,
    node_id: i32,
) -> Result<(), String> {
    // Persist the config row only; the poller doesn't spawn until the user
    // explicitly clicks Resume (per the "no auto-start" rule). We still
    // resolve the auth bundle once here so adding a node with broken auth
    // fails fast instead of silently sitting in a paused state forever.
    {
        let guard = db_state.conn.lock().map_err(|_| "lock")?;
        let conn = guard.as_ref().ok_or("db not ready")?;
        let _ = resolve_node_auth_for_monitor(conn, node_id)?;
        upsert_monitor_config(conn, node_id, &default_metrics(), &[], true)?;
    }
    save_vault_internal(&db_state)?;
    Ok(())
}

#[tauri::command]
async fn monitor_remove(
    db_state: tauri::State<'_, DbState>,
    map: tauri::State<'_, MonitorMap>,
    node_id: i32,
) -> Result<(), String> {
    monitor::stop_monitor(map.inner().clone(), node_id).await;
    {
        let guard = db_state.conn.lock().map_err(|_| "lock")?;
        let conn = guard.as_ref().ok_or("db not ready")?;
        conn.execute("DELETE FROM monitor_configs WHERE node_id=?1", [node_id])
            .map_err(|e| e.to_string())?;
    }
    save_vault_internal(&db_state)?;
    Ok(())
}

#[tauri::command]
async fn monitor_set_metrics(
    db_state: tauri::State<'_, DbState>,
    map: tauri::State<'_, MonitorMap>,
    node_id: i32,
    metrics: Vec<String>,
) -> Result<(), String> {
    {
        let guard = db_state.conn.lock().map_err(|_| "lock")?;
        let conn = guard.as_ref().ok_or("db not ready")?;
        // Preserve current pause state + custom list from row.
        let (_, customs, paused) = load_monitor_config(conn, node_id)
            .unwrap_or((default_metrics(), vec![], true));
        upsert_monitor_config(conn, node_id, &metrics, &customs, paused)?;
    }
    save_vault_internal(&db_state)?;
    // If a live poller exists, hot-update it; otherwise it'll pick up on resume.
    let _ = monitor::set_enabled_metrics(map.inner().clone(), node_id, metrics).await;
    Ok(())
}

#[tauri::command]
async fn monitor_set_custom_metrics(
    db_state: tauri::State<'_, DbState>,
    map: tauri::State<'_, MonitorMap>,
    node_id: i32,
    customs: Vec<monitor::CustomMetric>,
) -> Result<(), String> {
    let running = {
        let guard = db_state.conn.lock().map_err(|_| "lock")?;
        let conn = guard.as_ref().ok_or("db not ready")?;
        let (metrics, _, paused) = load_monitor_config(conn, node_id)
            .unwrap_or((default_metrics(), vec![], true));
        upsert_monitor_config(conn, node_id, &metrics, &customs, paused)?;
        // The list comes back whole from the panel, held commands included;
        // those still don't run (see approvals.rs). An edited command is the
        // user's own, and the write above has already released it.
        approvals::without_held_metrics(conn, approvals::server_uuid(conn, node_id as i64).as_deref(), customs)
    };
    save_vault_internal(&db_state)?;
    let _ = monitor::set_custom_metrics(map.inner().clone(), node_id, running).await;
    Ok(())
}

#[tauri::command]
async fn monitor_resume(
    app: tauri::AppHandle,
    db_state: tauri::State<'_, DbState>,
    map: tauri::State<'_, MonitorMap>,
    settings: tauri::State<'_, SharedSettings>,
    node_id: i32,
) -> Result<(), String> {
    let (auth, metrics, customs, name) = {
        let guard = db_state.conn.lock().map_err(|_| "lock")?;
        let conn = guard.as_ref().ok_or("db not ready")?;
        let (metrics, customs, _) = load_monitor_config(conn, node_id)
            .ok_or_else(|| format!("Node {} is not in the monitor list", node_id))?;
        upsert_monitor_config(conn, node_id, &metrics, &customs, false)?;
        let name = fetch_node_name(conn, node_id);
        // Commands held for this device's OK don't run (see approvals.rs).
        let customs = approvals::without_held_metrics(conn, approvals::server_uuid(conn, node_id as i64).as_deref(), customs);
        (resolve_node_auth_for_monitor(conn, node_id)?, metrics, customs, name)
    };
    save_vault_internal(&db_state)?;

    // If a poller already exists, just hot-flip paused; otherwise spawn one.
    if monitor::set_paused(map.inner().clone(), node_id, false).await.is_err() {
        let db_arc = std::sync::Arc::clone(&db_state.conn);
        let settings_arc: SharedSettings = (*settings.inner()).clone();
        monitor::start_monitor(
            app,
            map.inner().clone(),
            db_arc,
            settings_arc,
            node_id,
            name,
            auth,
            metrics,
            customs,
            false,
        ).await;
    }
    Ok(())
}

#[tauri::command]
async fn monitor_pause(
    db_state: tauri::State<'_, DbState>,
    map: tauri::State<'_, MonitorMap>,
    node_id: i32,
) -> Result<(), String> {
    {
        let guard = db_state.conn.lock().map_err(|_| "lock")?;
        let conn = guard.as_ref().ok_or("db not ready")?;
        if let Some((metrics, customs, _)) = load_monitor_config(conn, node_id) {
            upsert_monitor_config(conn, node_id, &metrics, &customs, true)?;
        }
    }
    save_vault_internal(&db_state)?;
    let _ = monitor::set_paused(map.inner().clone(), node_id, true).await;
    Ok(())
}

#[tauri::command]
async fn monitor_pause_all(
    db_state: tauri::State<'_, DbState>,
    map: tauri::State<'_, MonitorMap>,
) -> Result<(), String> {
    {
        let guard = db_state.conn.lock().map_err(|_| "lock")?;
        let conn = guard.as_ref().ok_or("db not ready")?;
        conn.execute("UPDATE monitor_configs SET paused = 1", [])
            .map_err(|e| e.to_string())?;
    }
    save_vault_internal(&db_state)?;
    monitor::pause_all(map.inner().clone()).await;
    Ok(())
}

#[tauri::command]
async fn monitor_resume_all(
    app: tauri::AppHandle,
    db_state: tauri::State<'_, DbState>,
    map: tauri::State<'_, MonitorMap>,
    settings: tauri::State<'_, SharedSettings>,
) -> Result<(), String> {
    // Persist all to unpaused first.
    let node_ids: Vec<i32> = {
        let guard = db_state.conn.lock().map_err(|_| "lock")?;
        let conn = guard.as_ref().ok_or("db not ready")?;
        conn.execute("UPDATE monitor_configs SET paused = 0", [])
            .map_err(|e| e.to_string())?;
        let mut stmt = conn.prepare("SELECT node_id FROM monitor_configs").map_err(|e| e.to_string())?;
        let rows = stmt.query_map([], |r| r.get::<_, i32>(0)).map_err(|e| e.to_string())?;
        rows.filter_map(|r| r.ok()).collect()
    };
    save_vault_internal(&db_state)?;

    // Start (or hot-resume) each one.
    for node_id in node_ids {
        if monitor::set_paused(map.inner().clone(), node_id, false).await.is_err() {
            let (auth, metrics, customs, name) = {
                let guard = db_state.conn.lock().map_err(|_| "lock")?;
                let conn = guard.as_ref().ok_or("db not ready")?;
                let (metrics, customs, _) = load_monitor_config(conn, node_id)
                    .unwrap_or((default_metrics(), vec![], false));
                let name = fetch_node_name(conn, node_id);
                // Commands held for this device's OK don't run (see approvals.rs).
                let customs = approvals::without_held_metrics(conn, approvals::server_uuid(conn, node_id as i64).as_deref(), customs);
                (resolve_node_auth_for_monitor(conn, node_id)?, metrics, customs, name)
            };
            let db_arc = std::sync::Arc::clone(&db_state.conn);
            let settings_arc: SharedSettings = (*settings.inner()).clone();
            monitor::start_monitor(
                app.clone(),
                map.inner().clone(),
                db_arc,
                settings_arc,
                node_id,
                name,
                auth,
                metrics,
                customs,
                false,
            ).await;
        }
    }
    Ok(())
}

/// The clipboard's text, for a paste into the terminal. Only the Linux
/// frontend asks; the others read it in the page.
///
/// WebKitGTK refuses the page's `navigator.clipboard.readText()` (#89). And
/// where the webview reads the clipboard itself (a keyboard paste, or the
/// page API once it is allowed), it crashes the whole app when nothing owns
/// the clipboard (seen with WebKitGTK 2.54). So on Linux the page asks here
/// and GTK is asked directly. A clipboard that is empty or holds no text
/// gives an empty string.
#[tauri::command]
async fn clipboard_read_text(app: tauri::AppHandle) -> Result<String, String> {
    #[cfg(target_os = "linux")]
    {
        let (tx, rx) = tokio::sync::oneshot::channel::<Option<String>>();
        // GTK's clipboard belongs to the main thread.
        app.run_on_main_thread(move || {
            gtk::Clipboard::get(&gdk::SELECTION_CLIPBOARD).request_text(move |_, text| {
                let _ = tx.send(text.map(str::to_owned));
            });
        })
        .map_err(|e| e.to_string())?;
        match tokio::time::timeout(std::time::Duration::from_secs(5), rx).await {
            Ok(Ok(text)) => Ok(text.unwrap_or_default()),
            _ => Err("The clipboard did not answer.".to_string()),
        }
    }
    #[cfg(not(target_os = "linux"))]
    {
        let _ = app;
        Err("Reading the clipboard here is only for Linux.".to_string())
    }
}

/// Library entrypoint shared by both the desktop `bin/main.rs` shim and
/// Tauri's Android entry-point macro. Everything that builds the
/// `tauri::Builder`, registers plugins/state/commands, and finally calls
/// `.run(generate_context!())` lives here so the same binary contents
/// ship on both platforms — only the wrapping is different.
#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    // Tauri 2 on Linux embeds webkit2gtk-4.1. Two failure modes have to be
    // headed off before the WebKit child process spawns, because once it's
    // up the env it inherited is the only one it sees:
    //
    //   1. The DMA-BUF + EGL renderer that WebKit defaults to crashes with
    //      "EGL_BAD_PARAMETER … Aborting" / SIGABRT on Mesa ≥ 24 across
    //      most GPUs. Flipping it off forces the older GLES path.
    //      (WebKit #258834, tauri-apps/tauri#9304)
    //
    //   2. On Wayland sessions with Mesa ≥ 24 (Fedora 40+, KDE Plasma 6,
    //      GNOME 46+) the bundled webkit2gtk-4.1's eglGetDisplay() against
    //      a wl_display still aborts even with the DMA-BUF renderer off,
    //      because the bundled libwayland-egl ABI predates the host Mesa.
    //      Routing GTK through XWayland avoids the mismatched Wayland-EGL
    //      handshake entirely and keeps the app usable on every desktop.
    //      The trade-off is XWayland's slightly fuzzier HiDPI scaling,
    //      which is acceptable in exchange for "the app actually opens".
    //
    // Every override is gated on `var_os(...).is_none()` so power users
    // (or distros that ship a patched WebKit) can opt back in by exporting
    // the variable themselves before launching.
    #[cfg(target_os = "linux")]
    {
        // The single most effective override for the EGL_BAD_PARAMETER abort
        // seen on Fedora 40+ / Mesa 24+: tell WebKit not to attempt hardware
        // accelerated rendering AT ALL. The flag short-circuits the WebKit
        // codepath that calls eglGetDisplay(), which is the exact line that
        // SIGABRTs when the bundled libwayland-egl can't negotiate with the
        // host Mesa. Set before any of the more granular flags so it wins
        // on builds of WebKit that ignore the renderer-specific switches.
        if std::env::var_os("WEBKIT_DISABLE_HARDWARE_ACCELERATION").is_none() {
            std::env::set_var("WEBKIT_DISABLE_HARDWARE_ACCELERATION", "1");
        }
        // Older-renderer + DMA-BUF flags stay as belt-and-braces — they
        // cost nothing on builds where WEBKIT_DISABLE_HARDWARE_ACCELERATION
        // already wins, and they cover the corner cases where a downstream
        // patched WebKit honours one but not the other.
        if std::env::var_os("WEBKIT_DISABLE_DMABUF_RENDERER").is_none() {
            std::env::set_var("WEBKIT_DISABLE_DMABUF_RENDERER", "1");
        }
        if std::env::var_os("WEBKIT_DISABLE_COMPOSITING_MODE").is_none() {
            std::env::set_var("WEBKIT_DISABLE_COMPOSITING_MODE", "1");
        }
        if std::env::var_os("GDK_BACKEND").is_none() {
            std::env::set_var("GDK_BACKEND", "x11");
        }
        // Mesa software rasteriser flag kept as the final fallback in case
        // WebKit's "no hardware" path still calls into Mesa somewhere.
        if std::env::var_os("LIBGL_ALWAYS_SOFTWARE").is_none() {
            std::env::set_var("LIBGL_ALWAYS_SOFTWARE", "1");
        }
        // Sandbox the web process (bubblewrap) when this machine supports it.
        // The rendering flags above still reach it: WebKit's bwrap launcher
        // only sets/unsets a few specific variables, it never clears the
        // environment. See webkit_sandbox.rs.
        webkit_sandbox::configure();
    }

    // Portable mode: with a `submarine-data` folder next to the executable,
    // every app directory moves into it — profiles, cloud token, window state,
    // and the webview's data (localStorage, i.e. the UI preferences). Decided
    // here, once, and applied before the app is built because Tauri reads the
    // override out of the config and derives the webview's data dir from it.
    // Without the folder nothing is touched. See portable.rs.
    let mut context = tauri::generate_context!();
    portable::apply(context.config_mut());

    let builder = tauri::Builder::default();
    // Save/restore the main window's last size + position to a JSON file
    // in app_data_dir. Keeps the user's preferred geometry across launches
    // without us having to wire setSize/setPosition by hand. Plain plugin —
    // it intercepts window events; no JS-facing commands to lock down.
    // Mobile builds skip this entirely: Android decides window geometry,
    // not us, and the plugin's crate isn't compiled into the Android target.
    #[cfg(not(target_os = "android"))]
    let builder = builder.plugin(tauri_plugin_window_state::Builder::default().build());
    // Cross-platform URL opener — Android (Intent.ACTION_VIEW), Windows
    // (start), macOS (open), Linux (xdg-open). about.rs's open_external_url
    // dispatches through this so the same code path works in the desktop
    // installer AND the Android APK. Capability is granted in default.json.
    let builder = builder.plugin(tauri_plugin_opener::init());
    let builder = builder
        .manage(DbState { conn: std::sync::Arc::new(StdMutex::new(None)), master_key: StdMutex::new(None), salt: StdMutex::new(None), db_path: StdMutex::new(None), active_profile: StdMutex::new(None), hlc: StdMutex::new(None), generation: std::sync::Arc::new(std::sync::atomic::AtomicU64::new(0)) })
        .manage(SshState::new())
        // Docker live-log stream registry — keyed by frontend-issued stream id,
        // values are tokio AbortHandles so the user can stop tailing on demand.
        .manage(docker::DockerStreams::new())
        // Monitoring state is its own root-level Tauri-managed value, separate
        // from SshState — monitors and interactive sessions own different SSH
        // handles per node and don't share lifecycle.
        .manage::<MonitorMap>(std::sync::Arc::new(tokio::sync::Mutex::new(std::collections::HashMap::new())))
        // Mirror tasks live under their own root-managed map — keyed by mirror
        // id, populated by `start_mirror`, drained by the spawned worker on
        // exit. Session teardown calls `mirror::stop_all_for_session` to make
        // sure no orphan watcher is left running after the SSH handle dies.
        .manage::<MirrorMap>(std::sync::Arc::new(tokio::sync::Mutex::new(std::collections::HashMap::new())))
        // Global monitor settings live in one shared Arc<Mutex>. Pollers
        // read it at the start of every cycle so interval/threshold changes
        // are hot-applied without restarting any monitor.
        .manage::<SharedSettings>(std::sync::Arc::new(tokio::sync::Mutex::new(monitor::MonitorSettings::default())))
        // CloudState needs the AppHandle to find app_data_dir on construction
        // (to load the server settings and any persisted bearer token). Setup
        // is the earliest hook we get an AppHandle, so initialise it there and
        // `manage` it for commands.
        .setup(|app| {
            let cloud_state = cloud::CloudState::new(&app.handle());
            app.manage(cloud_state);
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            check_db_exists, setup_master_db, persist_vault,
            list_profiles, cloud_list_sync_profiles, cloud_delete_profile, force_push_profile, select_profile, create_profile, delete_profile, close_profile,
            export_profile, import_profile_pick, import_profile_save, import_profile_bytes,
            cloud::cloud_status, cloud::cloud_signup, cloud::cloud_consume_verify_link,
            cloud::cloud_set_password, cloud::cloud_login, cloud::cloud_logout,
            cloud::cloud_request_password_reset, cloud::cloud_reset_password,
            cloud::cloud_request_login_link, cloud::cloud_login_with_link,
            cloud_config::cloud_get_config, cloud_config::cloud_set_config, cloud_config::cloud_test_connection,
            sync_now, move_profile_to_current_server,
            identity_status, setup_identity, reset_identity,
            share_current_profile, invite_to_share, list_shares, share_member_list,
            accept_share, import_shared_profile, restore_personal_profile, share_set_role, share_revoke, share_leave, share_delete,
            profile_share_status, stop_sharing, profile_sync_stats, share_key_state, accept_share_key, share_replace_key, held_deletions_list, resolve_held_deletions,
            set_editor_label,
            add_server, save_quick_connect_node, edit_server, delete_server, add_mirror_to_server, get_servers, allow_held, get_ssh_keys, set_server_color, set_folder_color, set_server_notes, set_server_run_on_connect, set_server_jump_host, reorder_servers, clone_server, reveal_server_password, reveal_credential_password, reveal_ssh_key,
            get_credentials, generate_ssh_key,
            add_folder, rename_folder, delete_folder, get_folders,
            add_command, edit_command, delete_command, get_commands,
            cmd_history_add, cmd_history_list, cmd_history_clear,
            add_note, edit_note, delete_note, get_notes,
            mirror_dry_run, start_mirror, stop_mirror, list_mirrors, pick_local_directory,
            shell_sync_probe, shell_sync_preview, shell_sync_push,
            add_credential, edit_credential, delete_credential,
            add_ssh_key, edit_ssh_key, delete_ssh_key,
            pick_ssh_key_file, read_ssh_key_file, import_ssh_key_file,
            initiate_connection, verify_fingerprint_response, submit_kbi_response, disconnect_session,
            start_tunnel, stop_tunnel, list_tunnels, restart_session_tunnels, persist_session_tunnels,
            list_tunnel_rules, remove_tunnel_rule, rename_tunnel_rule,
            open_terminal, local_shell, write_terminal_data, resize_terminal, close_terminal,
            ssh_info_probe_section, ssh_systemctl_action, ssh_kill_process,
            ssh_iptables_chain, ssh_nft_chain,
            docker::ssh_docker_container_action,
            docker::ssh_docker_inspect,
            docker::ssh_docker_stats,
            docker::ssh_docker_logs,
            docker::ssh_docker_logs_start,
            docker::ssh_docker_logs_stop,
            docker::ssh_docker_networks,
            docker::ssh_docker_containers,
            docker::ssh_docker_images_list,
            docker::ssh_docker_volumes_list,
            docker::ssh_docker_compose_list,
            docker::ssh_docker_compose_per_container,
            docker::ssh_docker_compose_services,
            docker::ssh_docker_compose_action,
            docker::ssh_docker_compose_view,
            docker::ssh_docker_prune,
            docker::open_container_terminal,
            select_local_folder, local_list_dir,
            local_home_dir, local_desktop_dir, local_create_dir, local_remove, local_rename,
            android_quick_dirs, android_default_local_dir,
            parse_ssh_config,
            parse_client_import,
            sftp_list_dir, sftp_create_dir, sftp_remove_file, sftp_remove_dir,
            sftp_rename, sftp_set_permissions, sftp_set_owner, sftp_stat,
            sftp_download_file, sftp_download_dir, sftp_upload_file, sftp_upload_dir, sftp_cancel_transfer, sftp_open_remote_file,
            sftp_set_elevated, sftp_elevation_status, sftp_login_user, sftp_resolve_owners,
            archive::local_archive, archive::local_extract, archive::sftp_archive, archive::sftp_extract,
            local_open_file, local_open_in_explorer, sftp_prepare_drag,
            monitor_list, monitor_add, monitor_remove, monitor_set_metrics, monitor_set_custom_metrics,
            monitor_resume, monitor_pause, monitor_resume_all, monitor_pause_all,
            monitor_get_settings, monitor_set_settings,
            about::app_info, about::check_for_updates, about::open_external_url,
            portable::get_storage_info,
            fonts::list_system_fonts,
            clipboard_read_text
        ]);

    // Clear out live-edit / drag temp dirs a crashed earlier run left behind
    // (only ones older than a day — a newer one may be another copy of the app
    // running right now). This run's own dir is swept on exit, below.
    sweep_app_temp(false);

    builder
        .build(context)
        .expect("error while building tauri application")
        .run(|_app, event| {
            if let tauri::RunEvent::Exit = event {
                // The decrypted copies this run staged go with it.
                sweep_app_temp(true);
            }
        });
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn dir_entry_name_rejects_traversal_and_separators() {
        // Attack vectors a hostile SFTP server can put in a readdir name.
        for bad in [
            "",
            ".",
            "..",
            "../../etc/passwd",
            "a/b",
            "/etc/passwd",
            "with\0nul",
        ] {
            assert!(!is_safe_dir_entry_name(bad), "should reject {:?}", bad);
        }
        // `\` separates components only on Windows; on a POSIX client it's an
        // ordinary byte (systemd unit names like `mnt-data\x2d1.mount`).
        for name in ["..\\..\\Startup\\x.bat", "a\\b", "mnt-data\\x2d1.mount"] {
            assert_eq!(is_safe_dir_entry_name(name), !cfg!(windows), "{:?}", name);
        }
    }

    #[test]
    fn dir_entry_name_accepts_plain_filenames() {
        // Legitimate names must still pass — including ones that merely
        // start with dots.
        for ok in [
            "file.txt",
            "notes 2024.md",
            ".bashrc",
            "..foo",
            "release-v0.2.37",
            "Ω_unicode_名前",
        ] {
            assert!(is_safe_dir_entry_name(ok), "should accept {:?}", ok);
        }
        // `:` is a legal POSIX filename byte — accepted on a POSIX client,
        // rejected on a Windows one (it's a drive marker / ADS there).
        #[cfg(not(windows))]
        assert!(is_safe_dir_entry_name("2024:01:01.log"));
    }

    #[cfg(windows)]
    #[test]
    fn dir_entry_name_rejects_windows_specials() {
        // Drive-relative markers (join discards the root) and NTFS ADS.
        for bad in ["C:", "C:evil", "a:b", "file.txt:stream"] {
            assert!(!is_safe_dir_entry_name(bad), "should reject {:?}", bad);
        }
        // Reserved device names, with and without an extension, any case.
        for bad in [
            "CON", "nul", "NUL.txt", "com1", "COM9", "LPT1", "lpt9.log", "aux", "Prn",
            "COM0", "lpt0.txt", "COM¹", "LPT³.log", "CONIN$", "conout$", "AUX .c",
        ] {
            assert!(!is_safe_dir_entry_name(bad), "should reject {:?}", bad);
        }
        // Trailing dot/space are silently stripped by Win32.
        for bad in ["name.", "name ", "trailingdot."] {
            assert!(!is_safe_dir_entry_name(bad), "should reject {:?}", bad);
        }
        // But a reserved stem as a substring of a longer name is fine.
        for ok in ["console.log", "communications", "nulled.txt", "lpt10"] {
            assert!(is_safe_dir_entry_name(ok), "should accept {:?}", ok);
        }
    }

    #[test]
    fn download_target_checks_only_the_server_named_part() {
        let dir = if cfg!(windows) { "C:\\Users\\u\\Downloads" } else { "/home/u/Downloads" };
        let sep = if cfg!(windows) { "\\" } else { "/" };
        let dest = |name: &str| format!("{}{}{}", dir, sep, name);

        assert!(validate_download_target(&dest("report.txt"), "/srv/report.txt").is_ok());
        assert!(validate_download_target(&dest(".bashrc"), "/home/x/.bashrc").is_ok());
        // A `..` the user typed in their own folder is fine; only the name is
        // the server's.
        let typed = format!("{}{}..{}Desktop{}report.txt", dir, sep, sep, sep);
        assert!(validate_download_target(&typed, "/srv/report.txt").is_ok());

        // The destination must end in exactly the remote file's name.
        assert!(validate_download_target(&dest("other.txt"), "/srv/report.txt").is_err());
        // No name at all, or `..` as the name.
        assert!(validate_download_target(&dest(""), "/srv/").is_err());
        assert!(validate_download_target(&dest(".."), "/srv/..").is_err());

        // A name that climbs out on Windows is refused there; on POSIX it's
        // one literal (odd) file name that stays in the folder.
        let climb = "..\\..\\Startup\\x.bat";
        assert_eq!(
            validate_download_target(&dest(climb), &format!("/srv/{}", climb)).is_ok(),
            !cfg!(windows)
        );
        #[cfg(windows)]
        assert!(validate_download_target(&dest("a:b"), "/srv/a:b").is_err());
    }

    #[test]
    fn skipped_names_note_counts() {
        assert_eq!(skipped_names_note(0), None);
        assert!(skipped_names_note(1).unwrap().starts_with("1 item skipped"));
        assert!(skipped_names_note(7).unwrap().starts_with("7 items skipped"));
    }
}
