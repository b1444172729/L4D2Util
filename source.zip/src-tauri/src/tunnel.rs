//! SSH tunnel management. Implements the two cross-platform forward modes
//! that don't require fiddly server-side cooperation:
//!
//!   * **Local forward** (`-L`): bind a local TCP listener and, for each
//!     incoming connection, open a `direct-tcpip` channel through SSH to a
//!     fixed `host:port` reachable from the server.
//!
//!   * **Dynamic forward** (`-D`): bind a local TCP listener that speaks
//!     SOCKS5 (no-auth, CONNECT only). Each accepted SOCKS request opens its
//!     own `direct-tcpip` channel to the requested target.
//!
//! Each tunnel has a stable `id` so the UI can list, refresh stats, and stop
//! it independently. State updates are pushed over the
//! `tunnel-update-{session_id}` event so the panel doesn't have to poll.

use std::collections::HashMap;
use std::net::SocketAddr;
use std::pin::Pin;
use std::sync::atomic::{AtomicBool, AtomicU32, AtomicU64, AtomicUsize, Ordering};
use std::sync::Arc;
use std::task::{ready, Context, Poll};
use std::time::{Duration, Instant};

use serde::{Deserialize, Serialize};
use tauri::{AppHandle, Emitter};
use tokio::io::{AsyncRead, AsyncReadExt, AsyncWrite, AsyncWriteExt, ReadBuf};
use tokio::net::TcpListener;
use tokio::sync::{broadcast, oneshot, Mutex, Notify, Semaphore};

use crate::ssh_manager::ClientHandler;

// ---------------------------------------------------------------------------
// Public types
// ---------------------------------------------------------------------------

/// One forwarding rule: what a node saves in its `tunnels` column, and what a
/// session keeps in its rule list (`SshState::session_tunnel_specs`).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TunnelSpec {
    /// "D" (dynamic / SOCKS5), "L" (local forward), "R" (remote forward —
    /// not implemented yet; start_tunnel returns an error for this kind).
    #[serde(rename = "type")]
    pub kind: String,
    /// Local side: port or "addr:port". Defaults to 127.0.0.1 when only a
    /// port is given so we don't accidentally bind 0.0.0.0.
    pub local: String,
    /// Remote target "host:port" — used by L only. Ignored by D.
    #[serde(default)]
    pub remote: String,
    /// The name the user gave the forward, if any (see `clean_name`).
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub name: Option<String>,
    /// Stopped by the user: the rule is kept, but nothing starts it (not a
    /// connect, a reconnect, the dedicated connection or a retry) until the
    /// user starts it again. Rules saved before this existed have no such
    /// field, and run.
    #[serde(default, skip_serializing_if = "is_false")]
    pub stopped: bool,
}

fn is_false(b: &bool) -> bool {
    !*b
}

/// Two specs are the same forward when their kind, local side and target
/// match. The name and the stopped flag describe a forward; they don't make
/// it a different one.
impl PartialEq for TunnelSpec {
    fn eq(&self, other: &Self) -> bool {
        self.kind == other.kind && self.local == other.local && self.remote == other.remote
    }
}

impl Eq for TunnelSpec {}

/// The longest name a forward keeps, in characters.
const NAME_MAX_CHARS: usize = 64;

/// A name as typed, the way it is kept: trimmed, at most `NAME_MAX_CHARS`
/// characters, and none at all when nothing is left.
pub fn clean_name(name: Option<&str>) -> Option<String> {
    let name: String = name?.trim().chars().take(NAME_MAX_CHARS).collect();
    let name = name.trim_end().to_string();
    (!name.is_empty()).then_some(name)
}

/// A session's rules after `spec` was started: the rule for that forward is
/// running again (and takes `spec`'s name, if it has one), or is added at the
/// end when the forward is new.
pub fn rule_started(rules: &mut Vec<TunnelSpec>, spec: &TunnelSpec) {
    match rules.iter_mut().find(|rule| *rule == spec) {
        Some(rule) => {
            rule.stopped = false;
            if spec.name.is_some() {
                rule.name = spec.name.clone();
            }
        }
        None => rules.push(TunnelSpec { stopped: false, ..spec.clone() }),
    }
}

/// A session's rules after the user stopped `spec`: the rule stays, marked
/// stopped. (Before #28 a stop removed the rule, and the node lost it.)
pub fn rule_stopped(rules: &mut [TunnelSpec], spec: &TunnelSpec) {
    for rule in rules.iter_mut().filter(|rule| *rule == spec) {
        rule.stopped = true;
    }
}

/// Removes the rule for `spec`. False when there was none.
pub fn rule_removed(rules: &mut Vec<TunnelSpec>, spec: &TunnelSpec) -> bool {
    let before = rules.len();
    rules.retain(|rule| rule != spec);
    rules.len() != before
}

/// Gives the rule for `spec` the name `name` (see `clean_name`). False when
/// there is no such rule.
pub fn rule_renamed(rules: &mut [TunnelSpec], spec: &TunnelSpec, name: Option<&str>) -> bool {
    let mut found = false;
    for rule in rules.iter_mut().filter(|rule| *rule == spec) {
        rule.name = clean_name(name);
        found = true;
    }
    found
}

#[derive(Debug, Clone, Serialize)]
pub struct TunnelStatus {
    pub id: String,
    pub session_id: String,
    pub kind: String,
    pub listen_addr: String,
    pub target: String,
    pub state: String, // "starting", "listening", "error", "closed"
    pub error: Option<String>,
    /// Total accepted connections since this tunnel started (monotonic).
    pub conns_total: u32,
    /// Number of connections currently bridged through this tunnel. Backed
    /// by an RAII guard on each spawned bridge task: the count increments
    /// when the task starts and decrements when the task's future ends,
    /// regardless of whether it ended cleanly, with an error, or via the
    /// stop-signal shutdown path.
    pub conns_active: u32,
    pub bytes_in: u64,
    pub bytes_out: u64,
    /// The rule this tunnel was started from, so the Ports panel can tell
    /// which of a session's rules are running (`listen_addr` is the resolved
    /// address, not what the rule says).
    pub spec: TunnelSpec,
}

pub struct ActiveTunnel {
    pub status: Arc<Mutex<TunnelStatus>>,
    pub stop_tx: Option<oneshot::Sender<()>>,
    /// JoinHandle of the spawned listener task. Held so that
    /// `stop_all_for_session` (and explicit `stop_tunnel`) can await
    /// the task's actual exit before declaring the tunnel torn down.
    /// Without this the port stays bound for several seconds on Windows
    /// while the OS keeps the socket in TIME_WAIT, racing with reconnects.
    pub join: Option<tauri::async_runtime::JoinHandle<()>>,
    /// The original spec used to start this tunnel. Carried so that an
    /// explicit `stop_tunnel` command can drop the matching entry from the
    /// per-session replay list (otherwise stopped tunnels would silently
    /// re-open on the next reconnect).
    pub spec: TunnelSpec,
}

pub type TunnelMap = Arc<Mutex<HashMap<String, ActiveTunnel>>>;

/// Lookup record for an active remote (-R) forward. The SSH server listens on
/// `server_port` (registered via `tcpip_forward`); when an inbound connection
/// hits that port the server opens a `forwarded-tcpip` channel to us, and our
/// `ClientHandler` consults this map to know what local `target` to bridge to.
#[derive(Clone)]
pub struct ForwardEntry {
    /// Local "host:port" we should connect to when a forwarded channel arrives.
    pub target: String,
    /// Tunnel status (shared with the listing UI) — handler increments
    /// `conns_total` and emits an update on every accepted forwarded connection.
    pub status: Arc<Mutex<TunnelStatus>>,
    /// AppHandle for emitting status updates from inside the handler.
    pub app: tauri::AppHandle,
    /// Caps how many inbound forwarded-tcpip connections can be bridged at once
    /// for this R tunnel. The server drives these opens, so without a cap a
    /// hostile or runaway peer could spam them and exhaust the client (tasks,
    /// sockets, memory) — the inbound mirror of the local/dynamic forwards'
    /// `conn_limiter`. Shared (Arc) across every inbound connection on the port.
    pub conn_limiter: Arc<Semaphore>,
}

/// Per-session map of `server_port → ForwardEntry`. Created once per SSH
/// connection in `initiate_connection`, handed to both the `ClientHandler`
/// (for inbound channel lookup) and to `tunnel::start_tunnel` (for "R"
/// registrations).
pub type ForwardedTargets = Arc<Mutex<HashMap<u32, ForwardEntry>>>;

// ---------------------------------------------------------------------------
// Spec parsing
// ---------------------------------------------------------------------------

fn parse_listen(local: &str) -> Result<SocketAddr, String> {
    // Accept "8080" or "0.0.0.0:8080" / "[::]:8080" — bare ports bind to loopback.
    let s = local.trim();
    if s.is_empty() {
        return Err("Local address is empty".into());
    }
    if !s.contains(':') {
        return format!("127.0.0.1:{}", s)
            .parse()
            .map_err(|e| format!("Invalid port {}: {}", s, e));
    }
    s.parse()
        .map_err(|e| format!("Invalid bind address {}: {}", s, e))
}

fn parse_target(remote: &str) -> Result<(String, u16), String> {
    let s = remote.trim();
    let (host, port) = s
        .rsplit_once(':')
        .ok_or_else(|| format!("Remote target {:?} must be host:port", s))?;
    let port: u16 = port.parse().map_err(|e| format!("Invalid port: {}", e))?;
    if host.is_empty() {
        return Err("Remote host is empty".into());
    }
    Ok((host.to_string(), port))
}

fn next_tunnel_id() -> String {
    use std::time::{SystemTime, UNIX_EPOCH};
    static SEQ: AtomicU64 = AtomicU64::new(0);
    let n = SEQ.fetch_add(1, Ordering::Relaxed);
    let ms = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_millis())
        .unwrap_or(0);
    format!("tun-{}-{}", ms, n)
}

// ---------------------------------------------------------------------------
// Status update helpers
// ---------------------------------------------------------------------------

async fn emit_update(app: &AppHandle, status: &TunnelStatus) {
    let _ = app.emit(
        &format!("tunnel-update-{}", status.session_id),
        status.clone(),
    );
}

/// Per-event log entry pushed to `tunnel-log-{session_id}`. The UI keeps a
/// short rolling buffer per tunnel so the user can see what addresses traffic
/// is going to and which connections are failing without having to dig
/// through stderr or a debug log file.
#[derive(Debug, Clone, Serialize)]
struct TunnelLogEntry<'a> {
    tunnel_id: &'a str,
    /// Wall-clock millis since UNIX epoch. UI formats this on render so we
    /// don't pay a String-allocation cost on the hot bridge path.
    ts_ms: u128,
    /// "info" | "warn" | "error". Drives the UI colour.
    level: &'a str,
    /// Short human-readable event ("connect", "fail", "close", ...).
    event: &'a str,
    /// Destination the connection targeted, when known.
    target: Option<String>,
    /// Source peer (the client that connected to our local listener).
    peer: Option<String>,
    /// Free-form detail — typically the error string on failures.
    message: Option<String>,
}

fn now_ms() -> u128 {
    use std::time::{SystemTime, UNIX_EPOCH};
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_millis())
        .unwrap_or(0)
}

fn emit_log(
    app: &AppHandle,
    session_id: &str,
    tunnel_id: &str,
    level: &str,
    event: &str,
    target: Option<String>,
    peer: Option<String>,
    message: Option<String>,
) {
    let entry = TunnelLogEntry {
        tunnel_id,
        ts_ms: now_ms(),
        level,
        event,
        target,
        peer,
        message,
    };
    let _ = app.emit(&format!("tunnel-log-{}", session_id), entry);
}

/// RAII counter for in-flight bridged connections. Increments
/// `status.conns_active` on construction and decrements it on drop,
/// emitting an update either side so the UI tracks the change in real
/// time. Drop is sync, so the decrement-and-emit step is offloaded to a
/// short-lived spawned task — the count itself is held in an AtomicU32
/// shared across the listener so the actual increment/decrement is
/// instant and lock-free; the mutex'd `TunnelStatus` is only touched
/// for the UI emit.
struct ActiveGuard {
    counter: Arc<AtomicU32>,
    status: Arc<Mutex<TunnelStatus>>,
    app: AppHandle,
}

impl ActiveGuard {
    async fn enter(
        counter: Arc<AtomicU32>,
        status: Arc<Mutex<TunnelStatus>>,
        app: AppHandle,
    ) -> Self {
        let n = counter.fetch_add(1, Ordering::Relaxed) + 1;
        {
            let mut s = status.lock().await;
            s.conns_active = n;
            s.conns_total = s.conns_total.saturating_add(1);
        }
        emit_update(&app, &status.lock().await.clone()).await;
        Self { counter, status, app }
    }
}

impl Drop for ActiveGuard {
    fn drop(&mut self) {
        let n = self.counter.fetch_sub(1, Ordering::Relaxed).saturating_sub(1);
        let status = Arc::clone(&self.status);
        let app = self.app.clone();
        tauri::async_runtime::spawn(async move {
            {
                let mut s = status.lock().await;
                s.conns_active = n;
            }
            emit_update(&app, &status.lock().await.clone()).await;
        });
    }
}

async fn set_state(
    app: &AppHandle,
    status_arc: &Arc<Mutex<TunnelStatus>>,
    state: &str,
    error: Option<String>,
) {
    let snapshot = {
        let mut s = status_arc.lock().await;
        s.state = state.to_string();
        if let Some(e) = error {
            s.error = Some(e);
        }
        s.clone()
    };
    emit_update(app, &snapshot).await;
}

// ---------------------------------------------------------------------------
// Public entry: start a tunnel
// ---------------------------------------------------------------------------

/// Bind a local listener, retrying briefly on `AddrInUse`. A reconnect can race
/// the previous listener's teardown, and on Windows a just-freed port can linger
/// momentarily (there is no `SO_REUSEADDR` on the tokio listener), so a single
/// bind would spuriously fail the auto-restore — and the caller used to strip
/// the spec on that failure, dropping the tunnel for good until a manual
/// restart. Retrying over ~1.5s rides out that transient window; a
/// non-`AddrInUse` error (bad address, permission) still fails immediately.
async fn bind_with_retry(addr: &str) -> std::io::Result<TcpListener> {
    let mut last: Option<std::io::Error> = None;
    for _ in 0..6 {
        match TcpListener::bind(addr).await {
            Ok(l) => return Ok(l),
            Err(e) if e.kind() == std::io::ErrorKind::AddrInUse => {
                last = Some(e);
                tokio::time::sleep(Duration::from_millis(250)).await;
            }
            Err(e) => return Err(e),
        }
    }
    Err(last.unwrap_or_else(|| std::io::Error::new(std::io::ErrorKind::AddrInUse, "bind retries exhausted")))
}

pub async fn start_tunnel(
    app: AppHandle,
    session_id: String,
    handle: Arc<Mutex<russh::client::Handle<ClientHandler>>>,
    tunnels_map: TunnelMap,
    forwarded_targets: ForwardedTargets,
    spec: TunnelSpec,
) -> Result<String, String> {
    let id = next_tunnel_id();

    // Pre-parse a server-side bind for R so we fail fast on bad input.
    let r_bind: Option<(String, u32)> = if spec.kind == "R" {
        let s = spec.local.trim();
        let (addr, port) = if let Some((a, p)) = s.rsplit_once(':') {
            (a.to_string(), p.parse::<u32>().map_err(|e| format!("无效的服务器端口：{}", e))?)
        } else {
            // Bare port on the server defaults to listening on all interfaces,
            // subject to the server's `GatewayPorts` setting.
            ("0.0.0.0".to_string(), s.parse::<u32>().map_err(|e| format!("无效的服务器端口：{}", e))?)
        };
        Some((addr, port))
    } else {
        None
    };

    let (kind, listen_addr_str, target_str): (String, String, String) = match spec.kind.as_str() {
        "D" => {
            let addr = parse_listen(&spec.local)?;
            ("dynamic".into(), addr.to_string(), "SOCKS5".into())
        }
        "L" => {
            let addr = parse_listen(&spec.local)?;
            let (host, port) = parse_target(&spec.remote)?;
            ("local".into(), addr.to_string(), format!("{}:{}", host, port))
        }
        "R" => {
            let (addr, port) = r_bind.as_ref().unwrap();
            // Validate local target now so we don't register a server-side
            // listener that maps to nowhere.
            let (lh, lp) = parse_target(&spec.remote)?;
            ("remote".into(), format!("{}:{}", addr, port), format!("{}:{}", lh, lp))
        }
        other => return Err(format!("Unknown tunnel kind: {}", other)),
    };

    let status = TunnelStatus {
        id: id.clone(),
        session_id: session_id.clone(),
        kind: kind.clone(),
        listen_addr: listen_addr_str.clone(),
        target: target_str.clone(),
        state: "starting".into(),
        error: None,
        conns_total: 0,
        conns_active: 0,
        bytes_in: 0,
        bytes_out: 0,
        spec: spec.clone(),
    };
    let status_arc = Arc::new(Mutex::new(status.clone()));

    // Bind the local listener (if any) on the CALLER thread so we return
    // a real error to the frontend when the port is taken — instead of
    // returning Ok(id) and reporting the failure asynchronously via the
    // status event, which the UI may have already started using.
    let local_listener = match kind.as_str() {
        "local" | "dynamic" => {
            Some(bind_with_retry(&listen_addr_str).await
                .map_err(|e| format!("bind {}: {}", listen_addr_str, e))?)
        }
        _ => None,
    };

    let (stop_tx, stop_rx) = oneshot::channel::<()>();

    emit_update(&app, &status).await;

    // Spawn the actual forwarder. It owns the listener and lives until it
    // either errors out or the stop signal fires.
    let app_for_task = app.clone();
    let status_for_task = Arc::clone(&status_arc);
    let tunnels_map_for_task = Arc::clone(&tunnels_map);
    let id_for_task = id.clone();
    let kind_for_task = kind.clone();
    let target_for_task = target_str.clone();
    let listen_for_task = listen_addr_str.clone();
    let session_for_task = session_id.clone();

    let forwarded_targets_for_task = Arc::clone(&forwarded_targets);
    let r_bind_for_task = r_bind.clone();

    let listener_for_task = local_listener;
    let _ = listen_for_task; // listener already bound; addr unused inside task
    let join = tauri::async_runtime::spawn(async move {
        let result = match kind_for_task.as_str() {
            "dynamic" => {
                run_dynamic_forward(
                    app_for_task.clone(),
                    session_for_task.clone(),
                    handle,
                    listener_for_task.expect("dynamic kind always has a listener"),
                    Arc::clone(&status_for_task),
                    stop_rx,
                )
                .await
            }
            "local" => {
                run_local_forward(
                    app_for_task.clone(),
                    session_for_task.clone(),
                    handle,
                    listener_for_task.expect("local kind always has a listener"),
                    target_for_task.clone(),
                    Arc::clone(&status_for_task),
                    stop_rx,
                )
                .await
            }
            "remote" => {
                let (addr, port) = r_bind_for_task.unwrap();
                run_remote_forward(
                    app_for_task.clone(),
                    handle,
                    addr,
                    port,
                    target_for_task.clone(),
                    Arc::clone(&status_for_task),
                    Arc::clone(&forwarded_targets_for_task),
                    stop_rx,
                )
                .await
            }
            _ => Err("unreachable".to_string()),
        };

        match result {
            Ok(()) => set_state(&app_for_task, &status_for_task, "closed", None).await,
            Err(e) => set_state(&app_for_task, &status_for_task, "error", Some(e)).await,
        }
        // Drop the entry from the map so list_tunnels reflects reality.
        tunnels_map_for_task.lock().await.remove(&id_for_task);
    });

    tunnels_map.lock().await.insert(
        id.clone(),
        ActiveTunnel {
            status: Arc::clone(&status_arc),
            stop_tx: Some(stop_tx),
            join: Some(join),
            spec,
        },
    );

    Ok(id)
}

pub async fn stop_tunnel(tunnels_map: &TunnelMap, id: &str) -> Result<(), String> {
    // Take the stop sender + join handle under the map lock, release the
    // lock, then await the task. Holding the map lock across the await
    // would deadlock anyone else inspecting / removing tunnels in the
    // meantime (the listener task itself removes its entry on exit).
    let join = {
        let mut map = tunnels_map.lock().await;
        match map.get_mut(id) {
            Some(t) => {
                if let Some(tx) = t.stop_tx.take() {
                    let _ = tx.send(());
                }
                t.join.take()
            }
            None => return Err(format!("No active tunnel with id {}", id)),
        }
    };
    if let Some(j) = join {
        // Best-effort await. If the task already panicked / was aborted,
        // we still want to return Ok so the caller's higher-level cleanup
        // can proceed — the worst case is a leaked listener which the
        // listener-task's own remove() will eventually clean up.
        let _ = j.await;
    }
    Ok(())
}

pub async fn list_tunnels(
    tunnels_map: &TunnelMap,
    session_id: Option<&str>,
) -> Vec<TunnelStatus> {
    let map = tunnels_map.lock().await;
    let mut out = Vec::new();
    for t in map.values() {
        let s = t.status.lock().await;
        if let Some(sid) = session_id {
            if s.session_id != sid {
                continue;
            }
        }
        out.push(s.clone());
    }
    out
}

pub async fn stop_all_for_session(tunnels_map: &TunnelMap, session_id: &str) {
    // Snapshot (id, status_arc) under the map lock — DO NOT take the
    // per-status mutex while holding the map mutex. The listener task's
    // emitter path already holds status.lock() and then briefly touches
    // the map on exit (`tunnels_map.lock()...remove(&id)`); nesting in
    // the opposite order here would form an AB-BA deadlock.
    let candidates: Vec<(String, Arc<Mutex<TunnelStatus>>)> = {
        let map = tunnels_map.lock().await;
        map.iter()
            .map(|(id, t)| (id.clone(), Arc::clone(&t.status)))
            .collect()
    };
    let mut ids = Vec::with_capacity(candidates.len());
    for (id, status) in candidates {
        if status.lock().await.session_id == session_id {
            ids.push(id);
        }
    }
    for id in ids {
        let _ = stop_tunnel(tunnels_map, &id).await;
    }
}

// ---------------------------------------------------------------------------
// Local forward
// ---------------------------------------------------------------------------

/// Socket options every tunnel data socket wants:
///   - TCP_NODELAY: don't Nagle-buffer interactive traffic.
///   - TCP keepalive: detect a peer that vanished WITHOUT a FIN/RST — a slept
///     laptop, a NAT that silently dropped the mapping, a yanked cable. The
///     data pump (`copy_bidirectional`) is intentionally unbounded so a
///     legitimately-idle tunnel stays open forever; the cost is that a
///     half-open socket whose peer is gone would otherwise park the bridge
///     task on a read that never completes and never errors. That task holds
///     one of MAX_CONCURRENT_CONNS permits for good, and once enough leak the
///     listener silently stops serving new connections while still reporting
///     "listening" — a tunnel that is up but passes no data. Kernel keepalive
///     turns that dead peer into a socket error within ~a minute, so the pump
///     returns and the permit is freed. A genuinely idle-but-alive connection
///     is untouched: its keepalive probes get ACKed.
fn apply_tunnel_sockopts(sock: &tokio::net::TcpStream) {
    use socket2::{SockRef, TcpKeepalive};
    let _ = sock.set_nodelay(true);
    let ka = TcpKeepalive::new()
        .with_time(Duration::from_secs(30))
        .with_interval(Duration::from_secs(10));
    let _ = SockRef::from(sock).set_tcp_keepalive(&ka);
}

/// Whether an `accept()` error is a transient per-connection hiccup (the client
/// went away between SYN and accept) that we should just skip, versus something
/// that warrants a short breather before retrying so we don't hot-spin. Either
/// way a "permanent" tunnel must NEVER tear its listener down over one accept
/// error — that was itself a silent-death path: a momentary EMFILE would return
/// from the loop, unbind the port, and kill the tunnel.
fn transient_accept_error(e: &std::io::Error) -> bool {
    use std::io::ErrorKind::*;
    matches!(e.kind(), ConnectionAborted | ConnectionReset | Interrupted | WouldBlock)
}

/// How long a forwarded connection may go with ZERO bytes moving in EITHER
/// direction before we close it and free its permit. This is the real cure for
/// the "tunnel shows connected but passes no data until I restart it" leak: when
/// the remote end of a forwarded connection dies silently (the SSH channel never
/// delivers EOF) while the local peer is idle-but-alive (its TCP keepalive keeps
/// answering), `copy_bidirectional` parks forever and pins one of
/// MAX_CONCURRENT_CONNS permits — eventually the pool is exhausted and every new
/// connection is silently refused. The idle window RESETS on any traffic, so a
/// busy connection is never cut; only a truly-silent one is reaped, and the
/// listener stays up so the client just reconnects.
const IDLE_TIMEOUT: Duration = Duration::from_secs(15 * 60);

/// A passthrough AsyncRead+AsyncWrite that stamps `last` (millis since `base`)
/// whenever it actually moves bytes, so the idle watchdog in `pump_bidirectional`
/// can tell a quiet-but-alive connection from a wedged one. `S` is Unpin
/// (TcpStream and the russh channel stream both are — `copy_bidirectional`
/// already requires it), so the wrapper is Unpin and `get_mut()` is safe.
struct ActivityTracked<'a, S> {
    inner: &'a mut S,
    last: Arc<AtomicU64>,
    base: Instant,
}

impl<'a, S: AsyncRead + Unpin> AsyncRead for ActivityTracked<'a, S> {
    fn poll_read(self: Pin<&mut Self>, cx: &mut Context<'_>, buf: &mut ReadBuf<'_>) -> Poll<std::io::Result<()>> {
        let this = self.get_mut();
        let before = buf.filled().len();
        let r = Pin::new(&mut *this.inner).poll_read(cx, buf);
        if let Poll::Ready(Ok(())) = &r {
            if buf.filled().len() != before {
                this.last.store(this.base.elapsed().as_millis() as u64, Ordering::Relaxed);
            }
        }
        r
    }
}

impl<'a, S: AsyncWrite + Unpin> AsyncWrite for ActivityTracked<'a, S> {
    fn poll_write(self: Pin<&mut Self>, cx: &mut Context<'_>, buf: &[u8]) -> Poll<std::io::Result<usize>> {
        let this = self.get_mut();
        let r = Pin::new(&mut *this.inner).poll_write(cx, buf);
        if let Poll::Ready(Ok(n)) = &r {
            if *n > 0 {
                this.last.store(this.base.elapsed().as_millis() as u64, Ordering::Relaxed);
            }
        }
        r
    }
    fn poll_flush(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<std::io::Result<()>> {
        let this = self.get_mut();
        Pin::new(&mut *this.inner).poll_flush(cx)
    }
    fn poll_shutdown(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<std::io::Result<()>> {
        let this = self.get_mut();
        Pin::new(&mut *this.inner).poll_shutdown(cx)
    }
}

/// Most SSH→local bytes ONE bridged connection may hold that its local peer
/// hasn't read yet. See `DrainedChannelStream`.
const MAX_UNFLUSHED_BYTES: usize = 64 * 1024 * 1024;

/// `AsyncRead + AsyncWrite` over a russh channel whose READ side is drained by
/// a dedicated task into an in-memory queue — the replacement for
/// `Channel::into_stream()` at every tunnel bridge site.
///
/// Why: since russh 0.50 each channel has a small bounded queue, and the
/// connection's single protocol task *awaits* room in it before it will
/// process anything else. russh also refills the SSH window as soon as data
/// ARRIVES (not when it is consumed), so there is no per-channel flow control
/// to lean on. With a plain `ChannelStream`, a local client that stops reading
/// (a paused browser download, a wedged app behind `-L` / `-D` / `-R`) makes
/// the pump stop reading the channel → its queue fills → the protocol task
/// blocks → EVERY terminal, SFTP op, keepalive and other tunnel on that SSH
/// connection freezes. Here the channel is always drained, so one slow consumer
/// can only ever hurt itself: once its backlog passes `MAX_UNFLUSHED_BYTES`
/// that ONE forwarded connection is cut (see `pump_channel`) instead of
/// freezing the session or growing without bound (the russh-0.40 behaviour).
///
/// Dropping the stream closes the channel (like `ChannelStream`) and stops the
/// drain task, whose receiver drop makes russh discard any late data for this
/// channel instead of waiting on it.
pub(crate) struct DrainedChannelStream {
    rx: tokio::sync::mpsc::UnboundedReceiver<russh::ChannelMsg>,
    /// Partially-consumed `ChannelMsg::Data` and the read offset into it.
    cur: Option<(russh::ChannelMsg, usize)>,
    queued: Arc<AtomicUsize>,
    overflowed: Arc<AtomicBool>,
    /// Signalled by the drain task when it gives up on a stalled local peer.
    overflow: Arc<Notify>,
    tx: Pin<Box<dyn AsyncWrite + Send>>,
    write_half: Option<russh::ChannelWriteHalf<russh::client::Msg>>,
    drain: tokio::task::AbortHandle,
}

pub(crate) fn drained_stream(channel: russh::Channel<russh::client::Msg>) -> DrainedChannelStream {
    drained_stream_with_cap(channel, MAX_UNFLUSHED_BYTES)
}

fn drained_stream_with_cap(channel: russh::Channel<russh::client::Msg>, cap: usize) -> DrainedChannelStream {
    let (mut read_half, write_half) = channel.split();
    let (msg_tx, rx) = tokio::sync::mpsc::unbounded_channel::<russh::ChannelMsg>();
    let queued = Arc::new(AtomicUsize::new(0));
    let overflowed = Arc::new(AtomicBool::new(false));
    let overflow = Arc::new(Notify::new());
    let drain = {
        let queued = Arc::clone(&queued);
        let overflowed = Arc::clone(&overflowed);
        let overflow = Arc::clone(&overflow);
        tokio::spawn(async move {
            while let Some(msg) = read_half.wait().await {
                match msg {
                    russh::ChannelMsg::Data { ref data } => {
                        let n = data.len();
                        if queued.fetch_add(n, Ordering::AcqRel) + n > cap {
                            overflowed.store(true, Ordering::Release);
                            overflow.notify_one();
                            eprintln!(
                                "[tunnel] local peer stopped reading ({} KiB backlog) — closing this forwarded connection",
                                cap >> 10
                            );
                            break;
                        }
                        if msg_tx.send(msg).is_err() {
                            break; // stream dropped
                        }
                    }
                    russh::ChannelMsg::Eof | russh::ChannelMsg::Close => break,
                    // stderr-style extended data, window adjusts, exit status…:
                    // nothing to forward on a TCP bridge. Consumed so it can't
                    // occupy the channel queue.
                    _ => {}
                }
            }
            // `read_half` (the channel's receiver) drops here.
        })
        .abort_handle()
    };
    DrainedChannelStream {
        rx,
        cur: None,
        queued,
        overflowed,
        overflow,
        tx: Box::pin(write_half.make_writer()),
        write_half: Some(write_half),
        drain,
    }
}

impl AsyncRead for DrainedChannelStream {
    fn poll_read(self: Pin<&mut Self>, cx: &mut Context<'_>, buf: &mut ReadBuf<'_>) -> Poll<std::io::Result<()>> {
        let this = self.get_mut();
        if buf.remaining() == 0 {
            return Poll::Ready(Ok(()));
        }
        loop {
            if let Some((msg, idx)) = this.cur.take() {
                if let russh::ChannelMsg::Data { data } = &msg {
                    let avail = data.len().saturating_sub(idx);
                    if avail > 0 {
                        let n = buf.remaining().min(avail);
                        buf.put_slice(&data[idx..idx + n]);
                        this.queued.fetch_sub(n, Ordering::AcqRel);
                        if n < avail {
                            this.cur = Some((msg, idx + n));
                        }
                        return Poll::Ready(Ok(()));
                    }
                }
                // Empty / fully consumed chunk: fetch the next one. (Returning
                // Ok with zero bytes here would read as EOF.)
                continue;
            }
            match ready!(this.rx.poll_recv(cx)) {
                Some(msg) => this.cur = Some((msg, 0)),
                None if this.overflowed.load(Ordering::Acquire) => {
                    return Poll::Ready(Err(std::io::Error::other(
                        "forwarded connection closed: local peer stopped reading",
                    )));
                }
                None => return Poll::Ready(Ok(())), // channel EOF / close
            }
        }
    }
}

impl AsyncWrite for DrainedChannelStream {
    fn poll_write(self: Pin<&mut Self>, cx: &mut Context<'_>, buf: &[u8]) -> Poll<std::io::Result<usize>> {
        self.get_mut().tx.as_mut().poll_write(cx, buf)
    }
    fn poll_flush(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<std::io::Result<()>> {
        self.get_mut().tx.as_mut().poll_flush(cx)
    }
    /// Sends the channel EOF (half-close), exactly like `ChannelStream`.
    fn poll_shutdown(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<std::io::Result<()>> {
        self.get_mut().tx.as_mut().poll_shutdown(cx)
    }
}

impl Drop for DrainedChannelStream {
    fn drop(&mut self) {
        self.drain.abort();
        if let Some(write_half) = self.write_half.take() {
            // Async close, best effort — same as russh's own ChannelStream drop.
            // Guarded so a drop outside a runtime (app shutdown) can't panic.
            if let Ok(rt) = tokio::runtime::Handle::try_current() {
                rt.spawn(async move {
                    let _ = write_half.close().await;
                });
            }
        }
    }
}

/// Bidirectional copy that closes the connection after `IDLE_TIMEOUT` of no
/// traffic in either direction, freeing its permit. Drop-in for the old bare
/// `tokio::io::copy_bidirectional` at every bridge site — the only behavioural
/// change is that a silently-dead connection can no longer pin a permit forever.
async fn pump_bidirectional<A, B>(a: &mut A, b: &mut B)
where
    A: AsyncRead + AsyncWrite + Unpin,
    B: AsyncRead + AsyncWrite + Unpin,
{
    pump_bidirectional_with_idle(a, b, IDLE_TIMEOUT).await
}

/// Core of `pump_bidirectional` with an injectable idle window (tests use a
/// short one). Returns when either side closes/errors, or after `idle` of no
/// bytes moving in EITHER direction.
async fn pump_bidirectional_with_idle<A, B>(a: &mut A, b: &mut B, idle: Duration)
where
    A: AsyncRead + AsyncWrite + Unpin,
    B: AsyncRead + AsyncWrite + Unpin,
{
    let base = Instant::now();
    let last = Arc::new(AtomicU64::new(0));
    let mut ta = ActivityTracked { inner: a, last: Arc::clone(&last), base };
    let mut tb = ActivityTracked { inner: b, last: Arc::clone(&last), base };
    let copy = tokio::io::copy_bidirectional(&mut ta, &mut tb);
    tokio::pin!(copy);
    // Poll the idle window at a quarter of its length so the reap lands within
    // ~idle of the last byte without spinning. Floor the tick so a tiny test
    // window still makes progress.
    let tick = (idle / 4).max(Duration::from_millis(1));
    let idle_ms = idle.as_millis() as u64;
    loop {
        tokio::select! {
            _ = &mut copy => break, // normal EOF / close / error on either side
            _ = tokio::time::sleep(tick) => {
                let now_ms = base.elapsed().as_millis() as u64;
                if now_ms.saturating_sub(last.load(Ordering::Relaxed)) >= idle_ms {
                    // Silent too long — drop both streams (closing the sockets /
                    // channel) and return so the bridge task ends and frees its
                    // permit.
                    break;
                }
            }
        }
    }
}

/// `pump_bidirectional` for a bridge whose SSH side is a `DrainedChannelStream`
/// — what every tunnel bridge uses. It additionally ends the moment the drain
/// task gives up on a local peer that stopped reading (backlog past
/// `MAX_UNFLUSHED_BYTES`). Without that the pump would sit blocked writing to
/// the stalled peer until the idle watchdog fired, holding the backlog in
/// memory while the server kept streaming into a channel nobody reads. Ending
/// drops both ends here: the local socket closes and the channel is closed, so
/// the server stops sending.
async fn pump_channel<A>(local: &mut A, channel: &mut DrainedChannelStream)
where
    A: AsyncRead + AsyncWrite + Unpin,
{
    let overflow = Arc::clone(&channel.overflow);
    tokio::select! {
        _ = pump_bidirectional(local, channel) => {}
        _ = overflow.notified() => {}
    }
}

async fn run_local_forward(
    app: AppHandle,
    session_id: String,
    handle: Arc<Mutex<russh::client::Handle<ClientHandler>>>,
    listener: TcpListener,
    target: String, // "host:port"
    status: Arc<Mutex<TunnelStatus>>,
    mut stop_rx: oneshot::Receiver<()>,
) -> Result<(), String> {
    let tunnel_id = status.lock().await.id.clone();
    set_state(&app, &status, "listening", None).await;
    emit_log(&app, &session_id, &tunnel_id, "info", "listen",
             Some(target.clone()), None,
             Some(format!("Local forward up; forwarding to {}", target)));

    let (target_host, target_port) = parse_target(&target)?;
    let active = Arc::new(AtomicU32::new(0));
    let conn_limiter = Arc::new(Semaphore::new(MAX_CONCURRENT_CONNS));
    let (shutdown_tx, _) = broadcast::channel::<()>(1);

    // The listener does ONE thing: accept incoming TCP connections and spawn
    // a bridge task for each. It does NOT poll the SSH handle's health. The
    // earlier version did, by lock()-ing the handle inside the select arm,
    // which could block `stop_rx` from firing whenever a slow bridge task
    // was already holding the mutex — symptom: clicking Stop did nothing
    // for several seconds while we waited on a wedged channel_open. The
    // main.rs watcher is the single authoritative SSH-death signal; it
    // calls `tunnel::stop_all_for_session` on detection, which signals
    // stop_tx here. Bridge tasks fail fast on their own when SSH is dead.

    loop {
        tokio::select! {
            _ = &mut stop_rx => {
                let _ = shutdown_tx.send(());
                break;
            }
            accepted = listener.accept() => {
                let (sock, peer) = match accepted {
                    Ok(pair) => pair,
                    Err(e) => {
                        // Keep the listener alive across accept errors — see
                        // transient_accept_error. Only a sustained resource
                        // error gets a short sleep to avoid a hot loop.
                        if !transient_accept_error(&e) {
                            tokio::time::sleep(Duration::from_millis(100)).await;
                        }
                        continue;
                    }
                };
                apply_tunnel_sockopts(&sock);
                // Hard cap on concurrent bridge tasks. try_acquire is
                // non-blocking: at the cap we close the new socket and keep
                // serving existing connections rather than queueing (an
                // unbounded queue is the same resource-exhaustion problem).
                let permit = match Arc::clone(&conn_limiter).try_acquire_owned() {
                    Ok(p) => p,
                    Err(_) => { drop(sock); continue; }
                };
                let handle = Arc::clone(&handle);
                let status = Arc::clone(&status);
                let app = app.clone();
                let session_id = session_id.clone();
                let target_host = target_host.clone();
                let target_full = format!("{}:{}", target_host, target_port);
                let active = Arc::clone(&active);
                let tunnel_id = tunnel_id.clone();
                let mut shutdown_rx = shutdown_tx.subscribe();

                tauri::async_runtime::spawn(async move {
                    let _permit = permit; // released when this bridge task ends
                    let _guard = ActiveGuard::enter(active, Arc::clone(&status), app.clone()).await;
                    emit_log(&app, &session_id, &tunnel_id, "info", "connect",
                             Some(target_full.clone()), Some(peer.to_string()), None);

                    tokio::select! {
                        _ = shutdown_rx.recv() => {
                            emit_log(&app, &session_id, &tunnel_id, "info", "stop",
                                     Some(target_full), Some(peer.to_string()),
                                     Some("Tunnel stopped".into()));
                        }
                        res = bridge_local_to_channel(handle, sock, peer, target_host, target_port) => {
                            match res {
                                Ok(()) => {
                                    emit_log(&app, &session_id, &tunnel_id, "info", "close",
                                             Some(target_full), Some(peer.to_string()), None);
                                }
                                Err(e) => {
                                    emit_log(&app, &session_id, &tunnel_id, "error", "fail",
                                             Some(target_full), Some(peer.to_string()), Some(e));
                                }
                            }
                        }
                    }
                });
            }
        }
    }
    emit_log(&app, &session_id, &tunnel_id, "info", "shutdown", None, None, None);
    Ok(())
}

async fn bridge_local_to_channel(
    handle: Arc<Mutex<russh::client::Handle<ClientHandler>>>,
    mut sock: tokio::net::TcpStream,
    peer: SocketAddr,
    target_host: String,
    target_port: u16,
) -> Result<(), String> {
    let channel = open_channel_with_retry(
        &handle, &target_host, target_port as u32,
        &peer.ip().to_string(), peer.port() as u32,
    ).await.map_err(|e| format!("channel_open_direct_tcpip: {}", e))?;
    let mut stream = drained_stream(channel);
    pump_channel(&mut sock, &mut stream).await;
    Ok(())
}

// ---------------------------------------------------------------------------
// Dynamic forward (SOCKS5, CONNECT only, NO-AUTH)
// ---------------------------------------------------------------------------

async fn run_dynamic_forward(
    app: AppHandle,
    session_id: String,
    handle: Arc<Mutex<russh::client::Handle<ClientHandler>>>,
    listener: TcpListener,
    status: Arc<Mutex<TunnelStatus>>,
    mut stop_rx: oneshot::Receiver<()>,
) -> Result<(), String> {
    let tunnel_id = status.lock().await.id.clone();
    set_state(&app, &status, "listening", None).await;
    emit_log(&app, &session_id, &tunnel_id, "info", "listen",
             Some("SOCKS4 / SOCKS5".into()), None,
             Some("Dynamic forward up; accepting SOCKS4 + SOCKS5 (CONNECT)".into()));

    let active = Arc::new(AtomicU32::new(0));
    let conn_limiter = Arc::new(Semaphore::new(MAX_CONCURRENT_CONNS));
    let (shutdown_tx, _) = broadcast::channel::<()>(1);

    // Single-responsibility listener: accept SOCKS / HTTP requests and spawn
    // a bridge task. SSH-liveness is NOT polled from here — see the matching
    // comment in run_local_forward for why. The main.rs watcher detects SSH
    // death and triggers `tunnel::stop_all_for_session`, which fires our
    // stop_rx and tears everything down cleanly.

    loop {
        tokio::select! {
            _ = &mut stop_rx => {
                let _ = shutdown_tx.send(());
                break;
            }
            accepted = listener.accept() => {
                let (sock, peer) = match accepted {
                    Ok(pair) => pair,
                    Err(e) => {
                        // Same resilience as run_local_forward: never let a
                        // single accept error kill the listener.
                        if !transient_accept_error(&e) {
                            tokio::time::sleep(Duration::from_millis(100)).await;
                        }
                        continue;
                    }
                };
                apply_tunnel_sockopts(&sock);
                // Hard cap on concurrent bridge tasks — see run_local_forward.
                // Non-blocking: at the cap we close the socket and keep serving.
                let permit = match Arc::clone(&conn_limiter).try_acquire_owned() {
                    Ok(p) => p,
                    Err(_) => { drop(sock); continue; }
                };
                let handle = Arc::clone(&handle);
                let status = Arc::clone(&status);
                let app = app.clone();
                let session_id = session_id.clone();
                let active = Arc::clone(&active);
                let tunnel_id = tunnel_id.clone();
                let mut shutdown_rx = shutdown_tx.subscribe();

                tauri::async_runtime::spawn(async move {
                    let _permit = permit; // released when this bridge task ends
                    let _guard = ActiveGuard::enter(active, Arc::clone(&status), app.clone()).await;

                    tokio::select! {
                        _ = shutdown_rx.recv() => {
                            emit_log(&app, &session_id, &tunnel_id, "info", "stop",
                                     None, Some(peer.to_string()), Some("Tunnel stopped".into()));
                        }
                        res = handle_dynamic_client(handle, sock, peer, app.clone(), session_id.clone(), tunnel_id.clone()) => {
                            if let Err(e) = res {
                                emit_log(&app, &session_id, &tunnel_id, "error", "fail",
                                         None, Some(peer.to_string()), Some(e));
                            }
                        }
                    }
                });
            }
        }
    }
    emit_log(&app, &session_id, &tunnel_id, "info", "shutdown", None, None, None);
    Ok(())
}

// ---------------------------------------------------------------------------
// Remote forward (server-side listener)
// ---------------------------------------------------------------------------
//
// Mechanics: we ask the server to bind a TCP listener (`tcpip_forward`),
// then sit waiting for the stop signal. When the server accepts a connection
// on that port it pushes us a `forwarded-tcpip` channel via
// `ClientHandler::server_channel_open_forwarded_tcpip`, which looks up the
// port in `ForwardedTargets` and bridges to the local target.

/// How long the server-side listener requests (`tcpip-forward` and its cancel)
/// may take before we give up. Without a bound, a server that stalls on the
/// global request hangs the setup/teardown forever — and, since the request is
/// made while holding the per-session handle lock, it also blocks the health
/// watcher's next probe (and any other channel on the session) for that whole
/// time. The timeout caps both: the lock is now held for at most this long.
const FORWARD_REQUEST_TIMEOUT: Duration = Duration::from_secs(10);

async fn run_remote_forward(
    app: AppHandle,
    handle: Arc<Mutex<russh::client::Handle<ClientHandler>>>,
    bind_addr: String,
    server_port: u32,
    local_target: String,
    status: Arc<Mutex<TunnelStatus>>,
    forwarded_targets: ForwardedTargets,
    stop_rx: oneshot::Receiver<()>,
) -> Result<(), String> {
    // Register the handler-side mapping FIRST, so any race between the
    // server confirming the forward and the first incoming channel is
    // resolved correctly.
    let entry = ForwardEntry {
        target: local_target.clone(),
        status: Arc::clone(&status),
        // The handler may need to emit updates on its own thread; we keep an
        // AppHandle clone per entry rather than threading it through every
        // callback path.
        app: app.clone(),
        conn_limiter: Arc::new(Semaphore::new(MAX_CONCURRENT_CONNS)),
    };
    forwarded_targets.lock().await.insert(server_port, entry);

    // Ask the server to start listening, bounded so a server that never
    // answers the global request can't hang the setup forever (nor hold the
    // per-session lock indefinitely and freeze the health watcher with it).
    let request = {
        let h = handle.lock().await;
        match tokio::time::timeout(
            FORWARD_REQUEST_TIMEOUT,
            h.tcpip_forward(&bind_addr, server_port),
        ).await {
            Ok(r) => r,
            Err(_) => {
                drop(h);
                forwarded_targets.lock().await.remove(&server_port);
                return Err(format!(
                    "tcpip-forward request timed out after {:?}",
                    FORWARD_REQUEST_TIMEOUT
                ));
            }
        }
    };
    match request {
        Ok(_) => {
            set_state(&app, &status, "listening", None).await;
        }
        Err(russh::Error::RequestDenied) => {
            forwarded_targets.lock().await.remove(&server_port);
            return Err(format!(
                "Server refused tcpip-forward on {}:{} — check sshd_config's `AllowTcpForwarding` / `GatewayPorts`",
                bind_addr, server_port
            ));
        }
        Err(e) => {
            forwarded_targets.lock().await.remove(&server_port);
            return Err(format!("tcpip-forward request failed: {}", e));
        }
    }

    // Wait until the user stops the tunnel (or the session goes away and the
    // sender side is dropped — either way the channel resolves).
    let _ = stop_rx.await;

    // Best-effort: tell the server to release the port and drop our map entry.
    // Same timeout as the setup request so teardown can't hang on the lock.
    {
        let h = handle.lock().await;
        let _ = tokio::time::timeout(
            FORWARD_REQUEST_TIMEOUT,
            h.cancel_tcpip_forward(&bind_addr, server_port),
        ).await;
    }
    forwarded_targets.lock().await.remove(&server_port);
    Ok(())
}

/// How long an inbound `forwarded-tcpip` open may wait on the LOCAL connect
/// before we refuse it. The server holds the outside client's connection open
/// until we answer, so an unreachable local target must not leave it hanging.
const FORWARDED_CONNECT_TIMEOUT: Duration = Duration::from_secs(10);

/// Helper used by `ClientHandler::server_channel_open_forwarded_tcpip` to
/// bridge an inbound forwarded channel to a local TCP socket. Lives in this
/// module so the forwarding/bookkeeping code stays in one place.
///
/// Answers the server's channel open (russh >= 0.62 hands us `reply`): the
/// local target is dialled FIRST and the channel is accepted only once that
/// succeeds; otherwise (error or `FORWARDED_CONNECT_TIMEOUT`) it is rejected
/// with `ConnectFailed`, so the outside connector sees a refusal rather than
/// an accepted-then-dropped connection. A channel only goes live (and only
/// needs draining) after `accept()`; from then on it's read through
/// `drained_stream` like every other bridge.
pub async fn bridge_forwarded_channel(
    entry: ForwardEntry,
    channel: russh::Channel<russh::client::Msg>,
    reply: russh::client::ChannelOpenHandle,
    // One permit from the entry's `conn_limiter`, acquired by the caller before
    // this bridge was spawned. Held for the whole bridge and released on return,
    // so it bounds how many inbound connections run at once for this R tunnel.
    _permit: tokio::sync::OwnedSemaphorePermit,
) {
    // Bump conns_total and push an update so the UI reflects the activity.
    {
        let mut s = entry.status.lock().await;
        s.conns_total = s.conns_total.saturating_add(1);
    }
    emit_update(&entry.app, &entry.status.lock().await.clone()).await;

    let connect = tokio::time::timeout(
        FORWARDED_CONNECT_TIMEOUT,
        tokio::net::TcpStream::connect(&entry.target),
    )
    .await;
    match connect {
        Ok(Ok(mut local)) => {
            apply_tunnel_sockopts(&local);
            reply.accept().await;
            let mut stream = drained_stream(channel);
            pump_channel(&mut local, &mut stream).await;
        }
        Ok(Err(e)) => {
            eprintln!("[remote-forward] connect to {} failed: {}", entry.target, e);
            drop(channel);
            reply.reject(russh::ChannelOpenFailure::ConnectFailed).await;
        }
        Err(_) => {
            eprintln!(
                "[remote-forward] connect to {} timed out after {:?}",
                entry.target, FORWARDED_CONNECT_TIMEOUT
            );
            drop(channel);
            reply.reject(russh::ChannelOpenFailure::ConnectFailed).await;
        }
    }
}

/// Hard ceiling on a single `channel_open_direct_tcpip`. russh awaits the
/// server's CHANNEL_OPEN_CONFIRMATION with no timeout of its own, and we hold
/// the shared handle mutex across that await — so when the SSH transport is
/// silently wedged (a network blip the kernel/russh hasn't yet surfaced as a
/// close) ONE new connection's open parks forever WHILE HOLDING THE HANDLE
/// LOCK. That freezes the health watcher (its `is_closed()` poll and its active
/// probe both take the same lock), so the session is never declared dead, never
/// auto-reconnects, and the bridge task's permit never frees — the exact
/// "tunnel dead, UI still green, only a manual restart brings it back" report.
/// Bounding the open releases the lock (and the permit) within this window: the
/// watcher runs again and, if the link is truly gone, its own probe strikes out
/// and triggers a reconnect; if the link recovered, the next connection just
/// succeeds. A real open completes in one round-trip (milliseconds), so 10s
/// never trips a healthy link.
const CHANNEL_OPEN_TIMEOUT: Duration = Duration::from_secs(10);

/// Open a `direct-tcpip` channel through the SSH session, with ONE quick
/// retry on transient failure. Modern browsers fire bursts of channel-open
/// requests (preconnect pools, image sprites, prefetch) and some SSH
/// servers temporarily refuse new channels under that load with a
/// transport-shaped error even though the session itself is healthy. A
/// 120ms backoff + single retry papers over those without holding the
/// caller noticeably longer. Falls back to the original error on the
/// second failure. Every open is bounded by CHANNEL_OPEN_TIMEOUT — see there
/// for why an unbounded open is the root of the silent-tunnel-death bug.
async fn open_channel_with_retry(
    handle: &Mutex<russh::client::Handle<ClientHandler>>,
    target_host: &str,
    target_port: u32,
    peer_ip: &str,
    peer_port: u32,
) -> Result<russh::Channel<russh::client::Msg>, String> {
    let first = {
        let h = handle.lock().await;
        tokio::time::timeout(
            CHANNEL_OPEN_TIMEOUT,
            h.channel_open_direct_tcpip(target_host.to_string(), target_port,
                                        peer_ip.to_string(), peer_port),
        ).await
    };
    let first_err: String = match first {
        Ok(Ok(c)) => return Ok(c),
        Ok(Err(e)) => e.to_string(),
        Err(_) => format!("channel open timed out after {:?}", CHANNEL_OPEN_TIMEOUT),
    };
    // Don't retry if the session is gone — wasted round-trip and the
    // user is about to see the disconnect banner anyway.
    let still_alive = {
        let h = handle.lock().await;
        !h.is_closed()
    };
    if !still_alive {
        return Err(first_err);
    }
    tokio::time::sleep(Duration::from_millis(120)).await;
    let second = {
        let h = handle.lock().await;
        tokio::time::timeout(
            CHANNEL_OPEN_TIMEOUT,
            h.channel_open_direct_tcpip(target_host.to_string(), target_port,
                                        peer_ip.to_string(), peer_port),
        ).await
    };
    match second {
        Ok(Ok(c)) => Ok(c),
        Ok(Err(e)) => Err(e.to_string()),
        Err(_) => Err(format!("channel open timed out after {:?} (retry)", CHANNEL_OPEN_TIMEOUT)),
    }
}

/// Detect the protocol the client is speaking from its first byte and hand
/// off to the matching handler. The dynamic forward accepts:
///
///   * SOCKS5 / SOCKS5h (0x05) — domain mode covers hostname-resolving
///     clients, no separate version on the wire.
///   * SOCKS4 / SOCKS4a (0x04)
///   * HTTP CONNECT (covers all HTTPS tunneling, plus any client that
///     speaks the older RFC 2616 absolute-URI proxy form for plain HTTP).
///     Triggered by ANY ASCII uppercase letter — the only legitimate first
///     byte of an HTTP request method.
///
/// Maximum concurrent bridge tasks per listener. Each accepted connection
/// spawns one task holding a socket + FD; without a cap a flood (especially
/// stalled slowloris connections) spawns them unbounded and exhausts FDs /
/// memory. 512 is far above any legitimate interactive use (a browser opens
/// ~6 preconnects per host) while still bounding the blast radius. At the cap
/// new connections are closed immediately rather than queued.
const MAX_CONCURRENT_CONNS: usize = 512;

/// Maximum time any single handshake read may block. SOCKS/HTTP proxy
/// handshakes are a handful of small reads that finish in milliseconds for a
/// real client; a client that connects and then stalls mid-handshake must not
/// be able to park a spawned task forever holding a socket + FD (the slowloris
/// half of a resource-exhaustion DoS). The data-pump phase
/// (`copy_bidirectional`) is deliberately NOT bounded — a long-lived idle
/// tunnel is legitimate.
const HANDSHAKE_READ_TIMEOUT: Duration = Duration::from_secs(30);

/// `read_exact` with a per-read deadline. Semantically identical to
/// `sock.read_exact(buf)` except it returns an `ErrorKind::TimedOut` error
/// instead of blocking indefinitely when the peer stops sending. Used for
/// every read on the handshake path so a stalled client can't wedge the task.
async fn read_exact_to(
    sock: &mut tokio::net::TcpStream,
    buf: &mut [u8],
) -> std::io::Result<()> {
    match tokio::time::timeout(HANDSHAKE_READ_TIMEOUT, sock.read_exact(buf)).await {
        Ok(r) => r.map(|_| ()),
        Err(_) => Err(std::io::Error::new(
            std::io::ErrorKind::TimedOut,
            "handshake read timed out",
        )),
    }
}

/// `read_exact` bounded by an ABSOLUTE deadline shared across an entire
/// handshake phase. read_exact_to's per-read timeout is fine for the fixed-size
/// SOCKS reads (a bounded count, each capped at 30s), but the byte-at-a-time
/// loops below reset a per-read timeout on every single byte — so a client
/// dribbling one byte just under the limit could keep a task (and one of the
/// 512 connection permits) alive for hours: the slowloris DoS. Threading one
/// `deadline` through each loop caps the whole field/line/header read regardless
/// of how the peer paces individual bytes.
async fn read_exact_by(
    sock: &mut tokio::net::TcpStream,
    buf: &mut [u8],
    deadline: tokio::time::Instant,
) -> std::io::Result<()> {
    match tokio::time::timeout_at(deadline, sock.read_exact(buf)).await {
        Ok(r) => r.map(|_| ()),
        Err(_) => Err(std::io::Error::new(
            std::io::ErrorKind::TimedOut,
            "handshake timed out",
        )),
    }
}

/// Anything else (control bytes, unknown SOCKS versions) gets a clean log
/// line and the connection closes; we don't try to autodetect TLS or other
/// raw bytes because there's no useful action we could take with them.
async fn handle_dynamic_client(
    handle: Arc<Mutex<russh::client::Handle<ClientHandler>>>,
    mut sock: tokio::net::TcpStream,
    peer: SocketAddr,
    app: AppHandle,
    session_id: String,
    tunnel_id: String,
) -> Result<(), String> {
    let mut ver = [0u8; 1];
    // Browser preconnect pools (Chrome opens ~6 connections per host
    // proactively, even before the user types a URL), health probes and
    // OS-level connection scrubbers regularly open a TCP socket against
    // our SOCKS listener and close it WITHOUT sending the version byte.
    // The earlier code surfaced every one of these as `read version:
    // early eof` in the activity log, even though the SSH side was fine.
    // Treat both "EOF before any byte arrived" AND "no byte within 30s"
    // as a silent close — return Ok(()) so the listener doesn't log a
    // fail line. Anything else (interrupted read, TCP reset mid-byte)
    // is still surfaced.
    let read_res = tokio::time::timeout(Duration::from_secs(30),
                                        sock.read_exact(&mut ver)).await;
    match read_res {
        Err(_) => return Ok(()), // 30s and the client said nothing — drop quietly
        Ok(Err(e)) if e.kind() == std::io::ErrorKind::UnexpectedEof => return Ok(()),
        Ok(Err(e)) => return Err(format!("read version: {}", e)),
        Ok(Ok(_)) => {}
    }
    match ver[0] {
        0x05 => handle_socks5(handle, sock, peer, app, session_id, tunnel_id).await,
        0x04 => handle_socks4(handle, sock, peer, app, session_id, tunnel_id).await,
        b if b.is_ascii_uppercase() => {
            handle_http_proxy(handle, sock, peer, b, app, session_id, tunnel_id).await
        }
        v => Err(format!("Unknown protocol version 0x{:02x}", v)),
    }
}

/// HTTP proxy handler covering both CONNECT (the modern way — tunnels
/// arbitrary TCP, used by every browser for HTTPS) and the older absolute-
/// URI form (`GET http://host/path HTTP/1.1`) for plain HTTP. The first
/// byte of the method was already consumed by the dispatcher and is passed
/// in so we can stitch it back when reading the request line.
async fn handle_http_proxy(
    handle: Arc<Mutex<russh::client::Handle<ClientHandler>>>,
    mut sock: tokio::net::TcpStream,
    peer: SocketAddr,
    first_byte: u8,
    app: AppHandle,
    session_id: String,
    tunnel_id: String,
) -> Result<(), String> {
    // One absolute deadline for the ENTIRE HTTP handshake (request line +
    // headers). Shared across every loop read so cumulative time is bounded no
    // matter how the peer paces bytes — see read_exact_by.
    let hs_deadline = tokio::time::Instant::now() + HANDSHAKE_READ_TIMEOUT;
    // Reconstruct the request line: dispatcher ate one byte, read the rest.
    let mut rest = read_line_max(&mut sock, 8192, hs_deadline).await
        .map_err(|e| format!("http read req-line: {}", e))?;
    let mut line = Vec::with_capacity(rest.len() + 1);
    line.push(first_byte);
    line.append(&mut rest);
    let request_line = String::from_utf8_lossy(&line).into_owned();

    let parts: Vec<&str> = request_line.splitn(3, ' ').collect();
    if parts.len() < 2 {
        let _ = sock.write_all(b"HTTP/1.1 400 Bad Request\r\n\r\n").await;
        return Err(format!("http: malformed request line {:?}", request_line));
    }
    let method = parts[0].to_string();
    let uri = parts[1].to_string();

    if method == "CONNECT" {
        // `CONNECT host:port HTTP/1.1` — consume headers, open tunnel, reply 200.
        consume_headers(&mut sock, 16 * 1024, hs_deadline).await
            .map_err(|e| format!("http connect headers: {}", e))?;
        let (host, port) = parse_host_port(&uri)
            .ok_or_else(|| format!("http connect: bad target {:?}", uri))?;

        let target_full = format!("{}:{}", host, port);
        emit_log(&app, &session_id, &tunnel_id, "info", "connect",
                 Some(target_full.clone()), Some(peer.to_string()),
                 Some("via HTTP CONNECT".into()));

        let channel = open_channel_with_retry(
            &handle, &host, port as u32,
            &peer.ip().to_string(), peer.port() as u32,
        ).await;
        let channel = match channel {
            Ok(c) => {
                sock.write_all(b"HTTP/1.1 200 Connection Established\r\n\r\n")
                    .await
                    .map_err(|e| format!("http connect reply: {}", e))?;
                c
            }
            Err(e) => {
                let _ = sock.write_all(b"HTTP/1.1 502 Bad Gateway\r\n\r\n").await;
                emit_log(&app, &session_id, &tunnel_id, "error", "fail",
                         Some(target_full), Some(peer.to_string()), Some(e.to_string()));
                return Err(format!("direct-tcpip {}:{} failed: {}", host, port, e));
            }
        };

        let mut stream = drained_stream(channel);
        pump_channel(&mut sock, &mut stream).await;
        emit_log(&app, &session_id, &tunnel_id, "info", "close",
                 Some(target_full), Some(peer.to_string()), None);
        return Ok(());
    }

    // Plain HTTP — clients send the absolute URI (`GET http://host/path`)
    // so the proxy can pick the destination. Bare-path requests (`GET /foo`)
    // mean the client thinks we're the origin server, which we aren't.
    let (host, port, path) = match parse_absolute_uri(&uri) {
        Some(t) => t,
        None => {
            let _ = sock.write_all(
                b"HTTP/1.1 400 Bad Request\r\nContent-Type: text/plain\r\nConnection: close\r\n\r\n\
                  Submarine HTTP proxy expects an absolute-URI request line \
                  (e.g. `GET http://example.com/path HTTP/1.1`).\n"
            ).await;
            return Err(format!("http: unsupported URI form {:?}", uri));
        }
    };
    let target_full = format!("{}:{}", host, port);
    emit_log(&app, &session_id, &tunnel_id, "info", "connect",
             Some(target_full.clone()), Some(peer.to_string()),
             Some(format!("via HTTP {} {}", method, path)));

    // Buffer the client headers so we can filter out the hop-by-hop /
    // proxy-only ones before forwarding. We also force Connection: close
    // upstream so we don't have to demultiplex a keep-alive pipeline back
    // to multiple destinations on the same socket.
    let headers_raw = read_headers_raw(&mut sock, 64 * 1024, hs_deadline).await
        .map_err(|e| format!("http headers: {}", e))?;
    let forwarded_headers = filter_and_rewrite_headers(&headers_raw);

    let channel = open_channel_with_retry(
        &handle, &host, port as u32,
        &peer.ip().to_string(), peer.port() as u32,
    ).await;
    let mut stream = match channel {
        Ok(c) => drained_stream(c),
        Err(e) => {
            let _ = sock.write_all(b"HTTP/1.1 502 Bad Gateway\r\nConnection: close\r\n\r\n").await;
            emit_log(&app, &session_id, &tunnel_id, "error", "fail",
                     Some(target_full), Some(peer.to_string()), Some(e.to_string()));
            return Err(format!("direct-tcpip {}:{} failed: {}", host, port, e));
        }
    };

    // Send rewritten request to upstream: relative URI, filtered headers, blank line.
    let req_line = format!("{} {} HTTP/1.1\r\n", method, path);
    if let Err(e) = stream.write_all(req_line.as_bytes()).await {
        return Err(format!("http upstream write req-line: {}", e));
    }
    if let Err(e) = stream.write_all(&forwarded_headers).await {
        return Err(format!("http upstream write headers: {}", e));
    }
    if let Err(e) = stream.write_all(b"\r\n").await {
        return Err(format!("http upstream write blank: {}", e));
    }

    // Bridge body (request → upstream) and response (upstream → client) in
    // both directions until either side finishes. Connection: close on the
    // forwarded request makes the upstream close its half after one
    // response, which cascades to closing the client socket — exactly what
    // a non-pipelined HTTP proxy should do.
    pump_channel(&mut sock, &mut stream).await;
    emit_log(&app, &session_id, &tunnel_id, "info", "close",
             Some(target_full), Some(peer.to_string()), None);
    Ok(())
}

// ----- HTTP helpers ---------------------------------------------------------

/// Read bytes until a CRLF terminator (the line itself is returned without
/// the CRLF). Capped at `max` bytes to refuse a malicious client streaming
/// indefinitely.
async fn read_line_max(sock: &mut tokio::net::TcpStream, max: usize, deadline: tokio::time::Instant) -> std::io::Result<Vec<u8>> {
    let mut out = Vec::with_capacity(128);
    let mut b = [0u8; 1];
    let mut last_was_cr = false;
    loop {
        read_exact_by(sock, &mut b, deadline).await?;
        if b[0] == b'\n' && last_was_cr {
            out.pop(); // drop the trailing CR
            return Ok(out);
        }
        last_was_cr = b[0] == b'\r';
        out.push(b[0]);
        if out.len() > max {
            return Err(std::io::Error::new(std::io::ErrorKind::InvalidData, "http line too long"));
        }
    }
}

/// Consume header block (lines until an empty line). Total bytes capped at
/// `max`. Used by the CONNECT path where we don't need to parse, just skip
/// past the headers.
async fn consume_headers(sock: &mut tokio::net::TcpStream, max: usize, deadline: tokio::time::Instant) -> std::io::Result<()> {
    let mut total = 0usize;
    loop {
        let line = read_line_max(sock, max, deadline).await?;
        total = total.saturating_add(line.len() + 2);
        if line.is_empty() {
            return Ok(());
        }
        if total > max {
            return Err(std::io::Error::new(std::io::ErrorKind::InvalidData, "http headers too long"));
        }
    }
}

/// Read headers and return the raw bytes (each header line followed by
/// CRLF; terminator blank line is NOT included so the caller can substitute
/// its own rewritten header set + blank line).
async fn read_headers_raw(sock: &mut tokio::net::TcpStream, max: usize, deadline: tokio::time::Instant) -> std::io::Result<Vec<u8>> {
    let mut out = Vec::with_capacity(512);
    loop {
        let line = read_line_max(sock, max, deadline).await?;
        if line.is_empty() {
            return Ok(out);
        }
        if out.len() + line.len() + 2 > max {
            return Err(std::io::Error::new(std::io::ErrorKind::InvalidData, "http headers too long"));
        }
        out.extend_from_slice(&line);
        out.extend_from_slice(b"\r\n");
    }
}

/// Drop hop-by-hop and proxy-specific headers, and force Connection: close
/// on the forwarded request so the upstream tears down after one response
/// (saves us from having to demultiplex a keep-alive pipeline across
/// multiple destinations on the same client socket).
fn filter_and_rewrite_headers(raw: &[u8]) -> Vec<u8> {
    let mut out = Vec::with_capacity(raw.len());
    let mut saw_connection = false;
    for line in raw.split(|&b| b == b'\n') {
        let mut line = line;
        if line.last() == Some(&b'\r') {
            line = &line[..line.len() - 1];
        }
        if line.is_empty() { continue; }
        let lower = match std::str::from_utf8(line) {
            Ok(s) => s.to_ascii_lowercase(),
            Err(_) => continue, // skip non-utf8 garbage rather than relay it
        };
        // Hop-by-hop headers per RFC 7230 §6.1 + the proxy-* family.
        if lower.starts_with("proxy-connection:")
            || lower.starts_with("proxy-authenticate:")
            || lower.starts_with("proxy-authorization:")
            || lower.starts_with("keep-alive:")
            || lower.starts_with("te:")
            || lower.starts_with("trailers:")
            || lower.starts_with("upgrade:")
        {
            continue;
        }
        if lower.starts_with("connection:") {
            // Replace any Connection variant with `Connection: close`.
            saw_connection = true;
            out.extend_from_slice(b"Connection: close\r\n");
            continue;
        }
        out.extend_from_slice(line);
        out.extend_from_slice(b"\r\n");
    }
    if !saw_connection {
        out.extend_from_slice(b"Connection: close\r\n");
    }
    out
}

/// Parse `host:port` (IPv4, hostname, or `[ipv6]:port`).
fn parse_host_port(s: &str) -> Option<(String, u16)> {
    let s = s.trim();
    if let Some(stripped) = s.strip_prefix('[') {
        // IPv6 literal: [::1]:443
        let close = stripped.find(']')?;
        let host = &stripped[..close];
        let rest = &stripped[close + 1..];
        let port = rest.strip_prefix(':')?.parse::<u16>().ok()?;
        return Some((host.to_string(), port));
    }
    let (host, port) = s.rsplit_once(':')?;
    let port = port.parse::<u16>().ok()?;
    if host.is_empty() {
        return None;
    }
    Some((host.to_string(), port))
}

/// Parse an absolute-URI proxy request target (`http://host[:port]/path`)
/// into `(host, port, path)`. Returns None for anything that doesn't look
/// like an http(s) URI — we won't honour `file://`, `ftp://`, etc., so a
/// confused client gets a clean 400 instead of being silently rerouted.
fn parse_absolute_uri(uri: &str) -> Option<(String, u16, String)> {
    let (scheme, rest) = uri.split_once("://")?;
    let scheme = scheme.to_ascii_lowercase();
    let default_port: u16 = match scheme.as_str() {
        "http" => 80,
        "https" => 443,
        _ => return None,
    };
    let (authority, path) = match rest.find('/') {
        Some(i) => (&rest[..i], &rest[i..]),
        None => (rest, "/"),
    };
    // Authority may carry userinfo (`user:pass@host`) which we strip — the
    // proxy doesn't propagate that level of auth into the SSH channel.
    let authority = authority.rsplit_once('@').map(|x| x.1).unwrap_or(authority);
    let (host, port) = match authority.strip_prefix('[') {
        Some(rest) => {
            // [ipv6]:port — port optional
            let close = rest.find(']')?;
            let host = &rest[..close];
            let after = &rest[close + 1..];
            let port = if after.is_empty() {
                default_port
            } else {
                after.strip_prefix(':')?.parse::<u16>().ok()?
            };
            (host.to_string(), port)
        }
        None => {
            if let Some((host, port_s)) = authority.rsplit_once(':') {
                let port = port_s.parse::<u16>().ok()?;
                (host.to_string(), port)
            } else {
                (authority.to_string(), default_port)
            }
        }
    };
    if host.is_empty() {
        return None;
    }
    Some((host, port, path.to_string()))
}

/// SOCKS4 / SOCKS4a — CONNECT (cmd 0x01) only. The version byte has already
/// been consumed by handle_socks. Format: VN(consumed) CD(1) DSTPORT(2)
/// DSTIP(4) USERID(null-terminated). If DSTIP is 0.0.0.X (SOCKS4a marker),
/// the hostname follows USERID, also null-terminated.
async fn handle_socks4(
    handle: Arc<Mutex<russh::client::Handle<ClientHandler>>>,
    mut sock: tokio::net::TcpStream,
    peer: SocketAddr,
    app: AppHandle,
    session_id: String,
    tunnel_id: String,
) -> Result<(), String> {
    // One absolute deadline shared across BOTH NUL-terminated reads (userid +
    // optional SOCKS4a hostname) so the whole handshake is bounded regardless
    // of per-byte pacing — see read_exact_by.
    let hs_deadline = tokio::time::Instant::now() + HANDSHAKE_READ_TIMEOUT;
    let mut hdr = [0u8; 7]; // CD + DSTPORT(2) + DSTIP(4)
    read_exact_to(&mut sock, &mut hdr).await.map_err(|e| format!("socks4 read req: {}", e))?;
    let cmd = hdr[0];
    let port = u16::from_be_bytes([hdr[1], hdr[2]]);
    let ip = [hdr[3], hdr[4], hdr[5], hdr[6]];

    // Read userid (ignored — we don't authenticate) until NUL.
    let userid = read_until_nul(&mut sock, 256, hs_deadline).await
        .map_err(|e| format!("socks4 read userid: {}", e))?;
    let _ = userid;

    if cmd != 0x01 {
        // 0x5B = request rejected. SOCKS4 reply: VN(0) + CD(1) + ignored(6).
        let _ = sock.write_all(&[0x00, 0x5B, 0, 0, 0, 0, 0, 0]).await;
        return Err(format!("SOCKS4 command 0x{:02x} not supported (only CONNECT)", cmd));
    }

    // SOCKS4a hostname extension: DSTIP = 0.0.0.X with X != 0 → hostname
    // follows the userid, also NUL-terminated.
    let target_host = if ip[0] == 0 && ip[1] == 0 && ip[2] == 0 && ip[3] != 0 {
        let host_bytes = read_until_nul(&mut sock, 256, hs_deadline).await
            .map_err(|e| format!("socks4a read host: {}", e))?;
        String::from_utf8(host_bytes).map_err(|e| format!("socks4a host non-utf8: {}", e))?
    } else {
        format!("{}.{}.{}.{}", ip[0], ip[1], ip[2], ip[3])
    };

    let target_full = format!("{}:{}", target_host, port);
    emit_log(&app, &session_id, &tunnel_id, "info", "connect",
             Some(target_full.clone()), Some(peer.to_string()), Some("via SOCKS4".into()));

    let channel = open_channel_with_retry(
        &handle, &target_host, port as u32,
        &peer.ip().to_string(), peer.port() as u32,
    ).await;

    let channel = match channel {
        Ok(c) => {
            // 0x5A = request granted.
            sock.write_all(&[0x00, 0x5A, hdr[1], hdr[2], hdr[3], hdr[4], hdr[5], hdr[6]])
                .await
                .map_err(|e| format!("socks4 reply: {}", e))?;
            c
        }
        Err(e) => {
            let _ = sock.write_all(&[0x00, 0x5B, hdr[1], hdr[2], hdr[3], hdr[4], hdr[5], hdr[6]]).await;
            emit_log(&app, &session_id, &tunnel_id, "error", "fail",
                     Some(target_full), Some(peer.to_string()), Some(e.to_string()));
            return Err(format!("direct-tcpip {}:{} failed: {}", target_host, port, e));
        }
    };

    let mut stream = drained_stream(channel);
    pump_channel(&mut sock, &mut stream).await;
    emit_log(&app, &session_id, &tunnel_id, "info", "close",
             Some(target_full), Some(peer.to_string()), None);
    Ok(())
}

/// Read bytes from `sock` until either NUL or the cap is reached. Returns
/// everything BEFORE the NUL. Used to consume SOCKS4 USERID + the SOCKS4a
/// hostname extension, both of which are NUL-terminated and unbounded by
/// the spec — we cap at 256 bytes to refuse malicious clients trying to
/// stream forever.
async fn read_until_nul(sock: &mut tokio::net::TcpStream, max: usize, deadline: tokio::time::Instant) -> std::io::Result<Vec<u8>> {
    let mut out = Vec::with_capacity(32);
    let mut b = [0u8; 1];
    loop {
        read_exact_by(sock, &mut b, deadline).await?;
        if b[0] == 0 || out.len() >= max {
            break;
        }
        out.push(b[0]);
    }
    Ok(out)
}

/// SOCKS5 server: NO-AUTH greeting, CONNECT (cmd 0x01) only, IPv4 / IPv6 /
/// domain address types (domain mode is what SOCKS5h clients send — the
/// protocol doesn't have a separate version). Anything else gets a clean
/// error reply and the connection closes. The leading version byte was
/// already consumed by `handle_socks`.
async fn handle_socks5(
    handle: Arc<Mutex<russh::client::Handle<ClientHandler>>>,
    mut sock: tokio::net::TcpStream,
    peer: SocketAddr,
    app: AppHandle,
    session_id: String,
    tunnel_id: String,
) -> Result<(), String> {
    // --- Greeting (version already consumed by handle_socks) ---
    let mut nm = [0u8; 1];
    read_exact_to(&mut sock, &mut nm).await.map_err(|e| format!("read methods cnt: {}", e))?;
    let n_methods = nm[0] as usize;
    let mut methods = vec![0u8; n_methods];
    read_exact_to(&mut sock, &mut methods).await.map_err(|e| format!("read methods: {}", e))?;
    // Always reply NO-AUTH (0x00). If the client didn't offer it, send
    // 0xFF and close.
    if !methods.contains(&0x00) {
        sock.write_all(&[0x05, 0xFF]).await.ok();
        return Err("client requires authentication, none supported".into());
    }
    sock.write_all(&[0x05, 0x00]).await.map_err(|e| format!("write method ack: {}", e))?;

    // --- Request ---
    let mut req_hdr = [0u8; 4];
    read_exact_to(&mut sock, &mut req_hdr).await.map_err(|e| format!("read req hdr: {}", e))?;
    if req_hdr[0] != 0x05 {
        return Err(format!("unexpected SOCKS version {:#x}", req_hdr[0]));
    }
    let cmd = req_hdr[1];
    let atyp = req_hdr[3];
    if cmd != 0x01 {
        // 0x07 = command not supported
        let _ = sock.write_all(&[0x05, 0x07, 0x00, 0x01, 0, 0, 0, 0, 0, 0]).await;
        return Err(format!("unsupported SOCKS command {:#x}", cmd));
    }

    let target_host: String = match atyp {
        0x01 => {
            // IPv4
            let mut octets = [0u8; 4];
            read_exact_to(&mut sock, &mut octets).await.map_err(|e| format!("read v4: {}", e))?;
            format!("{}.{}.{}.{}", octets[0], octets[1], octets[2], octets[3])
        }
        0x03 => {
            // Domain
            let mut lenb = [0u8; 1];
            read_exact_to(&mut sock, &mut lenb).await.map_err(|e| format!("read dom len: {}", e))?;
            let mut name = vec![0u8; lenb[0] as usize];
            read_exact_to(&mut sock, &mut name).await.map_err(|e| format!("read dom: {}", e))?;
            String::from_utf8(name).map_err(|e| format!("non-utf8 host: {}", e))?
        }
        0x04 => {
            // IPv6 — let Ipv6Addr produce the canonical form (`::1`,
            // `2001:db8::1`, etc.) instead of the verbose
            // `0:0:0:0:0:0:0:1` shape. russh expects a normalised host
            // string when opening direct-tcpip channels.
            let mut octets = [0u8; 16];
            read_exact_to(&mut sock, &mut octets).await.map_err(|e| format!("read v6: {}", e))?;
            format!("[{}]", std::net::Ipv6Addr::from(octets))
        }
        other => {
            let _ = sock.write_all(&[0x05, 0x08, 0x00, 0x01, 0, 0, 0, 0, 0, 0]).await;
            return Err(format!("unsupported address type {:#x}", other));
        }
    };
    let mut port_buf = [0u8; 2];
    read_exact_to(&mut sock, &mut port_buf).await.map_err(|e| format!("read port: {}", e))?;
    let target_port = u16::from_be_bytes(port_buf);

    let target_full = format!("{}:{}", target_host, target_port);
    let via = match atyp {
        0x01 => "via SOCKS5 (IPv4)",
        0x03 => "via SOCKS5h (hostname)",
        0x04 => "via SOCKS5 (IPv6)",
        _ => "via SOCKS5",
    };
    emit_log(&app, &session_id, &tunnel_id, "info", "connect",
             Some(target_full.clone()), Some(peer.to_string()), Some(via.into()));

    // --- Open the SSH direct-tcpip channel ---
    let channel = open_channel_with_retry(
        &handle, &target_host, target_port as u32,
        &peer.ip().to_string(), peer.port() as u32,
    ).await;

    let channel = match channel {
        Ok(c) => {
            // 0x00 = success. The bound address fields are filled with zeros —
            // most SOCKS clients ignore them.
            sock.write_all(&[0x05, 0x00, 0x00, 0x01, 0, 0, 0, 0, 0, 0])
                .await
                .map_err(|e| format!("write reply: {}", e))?;
            c
        }
        Err(e) => {
            // 0x05 = connection refused (best general-purpose code)
            let _ = sock.write_all(&[0x05, 0x05, 0x00, 0x01, 0, 0, 0, 0, 0, 0]).await;
            emit_log(&app, &session_id, &tunnel_id, "error", "fail",
                     Some(target_full), Some(peer.to_string()), Some(e.to_string()));
            return Err(format!("direct-tcpip {}:{} failed: {}", target_host, target_port, e));
        }
    };

    let mut stream = drained_stream(channel);
    pump_channel(&mut sock, &mut stream).await;
    emit_log(&app, &session_id, &tunnel_id, "info", "close",
             Some(target_full), Some(peer.to_string()), None);
    Ok(())
}

#[cfg(test)]
mod tunnel_tests {
    use super::{bind_with_retry, drained_stream, drained_stream_with_cap, pump_bidirectional_with_idle, pump_channel};
    use super::{clean_name, rule_removed, rule_renamed, rule_started, rule_stopped, TunnelSpec};
    use crate::ssh_test_server::{connect, TestServer};
    use std::sync::atomic::Ordering;
    use std::time::{Duration, Instant};
    use tokio::io::{AsyncReadExt, AsyncWriteExt};

    fn spec(kind: &str, local: &str, remote: &str) -> TunnelSpec {
        serde_json::from_value(serde_json::json!({ "type": kind, "local": local, "remote": remote })).unwrap()
    }

    #[test]
    fn rules_saved_before_names_and_stopping_read_and_save_as_they_were() {
        let old = r#"[{"type":"L","local":"8080","remote":"db:5432"},{"type":"D","local":"1080","remote":""}]"#;
        let rules: Vec<TunnelSpec> = serde_json::from_str(old).unwrap();
        assert!(rules.iter().all(|rule| rule.name.is_none() && !rule.stopped));
        // Unchanged rules are saved byte for byte as before, so an older
        // version reading them sees nothing new.
        assert_eq!(serde_json::to_string(&rules).unwrap(), old);
        // The node form keeps a row id of its own in the same objects.
        let with_row_id: TunnelSpec =
            serde_json::from_str(r#"{"rid":"t-1","type":"L","local":"8080","remote":"db:5432"}"#).unwrap();
        assert_eq!(with_row_id, rules[0]);
    }

    #[test]
    fn a_name_and_a_stop_are_saved_with_the_rule() {
        let mut rule = spec("L", "8080", "db:5432");
        rule.name = Some("database".into());
        rule.stopped = true;
        let json = serde_json::to_string(&rule).unwrap();
        assert_eq!(json, r#"{"type":"L","local":"8080","remote":"db:5432","name":"database","stopped":true}"#);
        let back: TunnelSpec = serde_json::from_str(&json).unwrap();
        assert_eq!(back.name.as_deref(), Some("database"));
        assert!(back.stopped);
    }

    #[test]
    fn a_forward_is_the_same_one_whatever_its_name_or_state() {
        let mut named = spec("L", "8080", "db:5432");
        named.name = Some("database".into());
        named.stopped = true;
        assert_eq!(named, spec("L", "8080", "db:5432"));
        assert_ne!(spec("L", "8080", "db:5432"), spec("L", "8081", "db:5432"));
        assert_ne!(spec("L", "8080", "db:5432"), spec("L", "8080", "db:5433"));
        assert_ne!(spec("L", "8080", "x:1"), spec("R", "8080", "x:1"));
    }

    #[test]
    fn a_name_is_kept_trimmed_and_short_and_none_when_blank() {
        assert_eq!(clean_name(Some("  web admin  ")).as_deref(), Some("web admin"));
        assert_eq!(clean_name(Some("   ")), None);
        assert_eq!(clean_name(Some("")), None);
        assert_eq!(clean_name(None), None);
        let long = "ü".repeat(100);
        assert_eq!(clean_name(Some(&long)).unwrap().chars().count(), 64);
        // Cutting at 64 can leave a space at the end; it goes too.
        let spaced = format!("{} tail", "a".repeat(63));
        assert_eq!(clean_name(Some(&spaced)).unwrap(), "a".repeat(63));
    }

    #[test]
    fn stopping_keeps_the_rule_and_starting_brings_it_back() {
        let mut rules = vec![spec("D", "1080", ""), spec("L", "8080", "db:5432")];
        rules[1].name = Some("database".into());

        rule_stopped(&mut rules, &spec("L", "8080", "db:5432"));
        assert_eq!(rules.len(), 2, "a stop keeps the rule");
        assert!(rules[1].stopped && !rules[0].stopped);
        assert_eq!(rules[1].name.as_deref(), Some("database"));

        // Started again without a name: the rule keeps the one it has.
        rule_started(&mut rules, &spec("L", "8080", "db:5432"));
        assert_eq!(rules.len(), 2, "no duplicate");
        assert!(!rules[1].stopped);
        assert_eq!(rules[1].name.as_deref(), Some("database"));

        // A new forward is added at the end, running, with its name.
        let mut new = spec("R", "9000", "localhost:22");
        new.name = Some("back in".into());
        new.stopped = true; // whatever the caller sent, a started rule runs
        rule_started(&mut rules, &new);
        assert_eq!(rules.len(), 3);
        assert!(!rules[2].stopped);
        assert_eq!(rules[2].name.as_deref(), Some("back in"));
    }

    #[test]
    fn removing_and_renaming_touch_only_that_rule() {
        let mut rules = vec![spec("D", "1080", ""), spec("L", "8080", "db:5432")];
        assert!(rule_renamed(&mut rules, &spec("D", "1080", ""), Some(" socks ")));
        assert_eq!(rules[0].name.as_deref(), Some("socks"));
        assert!(rule_renamed(&mut rules, &spec("D", "1080", ""), Some("")));
        assert_eq!(rules[0].name, None, "an empty name takes the name away");
        assert!(!rule_renamed(&mut rules, &spec("D", "1081", ""), Some("x")), "no such rule");

        assert!(rule_removed(&mut rules, &spec("L", "8080", "db:5432")));
        assert_eq!(rules, vec![spec("D", "1080", "")]);
        assert!(!rule_removed(&mut rules, &spec("L", "8080", "db:5432")), "already gone");
    }

    /// Round-trip a few bytes on a NEW channel of `session` — only possible
    /// while russh's protocol task for the connection is not blocked.
    async fn echo_round_trip(session: &russh::client::Handle<crate::ssh_test_server::TestClient>) {
        let channel = session.channel_open_session().await.unwrap();
        channel.exec(false, "echo").await.unwrap();
        let mut echo = drained_stream(channel);
        echo.write_all(b"ping").await.unwrap();
        let mut buf = [0u8; 4];
        echo.read_exact(&mut buf).await.unwrap();
        assert_eq!(&buf, b"ping");
    }

    // B2: with a plain `ChannelStream`, a bridge whose local peer stops reading
    // stops reading its channel; the channel's bounded queue fills and russh's
    // protocol task blocks on it, freezing EVERY channel of the connection. A
    // drained stream keeps accepting the data, so the rest of the connection
    // stays usable — and the stalled peer still gets every byte once it resumes.
    #[tokio::test]
    async fn drained_stream_keeps_the_connection_usable_while_a_local_peer_stalls() {
        const DOWNLOAD: usize = 16 * 1024 * 1024; // far more than a channel queue holds
        let session = connect(TestServer::default(), |_| {}, crate::build_ssh_client_config())
            .await
            .expect("in-process SSH connection");
        let download = session.channel_open_session().await.unwrap();
        download.exec(false, format!("flood {}", DOWNLOAD)).await.unwrap();
        // Nobody reads it for now — the paused local client.
        let mut download = drained_stream(download);

        tokio::time::timeout(Duration::from_secs(60), async {
            while download.queued.load(Ordering::SeqCst) < DOWNLOAD {
                tokio::time::sleep(Duration::from_millis(20)).await;
            }
        })
        .await
        .expect("the whole download must be drained off the connection");
        tokio::time::timeout(Duration::from_secs(10), echo_round_trip(&session))
            .await
            .expect("other channels must keep working while one local peer stalls");

        // The peer resumes: every byte, then EOF.
        let mut got = Vec::new();
        tokio::time::timeout(Duration::from_secs(30), download.read_to_end(&mut got))
            .await
            .expect("download completes")
            .unwrap();
        assert_eq!(got.len(), DOWNLOAD);
    }

    // Past the backlog cap the stalled bridge is cut at once — rather than
    // holding the backlog until the idle watchdog fires while the server keeps
    // sending — and only that bridge: the connection stays healthy.
    #[tokio::test]
    async fn a_local_peer_stalled_past_the_cap_cuts_only_its_own_bridge() {
        let session = connect(TestServer::default(), |_| {}, crate::build_ssh_client_config())
            .await
            .expect("in-process SSH connection");
        let channel = session.channel_open_session().await.unwrap();
        channel.exec(false, "flood 67108864").await.unwrap();
        let mut stream = drained_stream_with_cap(channel, 1024 * 1024);
        // The local side of the bridge: a peer that never reads.
        let (_stalled_peer, mut local) = tokio::io::duplex(64 * 1024);
        tokio::time::timeout(Duration::from_secs(30), pump_channel(&mut local, &mut stream))
            .await
            .expect("the bridge must be cut once the backlog passes the cap");
        drop(stream);
        tokio::time::timeout(Duration::from_secs(10), echo_round_trip(&session))
            .await
            .expect("the SSH connection itself must stay usable");
    }

    // ProxyJump: the target session's russh protocol task stops reading its
    // transport (the bastion's direct-tcpip channel) while a write waits for
    // the bastion's window. With a plain `ChannelStream` the target's output
    // then fills that channel's queue, the bastion connection's protocol task
    // blocks on it — and never delivers the window adjust the write waits
    // for: the whole jumped session deadlocks (reproduced with this exact
    // setup). The always-drained transport keeps it moving.
    #[tokio::test]
    async fn a_drained_proxyjump_transport_does_not_deadlock_on_upload_plus_output() {
        let bastion_server = TestServer::default();
        let target_received = std::sync::Arc::clone(&bastion_server.jump_target_received);
        // Small bastion window: the target session's writes keep waiting on it.
        let bastion = connect(bastion_server, |c| c.window_size = 64 * 1024, crate::build_ssh_client_config())
            .await
            .expect("bastion connection");
        let hop = bastion
            .channel_open_direct_tcpip("target", 22, "127.0.0.1", 0)
            .await
            .unwrap();
        // Same transport lib.rs hands the target session for a ProxyJump hop.
        let target = crate::ssh_test_server::client_over(
            drained_stream(hop),
            crate::build_ssh_client_config(),
            crate::ssh_test_server::TestClient::default(),
        )
        .await
        .expect("target session through the jump host");

        // The target floods output (drained, like the terminal pump would) ...
        let output = target.channel_open_session().await.unwrap();
        output.exec(false, "flood 268435456").await.unwrap();
        let mut output = drained_stream(output);
        tokio::spawn(async move {
            let mut buf = vec![0u8; 64 * 1024];
            while matches!(output.read(&mut buf).await, Ok(n) if n > 0) {}
        });
        // ... while we upload far more than the bastion's window.
        const UPLOAD: usize = 4 * 1024 * 1024;
        let upload = target.channel_open_session().await.unwrap();
        tokio::spawn(async move { upload.data_bytes(vec![b'u'; UPLOAD]).await });

        tokio::time::timeout(Duration::from_secs(60), async {
            while target_received.load(Ordering::SeqCst) < UPLOAD {
                tokio::time::sleep(Duration::from_millis(20)).await;
            }
        })
        .await
        .expect("the upload must reach the target while its output keeps flowing (no deadlock)");
    }

    // The reconnect fix: a bind that hits a transient AddrInUse (the previous
    // listener still releasing the port during a reconnect) must succeed once
    // the port frees, instead of failing and letting the caller drop the tunnel.
    #[tokio::test]
    async fn bind_with_retry_succeeds_once_the_port_frees() {
        let l = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let port = l.local_addr().unwrap().port();
        let addr = format!("127.0.0.1:{}", port);
        // Free the port partway through the retry window.
        tokio::spawn(async move {
            tokio::time::sleep(Duration::from_millis(400)).await;
            drop(l);
        });
        let got = tokio::time::timeout(Duration::from_secs(3), bind_with_retry(&addr))
            .await
            .expect("must not hang")
            .expect("must bind once the port frees");
        assert_eq!(got.local_addr().unwrap().port(), port);
    }

    // If the port never frees, it must give up cleanly (Err) rather than hang —
    // the caller keeps the spec and retries on the next reconnect.
    #[tokio::test]
    async fn bind_with_retry_gives_up_if_port_stays_taken() {
        let l = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let port = l.local_addr().unwrap().port();
        let addr = format!("127.0.0.1:{}", port);
        let r = tokio::time::timeout(Duration::from_secs(5), bind_with_retry(&addr))
            .await
            .expect("must return, not hang");
        assert!(r.is_err(), "must give up when the port never frees");
        drop(l);
    }

    // The pump must relay bytes in BOTH directions (it didn't break the copy
    // semantics) and finish cleanly when both ends close (EOF), not hang.
    #[tokio::test]
    async fn pump_relays_both_directions_and_finishes_on_eof() {
        let (mut ca, mut a) = tokio::io::duplex(64);
        let (mut cb, mut b) = tokio::io::duplex(64);
        let pump = tokio::spawn(async move {
            pump_bidirectional_with_idle(&mut a, &mut b, Duration::from_secs(30)).await;
        });

        // a-side client -> b-side client
        ca.write_all(b"ping").await.unwrap();
        let mut buf = [0u8; 4];
        cb.read_exact(&mut buf).await.unwrap();
        assert_eq!(&buf, b"ping");

        // b-side client -> a-side client
        cb.write_all(b"pong").await.unwrap();
        let mut buf2 = [0u8; 4];
        ca.read_exact(&mut buf2).await.unwrap();
        assert_eq!(&buf2, b"pong");

        // Both clients close -> pump sees EOF on both halves and returns.
        drop(ca);
        drop(cb);
        tokio::time::timeout(Duration::from_secs(5), pump)
            .await
            .expect("pump must finish on EOF, not hang")
            .unwrap();
    }

    // The core fix: a connection whose ends never close (no EOF) and never move
    // a byte must be REAPED after the idle window, freeing its permit — instead
    // of parking forever like the old bare copy_bidirectional.
    #[tokio::test]
    async fn pump_reaps_a_silent_connection() {
        let (ca, mut a) = tokio::io::duplex(64);
        let (cb, mut b) = tokio::io::duplex(64);
        let idle = Duration::from_millis(300);
        let start = Instant::now();
        // Clients are kept ALIVE (not dropped) for the whole call, so there is
        // no EOF — the only way this returns is the idle timeout.
        tokio::time::timeout(
            Duration::from_secs(5),
            pump_bidirectional_with_idle(&mut a, &mut b, idle),
        )
        .await
        .expect("a silent connection must be reaped by the idle timeout, not hang");
        assert!(start.elapsed() >= idle, "must not reap before the idle window elapses");
        drop(ca);
        drop(cb);
    }

    // The don't-break-active guarantee: while traffic keeps flowing (each byte
    // resets the idle window), the pump must NOT reap the connection.
    #[tokio::test]
    async fn pump_keeps_an_active_connection_open() {
        let (mut ca, mut a) = tokio::io::duplex(1024);
        let (mut cb, mut b) = tokio::io::duplex(1024);
        let idle = Duration::from_millis(300);
        let pump = tokio::spawn(async move {
            pump_bidirectional_with_idle(&mut a, &mut b, idle).await;
        });

        // One byte every 100ms (< idle) for ~1s — well past the idle window in
        // wall-clock time, but never idle for a full window.
        for _ in 0..10 {
            ca.write_all(b"x").await.unwrap();
            let mut buf = [0u8; 1];
            cb.read_exact(&mut buf).await.unwrap();
            tokio::time::sleep(Duration::from_millis(100)).await;
        }
        assert!(!pump.is_finished(), "an actively-used connection must not be reaped");

        // Stop traffic -> pump reaps (via EOF once we drop, or idle) and ends.
        drop(ca);
        drop(cb);
        tokio::time::timeout(Duration::from_secs(5), pump)
            .await
            .expect("pump must finish after traffic stops")
            .unwrap();
    }
}
