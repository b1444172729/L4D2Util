package com.tenglong.iappreverse;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    private static final int REQ_PICK = 0x51;

    private Button btnPick, btnExport;
    private ProgressBar progress;
    private TextView tvStatus, tvBadge, tvSummary, tvPreview;
    private LinearLayout cardResult, cardFiles, listFiles;

    private final Handler ui = new Handler(Looper.getMainLooper());

    private String workFolder = null;
    private String zipPath = null;
    private String apkName = "";

    private final List<String> fileNames = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnPick = findViewById(R.id.btn_pick);
        btnExport = findViewById(R.id.btn_export);
        progress = findViewById(R.id.progress);
        tvStatus = findViewById(R.id.tv_status);
        tvBadge = findViewById(R.id.tv_badge);
        tvSummary = findViewById(R.id.tv_summary);
        tvPreview = findViewById(R.id.tv_preview);
        cardResult = findViewById(R.id.card_result);
        cardFiles = findViewById(R.id.card_files);
        listFiles = findViewById(R.id.list_files);

        btnPick.setOnClickListener(v -> pickApk());
        btnExport.setOnClickListener(v -> exportZip());
    }

    

    private void pickApk() {
        String err = launchPicker(Intent.ACTION_OPEN_DOCUMENT);
        if (err == null) return;
        err = launchPicker(Intent.ACTION_GET_CONTENT);
        if (err == null) return;
        toast("打不开文件选择器：" + err);
    }

    private String launchPicker(String action) {
        Intent i = new Intent(action);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        try {
            startActivityForResult(i, REQ_PICK);
            return null;
        } catch (Exception e) {
            return e.getMessage() == null ? e.toString() : e.getMessage();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_PICK || resultCode != RESULT_OK || data == null || data.getData() == null) {
            return;
        }
        final Uri uri = data.getData();
        apkName = queryName(uri);

        cardResult.setVisibility(View.GONE);
        cardFiles.setVisibility(View.GONE);
        btnExport.setVisibility(View.GONE);
        zipPath = null;
        workFolder = null;
        listFiles.removeAllViews();
        fileNames.clear();

        status("正在读取 " + apkName + " …", true);

        new Thread(() -> {
            try {
                File cacheDir = new File(getCacheDir(), "apk");
                if (!cacheDir.exists() && !cacheDir.mkdirs()) {
                    throw new RuntimeException("缓存目录创建失败");
                }
                File local = new File(cacheDir, "input.apk");
                copy(uri, local);

                File outDir = new File(getFilesDir(), "out");
                if (outDir.exists()) deleteTree(outDir);
                if (!outDir.mkdirs() && !outDir.isDirectory()) {
                    throw new RuntimeException("输出目录创建失败");
                }

                ui.post(() -> status("正在分析结构 …", true));

                Python py = Python.getInstance();
                PyObject mod = py.getModule("iapp_app");
                String json = mod.callAttr("process", local.getAbsolutePath(),
                        outDir.getAbsolutePath()).toString();
                JSONObject obj = new JSONObject(json);

                if (!obj.optBoolean("ok")) {
                    String err = obj.optString("error", "未知错误");
                    ui.post(() -> {
                        status("没还原出来：" + err, false);
                        toast("还原失败");
                    });
                    return;
                }

                final String kind = obj.optString("kind", "");
                final String report = obj.optString("report", "");
                final String zip = obj.optString("zip", "");
                final String folder = obj.optString("folder", "");
                JSONArray files = obj.optJSONArray("files");

                List<String> names = new ArrayList<>();
                List<Long> sizes = new ArrayList<>();
                if (files != null) {
                    for (int k = 0; k < files.length(); k++) {
                        JSONObject f = files.getJSONObject(k);
                        names.add(f.optString("name"));
                        sizes.add(f.optLong("size"));
                    }
                }

                ui.post(() -> {
                    workFolder = folder;
                    zipPath = zip;
                    renderResult(kind, report, names, sizes);
                    status("完成：" + names.size() + " 个文件", false);
                });

            } catch (Throwable t) {
                ui.post(() -> {
                    status("出错了：" + t.getMessage(), false);
                    toast("出错了");
                });
            }
        }).start();
    }

    private String queryName(Uri uri) {
        try (android.database.Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) return c.getString(idx);
            }
        } catch (Exception ignored) {
        }
        String p = uri.getLastPathSegment();
        return p == null ? "input.apk" : p;
    }

    private void copy(Uri uri, File dest) throws Exception {
        try (InputStream in = getContentResolver().openInputStream(uri);
             OutputStream out = new FileOutputStream(dest)) {
            if (in == null) throw new RuntimeException("读取不到文件");
            byte[] buf = new byte[1 << 20];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
            }
        }
    }

    

    private void renderResult(String kind, String report, List<String> names, List<Long> sizes) {
        String badge;
        switch (kind == null ? "" : kind) {
            case "libso":
                badge = "加密包 · assets/lib.so";
                break;
            case "web":
                badge = "网页工程 · Vue 源码";
                break;
            case "java":
                badge = "编译型 · dex 字节码";
                break;
            default:
                badge = "未识别的包型";
        }
        tvBadge.setText(badge);

        StringBuilder sb = new StringBuilder();
        for (String line : report.split("\n")) {
            String t = line.trim();
            if (t.isEmpty()) continue;
            if (t.startsWith("===") || t.startsWith("腾龙逆源")) continue;
            if (t.startsWith("应用：") || t.startsWith("包：") || t.startsWith("类型：")
                    || t.startsWith("- ") || t.startsWith("【输入】") || t.startsWith("【结果】")
                    || t.startsWith("【判定】") || t.startsWith("算法族") || t.startsWith("还原文件")) {
                sb.append(t).append('\n');
            } else if (t.startsWith("说明") || t.startsWith("模式")) {
                sb.append(t).append('\n');
            }
        }
        if (sb.length() == 0) sb.append("还原完成");
        tvSummary.setText(sb.toString().trim());

        cardResult.setVisibility(View.VISIBLE);

        listFiles.removeAllViews();
        fileNames.clear();
        if (names.isEmpty()) {
            cardFiles.setVisibility(View.GONE);
            return;
        }

        for (int i = 0; i < names.size(); i++) {
            final String name = names.get(i);
            long size = i < sizes.size() ? sizes.get(i) : 0;
            fileNames.add(name);

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(dp(10), dp(11), dp(10), dp(11));
            row.setBackground(getDrawable(R.drawable.code_bg));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.bottomMargin = dp(6);
            row.setLayoutParams(lp);

            TextView t = new TextView(this);
            t.setText(name);
            t.setTextColor(0xFFD3E2FF);
            t.setTextSize(12.5f);
            t.setSingleLine(true);
            t.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
            t.setLayoutParams(new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            row.addView(t);

            TextView s = new TextView(this);
            s.setText(human(size));
            s.setTextColor(0xFF6E82A6);
            s.setTextSize(11f);
            row.addView(s);

            row.setOnClickListener(v -> showPreview(name));
            listFiles.addView(row);
        }

        cardFiles.setVisibility(View.VISIBLE);
        if (zipPath != null && !zipPath.isEmpty()) {
            btnExport.setVisibility(View.VISIBLE);
        }
    }

    private void showPreview(String name) {
        if (workFolder == null) return;
        new Thread(() -> {
            String text;
            try {
                PyObject mod = Python.getInstance().getModule("iapp_app");
                text = mod.callAttr("preview", workFolder, name, 3000).toString();
            } catch (Throwable t) {
                text = "";
            }
            final String out = (text == null || text.isEmpty())
                    ? "（这个文件没法直接预览，导出 zip 看吧）" : text;
            ui.post(() -> {
                tvPreview.setText(out);
                tvPreview.setVisibility(View.VISIBLE);
                ScrollView parent = (ScrollView) tvPreview.getParent().getParent();
                parent.smoothScrollTo(0, tvPreview.getTop());
            });
        }).start();
    }

    

    private void exportZip() {
        if (zipPath == null || zipPath.isEmpty()) {
            toast("还没有可导出的结果");
            return;
        }
        File src = new File(zipPath);
        if (!src.isFile()) {
            toast("结果包不见了，重新解一次吧");
            return;
        }
        String name = src.getName();
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.Downloads.DISPLAY_NAME, name);
                cv.put(MediaStore.Downloads.MIME_TYPE, "application/zip");
                cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (uri == null) throw new RuntimeException("创建下载项失败");
                try (OutputStream out = getContentResolver().openOutputStream(uri);
                     FileInputStream in = new FileInputStream(src)) {
                    if (out == null) throw new RuntimeException("写入失败");
                    byte[] buf = new byte[1 << 16];
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                }
                toast("已保存到 下载/" + name);
            } else {
                File dl = new File(Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_DOWNLOADS), name);
                try (FileInputStream in = new FileInputStream(src);
                     FileOutputStream out = new FileOutputStream(dl)) {
                    byte[] buf = new byte[1 << 16];
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                }
                toast("已保存到 " + dl.getAbsolutePath());
            }
        } catch (Throwable t) {
            toast("导出失败：" + t.getMessage());
        }
    }

    

    private void status(String text, boolean busy) {
        tvStatus.setText(text);
        tvStatus.setVisibility(View.VISIBLE);
        progress.setVisibility(busy ? View.VISIBLE : View.GONE);
        btnPick.setEnabled(!busy);
        btnPick.setAlpha(busy ? 0.55f : 1f);
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    private int dp(int v) {
        return Math.round(getResources().getDisplayMetrics().density * v);
    }

    private String human(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format("%.1f KB", bytes / 1024f);
        return String.format("%.1f MB", bytes / 1048576f);
    }

    private void deleteTree(File f) {
        if (f == null || !f.exists()) return;
        File[] kids = f.listFiles();
        if (kids != null) {
            for (File k : kids) deleteTree(k);
        }
        
        f.delete();
    }

    public void onNav(View v) {
        int id = v.getId();
        if (id == R.id.znav1) {
            applyPage(0);
        } else if (id == R.id.znav2) {
            applyPage(1);
        } else {
            applyPage(2);
        }
    }

    public void applyPage(int index) {
        View[] pages = {findViewById(R.id.zpage_main), findViewById(R.id.zpage_guide), findViewById(R.id.zpage_about)};
        TextView[] navs = {findViewById(R.id.znav1), findViewById(R.id.znav2), findViewById(R.id.znav3)};
        for (int i = 0; i < pages.length; i++) {
            if (pages[i] != null) {
                pages[i].setVisibility(i == index ? View.VISIBLE : View.GONE);
            }
        }
        for (int i = 0; i < navs.length; i++) {
            TextView t = navs[i];
            if (t == null) {
                continue;
            }
            t.setBackgroundResource(i == index ? R.drawable.zz_seg_on : 0);
            t.setTextColor(i == index ? 0xFFDCE9FF : 0xFF6F83A6);
        }
    }
}
