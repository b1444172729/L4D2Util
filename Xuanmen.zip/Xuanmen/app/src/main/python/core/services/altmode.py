from __future__ import annotations

import re
import struct
import zipfile
from typing import Dict, List, Optional, Tuple

WEB_MARKERS = (b"main.iyu.js", b"lib/iapp.js", b"lib/app.js")
LIBRARY_PREFIXES = (
    "android/", "androidx/", "kotlin/", "kotlinx/", "com/google/", "com/android/",
    "java/", "javax/", "dalvik/", "org/intellij/", "org/jetbrains/", "i6/",
    "okhttp3/", "okio/", "org/apache/", "com/bumptech/", "io/reactivex/",
    "org/json/", "com/airbnb/", "com/facebook/", "org/slf4j/", "com/squareup/",
    "org/greenrobot/", "com/tencent/", "com/alibaba/", "org/xmlpull/",
)


def detect_kind(apk_bytes: bytes) -> Tuple[str, Dict[str, str]]:
    try:
        zf = zipfile.ZipFile(__import__("io").BytesIO(apk_bytes))
    except Exception:
        return "unknown", {"error": "不是有效的 APK/ZIP"}

    names = zf.namelist()
    low = {n.lower(): n for n in names}

    info: Dict[str, str] = {}
    if "assets/lib.so" in low:
        info["入口"] = "assets/lib.so（加密源码包）"
        info["说明"] = "加密型工程，走 lib.so 解密链"
        return "libso", info

    web_hits = [n for n in names if n.startswith("assets/") and
                (n.endswith(".iyu.js") or n in ("assets/lib/iapp.js", "assets/lib/app.js"))]
    if web_hits:
        info["入口"] = "、".join(sorted(web_hits)[:4])
        info["说明"] = "网页(Vue)工程，源码明文存放在 assets"
        return "web", info

    dex_names = [n for n in names if re.fullmatch(r"classes\d*\.dex", n)]
    dexans = []
    for dn in dex_names:
        try:
            dexans.append(zf.read(dn))
        except Exception:
            pass
    proj = project_packages(dexans)
    if proj:
        info["入口"] = "classes.dex（编译型）"
        info["说明"] = "Java 编译模式工程，源码已编译为字节码"
        info["工程包"] = "、".join(proj[:6])
        return "java", info

    info["说明"] = "没找到 iApp 的工程区（既没有 assets/lib.so，也没有网页工程）"
    return "unknown", info



def extract_web_project(apk_bytes: bytes) -> Tuple[Dict[str, bytes], Dict[str, str]]:
    zf = zipfile.ZipFile(__import__("io").BytesIO(apk_bytes))
    files: Dict[str, bytes] = {}
    for n in zf.namelist():
        if not n.startswith("assets/"):
            continue
        if n.endswith("/"):
            continue
        if n.startswith("assets/dexopt/"):
            continue
        rel = n[len("assets/"):]
        try:
            files[rel] = zf.read(n)
        except Exception:
            continue

    pages = [k for k in files if k.endswith(".iyu.js")]
    info = {
        "模式": "网页(Vue)工程",
        "页面": "、".join(sorted(pages)) or "-",
        "文件数": str(len(files)),
    }
    return files, info



def project_packages(dex_list: List[bytes]) -> List[str]:
    found: Dict[str, int] = {}
    for dex in dex_list:
        try:
            d = DexFile(dex)
        except Exception:
            continue
        for cd in d.class_defs():
            name = d.type_name(cd["class_idx"])
            if not name.startswith("L"):
                continue
            path = name[1:-1]
            if any(path.startswith(p) for p in LIBRARY_PREFIXES):
                continue
            pkg = path.rsplit("/", 1)[0] if "/" in path else ""
            if not pkg:
                continue
            found[pkg] = found.get(pkg, 0) + 1
    return [p for p, c in sorted(found.items(), key=lambda kv: -kv[1]) if c >= 1]


def _app_packages(d: "DexFile") -> set:
    pkgs: set = set()
    for cd in d.class_defs():
        name = d.type_name(cd["class_idx"])
        if not name.startswith("L"):
            continue
        path = name[1:-1]
        if any(path.startswith(p) for p in LIBRARY_PREFIXES):
            continue
        pkg = path.rsplit("/", 1)[0] if "/" in path else ""
        if not pkg or len(pkg.split("/")[-1]) <= 2:
            continue
        sup = d.type_name(cd["super_idx"]) if cd["super_idx"] != 0xFFFFFFFF else ""
        if sup.startswith("Li6/"):
            pkgs.add(pkg)
            continue
        try:
            if cd["source_idx"] != 0xFFFFFFFF and cd["source_idx"] < d.string_ids_size:
                src = d.string(cd["source_idx"])
                if src.lower() in ("mian.java", "mian.iyu", "main.java"):
                    pkgs.add(pkg)
        except Exception:
            pass
    return pkgs


def extract_java_project(apk_bytes: bytes) -> Tuple[Dict[str, bytes], Dict[str, str]]:
    import io
    zf = zipfile.ZipFile(io.BytesIO(apk_bytes))
    dexes = []
    for n in sorted(zf.namelist()):
        if re.fullmatch(r"classes\d*\.dex", n):
            dexes.append((n, zf.read(n)))

    files: Dict[str, bytes] = {}
    total = 0
    kept_pkgs: List[str] = []
    for dz_name, data in dexes:
        try:
            d = DexFile(data)
        except Exception:
            continue
        pkgs = _app_packages(d)
        kept_pkgs.extend(sorted(pkgs))
        for cd in d.class_defs():
            full = d.type_name(cd["class_idx"])
            if not full.startswith("L"):
                continue
            path = full[1:-1]
            pkg = path.rsplit("/", 1)[0] if "/" in path else ""
            if pkg not in pkgs:
                continue
            try:
                text = d.disassemble(cd)
            except Exception as exc:
                text = f"# 反汇编失败：{exc}\n.class {full}\n"
            files[path.replace("/", "_") + ".smali"] = text.encode("utf-8")
            total += 1

    info = {
        "模式": "Java 编译型工程",
        "用户类": str(total),
        "工程包": "、".join(sorted(set(kept_pkgs))) or "-",
        "说明": "源码已抽成 smali，可读可重新编译；需要 Java 源码可用 jadx 打开 dex",
    }
    return files, info



class DexFile:
    def __init__(self, data: bytes):
        self.data = data
        if data[:4] != b"dex\n":
            raise ValueError("not a dex")
        u = lambda off: struct.unpack_from("<I", data, off)[0]
        self.string_ids_size, self.string_ids_off = u(0x38), u(0x3C)
        self.type_ids_size, self.type_ids_off = u(0x40), u(0x44)
        self.proto_ids_size, self.proto_ids_off = u(0x48), u(0x4C)
        self.field_ids_size, self.field_ids_off = u(0x50), u(0x54)
        self.method_ids_size, self.method_ids_off = u(0x58), u(0x5C)
        self.class_defs_size, self.class_defs_off = u(0x60), u(0x64)
        self._strings: Dict[int, str] = {}

    def string(self, idx: int) -> str:
        if idx in self._strings:
            return self._strings[idx]
        off = struct.unpack_from("<I", self.data, self.string_ids_off + idx * 4)[0]
        p = off
        _, p = self.uleb(p)
        end = self.data.index(b"\x00", p)
        raw = self.data[p:end]
        try:
            s = raw.decode("utf-8", "replace")
        except Exception:
            s = raw.decode("latin-1", "replace")
        self._strings[idx] = s
        return s

    def type_name(self, idx: int) -> str:
        sidx = struct.unpack_from("<I", self.data, self.type_ids_off + idx * 4)[0]
        return self.string(sidx)

    def proto(self, idx: int) -> str:
        off = self.proto_ids_off + idx * 12
        ret_idx, params_off = struct.unpack_from("<II", self.data, off + 4)
        ret = self.type_name(ret_idx)
        params = ""
        if params_off:
            size = struct.unpack_from("<I", self.data, params_off)[0]
            parts = [self.type_name(struct.unpack_from("<H", self.data, params_off + 4 + i * 2)[0])
                     for i in range(size)]
            params = "".join(parts)
        return f"({params}){ret}"

    def field(self, idx: int) -> str:
        off = self.field_ids_off + idx * 8
        cidx, tidx = struct.unpack_from("<HH", self.data, off)
        nidx = struct.unpack_from("<I", self.data, off + 4)[0]
        return f"{self.type_name(cidx)}->{self.string(nidx)}:{self.type_name(tidx)}"

    def method(self, idx: int) -> str:
        off = self.method_ids_off + idx * 8
        cidx, pidx = struct.unpack_from("<HH", self.data, off)
        nidx = struct.unpack_from("<I", self.data, off + 4)[0]
        return f"{self.type_name(cidx)}->{self.string(nidx)}{self.proto(pidx)}"

    def _field_decl(self, idx: int) -> str:
        off = self.field_ids_off + idx * 8
        cidx, tidx = struct.unpack_from("<HH", self.data, off)
        nidx = struct.unpack_from("<I", self.data, off + 4)[0]
        return f"{self.string(nidx)}:{self.type_name(tidx)}"

    def _method_decl(self, idx: int) -> str:
        off = self.method_ids_off + idx * 8
        cidx, pidx = struct.unpack_from("<HH", self.data, off)
        nidx = struct.unpack_from("<I", self.data, off + 4)[0]
        return f"{self.string(nidx)}{self.proto(pidx)}"

    def uleb(self, p: int) -> Tuple[int, int]:
        result = shift = 0
        while True:
            b = self.data[p]
            p += 1
            result |= (b & 0x7F) << shift
            if not (b & 0x80):
                break
            shift += 7
        return result, p

    def class_defs(self):
        out = []
        for i in range(self.class_defs_size):
            base = self.class_defs_off + i * 32
            (cidx, flags, sidx, ifaces, src_idx,
             anno, cdata_off, static_vals) = struct.unpack_from("<IIIIIIII", self.data, base)
            out.append({
                "class_idx": cidx, "access": flags, "super_idx": sidx,
                "source_idx": src_idx, "class_data_off": cdata_off,
            })
        return out

    def _class_data(self, off: int):
        if not off:
            return [], [], [], []
        p = off
        sf, p = self.uleb(p)
        inf, p = self.uleb(p)
        dm, p = self.uleb(p)
        vm, p = self.uleb(p)

        def read_fields(count, p):
            res, idx = [], 0
            for _ in range(count):
                diff, p = self.uleb(p)
                flags, p = self.uleb(p)
                idx += diff
                res.append((idx, flags))
            return res, p

        def read_methods(count, p):
            res, idx = [], 0
            for _ in range(count):
                diff, p = self.uleb(p)
                flags, p = self.uleb(p)
                code, p = self.uleb(p)
                idx += diff
                res.append((idx, flags, code))
            return res, p

        sfields, p = read_fields(sf, p)
        ifields, p = read_fields(inf, p)
        dmethods, p = read_methods(dm, p)
        vmethods, p = read_methods(vm, p)
        return sfields, ifields, dmethods, vmethods

    def disassemble(self, cd: dict) -> str:
        name = self.type_name(cd["class_idx"])
        super_name = self.type_name(cd["super_idx"]) if cd["super_idx"] != 0xFFFFFFFF else ""
        access = " ".join(_access_flags(cd["access"]))
        lines = [f".class {access} {name}".replace("  ", " ")]
        if super_name:
            lines.append(f".super {super_name}")
        if cd["source_idx"] != 0xFFFFFFFF and cd["source_idx"] < self.string_ids_size:
            try:
                lines.append(f'.source "{self.string(cd["source_idx"])}"')
            except Exception:
                pass

        sfields, ifields, dmethods, vmethods = self._class_data(cd["class_data_off"])
        for idx, flags in sfields:
            lines.append("")
            lines.append(f".field {' '.join(_access_flags(flags))} {self._field_decl(idx)}")
            lines[-1] = lines[-1].replace("  ", " ")
        for idx, flags in ifields:
            lines.append("")
            lines.append(f".field {' '.join(_access_flags(flags))} {self._field_decl(idx)}")
            lines[-1] = lines[-1].replace("  ", " ")

        for idx, flags, code_off in dmethods + vmethods:
            lines.append("")
            lines.append(f".method {' '.join(_access_flags(flags))} {self._method_decl(idx)}")
            lines[-1] = lines[-1].replace("  ", " ")
            if code_off:
                try:
                    lines.extend(self.disassemble_code(code_off))
                except Exception as exc:
                    lines.append(f"    # 代码段解码失败: {exc}")
            lines.append(".end method")
        lines.append("")
        return "\n".join(lines)

    def disassemble_code(self, code_off: int) -> List[str]:
        registers, ins, outs, tries = struct.unpack_from("<HHHH", self.data, code_off)
        insns_size = struct.unpack_from("<I", self.data, code_off + 12)[0]
        p = code_off + 16
        insns = struct.unpack_from(f"<{insns_size}H", self.data, p)
        self._reg_total = registers
        self._ins_size = ins
        out = [f"    .registers {registers}"]
        i = 0
        while i < len(insns):
            op = insns[i] & 0xFF
            mnemonic, fmt, kind = _OPCODES.get(op, ("nop", "10x", None))
            try:
                text, used = self._decode(i, insns, op, mnemonic, fmt, kind)
            except Exception:
                text, used = f"#bad-op {op:#x}", 1
            out.append(f"    {text}")
            i += used
        return out

    def _r(self, idx: int) -> str:
        total = getattr(self, "_reg_total", 0)
        ins = getattr(self, "_ins_size", 0)
        if ins and idx >= total - ins:
            return f"p{idx - (total - ins)}"
        return f"v{idx}"

    def _decode(self, i: int, insns, op, mnemonic, fmt, kind):
        u0 = insns[i]
        R = self._r
        def u(n):
            return insns[i + n] if i + n < len(insns) else 0
        def s16(v):
            return v - 0x10000 if v & 0x8000 else v
        def s32(v):
            return v - 0x100000000 if v & 0x80000000 else v

        if fmt == "10x":
            return mnemonic, 1
        if fmt == "12x":
            return f"{mnemonic} {R(u0 >> 8 & 0xF)}, {R(u0 >> 12 & 0xF)}", 1
        if fmt == "11n":
            b = (u0 >> 12) & 0xF
            b = b - 16 if b & 0x8 else b
            return f"{mnemonic} {R(u0 >> 8 & 0xF)}, {hex(b) if b >= 0 else '-0x%x' % -b}", 1
        if fmt == "11x":
            return f"{mnemonic} {R(u0 >> 8 & 0xFF)}", 1
        if fmt == "10t":
            off = (u0 >> 8) & 0xFF
            off = off - 256 if off & 0x80 else off
            return f"{mnemonic} :label_{i + off}", 1
        if fmt == "20t":
            return f"{mnemonic} :label_{i + s16(u(1))}", 2
        if fmt == "30t":
            return f"{mnemonic} :label_{i + s32(u(1) | (u(2) << 16))}", 3
        if fmt == "22x":
            return f"{mnemonic} {R(u0 >> 8 & 0xFF)}, {R(u(1))}", 2
        if fmt == "32x":
            return f"{mnemonic} {R(u(1))}, {R(u(2))}", 3
        if fmt == "21t":
            return f"{mnemonic} {R(u0 >> 8 & 0xFF)}, :label_{i + s16(u(1))}", 2
        if fmt == "21s":
            v = s16(u(1))
            return f"{mnemonic} {R(u0 >> 8 & 0xFF)}, {hex(v) if v >= 0 else '-0x%x' % -v}", 2
        if fmt == "21h":
            return f"{mnemonic} {R(u0 >> 8 & 0xFF)}, #{s16(u(1)) << 16}", 2
        if fmt == "31i":
            v = s32(u(1) | (u(2) << 16))
            return f"{mnemonic} {R(u0 >> 8 & 0xFF)}, {hex(v) if v >= 0 else '-0x%x' % -v}", 3
        if fmt == "51l":
            val = u(1) | (u(2) << 16) | (u(3) << 32) | (u(4) << 48)
            if val & (1 << 63):
                val -= 1 << 64
            return f"{mnemonic} {R(u0 >> 8 & 0xFF)}, #{val}", 5
        if fmt == "21c":
            return f"{mnemonic} {R(u0 >> 8 & 0xFF)}, {self._ref(kind, u(1))}", 2
        if fmt == "31c":
            return f"{mnemonic} {R(u0 >> 8 & 0xFF)}, {self._ref(kind, u(1) | (u(2) << 16))}", 3
        if fmt == "22c":
            return f"{mnemonic} {R(u0 >> 8 & 0xF)}, {R(u0 >> 12 & 0xF)}, {self._ref(kind, u(1))}", 2
        if fmt == "22t":
            return f"{mnemonic} {R(u0 >> 8 & 0xF)}, {R(u0 >> 12 & 0xF)}, :label_{i + s16(u(1))}", 2
        if fmt == "22s":
            v = s16(u(1))
            return f"{mnemonic} {R(u0 >> 8 & 0xF)}, {R(u0 >> 12 & 0xF)}, {hex(v) if v >= 0 else '-0x%x' % -v}", 2
        if fmt == "22b":
            cc = (u(1) >> 8) & 0xFF
            cc = cc - 256 if cc & 0x80 else cc
            return f"{mnemonic} {R(u0 >> 8 & 0xFF)}, {R(u(1) & 0xFF)}, #{cc}", 2
        if fmt == "23x":
            return f"{mnemonic} {R(u0 >> 8 & 0xFF)}, {R(u(1) & 0xFF)}, {R(u(1) >> 8 & 0xFF)}", 2
        if fmt == "35c":
            count = u0 >> 12
            u2 = u(2)
            regs = [u2 & 0xF, (u2 >> 4) & 0xF, (u2 >> 8) & 0xF, (u2 >> 12) & 0xF, (u0 >> 8) & 0xF][:count]
            ref = self._ref(kind or "method", u(1))
            return f"{mnemonic} {{{', '.join(R(r) for r in regs)}}}, {ref}", 3
        if fmt == "3rc":
            count = u0 >> 8 & 0xFF
            first = u(2)
            regs = ", ".join(R(first + k) for k in range(count))
            ref = self._ref(kind or "method", u(1))
            return f"{mnemonic} {{{regs}}}, {ref}", 3
        return mnemonic, 1

    def _ref(self, kind, idx):
        if kind == "string":
            return f'"{self.string(idx)}"'
        if kind == "type":
            return self.type_name(idx)
        if kind == "field":
            return self.field(idx)
        if kind == "method":
            return self.method(idx)
        return str(idx)


_ACC = [
    (0x1, "public"), (0x2, "private"), (0x4, "protected"), (0x8, "static"),
    (0x10, "final"), (0x20, "synchronized"), (0x40, "volatile"), (0x80, "transient"),
    (0x100, "native"), (0x200, "interface"), (0x400, "abstract"), (0x1000, "synthetic"),
    (0x2000, "annotation"), (0x4000, "enum"), (0x10000, "constructor"),
    (0x20000, "declared-synchronized"),
]


def _access_flags(flags: int) -> List[str]:
    return [n for bit, n in _ACC if flags & bit]


def _build_opcodes() -> Dict[int, Tuple[str, str, Optional[str]]]:
    t: Dict[int, Tuple[str, str, Optional[str]]] = {}
    def add(start, names, fmt, kind=None):
        for k, n in enumerate(names):
            t[start + k] = (n, fmt, kind)

    t[0x00] = ("nop", "10x", None)
    add(0x01, ["move", "move/from16", "move/16", "move-wide", "move-wide/from16",
               "move-wide/16", "move-object", "move-object/from16", "move-object/16"],
        "12x")
    t[0x02] = ("move/from16", "22x", None)
    t[0x03] = ("move/16", "32x", None)
    t[0x05] = ("move-wide/from16", "22x", None)
    t[0x06] = ("move-wide/16", "32x", None)
    t[0x08] = ("move-object/from16", "22x", None)
    t[0x09] = ("move-object/16", "32x", None)
    add(0x0A, ["move-result", "move-result-wide", "move-result-object", "move-exception"], "11x")
    add(0x0E, ["return-void", "return", "return-wide", "return-object"], "11x")
    t[0x0E] = ("return-void", "10x", None)
    t[0x12] = ("const/4", "11n", None)
    t[0x13] = ("const/16", "21s", None)
    t[0x14] = ("const", "31i", None)
    t[0x15] = ("const/high16", "21h", None)
    t[0x16] = ("const-wide/16", "21s", None)
    t[0x17] = ("const-wide/32", "31i", None)
    t[0x18] = ("const-wide", "51l", None)
    t[0x19] = ("const-wide/high16", "21h", None)
    t[0x1A] = ("const-string", "21c", "string")
    t[0x1B] = ("const-string/jumbo", "31c", "string")
    t[0x1C] = ("const-class", "21c", "type")
    add(0x1D, ["monitor-enter", "monitor-exit"], "11x")
    t[0x1F] = ("check-cast", "21c", "type")
    t[0x20] = ("instance-of", "22c", "type")
    t[0x21] = ("array-length", "12x", None)
    t[0x22] = ("new-instance", "21c", "type")
    t[0x23] = ("new-array", "22c", "type")
    t[0x24] = ("filled-new-array", "35c", "type")
    t[0x25] = ("filled-new-array/range", "3rc", "type")
    t[0x26] = ("fill-array-data", "31t", None)
    t[0x27] = ("throw", "11x", None)
    t[0x28] = ("goto", "10t", None)
    t[0x29] = ("goto/16", "20t", None)
    t[0x2A] = ("goto/32", "30t", None)
    t[0x2B] = ("packed-switch", "31t", None)
    t[0x2C] = ("sparse-switch", "31t", None)
    add(0x2D, ["cmpl-float", "cmpg-float", "cmpl-double", "cmpg-double", "cmp-long"], "23x")
    add(0x32, ["if-eq", "if-ne", "if-lt", "if-ge", "if-gt", "if-le"], "22t")
    add(0x38, ["if-eqz", "if-nez", "if-ltz", "if-gez", "if-gtz", "if-lez"], "21t")
    add(0x44, ["aget", "aget-wide", "aget-object", "aget-boolean", "aget-byte",
               "aget-char", "aget-short"], "23x")
    add(0x4B, ["aput", "aput-wide", "aput-object", "aput-boolean", "aput-byte",
               "aput-char", "aput-short"], "23x")
    add(0x52, ["iget", "iget-wide", "iget-object", "iget-boolean", "iget-byte",
               "iget-char", "iget-short"], "22c", "field")
    add(0x59, ["iput", "iput-wide", "iput-object", "iput-boolean", "iput-byte",
               "iput-char", "iput-short"], "22c", "field")
    add(0x60, ["sget", "sget-wide", "sget-object", "sget-boolean", "sget-byte",
               "sget-char", "sget-short"], "21c", "field")
    add(0x67, ["sput", "sput-wide", "sput-object", "sput-boolean", "sput-byte",
               "sput-char", "sput-short"], "21c", "field")
    inv = ["invoke-virtual", "invoke-super", "invoke-direct", "invoke-static", "invoke-interface"]
    for k, n in enumerate(inv):
        t[0x6E + k] = (n, "35c", "method")
    for k, n in enumerate(inv):
        t[0x74 + k] = (n + "/range", "3rc", "method")
    add(0x7B, ["neg-int", "not-int", "neg-long", "not-long", "neg-float", "neg-double",
               "int-to-long", "int-to-float", "int-to-double", "long-to-int", "long-to-float",
               "long-to-double", "float-to-int", "float-to-long", "float-to-double",
               "double-to-int", "double-to-long", "double-to-float", "int-to-byte",
               "int-to-char", "int-to-short"], "12x")
    binops = ["add", "sub", "mul", "div", "rem", "and", "or", "xor", "shl", "shr", "ushr"]
    typs = ["int", "long", "float", "double"]
    idx = 0x90
    for op in binops:
        for ty in typs:
            t[idx] = (f"{op}-{ty}", "23x", None); idx += 1
    t[0xA0] = ("add-int", "23x", None)
    idx = 0xB0
    for op in binops:
        for ty in typs:
            t[idx] = (f"{op}-{ty}/2addr", "12x", None); idx += 1
    idx = 0xD0
    for op in binops:
        t[idx] = (f"{op}-int/lit16", "22s", None); idx += 1
    t[0xE3] = ("add-int/lit8", "22b", None)
    idx = 0xD8
    for op in binops:
        t[idx] = (f"{op}-int/lit8", "22b", None); idx += 1
    t[0xFA] = ("invoke-polymorphic", "35c", "method")
    t[0xFB] = ("invoke-polymorphic/range", "3rc", "method")
    t[0xFC] = ("invoke-custom", "35c", "method")
    t[0xFD] = ("invoke-custom/range", "3rc", "method")
    t[0xFE] = ("const-method-handle", "21c", "method")
    t[0xFF] = ("const-method-type", "21c", "method")
    return t


_OPCODES = _build_opcodes()
