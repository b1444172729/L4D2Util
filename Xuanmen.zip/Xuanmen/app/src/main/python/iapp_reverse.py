from __future__ import annotations

import argparse
import base64
import io
import json
import os
import re
import shutil
import sys
import time
import traceback
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE / "core"))

from config import MAX_TOTAL_SECONDS
from algorithms.common import DecryptConfig, normalize_member_name
from services.apk_extract import ApkExtractor
from services.decrypt import build_response
from services import altmode

VERSION = "1.0"
OUT_ROOT = BASE / "out"

SOURCE_EXTS = (".iyu", ".myu", ".ilua", ".mlua", ".ijava", ".mjava",
               ".ijs", ".mjs", ".java", ".yul", ".html", ".xml", ".txt", ".mrs")


@dataclass
class Inputs:
    lib_so: bytes
    native_so: Optional[bytes]
    sok: Optional[str]
    dek: Optional[str]
    package_name: str
    version_name: str
    version_code: str
    app_name: str
    sign_b64: Optional[str] = None
    sign_md5: Optional[str] = None
    native_so_name: Optional[str] = None
    lib_so_name: str = "lib.so"
    notes: List[str] = field(default_factory=list)
    dek_candidates: List[str] = field(default_factory=list)
    sok_candidates: List[str] = field(default_factory=list)

    def summary(self) -> dict:
        return {
            "加密源码包": f"{self.lib_so_name} ({len(self.lib_so)} 字节)",
            "原生库": f"{self.native_so_name or '-'} ({len(self.native_so) if self.native_so else 0} 字节)",
            "sok": self.sok or "未取到",
            "dek": self.dek or "未取到",
            "包名": self.package_name,
            "版本": f"{self.version_name} ({self.version_code})",
            "应用名": self.app_name,
            "签名": "已取到" if (self.sign_b64 or self.sign_md5) else "未取到",
        }


def extract_from_apk(apk_bytes: bytes) -> Inputs:
    raw = ApkExtractor.extract_all(apk_bytes)
    notes: List[str] = []

    lib_b64 = raw.get("lib_so_base64")
    if not lib_b64:
        raise ValueError("这个包里没有 assets/lib.so —— 不是 iApp 打包的 APK，或者源码被作者挖掉了")
    lib_so = base64.b64decode(lib_b64)

    native_b64 = raw.get("native_so_base64")
    native_so = base64.b64decode(native_b64) if native_b64 else None

    def clean(v, fallback=""):
        v = (v or "").strip()
        return v if v and v != "N/A" else fallback

    package = clean(raw.get("package_name"), "com.unknown")
    vname = clean(raw.get("version_name"), "1.0")
    vcode = clean(raw.get("version_code"), "1")
    app_name = clean(raw.get("app_name"), package.split(".")[-1])

    sok = raw.get("sok")
    dek = raw.get("dek")
    if not sok:
        notes.append("没有从 libygsiyu.so 里取到 sok，可能被加壳或换了库名")
    if not dek:
        notes.append("没有从 dex 里取到 dek，可能被加固 / dex 被抽走")

    return Inputs(
        lib_so=lib_so,
        native_so=native_so,
        sok=str(sok) if sok else None,
        dek=str(dek) if dek else None,
        package_name=package,
        version_name=vname,
        version_code=str(vcode),
        app_name=app_name,
        sign_b64=raw.get("sign_b64"),
        sign_md5=raw.get("sign_key"),
        native_so_name=raw.get("native_so_name"),
        lib_so_name=raw.get("lib_so_name") or "lib.so",
        notes=notes,
        dek_candidates=gather_dek_candidates(apk_bytes),
        sok_candidates=gather_sok_candidates(native_so),
    )


_HEX_RE = re.compile(r"^[0-9a-fA-F]{16,80}$")
_SOK_RE = re.compile(rb"[A-Za-z0-9]{10}Q{10}W{10}EE")


def dex_string_pool(dex: bytes, cap: int = 400000) -> List[str]:
    import struct
    if len(dex) < 112 or not dex.startswith(b"dex\n"):
        return []
    try:
        str_size, str_off = struct.unpack_from("<II", dex, 56)
    except struct.error:
        return []
    if str_size > cap or str_off + str_size * 4 > len(dex):
        return []
    out: List[str] = []
    for i in range(str_size):
        try:
            (off,) = struct.unpack_from("<I", dex, str_off + i * 4)
            p = off
            while p < len(dex) and dex[p] & 0x80:
                p += 1
            p += 1
            end = dex.index(b"\x00", p)
            out.append(dex[p:end].decode("utf-8", errors="ignore"))
        except Exception:
            continue
    return out


def gather_dek_candidates(apk_bytes: bytes, limit: int = 10) -> List[str]:
    cands: List[str] = []
    seen = set()
    try:
        with zipfile.ZipFile(io.BytesIO(apk_bytes)) as zf:
            names = [n for n in zf.namelist() if n.endswith(".dex")]
            names.sort(key=lambda n: (n != "classes.dex", n))
            for name in names[:6]:
                for text in dex_string_pool(zf.read(name)):
                    t = text.strip()
                    if not _HEX_RE.match(t):
                        continue
                    key = t.lower()
                    if key in seen:
                        continue
                    seen.add(key)
                    cands.append(t)
    except Exception:
        return []
    cands.sort(key=lambda v: (len(v) != 32, len(v) != 16, -len(v)))
    return cands[:limit]


def gather_sok_candidates(native_so: Optional[bytes], limit: int = 6) -> List[str]:
    if not native_so:
        return []
    out, seen = [], set()
    for m in _SOK_RE.finditer(native_so):
        s = m.group(0).decode("ascii", errors="ignore")
        if s not in seen:
            seen.add(s)
            out.append(s)
    marker = native_so.find(b"\x00aa\x00lib.so")
    if marker >= 4:
        s = native_so[marker - 4:marker].decode("ascii", errors="ignore")
        if len(s) == 4 and s.isprintable() and s not in seen:
            out.append(s)
    return out[:limit]


def decrypt(inputs: Inputs, mode: str = "auto",
            post_key: Optional[bytes] = None,
            xor_key: Optional[bytes] = None,
            pwd_key: str = "") -> dict:
    def build(sok: str, dek: str) -> dict:
        cfg = DecryptConfig(
            package_name=inputs.package_name,
            version_name=inputs.version_name,
            version_code=str(inputs.version_code),
            app_name=inputs.app_name,
            sok=sok,
            dek=dek,
            entry_file="mian.iyu",
            sign_key=inputs.sign_md5 or "",
            sign_b64=inputs.sign_b64 or "",
            pwd_key=pwd_key,
        )
        t0 = time.time()
        out = build_response(
            inputs.lib_so, cfg,
            native_so=inputs.native_so,
            mode=mode,
            manual_post_key=post_key,
            manual_xor_key=xor_key,
        )
        out["elapsed"] = round(time.time() - t0, 2)
        out["resolved_sok"] = sok
        out["resolved_dek"] = dek
        return out

    sok_list = [s for s in [inputs.sok] + list(inputs.sok_candidates) if s]
    dek_list = [d for d in [inputs.dek] + list(inputs.dek_candidates) if d]
    if not sok_list:
        raise ValueError("missing decrypt fields: sok（没拿到 so 里的 key）")
    if not dek_list:
        raise ValueError("missing decrypt fields: dek（没从 dex 里拿到密钥常量）")

    first_error: Optional[Exception] = None
    tried = 0
    total_started = time.monotonic()
    for sok in sok_list[:4]:
        for dek in dek_list[:8]:
            tried += 1
            spent = time.monotonic() - total_started
            if spent > MAX_TOTAL_SECONDS:
                raise RuntimeError(
                    f"解密总时长已超限（{spent:.0f}s，试了 {tried} 组 sok/dek 组合）。"
                    f"这个包的 sok 或 dek 大概率取不到，或密钥与已知候选不匹配。"
                )
            print("[TL] decrypt combo %d/%d sok=%s dek=%s" % (tried, min(32, len(sok_list)*len(dek_list)), sok[:12], dek[:12]), flush=True)
            try:
                res = build(sok, dek)
                res["attempts"] = tried
                return res
            except Exception as exc:
                if first_error is None:
                    first_error = exc
                continue
    raise first_error or RuntimeError("decrypt failed")


def _safe_name(text: str) -> str:
    text = re.sub(r'[\\/:*?"<>|\r\n\t]+', "_", (text or "").strip())
    return (text[:60] or "iapp_output").strip("._ ") or "iapp_output"


def save_result(inputs: Inputs, res: dict, out_dir: Path) -> Tuple[Path, Path]:
    tag = _safe_name(f"{inputs.app_name}_{inputs.version_name}")
    folder = out_dir / tag
    files_dir = folder / "files"
    if folder.exists():
        shutil.rmtree(folder, ignore_errors=True)
    files_dir.mkdir(parents=True, exist_ok=True)

    files: Dict[str, str] = res.get("files") or {}
    for name, content in files.items():
        rel = name.replace("\\", "/").lstrip("/")
        target = files_dir / rel
        try:
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(content, encoding="utf-8", errors="replace")
        except OSError:
            safe = _safe_name(rel)
            (files_dir / safe).write_text(content, encoding="utf-8", errors="replace")

    report = _build_report(inputs, res)
    (folder / "report.txt").write_text(report, encoding="utf-8")

    zip_path = out_dir / f"{tag}.zip"
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for p in folder.rglob("*"):
            if p.is_file():
                zf.write(p, p.relative_to(folder).as_posix())
    return folder, zip_path


def _build_report(inputs: Inputs, res: dict) -> str:
    st = res.get("strategy") or {}
    files = res.get("files") or {}
    failed = res.get("failed") or []
    lines = [
        "腾龙逆源 v" + VERSION + "  解密报告",
        "=" * 46,
        f"应用：{inputs.app_name}    包名：{inputs.package_name}",
        f"版本：{inputs.version_name} ({inputs.version_code})",
        "",
        "【输入】",
    ]
    for k, v in inputs.summary().items():
        lines.append(f"  {k}：{v}")
    for note in inputs.notes:
        lines.append(f"  ! {note}")

    lines += [
        "",
        "【结果】",
        f"  算法族：{st.get('algorithm_family') or '-'}",
        f"  外层候选：{st.get('candidate') or '-'}",
        f"  密钥组：{st.get('key_set') or '-'}",
        f"  成员策略：{st.get('member_strategy') or '-'}",
        f"  外层密钥：{st.get('outer_key_hex') or '-'}",
        f"  post_key：{st.get('post_key_hex') or '-'}",
        f"  xor_key：{st.get('xor_key_hex') or '-'}",
        f"  尝试次数：{st.get('tried_count')}（候选 {st.get('candidate_count')} × 密钥组 {st.get('key_set_count')}）",
        f"  耗时：{res.get('elapsed')} 秒",
        f"  还原文件：{len(files)} 个",
    ]
    for name in sorted(files):
        lines.append(f"    - {name}（{len(files[name])} 字符）")
    if failed:
        lines.append(f"  失败成员：{len(failed)} 个")
        for item in failed[:30]:
            lines.append(f"    x {item.get('name')}：{item.get('error')}")
    lines += [
        "",
        "【说明】",
        "  解出来的是 iApp 工程源码，用 iApp 开发工具打开对应文件即可继续编辑/导出工程。",
        "  若只还原出部分成员，多半是那部分用了不同族的加密或密钥，把 report 发我继续追。",
    ]
    return "\n".join(lines)


def save_generic(apk_name: str, kind: str, info: dict, files: dict, out_dir: Path) -> dict:
    stem = _safe_name(Path(apk_name).stem)
    tag = _safe_name(f"{stem}_{ 'web' if kind == 'web' else 'java' }")
    folder = out_dir / tag
    files_dir = folder / "files"
    if folder.exists():
        shutil.rmtree(folder, ignore_errors=True)
    files_dir.mkdir(parents=True, exist_ok=True)

    for name, content in files.items():
        rel = name.replace("\\", "/").lstrip("/")
        target = files_dir / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        if isinstance(content, bytes):
            target.write_bytes(content)
        else:
            target.write_text(content, encoding="utf-8", errors="replace")

    lines = [
        "腾龙逆源 v" + VERSION + "  还原报告",
        "=" * 46,
        f"包：{apk_name}",
        f"类型：{info.get('模式') or kind}",
        "",
        "【判定】",
    ]
    for k, v in info.items():
        lines.append(f"  {k}：{v}")
    lines += ["", "【结果】", f"  还原文件：{len(files)} 个"]
    for name in sorted(files):
        size = len(files[name])
        lines.append(f"    - {name}（{size} 字节）")
    if kind == "java":
        lines += [
            "",
            "【说明】",
            "  这是 iApp 的 Java 编译模式工程，导出时源码被直接编译进 classes.dex，",
            "  包里不存在 iyu 源文件。上面给的是逐类反汇编出来的 smali，可读、可回编译。",
            "  需要 Java 源码的话，用 jadx 打开同一个 apk 即可看到近似 Java。",
        ]
    else:
        lines += [
            "",
            "【说明】",
            "  这是 iApp 的网页(Vue)工程模式，assets 里的 .iyu.js 就是页面源码，",
            "  属于明文，直接拿去编辑即可。",
        ]
    (folder / "report.txt").write_text("\n".join(lines), encoding="utf-8")

    zip_path = out_dir / f"{tag}.zip"
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for fp in folder.rglob("*"):
            if fp.is_file():
                zf.write(fp, fp.relative_to(folder).as_posix())
    return {"ok": True, "name": apk_name, "folder": str(folder), "zip": str(zip_path),
            "files": len(files), "family": kind, "elapsed": 0}


def process_file(path: Path, mode: str = "auto", out_dir: Path = OUT_ROOT) -> dict:
    print("[TL] stage:read " + str(path), flush=True)
    data = path.read_bytes()
    print("[TL] stage:detect size=" + str(len(data)), flush=True)
    kind, info = altmode.detect_kind(data)
    if kind == "web":
        files, meta = altmode.extract_web_project(data)
        meta.update({k: v for k, v in info.items() if k not in meta})
        return save_generic(path.name, "web", meta, files, out_dir)
    if kind == "java":
        files, meta = altmode.extract_java_project(data)
        meta.update({k: v for k, v in info.items() if k not in meta})
        return save_generic(path.name, "java", meta, files, out_dir)

    print("[TL] stage:extract kind=" + str(kind), flush=True)
    inputs = extract_from_apk(data)
    print("[TL] stage:decrypt start lib=" + str(len(getattr(inputs, "lib_so", b"") or b"")) +
          " sok=" + str(len(getattr(inputs, "sok", "") or "")) +
          " dek=" + str(len(getattr(inputs, "dek", "") or "")), flush=True)
    res = decrypt(inputs, mode=mode)
    print("[TL] stage:save", flush=True)
    folder, zip_path = save_result(inputs, res, out_dir)
    return {"ok": True, "name": path.name, "folder": str(folder),
            "zip": str(zip_path), "files": len(res.get("files") or {}),
            "family": (res.get("strategy") or {}).get("algorithm_family"),
            "elapsed": res.get("elapsed")}


def manual_mode(args) -> int:
    lib = Path(args.lib).read_bytes()
    inputs = Inputs(
        lib_so=lib,
        native_so=Path(args.native).read_bytes() if args.native else None,
        sok=args.sok,
        dek=args.dek,
        package_name=args.package,
        version_name=args.vname,
        version_code=str(args.vcode),
        app_name=args.app or args.package,
    )
    res = decrypt(inputs, mode=args.mode,
                  post_key=bytes.fromhex(args.post_key) if args.post_key else None,
                  xor_key=bytes.fromhex(args.xor_key) if args.xor_key else None,
                  pwd_key=args.pwd or "")
    folder, zip_path = save_result(inputs, res, Path(args.out).resolve())
    print(f"[OK] {len(res.get('files') or {})} 个文件 -> {folder}")
    print(f"[OK] 打包 -> {zip_path}")
    return 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=f"腾龙逆源 v{VERSION} —— iApp 加密包解密/源码还原")
    ap.add_argument("target", nargs="?", help="APK 文件或目录（配 --batch）")
    ap.add_argument("--batch", action="store_true", help="批量处理目录里的所有 apk")
    ap.add_argument("-o", "--out", default=str(OUT_ROOT), help="输出目录")
    ap.add_argument("--mode", default="auto",
                    choices=["auto", "current", "legacy", "legacy4", "transitional"],
                    help="算法族，默认 auto 自动判断")
    ap.add_argument("--gui", action="store_true", help="打开图形界面")
    ap.add_argument("--lib", help="assets/lib.so 路径（手动模式）")
    ap.add_argument("--native", help="libygsiyu.so 路径（可选，用来提 key）")
    ap.add_argument("--sok"), ap.add_argument("--dek")
    ap.add_argument("--package"), ap.add_argument("--vname", default="1.0")
    ap.add_argument("--vcode", default="1"), ap.add_argument("--app")
    ap.add_argument("--post-key", dest="post_key", help="手动 post_key（hex）")
    ap.add_argument("--xor-key", dest="xor_key", help="手动 xor_key（hex）")
    ap.add_argument("--pwd", help="iApp 用户加密密码（设了密码的工程才要）")
    args = ap.parse_args(argv)

    if args.gui:
        import gui_server
        gui_server.run()
        return 0

    if args.lib:
        if not (args.sok and args.dek and args.package):
            print("[X] 手动模式至少要给 --sok --dek --package")
            return 2
        return manual_mode(args)

    if not args.target:
        ap.print_help()
        return 2

    out_dir = Path(args.out).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    targets: List[Path] = []
    p = Path(args.target)
    if p.is_dir():
        targets = sorted(p.glob("*.apk")) + sorted(p.glob("*.APK"))
    else:
        targets = [p]
    if not targets:
        print("[X] 没找到 apk")
        return 2

    ok = 0
    for item in targets:
        print(f"\n=== {item.name} ===")
        try:
            r = process_file(item, mode=args.mode, out_dir=out_dir)
            ok += 1
            print(f"[OK] {r['files']} 个源码文件  算法族={r['family']}  耗时={r['elapsed']}s")
            print(f"     源码目录：{r['folder']}")
            print(f"     打包文件：{r['zip']}")
        except Exception as exc:
            print(f"[X] {item.name} 解密失败：{exc}")
            if os.environ.get("IAPP_DEBUG"):
                traceback.print_exc()
    print(f"\n完成 {ok}/{len(targets)}")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
