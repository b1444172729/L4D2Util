import json
import os
import sys
import traceback

BASE = os.path.dirname(os.path.abspath(__file__))
if BASE not in sys.path:
    sys.path.insert(0, BASE)

import iapp_reverse as core
from services import altmode

VERSION = "2.0"


def _walk(folder):
    out = []
    for root, _dirs, files in os.walk(folder):
        for f in sorted(files):
            p = os.path.join(root, f)
            out.append({
                "name": os.path.relpath(p, folder).replace("\\", "/"),
                "size": os.path.getsize(p),
            })
    return sorted(out, key=lambda x: x["name"])


def detect(apk_path):
    try:
        with open(apk_path, "rb") as f:
            data = f.read()
        kind, info = altmode.detect_kind(data)
        return json.dumps({"ok": True, "kind": kind, "info": info}, ensure_ascii=False)
    except Exception:
        return json.dumps({"ok": False, "error": traceback.format_exc(limit=2)},
                          ensure_ascii=False)


def process(apk_path, out_root):
    try:
        os.makedirs(out_root, exist_ok=True)
        from pathlib import Path
        res = core.process_file(Path(apk_path), out_dir=Path(out_root))
        folder = res.get("folder") or ""
        report_path = os.path.join(folder, "report.txt")
        report = ""
        if os.path.exists(report_path):
            with open(report_path, "r", encoding="utf-8", errors="replace") as f:
                report = f.read()
        return json.dumps({
            "ok": True,
            "kind": res.get("family"),
            "files": _walk(os.path.join(folder, "files")) if folder else [],
            "zip": res.get("zip"),
            "folder": folder,
            "report": report,
            "count": res.get("files", 0),
        }, ensure_ascii=False)
    except Exception as exc:
        return json.dumps({"ok": False, "error": str(exc),
                           "trace": traceback.format_exc(limit=4)}, ensure_ascii=False)


def preview(folder, name, limit=4000):
    try:
        p = os.path.join(folder, "files", name)
        if not os.path.isfile(p):
            return ""
        with open(p, "r", encoding="utf-8", errors="replace") as f:
            return f.read(limit)
    except Exception:
        return ""
